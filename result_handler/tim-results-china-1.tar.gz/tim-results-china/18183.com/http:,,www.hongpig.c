[0711/234643.218440:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234643.218841:INFO:switcher_clone.cc(787)] backtrace rip is 7f81cecb6891
[0711/234644.190940:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234644.191456:INFO:switcher_clone.cc(787)] backtrace rip is 7f5d84a4b891
[1:1:0711/234644.205632:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/234644.205962:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/234644.211754:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[38199:38199:0711/234645.296858:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/3e54d1e9-fb39-437c-928f-53af5bd732c5
[0711/234645.523770:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234645.524073:INFO:switcher_clone.cc(787)] backtrace rip is 7f1e44211891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[38230:38230:0711/234645.763692:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=38230
[38243:38243:0711/234645.764209:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=38243
[38199:38199:0711/234645.822635:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[38199:38228:0711/234645.823303:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/234645.823550:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/234645.823766:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/234645.824337:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/234645.824512:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/234645.827395:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8fc45d4, 1
[1:1:0711/234645.827753:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2edcb7c2, 0
[1:1:0711/234645.827974:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x18a59121, 3
[1:1:0711/234645.828170:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x399095c3, 2
[1:1:0711/234645.828393:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc2ffffffb7ffffffdc2e ffffffd445fffffffc08 ffffffc3ffffff95ffffff9039 21ffffff91ffffffa518 , 10104, 4
[1:1:0711/234645.829401:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[38199:38228:0711/234645.829675:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING·�.�E�Õ�9!��5��3
[38199:38228:0711/234645.829760:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ·�.�E�Õ�9!��H
5��3
[1:1:0711/234645.829869:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5d82c860a0, 3
[38199:38228:0711/234645.830039:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/234645.830079:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5d82e11080, 2
[38199:38228:0711/234645.830118:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 38251, 4, c2b7dc2e d445fc08 c3959039 2191a518 
[1:1:0711/234645.830247:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5d6cad4d20, -2
[1:1:0711/234645.864592:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/234645.865486:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 399095c3
[1:1:0711/234645.866461:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 399095c3
[1:1:0711/234645.868066:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 399095c3
[1:1:0711/234645.869518:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.869740:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.869922:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.870117:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.870783:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 399095c3
[1:1:0711/234645.871085:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5d84a4b7ba
[1:1:0711/234645.871216:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5d84a42def, 7f5d84a4b77a, 7f5d84a4d0cf
[1:1:0711/234645.874434:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 399095c3
[1:1:0711/234645.874641:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 399095c3
[1:1:0711/234645.874937:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 399095c3
[1:1:0711/234645.875965:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.876217:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.876361:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.876464:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 399095c3
[1:1:0711/234645.876948:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 399095c3
[1:1:0711/234645.877107:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5d84a4b7ba
[1:1:0711/234645.877190:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5d84a42def, 7f5d84a4b77a, 7f5d84a4d0cf
[1:1:0711/234645.879377:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/234645.879651:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/234645.879742:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdfc977c18, 0x7ffdfc977b98)
[1:1:0711/234645.894747:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/234645.901013:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[38199:38222:0711/234646.450332:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[38199:38199:0711/234646.483307:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[38199:38199:0711/234646.485075:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[38199:38210:0711/234646.498053:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[38199:38199:0711/234646.498177:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[38199:38210:0711/234646.498170:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[38199:38199:0711/234646.498260:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[38199:38199:0711/234646.498393:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,38251, 4
[1:7:0711/234646.505159:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234646.670123:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3899d2080220
[1:1:0711/234646.670439:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/234647.030921:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[38199:38199:0711/234648.436355:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[38199:38199:0711/234648.436569:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/234648.465007:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234648.466873:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234649.250263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a3aceb61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/234649.250465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234649.255604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a3aceb61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/234649.255735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234649.264740:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234649.374322:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234649.374574:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234649.906041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234649.914216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a3aceb61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/234649.914450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234649.951049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234649.961514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a3aceb61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/234649.961767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234649.973530:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/234649.977100:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3899d207ee20
[1:1:0711/234649.977292:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[38199:38199:0711/234649.979123:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[38199:38199:0711/234649.994049:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[38199:38199:0711/234650.042337:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[38199:38199:0711/234650.042493:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/234650.072436:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234651.129677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f5d6e6af2e0 0x3899d21ebbe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234651.131349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a3aceb61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/234651.131609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234651.133557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[38199:38199:0711/234651.197973:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234651.200147:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3899d207f820
[1:1:0711/234651.200380:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[38199:38199:0711/234651.204884:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/234651.222472:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/234651.222725:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[38199:38199:0711/234651.223886:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[38199:38199:0711/234651.231589:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[38199:38199:0711/234651.232628:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[38199:38210:0711/234651.239065:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[38199:38210:0711/234651.239161:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[38199:38199:0711/234651.239410:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[38199:38199:0711/234651.239507:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[38199:38199:0711/234651.239682:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,38251, 4
[1:7:0711/234651.247279:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234651.851235:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/234652.457318:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 491 0x7f5d6e6af2e0 0x3899d23f92e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234652.458322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a3aceb61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/234652.458574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234652.459361:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234652.540611:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[38199:38199:0711/234652.544858:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[38199:38199:0711/234652.544915:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/234652.945290:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[38199:38199:0711/234653.372770:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[38199:38228:0711/234653.373232:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/234653.373416:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/234653.373690:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/234653.374100:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/234653.374287:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/234653.374851:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234653.375067:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/234653.377448:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33ae9360, 1
[1:1:0711/234653.377934:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x551576b, 0
[1:1:0711/234653.378115:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x24d9adc2, 3
[1:1:0711/234653.378291:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e6ea0a1, 2
[1:1:0711/234653.378459:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6b575105 60ffffff93ffffffae33 ffffffa1ffffffa06e2e ffffffc2ffffffadffffffd924 , 10104, 5
[1:1:0711/234653.379459:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[38199:38228:0711/234653.379807:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGkWQ`��3��n.­�$6��3
[38199:38228:0711/234653.379898:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is kWQ`��3��n.­�$�6��3
[1:1:0711/234653.379775:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5d82c860a0, 3
[1:1:0711/234653.379978:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5d82e11080, 2
[38199:38228:0711/234653.380157:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 38298, 5, 6b575105 6093ae33 a1a06e2e c2add924 
[1:1:0711/234653.380218:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5d6cad4d20, -2
[1:1:0711/234653.401096:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/234653.401466:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e6ea0a1
[1:1:0711/234653.401837:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e6ea0a1
[1:1:0711/234653.402468:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e6ea0a1
[1:1:0711/234653.403943:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.404193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.404403:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.404610:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.405300:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e6ea0a1
[1:1:0711/234653.405607:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5d84a4b7ba
[1:1:0711/234653.405775:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5d84a42def, 7f5d84a4b77a, 7f5d84a4d0cf
[1:1:0711/234653.411909:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e6ea0a1
[1:1:0711/234653.412352:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e6ea0a1
[1:1:0711/234653.413093:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e6ea0a1
[1:1:0711/234653.415053:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.415294:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.415509:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.415753:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e6ea0a1
[1:1:0711/234653.416991:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e6ea0a1
[1:1:0711/234653.417449:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5d84a4b7ba
[1:1:0711/234653.417755:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5d84a42def, 7f5d84a4b77a, 7f5d84a4d0cf
[1:1:0711/234653.427371:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/234653.428057:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/234653.428257:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdfc977c18, 0x7ffdfc977b98)
[1:1:0711/234653.442501:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/234653.446682:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/234653.649437:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3899d1fef220
[1:1:0711/234653.649678:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/234653.827876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 566, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/234653.832361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2a3acec909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/234653.832633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/234653.840412:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[38199:38199:0711/234654.416507:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[38199:38199:0711/234654.421399:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[38199:38199:0711/234654.455904:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.hongpig.com/
[38199:38199:0711/234654.456028:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hongpig.com/, http://www.hongpig.com/games/202924.html, 1
[38199:38199:0711/234654.456172:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.hongpig.com/, HTTP/1.1 200 OK Server: nginx Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Keep-Alive: timeout=20 Date: Fri, 12 Jul 2019 06:46:54 GMT X-Page-Speed: 1.12.34.2-0 Cache-Control: max-age=0, no-cache Content-Encoding: gzip  ,38298, 5
[38199:38210:0711/234654.457430:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[38199:38210:0711/234654.457511:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/234654.458565:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234654.510995:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.hongpig.com/
[1:1:0711/234654.634926:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[38199:38199:0711/234654.647534:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hongpig.com/, http://www.hongpig.com/, 1
[38199:38199:0711/234654.647595:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.hongpig.com/, http://www.hongpig.com
[1:1:0711/234654.692919:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234654.719370:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234654.719608:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hongpig.com/games/202924.html"
[1:1:0711/234655.012458:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/234655.479253:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234655.700560:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234655.701037:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234655.701398:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234655.701845:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234655.702199:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234655.741971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7f5d6caefbd0 0x3899d20c6d58 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234655.762040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};ret
[1:1:0711/234655.762329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234655.764392:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_72595326 -> 0
		remove user.11_71d391dc -> 0
		remove user.12_ac9ca26f -> 0
		remove user.13_266d7c9b -> 0
		remove user.14_27d67afb -> 0
[1:1:0711/234655.951639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7f5d6caefbd0 0x3899d20c6d58 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234655.966301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7f5d6caefbd0 0x3899d20c6d58 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234655.980480:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7f5d6caefbd0 0x3899d20c6d58 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234656.013718:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7f5d6caefbd0 0x3899d20c6d58 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234656.058235:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7f5d6caefbd0 0x3899d20c6d58 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234656.980790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f5d6caefbd0 0x3899d1ffc1d8 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234656.985540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , !function(){var a=window.dispatchEvent,b={preventDefaultEvent:function(a){a=window.event||a,a&&(a.pr
[1:1:0711/234656.985748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234657.291975:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234657.586264:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234657.586567:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hongpig.com/games/202924.html"
[1:1:0711/234657.587566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 302 0x7f5d6c787070 0x3899d21a5f60 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234657.590236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , if (self != top) {selfUrl = location.protocol+'//'+location.host+location.pathname;if (top.location 
[1:1:0711/234657.590489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234657.790680:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.204012, 690, 1
[1:1:0711/234657.791040:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234658.018251:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234658.018515:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hongpig.com/games/202924.html"
[1:1:0711/234658.022340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 325 0x7f5d6c787070 0x3899d2381860 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234658.023660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.write('<style>\r\n\t.bottom_toolbar{width:100%; min-width:980px; overflow:hidden;}\r\n\t.bo
[1:1:0711/234658.023923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234658.032556:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 325 0x7f5d6c787070 0x3899d2381860 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234704.367044:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 658 0x7f5d6caefbd0 0x3899d257ff58 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234704.374516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , (function(){var h={},mt={},c={id:"3782151c2b39bc6837a4913c89752cbc",dm:["18183.com"],js:"tongji.baid
[1:1:0711/234704.374806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234704.395153:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a160
[1:1:0711/234704.395405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234704.395849:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 674
[1:1:0711/234704.396089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 674 0x7f5d6c787070 0x3899d21a78e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 658 0x7f5d6caefbd0 0x3899d257ff58 
[38199:38199:0711/234708.519582:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://js.18183.com/pc/user/js/passport.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.18183.com/hongpigdl/common/js/top_toolbar.js (1)
[38199:38199:0711/234708.523587:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://js.18183.com/pc/user/js/passport.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.18183.com/hongpigdl/common/js/top_toolbar.js (1)
[38199:38199:0711/234708.592632:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?3782151c2b39bc6837a4913c89752cbc, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[38199:38199:0711/234708.596677:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?3782151c2b39bc6837a4913c89752cbc, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[38199:38199:0711/234708.737642:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/234708.763393:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/234711.233078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/234711.233383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234712.960401:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234713.064731:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 674, 7f5d6f0cc881
[1:1:0711/234713.101075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"658 0x7f5d6caefbd0 0x3899d257ff58 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234713.101439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"658 0x7f5d6caefbd0 0x3899d257ff58 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234713.101759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234713.102415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234713.102627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234713.103457:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234713.103651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234713.104082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 781
[1:1:0711/234713.104321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7f5d6c787070 0x3899d25c60e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 674 0x7f5d6c787070 0x3899d21a78e0 
[1:1:0711/234713.538814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234713.539098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234714.608406:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234714.608711:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hongpig.com/games/202924.html"
[1:1:0711/234714.609950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 780 0x7f5d6c787070 0x3899d2dc5ee0 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234714.611150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.w
[1:1:0711/234714.611369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[38199:38199:0711/234714.624538:INFO:CONSOLE(522)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://w.cnzz.com/c.php?id=1254606331, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.hongpig.com/games/202924.html (522)
[38199:38199:0711/234714.629065:INFO:CONSOLE(522)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://w.cnzz.com/c.php?id=1254606331, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.hongpig.com/games/202924.html (522)
[1:1:0711/234714.660676:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 781, 7f5d6f0cc881
[1:1:0711/234714.697184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"674 0x7f5d6c787070 0x3899d21a78e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234714.697529:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"674 0x7f5d6c787070 0x3899d21a78e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234714.698110:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234714.698780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234714.698995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234714.699737:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234714.699973:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234714.700381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 820
[1:1:0711/234714.700609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 820 0x7f5d6c787070 0x3899d2486960 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 781 0x7f5d6c787070 0x3899d25c60e0 
[1:1:0711/234714.910161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234714.910455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234716.118798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821, "http://www.hongpig.com/games/202924.html"
[1:1:0711/234716.125648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , (function(){function p(){this.c="1254606331";this.ca="q";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0711/234716.125939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234716.235505:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821, "http://www.hongpig.com/games/202924.html"
[1:1:0711/234716.318045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821, "http://www.hongpig.com/games/202924.html"
[1:1:0711/234716.328478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.hongpig.com/games/202924.html"
[38199:38199:0711/234716.333729:INFO:CONSOLE(1)] "Uncaught SyntaxError: Unexpected token <", source: http://www.hongpig.com/ (1)
[1:1:0711/234726.164739:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[38199:38199:0711/234730.608884:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/234733.666356:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234733.666855:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234734.458962:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.hongpig.com/games/202924.html"
[38199:38199:0711/234734.461413:INFO:CONSOLE(1)] "Uncaught TypeError: Cannot read property 'appendChild' of undefined", source: http://js.18183.com/hongpigdl/index/2018/js/qrcode.min.js (1)
[1:1:0711/234734.584184:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234734.585064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , f.onload, (){f.onload=v;f=window[d]=v;a&&a(b)}
[1:1:0711/234734.585333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234734.595952:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 820, 7f5d6f0cc881
[1:1:0711/234734.636113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"781 0x7f5d6c787070 0x3899d25c60e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234734.636418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"781 0x7f5d6c787070 0x3899d25c60e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234734.636723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234734.637152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234734.637337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234734.637791:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234734.637925:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234734.638237:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 896
[1:1:0711/234734.638398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7f5d6c787070 0x3899d27439e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 820 0x7f5d6c787070 0x3899d2486960 
[1:1:0711/234734.675867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234734.676047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/234736.130014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234736.130778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , f, (){c._bSupportDataURI=!0,c._fSuccess&&c._fSuccess.call(c)}
[1:1:0711/234736.130961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234736.567501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234736.567738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234736.571150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 896, 7f5d6f0cc881
[1:1:0711/234736.596906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"820 0x7f5d6c787070 0x3899d2486960 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234736.597102:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"820 0x7f5d6c787070 0x3899d2486960 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234736.597342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234736.597664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234736.597789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234736.598129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234736.598228:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234736.598405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 938
[1:1:0711/234736.598514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7f5d6c787070 0x3899d2ccf6e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 896 0x7f5d6c787070 0x3899d27439e0 
[1:1:0711/234736.983563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 916 0x7f5d6e6af2e0 0x3899d2c52560 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234736.987447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0711/234736.987673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.064017:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 917 0x7f5d6e6af2e0 0x3899d61bfde0 , "http://www.hongpig.com/games/202924.html"
[1:1:0711/234737.065948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0711/234737.066134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.367582:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234737.368536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0711/234737.368768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.563532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234737.563993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0711/234737.564161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.628288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234737.628465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.629777:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 938, 7f5d6f0cc881
[1:1:0711/234737.651294:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"896 0x7f5d6c787070 0x3899d27439e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234737.651494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"896 0x7f5d6c787070 0x3899d27439e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234737.651757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234737.652096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234737.652220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.652542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234737.652641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234737.652825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 959
[1:1:0711/234737.652934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7f5d6c787070 0x3899d50695e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 938 0x7f5d6c787070 0x3899d2ccf6e0 
[1:1:0711/234737.926398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234737.926644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.964439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 959, 7f5d6f0cc881
[1:1:0711/234737.978098:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"938 0x7f5d6c787070 0x3899d2ccf6e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234737.978303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"938 0x7f5d6c787070 0x3899d2ccf6e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234737.978514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234737.978829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234737.978939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234737.979295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234737.979398:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234737.979582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 965
[1:1:0711/234737.979693:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7f5d6c787070 0x3899d2dd3b60 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 959 0x7f5d6c787070 0x3899d50695e0 
[1:1:0711/234737.994341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234737.994512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.055979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234738.056297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.203659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234738.203829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.240744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 965, 7f5d6f0cc881
[1:1:0711/234738.275846:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"959 0x7f5d6c787070 0x3899d50695e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234738.276057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"959 0x7f5d6c787070 0x3899d50695e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234738.276295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234738.276625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234738.276728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.277039:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234738.277135:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234738.277339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 988
[1:1:0711/234738.277477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 988 0x7f5d6c787070 0x3899d69a7460 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 965 0x7f5d6c787070 0x3899d2dd3b60 
[1:1:0711/234738.306192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234738.306391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.438728:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234738.439469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0711/234738.439650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.443201:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234738.443811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234738.446737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.hongpig.com/games/202924.html"
[1:1:0711/234738.448042:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a2f0
[1:1:0711/234738.448206:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234738.448603:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 995
[1:1:0711/234738.448796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7f5d6c787070 0x3899d2626ee0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 986 0x7f5d6c787070 0x3899d66652e0 
[1:1:0711/234738.593378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , , document.readyState
[1:1:0711/234738.593615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.687906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 995, 7f5d6f0cc881
[1:1:0711/234738.729551:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"986 0x7f5d6c787070 0x3899d66652e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234738.729825:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"986 0x7f5d6c787070 0x3899d66652e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234738.730161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234738.730735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234738.730912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234738.731617:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234738.731777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234738.732137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1008
[1:1:0711/234738.732326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1008 0x7f5d6c787070 0x3899d4f446e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 995 0x7f5d6c787070 0x3899d2626ee0 
[1:1:0711/234739.082594:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1008, 7f5d6f0cc881
[1:1:0711/234739.123863:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"995 0x7f5d6c787070 0x3899d2626ee0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.124133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"995 0x7f5d6c787070 0x3899d2626ee0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.124463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234739.125103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234739.125276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234739.125977:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234739.126133:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234739.126518:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1017
[1:1:0711/234739.126707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7f5d6c787070 0x3899d6ae55e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1008 0x7f5d6c787070 0x3899d4f446e0 
[1:1:0711/234739.431041:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1017, 7f5d6f0cc881
[1:1:0711/234739.472815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1008 0x7f5d6c787070 0x3899d4f446e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.473083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1008 0x7f5d6c787070 0x3899d4f446e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.473424:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234739.473991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234739.474164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234739.474877:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234739.475035:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234739.475399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1030
[1:1:0711/234739.475598:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f5d6c787070 0x3899d6d5b5e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1017 0x7f5d6c787070 0x3899d6ae55e0 
[1:1:0711/234739.782018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1030, 7f5d6f0cc881
[1:1:0711/234739.812011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1017 0x7f5d6c787070 0x3899d6ae55e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.812179:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1017 0x7f5d6c787070 0x3899d6ae55e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.812373:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234739.812707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234739.812822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234739.813159:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234739.813261:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234739.813446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1042
[1:1:0711/234739.813557:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1042 0x7f5d6c787070 0x3899d5069b60 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1030 0x7f5d6c787070 0x3899d6d5b5e0 
[1:1:0711/234739.945114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1042, 7f5d6f0cc881
[1:1:0711/234739.957480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1030 0x7f5d6c787070 0x3899d6d5b5e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.957625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1030 0x7f5d6c787070 0x3899d6d5b5e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234739.957820:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234739.958123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234739.958226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234739.959612:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234739.959717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234739.959945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1050
[1:1:0711/234739.960055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1050 0x7f5d6c787070 0x3899d2c4e560 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1042 0x7f5d6c787070 0x3899d5069b60 
[1:1:0711/234740.071163:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1050, 7f5d6f0cc881
[1:1:0711/234740.085077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1042 0x7f5d6c787070 0x3899d5069b60 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.085258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1042 0x7f5d6c787070 0x3899d5069b60 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.085454:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234740.085800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234740.085924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234740.086258:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234740.086361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234740.086548:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1058
[1:1:0711/234740.086663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7f5d6c787070 0x3899d2028360 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1050 0x7f5d6c787070 0x3899d2c4e560 
[1:1:0711/234740.343324:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1058, 7f5d6f0cc881
[1:1:0711/234740.386739:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1050 0x7f5d6c787070 0x3899d2c4e560 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.387093:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1050 0x7f5d6c787070 0x3899d2c4e560 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.387443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234740.388041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234740.388220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234740.388931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234740.389091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234740.389457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1070
[1:1:0711/234740.389643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1070 0x7f5d6c787070 0x3899d5822fe0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1058 0x7f5d6c787070 0x3899d2028360 
[1:1:0711/234740.577416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1070, 7f5d6f0cc881
[1:1:0711/234740.620467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1058 0x7f5d6c787070 0x3899d2028360 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.620790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1058 0x7f5d6c787070 0x3899d2028360 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.621162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234740.621717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234740.621889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234740.622587:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234740.622742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234740.623147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1080
[1:1:0711/234740.623339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7f5d6c787070 0x3899d28dd7e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1070 0x7f5d6c787070 0x3899d5822fe0 
[1:1:0711/234740.744245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1080, 7f5d6f0cc881
[1:1:0711/234740.756671:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1070 0x7f5d6c787070 0x3899d5822fe0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.756815:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1070 0x7f5d6c787070 0x3899d5822fe0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.757025:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234740.757341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234740.757444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234740.757758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234740.757854:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234740.758053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1087
[1:1:0711/234740.758166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1087 0x7f5d6c787070 0x3899d1fe5360 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1080 0x7f5d6c787070 0x3899d28dd7e0 
[1:1:0711/234740.914024:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1087, 7f5d6f0cc881
[1:1:0711/234740.956909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1080 0x7f5d6c787070 0x3899d28dd7e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.957217:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1080 0x7f5d6c787070 0x3899d28dd7e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234740.957553:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234740.958109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234740.958284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234740.958961:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234740.959135:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234740.959503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1089
[1:1:0711/234740.959689:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7f5d6c787070 0x3899d1ff6860 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1087 0x7f5d6c787070 0x3899d1fe5360 
[1:1:0711/234741.109696:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1089, 7f5d6f0cc881
[1:1:0711/234741.152978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1087 0x7f5d6c787070 0x3899d1fe5360 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.153274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1087 0x7f5d6c787070 0x3899d1fe5360 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.153615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234741.154190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234741.154364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234741.155040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234741.155220:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234741.155581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1091
[1:1:0711/234741.155768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1091 0x7f5d6c787070 0x3899d2115460 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1089 0x7f5d6c787070 0x3899d1ff6860 
[1:1:0711/234741.307055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1091, 7f5d6f0cc881
[1:1:0711/234741.350174:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1089 0x7f5d6c787070 0x3899d1ff6860 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.350449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1089 0x7f5d6c787070 0x3899d1ff6860 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.350788:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234741.351361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234741.351637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234741.352392:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234741.352552:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234741.352922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1093
[1:1:0711/234741.353109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1093 0x7f5d6c787070 0x3899d33594e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1091 0x7f5d6c787070 0x3899d2115460 
[1:1:0711/234741.531549:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1093, 7f5d6f0cc881
[1:1:0711/234741.577617:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1091 0x7f5d6c787070 0x3899d2115460 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.577914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1091 0x7f5d6c787070 0x3899d2115460 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.578295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234741.578876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234741.579059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234741.579798:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234741.579965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234741.580412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1096
[1:1:0711/234741.580611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7f5d6c787070 0x3899d2088560 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1093 0x7f5d6c787070 0x3899d33594e0 
[1:1:0711/234741.749089:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1096, 7f5d6f0cc881
[1:1:0711/234741.792858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1093 0x7f5d6c787070 0x3899d33594e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.793158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1093 0x7f5d6c787070 0x3899d33594e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.793528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234741.794079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234741.794270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234741.794956:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234741.795113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234741.795511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1099
[1:1:0711/234741.795700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7f5d6c787070 0x3899d2dd34e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1096 0x7f5d6c787070 0x3899d2088560 
[1:1:0711/234741.964517:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1099, 7f5d6f0cc881
[1:1:0711/234741.983748:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1096 0x7f5d6c787070 0x3899d2088560 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.983908:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1096 0x7f5d6c787070 0x3899d2088560 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234741.984106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234741.984463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234741.984578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234741.984907:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234741.985011:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234741.985193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1101
[1:1:0711/234741.985341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7f5d6c787070 0x3899d6665ee0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1099 0x7f5d6c787070 0x3899d2dd34e0 
[1:1:0711/234742.138014:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1101, 7f5d6f0cc881
[1:1:0711/234742.184011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1099 0x7f5d6c787070 0x3899d2dd34e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.184312:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1099 0x7f5d6c787070 0x3899d2dd34e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.184726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234742.185301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234742.185501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234742.186217:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234742.186405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234742.192196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1103
[1:1:0711/234742.192439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7f5d6c787070 0x3899d201fb60 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1101 0x7f5d6c787070 0x3899d6665ee0 
[1:1:0711/234742.295073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1103, 7f5d6f0cc881
[1:1:0711/234742.308926:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1101 0x7f5d6c787070 0x3899d6665ee0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.309073:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1101 0x7f5d6c787070 0x3899d6665ee0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.309260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234742.309593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234742.309704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234742.310028:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234742.310130:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234742.310308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1106
[1:1:0711/234742.310448:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f5d6c787070 0x3899d5069860 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1103 0x7f5d6c787070 0x3899d201fb60 
[1:1:0711/234742.447780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1106, 7f5d6f0cc881
[1:1:0711/234742.464544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1103 0x7f5d6c787070 0x3899d201fb60 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.464706:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1103 0x7f5d6c787070 0x3899d201fb60 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.464896:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234742.465212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234742.465317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234742.465681:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234742.465784:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234742.465966:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1108
[1:1:0711/234742.466074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1108 0x7f5d6c787070 0x3899d4a8dbe0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1106 0x7f5d6c787070 0x3899d5069860 
[1:1:0711/234742.599148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1108, 7f5d6f0cc881
[1:1:0711/234742.613175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1106 0x7f5d6c787070 0x3899d5069860 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.613339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1106 0x7f5d6c787070 0x3899d5069860 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.613555:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234742.613874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234742.613984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234742.614313:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234742.614416:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234742.614624:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1110
[1:1:0711/234742.614740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1110 0x7f5d6c787070 0x3899d2de6be0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1108 0x7f5d6c787070 0x3899d4a8dbe0 
[1:1:0711/234742.776297:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1110, 7f5d6f0cc881
[1:1:0711/234742.822827:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1108 0x7f5d6c787070 0x3899d4a8dbe0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.823160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1108 0x7f5d6c787070 0x3899d4a8dbe0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234742.823524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234742.824129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234742.824310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234742.825074:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234742.825240:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234742.825672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1112
[1:1:0711/234742.825874:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7f5d6c787070 0x3899d5a3e5e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1110 0x7f5d6c787070 0x3899d2de6be0 
[1:1:0711/234742.972156:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1112, 7f5d6f0cc881
[1:1:0711/234743.008412:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1110 0x7f5d6c787070 0x3899d2de6be0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.008640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1110 0x7f5d6c787070 0x3899d2de6be0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.008859:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234743.009183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234743.009295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234743.009662:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234743.009776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234743.009961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1115
[1:1:0711/234743.010076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1115 0x7f5d6c787070 0x3899d4f44be0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1112 0x7f5d6c787070 0x3899d5a3e5e0 
[1:1:0711/234743.168724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1115, 7f5d6f0cc881
[1:1:0711/234743.215261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1112 0x7f5d6c787070 0x3899d5a3e5e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.215565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1112 0x7f5d6c787070 0x3899d5a3e5e0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.215997:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234743.216567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234743.216773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234743.217483:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234743.217664:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234743.218058:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1117
[1:1:0711/234743.218252:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1117 0x7f5d6c787070 0x3899d5697760 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1115 0x7f5d6c787070 0x3899d4f44be0 
[1:1:0711/234743.368408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1117, 7f5d6f0cc881
[1:1:0711/234743.415244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1115 0x7f5d6c787070 0x3899d4f44be0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.415536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1115 0x7f5d6c787070 0x3899d4f44be0 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.415948:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234743.416536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234743.416750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234743.417487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234743.417657:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234743.418071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1120
[1:1:0711/234743.418274:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7f5d6c787070 0x3899d3325960 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1117 0x7f5d6c787070 0x3899d5697760 
[1:1:0711/234743.568811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1120, 7f5d6f0cc881
[1:1:0711/234743.584649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a362d882860","ptid":"1117 0x7f5d6c787070 0x3899d5697760 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.584879:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hongpig.com/","ptid":"1117 0x7f5d6c787070 0x3899d5697760 ","rf":"5:3_http://www.hongpig.com/"}
[1:1:0711/234743.585109:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hongpig.com/games/202924.html"
[1:1:0711/234743.585474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hongpig.com/, 3a362d882860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/234743.585596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hongpig.com/games/202924.html", "www.hongpig.com", 3, 1, , , 0
[1:1:0711/234743.585991:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x287fe3e029c8, 0x3899d1e7a150
[1:1:0711/234743.586108:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hongpig.com/games/202924.html", 100
[1:1:0711/234743.586316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hongpig.com/, 1123
[1:1:0711/234743.586438:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7f5d6c787070 0x3899d208a2e0 , 5:3_http://www.hongpig.com/, 1, -5:3_http://www.hongpig.com/, 1120 0x7f5d6c787070 0x3899d3325960 
