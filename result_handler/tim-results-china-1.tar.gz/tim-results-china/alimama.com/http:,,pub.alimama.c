[0711/205137.435905:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/205137.436242:INFO:switcher_clone.cc(787)] backtrace rip is 7f35f85b9891
[0711/205138.408598:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/205138.408897:INFO:switcher_clone.cc(787)] backtrace rip is 7f138adfd891
[1:1:0711/205138.413015:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/205138.413186:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/205138.418369:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[14762:14762:0711/205139.701798:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/968acc0b-7868-48c6-ad44-44f240dcc01a
[0711/205139.821530:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/205139.822010:INFO:switcher_clone.cc(787)] backtrace rip is 7fe9a7882891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[14794:14794:0711/205140.052929:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=14794
[14806:14806:0711/205140.053378:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=14806
[14762:14762:0711/205140.297361:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[14762:14792:0711/205140.298099:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/205140.298322:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/205140.298560:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/205140.299173:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/205140.299362:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/205140.302266:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x24ff99fd, 1
[1:1:0711/205140.302567:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x180fa4fa, 0
[1:1:0711/205140.302739:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x53963bf, 3
[1:1:0711/205140.302898:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x253ff5c3, 2
[1:1:0711/205140.303080:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffaffffffa40f18 fffffffdffffff99ffffffff24 ffffffc3fffffff53f25 ffffffbf633905 , 10104, 4
[1:1:0711/205140.304210:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14762:14792:0711/205140.304419:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�����$��?%�c9}t�8
[14762:14792:0711/205140.304506:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �����$��?%�c9XV}t�8
[1:1:0711/205140.304619:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13890380a0, 3
[14762:14792:0711/205140.304827:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[14762:14792:0711/205140.304900:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14814, 4, faa40f18 fd99ff24 c3f53f25 bf633905 
[1:1:0711/205140.304876:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13891c3080, 2
[1:1:0711/205140.305090:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1372e86d20, -2
[1:1:0711/205140.315115:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/205140.315804:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 253ff5c3
[1:1:0711/205140.316769:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 253ff5c3
[1:1:0711/205140.318329:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 253ff5c3
[1:1:0711/205140.319819:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.320018:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.320200:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.320388:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.321053:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 253ff5c3
[1:1:0711/205140.321380:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f138adfd7ba
[1:1:0711/205140.321514:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f138adf4def, 7f138adfd77a, 7f138adff0cf
[1:1:0711/205140.327183:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 253ff5c3
[1:1:0711/205140.327616:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 253ff5c3
[1:1:0711/205140.328451:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 253ff5c3
[1:1:0711/205140.330538:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.330770:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.330957:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.331136:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 253ff5c3
[1:1:0711/205140.333343:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 253ff5c3
[1:1:0711/205140.333738:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f138adfd7ba
[1:1:0711/205140.333902:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f138adf4def, 7f138adfd77a, 7f138adff0cf
[1:1:0711/205140.342363:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/205140.342910:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/205140.343086:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffe6b8fae8, 0x7fffe6b8fa68)
[1:1:0711/205140.359916:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/205140.365714:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[14762:14762:0711/205140.958013:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14762:14762:0711/205140.958769:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14762:14773:0711/205140.968693:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[14762:14773:0711/205140.968792:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[14762:14762:0711/205140.969030:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[14762:14762:0711/205140.969109:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[14762:14762:0711/205140.969254:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,14814, 4
[1:7:0711/205140.971308:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[14762:14784:0711/205141.007378:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/205141.098752:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2537a9700220
[1:1:0711/205141.099599:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/205141.434091:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[14762:14762:0711/205142.826472:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[14762:14762:0711/205142.826668:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/205142.862397:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205142.866370:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/205143.878556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 12a91a641f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/205143.878733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205143.883754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 12a91a641f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/205143.883934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205143.903853:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/205144.146905:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205144.147120:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205144.602538:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205144.610566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 12a91a641f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/205144.610808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205144.647084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205144.657799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 12a91a641f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/205144.658036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205144.669882:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/205144.673289:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2537a96fee20
[1:1:0711/205144.673459:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[14762:14762:0711/205144.674596:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[14762:14762:0711/205144.690783:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[14762:14762:0711/205144.740736:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[14762:14762:0711/205144.740934:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/205144.785110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205146.031282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f1374a612e0 0x2537a99389e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205146.033008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 12a91a641f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/205146.033282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205146.035145:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205146.110505:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2537a96ff820
[1:1:0711/205146.110753:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[14762:14762:0711/205146.110992:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[14762:14762:0711/205146.119176:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/205146.123175:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/205146.123327:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[14762:14762:0711/205146.138131:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[14762:14762:0711/205146.150317:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14762:14762:0711/205146.151474:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14762:14773:0711/205146.157470:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[14762:14773:0711/205146.157560:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[14762:14762:0711/205146.157718:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[14762:14762:0711/205146.157793:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[14762:14762:0711/205146.157926:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,14814, 4
[1:7:0711/205146.161538:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/205146.672299:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/205146.920969:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f1374a612e0 0x2537a99f25e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205146.922009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 12a91a641f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/205146.922280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205146.923043:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[14762:14762:0711/205147.233006:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[14762:14762:0711/205147.233125:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/205147.243648:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/205147.424592:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[14762:14762:0711/205147.691024:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[14762:14792:0711/205147.691531:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/205147.691771:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/205147.692013:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/205147.692399:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/205147.692647:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/205147.695776:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1c164820, 1
[1:1:0711/205147.696126:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3d50e92f, 0
[1:1:0711/205147.696368:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3352a2c6, 3
[1:1:0711/205147.696505:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e0116d5, 2
[1:1:0711/205147.696596:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2fffffffe9503d 2048161c ffffffd516012e ffffffc6ffffffa25233 , 10104, 5
[1:1:0711/205147.697298:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14762:14792:0711/205147.697455:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING/�P= H�.ƢR3�v�8
[14762:14792:0711/205147.697494:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is /�P= H�.ƢR3���v�8
[1:1:0711/205147.697562:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13890380a0, 3
[1:1:0711/205147.697666:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13891c3080, 2
[14762:14792:0711/205147.697720:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14859, 5, 2fe9503d 2048161c d516012e c6a25233 
[1:1:0711/205147.697770:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1372e86d20, -2
[1:1:0711/205147.708095:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/205147.708376:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e0116d5
[1:1:0711/205147.708612:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e0116d5
[1:1:0711/205147.708970:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e0116d5
[1:1:0711/205147.709656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.709799:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.709935:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.710076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.710438:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e0116d5
[1:1:0711/205147.710640:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f138adfd7ba
[1:1:0711/205147.710750:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f138adf4def, 7f138adfd77a, 7f138adff0cf
[1:1:0711/205147.713102:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e0116d5
[1:1:0711/205147.713362:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e0116d5
[1:1:0711/205147.713768:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e0116d5
[1:1:0711/205147.714808:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.714975:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.715118:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.715264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e0116d5
[1:1:0711/205147.715961:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e0116d5
[1:1:0711/205147.716189:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f138adfd7ba
[1:1:0711/205147.716352:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f138adf4def, 7f138adfd77a, 7f138adff0cf
[1:1:0711/205147.719189:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/205147.719608:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/205147.719731:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffe6b8fae8, 0x7fffe6b8fa68)
[1:1:0711/205147.731053:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/205147.734322:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/205147.958237:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2537a96cd220
[1:1:0711/205147.958520:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/205148.007906:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205148.008178:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[14762:14762:0711/205148.503803:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0711/205148.521329:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205148.523765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 12a91a7709f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/205148.524108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[14762:14762:0711/205148.536383:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[14762:14792:0711/205148.536829:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0711/205148.537104:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/205148.538133:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[1:1:0711/205148.532081:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[3:3:0711/205148.538676:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/205148.538916:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0711/205148.543283:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1d1868e2, 1
[1:1:0711/205148.543631:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x30941d17, 0
[1:1:0711/205148.543826:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x209540b, 3
[1:1:0711/205148.543985:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e816e53, 2
[1:1:0711/205148.544141:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 171dffffff9430 ffffffe268181d 536effffff812e 0b540902 , 10104, 6
[1:1:0711/205148.545195:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14762:14792:0711/205148.545523:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�0�hSn�.T	�v�8
[14762:14792:0711/205148.545621:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �0�hSn�.T	hB�v�8
[1:1:0711/205148.545502:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13890380a0, 3
[1:1:0711/205148.545710:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13891c3080, 2
[14762:14792:0711/205148.545949:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14875, 6, 171d9430 e268181d 536e812e 0b540902 
[1:1:0711/205148.545912:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1372e86d20, -2
[1:1:0711/205148.569045:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/205148.569390:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e816e53
[1:1:0711/205148.569707:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e816e53
[1:1:0711/205148.570285:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e816e53
[1:1:0711/205148.571590:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[1:1:0711/205148.571703:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[1:1:0711/205148.571800:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[1:1:0711/205148.571892:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[14762:14762:0711/205148.572197:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/205148.572122:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e816e53
[1:1:0711/205148.572453:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f138adfd7ba
[1:1:0711/205148.572659:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f138adf4def, 7f138adfd77a, 7f138adff0cf
[1:1:0711/205148.579534:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e816e53
[1:1:0711/205148.580016:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e816e53
[1:1:0711/205148.580934:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e816e53
[1:1:0711/205148.583272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[1:1:0711/205148.583496:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[1:1:0711/205148.583684:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[1:1:0711/205148.583859:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e816e53
[1:1:0711/205148.585125:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e816e53
[1:1:0711/205148.585500:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f138adfd7ba
[14762:14773:0711/205148.585715:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[1:1:0711/205148.585655:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f138adf4def, 7f138adfd77a, 7f138adff0cf
[14762:14773:0711/205148.585806:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[14762:14762:0711/205148.586011:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pub.alimama.com/
[14762:14762:0711/205148.586068:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://pub.alimama.com/, https://pub.alimama.com/, 1
[14762:14762:0711/205148.586789:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://pub.alimama.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 03:51:48 GMT content-type:text/html;charset=UTF-8 server:Tengine vary:Accept-Encoding s:STATUS_NOT_EXISTED access-control-allow-origin:https://shop.alimama.com access-control-allow-credentials:true access-control-allow-methods:GET,POST set-cookie:t=95d7b6d42819ea23dde7884ff47eb44a; Domain=.alimama.com; Expires=Tue, 10-Apr-2029 04:31:48 GMT; Path=/ set-cookie:cookie2=1f7d3e02e3bcf18a0b9936a962ae3cff;Domain=.alimama.com;Path=/;HttpOnly set-cookie:v=0; Domain=.alimama.com; Path=/ set-cookie:_tb_token_=363e386576758; Domain=.alimama.com; Path=/ p3p:CP='CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR' content-language:en-US content-encoding:gzip eagleeye-traceid:0b17483300158697582108906e5701 strict-transport-security:max-age=31536000 timing-allow-origin:*  ,0, 6
[3:3:0711/205148.590835:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/205148.593850:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/205148.594397:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/205148.594605:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffe6b8fae8, 0x7fffe6b8fa68)
[1:1:0711/205148.610760:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/205148.615442:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0711/205148.665909:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/205148.803263:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205148.804251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 12a91a641f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/205148.804617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205148.815692:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2537a96ec220
[1:1:0711/205148.816017:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/205148.917340:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://pub.alimama.com/
[1:1:0711/205149.220323:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[14762:14762:0711/205149.249771:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://pub.alimama.com/, https://pub.alimama.com/, 1
[14762:14762:0711/205149.249874:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://pub.alimama.com/, https://pub.alimama.com
[1:1:0711/205149.306565:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/205149.426360:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205149.426663:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pub.alimama.com/"
[1:1:0711/205149.561892:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205149.563219:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/205149.563451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 12a91a7709f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/205149.563790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205149.715289:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205149.716155:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/205149.716326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 12a91a7709f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/205149.716541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205150.388453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f1372b39070 0x2537a97db260 , "https://pub.alimama.com/"
[1:1:0711/205150.394578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , var requirejs,require,define;!function(global){function isFunction(e){return"[object Function]"===os
[1:1:0711/205150.394844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205150.399043:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205150.420156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9b0
[1:1:0711/205150.420521:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.421017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 184
[1:1:0711/205150.421258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 184 0x7f1372b39070 0x2537a9894a60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.443166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9b0
[1:1:0711/205150.443438:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.443810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 185
[1:1:0711/205150.444070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 185 0x7f1372b39070 0x2537a9892060 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.459095:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9b0
[1:1:0711/205150.459397:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.459803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 186
[1:1:0711/205150.460087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 186 0x7f1372b39070 0x2537a974cf60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.473271:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9b0
[1:1:0711/205150.473551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.473957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 187
[1:1:0711/205150.474194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 187 0x7f1372b39070 0x2537a98722e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.493254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9b0
[1:1:0711/205150.493533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.494002:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 188
[1:1:0711/205150.494268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 188 0x7f1372b39070 0x2537a97db1e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.499844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f1372b39070 0x2537a97db260 , "https://pub.alimama.com/"
[1:1:0711/205150.504664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f1372b39070 0x2537a97db260 , "https://pub.alimama.com/"
[1:1:0711/205150.509078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3a82a92429c8, 0x2537a92ec9a8
[1:1:0711/205150.509329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 5000
[1:1:0711/205150.509706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 193
[1:1:0711/205150.510000:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 193 0x7f1372b39070 0x2537a97dd4e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.515245:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f1372b39070 0x2537a97db260 , "https://pub.alimama.com/"
[1:1:0711/205150.531737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f1372b39070 0x2537a97db260 , "https://pub.alimama.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/205150.799179:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f1372b39070 0x2537a97db260 , "https://pub.alimama.com/"
[1:1:0711/205150.807269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f1372b39070 0x2537a97db260 , "https://pub.alimama.com/"
[1:1:0711/205150.817892:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9a8
[1:1:0711/205150.818217:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.818690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 207
[1:1:0711/205150.819007:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 207 0x7f1372b39070 0x2537a9893fe0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.823519:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9a8
[1:1:0711/205150.823729:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.824233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 208
[1:1:0711/205150.824465:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 208 0x7f1372b39070 0x2537a97c6b60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.826587:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9a8
[1:1:0711/205150.826787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205150.827205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 209
[1:1:0711/205150.827435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 209 0x7f1372b39070 0x2537a9888be0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 182 0x7f1372b39070 0x2537a97db260 
[1:1:0711/205150.834111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://pub.alimama.com/"
[1:1:0711/205151.005867:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205151.006220:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205151.006495:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205151.006848:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205151.007274:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205151.104906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 184, 7f137547e881
[1:1:0711/205151.114648:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.114973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.115297:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.115854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.116175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.130308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 185, 7f137547e881
[1:1:0711/205151.141068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.141435:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.141753:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.142331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.142546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.154340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 186, 7f137547e881
[1:1:0711/205151.163981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.164338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.164635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.165170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.165369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.189137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 187, 7f137547e881
[1:1:0711/205151.197005:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.197310:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.197593:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.198201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.198423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.209345:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 188, 7f137547e881
[1:1:0711/205151.219762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.220168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.220495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.221004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.221215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.235748:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 207, 7f137547e881
[1:1:0711/205151.245531:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.245848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.246181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.246698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.246912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.263886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1374a612e0 0x2537a97da8e0 , "https://pub.alimama.com/"
[1:1:0711/205151.265041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , 
	    window.tcl_176227&&tcl_176227(
		{"176227":{"dynamic":false,"value":{"moduleinfo":{"developme
[1:1:0711/205151.265286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.266712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205151.281537:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 208, 7f137547e881
[1:1:0711/205151.290033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.290359:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.290693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.291214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.291452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.298659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 209, 7f137547e881
[1:1:0711/205151.309234:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.309583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"182 0x7f1372b39070 0x2537a97db260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205151.309927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205151.310492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205151.310737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205151.433718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205151.433998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205151.434459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 248
[1:1:0711/205151.434702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 248 0x7f1372b39070 0x2537a97deee0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 209 0x7f1372b39070 0x2537a9888be0 
[1:1:0711/205151.484779:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f1374a612e0 0x2537a9984260 , "https://pub.alimama.com/"
[1:1:0711/205151.488302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , !function e(t,n,r){function a(i,u){if(!n[i]){if(!t[i]){var s="function"==typeof require&&require;if(
[1:1:0711/205151.488577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[3:3:0711/205201.805580:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/205202.346209:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205202.614487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/205202.614845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205202.874856:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 248, 7f137547e881
[1:1:0711/205202.890270:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"209 0x7f1372b39070 0x2537a9888be0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205202.890687:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"209 0x7f1372b39070 0x2537a9888be0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205202.891082:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205202.891592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205202.891825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205202.897847:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205202.898063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205202.898435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 334
[1:1:0711/205202.898695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 334 0x7f1372b39070 0x2537a99c43e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 248 0x7f1372b39070 0x2537a97deee0 
[14762:14762:0711/205202.936053:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/205202.956252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0711/205202.956543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205202.974844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0711/205202.975119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.131759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 303 0x7f1374a612e0 0x2537a99c3260 , "https://pub.alimama.com/"
[1:1:0711/205203.142009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , !function(e,t,n,r,i,a,o,s,u,f){f=1,u=function(e){return e.id||(e.id="mx_n_"+f++)},s("magix",["jquery
[1:1:0711/205203.142299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.145631:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205203.246126:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f1374a612e0 0x2537a99c2f60 , "https://pub.alimama.com/"
[1:1:0711/205203.247926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , /*
 * api文档：http://docs.kissyui.com/1.4/docs/html/api/cookie/index.html
 */
/* global define *
[1:1:0711/205203.248241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.250069:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205203.341476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f1374a612e0 0x2537a988a460 , "https://pub.alimama.com/"
[1:1:0711/205203.343398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==type
[1:1:0711/205203.343654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.345391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205203.496728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7f1374a612e0 0x2537a97db060 , "https://pub.alimama.com/"
[1:1:0711/205203.501394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==type
[1:1:0711/205203.501746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.503509:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205203.572467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f1374a612e0 0x2537a99c3ee0 , "https://pub.alimama.com/"
[1:1:0711/205203.581442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("brix/loader/constant",[],function(){var e="0.0.x",t=(Math.random()+"").replace(/\D/g,"");ret
[1:1:0711/205203.581716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.585168:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
		remove user.10_9b583aef -> 0
		remove user.11_efb983b1 -> 0
		remove user.12_2482e2e5 -> 0
		remove user.13_9d5184ae -> 0
		remove user.14_d8e93682 -> 0
		remove user.10_2a1d90ce -> 0
[1:1:0711/205203.900830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7f1374a612e0 0x2537a99c5de0 , "https://pub.alimama.com/"
[1:1:0711/205203.904103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , var CONFIG={spma:"a219t",logkey:"alimama.11",dialogKey:"null",bottom_spmb:"",pages:{"/manage/effect/
[1:1:0711/205203.904344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.907954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205203.985462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 312 0x7f1374a612e0 0x2537a9580be0 , "https://pub.alimama.com/"
[1:1:0711/205203.987834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , /* 2017-05-15 10:58:48 */
!function(e){if("object"==typeof exports)module.exports=e();else if("funct
[1:1:0711/205203.988008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205203.989099:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205204.027312:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205204.027566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pub.alimama.com/, 359
[1:1:0711/205204.027691:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 359 0x7f1372b39070 0x2537a999c6e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 312 0x7f1374a612e0 0x2537a9580be0 
[1:1:0711/205204.049861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f1374a612e0 0x2537a999cae0 , "https://pub.alimama.com/"
[1:1:0711/205204.055667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , /*!
 * @overview es6-promise - a tiny implementation of Promises/A+.
 * @copyright Copyright (c) 201
[1:1:0711/205204.056010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205204.060941:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205204.127082:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 315 0x7f1374a612e0 0x2537a98898e0 , "https://pub.alimama.com/"
[1:1:0711/205204.135847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , "use strict";var _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){ret
[1:1:0711/205204.136106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205204.669365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205204.669556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205204.682939:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 334, 7f137547e881
[1:1:0711/205204.689470:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"248 0x7f1372b39070 0x2537a97deee0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205204.689718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"248 0x7f1372b39070 0x2537a97deee0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205204.690019:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205204.690474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205204.690640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205204.693560:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205204.693747:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205204.693922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 408
[1:1:0711/205204.694052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 408 0x7f1372b39070 0x2537aa121be0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 334 0x7f1372b39070 0x2537a99c43e0 
[1:1:0711/205204.882649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pub.alimama.com/, 359, 7f137547e8db
[1:1:0711/205204.903489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"312 0x7f1374a612e0 0x2537a9580be0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205204.903690:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"312 0x7f1374a612e0 0x2537a9580be0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205204.904042:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pub.alimama.com/, 417
[1:1:0711/205204.904303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 417 0x7f1372b39070 0x2537a973dae0 , 6:3_https://pub.alimama.com/, 0, , 359 0x7f1372b39070 0x2537a999c6e0 
[1:1:0711/205204.904604:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205204.905142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , e, (){u=a.jQuery||a.Zepto,u&&t.setup()}
[1:1:0711/205204.905319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205205.237964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (e){t(e)}
[1:1:0711/205205.238174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205205.241962:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f1386098bb0 0x2537a9a53720 0 , "https://pub.alimama.com/"
[1:1:0711/205205.537263:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x3a82a92429c8, 0x2537a92ecd88
[1:1:0711/205205.537514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 1000
[1:1:0711/205205.537850:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 439
[1:1:0711/205205.538116:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 439 0x7f1372b39070 0x2537a97de460 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 384 0x7f1386098bb0 0x2537a9a53720 0 
[1:1:0711/205205.593866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ecd88
[1:1:0711/205205.594030:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205205.594213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 440
[1:1:0711/205205.594343:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 440 0x7f1372b39070 0x2537a96c0260 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 384 0x7f1386098bb0 0x2537a9a53720 0 
[1:1:0711/205205.625903:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x3a82a92429c8, 0x2537a92ecd88
[1:1:0711/205205.626097:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 10
[1:1:0711/205205.626311:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 442
[1:1:0711/205205.626428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 442 0x7f1372b39070 0x2537a97db560 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 384 0x7f1386098bb0 0x2537a9a53720 0 
[1:1:0711/205205.982000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205205.982238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205206.040312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 408, 7f137547e881
[1:1:0711/205206.063370:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"334 0x7f1372b39070 0x2537a99c43e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205206.063756:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"334 0x7f1372b39070 0x2537a99c43e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205206.064213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205206.064840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205206.065059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205206.070820:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205206.071100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205206.071552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 461
[1:1:0711/205206.071827:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 461 0x7f1372b39070 0x2537a9836ae0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 408 0x7f1372b39070 0x2537aa121be0 
[1:1:0711/205206.168720:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 412 0x7f1374a612e0 0x2537aa11bb60 , "https://pub.alimama.com/"
[1:1:0711/205206.171332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("brix/event/constant",[],function(){return{PREFIX:"bx-",BX_EVENT_NAMESPACE:"."+(Math.random()
[1:1:0711/205206.171506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205206.174224:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205207.270002:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7f1374a612e0 0x2537aa116ee0 , "https://pub.alimama.com/"
[1:1:0711/205207.278282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , //     Underscore.js 1.7.0
//     http://underscorejs.org
//     (c) 2009-2014 Jeremy Ashkenas, Docu
[1:1:0711/205207.278494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205207.451782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205207.533628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f1374a612e0 0x2537a999cfe0 , "https://pub.alimama.com/"
[1:1:0711/205207.536405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , /*! jQuery v1.12.4 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0711/205207.536557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205207.655620:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3a82a92429c8, 0x2537a92ec960
[1:1:0711/205207.655923:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 0
[1:1:0711/205207.656252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 486
[1:1:0711/205207.656442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 486 0x7f1372b39070 0x2537a9587de0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 415 0x7f1374a612e0 0x2537a999cfe0 
[1:1:0711/205207.703901:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205207.704376:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205207.759686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205208.024573:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pub.alimama.com/, 417, 7f137547e8db
[1:1:0711/205208.039479:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"359 0x7f1372b39070 0x2537a999c6e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.039682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"359 0x7f1372b39070 0x2537a999c6e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.039979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pub.alimama.com/, 497
[1:1:0711/205208.040107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 497 0x7f1372b39070 0x2537aa8e8460 , 6:3_https://pub.alimama.com/, 0, , 417 0x7f1372b39070 0x2537a973dae0 
[1:1:0711/205208.040270:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205208.040553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , e, (){u=a.jQuery||a.Zepto,u&&t.setup()}
[1:1:0711/205208.040658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205208.539635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 442, 7f137547e881
[1:1:0711/205208.559842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"384 0x7f1386098bb0 0x2537a9a53720 0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.560157:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"384 0x7f1386098bb0 0x2537a9a53720 0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.560447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205208.560857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0711/205208.561040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205208.776251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205208.776545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205208.802237:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 440, 7f137547e881
[1:1:0711/205208.818095:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"384 0x7f1386098bb0 0x2537a9a53720 0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.818520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"384 0x7f1386098bb0 0x2537a9a53720 0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.819056:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205208.819672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205208.819897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205208.820883:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205208.821094:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205208.821540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 518
[1:1:0711/205208.821841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f1372b39070 0x2537aab31560 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 440 0x7f1372b39070 0x2537a96c0260 
[1:1:0711/205208.823744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 461, 7f137547e881
[1:1:0711/205208.846546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"408 0x7f1372b39070 0x2537aa121be0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.846961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"408 0x7f1372b39070 0x2537aa121be0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.847499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205208.848162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205208.848386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205208.924279:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 439, 7f137547e881
[1:1:0711/205208.930894:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"384 0x7f1386098bb0 0x2537a9a53720 0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.931114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"384 0x7f1386098bb0 0x2537a9a53720 0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205208.931314:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205208.931630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0711/205208.931733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205208.975513:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pub.alimama.com/"
[1:1:0711/205208.975902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , c, (a,d){var f,i,j;if(c&&(d||4===g.readyState))if(delete fc[h],c=void 0,g.onreadystatechange=n.noop,d)4
[1:1:0711/205208.976096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205208.977424:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pub.alimama.com/"
[1:1:0711/205208.980942:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pub.alimama.com/"
[1:1:0711/205208.981713:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2d95ef3995a8
[1:1:0711/205209.043882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 486, 7f137547e881
[1:1:0711/205209.067726:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"415 0x7f1374a612e0 0x2537a999cfe0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205209.068129:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"415 0x7f1374a612e0 0x2537a999cfe0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205209.068523:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205209.069055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , ready, (a){(a===!0?--n.readyWait:n.isReady)||(n.isReady=!0,a!==!0&&--n.readyWait>0||(I.resolveWith(d,[n]),n
[1:1:0711/205209.069233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205209.229741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pub.alimama.com/"
[1:1:0711/205209.230483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , c, (a,d){var f,i,j;if(c&&(d||4===g.readyState))if(delete fc[h],c=void 0,g.onreadystatechange=n.noop,d)4
[1:1:0711/205209.230665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205209.231126:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pub.alimama.com/"
[1:1:0711/205209.234116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pub.alimama.com/"
[1:1:0711/205209.234935:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2d95ef3995a8
[1:1:0711/205209.248644:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92eca10
[1:1:0711/205209.248859:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205209.249221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 530
[1:1:0711/205209.249411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7f1372b39070 0x2537aa8e8de0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 495
[1:1:0711/205209.528214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205209.528416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205209.671973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 530, 7f137547e881
[1:1:0711/205209.679535:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"495","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205209.679717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"495","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205209.679915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205209.680260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205209.680394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205209.702826:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205209.703035:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205209.703362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 554
[1:1:0711/205209.703558:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7f1372b39070 0x2537a99c6760 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 530 0x7f1372b39070 0x2537aa8e8de0 
[1:1:0711/205209.750933:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 518, 7f137547e881
[1:1:0711/205209.766635:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"440 0x7f1372b39070 0x2537a96c0260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205209.766825:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"440 0x7f1372b39070 0x2537a96c0260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205209.767056:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205209.767477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205209.767584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205209.767963:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205209.768062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205209.768283:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 557
[1:1:0711/205209.768398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7f1372b39070 0x2537aa6f8c60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 518 0x7f1372b39070 0x2537aab31560 
[1:1:0711/205209.851351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545 0x7f1374a612e0 0x2537aab38be0 , "https://pub.alimama.com/"
[1:1:0711/205209.852797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0711/205209.852982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205209.868023:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205209.944343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f1374a612e0 0x2537a94383e0 , "https://pub.alimama.com/"
[1:1:0711/205209.944995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="R3KTFa0Quk8CAdrxhyKpAJUj";goldlog.stag=1;
[1:1:0711/205209.945113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205209.945498:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205209.945852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205209.995418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205209.995693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205210.152542:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 554, 7f137547e881
[1:1:0711/205210.166435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"530 0x7f1372b39070 0x2537aa8e8de0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205210.166744:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"530 0x7f1372b39070 0x2537aa8e8de0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205210.167080:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205210.167607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205210.167779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205210.169825:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205210.170005:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205210.170362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 582
[1:1:0711/205210.170549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7f1372b39070 0x2537a955c260 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 554 0x7f1372b39070 0x2537a99c6760 
[1:1:0711/205210.378268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205210.378609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205210.518855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7f1374a612e0 0x2537aa121de0 , "https://pub.alimama.com/"
[1:1:0711/205210.520008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/ini",["jquery","magix"],function(a,e){var t="app/views/layout/default",i={"app/views/lay
[1:1:0711/205210.520184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205210.521099:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205210.521556:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205210.555690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3a82a92429c8, 0x2537a92ec9e0
[1:1:0711/205210.555965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 4
[1:1:0711/205210.556420:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 593
[1:1:0711/205210.556686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 593 0x7f1372b39070 0x2537a9aa0e60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 579 0x7f1374a612e0 0x2537aa121de0 
[1:1:0711/205210.647581:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 580 0x7f1374a612e0 0x2537a99827e0 , "https://pub.alimama.com/"
[1:1:0711/205210.650401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0711/205210.650597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205210.849361:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205210.849695:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205210.851383:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:20:0711/205210.856782:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0711/205210.871974:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3a82a92429c8, 0x2537a92ec990
[1:1:0711/205210.872321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 5000
[1:1:0711/205210.872806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 614
[1:1:0711/205210.873069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f1372b39070 0x2537aab38d60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 580 0x7f1374a612e0 0x2537a99827e0 
[1:1:0711/205210.932678:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205211.027738:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 582, 7f137547e881
[1:1:0711/205211.043756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"554 0x7f1372b39070 0x2537a99c6760 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205211.043951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"554 0x7f1372b39070 0x2537a99c6760 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205211.044419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205211.044790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205211.044906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205211.107225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 557, 7f137547e881
[1:1:0711/205211.132267:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"518 0x7f1372b39070 0x2537aab31560 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205211.132590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"518 0x7f1372b39070 0x2537aab31560 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205211.133011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205211.133548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205211.133730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205211.134619:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205211.134771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205211.135082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 629
[1:1:0711/205211.135264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7f1372b39070 0x2537aae32260 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 557 0x7f1372b39070 0x2537aa6f8c60 
[1:1:0711/205211.165240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205211.165473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205211.169037:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 593, 7f137547e881
[1:1:0711/205211.186604:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"579 0x7f1374a612e0 0x2537aa121de0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205211.186791:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"579 0x7f1374a612e0 0x2537aa121de0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205211.187059:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205211.187578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){b(),f=s(a(null,t)),f.skipMap=n.skipMap,f.init(r,i,c,{enabled:!0}),l()}
[1:1:0711/205211.187821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205211.317044:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205211.317204:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205211.317391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 640
[1:1:0711/205211.317506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7f1372b39070 0x2537aab6b960 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 593 0x7f1372b39070 0x2537a9aa0e60 
[1:1:0711/205211.581097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (n){G=n}
[1:1:0711/205211.581272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205211.766362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (n){a.setLocalDescription(n,function(){},function(){})}
[1:1:0711/205211.766544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205211.950729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205211.950969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205212.597382:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 640, 7f137547e881
[1:1:0711/205212.628157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"593 0x7f1372b39070 0x2537a9aa0e60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205212.628540:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"593 0x7f1372b39070 0x2537a9aa0e60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205212.629027:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205212.629570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205212.629790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205212.634448:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205212.634725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205212.635222:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 698
[1:1:0711/205212.635502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7f1372b39070 0x2537aa38b3e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 640 0x7f1372b39070 0x2537aab6b960 
[1:22:0711/205212.896463:WARNING:paced_sender.cc(261)] Elapsed time (2007 ms) longer than expected, limiting to 2000 ms
[1:1:0711/205212.904379:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 629, 7f137547e881
[1:1:0711/205212.923847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"557 0x7f1372b39070 0x2537aa6f8c60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205212.924158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"557 0x7f1372b39070 0x2537aa6f8c60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205212.924389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205212.924686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205212.924789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205212.925235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205212.925334:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205212.925505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 706
[1:1:0711/205212.925613:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7f1372b39070 0x2537aab58760 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 629 0x7f1372b39070 0x2537aae32260 
[1:20:0711/205212.985369:WARNING:stunport.cc(403)] Port[0x2537aadc4020:data:1:0:local:Net[any:::/0:Unknown]]: StunPort: stun host lookup received error 0
[1:20:0711/205213.082573:WARNING:p2ptransportchannel.cc(714)] Port[0x2537a982e6a0:data:1:0:local:Net[any:0.0.0.0/0:Unknown]]: SetOption(5, 0) failed: 0
[1:20:0711/205213.083602:WARNING:p2ptransportchannel.cc(714)] Port[0x2537aaf56fa0:data:1:0:local:Net[any:::/0:Unknown]]: SetOption(5, 0) failed: 0
[1:1:0711/205213.115318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){}
[1:1:0711/205213.115650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205213.198218:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f1374a612e0 0x2537aab46f60 , "https://pub.alimama.com/"
[1:1:0711/205213.209490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , !function(){function e(e,a){for(var r=3;void 0!==r;){var s=-1&r,c=r>>-(1/0),b=-1&c;switch(s){case 0:
[1:1:0711/205213.209764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:22:0711/205213.399095:WARNING:paced_sender.cc(261)] Elapsed time (2510 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205213.900216:WARNING:paced_sender.cc(261)] Elapsed time (3011 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205214.402304:WARNING:paced_sender.cc(261)] Elapsed time (3513 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205214.903424:WARNING:paced_sender.cc(261)] Elapsed time (4014 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205215.405549:WARNING:paced_sender.cc(261)] Elapsed time (4516 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205215.907649:WARNING:paced_sender.cc(261)] Elapsed time (5018 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205216.409754:WARNING:paced_sender.cc(261)] Elapsed time (5520 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205216.911694:WARNING:paced_sender.cc(261)] Elapsed time (6022 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205217.413020:WARNING:paced_sender.cc(261)] Elapsed time (6524 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205217.915098:WARNING:paced_sender.cc(261)] Elapsed time (7026 ms) longer than expected, limiting to 2000 ms
[1:1:0711/205217.936813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3a82a92429c8, 0x2537a92ec990
[1:1:0711/205217.937089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 5000
[1:1:0711/205217.937454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 722
[1:1:0711/205217.937650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7f1372b39070 0x2537aaee75e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 669 0x7f1374a612e0 0x2537aab46f60 
[1:22:0711/205218.417208:WARNING:paced_sender.cc(261)] Elapsed time (7528 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205218.919338:WARNING:paced_sender.cc(261)] Elapsed time (8030 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205219.421460:WARNING:paced_sender.cc(261)] Elapsed time (8532 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205219.923573:WARNING:paced_sender.cc(261)] Elapsed time (9034 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205219.960579:WARNING:paced_sender.cc(261)] Elapsed time (2009 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205220.425688:WARNING:paced_sender.cc(261)] Elapsed time (9536 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205220.463707:WARNING:paced_sender.cc(261)] Elapsed time (2513 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205220.927790:WARNING:paced_sender.cc(261)] Elapsed time (10038 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205220.965855:WARNING:paced_sender.cc(261)] Elapsed time (3015 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205221.428889:WARNING:paced_sender.cc(261)] Elapsed time (10539 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205221.467928:WARNING:paced_sender.cc(261)] Elapsed time (3517 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205221.930763:WARNING:paced_sender.cc(261)] Elapsed time (11041 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205221.970020:WARNING:paced_sender.cc(261)] Elapsed time (4019 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205222.433162:WARNING:paced_sender.cc(261)] Elapsed time (11544 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205222.472156:WARNING:paced_sender.cc(261)] Elapsed time (4521 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205222.935247:WARNING:paced_sender.cc(261)] Elapsed time (12046 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205222.974251:WARNING:paced_sender.cc(261)] Elapsed time (5023 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205223.436367:WARNING:paced_sender.cc(261)] Elapsed time (12547 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205223.476379:WARNING:paced_sender.cc(261)] Elapsed time (5525 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205223.938468:WARNING:paced_sender.cc(261)] Elapsed time (13049 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205223.978497:WARNING:paced_sender.cc(261)] Elapsed time (6027 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205224.441600:WARNING:paced_sender.cc(261)] Elapsed time (13552 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205224.479626:WARNING:paced_sender.cc(261)] Elapsed time (6529 ms) longer than expected, limiting to 2000 ms
[14762:14762:0711/205224.822878:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:22:0711/205224.944746:WARNING:paced_sender.cc(261)] Elapsed time (14055 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205224.981723:WARNING:paced_sender.cc(261)] Elapsed time (7031 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205225.446838:WARNING:paced_sender.cc(261)] Elapsed time (14557 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205225.483845:WARNING:paced_sender.cc(261)] Elapsed time (7533 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205225.948926:WARNING:paced_sender.cc(261)] Elapsed time (15059 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205225.985938:WARNING:paced_sender.cc(261)] Elapsed time (8035 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205226.451054:WARNING:paced_sender.cc(261)] Elapsed time (15562 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205226.488093:WARNING:paced_sender.cc(261)] Elapsed time (8537 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205226.951155:WARNING:paced_sender.cc(261)] Elapsed time (16062 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205226.990180:WARNING:paced_sender.cc(261)] Elapsed time (9039 ms) longer than expected, limiting to 2000 ms
		remove user.11_8e04fe30 -> 0
		remove user.12_b02dd3bb -> 0
		remove user.13_3c65cc6f -> 0
		remove user.14_abfcfd0e -> 0
		remove user.15_d90ccbf1 -> 0
		remove user.16_7258a9da -> 0
		remove user.17_3a23aed5 -> 0
[1:22:0711/205227.461279:WARNING:paced_sender.cc(261)] Elapsed time (16572 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205227.492334:WARNING:paced_sender.cc(261)] Elapsed time (9541 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205227.961552:WARNING:paced_sender.cc(261)] Elapsed time (17072 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205227.994399:WARNING:paced_sender.cc(261)] Elapsed time (10043 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205228.464414:WARNING:paced_sender.cc(261)] Elapsed time (17575 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205228.496425:WARNING:paced_sender.cc(261)] Elapsed time (10545 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205228.967640:WARNING:paced_sender.cc(261)] Elapsed time (18078 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205228.998641:WARNING:paced_sender.cc(261)] Elapsed time (11048 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205229.468097:WARNING:paced_sender.cc(261)] Elapsed time (18579 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205229.500754:WARNING:paced_sender.cc(261)] Elapsed time (11550 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205229.968984:WARNING:paced_sender.cc(261)] Elapsed time (19079 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205230.002873:WARNING:paced_sender.cc(261)] Elapsed time (12052 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205230.468996:WARNING:paced_sender.cc(261)] Elapsed time (19579 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205230.502985:WARNING:paced_sender.cc(261)] Elapsed time (12552 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205230.971098:WARNING:paced_sender.cc(261)] Elapsed time (20082 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205231.005097:WARNING:paced_sender.cc(261)] Elapsed time (13054 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205231.473250:WARNING:paced_sender.cc(261)] Elapsed time (20584 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205231.507217:WARNING:paced_sender.cc(261)] Elapsed time (13556 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205231.974338:WARNING:paced_sender.cc(261)] Elapsed time (21085 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205232.007354:WARNING:paced_sender.cc(261)] Elapsed time (14056 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205232.475944:WARNING:paced_sender.cc(261)] Elapsed time (21586 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205232.508458:WARNING:paced_sender.cc(261)] Elapsed time (14557 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205232.978570:WARNING:paced_sender.cc(261)] Elapsed time (22089 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205233.011598:WARNING:paced_sender.cc(261)] Elapsed time (15060 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205233.481681:WARNING:paced_sender.cc(261)] Elapsed time (22592 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205233.513836:WARNING:paced_sender.cc(261)] Elapsed time (15563 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205233.983842:WARNING:paced_sender.cc(261)] Elapsed time (23094 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205234.015818:WARNING:paced_sender.cc(261)] Elapsed time (16065 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205234.485935:WARNING:paced_sender.cc(261)] Elapsed time (23596 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205234.517911:WARNING:paced_sender.cc(261)] Elapsed time (16567 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205234.988032:WARNING:paced_sender.cc(261)] Elapsed time (24099 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205235.020075:WARNING:paced_sender.cc(261)] Elapsed time (17069 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205235.490173:WARNING:paced_sender.cc(261)] Elapsed time (24601 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205235.521284:WARNING:paced_sender.cc(261)] Elapsed time (17570 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205235.990264:WARNING:paced_sender.cc(261)] Elapsed time (25101 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205236.023285:WARNING:paced_sender.cc(261)] Elapsed time (18072 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205236.492383:WARNING:paced_sender.cc(261)] Elapsed time (25603 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205236.525391:WARNING:paced_sender.cc(261)] Elapsed time (18574 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205236.993500:WARNING:paced_sender.cc(261)] Elapsed time (26104 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205237.027526:WARNING:paced_sender.cc(261)] Elapsed time (19076 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205237.495757:WARNING:paced_sender.cc(261)] Elapsed time (26606 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205237.530618:WARNING:paced_sender.cc(261)] Elapsed time (19580 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205237.997719:WARNING:paced_sender.cc(261)] Elapsed time (27108 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205238.030769:WARNING:paced_sender.cc(261)] Elapsed time (20080 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205238.499847:WARNING:paced_sender.cc(261)] Elapsed time (27610 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205238.531987:WARNING:paced_sender.cc(261)] Elapsed time (20581 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205239.001696:WARNING:paced_sender.cc(261)] Elapsed time (28112 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205239.033024:WARNING:paced_sender.cc(261)] Elapsed time (21082 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205239.504119:WARNING:paced_sender.cc(261)] Elapsed time (28615 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205239.534077:WARNING:paced_sender.cc(261)] Elapsed time (21583 ms) longer than expected, limiting to 2000 ms
[1:22:0711/205240.006194:WARNING:paced_sender.cc(261)] Elapsed time (29117 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205240.036214:WARNING:paced_sender.cc(261)] Elapsed time (22085 ms) longer than expected, limiting to 2000 ms
[14762:14762:0711/205240.372738:INFO:CONSOLE(3)] "", source: https://g.alicdn.com/secdev/nsv/1.0.63/ns_c_74_3_f.js (3)
[1:1:0711/205240.374187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205240.437864:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670 0x7f1374a612e0 0x2537aaedc360 , "https://pub.alimama.com/"
[1:1:0711/205240.441197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/view",["jquery","underscore","handlebars","magix","pat","brix/loader","app/models/manage
[1:1:0711/205240.441466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205240.442823:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205240.443478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:22:0711/205240.508437:WARNING:paced_sender.cc(261)] Elapsed time (29619 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205240.538361:WARNING:paced_sender.cc(261)] Elapsed time (22587 ms) longer than expected, limiting to 2000 ms
[1:1:0711/205240.783959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205240.784249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205240.835194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 673 0x7f1374a612e0 0x2537aab581e0 , "https://pub.alimama.com/"
[1:1:0711/205240.836360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/adjust",["jquery","magix"],function(d){function o(){i.width()<1190?(window.PUB_WRAP_WIDT
[1:1:0711/205240.836590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205240.837763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205240.838394:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:22:0711/205241.009913:WARNING:paced_sender.cc(261)] Elapsed time (30120 ms) longer than expected, limiting to 2000 ms
[1:1:0711/205241.025213:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 674 0x7f1374a612e0 0x2537a9888560 , "https://pub.alimama.com/"
[1:1:0711/205241.026648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/login",["jquery","magix"],function(t,o){t("body").on("click","[data-login]",function(e){
[1:1:0711/205241.026853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205241.028038:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205241.028773:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:24:0711/205241.040467:WARNING:paced_sender.cc(261)] Elapsed time (23089 ms) longer than expected, limiting to 2000 ms
[1:1:0711/205241.169724:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 677 0x7f1374a612e0 0x2537aabcdee0 , "https://pub.alimama.com/"
[1:1:0711/205241.170863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/vclick",["jquery","magix"],function(t,e){t("body").on("click","a",function(r){var a=t(r.
[1:1:0711/205241.171094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205241.172279:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205241.172925:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205241.246322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 678 0x7f1374a612e0 0x2537a9cf96e0 , "https://pub.alimama.com/"
[1:1:0711/205241.247577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/anim",["jquery"],function(a){a("body").on("animationend",".endtext",function(n){var t=a(
[1:1:0711/205241.247870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205241.249112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205241.249761:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:22:0711/205241.512588:WARNING:paced_sender.cc(261)] Elapsed time (30623 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205241.543563:WARNING:paced_sender.cc(261)] Elapsed time (23592 ms) longer than expected, limiting to 2000 ms
[1:1:0711/205241.573373:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 698, 7f137547e881
[1:1:0711/205241.590275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"640 0x7f1372b39070 0x2537aab6b960 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205241.590640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"640 0x7f1372b39070 0x2537aab6b960 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205241.591096:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205241.591651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205241.591922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205241.596476:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205241.600431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205241.600932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 772
[1:1:0711/205241.601173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 772 0x7f1372b39070 0x2537aabf98e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 698 0x7f1372b39070 0x2537aa38b3e0 
[1:1:0711/205241.825712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "icecandidate", "https://pub.alimama.com/"
[1:1:0711/205241.826923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , A.a.onicecandidate, (t){var i=t.candidate;if(!i)return void n(0);var r=E(i.candidate);null!=r&&(n(r),a.onicecandidate=nu
[1:1:0711/205241.827167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:22:0711/205242.014251:WARNING:paced_sender.cc(261)] Elapsed time (31125 ms) longer than expected, limiting to 2000 ms
[1:24:0711/205242.046704:WARNING:paced_sender.cc(261)] Elapsed time (24096 ms) longer than expected, limiting to 2000 ms
[1:1:0711/205242.138011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , S, (e){var a="se";a&&(a+="tLo"),a+="calDes",a+="cript",a+="io",a+="n",$a[a](e)}
[1:1:0711/205242.138307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205242.229135:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 706, 7f137547e881
[1:1:0711/205242.261415:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"629 0x7f1372b39070 0x2537aae32260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.261801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"629 0x7f1372b39070 0x2537aae32260 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.262236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205242.262825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205242.263041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205242.264069:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205242.264286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205242.264678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 797
[1:1:0711/205242.264924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7f1372b39070 0x2537aaf1b2e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 706 0x7f1372b39070 0x2537aab58760 
[1:1:0711/205242.266366:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 614, 7f137547e881
[1:1:0711/205242.284548:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"580 0x7f1374a612e0 0x2537a99827e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.284941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"580 0x7f1374a612e0 0x2537a99827e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.285354:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205242.285966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (n){try{a.close()}catch(t){}}
[1:1:0711/205242.286236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205242.298232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 722, 7f137547e881
[1:1:0711/205242.335947:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"669 0x7f1374a612e0 0x2537aab46f60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.336298:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"669 0x7f1374a612e0 0x2537aab46f60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.336737:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205242.337373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , Y, (e){try{for(var a="\u0441\u044a\u044d\u0451\u0443",r="",s=0;s<a.length;s++){var c=a.charCodeAt(s)-99
[1:1:0711/205242.337612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205242.636470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205242.636769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205242.858828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 772, 7f137547e881
[1:1:0711/205242.875415:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"698 0x7f1372b39070 0x2537aa38b3e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.875768:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"698 0x7f1372b39070 0x2537aa38b3e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205242.876228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205242.876760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205242.877003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205242.881799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205242.882069:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205242.882454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 834
[1:1:0711/205242.882689:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 834 0x7f1372b39070 0x2537a921e160 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 772 0x7f1372b39070 0x2537aabf98e0 
[1:1:0711/205242.905874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://pub.alimama.com/"
[1:1:0711/205242.906678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , D, (n){cn=n.gamma,en||(en=s(function(n){removeEventListener("deviceorientation",D),s(A,470)},30))}
[1:1:0711/205242.906947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205242.907953:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x3a82a92429c8, 0x2537a92eca38
[1:1:0711/205242.908179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 30
[1:1:0711/205242.908545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 836
[1:1:0711/205242.908775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 836 0x7f1372b39070 0x2537a921e460 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 779 0x7f138b0983d0 0x2537aab387e0 
[1:1:0711/205242.909228:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://pub.alimama.com/"
[1:1:0711/205244.121117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 814 0x7f1374a612e0 0x2537aac5a860 , "https://pub.alimama.com/"
[1:1:0711/205244.126219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , /*!

 handlebars v2.0.0

Copyright (C) 2011-2014 by Yehuda Katz

Permission is hereby granted, free 
[1:1:0711/205244.126517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205244.128184:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.128839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.173303:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205244.173904:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205244.174444:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205244.174915:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205244.282501:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 815 0x7f1374a612e0 0x2537ad356ee0 , "https://pub.alimama.com/"
[1:1:0711/205244.285931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/models/manager",["app/models/model","magix"],function(e,t){var n=t.Manager.create(e);if(
[1:1:0711/205244.286230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205244.287639:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.288329:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.445859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205244.446253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205244.495848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 818 0x7f1374a612e0 0x2537aabe17e0 , "https://pub.alimama.com/"
[1:1:0711/205244.497517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/util/dialog/index",["jquery","magix","underscore","app/exts/dialog/dialog","app/exts/dia
[1:1:0711/205244.497787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205244.498811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.499626:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.863011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 819 0x7f1374a612e0 0x2537aaf2b960 , "https://pub.alimama.com/"
[1:1:0711/205244.865815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/util/lazyload/index",["jquery","underscore","magix"],function(t,e,i){var r="~^";return{l
[1:1:0711/205244.866108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205244.867620:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.868365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.940844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 822 0x7f1374a612e0 0x2537ad453160 , "https://pub.alimama.com/"
[1:1:0711/205244.941890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/filters",["jquery","magix","app/util/index"],function(n,t,a){return{adaptImg100:function
[1:1:0711/205244.942136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205244.943760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205244.944467:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205245.208507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 797, 7f137547e881
[1:1:0711/205245.249082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"706 0x7f1372b39070 0x2537aab58760 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205245.249479:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"706 0x7f1372b39070 0x2537aab58760 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205245.250005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205245.250632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205245.250846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205245.251794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205245.252025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205245.252403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 880
[1:1:0711/205245.252668:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7f1372b39070 0x2537aaedc5e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 797 0x7f1372b39070 0x2537aaf1b2e0 
[1:1:0711/205245.428459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 834, 7f137547e881
[1:1:0711/205245.464455:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"772 0x7f1372b39070 0x2537aabf98e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205245.464913:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"772 0x7f1372b39070 0x2537aabf98e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205245.465367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205245.465928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205245.466146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205245.472500:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205245.472764:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205245.473164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 884
[1:1:0711/205245.473515:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f1372b39070 0x2537a99c9a60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 834 0x7f1372b39070 0x2537a921e160 
[1:1:0711/205245.475166:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 836, 7f137547e881
[1:1:0711/205245.514560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"779 0x7f138b0983d0 0x2537aab387e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205245.514932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"779 0x7f138b0983d0 0x2537aab387e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205245.515352:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205245.515903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/205245.516149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205245.517382:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205245.517620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 470
[1:1:0711/205245.518042:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 885
[1:1:0711/205245.518301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 885 0x7f1372b39070 0x2537aaf1b2e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 836 0x7f1372b39070 0x2537a921e460 
[1:1:0711/205245.832753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205245.833062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205246.211212:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 884, 7f137547e881
[1:1:0711/205246.235864:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"834 0x7f1372b39070 0x2537a921e160 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205246.236238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"834 0x7f1372b39070 0x2537a921e160 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205246.236643:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205246.237212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205246.237439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205246.243050:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205246.243324:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205246.243721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 916
[1:1:0711/205246.244012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7f1372b39070 0x2537aaf1b8e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 884 0x7f1372b39070 0x2537a99c9a60 
[1:1:0711/205246.472309:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 896 0x7f1374a612e0 0x2537ad400a60 , "https://pub.alimama.com/"
[1:1:0711/205246.474133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/models/model",["jquery","underscore","magix","app/util/index"],function(e,t,a,i){var o={
[1:1:0711/205246.474333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205246.475635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205246.476264:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205246.655375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 897 0x7f1374a612e0 0x2537ad400060 , "https://pub.alimama.com/"
[1:1:0711/205246.656475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/exts/dialog/dialog",["jquery","underscore","components/base","brix/loader","brix/event",
[1:1:0711/205246.656597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205246.657264:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205246.657572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205247.036190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 880, 7f137547e881
[1:1:0711/205247.066042:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"797 0x7f1372b39070 0x2537aaf1b2e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205247.066360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"797 0x7f1372b39070 0x2537aaf1b2e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205247.066735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205247.067301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205247.067478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205247.068375:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205247.068544:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205247.068873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 940
[1:1:0711/205247.069085:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 940 0x7f1372b39070 0x2537aa11bce0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 880 0x7f1372b39070 0x2537aaedc5e0 
[1:1:0711/205247.149157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , document.readyState
[1:1:0711/205247.149393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205247.269815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 902 0x7f1374a612e0 0x2537a9999ce0 , "https://pub.alimama.com/"
[1:1:0711/205247.271548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/exts/dialog/position",["jquery"],function(t){function e(e,r,a,c){var f=t(e);if(!f.length
[1:1:0711/205247.271736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205247.278052:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205247.278641:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205247.372675:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 903 0x7f1374a612e0 0x2537aa121a60 , "https://pub.alimama.com/"
[1:1:0711/205247.373912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/util/index",["jquery","underscore","app/util/level/level","app/util/tool/tool","app/util
[1:1:0711/205247.374120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205247.375261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205247.375862:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205248.019274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 885, 7f137547e881
[1:1:0711/205248.045805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"836 0x7f1372b39070 0x2537a921e460 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205248.045978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"836 0x7f1372b39070 0x2537a921e460 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205248.046177:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205248.046687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0711/205248.046880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205248.447504:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 916, 7f137547e881
[1:1:0711/205248.467238:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"884 0x7f1372b39070 0x2537a99c9a60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205248.467664:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"884 0x7f1372b39070 0x2537a99c9a60 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205248.468141:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205248.468560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205248.468671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205248.481838:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205248.482061:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205248.482428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 977
[1:1:0711/205248.482618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7f1372b39070 0x2537aac418e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 916 0x7f1372b39070 0x2537aaf1b8e0 
[14762:14762:0711/205248.555791:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/205249.796540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 940, 7f137547e881
[1:1:0711/205249.812045:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"880 0x7f1372b39070 0x2537aaedc5e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205249.812246:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"880 0x7f1372b39070 0x2537aaedc5e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205249.812462:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205249.812966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/205249.813188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205249.814130:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205249.814265:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 500
[1:1:0711/205249.814453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 1028
[1:1:0711/205249.814569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1028 0x7f1372b39070 0x2537ad5807e0 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 940 0x7f1372b39070 0x2537aa11bce0 
[1:1:0711/205249.972303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 977, 7f137547e881
[1:1:0711/205249.986260:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cfdaef22860","ptid":"916 0x7f1372b39070 0x2537aaf1b8e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205249.986444:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pub.alimama.com/","ptid":"916 0x7f1372b39070 0x2537aaf1b8e0 ","rf":"6:3_https://pub.alimama.com/"}
[1:1:0711/205249.986664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pub.alimama.com/"
[1:1:0711/205249.986956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , (){E=0,l()}
[1:1:0711/205249.987058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205249.991447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3a82a92429c8, 0x2537a92ec950
[1:1:0711/205249.991551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 50
[1:1:0711/205249.991765:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pub.alimama.com/, 1036
[1:1:0711/205249.991875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1036 0x7f1372b39070 0x2537aab38a60 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 977 0x7f1372b39070 0x2537aac418e0 
[1:1:0711/205250.148732:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7f1374a612e0 0x2537aab31760 , "https://pub.alimama.com/"
[1:1:0711/205250.149993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("jquery"),
[1:1:0711/205250.150296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205250.152306:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.153120:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.263867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 988 0x7f1374a612e0 0x2537aa1194e0 , "https://pub.alimama.com/"
[1:1:0711/205250.265823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/exts/dialog/mask",["jquery","underscore","brix/base","brix/event","css!app/exts/dialog/m
[1:1:0711/205250.266137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205250.267684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.268557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.554976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 990 0x7f1374a612e0 0x2537a96f12e0 , "https://pub.alimama.com/"
[1:1:0711/205250.556289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/exts/dialog/dialog.tpl",function(){return'  <div class="dialog dialog-singleton dialog-<
[1:1:0711/205250.556535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205250.558717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.559494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.628496:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7f1374a612e0 0x2537ad5b9160 , "https://pub.alimama.com/"
[1:1:0711/205250.629481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , /*
 * Require-CSS RequireJS css! loader plugin
 * 0.1.10
 * Guy Bedford 2014
 * MIT
 */

/*
 *
 * Us
[1:1:0711/205250.629597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205250.630719:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.631069:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205250.741492:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 10
[1:1:0711/205250.742019:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pub.alimama.com/, 1054
[1:1:0711/205250.742279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1054 0x7f1372b39070 0x2537ae28a460 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 991 0x7f1374a612e0 0x2537ad5b9160 
[1:1:0711/205250.837683:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pub.alimama.com/", 10
[1:1:0711/205250.838103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pub.alimama.com/, 1057
[1:1:0711/205250.838301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1057 0x7f1372b39070 0x2537aae32860 , 6:3_https://pub.alimama.com/, 1, -6:3_https://pub.alimama.com/, 991 0x7f1374a612e0 0x2537ad5b9160 
[1:1:0711/205251.041068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 993 0x7f1374a612e0 0x2537a9cb44e0 , "https://pub.alimama.com/"
[1:1:0711/205251.042744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/util/level/level",["jquery","underscore"],function(){return{getTkLevel:function(e,t){if(
[1:1:0711/205251.042957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205251.044156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205251.044913:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205251.165850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 994 0x7f1374a612e0 0x2537ad4536e0 , "https://pub.alimama.com/"
[1:1:0711/205251.168293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/util/tool/tool",["moment"],function(n){return{formatFloat:function(n){if(null===n||void 
[1:1:0711/205251.168543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205251.170202:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205251.170959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205251.385956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 996 0x7f1374a612e0 0x2537ad5b98e0 , "https://pub.alimama.com/"
[1:1:0711/205251.386871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pub.alimama.com/, 2cfdaef22860, , , define("app/util/globaltip/globaltip",["jquery","underscore","app/exts/globaltip/index"],function(i,
[1:1:0711/205251.387052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pub.alimama.com/", "pub.alimama.com", 3, 1, , , 0
[1:1:0711/205251.388045:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
[1:1:0711/205251.388536:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pub.alimama.com/"
