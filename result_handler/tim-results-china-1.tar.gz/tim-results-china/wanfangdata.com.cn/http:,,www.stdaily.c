[0713/023209.341513:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/023209.341821:INFO:switcher_clone.cc(787)] backtrace rip is 7feda7b57891
[0713/023210.324063:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/023210.324343:INFO:switcher_clone.cc(787)] backtrace rip is 7f9a05c6a891
[1:1:0713/023210.328612:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/023210.328786:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/023210.332448:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/023211.592097:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/023211.592524:INFO:switcher_clone.cc(787)] backtrace rip is 7fab33e1d891
[43006:43006:0713/023211.727556:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/8c7bb4df-1a98-4553-9a6a-48c5a39ebd2c
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[43039:43039:0713/023211.820794:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=43039
[43050:43050:0713/023211.821188:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=43050
[43006:43006:0713/023212.090416:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[43006:43036:0713/023212.091242:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/023212.091481:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/023212.091699:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/023212.092292:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/023212.092438:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/023212.095354:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xbaf6341, 1
[1:1:0713/023212.095684:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xaa35c94, 0
[1:1:0713/023212.095881:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x15a92ef6, 3
[1:1:0713/023212.096106:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x165b2521, 2
[1:1:0713/023212.096346:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff945cffffffa30a 4163ffffffaf0b 21255b16 fffffff62effffffa915 , 10104, 4
[1:1:0713/023212.097315:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[43006:43036:0713/023212.097569:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�\�
Ac�!%[�.����/
[43006:43036:0713/023212.097635:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �\�
Ac�!%[�.�����/
[1:1:0713/023212.097562:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9a03ea50a0, 3
[1:1:0713/023212.097835:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9a04030080, 2
[43006:43036:0713/023212.098059:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[43006:43036:0713/023212.098138:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 43058, 4, 945ca30a 4163af0b 21255b16 f62ea915 
[1:1:0713/023212.098133:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f99edcf3d20, -2
[1:1:0713/023212.116747:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/023212.117620:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 165b2521
[1:1:0713/023212.118566:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 165b2521
[1:1:0713/023212.120209:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 165b2521
[1:1:0713/023212.121710:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.121894:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.122126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.122315:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.122936:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 165b2521
[1:1:0713/023212.123287:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9a05c6a7ba
[1:1:0713/023212.123425:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9a05c61def, 7f9a05c6a77a, 7f9a05c6c0cf
[1:1:0713/023212.129114:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 165b2521
[1:1:0713/023212.129454:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 165b2521
[1:1:0713/023212.130189:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 165b2521
[1:1:0713/023212.132264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.132459:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.132640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.132853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 165b2521
[1:1:0713/023212.134094:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 165b2521
[1:1:0713/023212.134447:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9a05c6a7ba
[1:1:0713/023212.134577:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9a05c61def, 7f9a05c6a77a, 7f9a05c6c0cf
[1:1:0713/023212.142639:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/023212.143228:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/023212.143413:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8816b168, 0x7fff8816b0e8)
[1:1:0713/023212.161252:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/023212.167035:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[43006:43006:0713/023212.743961:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43006:43006:0713/023212.745365:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43006:43017:0713/023212.764153:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[43006:43017:0713/023212.764261:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[43006:43006:0713/023212.764461:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[43006:43006:0713/023212.764538:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[43006:43006:0713/023212.764681:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,43058, 4
[1:7:0713/023212.768869:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[43006:43028:0713/023212.850646:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/023212.872046:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2fdd0e78a220
[1:1:0713/023212.872847:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/023213.231931:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/023214.547445:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023214.549999:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[43006:43006:0713/023214.911476:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[43006:43006:0713/023214.911610:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/023215.712684:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/023215.992046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 352b7f701f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/023215.992227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/023216.006989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 352b7f701f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/023216.007194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/023216.102894:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/023216.103161:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023216.542441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023216.550516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 352b7f701f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/023216.550718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/023216.585048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023216.595450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 352b7f701f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/023216.595676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/023216.607400:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/023216.610743:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2fdd0e788e20
[1:1:0713/023216.610916:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[43006:43006:0713/023216.611573:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[43006:43006:0713/023216.626004:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[43006:43006:0713/023216.648277:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[43006:43006:0713/023216.648436:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/023216.695470:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023217.413855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f99ef8ce2e0 0x2fdd0ea19ae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023217.414589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 352b7f701f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/023217.414719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/023217.415287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[43006:43006:0713/023217.476805:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/023217.480673:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2fdd0e789820
[1:1:0713/023217.481497:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[43006:43006:0713/023217.484018:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/023217.505865:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/023217.506072:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[43006:43006:0713/023217.507095:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[43006:43006:0713/023217.520890:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43006:43006:0713/023217.521904:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43006:43017:0713/023217.527742:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[43006:43017:0713/023217.527827:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[43006:43006:0713/023217.527978:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[43006:43006:0713/023217.528054:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[43006:43006:0713/023217.528189:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,43058, 4
[1:7:0713/023217.531669:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/023218.119408:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/023218.721545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f99ef8ce2e0 0x2fdd0eb56be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023218.722658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 352b7f701f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/023218.722890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/023218.723660:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023218.878851:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[43006:43006:0713/023218.883438:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[43006:43006:0713/023218.883538:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/023219.455531:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[43006:43006:0713/023219.680950:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[43006:43036:0713/023219.681340:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/023219.681531:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/023219.681785:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/023219.682199:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/023219.682379:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/023219.685408:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b6dc423, 1
[1:1:0713/023219.685791:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2459707c, 0
[1:1:0713/023219.685994:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1daf652c, 3
[1:1:0713/023219.686212:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3fc1e23e, 2
[1:1:0713/023219.686386:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7c705924 23ffffffc46d1b 3effffffe2ffffffc13f 2c65ffffffaf1d , 10104, 5
[1:1:0713/023219.687409:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[43006:43036:0713/023219.687685:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING|pY$#�m>��?,e���/
[43006:43036:0713/023219.687776:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is |pY$#�m>��?,e�����/
[1:1:0713/023219.687672:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9a03ea50a0, 3
[1:1:0713/023219.687902:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9a04030080, 2
[43006:43036:0713/023219.688069:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 43102, 5, 7c705924 23c46d1b 3ee2c13f 2c65af1d 
[1:1:0713/023219.688150:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f99edcf3d20, -2
[1:1:0713/023219.713961:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/023219.714465:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fc1e23e
[1:1:0713/023219.714906:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fc1e23e
[1:1:0713/023219.715706:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fc1e23e
[1:1:0713/023219.717098:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.717329:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.717545:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.717754:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.718444:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fc1e23e
[1:1:0713/023219.718775:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9a05c6a7ba
[1:1:0713/023219.718999:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9a05c61def, 7f9a05c6a77a, 7f9a05c6c0cf
[1:1:0713/023219.725586:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fc1e23e
[1:1:0713/023219.726005:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fc1e23e
[1:1:0713/023219.726766:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fc1e23e
[1:1:0713/023219.728867:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.729130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.729352:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.729582:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc1e23e
[1:1:0713/023219.730880:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fc1e23e
[1:1:0713/023219.731279:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9a05c6a7ba
[1:1:0713/023219.731448:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9a05c61def, 7f9a05c6a77a, 7f9a05c6c0cf
[1:1:0713/023219.739198:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/023219.739726:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/023219.739931:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8816b168, 0x7fff8816b0e8)
[1:1:0713/023219.754653:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/023219.758806:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/023219.984741:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2fdd0e750220
[1:1:0713/023219.985032:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/023220.015121:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/023220.015408:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[43006:43006:0713/023220.176589:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43006:43006:0713/023220.182232:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43006:43017:0713/023220.230708:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[43006:43017:0713/023220.230809:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[43006:43006:0713/023220.231177:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.stdaily.com/
[43006:43006:0713/023220.231224:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.stdaily.com/, http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml, 1
[43006:43006:0713/023220.231287:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.stdaily.com/, HTTP/1.1 200 OK DrivedBy: SrvEng/1.5.0 Date: Sat, 13 Jul 2019 09:31:41 GMT Content-Type: text/html; charset=UTF-8 Content-Length: 14958 Connection: keep-alive X-Frame-Option: allow-from http://www.kjcg123.com/, allow-from http://yun.kjcg123.com:8080/ Set-Cookie: gkyh_cookie=10.10.0.14.1563010340237801; path=/; max-age=31536000; domain=.stdaily.com Accept-Ranges: bytes Vary: Accept-Encoding,User-Agent Content-Encoding: gzip  ,43102, 5
[1:7:0713/023220.238204:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/023220.289288:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.stdaily.com/
[1:1:0713/023220.337085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/023220.341205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 352b7f82e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/023220.341512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/023220.349626:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[43006:43006:0713/023220.450153:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.stdaily.com/, http://www.stdaily.com/, 1
[43006:43006:0713/023220.450257:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.stdaily.com/, http://www.stdaily.com
[1:1:0713/023220.494079:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/023220.522909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/023220.523621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 352b7f701f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/023220.523832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/023220.602605:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/023220.681414:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/023220.681661:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/023221.428448:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f99ed9a6070 0x2fdd0e92c860 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023221.430635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , document.write("<link rel='stylesheet' type='text/css' href='/index/xhtml/css/f_header.css?time=" + 
[1:1:0713/023221.430862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023221.739324:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f99ed9a6070 0x2fdd0e869960 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023221.741266:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023221.741700:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023221.745633:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023221.746265:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023221.746683:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023221.791479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , /*!jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingURL=jquery.min.map
*/
(function(
[1:1:0713/023221.791758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023221.798751:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023221.959291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f99ed9a6070 0x2fdd0e869960 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023222.040049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f99ed9a6070 0x2fdd0e869960 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023222.045705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f99ed9a6070 0x2fdd0e869960 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023222.054357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f99ed9a6070 0x2fdd0e869960 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023222.246047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f99ed9a6070 0x2fdd0e869960 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023222.314020:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.356498, 282, 1
[1:1:0713/023222.314305:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/023222.862752:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/023222.863029:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023222.864148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7f99ed9a6070 0x2fdd0e8d7660 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023222.866447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , 

var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm
[1:1:0713/023222.866749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023222.891077:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0278502, 63, 1
[1:1:0713/023222.891368:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/023223.167978:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/023223.168252:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023223.237574:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0691221, 773, 1
[1:1:0713/023223.237858:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/023223.258015:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 264 0x7f99ef8ce2e0 0x2fdd0e8658e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023223.266053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0713/023223.266368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023223.503180:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/023223.503449:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023223.507109:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7f99ed9a6070 0x2fdd0e86aae0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023223.513674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , !function(e,n){"function"==typeof define&&(define.amd||define.cmd)?define(function(){return n(e)}):n
[1:1:0713/023223.513915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023223.542736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023223.546132:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7f99ed9a6070 0x2fdd0e86aae0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023223.593064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7f99ed9a6070 0x2fdd0e86aae0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023223.596392:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023224.889042:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 1000
[1:1:0713/023224.889688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 331
[1:1:0713/023224.889981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 331 0x7f99ed9a6070 0x2fdd0ec71d60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 286 0x7f99ed9a6070 0x2fdd0e86aae0 
[1:1:0713/023224.964074:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 5000
[1:1:0713/023224.964703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 332
[1:1:0713/023224.964934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 332 0x7f99ed9a6070 0x2fdd0ec5ede0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 286 0x7f99ed9a6070 0x2fdd0e86aae0 
[1:1:0713/023224.979659:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023225.004645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e2989e0
[1:1:0713/023225.004931:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023225.005458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 333
[1:1:0713/023225.005701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7f99ed9a6070 0x2fdd0ec5d8e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 286 0x7f99ed9a6070 0x2fdd0e86aae0 
[1:1:0713/023225.011913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e2989e0
[1:1:0713/023225.012198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023225.012808:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 334
[1:1:0713/023225.013070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 334 0x7f99ed9a6070 0x2fdd0e627ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 286 0x7f99ed9a6070 0x2fdd0e86aae0 
[1:1:0713/023225.022104:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e2989e0
[1:1:0713/023225.022430:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023225.022936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 337
[1:1:0713/023225.023216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 337 0x7f99ed9a6070 0x2fdd0ec08760 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 286 0x7f99ed9a6070 0x2fdd0e86aae0 
[1:1:0713/023225.034762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e2989e0
[1:1:0713/023225.035027:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023225.035532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 340
[1:1:0713/023225.035771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 340 0x7f99ed9a6070 0x2fdd0ec0c360 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 286 0x7f99ed9a6070 0x2fdd0e86aae0 
[1:1:0713/023225.040963:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x5e9e67029c8, 0x2fdd0e2989e0
[1:1:0713/023225.041278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 3000
[1:1:0713/023225.041839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 342
[1:1:0713/023225.042085:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 342 0x7f99ed9a6070 0x2fdd0ec0f4e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 286 0x7f99ed9a6070 0x2fdd0e86aae0 
[1:1:0713/023225.198500:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023225.865937:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023225.866790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/023225.867045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023225.913825:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361 0x7f99ef8ce2e0 0x2fdd0e863ee0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023225.923641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (function(){var h={},mt={},c={id:"d11e62e2e2c8d774bb326bab95dd0a4d",dm:["114.55.19.24","stdaily.com"
[1:1:0713/023225.923892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023225.944571:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298948
[1:1:0713/023225.944834:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023225.945375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 404
[1:1:0713/023225.945642:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 404 0x7f99ed9a6070 0x2fdd0ec09fe0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 361 0x7f99ef8ce2e0 0x2fdd0e863ee0 
[43006:43006:0713/023304.778865:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/023304.837339:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/023304.879548:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023304.948757:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023304.975944:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7f99ef8ce2e0 0x2fdd0e913260 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023304.977402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0713/023304.977651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023304.983645:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.039915:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.040731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/023305.040912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023305.121935:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367 0x7f99ef8ce2e0 0x2fdd0ecb7560 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.131713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (function(){var h={},mt={},c={id:"d11e62e2e2c8d774bb326bab95dd0a4d",dm:["114.55.19.24","stdaily.com"
[1:1:0713/023305.131921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023305.154745:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298940
[1:1:0713/023305.154961:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023305.155440:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 468
[1:1:0713/023305.155630:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 468 0x7f99ed9a6070 0x2fdd0e912ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 367 0x7f99ef8ce2e0 0x2fdd0ecb7560 
[1:1:0713/023305.165494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.186767:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7f99ef8ce2e0 0x2fdd0e929760 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.188268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/023305.188449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023305.209465:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e298988
[1:1:0713/023305.209657:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023305.210102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 470
[1:1:0713/023305.210331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7f99ed9a6070 0x2fdd0e868f60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 368 0x7f99ef8ce2e0 0x2fdd0e929760 
[1:1:0713/023305.238468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e298988
[1:1:0713/023305.238678:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023305.239125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 473
[1:1:0713/023305.239337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 473 0x7f99ed9a6070 0x2fdd0e75ade0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 368 0x7f99ef8ce2e0 0x2fdd0e929760 
[1:1:0713/023305.244070:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.244981:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.297700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 371 0x7f99ef8ce2e0 0x2fdd0e9124e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.298739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/023305.298922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023305.328824:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e298988
[1:1:0713/023305.329011:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023305.329484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 478
[1:1:0713/023305.329677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 478 0x7f99ed9a6070 0x2fdd0e927ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 371 0x7f99ef8ce2e0 0x2fdd0e9124e0 
[1:1:0713/023305.334399:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.335133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.383715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f99ef8ce2e0 0x2fdd0e724e60 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.386697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("view/image_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/023305.386882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023305.412563:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.413364:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.602755:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.604475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){t&&(delete yn[o],t=s.onload=s.onerror=null,"abort"===e?s.abort():"error"===e?r(s.status||404,s.st
[1:1:0713/023305.604715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023305.813161:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7f99ef8ce2e0 0x2fdd0f14b3e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.814848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("share/image_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/023305.815078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023305.846111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023305.847121:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023306.202145:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 331, 7f99f02eb881
[1:1:0713/023306.222098:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"286 0x7f99ed9a6070 0x2fdd0e86aae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023306.222481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"286 0x7f99ed9a6070 0x2fdd0e86aae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023306.222900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023306.223947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , $('.ccH5playerBox').width('100%').height('auto')
[1:1:0713/023306.224256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023306.401739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/023306.402022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023307.076706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 404, 7f99f02eb881
[1:1:0713/023307.097597:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"361 0x7f99ef8ce2e0 0x2fdd0e863ee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.097947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"361 0x7f99ef8ce2e0 0x2fdd0e863ee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.098356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023307.099060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023307.099276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023307.100191:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023307.100396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023307.100898:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 498
[1:1:0713/023307.101212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7f99ed9a6070 0x2fdd0ec61b60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 404 0x7f99ed9a6070 0x2fdd0ec09fe0 
[1:1:0713/023307.123217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 342, 7f99f02eb881
[1:1:0713/023307.144606:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"286 0x7f99ed9a6070 0x2fdd0e86aae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.144964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"286 0x7f99ed9a6070 0x2fdd0e86aae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.145381:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023307.146099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0713/023307.146411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023307.154401:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023307.154656:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023307.155208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 499
[1:1:0713/023307.155460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 499 0x7f99ed9a6070 0x2fdd0e91c8e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 342 0x7f99ed9a6070 0x2fdd0ec0f4e0 
[1:1:0713/023307.162912:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 332, 7f99f02eb8db
[1:1:0713/023307.185126:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"286 0x7f99ed9a6070 0x2fdd0e86aae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.185440:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"286 0x7f99ed9a6070 0x2fdd0e86aae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.185901:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 502
[1:1:0713/023307.186163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 502 0x7f99ed9a6070 0x2fdd0f3ef960 , 5:3_http://www.stdaily.com/, 0, , 332 0x7f99ed9a6070 0x2fdd0ec5ede0 
[1:1:0713/023307.186445:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023307.187100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , i, (){return e.apply(t||this,r.concat(d.call(arguments)))}
[1:1:0713/023307.187311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023307.249694:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023307.249975:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 600
[1:1:0713/023307.250467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 503
[1:1:0713/023307.250708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 503 0x7f99ed9a6070 0x2fdd0e865de0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 332 0x7f99ed9a6070 0x2fdd0ec5ede0 
[1:1:0713/023307.252409:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 5000
[1:1:0713/023307.252932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 504
[1:1:0713/023307.253160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7f99ed9a6070 0x2fdd0e923560 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 332 0x7f99ed9a6070 0x2fdd0ec5ede0 
[1:1:0713/023307.552837:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 468, 7f99f02eb881
[1:1:0713/023307.575036:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"367 0x7f99ef8ce2e0 0x2fdd0ecb7560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.575396:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"367 0x7f99ef8ce2e0 0x2fdd0ecb7560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023307.575812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023307.576509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023307.576726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023307.577631:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023307.577867:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023307.578350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 525
[1:1:0713/023307.578601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7f99ed9a6070 0x2fdd0e85fae0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 468 0x7f99ed9a6070 0x2fdd0e912ce0 
[1:1:0713/023307.707238:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023307.708081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/023307.708308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023307.755012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , document.readyState
[1:1:0713/023307.755317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023308.325068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 498, 7f99f02eb881
[1:1:0713/023308.336181:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"404 0x7f99ed9a6070 0x2fdd0ec09fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023308.336401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"404 0x7f99ed9a6070 0x2fdd0ec09fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023308.336654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.337121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023308.337269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023308.337757:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023308.337894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023308.338190:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 563
[1:1:0713/023308.338349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 563 0x7f99ed9a6070 0x2fdd0efbaa60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 498 0x7f99ed9a6070 0x2fdd0ec61b60 
[1:1:0713/023308.470233:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.470672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/023308.470781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023308.593245:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7f99ef8ce2e0 0x2fdd0eca0360 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.594330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0713/023308.594515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023308.609533:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.610378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.643096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 524 0x7f99ef8ce2e0 0x2fdd0ec5ea60 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.644129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0713/023308.644310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023308.664968:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.665793:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.747214:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7f99ef8ce2e0 0x2fdd0ec0f360 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.748591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0713/023308.748814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023308.774782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.775816:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.789333:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 529 0x7f99ef8ce2e0 0x2fdd0f3feee0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023308.792149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0713/023308.792266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
		remove user.10_410670b2 -> 0
		remove user.11_b5b7e70a -> 0
[1:1:0713/023309.441671:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/023309.502555:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e298948
[1:1:0713/023309.502783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023309.503235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 575
[1:1:0713/023309.503451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f99ed9a6070 0x2fdd0f4f3b60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 529 0x7f99ef8ce2e0 0x2fdd0f3feee0 
[1:1:0713/023309.546472:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x5e9e67029c8, 0x2fdd0e298948
[1:1:0713/023309.546766:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 0
[1:1:0713/023309.547544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 578
[1:1:0713/023309.547791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 578 0x7f99ed9a6070 0x2fdd0f659160 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 529 0x7f99ef8ce2e0 0x2fdd0f3feee0 
[1:1:0713/023309.548391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x5e9e67029c8, 0x2fdd0e298948
[1:1:0713/023309.548592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/023309.549140:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 579
[1:1:0713/023309.549411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 579 0x7f99ed9a6070 0x2fdd0e863ee0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 529 0x7f99ef8ce2e0 0x2fdd0f3feee0 
[1:1:0713/023309.888828:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 1000
[1:1:0713/023309.889351:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 582
[1:1:0713/023309.889586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7f99ed9a6070 0x2fdd0f6595e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 529 0x7f99ef8ce2e0 0x2fdd0f3feee0 
[1:1:0713/023309.919384:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023309.920254:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023309.935444:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 525, 7f99f02eb881
[1:1:0713/023309.958579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"468 0x7f99ed9a6070 0x2fdd0e912ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023309.958764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"468 0x7f99ed9a6070 0x2fdd0e912ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023309.959017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023309.959354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023309.959489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023309.959906:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023309.960007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023309.960202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 594
[1:1:0713/023309.960315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7f99ed9a6070 0x2fdd0efb9860 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 525 0x7f99ed9a6070 0x2fdd0e85fae0 
[1:1:0713/023309.975751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , document.readyState
[1:1:0713/023309.975870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023310.129962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 503, 7f99f02eb881
[1:1:0713/023310.157947:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"332 0x7f99ed9a6070 0x2fdd0ec5ede0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023310.158322:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"332 0x7f99ed9a6070 0x2fdd0ec5ede0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023310.158810:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023310.159594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , e, (){c||a(d).trigger(a.support.transition.end)}
[1:1:0713/023310.159833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023310.176363:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023310.176540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 0
[1:1:0713/023310.176738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 598
[1:1:0713/023310.176845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7f99ed9a6070 0x2fdd1006d660 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 503 0x7f99ed9a6070 0x2fdd0e865de0 
[1:1:0713/023310.540769:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 563, 7f99f02eb881
[1:1:0713/023310.565573:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"498 0x7f99ed9a6070 0x2fdd0ec61b60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023310.565847:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"498 0x7f99ed9a6070 0x2fdd0ec61b60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023310.566205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023310.566862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023310.567038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023310.567957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023310.568116:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023310.568572:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 606
[1:1:0713/023310.568763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f99ed9a6070 0x2fdd0ecb7b60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 563 0x7f99ed9a6070 0x2fdd0efbaa60 
[1:1:0713/023311.023182:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 578, 7f99f02eb881
[1:1:0713/023311.048807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"529 0x7f99ef8ce2e0 0x2fdd0f3feee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.049099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"529 0x7f99ef8ce2e0 0x2fdd0f3feee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.049445:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.050075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){l(e,t)}
[1:1:0713/023311.050261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.051902:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023311.052017:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 1
[1:1:0713/023311.052216:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 622
[1:1:0713/023311.052326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f99ed9a6070 0x2fdd0e3aa6e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 578 0x7f99ed9a6070 0x2fdd0f659160 
[1:1:0713/023311.069272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , document.readyState
[1:1:0713/023311.069421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.078420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 594, 7f99f02eb881
[1:1:0713/023311.085759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"525 0x7f99ed9a6070 0x2fdd0e85fae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.085895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"525 0x7f99ed9a6070 0x2fdd0e85fae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.086066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.086368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023311.086470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.086941:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023311.087053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023311.087242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 626
[1:1:0713/023311.087346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7f99ed9a6070 0x2fdd0ec0fc60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 594 0x7f99ed9a6070 0x2fdd0efb9860 
[1:1:0713/023311.095981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 598, 7f99f02eb881
[1:1:0713/023311.104722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"503 0x7f99ed9a6070 0x2fdd0e865de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.104883:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"503 0x7f99ed9a6070 0x2fdd0e865de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.105063:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.105361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){i.$element.trigger(m)}
[1:1:0713/023311.105465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.337005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 608 0x7f99ef8ce2e0 0x2fdd0efbca60 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.337852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0713/023311.337967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.344460:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.344894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.356191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 606, 7f99f02eb881
[1:1:0713/023311.363592:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"563 0x7f99ed9a6070 0x2fdd0efbaa60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.363745:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"563 0x7f99ed9a6070 0x2fdd0efbaa60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.363917:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.364219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023311.364333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.364655:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023311.364777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023311.364983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 640
[1:1:0713/023311.365090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7f99ed9a6070 0x2fdd0fe68b60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 606 0x7f99ed9a6070 0x2fdd0ecb7b60 
[1:1:0713/023311.444302:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.445110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/023311.445290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.470905:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.471336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0713/023311.471445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.472255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 582, 7f99f02eb8db
[1:1:0713/023311.480052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"529 0x7f99ef8ce2e0 0x2fdd0f3feee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.480183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"529 0x7f99ef8ce2e0 0x2fdd0f3feee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.480370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 642
[1:1:0713/023311.480476:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 642 0x7f99ed9a6070 0x2fdd0e860460 , 5:3_http://www.stdaily.com/, 0, , 582 0x7f99ed9a6070 0x2fdd0f6595e0 
[1:1:0713/023311.480606:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.480872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){document.hasFocus()&&s++}
[1:1:0713/023311.480989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.533402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.533918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0713/023311.534027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.534647:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 622, 7f99f02eb881
[1:1:0713/023311.542452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"578 0x7f99ed9a6070 0x2fdd0f659160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.542612:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"578 0x7f99ed9a6070 0x2fdd0f659160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023311.542806:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.543078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){n?t&&t():l(e,t)}
[1:1:0713/023311.543182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.553101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , document.readyState
[1:1:0713/023311.553258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.599025:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.599999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , y.handle, (e){return typeof x===r||e&&x.event.triggered===e.type?undefined:x.event.dispatch.apply(a.elem,argum
[1:1:0713/023311.600228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023311.636559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.637878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.639061:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.666336:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.667067:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298af0
[1:1:0713/023311.667177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023311.667374:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 648
[1:1:0713/023311.667494:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7f99ed9a6070 0x2fdd0e8556e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 631
[1:1:0713/023311.667692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023311.668111:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e2989f0
[1:1:0713/023311.668209:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023311.668384:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 649
[1:1:0713/023311.668492:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f99ed9a6070 0x2fdd0e8d7b60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 631
[1:1:0713/023311.908406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , document.readyState
[1:1:0713/023311.908641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023312.160089:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 648, 7f99f02eb881
[1:1:0713/023312.186823:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"631","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.187119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"631","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.187491:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023312.188143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023312.188319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023312.189093:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023312.189252:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023312.189686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 676
[1:1:0713/023312.189881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f99ed9a6070 0x2fdd0f3fe960 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 648 0x7f99ed9a6070 0x2fdd0e8556e0 
[1:1:0713/023312.191187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 649, 7f99f02eb881
[1:1:0713/023312.218050:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"631","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.218297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"631","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.218612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023312.219237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023312.219412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023312.220166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023312.220322:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023312.220889:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 677
[1:1:0713/023312.221096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7f99ed9a6070 0x2fdd0ffa4c60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 649 0x7f99ed9a6070 0x2fdd0e8d7b60 
[1:1:0713/023312.277321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 642, 7f99f02eb8db
[1:1:0713/023312.304157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"582 0x7f99ed9a6070 0x2fdd0f6595e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.304375:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"582 0x7f99ed9a6070 0x2fdd0f6595e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.304724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 679
[1:1:0713/023312.304907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f99ed9a6070 0x2fdd0efba660 , 5:3_http://www.stdaily.com/, 0, , 642 0x7f99ed9a6070 0x2fdd0e860460 
[1:1:0713/023312.305160:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023312.305715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){document.hasFocus()&&s++}
[1:1:0713/023312.305885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023312.785609:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 504, 7f99f02eb8db
[1:1:0713/023312.814231:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"332 0x7f99ed9a6070 0x2fdd0ec5ede0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.814530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"332 0x7f99ed9a6070 0x2fdd0ec5ede0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.814919:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 688
[1:1:0713/023312.815131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7f99ed9a6070 0x2fdd0fe68960 , 5:3_http://www.stdaily.com/, 0, , 504 0x7f99ed9a6070 0x2fdd0e923560 
[1:1:0713/023312.815393:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023312.815999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , i, (){return e.apply(t||this,r.concat(d.call(arguments)))}
[1:1:0713/023312.816196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023312.899406:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023312.899577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 600
[1:1:0713/023312.899780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 689
[1:1:0713/023312.899893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f99ed9a6070 0x2fdd0f4f3160 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 504 0x7f99ed9a6070 0x2fdd0e923560 
[1:1:0713/023312.900550:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 5000
[1:1:0713/023312.900744:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 690
[1:1:0713/023312.900852:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7f99ed9a6070 0x2fdd0e8e92e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 504 0x7f99ed9a6070 0x2fdd0e923560 
[1:1:0713/023312.931388:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 676, 7f99f02eb881
[1:1:0713/023312.944557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"648 0x7f99ed9a6070 0x2fdd0e8556e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.944816:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"648 0x7f99ed9a6070 0x2fdd0e8556e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.945090:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023312.945562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023312.945723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023312.946247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023312.946385:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023312.946662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 696
[1:1:0713/023312.946819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 696 0x7f99ed9a6070 0x2fdd0ffc0fe0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 676 0x7f99ed9a6070 0x2fdd0f3fe960 
[1:1:0713/023312.947494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 677, 7f99f02eb881
[1:1:0713/023312.964560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"649 0x7f99ed9a6070 0x2fdd0e8d7b60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.964928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"649 0x7f99ed9a6070 0x2fdd0e8d7b60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023312.965383:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023312.966207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023312.966433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023312.967421:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023312.967624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023312.968214:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 697
[1:1:0713/023312.968460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7f99ed9a6070 0x2fdd100126e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 677 0x7f99ed9a6070 0x2fdd0ffa4c60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/023313.141514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 679, 7f99f02eb8db
[1:1:0713/023313.170666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"642 0x7f99ed9a6070 0x2fdd0e860460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.170943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"642 0x7f99ed9a6070 0x2fdd0e860460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.171378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 709
[1:1:0713/023313.171576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f99ed9a6070 0x2fdd0ff2a460 , 5:3_http://www.stdaily.com/, 0, , 679 0x7f99ed9a6070 0x2fdd0efba660 
[1:1:0713/023313.171827:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023313.172477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){document.hasFocus()&&s++}
[1:1:0713/023313.172653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023313.346043:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 696, 7f99f02eb881
[1:1:0713/023313.375323:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"676 0x7f99ed9a6070 0x2fdd0f3fe960 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.375716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"676 0x7f99ed9a6070 0x2fdd0f3fe960 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.376187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023313.377034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023313.377277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023313.378280:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023313.378488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023313.379050:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 713
[1:1:0713/023313.379315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f99ed9a6070 0x2fdd0ec0ff60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 696 0x7f99ed9a6070 0x2fdd0ffc0fe0 
[1:1:0713/023313.436539:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 697, 7f99f02eb881
[1:1:0713/023313.445556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"677 0x7f99ed9a6070 0x2fdd0ffa4c60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.445724:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"677 0x7f99ed9a6070 0x2fdd0ffa4c60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.445941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023313.446302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023313.446427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023313.446758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023313.446856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023313.447045:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 714
[1:1:0713/023313.447158:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7f99ed9a6070 0x2fdd0ffa6e60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 697 0x7f99ed9a6070 0x2fdd100126e0 
[1:1:0713/023313.733121:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 713, 7f99f02eb881
[1:1:0713/023313.743074:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"696 0x7f99ed9a6070 0x2fdd0ffc0fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.743345:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"696 0x7f99ed9a6070 0x2fdd0ffc0fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.743561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023313.746844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023313.747043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023313.747836:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023313.747997:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023313.748469:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 729
[1:1:0713/023313.748664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f99ed9a6070 0x2fdd0e5ab2e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 713 0x7f99ed9a6070 0x2fdd0ec0ff60 
[1:1:0713/023313.750001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 689, 7f99f02eb881
[1:1:0713/023313.781295:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"504 0x7f99ed9a6070 0x2fdd0e923560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.781618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"504 0x7f99ed9a6070 0x2fdd0e923560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.781970:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023313.782696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , e, (){c||a(d).trigger(a.support.transition.end)}
[1:1:0713/023313.782901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023313.809680:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023313.809903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 0
[1:1:0713/023313.810402:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 730
[1:1:0713/023313.810613:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f99ed9a6070 0x2fdd0ffa6360 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 689 0x7f99ed9a6070 0x2fdd0f4f3160 
[1:1:0713/023313.841849:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 714, 7f99f02eb881
[1:1:0713/023313.851229:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"697 0x7f99ed9a6070 0x2fdd100126e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.851511:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"697 0x7f99ed9a6070 0x2fdd100126e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023313.851854:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023313.852187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023313.852293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023313.852651:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023313.852752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023313.852991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 733
[1:1:0713/023313.853100:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f99ed9a6070 0x2fdd0f3e82e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 714 0x7f99ed9a6070 0x2fdd0ffa6e60 
[1:1:0713/023314.115032:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 730, 7f99f02eb881
[1:1:0713/023314.150650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"689 0x7f99ed9a6070 0x2fdd0f4f3160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.151025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"689 0x7f99ed9a6070 0x2fdd0f4f3160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.152325:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.153030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){i.$element.trigger(m)}
[1:1:0713/023314.153249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
		remove user.12_dff1f9dd -> 0
[1:1:0713/023314.203716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 729, 7f99f02eb881
[1:1:0713/023314.235828:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"713 0x7f99ed9a6070 0x2fdd0ec0ff60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.236193:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"713 0x7f99ed9a6070 0x2fdd0ec0ff60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.236661:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.237354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023314.237569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.238379:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023314.238625:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023314.239119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 744
[1:1:0713/023314.239351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 744 0x7f99ed9a6070 0x2fdd0e919ae0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 729 0x7f99ed9a6070 0x2fdd0e5ab2e0 
[1:1:0713/023314.240690:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 709, 7f99f02eb8db
[1:1:0713/023314.254116:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"679 0x7f99ed9a6070 0x2fdd0efba660 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.254432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"679 0x7f99ed9a6070 0x2fdd0efba660 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.254946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 745
[1:1:0713/023314.255178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f99ed9a6070 0x2fdd0ffc0860 , 5:3_http://www.stdaily.com/, 0, , 709 0x7f99ed9a6070 0x2fdd0ff2a460 
[1:1:0713/023314.255483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.256138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){document.hasFocus()&&s++}
[1:1:0713/023314.256360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.374984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 733, 7f99f02eb881
[1:1:0713/023314.405309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"714 0x7f99ed9a6070 0x2fdd0ffa6e60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.405708:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"714 0x7f99ed9a6070 0x2fdd0ffa6e60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.406135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.406897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023314.407111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.407933:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023314.408131:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023314.408646:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 749
[1:1:0713/023314.408875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7f99ed9a6070 0x2fdd0f7a1ae0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 733 0x7f99ed9a6070 0x2fdd0f3e82e0 
[1:1:0713/023314.545093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 744, 7f99f02eb881
[1:1:0713/023314.575247:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"729 0x7f99ed9a6070 0x2fdd0e5ab2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.575636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"729 0x7f99ed9a6070 0x2fdd0e5ab2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.576041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.576779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023314.576996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.577818:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023314.578013:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023314.578587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 754
[1:1:0713/023314.578835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7f99ed9a6070 0x2fdd0ffc32e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 744 0x7f99ed9a6070 0x2fdd0e919ae0 
[1:1:0713/023314.676384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 749, 7f99f02eb881
[1:1:0713/023314.708788:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"733 0x7f99ed9a6070 0x2fdd0f3e82e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.709156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"733 0x7f99ed9a6070 0x2fdd0f3e82e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.709584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.710464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023314.710753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.711551:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023314.711770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023314.712268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 756
[1:1:0713/023314.712498:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f99ed9a6070 0x2fdd0ffc0d60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 749 0x7f99ed9a6070 0x2fdd0f7a1ae0 
[1:1:0713/023314.714214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 754, 7f99f02eb881
[1:1:0713/023314.744880:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"744 0x7f99ed9a6070 0x2fdd0e919ae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.745284:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"744 0x7f99ed9a6070 0x2fdd0e919ae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.745737:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.746446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023314.746761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.747605:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023314.747814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023314.748333:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 759
[1:1:0713/023314.748590:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7f99ed9a6070 0x2fdd10151e60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 754 0x7f99ed9a6070 0x2fdd0ffc32e0 
[1:1:0713/023314.817925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 756, 7f99f02eb881
[1:1:0713/023314.851419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"749 0x7f99ed9a6070 0x2fdd0f7a1ae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.851950:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"749 0x7f99ed9a6070 0x2fdd0f7a1ae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.852404:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.853129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023314.853379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.860040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023314.860261:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023314.860785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 766
[1:1:0713/023314.861017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 766 0x7f99ed9a6070 0x2fdd1018fee0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 756 0x7f99ed9a6070 0x2fdd0ffc0d60 
[1:1:0713/023314.898449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 759, 7f99f02eb881
[1:1:0713/023314.916402:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"754 0x7f99ed9a6070 0x2fdd0ffc32e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.916765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"754 0x7f99ed9a6070 0x2fdd0ffc32e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023314.917195:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023314.917980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023314.918257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023314.919095:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023314.919303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023314.919817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 771
[1:1:0713/023314.920052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 771 0x7f99ed9a6070 0x2fdd0ec09c60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 759 0x7f99ed9a6070 0x2fdd10151e60 
[1:1:0713/023314.991325:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 745, 7f99f02eb8db
[1:1:0713/023315.022608:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"709 0x7f99ed9a6070 0x2fdd0ff2a460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.022991:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"709 0x7f99ed9a6070 0x2fdd0ff2a460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.023435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 775
[1:1:0713/023315.023685:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7f99ed9a6070 0x2fdd0e8c9460 , 5:3_http://www.stdaily.com/, 0, , 745 0x7f99ed9a6070 0x2fdd0ffc0860 
[1:1:0713/023315.024024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.024711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){document.hasFocus()&&s++}
[1:1:0713/023315.024925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.057771:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 766, 7f99f02eb881
[1:1:0713/023315.088611:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"756 0x7f99ed9a6070 0x2fdd0ffc0d60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.088982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"756 0x7f99ed9a6070 0x2fdd0ffc0d60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.089376:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.090074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.090325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.091149:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.091347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.091876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 780
[1:1:0713/023315.092108:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f99ed9a6070 0x2fdd0ffa47e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 766 0x7f99ed9a6070 0x2fdd1018fee0 
[1:1:0713/023315.159035:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 771, 7f99f02eb881
[1:1:0713/023315.189888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"759 0x7f99ed9a6070 0x2fdd10151e60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.190245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"759 0x7f99ed9a6070 0x2fdd10151e60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.190665:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.191368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.191581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.192387:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.192581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.192902:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 783
[1:1:0713/023315.193132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7f99ed9a6070 0x2fdd101919e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 771 0x7f99ed9a6070 0x2fdd0ec09c60 
[1:1:0713/023315.238048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 780, 7f99f02eb881
[1:1:0713/023315.268296:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"766 0x7f99ed9a6070 0x2fdd1018fee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.268662:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"766 0x7f99ed9a6070 0x2fdd1018fee0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.269149:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.269868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.270088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.270927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.271148:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.271651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 789
[1:1:0713/023315.271891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7f99ed9a6070 0x2fdd100365e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 780 0x7f99ed9a6070 0x2fdd0ffa47e0 
[1:1:0713/023315.306079:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 783, 7f99f02eb881
[1:1:0713/023315.317538:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"771 0x7f99ed9a6070 0x2fdd0ec09c60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.317871:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"771 0x7f99ed9a6070 0x2fdd0ec09c60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.318253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.318956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.319172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.319997:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.320198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.320681:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 792
[1:1:0713/023315.320911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7f99ed9a6070 0x2fdd0f7a2660 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 783 0x7f99ed9a6070 0x2fdd101919e0 
[1:1:0713/023315.372574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 789, 7f99f02eb881
[1:1:0713/023315.403807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"780 0x7f99ed9a6070 0x2fdd0ffa47e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.404194:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"780 0x7f99ed9a6070 0x2fdd0ffa47e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.404592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.405295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.405531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.406387:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.406633:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.409179:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 798
[1:1:0713/023315.409433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7f99ed9a6070 0x2fdd100fa560 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 789 0x7f99ed9a6070 0x2fdd100365e0 
[1:1:0713/023315.442259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 792, 7f99f02eb881
[1:1:0713/023315.474351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"783 0x7f99ed9a6070 0x2fdd101919e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.474741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"783 0x7f99ed9a6070 0x2fdd101919e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.475169:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.475893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.476116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.476968:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.477166:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.477657:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 802
[1:1:0713/023315.477893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7f99ed9a6070 0x2fdd100fa0e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 792 0x7f99ed9a6070 0x2fdd0f7a2660 
[1:1:0713/023315.608727:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 798, 7f99f02eb881
[1:1:0713/023315.631822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"789 0x7f99ed9a6070 0x2fdd100365e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.632201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"789 0x7f99ed9a6070 0x2fdd100365e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.632598:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.633310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.633554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.634403:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.634644:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.635157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 811
[1:1:0713/023315.635390:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7f99ed9a6070 0x2fdd0f7a1fe0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 798 0x7f99ed9a6070 0x2fdd100fa560 
[1:1:0713/023315.676311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 802, 7f99f02eb881
[1:1:0713/023315.710787:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"792 0x7f99ed9a6070 0x2fdd0f7a2660 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.711233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"792 0x7f99ed9a6070 0x2fdd0f7a2660 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.711653:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.712358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.712585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.713424:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.713624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.714139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 814
[1:1:0713/023315.714412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7f99ed9a6070 0x2fdd0f4f3de0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 802 0x7f99ed9a6070 0x2fdd100fa0e0 
[1:1:0713/023315.744241:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 811, 7f99f02eb881
[1:1:0713/023315.777295:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"798 0x7f99ed9a6070 0x2fdd100fa560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.777665:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"798 0x7f99ed9a6070 0x2fdd100fa560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.778089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.778838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.779090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.779933:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.780132:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.780626:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 817
[1:1:0713/023315.780872:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 817 0x7f99ed9a6070 0x2fdd0e7d4160 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 811 0x7f99ed9a6070 0x2fdd0f7a1fe0 
[1:1:0713/023315.822084:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 814, 7f99f02eb881
[1:1:0713/023315.838719:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"802 0x7f99ed9a6070 0x2fdd100fa0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.839120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"802 0x7f99ed9a6070 0x2fdd100fa0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.839635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.840332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.840548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.841396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.841616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.842128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 821
[1:1:0713/023315.842394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f99ed9a6070 0x2fdd0e724960 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 814 0x7f99ed9a6070 0x2fdd0f4f3de0 
[1:1:0713/023315.946757:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 817, 7f99f02eb881
[1:1:0713/023315.979697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"811 0x7f99ed9a6070 0x2fdd0f7a1fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.980082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"811 0x7f99ed9a6070 0x2fdd0f7a1fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023315.980480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023315.981192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023315.981408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023315.982309:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023315.982585:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023315.983105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 831
[1:1:0713/023315.983346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7f99ed9a6070 0x2fdd0f6353e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 817 0x7f99ed9a6070 0x2fdd0e7d4160 
[1:1:0713/023316.017101:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 775, 7f99f02eb8db
[1:1:0713/023316.051313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"745 0x7f99ed9a6070 0x2fdd0ffc0860 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.051655:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"745 0x7f99ed9a6070 0x2fdd0ffc0860 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.052117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 834
[1:1:0713/023316.052361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 834 0x7f99ed9a6070 0x2fdd10151160 , 5:3_http://www.stdaily.com/, 0, , 775 0x7f99ed9a6070 0x2fdd0e8c9460 
[1:1:0713/023316.052650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.053324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){document.hasFocus()&&s++}
[1:1:0713/023316.053558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.066618:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 821, 7f99f02eb881
[1:1:0713/023316.082277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"814 0x7f99ed9a6070 0x2fdd0f4f3de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.082679:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"814 0x7f99ed9a6070 0x2fdd0f4f3de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.083128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.083825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.084084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.084938:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.085143:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.085639:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 835
[1:1:0713/023316.085871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 835 0x7f99ed9a6070 0x2fdd101546e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 821 0x7f99ed9a6070 0x2fdd0e724960 
[1:1:0713/023316.087522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 831, 7f99f02eb881
[1:1:0713/023316.119861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"817 0x7f99ed9a6070 0x2fdd0e7d4160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.120236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"817 0x7f99ed9a6070 0x2fdd0e7d4160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.120666:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.121393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.121619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.122451:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.122688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.123213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 838
[1:1:0713/023316.123449:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 838 0x7f99ed9a6070 0x2fdd10134260 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 831 0x7f99ed9a6070 0x2fdd0f6353e0 
[1:1:0713/023316.277745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 835, 7f99f02eb881
[1:1:0713/023316.310243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"821 0x7f99ed9a6070 0x2fdd0e724960 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.310625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"821 0x7f99ed9a6070 0x2fdd0e724960 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.311048:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.311737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.311996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.312846:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.313058:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.313550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 848
[1:1:0713/023316.313785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 848 0x7f99ed9a6070 0x2fdd10134160 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 835 0x7f99ed9a6070 0x2fdd101546e0 
[1:1:0713/023316.315219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 838, 7f99f02eb881
[1:1:0713/023316.356032:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"831 0x7f99ed9a6070 0x2fdd0f6353e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.356400:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"831 0x7f99ed9a6070 0x2fdd0f6353e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.356803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.357510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.357725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.358542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.358773:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.359285:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 849
[1:1:0713/023316.359519:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f99ed9a6070 0x2fdd101911e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 838 0x7f99ed9a6070 0x2fdd10134260 
[1:1:0713/023316.441045:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 848, 7f99f02eb881
[1:1:0713/023316.470458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"835 0x7f99ed9a6070 0x2fdd101546e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.470823:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"835 0x7f99ed9a6070 0x2fdd101546e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.471249:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.471947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.472170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.472968:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.473167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.473660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 852
[1:1:0713/023316.473892:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f99ed9a6070 0x2fdd0e724960 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 848 0x7f99ed9a6070 0x2fdd10134160 
[1:1:0713/023316.475582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 849, 7f99f02eb881
[1:1:0713/023316.508262:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"838 0x7f99ed9a6070 0x2fdd10134260 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.508644:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"838 0x7f99ed9a6070 0x2fdd10134260 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.509094:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.509782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.509996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.510887:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.511103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.511598:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 855
[1:1:0713/023316.511845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 855 0x7f99ed9a6070 0x2fdd1006d3e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 849 0x7f99ed9a6070 0x2fdd101911e0 
[1:1:0713/023316.591889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 852, 7f99f02eb881
[1:1:0713/023316.627570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"848 0x7f99ed9a6070 0x2fdd10134160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.627941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"848 0x7f99ed9a6070 0x2fdd10134160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.628354:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.629048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.629263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.630136:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.630361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.630875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 860
[1:1:0713/023316.631125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 860 0x7f99ed9a6070 0x2fdd0f3fed60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 852 0x7f99ed9a6070 0x2fdd0e724960 
[1:1:0713/023316.632486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 855, 7f99f02eb881
[1:1:0713/023316.643955:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"849 0x7f99ed9a6070 0x2fdd101911e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.644315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"849 0x7f99ed9a6070 0x2fdd101911e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.644689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.645332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.645547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.646402:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.646599:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.647115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 862
[1:1:0713/023316.647346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f99ed9a6070 0x2fdd0e921e60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 855 0x7f99ed9a6070 0x2fdd1006d3e0 
[1:1:0713/023316.749576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 860, 7f99f02eb881
[1:1:0713/023316.780488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"852 0x7f99ed9a6070 0x2fdd0e724960 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.780847:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"852 0x7f99ed9a6070 0x2fdd0e724960 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.781263:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.781945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.782172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.782973:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.783188:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.783677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 865
[1:1:0713/023316.783916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7f99ed9a6070 0x2fdd0e91cd60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 860 0x7f99ed9a6070 0x2fdd0f3fed60 
[1:1:0713/023316.785320:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 862, 7f99f02eb881
[1:1:0713/023316.818295:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"855 0x7f99ed9a6070 0x2fdd1006d3e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.818657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"855 0x7f99ed9a6070 0x2fdd1006d3e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.819052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.819737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.819952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.820761:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.820956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.821464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 866
[1:1:0713/023316.821693:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 866 0x7f99ed9a6070 0x2fdd0ffa69e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 862 0x7f99ed9a6070 0x2fdd0e921e60 
[1:1:0713/023316.899410:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 865, 7f99f02eb881
[1:1:0713/023316.919937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32cfd4da2860","ptid":"860 0x7f99ed9a6070 0x2fdd0f3fed60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.920309:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"860 0x7f99ed9a6070 0x2fdd0f3fed60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/023316.920714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/023316.921419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/023316.921633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/023316.922494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x5e9e67029c8, 0x2fdd0e298950
[1:1:0713/023316.922699:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/023316.923212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 869
[1:1:0713/023316.923444:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 869 0x7f99ed9a6070 0x2fdd10015ae0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 865 0x7f99ed9a6070 0x2fdd0e91cd60 
[1:1:0713/023316.924792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 834, 7f99f02eb8db
[1:1:0100/000000.961360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"775 0x7f99ed9a6070 0x2fdd0e8c9460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0100/000000.961587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"775 0x7f99ed9a6070 0x2fdd0e8c9460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0100/000000.962009:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 874
[1:1:0100/000000.962192:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 874 0x7f99ed9a6070 0x2fdd1018fb60 , 5:3_http://www.stdaily.com/, 0, , 834 0x7f99ed9a6070 0x2fdd10151160 
[1:1:0100/000000.962392:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0100/000000.962968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 32cfd4da2860, , , (){document.hasFocus()&&s++}
[1:1:0100/000000.963111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0100/000000.965178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 866, 7f99f02eb881
