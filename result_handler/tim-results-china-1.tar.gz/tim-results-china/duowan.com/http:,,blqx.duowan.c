[0712/144220.758372:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144220.758840:INFO:switcher_clone.cc(787)] backtrace rip is 7f3482749891
[0712/144221.715926:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144221.716235:INFO:switcher_clone.cc(787)] backtrace rip is 7fbda8eb6891
[1:1:0712/144221.720468:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/144221.720671:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/144221.726097:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/144222.962786:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144222.963213:INFO:switcher_clone.cc(787)] backtrace rip is 7fbd51ade891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[25873:25873:0712/144223.183039:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25873
[25884:25884:0712/144223.183486:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25884
[25842:25842:0712/144223.314149:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/543b916c-e65d-4a67-9e00-6bd4cafea4cc
[25842:25842:0712/144223.735150:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[25842:25871:0712/144223.735862:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/144223.736129:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144223.736402:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144223.736981:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144223.737141:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/144223.740052:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x453048d, 1
[1:1:0712/144223.740450:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3fac4799, 0
[1:1:0712/144223.740620:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2ece8017, 3
[1:1:0712/144223.740783:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2152591b, 2
[1:1:0712/144223.740978:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9947ffffffac3f ffffff8d045304 1b595221 17ffffff80ffffffce2e , 10104, 4
[1:1:0712/144223.741928:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25842:25871:0712/144223.742267:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�G�?�SYR!��.��Y1
[25842:25871:0712/144223.742351:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �G�?�SYR!��.H��Y1
[1:1:0712/144223.742258:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbda70f10a0, 3
[1:1:0712/144223.742485:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbda727c080, 2
[25842:25871:0712/144223.742640:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/144223.742640:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbd90f3fd20, -2
[25842:25871:0712/144223.742710:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25894, 4, 9947ac3f 8d045304 1b595221 1780ce2e 
[1:1:0712/144223.758336:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144223.759224:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2152591b
[1:1:0712/144223.760280:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2152591b
[1:1:0712/144223.761903:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2152591b
[1:1:0712/144223.763431:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.763621:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.763808:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.764014:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.764719:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2152591b
[1:1:0712/144223.765045:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbda8eb67ba
[1:1:0712/144223.765180:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbda8eaddef, 7fbda8eb677a, 7fbda8eb80cf
[1:1:0712/144223.767952:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2152591b
[1:1:0712/144223.768138:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2152591b
[1:1:0712/144223.768466:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2152591b
[1:1:0712/144223.769156:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.769290:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.769403:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.769497:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2152591b
[1:1:0712/144223.769932:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2152591b
[1:1:0712/144223.770094:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbda8eb67ba
[1:1:0712/144223.770169:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbda8eaddef, 7fbda8eb677a, 7fbda8eb80cf
[1:1:0712/144223.772439:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144223.772713:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144223.772805:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc5c8ce388, 0x7ffc5c8ce308)
[1:1:0712/144223.787141:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144223.793435:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[25842:25842:0712/144224.333794:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25842:25842:0712/144224.335126:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25842:25853:0712/144224.356227:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[25842:25853:0712/144224.356331:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[25842:25842:0712/144224.356554:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[25842:25842:0712/144224.356653:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[25842:25842:0712/144224.356837:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,25894, 4
[1:7:0712/144224.358867:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[25842:25866:0712/144224.419045:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/144224.469149:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1a40362b6220
[1:1:0712/144224.469461:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/144224.787514:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[25842:25842:0712/144226.601472:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[25842:25842:0712/144226.601594:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144226.630165:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144226.634500:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144227.923079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0daed4341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144227.923404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144227.953931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0daed4341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144227.954257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144227.988108:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144228.240513:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144228.240786:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144228.576218:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144228.584192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0daed4341f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144228.584502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144228.606913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144228.617358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0daed4341f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144228.617620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144228.629421:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/144228.632837:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1a40362b4e20
[1:1:0712/144228.633014:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[25842:25842:0712/144228.633517:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[25842:25842:0712/144228.647795:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[25842:25842:0712/144228.693488:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[25842:25842:0712/144228.693587:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144228.723903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144229.646045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fbd92b1a2e0 0x1a403649fee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144229.646793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0daed4341f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/144229.647291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144229.648808:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[25842:25842:0712/144229.722292:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144229.724735:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1a40362b5820
[1:1:0712/144229.724938:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[25842:25842:0712/144229.742662:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/144229.743435:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144229.743626:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[25842:25842:0712/144229.768964:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[25842:25842:0712/144229.782750:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25842:25842:0712/144229.783999:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25842:25853:0712/144229.791423:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[25842:25853:0712/144229.791524:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[25842:25842:0712/144229.791781:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[25842:25842:0712/144229.791881:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[25842:25842:0712/144229.792049:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,25894, 4
[1:7:0712/144229.795528:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144230.477481:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/144231.277464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fbd92b1a2e0 0x1a4036542860 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144231.278525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0daed4341f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/144231.278768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144231.279575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[25842:25842:0712/144231.391440:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[25842:25842:0712/144231.391595:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/144231.422052:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[25842:25842:0712/144231.626576:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[25842:25871:0712/144231.627043:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/144231.627407:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144231.627687:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144231.628235:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144231.628414:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/144231.632136:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x113973d6, 1
[1:1:0712/144231.632559:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3789ce6a, 0
[1:1:0712/144231.632717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3e2a5bca, 3
[1:1:0712/144231.632862:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x34c969ca, 2
[1:1:0712/144231.633015:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6affffffceffffff8937 ffffffd6733911 ffffffca69ffffffc934 ffffffca5b2a3e , 10104, 5
[1:1:0712/144231.633978:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25842:25871:0712/144231.634268:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGjΉ7�s9�i�4�[*>��Y1
[25842:25871:0712/144231.634356:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is jΉ7�s9�i�4�[*>8��Y1
[1:1:0712/144231.634260:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbda70f10a0, 3
[1:1:0712/144231.634502:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbda727c080, 2
[25842:25871:0712/144231.634658:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25940, 5, 6ace8937 d6733911 ca69c934 ca5b2a3e 
[1:1:0712/144231.634733:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbd90f3fd20, -2
[1:1:0712/144231.658791:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144231.659264:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34c969ca
[1:1:0712/144231.659642:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34c969ca
[1:1:0712/144231.660453:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34c969ca
[1:1:0712/144231.662198:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.662433:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.662656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.662877:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.663705:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34c969ca
[1:1:0712/144231.664069:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbda8eb67ba
[1:1:0712/144231.664282:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbda8eaddef, 7fbda8eb677a, 7fbda8eb80cf
[1:1:0712/144231.668523:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34c969ca
[1:1:0712/144231.668765:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34c969ca
[1:1:0712/144231.669154:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34c969ca
[1:1:0712/144231.670154:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.670502:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.670773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.671025:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34c969ca
[1:1:0712/144231.672706:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34c969ca
[1:1:0712/144231.673201:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbda8eb67ba
[1:1:0712/144231.673382:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbda8eaddef, 7fbda8eb677a, 7fbda8eb80cf
[1:1:0712/144231.678739:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144231.679186:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144231.679317:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc5c8ce388, 0x7ffc5c8ce308)
[1:1:0712/144231.695155:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144231.698139:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/144231.789454:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144231.943263:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1a403627a220
[1:1:0712/144231.943435:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[25842:25842:0712/144232.393122:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25842:25842:0712/144232.398787:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/144232.427281:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144232.427590:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[25842:25842:0712/144232.436409:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://blqx.duowan.com/
[25842:25842:0712/144232.436517:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://blqx.duowan.com/, http://blqx.duowan.com/, 1
[25842:25842:0712/144232.436675:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://blqx.duowan.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 21:42:32 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 21:57:32 GMT Cache-Control: max-age=900 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,25940, 5
[25842:25853:0712/144232.443371:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[25842:25853:0712/144232.443490:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/144232.444439:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144232.458578:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://blqx.duowan.com/
[25842:25842:0712/144232.635509:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://blqx.duowan.com/, http://blqx.duowan.com/, 1
[25842:25842:0712/144232.635652:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://blqx.duowan.com/, http://blqx.duowan.com
[1:1:0712/144232.667865:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144232.769597:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144232.812910:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144232.846647:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144232.846813:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://blqx.duowan.com/"
[1:1:0712/144232.963028:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144233.124027:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144233.128318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0daed446e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/144233.128664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144233.138679:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144233.522857:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7fbd90bf2070 0x1a4036435ae0 , "http://blqx.duowan.com/"
[1:1:0712/144233.525099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , 
     	 if(location.protocol == "https:") {
 				window.location.href = window.location.href.replace
[1:1:0712/144233.525277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144233.621738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7fbd90bf2070 0x1a4036435ae0 , "http://blqx.duowan.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/144234.107747:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144234.306466:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 216 0x7fbda727c080 0x1a403648fec0 1 0 0x1a403648fed8 , "http://blqx.duowan.com/"
[1:1:0712/144234.307503:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144234.319722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , /*! jQuery v1.11.2 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/144234.320050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144234.384325:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144234.388815:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144234.389324:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144234.389745:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144234.390201:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_9926dee2 -> 0
[1:1:0712/144234.572427:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0073421, 139, 1
[1:1:0712/144234.572725:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144234.832445:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144234.832726:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://blqx.duowan.com/"
[1:1:0712/144234.839412:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fbd90bf2070 0x1a40366450e0 , "http://blqx.duowan.com/"
[1:1:0712/144234.843590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , !function(window,$){function parseCookieString(i,n){var o={};if(isString(i)&&i.length>0)for(var t,e,
[1:1:0712/144234.843871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144234.913813:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fbd90bf2070 0x1a40366450e0 , "http://blqx.duowan.com/"
[1:1:0712/144235.369866:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.537028, 1184, 0
[1:1:0712/144235.370167:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144236.126166:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144236.126452:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://blqx.duowan.com/"
[1:1:0712/144236.243965:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.117495, 926, 1
[1:1:0712/144236.244319:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144236.694558:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144236.694827:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://blqx.duowan.com/"
[1:1:0712/144236.698643:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7fbd90bf2070 0x1a40367f11e0 , "http://blqx.duowan.com/"
[1:1:0712/144236.701830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , !function(){var scripts=document.getElementsByTagName("script"),src=scripts[scripts.length-1].src,ar
[1:1:0712/144236.702057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144236.762926:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7fbd90bf2070 0x1a40367f11e0 , "http://blqx.duowan.com/"
[1:1:0712/144236.790148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7fbd90bf2070 0x1a40367f11e0 , "http://blqx.duowan.com/"
[1:1:0712/144237.141418:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7fbd90bf2070 0x1a40367f11e0 , "http://blqx.duowan.com/"
[1:1:0712/144241.671565:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 4.97673, 0, 0
[1:1:0712/144241.671900:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144244.240928:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144244.241193:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://blqx.duowan.com/"
[1:1:0712/144244.245747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://blqx.duowan.com/"
[1:1:0712/144244.247601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , J, (){(y.addEventListener||"load"===event.type||"complete"===y.readyState)&&(I(),m.ready())}
[1:1:0712/144244.247878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144244.433953:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://blqx.duowan.com/"
[1:1:0712/144246.628764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 517 0x7fbd92b1a2e0 0x1a4036286be0 , "http://blqx.duowan.com/"
[1:1:0712/144246.631100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , !function(a){var b=a;String.prototype.startsWith=function(a){var b=new RegExp("^"+a);return b.test(t
[1:1:0712/144246.631335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144246.644943:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144246.645501:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144246.657715:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/144246.675618:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1a4036d17020
[1:1:0712/144246.675875:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/144246.722057:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/144246.722697:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/144246.737434:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1a4036f9de20
[1:1:0712/144246.737679:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/144246.788462:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x1a4036d1a220
[1:1:0712/144246.788730:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0712/144246.836715:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144246.854201:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 518 0x7fbd92b1a2e0 0x1a4036432be0 , "http://blqx.duowan.com/"
[1:1:0712/144246.855682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , !function(){var a=document.getElementsByTagName("script"),c=a[a.length-1].src,e=-1!==c.indexOf("?")?
[1:1:0712/144246.855929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144246.870235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144247.116275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7fbd92b1a2e0 0x1a40366fcbe0 , "http://blqx.duowan.com/"
[1:1:0712/144247.117378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , !function(e){var t=e.amkit;t||(t=e.amkit={});var n=t.entry;n||(n=t.entry={}),n.getScript||(n.getScri
[1:1:0712/144247.117609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144247.122879:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144247.154235:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531 0x7fbd92b1a2e0 0x1a40365ca160 , "http://blqx.duowan.com/"
[1:1:0712/144247.163680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , (function(){var h={},mt={},c={id:"6513a3d44e6315041f56d62463297554",dm:["fn.duowan.com"],js:"tongji.
[1:1:0712/144247.164004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144247.206356:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9948
[1:1:0712/144247.206658:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144247.207083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 661
[1:1:0712/144247.207355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7fbd90bf2070 0x1a4036aacee0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 531 0x7fbd92b1a2e0 0x1a40365ca160 
[25842:25842:0712/144304.297137:INFO:CONSOLE(58)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pub.dwstatic.com/common/js/jquery.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://blqx.duowan.com/ (58)
[25842:25842:0712/144304.300982:INFO:CONSOLE(58)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pub.dwstatic.com/common/js/jquery.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://blqx.duowan.com/ (58)
[25842:25842:0712/144304.513691:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[25842:25842:0712/144304.518467:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[25842:25842:0712/144304.524543:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[25842:25842:0712/144304.545443:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://blqx.duowan.com/, http://blqx.duowan.com/, 4
[25842:25842:0712/144304.545581:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://blqx.duowan.com/, http://blqx.duowan.com
[25842:25842:0712/144304.589231:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[25842:25842:0712/144304.595859:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[25842:25842:0712/144304.617859:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://blqx.duowan.com/, http://blqx.duowan.com/, 5
[25842:25842:0712/144304.617998:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://blqx.duowan.com/, http://blqx.duowan.com
[25842:25842:0712/144304.661127:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[25842:25842:0712/144304.668317:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[25842:25842:0712/144304.689902:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://blqx.duowan.com/, http://blqx.duowan.com/, 6
[25842:25842:0712/144304.690042:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://blqx.duowan.com/, http://blqx.duowan.com
[3:3:0712/144304.750339:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[25842:25842:0712/144304.911771:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[25842:25842:0712/144304.922368:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[25842:25842:0712/144304.931085:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/144308.382035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/144308.382356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144311.045716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 661, 7fbd93537881
[1:1:0712/144311.080617:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"531 0x7fbd92b1a2e0 0x1a40365ca160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144311.081021:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"531 0x7fbd92b1a2e0 0x1a40365ca160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144311.081468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144311.082096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144311.082313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144311.083074:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144311.083287:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144311.083644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 850
[1:1:0712/144311.083907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7fbd90bf2070 0x1a4037b47160 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 661 0x7fbd90bf2070 0x1a4036aacee0 
[1:1:0712/144312.617468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 808 0x7fbd92b1a2e0 0x1a4036acd060 , "http://blqx.duowan.com/"
[1:1:0712/144312.618715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , /* Hiido v20161212.02*/
eval(function(E,I,A,D,J,K,L,H){function C(A){return A<62?String.fromCharCode
[1:1:0712/144312.618910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144312.764442:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144312.802604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 809 0x7fbd92b1a2e0 0x1a4036aeebe0 , "http://blqx.duowan.com/"
[1:1:0712/144312.804365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , var market_frame = null;
function market_count(adid, start, end) {
	var setcookie = function(sName
[1:1:0712/144312.804546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144312.805058:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x19f55a4229c8, 0x1a40360d9a00
[1:1:0712/144312.805169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 3000
[1:1:0712/144312.805338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 887
[1:1:0712/144312.805584:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 887 0x7fbd90bf2070 0x1a4037c6a060 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 809 0x7fbd92b1a2e0 0x1a4036aeebe0 
[1:1:0712/144312.808177:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144312.935261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 811 0x7fbd92b1a2e0 0x1a4036ad39e0 , "http://blqx.duowan.com/"
[1:1:0712/144312.935849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , !function(){function e(){var e="http://daoliang.duowan.com/index.php?r=default/sum",t=new Date,n=t.g
[1:1:0712/144312.935963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144312.946129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144312.987144:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 812 0x7fbd92b1a2e0 0x1a4036aabc60 , "http://blqx.duowan.com/"
[1:1:0712/144312.989744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , !function(e,r){function t(e){return function(r){return{}.toString.call(r)=="[object "+e+"]"}}functio
[1:1:0712/144312.990026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144313.087709:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144313.174186:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 814 0x7fbd92b1a2e0 0x1a4036725460 , "http://blqx.duowan.com/"
[1:1:0712/144313.175736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , (function(){var h={},mt={},c={id:"a23a522269c249986e4e7039f5808f80",dm:["duowan.com"],js:"tongji.bai
[1:1:0712/144313.175884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144313.290749:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9990
[1:1:0712/144313.290979:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144313.291394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 900
[1:1:0712/144313.291606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7fbd90bf2070 0x1a40370885e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 814 0x7fbd92b1a2e0 0x1a4036725460 
[1:1:0712/144313.381188:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144313.672545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144313.672889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144315.073590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144315.074337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/144315.074555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144315.082147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 850, 7fbd93537881
[1:1:0712/144315.122312:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"661 0x7fbd90bf2070 0x1a4036aacee0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144315.122643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"661 0x7fbd90bf2070 0x1a4036aacee0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144315.123039:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144315.123565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144315.123778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144315.124480:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144315.124678:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144315.125056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 959
[1:1:0712/144315.125284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7fbd90bf2070 0x1a403642e260 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 850 0x7fbd90bf2070 0x1a4037b47160 
[1:1:0712/144317.486895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 900, 7fbd93537881
[1:1:0712/144317.515352:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"814 0x7fbd92b1a2e0 0x1a4036725460 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144317.515782:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"814 0x7fbd92b1a2e0 0x1a4036725460 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144317.516241:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144317.516817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144317.517045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144317.517851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144317.518064:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144317.518445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1015
[1:1:0712/144317.518739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1015 0x7fbd90bf2070 0x1a4036d12c60 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 900 0x7fbd90bf2070 0x1a40370885e0 
[1:1:0712/144317.634387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144317.634728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144319.503253:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 959, 7fbd93537881
[1:1:0712/144319.548607:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"850 0x7fbd90bf2070 0x1a4037b47160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144319.548975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"850 0x7fbd90bf2070 0x1a4037b47160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144319.549411:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144319.550022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144319.550274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144319.550954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144319.551200:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144319.551591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1051
[1:1:0712/144319.551902:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1051 0x7fbd90bf2070 0x1a4036bdece0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 959 0x7fbd90bf2070 0x1a403642e260 
[1:1:0712/144320.243891:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 887, 7fbd93537881
[1:1:0712/144320.287862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"809 0x7fbd92b1a2e0 0x1a4036aeebe0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144320.288230:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"809 0x7fbd92b1a2e0 0x1a4036aeebe0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144320.288679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144320.289286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , listenLoaded, () {
	if (document.readyState)// IE
	{
		if (document.readyState == "loaded"
				|| document.rea
[1:1:0712/144320.289508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144320.290246:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144320.290505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 3000
[1:1:0712/144320.290870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1075
[1:1:0712/144320.291114:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1075 0x7fbd90bf2070 0x1a4038890160 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 887 0x7fbd90bf2070 0x1a4037c6a060 
[1:1:0712/144320.452181:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 993 0x7fbd92b1a2e0 0x1a4035f92d60 , "http://blqx.duowan.com/"
[1:1:0712/144320.460494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , /* @version hiido_internal.js: v2.4.1 2019-05-30 17:45:51 */
!function(){"use strict";var e="undefin
[1:1:0712/144320.460845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144320.870075:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144320.995070:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 994 0x7fbd92b1a2e0 0x1a4037c5f860 , "http://blqx.duowan.com/"
[1:1:0712/144321.001048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , define("arale/switchable/1.0.2/carousel",["./switchable","$","arale/widget/1.1.1/widget","arale/base
[1:1:0712/144321.001381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144321.020958:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144321.380765:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144321.381215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , J.onload, (){return}
[1:1:0712/144321.381330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144321.470852:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7fbd92b1a2e0 0x1a40367f1160 , "http://blqx.duowan.com/"
[1:1:0712/144321.476065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , define("arale/switchable/1.0.2/slide",["./switchable","$","arale/widget/1.1.1/widget","arale/base/1.
[1:1:0712/144321.476307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144321.499202:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144321.553833:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 999 0x7fbd92b1a2e0 0x1a4037e750e0 , "http://blqx.duowan.com/"
[1:1:0712/144321.555792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , define("arale/switchable/1.0.2/tabs",["./switchable","$","arale/widget/1.1.1/widget","arale/base/1.1
[1:1:0712/144321.555948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144321.565456:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144321.966300:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144321.966767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , g.onload, (){g.onload=t;g=window[d]=t;a&&a(b)}
[1:1:0712/144321.966887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144321.970349:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1015, 7fbd93537881
[1:1:0712/144322.019230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"900 0x7fbd90bf2070 0x1a40370885e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144322.019652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"900 0x7fbd90bf2070 0x1a40370885e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144322.020214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144322.020888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144322.021120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144322.021968:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144322.022194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144322.022619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1121
[1:1:0712/144322.022888:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1121 0x7fbd90bf2070 0x1a4038b69ce0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1015 0x7fbd90bf2070 0x1a4036d12c60 
[1:1:0712/144322.085011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144322.085274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144322.205784:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://blqx.duowan.com/"
[1:1:0712/144322.206627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , A.handle, (e){return"undefined"==typeof At||e&&At.event.triggered===e.type?void 0:At.event.dispatch.apply(k.el
[1:1:0712/144322.206882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144323.267354:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1051, 7fbd93537881
[1:1:0712/144323.283132:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"959 0x7fbd90bf2070 0x1a403642e260 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144323.283339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"959 0x7fbd90bf2070 0x1a403642e260 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144323.283539:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144323.283859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144323.283967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144323.284332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144323.284444:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144323.284612:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1143
[1:1:0712/144323.284723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1143 0x7fbd90bf2070 0x1a4036adf2e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1051 0x7fbd90bf2070 0x1a4036bdece0 
[1:1:0712/144324.343808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144324.344155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144324.348153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1121, 7fbd93537881
[1:1:0712/144324.375340:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1015 0x7fbd90bf2070 0x1a4036d12c60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144324.375558:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1015 0x7fbd90bf2070 0x1a4036d12c60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144324.375762:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144324.376072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144324.376181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144324.376853:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144324.377051:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144324.377477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1172
[1:1:0712/144324.377722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7fbd90bf2070 0x1a4038879d60 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1121 0x7fbd90bf2070 0x1a4038b69ce0 
[1:1:0712/144324.447795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144324.447982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144324.934216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1075, 7fbd93537881
[1:1:0712/144324.965275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"887 0x7fbd90bf2070 0x1a4037c6a060 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144324.965538:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"887 0x7fbd90bf2070 0x1a4037c6a060 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144324.965797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144324.966131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , listenLoaded, () {
	if (document.readyState)// IE
	{
		if (document.readyState == "loaded"
				|| document.rea
[1:1:0712/144324.966241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144324.966576:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144324.966689:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 3000
[1:1:0712/144324.966856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1184
[1:1:0712/144324.966974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7fbd90bf2070 0x1a4038ea3be0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1075 0x7fbd90bf2070 0x1a4038890160 
[1:1:0712/144325.066631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1143, 7fbd93537881
[1:1:0712/144325.083826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1051 0x7fbd90bf2070 0x1a4036bdece0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144325.084042:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1051 0x7fbd90bf2070 0x1a4036bdece0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144325.084271:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144325.084593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144325.084705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144325.085004:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144325.085111:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144325.085284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1187
[1:1:0712/144325.085396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1187 0x7fbd90bf2070 0x1a4037030be0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1143 0x7fbd90bf2070 0x1a4036adf2e0 
[1:1:0712/144325.334077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144325.334526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , d.onload, (){window[c]=null}
[1:1:0712/144325.334687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144325.394489:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1166 0x7fbd92b1a2e0 0x1a4037ff9e60 , "http://blqx.duowan.com/"
[1:1:0712/144325.403015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , define("arale/widget/1.1.1/widget",["arale/base/1.1.1/base","arale/class/1.1.0/class","arale/events/
[1:1:0712/144325.403300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144325.448225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144326.007563:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 5000
[1:1:0712/144326.008080:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1193
[1:1:0712/144326.008283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1193 0x7fbd90bf2070 0x1a4037e89ee0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1166 0x7fbd92b1a2e0 0x1a4037ff9e60 
		remove user.11_9f75be08 -> 0
		remove user.12_34c21a00 -> 0
		remove user.13_bd6c59b7 -> 0
[25842:25842:0712/144326.717328:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/144327.240734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 5000
[1:1:0712/144327.241173:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1195
[1:1:0712/144327.241373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7fbd90bf2070 0x1a4039519d60 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1166 0x7fbd92b1a2e0 0x1a4037ff9e60 
[1:1:0712/144327.949421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144327.949628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144327.950926:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1172, 7fbd93537881
[1:1:0712/144327.987921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1121 0x7fbd90bf2070 0x1a4038b69ce0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144327.988270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1121 0x7fbd90bf2070 0x1a4038b69ce0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144327.988644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144327.989338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144327.989606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144327.990334:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144327.990509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144327.990819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1201
[1:1:0712/144327.991007:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1201 0x7fbd90bf2070 0x1a4038895fe0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1172 0x7fbd90bf2070 0x1a4038879d60 
[1:1:0712/144328.024267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144328.024459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144328.421028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1187, 7fbd93537881
[1:1:0712/144328.448592:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1143 0x7fbd90bf2070 0x1a4036adf2e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144328.448799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1143 0x7fbd90bf2070 0x1a4036adf2e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144328.449003:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144328.449336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144328.449452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144328.449758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144328.449860:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144328.450039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1212
[1:1:0712/144328.450155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1212 0x7fbd90bf2070 0x1a403893a660 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1187 0x7fbd90bf2070 0x1a4037030be0 
[1:1:0712/144328.808490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144328.808750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144328.810588:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1184, 7fbd93537881
[1:1:0712/144328.854222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1075 0x7fbd90bf2070 0x1a4038890160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144328.854535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1075 0x7fbd90bf2070 0x1a4038890160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144328.854865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144328.855321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , listenLoaded, () {
	if (document.readyState)// IE
	{
		if (document.readyState == "loaded"
				|| document.rea
[1:1:0712/144328.855519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144328.855955:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144328.856101:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 3000
[1:1:0712/144328.856363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1220
[1:1:0712/144328.856571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1220 0x7fbd90bf2070 0x1a40371739e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1184 0x7fbd90bf2070 0x1a4038ea3be0 
[1:1:0712/144328.894125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144328.894308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144328.939108:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1201, 7fbd93537881
[1:1:0712/144329.000023:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1172 0x7fbd90bf2070 0x1a4038879d60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.000448:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1172 0x7fbd90bf2070 0x1a4038879d60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.000918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144329.001592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144329.001848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.002664:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144329.002873:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144329.003258:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1225
[1:1:0712/144329.003521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1225 0x7fbd90bf2070 0x1a4038c96be0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1201 0x7fbd90bf2070 0x1a4038895fe0 
[1:1:0712/144329.105619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1212, 7fbd93537881
[1:1:0712/144329.122898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1187 0x7fbd90bf2070 0x1a4037030be0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.123108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1187 0x7fbd90bf2070 0x1a4037030be0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.123339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144329.123729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144329.123870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.124199:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144329.124312:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144329.124522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1230
[1:1:0712/144329.124644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1230 0x7fbd90bf2070 0x1a40399e80e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1212 0x7fbd90bf2070 0x1a403893a660 
[1:1:0712/144329.169095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144329.169342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.274738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144329.275001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.479808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1225, 7fbd93537881
[1:1:0712/144329.539052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1201 0x7fbd90bf2070 0x1a4038895fe0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.539371:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1201 0x7fbd90bf2070 0x1a4038895fe0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.539808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144329.540464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144329.540712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.541529:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144329.541752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144329.542158:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1243
[1:1:0712/144329.542404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1243 0x7fbd90bf2070 0x1a4037c80fe0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1225 0x7fbd90bf2070 0x1a4038c96be0 
[1:1:0712/144329.591668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144329.591875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.748900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144329.749162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.754206:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1230, 7fbd93537881
[1:1:0712/144329.792544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1212 0x7fbd90bf2070 0x1a403893a660 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.792807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1212 0x7fbd90bf2070 0x1a403893a660 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144329.793045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144329.793363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144329.793475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.793819:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144329.793931:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144329.794103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1250
[1:1:0712/144329.794215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1250 0x7fbd90bf2070 0x1a40390afa60 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1230 0x7fbd90bf2070 0x1a40399e80e0 
[1:1:0712/144329.955731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , document.readyState
[1:1:0712/144329.956003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144329.959264:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1243, 7fbd93537881
[1:1:0712/144330.003666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1225 0x7fbd90bf2070 0x1a4038c96be0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144330.004097:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1225 0x7fbd90bf2070 0x1a4038c96be0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144330.004570:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144330.005241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144330.005483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144330.006308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144330.006513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144330.006941:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1261
[1:1:0712/144330.007189:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1261 0x7fbd90bf2070 0x1a4037ff9460 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1243 0x7fbd90bf2070 0x1a4037c80fe0 
[1:1:0712/144330.136984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144330.137308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144330.434297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1256 0x7fbd92b1a2e0 0x1a4036d48c60 , "http://blqx.duowan.com/"
[1:1:0712/144330.435953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , jsonpStore({"day":[{"name":"\u6447\u6eda","price":"800","rarity":"epic","img_src":"https:\/\/image.f
[1:1:0712/144330.436220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144330.438488:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[25842:25842:0712/144330.475398:INFO:CONSOLE(194)] "Uncaught TypeError: Cannot read property 'children' of undefined", source: http://pub.dwstatic.com/zq2018/fortnight//js/_index_d8ae235.js?0314 (194)
[1:1:0712/144330.557476:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1250, 7fbd93537881
[1:1:0712/144330.574576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1230 0x7fbd90bf2070 0x1a40399e80e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144330.574777:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1230 0x7fbd90bf2070 0x1a40399e80e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144330.575103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144330.575405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144330.575509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144330.575799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144330.575941:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144330.576109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1274
[1:1:0712/144330.576219:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1274 0x7fbd90bf2070 0x1a40399e5ae0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1250 0x7fbd90bf2070 0x1a40390afa60 
[1:1:0712/144330.633005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144330.633643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/144330.633820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144330.634564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144330.644325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144330.658687:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144330.659637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[25842:25842:0712/144330.671755:INFO:CONSOLE(2)] "没有采集到fmp数据", source: http://hdjs.hiido.com/hiido_internal.js?siteid=blqx@duowan (2)
[1:1:0712/144330.700340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://blqx.duowan.com/"
[1:1:0712/144330.702120:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9af0
[1:1:0712/144330.702342:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144330.702747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1277
[1:1:0712/144330.703019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1277 0x7fbd90bf2070 0x1a4039a836e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1260 0x7fbda727c080 0x1a4039a71100 1 0 0x1a4039a71118 
[1:1:0712/144330.703529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://blqx.duowan.com/"
[1:1:0712/144330.704566:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d99f0
[1:1:0712/144330.704783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144330.705358:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1279
[1:1:0712/144330.705604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1279 0x7fbd90bf2070 0x1a40399e5760 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1260 0x7fbda727c080 0x1a4039a71100 1 0 0x1a4039a71118 
[1:1:0712/144330.774027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144330.774353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144331.447745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1277, 7fbd93537881
[1:1:0712/144331.503302:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1260 0x7fbda727c080 0x1a4039a71100 1 0 0x1a4039a71118 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144331.503663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1260 0x7fbda727c080 0x1a4039a71100 1 0 0x1a4039a71118 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144331.504088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144331.504416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144331.504526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144331.504832:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144331.504932:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144331.505133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1307
[1:1:0712/144331.505255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1307 0x7fbd90bf2070 0x1a403963aae0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1277 0x7fbd90bf2070 0x1a4039a836e0 
[1:1:0712/144331.505852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1279, 7fbd93537881
[1:1:0712/144331.524012:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1260 0x7fbda727c080 0x1a4039a71100 1 0 0x1a4039a71118 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144331.524270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1260 0x7fbda727c080 0x1a4039a71100 1 0 0x1a4039a71118 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144331.524502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144331.524838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144331.524985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144331.525329:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144331.525434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144331.525601:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1309
[1:1:0712/144331.525712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1309 0x7fbd90bf2070 0x1a4039040360 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1279 0x7fbd90bf2070 0x1a40399e5760 
[1:1:0712/144331.545855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144331.546049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144331.784376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1193, 7fbd935378db
[1:1:0712/144331.838651:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1166 0x7fbd92b1a2e0 0x1a4037ff9e60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144331.838992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1166 0x7fbd92b1a2e0 0x1a4037ff9e60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144331.839446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1317
[1:1:0712/144331.839646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1317 0x7fbd90bf2070 0x1a4037ff7ee0 , 5:3_http://blqx.duowan.com/, 0, , 1193 0x7fbd90bf2070 0x1a4037e89ee0 
[1:1:0712/144331.839960:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144331.840583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , (){h.paused||h.next()}
[1:1:0712/144331.840830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.127818:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://blqx.duowan.com/"
[1:1:0712/144332.128677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , d.onload, (){window[c]=null}
[1:1:0712/144332.128917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.296715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144332.296918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.298838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1307, 7fbd93537881
[1:1:0712/144332.317397:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1277 0x7fbd90bf2070 0x1a4039a836e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.317611:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1277 0x7fbd90bf2070 0x1a4039a836e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.317857:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144332.318182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144332.318318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.318635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144332.318737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144332.318909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1332
[1:1:0712/144332.319020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1332 0x7fbd90bf2070 0x1a4039ae1160 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1307 0x7fbd90bf2070 0x1a403963aae0 
[1:1:0712/144332.319547:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1309, 7fbd93537881
[1:1:0712/144332.337465:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1279 0x7fbd90bf2070 0x1a40399e5760 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.337660:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1279 0x7fbd90bf2070 0x1a40399e5760 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.337915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144332.338218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144332.338348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.338645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144332.338747:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144332.338917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1333
[1:1:0712/144332.339030:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1333 0x7fbd90bf2070 0x1a4039adb160 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1309 0x7fbd90bf2070 0x1a4039040360 
[1:1:0712/144332.396160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1220, 7fbd93537881
[1:1:0712/144332.429394:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1184 0x7fbd90bf2070 0x1a4038ea3be0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.429715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1184 0x7fbd90bf2070 0x1a4038ea3be0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.430060:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144332.430565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , listenLoaded, () {
	if (document.readyState)// IE
	{
		if (document.readyState == "loaded"
				|| document.rea
[1:1:0712/144332.430800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.471585:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1195, 7fbd935378db
[1:1:0712/144332.489626:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1166 0x7fbd92b1a2e0 0x1a4037ff9e60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.489846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1166 0x7fbd92b1a2e0 0x1a4037ff9e60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.490108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1336
[1:1:0712/144332.490230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1336 0x7fbd90bf2070 0x1a4038fe90e0 , 5:3_http://blqx.duowan.com/, 0, , 1195 0x7fbd90bf2070 0x1a4039519d60 
[1:1:0712/144332.490435:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144332.490750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , (){h.paused||h.next()}
[1:1:0712/144332.490864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.565625:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144332.565927:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 0
[1:1:0712/144332.566359:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1337
[1:1:0712/144332.566616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1337 0x7fbd90bf2070 0x1a40398907e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1195 0x7fbd90bf2070 0x1a4039519d60 
[1:1:0712/144332.606502:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 13
[1:1:0712/144332.606944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1338
[1:1:0712/144332.607202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7fbd90bf2070 0x1a4039041560 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1195 0x7fbd90bf2070 0x1a4039519d60 
[1:1:0712/144332.762332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144332.762606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.840667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1332, 7fbd93537881
[1:1:0712/144332.898056:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1307 0x7fbd90bf2070 0x1a403963aae0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.898404:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1307 0x7fbd90bf2070 0x1a403963aae0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.898827:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144332.899462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144332.899669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.900315:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144332.900525:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144332.900848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1351
[1:1:0712/144332.901042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1351 0x7fbd90bf2070 0x1a4038bdcae0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1332 0x7fbd90bf2070 0x1a4039ae1160 
[1:1:0712/144332.943391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1333, 7fbd93537881
[1:1:0712/144332.984386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1309 0x7fbd90bf2070 0x1a4039040360 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.984622:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1309 0x7fbd90bf2070 0x1a4039040360 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144332.984860:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144332.985169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144332.985277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144332.985609:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144332.985712:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144332.985878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1353
[1:1:0712/144332.985986:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7fbd90bf2070 0x1a4039042060 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1333 0x7fbd90bf2070 0x1a4039adb160 
[1:1:0712/144332.986495:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1337, 7fbd93537881
[1:1:0712/144333.005251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1195 0x7fbd90bf2070 0x1a4039519d60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.005486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1195 0x7fbd90bf2070 0x1a4039519d60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.005724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144333.006019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , , (){Rn=void 0}
[1:1:0712/144333.006124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.026024:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1338, 7fbd935378db
[1:1:0712/144333.044954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1195 0x7fbd90bf2070 0x1a4039519d60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.045186:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1195 0x7fbd90bf2070 0x1a4039519d60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.045502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1356
[1:1:0712/144333.045699:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1356 0x7fbd90bf2070 0x1a4039bcdce0 , 5:3_http://blqx.duowan.com/, 0, , 1338 0x7fbd90bf2070 0x1a4039041560 
[1:1:0712/144333.046016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144333.046375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , At.fx.tick, (){var a,c=At.timers,i=0;for(Rn=At.now();i<c.length;i++)a=c[i],a()||c[i]!==a||c.splice(i--,1);c.leng
[1:1:0712/144333.046501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.113274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144333.113568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.434787:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1351, 7fbd93537881
[1:1:0712/144333.453476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1332 0x7fbd90bf2070 0x1a4039ae1160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.453699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1332 0x7fbd90bf2070 0x1a4039ae1160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.453933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144333.454247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144333.454366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.454710:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144333.454815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144333.454980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1367
[1:1:0712/144333.455088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1367 0x7fbd90bf2070 0x1a4039bc76e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1351 0x7fbd90bf2070 0x1a4038bdcae0 
[1:1:0712/144333.455609:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1356, 7fbd935378db
[1:1:0712/144333.474848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1338 0x7fbd90bf2070 0x1a4039041560 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.475051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1338 0x7fbd90bf2070 0x1a4039041560 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.475317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://blqx.duowan.com/, 1369
[1:1:0712/144333.475438:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1369 0x7fbd90bf2070 0x1a40388e8fe0 , 5:3_http://blqx.duowan.com/, 0, , 1356 0x7fbd90bf2070 0x1a4039bcdce0 
[1:1:0712/144333.475658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144333.475964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , At.fx.tick, (){var a,c=At.timers,i=0;for(Rn=At.now();i<c.length;i++)a=c[i],a()||c[i]!==a||c.splice(i--,1);c.leng
[1:1:0712/144333.476071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.501940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144333.502131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.622955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1353, 7fbd93537881
[1:1:0712/144333.650682:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1333 0x7fbd90bf2070 0x1a4039adb160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.650900:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1333 0x7fbd90bf2070 0x1a4039adb160 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.651133:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144333.651445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144333.651566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.651907:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144333.652007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144333.652178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1375
[1:1:0712/144333.652296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1375 0x7fbd90bf2070 0x1a4039be9e60 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1353 0x7fbd90bf2070 0x1a4039042060 
[1:1:0712/144333.774157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144333.774360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.874885:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1367, 7fbd93537881
[1:1:0712/144333.893561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1351 0x7fbd90bf2070 0x1a4038bdcae0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.893801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1351 0x7fbd90bf2070 0x1a4038bdcae0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.894051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144333.894368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144333.894476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.894865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144333.894973:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144333.895156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1379
[1:1:0712/144333.895267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1379 0x7fbd90bf2070 0x1a4039aedce0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1367 0x7fbd90bf2070 0x1a4039bc76e0 
[1:1:0712/144333.895765:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1375, 7fbd93537881
[1:1:0712/144333.920590:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1353 0x7fbd90bf2070 0x1a4039042060 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.920868:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1353 0x7fbd90bf2070 0x1a4039042060 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144333.921091:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144333.921404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144333.921512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.922119:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144333.922328:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144333.922737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1380
[1:1:0712/144333.922973:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1380 0x7fbd90bf2070 0x1a4039adae60 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1375 0x7fbd90bf2070 0x1a4039be9e60 
[1:1:0712/144333.959321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144333.959583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144333.984953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144333.985150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.030428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144334.030620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.032292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1379, 7fbd93537881
[1:1:0712/144334.063071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1367 0x7fbd90bf2070 0x1a4039bc76e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.063409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1367 0x7fbd90bf2070 0x1a4039bc76e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.063853:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144334.064392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144334.064585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.065247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144334.065419:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144334.065798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1386
[1:1:0712/144334.066019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1386 0x7fbd90bf2070 0x1a4038c97360 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1379 0x7fbd90bf2070 0x1a4039aedce0 
[1:1:0712/144334.123785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144334.124057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.126772:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1380, 7fbd93537881
[1:1:0712/144334.156228:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1375 0x7fbd90bf2070 0x1a4039be9e60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.156453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1375 0x7fbd90bf2070 0x1a4039be9e60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.156700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144334.157054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144334.157168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.157480:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144334.157585:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144334.157823:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1389
[1:1:0712/144334.157957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1389 0x7fbd90bf2070 0x1a40380476e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1380 0x7fbd90bf2070 0x1a4039adae60 
[1:1:0712/144334.197531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144334.197733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.199334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1386, 7fbd93537881
[1:1:0712/144334.230327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1379 0x7fbd90bf2070 0x1a4039aedce0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.230650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1379 0x7fbd90bf2070 0x1a4039aedce0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.231051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144334.231572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144334.231799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.232443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144334.232603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144334.232944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1392
[1:1:0712/144334.233142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1392 0x7fbd90bf2070 0x1a4039c496e0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1386 0x7fbd90bf2070 0x1a4038c97360 
[1:1:0712/144334.292627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144334.292914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.355523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144334.355829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.418165:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1389, 7fbd93537881
[1:1:0712/144334.475545:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1380 0x7fbd90bf2070 0x1a4039adae60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.475958:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1380 0x7fbd90bf2070 0x1a4039adae60 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.476360:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144334.476907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144334.477093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.477738:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144334.477926:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144334.478254:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1399
[1:1:0712/144334.478450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1399 0x7fbd90bf2070 0x1a4039aedce0 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1389 0x7fbd90bf2070 0x1a40380476e0 
[1:1:0712/144334.538170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144334.538431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.542978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1392, 7fbd93537881
[1:1:0712/144334.606009:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1386 0x7fbd90bf2070 0x1a4038c97360 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.606356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1386 0x7fbd90bf2070 0x1a4038c97360 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.606745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144334.607289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/144334.607470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.608150:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144334.608338:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144334.608662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1404
[1:1:0712/144334.608906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1404 0x7fbd90bf2070 0x1a4039ada960 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1392 0x7fbd90bf2070 0x1a4039c496e0 
[1:1:0712/144334.725073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/144334.725347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.729375:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1399, 7fbd93537881
[1:1:0712/144334.789437:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d9c46d42860","ptid":"1389 0x7fbd90bf2070 0x1a40380476e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.789784:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://blqx.duowan.com/","ptid":"1389 0x7fbd90bf2070 0x1a40380476e0 ","rf":"5:3_http://blqx.duowan.com/"}
[1:1:0712/144334.790211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://blqx.duowan.com/"
[1:1:0712/144334.790738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://blqx.duowan.com/, 3d9c46d42860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/144334.790936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://blqx.duowan.com/", "blqx.duowan.com", 3, 1, , , 0
[1:1:0712/144334.791580:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x19f55a4229c8, 0x1a40360d9950
[1:1:0712/144334.791739:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://blqx.duowan.com/", 100
[1:1:0712/144334.792115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://blqx.duowan.com/, 1412
[1:1:0712/144334.792312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1412 0x7fbd90bf2070 0x1a4039bd4960 , 5:3_http://blqx.duowan.com/, 1, -5:3_http://blqx.duowan.com/, 1399 0x7fbd90bf2070 0x1a4039aedce0 
