[0712/143123.182897:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143123.183313:INFO:switcher_clone.cc(787)] backtrace rip is 7f1750198891
[0712/143124.144817:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143124.145130:INFO:switcher_clone.cc(787)] backtrace rip is 7fb0a8b85891
[1:1:0712/143124.155028:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/143124.155242:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/143124.159737:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[24593:24593:0712/143125.433305:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/baad3967-5f2b-4401-b2d4-384b5f77726e
[0712/143125.594777:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143125.595182:INFO:switcher_clone.cc(787)] backtrace rip is 7f20e77ef891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[24627:24627:0712/143125.828206:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=24627
[24638:24638:0712/143125.828710:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=24638
[24593:24593:0712/143125.904186:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[24593:24623:0712/143125.905123:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/143125.905385:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/143125.905607:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/143125.906182:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/143125.906355:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/143125.909625:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36a80126, 1
[1:1:0712/143125.909974:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x135a843c, 0
[1:1:0712/143125.910172:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2cedba31, 3
[1:1:0712/143125.910385:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x300b2014, 2
[1:1:0712/143125.910639:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3cffffff845a13 2601ffffffa836 14200b30 31ffffffbaffffffed2c , 10104, 4
[1:1:0712/143125.911705:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[24593:24623:0712/143125.911974:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING<�Z&�6 01��,�4�
[24593:24623:0712/143125.912040:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is <�Z&�6 01��,8^�4�
[1:1:0712/143125.912149:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb0a6dc00a0, 3
[24593:24623:0712/143125.912379:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[24593:24623:0712/143125.912420:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 24646, 4, 3c845a13 2601a836 14200b30 31baed2c 
[1:1:0712/143125.912361:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb0a6f4b080, 2
[1:1:0712/143125.912512:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb090c0ed20, -2
[1:1:0712/143125.931681:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/143125.932808:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 300b2014
[1:1:0712/143125.934059:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 300b2014
[1:1:0712/143125.936060:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 300b2014
[1:1:0712/143125.937948:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.938183:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.938435:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.938680:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.939480:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 300b2014
[1:1:0712/143125.939904:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb0a8b857ba
[1:1:0712/143125.940083:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb0a8b7cdef, 7fb0a8b8577a, 7fb0a8b870cf
[1:1:0712/143125.947360:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 300b2014
[1:1:0712/143125.947806:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 300b2014
[1:1:0712/143125.948742:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 300b2014
[1:1:0712/143125.951349:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.951620:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.951853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.952401:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 300b2014
[1:1:0712/143125.953983:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 300b2014
[1:1:0712/143125.954455:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb0a8b857ba
[1:1:0712/143125.954629:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb0a8b7cdef, 7fb0a8b8577a, 7fb0a8b870cf
[1:1:0712/143125.964463:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/143125.965005:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/143125.965212:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc3694cc28, 0x7ffc3694cba8)
[1:1:0712/143125.982559:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/143125.988697:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[24593:24593:0712/143126.547650:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[24593:24593:0712/143126.549077:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[24593:24605:0712/143126.573395:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[24593:24605:0712/143126.573531:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[24593:24593:0712/143126.573742:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[24593:24593:0712/143126.573844:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[24593:24593:0712/143126.574020:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,24646, 4
[1:7:0712/143126.576145:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[24593:24618:0712/143126.670268:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/143126.679210:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x20227c2dc220
[1:1:0712/143126.680017:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/143126.973721:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/143128.760520:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143128.765191:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[24593:24593:0712/143128.856826:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[24593:24593:0712/143128.856940:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/143130.038228:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143130.300628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3307dd4c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/143130.300891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143130.317059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3307dd4c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/143130.317302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143130.438745:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143130.438912:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143130.895893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143130.905113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3307dd4c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/143130.905350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143130.941932:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143130.953011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3307dd4c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/143130.953256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143130.966342:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[24593:24593:0712/143130.971474:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/143130.970791:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x20227c2dae20
[1:1:0712/143130.972563:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[24593:24593:0712/143130.991516:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[24593:24593:0712/143131.031361:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[24593:24593:0712/143131.031463:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/143131.054156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143131.674097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fb0927e92e0 0x20227c4a4ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143131.674884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3307dd4c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/143131.675547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143131.677137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[24593:24593:0712/143131.726403:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/143131.728855:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x20227c2db820
[1:1:0712/143131.729068:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[24593:24593:0712/143131.737367:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/143131.748670:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/143131.748896:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[24593:24593:0712/143131.760581:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[24593:24593:0712/143131.774447:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[24593:24593:0712/143131.775801:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[24593:24605:0712/143131.783290:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[24593:24605:0712/143131.783385:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[24593:24593:0712/143131.783656:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[24593:24593:0712/143131.783792:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[24593:24593:0712/143131.783976:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,24646, 4
[1:7:0712/143131.789594:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143132.174714:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/143132.776437:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7fb0927e92e0 0x20227c4a2160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143132.777058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3307dd4c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/143132.777186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143132.777521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[24593:24593:0712/143132.818069:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[24593:24593:0712/143132.818184:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/143132.848881:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143133.121405:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[24593:24593:0712/143133.297964:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[24593:24623:0712/143133.298427:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/143133.298645:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/143133.298870:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/143133.299362:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/143133.299549:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/143133.303273:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3aafaabe, 1
[1:1:0712/143133.303647:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x10f1aaa8, 0
[1:1:0712/143133.303803:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x15c0614c, 3
[1:1:0712/143133.303947:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x6935cdd, 2
[1:1:0712/143133.304156:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa8ffffffaafffffff110 ffffffbeffffffaaffffffaf3a ffffffdd5cffffff9306 4c61ffffffc015 , 10104, 5
[1:1:0712/143133.305223:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[24593:24623:0712/143133.305408:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING������:�\�La��7�
[24593:24623:0712/143133.305489:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ������:�\�La�8W�7�
[24593:24623:0712/143133.305919:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 24691, 5, a8aaf110 beaaaf3a dd5c9306 4c61c015 
[1:1:0712/143133.305624:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb0a6dc00a0, 3
[1:1:0712/143133.306384:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb0a6f4b080, 2
[1:1:0712/143133.306641:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb090c0ed20, -2
[1:1:0712/143133.324520:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/143133.324839:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6935cdd
[1:1:0712/143133.325213:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6935cdd
[1:1:0712/143133.325944:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6935cdd
[1:1:0712/143133.327340:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.327564:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.327746:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.327916:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.328556:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6935cdd
[1:1:0712/143133.328844:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb0a8b857ba
[1:1:0712/143133.328977:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb0a8b7cdef, 7fb0a8b8577a, 7fb0a8b870cf
[1:1:0712/143133.335603:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6935cdd
[1:1:0712/143133.335949:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6935cdd
[1:1:0712/143133.336682:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6935cdd
[1:1:0712/143133.338612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.338828:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.339014:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.339219:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6935cdd
[1:1:0712/143133.340403:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6935cdd
[1:1:0712/143133.340752:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb0a8b857ba
[1:1:0712/143133.340879:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb0a8b7cdef, 7fb0a8b8577a, 7fb0a8b870cf
[1:1:0712/143133.348702:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/143133.349758:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/143133.349930:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc3694cc28, 0x7ffc3694cba8)
[1:1:0712/143133.366643:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/143133.371878:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/143133.615935:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x20227c2a0220
[1:1:0712/143133.616229:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/143133.629483:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143133.629806:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[24593:24593:0712/143133.996723:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[24593:24593:0712/143134.003732:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[24593:24605:0712/143134.016496:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[24593:24605:0712/143134.016628:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[24593:24593:0712/143134.017850:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://news.duowan.com/
[24593:24593:0712/143134.017945:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://news.duowan.com/, http://news.duowan.com/1907/426683510504.html, 1
[24593:24593:0712/143134.018113:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://news.duowan.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 21:31:33 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 21:36:33 GMT Cache-Control: max-age=300 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,24691, 5
[1:7:0712/143134.024120:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143134.064884:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://news.duowan.com/
[24593:24593:0712/143134.209664:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://news.duowan.com/, http://news.duowan.com/, 1
[24593:24593:0712/143134.209808:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://news.duowan.com/, http://news.duowan.com
[1:1:0712/143134.233846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/143134.238397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3307dd5ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/143134.238719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/143134.246653:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/143134.250397:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143134.366028:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143134.440200:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143134.440434:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143134.480611:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 120 0x7fb0908c1070 0x20227c2e2e60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143134.483673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , 
        if (/Android|webOS|iPhone|Windows Phone|iPod|BlackBerry|SymbianOS/i.test(window.navigator.u
[1:1:0712/143134.483927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143134.498613:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143134.499344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3307dd4c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/143134.499604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143134.664017:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143134.878636:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 153 0x7fb090c29bd0 0x20227c3bd558 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143134.890269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(a,c){"object"==typeof module&&"object"==typeof module.exports?module.exports=a.document?c(
[1:1:0712/143134.890605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143134.917926:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_37e8e5b9 -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/143135.407905:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 153 0x7fb090c29bd0 0x20227c3bd558 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143135.419432:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.251544, 146, 1
[1:1:0712/143135.419744:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143135.600522:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143135.601141:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143135.601616:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143135.602148:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143135.602704:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143135.956670:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143135.956967:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143135.963896:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7fb0908c1070 0x20227c4f2be0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143135.968484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(window,$){function parseCookieString(i,n){var o={};if(isString(i)&&i.length>0)for(var t,e,
[1:1:0712/143135.968798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143136.054833:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7fb0908c1070 0x20227c4f2be0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143137.197288:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.24019, 0, 0
[1:1:0712/143137.197567:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143138.104473:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143138.104694:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143138.132165:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.027354, 146, 1
[1:1:0712/143138.132394:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143138.495552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7fb0927e92e0 0x20227c81b1e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143138.498951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(a){var b=a;String.prototype.startsWith=function(a){var b=new RegExp("^"+a);return b.test(t
[1:1:0712/143138.499222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143138.528121:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143138.752956:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143138.753257:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143138.754248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 296 0x7fb0908c1070 0x20227c6ed0e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143138.755326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , var comment3Uniqid = '41e70091c260b9c2b181e94bc0d527b8';
[1:1:0712/143138.755591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143138.761630:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 296 0x7fb0908c1070 0x20227c6ed0e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143138.777922:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 296 0x7fb0908c1070 0x20227c6ed0e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143138.837712:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.084249, 321, 1
[1:1:0712/143138.837970:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143139.466679:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143139.466843:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143139.468225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7fb0908c1070 0x20227c7ede60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143139.469420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(){var scripts=document.getElementsByTagName("script"),src=scripts[scripts.length-1].src,ar
[1:1:0712/143139.469539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143139.522238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7fb0908c1070 0x20227c7ede60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143139.528161:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7fb0908c1070 0x20227c7ede60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143139.536393:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7fb0908c1070 0x20227c7ede60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143139.539787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7fb0908c1070 0x20227c7ede60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143139.545028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143141.305022:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
		remove user.10_c0dfc46 -> 0
		remove user.11_c983d8f3 -> 0
		remove user.12_d97775ec -> 0
		remove user.13_acc90aba -> 0
		remove user.14_bdd70626 -> 0
[1:1:0712/143141.323913:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x20227cc53820
[1:1:0712/143141.324210:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/143141.373481:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/143141.374212:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/143141.383573:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x20227cc52e20
[1:1:0712/143141.383779:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/143141.436279:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x20227ca43020
[1:1:0712/143141.436506:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0712/143141.737817:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 349 0x7fb0927e92e0 0x20227c57d6e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143141.741920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(e,r){function t(e){return function(r){return{}.toString.call(r)=="[object "+e+"]"}}functio
[1:1:0712/143141.742211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143141.780727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143142.671529:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7fb0927e92e0 0x20227c4f5860 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143142.672255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(){var a=document.getElementsByTagName("script"),c=a[a.length-1].src,e=-1!==c.indexOf("?")?
[1:1:0712/143142.672415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143142.688721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143142.734879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 441 0x7fb0927e92e0 0x20227c81c460 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143142.737165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (function(win, doc) {
    var md5=window.md5||{};!function(){function r(r){return C(t(A(r),r.length
[1:1:0712/143142.737334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143142.918927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143142.968113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7fb0927e92e0 0x20227bea36e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143142.969400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/143142.969614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143142.999258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 445 0x7fb0927e92e0 0x20227beac8e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143143.000406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/143143.000661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143143.050785:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f1c0
[1:1:0712/143143.050980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143143.051173:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 495
[1:1:0712/143143.051293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7fb0908c1070 0x20227c3a6060 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 445 0x7fb0927e92e0 0x20227beac8e0 
[1:1:0712/143143.058138:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f1c0
[1:1:0712/143143.058335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143143.058630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 497
[1:1:0712/143143.058791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 497 0x7fb0908c1070 0x20227bed2360 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 445 0x7fb0927e92e0 0x20227beac8e0 
[1:1:0712/143143.061969:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x12fc2df229c8, 0x20227c12f1c0
[1:1:0712/143143.062119:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 3000
[1:1:0712/143143.062361:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 498
[1:1:0712/143143.062626:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7fb0908c1070 0x20227c3bb9e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 445 0x7fb0927e92e0 0x20227beac8e0 
[1:1:0712/143143.143210:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7fb0927e92e0 0x20227beb4be0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143143.154339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (function(){var h={},mt={},c={id:"f8c344878782e7ee9b1e01e1870c6c6b",dm:["news.duowan.com","news.duow
[1:1:0712/143143.154667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143143.183196:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f140
[1:1:0712/143143.183384:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143143.183599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 507
[1:1:0712/143143.183715:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 507 0x7fb0908c1070 0x20227c6edd60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 447 0x7fb0927e92e0 0x20227beb4be0 
[24593:24593:0712/143205.430145:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[24593:24593:0712/143205.432167:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[24593:24593:0712/143205.437749:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://news.duowan.com/, http://news.duowan.com/, 4
[24593:24593:0712/143205.437828:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://news.duowan.com/, http://news.duowan.com
[24593:24593:0712/143205.475188:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[24593:24593:0712/143205.479539:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[24593:24593:0712/143205.484967:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://news.duowan.com/, http://news.duowan.com/, 5
[24593:24593:0712/143205.485062:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://news.duowan.com/, http://news.duowan.com
[24593:24593:0712/143205.493172:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[24593:24593:0712/143205.495131:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[24593:24593:0712/143205.500331:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://news.duowan.com/, http://news.duowan.com/, 6
[24593:24593:0712/143205.500394:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://news.duowan.com/, http://news.duowan.com
[24593:24593:0712/143205.534185:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/143205.574849:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[24593:24593:0712/143205.654479:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[24593:24593:0712/143205.721917:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/143205.728933:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[24593:24593:0712/143205.730147:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/143205.784992:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7fb0927e92e0 0x20227c3a7be0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143205.785781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , seajs.config({moduleVersion:[["p/comment","20180121903"]]}),define("p/comment/main",["jquery","./m/u
[1:1:0712/143205.785900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143205.788232:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143207.465298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/143207.465590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143209.233433:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 507, 7fb093206881
[1:1:0712/143209.261046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"447 0x7fb0927e92e0 0x20227beb4be0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.261365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"447 0x7fb0927e92e0 0x20227beb4be0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.261738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143209.262350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143209.262530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143209.263333:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143209.263504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143209.264003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 666
[1:1:0712/143209.264198:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7fb0908c1070 0x20227d3a8d60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 507 0x7fb0908c1070 0x20227c6edd60 
[1:1:0712/143209.265731:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 498, 7fb093206881
[1:1:0712/143209.293537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"445 0x7fb0927e92e0 0x20227beac8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.293827:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"445 0x7fb0927e92e0 0x20227beac8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.294221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143209.294780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0712/143209.294971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143209.301222:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143209.301395:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143209.301585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 667
[1:1:0712/143209.301697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7fb0908c1070 0x20227d3a4660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 498 0x7fb0908c1070 0x20227c3bb9e0 
[1:1:0712/143209.323551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 495, 7fb093206881
[1:1:0712/143209.337244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"445 0x7fb0927e92e0 0x20227beac8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.337450:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"445 0x7fb0927e92e0 0x20227beac8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.337671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143209.338016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){throw new Error("load "+n+" timeout : "+t)}
[1:1:0712/143209.338126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[24593:24593:0712/143209.340537:INFO:CONSOLE(1)] "Uncaught Error: load js timeout : http://bdimg.share.baidu.com/static/api/js/share/share_api.js?v=226108fe.js", source: http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=434156 (1)
[1:1:0712/143209.358324:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 497, 7fb093206881
[1:1:0712/143209.386196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"445 0x7fb0927e92e0 0x20227beac8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.386506:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"445 0x7fb0927e92e0 0x20227beac8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143209.386872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143209.387483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){throw new Error("load "+n+" timeout : "+t)}
[1:1:0712/143209.387657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[24593:24593:0712/143209.392844:INFO:CONSOLE(1)] "Uncaught Error: load js timeout : http://bdimg.share.baidu.com/static/api/js/view/share_view.js?v=3ae6026d.js", source: http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=434156 (1)
[1:1:0712/143210.077920:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7fb0927e92e0 0x20227cc572e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.078557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , /* Hiido v20161212.02*/
eval(function(E,I,A,D,J,K,L,H){function C(A){return A<62?String.fromCharCode
[1:1:0712/143210.078682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143210.199889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.244677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 620 0x7fb0927e92e0 0x20227cf60ce0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.246184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , var market_frame = null;
function market_count(adid, start, end) {
	var setcookie = function(sName
[1:1:0712/143210.246370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143210.247632:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x12fc2df229c8, 0x20227c12f200
[1:1:0712/143210.247861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 3000
[1:1:0712/143210.248371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 701
[1:1:0712/143210.248617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7fb0908c1070 0x20227c368160 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 620 0x7fb0927e92e0 0x20227cf60ce0 
[1:1:0712/143210.251269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.322268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 622 0x7fb0927e92e0 0x20227c1481e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.323406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(){function e(){var e="http://daoliang.duowan.com/index.php?r=default/sum",t=new Date,n=t.g
[1:1:0712/143210.323592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143210.338337:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.373641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 623 0x7fb0927e92e0 0x20227c3a6160 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.384021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (function(){var h={},mt={},c={id:"f65018eb01bd372e3bb369b484f6d866",dm:["cms.duowan.com"],js:"tongji
[1:1:0712/143210.384304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143210.407982:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f140
[1:1:0712/143210.408235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143210.408633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 704
[1:1:0712/143210.408823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 704 0x7fb0908c1070 0x20227d37d6e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 623 0x7fb0927e92e0 0x20227c3a6160 
[1:1:0712/143210.556031:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 627 0x7fb0927e92e0 0x20227d196060 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.557441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , jQuery112102995032508437785_1562967095079({"headpic1":{"title":"\u533b\u9662\u5f00\u8bbe\u9752\u5c11
[1:1:0712/143210.557769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143210.559666:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.578952:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 628 0x7fb0927e92e0 0x20227bea3be0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.579973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , jQuery112102995032508437785_1562967095081({"result":1,"code":0,"msg":"成功","data":[]})
[1:1:0712/143210.580280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143210.581151:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.792012:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5280000, 0x12fc2df229c8, 0x20227c12f210
[1:1:0712/143210.792328:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 5280000
[1:1:0712/143210.792765:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 730
[1:1:0712/143210.793040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7fb0908c1070 0x20227d365be0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 628 0x7fb0927e92e0 0x20227bea3be0 
[24593:24593:0712/143210.796002:INFO:CONSOLE(597)] "minutes:", source: http://pub.dwstatic.com/common/newsPopup/newsPopup.js?201907 (597)
[1:1:0712/143210.919917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7fb0927e92e0 0x20227c7ef7e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.921423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/143210.921650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143210.939818:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f188
[1:1:0712/143210.940119:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143210.940653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 739
[1:1:0712/143210.940927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 739 0x7fb0908c1070 0x20227bea3ce0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 631 0x7fb0927e92e0 0x20227c7ef7e0 
[1:1:0712/143210.963927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f188
[1:1:0712/143210.964213:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143210.964656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 742
[1:1:0712/143210.964895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7fb0908c1070 0x20227d349560 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 631 0x7fb0927e92e0 0x20227c7ef7e0 
[1:1:0712/143210.970146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.988265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 632 0x7fb0927e92e0 0x20227c812e60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143210.989315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/143210.989570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143211.009430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f188
[1:1:0712/143211.009699:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143211.010124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 746
[1:1:0712/143211.010388:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 746 0x7fb0908c1070 0x20227cf60fe0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 632 0x7fb0927e92e0 0x20227c812e60 
[1:1:0712/143211.015756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143211.043707:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 634 0x7fb0927e92e0 0x20227c3bb7e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143211.048268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (function(){var h={},mt={},c={id:"a23a522269c249986e4e7039f5808f80",dm:["duowan.com"],js:"tongji.bai
[1:1:0712/143211.048537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143211.149603:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143211.150279:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143211.157610:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f190
[1:1:0712/143211.157838:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143211.158272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 749
[1:1:0712/143211.158517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7fb0908c1070 0x20227d196de0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 634 0x7fb0927e92e0 0x20227c3bb7e0 
[1:1:0712/143211.406010:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143211.871807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143211.872160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143212.870742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143212.871532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/143212.871830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143212.879960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 666, 7fb093206881
[1:1:0712/143212.917236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"507 0x7fb0908c1070 0x20227c6edd60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143212.917622:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"507 0x7fb0908c1070 0x20227c6edd60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143212.918076:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143212.918724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143212.918972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143212.919925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143212.920146:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143212.920579:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 833
[1:1:0712/143212.920833:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7fb0908c1070 0x20227c368960 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 666 0x7fb0908c1070 0x20227d3a8d60 
[1:1:0712/143213.232893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 689 0x7fb0927e92e0 0x20227d3f6e60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143213.234022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0712/143213.234277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143213.254737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143214.056192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 704, 7fb093206881
[1:1:0712/143214.100144:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"623 0x7fb0927e92e0 0x20227c3a6160 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143214.100553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"623 0x7fb0927e92e0 0x20227c3a6160 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143214.100978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143214.101708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143214.101946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143214.102448:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143214.102647:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143214.103107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 847
[1:1:0712/143214.103342:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7fb0908c1070 0x20227d59c860 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 704 0x7fb0908c1070 0x20227d37d6e0 
[1:1:0712/143215.568593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 749, 7fb093206881
[1:1:0712/143215.598555:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"634 0x7fb0927e92e0 0x20227c3bb7e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143215.598925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"634 0x7fb0927e92e0 0x20227c3bb7e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143215.599338:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143215.599950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143215.600149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143215.601011:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143215.601175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143215.601591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 870
[1:1:0712/143215.601790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7fb0908c1070 0x20227d5c1ae0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 749 0x7fb0908c1070 0x20227d196de0 
[1:1:0712/143215.820002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143215.820192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143217.049630:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 829 0x7fb0927e92e0 0x20227d38b060 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143217.052606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , /* @version hiido_internal.js: v2.4.1 2019-05-30 17:45:51 */
!function(){"use strict";var e="undefin
[1:1:0712/143217.052748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143217.562289:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 830 0x7fb0927e92e0 0x20227d746e60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143217.563317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0712/143217.563510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143217.578701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143217.768099:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 833, 7fb093206881
[1:1:0712/143217.784560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"666 0x7fb0908c1070 0x20227d3a8d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143217.784790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"666 0x7fb0908c1070 0x20227d3a8d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143217.785024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143217.785361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143217.785485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143217.785804:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143217.785904:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143217.786122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 919
[1:1:0712/143217.786239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7fb0908c1070 0x20227dd64e60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 833 0x7fb0908c1070 0x20227c368960 
[1:1:0712/143217.786790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 701, 7fb093206881
[1:1:0712/143217.799475:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"620 0x7fb0927e92e0 0x20227cf60ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143217.799672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"620 0x7fb0927e92e0 0x20227cf60ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143217.799880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143217.800258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , listenLoaded, () {
	if (document.readyState)// IE
	{
		if (document.readyState == "loaded"
				|| document.rea
[1:1:0712/143217.800372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143217.800729:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143217.800831:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 3000
[1:1:0712/143217.801048:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 921
[1:1:0712/143217.801164:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7fb0908c1070 0x20227dd7ad60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 701 0x7fb0908c1070 0x20227c368160 
[1:1:0712/143217.876639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 841 0x7fb0927e92e0 0x20227d35ab60 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143217.877446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0712/143217.877614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143217.891029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143218.021949:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 842 0x7fb0927e92e0 0x20227d5b32e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143218.024364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , define("gallery/jquery/1.11.1/jquery",[],function(e,t,n){!function(e,t){"object"==typeof n&&"object"
[1:1:0712/143218.024490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143218.050162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
		remove user.11_939aeb67 -> 0
		remove user.12_99bac106 -> 0
		remove user.13_df6338ab -> 0
[1:1:0712/143218.879633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143218.880482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , J.onload, (){return}
[1:1:0712/143218.880708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143218.918480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143218.919265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/143218.919518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143218.927314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 847, 7fb093206881
[1:1:0712/143218.964707:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"704 0x7fb0908c1070 0x20227d37d6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143218.965119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"704 0x7fb0908c1070 0x20227d37d6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143218.965633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143218.966646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143218.967050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143218.967855:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143218.968100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143218.968544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 943
[1:1:0712/143218.968813:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 943 0x7fb0908c1070 0x20227e3df760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 847 0x7fb0908c1070 0x20227d59c860 
[1:1:0712/143219.104595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143219.104898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143219.366632:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 859 0x7fb0927e92e0 0x20227d5c4ce0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143219.377367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0712/143219.377672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143219.825187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 1000
[1:1:0712/143219.825752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 956
[1:1:0712/143219.826006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7fb0908c1070 0x20227e25a6e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 859 0x7fb0927e92e0 0x20227d5c4ce0 
[1:1:0712/143219.949210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f188
[1:1:0712/143219.949535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143219.949975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 957
[1:1:0712/143219.950320:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7fb0908c1070 0x20227e5dca60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 859 0x7fb0927e92e0 0x20227d5c4ce0 
[1:1:0712/143219.983447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12fc2df229c8, 0x20227c12f188
[1:1:0712/143219.983771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 0
[1:1:0712/143219.984265:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 960
[1:1:0712/143219.984550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7fb0908c1070 0x20227e25a7e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 859 0x7fb0927e92e0 0x20227d5c4ce0 
[1:1:0712/143219.985069:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x12fc2df229c8, 0x20227c12f188
[1:1:0712/143219.985271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 15000
[1:1:0712/143219.985716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 961
[1:1:0712/143219.985949:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7fb0908c1070 0x20227e352660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 859 0x7fb0927e92e0 0x20227d5c4ce0 
[1:1:0712/143219.996391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143220.298753:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143220.299549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , g.onload, (){g.onload=t;g=window[d]=t;a&&a(b)}
[1:1:0712/143220.299869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143220.307980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 870, 7fb093206881
[1:1:0712/143220.337335:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"749 0x7fb0908c1070 0x20227d196de0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143220.337732:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"749 0x7fb0908c1070 0x20227d196de0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143220.338162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143220.338813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143220.339033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143220.339963:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143220.340280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143220.340823:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 974
[1:1:0712/143220.341092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7fb0908c1070 0x20227e6e8ae0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 870 0x7fb0908c1070 0x20227d5c1ae0 
[1:1:0712/143220.374779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143220.375087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143221.253048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 919, 7fb093206881
[1:1:0712/143221.282092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"833 0x7fb0908c1070 0x20227c368960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143221.282487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"833 0x7fb0908c1070 0x20227c368960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143221.282917:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143221.283540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143221.283756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143221.284701:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143221.284943:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143221.285372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 985
[1:1:0712/143221.285602:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7fb0908c1070 0x20227d5c4760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 919 0x7fb0908c1070 0x20227dd64e60 
[1:1:0712/143221.692234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 943, 7fb093206881
[1:1:0712/143221.725206:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"847 0x7fb0908c1070 0x20227d59c860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143221.725631:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"847 0x7fb0908c1070 0x20227d59c860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143221.726129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143221.726773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143221.727123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143221.728097:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143221.728303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143221.728730:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 989
[1:1:0712/143221.729001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 989 0x7fb0908c1070 0x20227e73ede0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 943 0x7fb0908c1070 0x20227e3df760 
[1:1:0712/143221.792606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143221.792938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143222.294332:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 960, 7fb093206881
[1:1:0712/143222.337655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"859 0x7fb0927e92e0 0x20227d5c4ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.338036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"859 0x7fb0927e92e0 0x20227d5c4ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.338524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143222.339167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){l(e,t)}
[1:1:0712/143222.339482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143222.341463:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143222.341676:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 1
[1:1:0712/143222.342243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 995
[1:1:0712/143222.342506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7fb0908c1070 0x20227e720b60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 960 0x7fb0908c1070 0x20227e25a7e0 
[1:1:0712/143222.715552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143222.716025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143222.764809:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 974, 7fb093206881
[1:1:0712/143222.807389:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"870 0x7fb0908c1070 0x20227d5c1ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.807760:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"870 0x7fb0908c1070 0x20227d5c1ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.808241:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143222.808883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143222.809111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143222.809871:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143222.810076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143222.810509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1011
[1:1:0712/143222.810748:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1011 0x7fb0908c1070 0x20227e7250e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 974 0x7fb0908c1070 0x20227e6e8ae0 
[1:1:0712/143222.856360:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 921, 7fb093206881
[1:1:0712/143222.902184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"701 0x7fb0908c1070 0x20227c368160 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.902590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"701 0x7fb0908c1070 0x20227c368160 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.903057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143222.903741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , listenLoaded, () {
	if (document.readyState)// IE
	{
		if (document.readyState == "loaded"
				|| document.rea
[1:1:0712/143222.904027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143222.905012:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143222.905259:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 3000
[1:1:0712/143222.905743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1012
[1:1:0712/143222.906000:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7fb0908c1070 0x20227e9a1660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 921 0x7fb0908c1070 0x20227dd7ad60 
[1:1:0712/143222.907972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 956, 7fb0932068db
[1:1:0712/143222.950131:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"859 0x7fb0927e92e0 0x20227d5c4ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.950515:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"859 0x7fb0927e92e0 0x20227d5c4ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143222.950999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1014
[1:1:0712/143222.951302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7fb0908c1070 0x20227e9c2260 , 5:3_http://news.duowan.com/, 0, , 956 0x7fb0908c1070 0x20227e25a6e0 
[1:1:0712/143222.951673:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143222.952425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143222.952730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.051752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.052574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , d.onload, (){window[c]=null}
[1:1:0712/143223.052803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.054696:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 985, 7fb093206881
[1:1:0712/143223.099442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"919 0x7fb0908c1070 0x20227dd64e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.099829:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"919 0x7fb0908c1070 0x20227dd64e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.100305:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.100951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143223.101174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.101969:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143223.102178:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143223.102630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1017
[1:1:0712/143223.102888:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7fb0908c1070 0x20227e609de0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 985 0x7fb0908c1070 0x20227d5c4760 
[1:1:0712/143223.237030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143223.237351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.320401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 989, 7fb093206881
[1:1:0712/143223.359818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"943 0x7fb0908c1070 0x20227e3df760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.360229:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"943 0x7fb0908c1070 0x20227e3df760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.360811:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.361561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143223.361795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.362583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143223.362697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143223.362894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1029
[1:1:0712/143223.363021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7fb0908c1070 0x20227e3e7960 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 989 0x7fb0908c1070 0x20227e73ede0 
[1:1:0712/143223.399876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 993 0x7fb0927e92e0 0x20227e741ce0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.400998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0712/143223.401165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.421855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.526810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 995, 7fb093206881
[1:1:0712/143223.572488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"960 0x7fb0908c1070 0x20227e25a7e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.572821:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"960 0x7fb0908c1070 0x20227e25a7e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.573228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.573814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){n?t&&t():l(e,t)}
[1:1:0712/143223.573994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.576610:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143223.576806:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 1
[1:1:0712/143223.577334:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1033
[1:1:0712/143223.577568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1033 0x7fb0908c1070 0x20227e6cb8e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 995 0x7fb0908c1070 0x20227e720b60 
[1:1:0712/143223.755637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.756393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/143223.756632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.839019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.839517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/143223.839636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.883554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143223.883751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.885027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1011, 7fb093206881
[1:1:0712/143223.899634:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"974 0x7fb0908c1070 0x20227e6e8ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.899853:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"974 0x7fb0908c1070 0x20227e6e8ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143223.900089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143223.900420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143223.900546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143223.900869:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143223.900972:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143223.901157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1039
[1:1:0712/143223.901269:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1039 0x7fb0908c1070 0x20227e9a5760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1011 0x7fb0908c1070 0x20227e7250e0 
[1:1:0712/143224.094152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143224.094350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143224.185199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1017, 7fb093206881
[1:1:0712/143224.228365:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"985 0x7fb0908c1070 0x20227d5c4760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.228806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"985 0x7fb0908c1070 0x20227d5c4760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.229373:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143224.230120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143224.230352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143224.231262:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143224.231465:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143224.231971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1051
[1:1:0712/143224.232220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1051 0x7fb0908c1070 0x20227e73d660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1017 0x7fb0908c1070 0x20227e609de0 
[1:1:0712/143224.394123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1029, 7fb093206881
[1:1:0712/143224.414189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"989 0x7fb0908c1070 0x20227e73ede0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.414420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"989 0x7fb0908c1070 0x20227e73ede0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.414697:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143224.415026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143224.415134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143224.415454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143224.415564:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143224.415788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1056
[1:1:0712/143224.415899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1056 0x7fb0908c1070 0x20227e9c1fe0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1029 0x7fb0908c1070 0x20227e3e7960 
[1:1:0712/143224.416409:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1033, 7fb093206881
[1:1:0712/143224.441902:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"995 0x7fb0908c1070 0x20227e720b60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.442227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"995 0x7fb0908c1070 0x20227e720b60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.442643:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143224.443204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){n?t&&t():l(e,t)}
[1:1:0712/143224.443380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143224.497965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143224.498292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143224.557796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1014, 7fb0932068db
[1:1:0712/143224.604804:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"956 0x7fb0908c1070 0x20227e25a6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.605101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"956 0x7fb0908c1070 0x20227e25a6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.605514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1061
[1:1:0712/143224.605728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1061 0x7fb0908c1070 0x20227e744360 , 5:3_http://news.duowan.com/, 0, , 1014 0x7fb0908c1070 0x20227e9c2260 
[1:1:0712/143224.606086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143224.606652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143224.606833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143224.707573:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1039, 7fb093206881
[1:1:0712/143224.762008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1011 0x7fb0908c1070 0x20227e7250e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.762337:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1011 0x7fb0908c1070 0x20227e7250e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143224.762742:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143224.763390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143224.763565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143224.764299:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143224.764466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143224.764883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1064
[1:1:0712/143224.765079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1064 0x7fb0908c1070 0x20227e9b35e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1039 0x7fb0908c1070 0x20227e9a5760 
[1:1:0712/143224.872150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1044 0x7fb0927e92e0 0x20227e9aade0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143224.888695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , !function(){function parseCookieString(e,t){var n={};if(isString(e)&&e.length>0)for(var i,o,r,a=t?de
[1:1:0712/143224.889012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.181315:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.272643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143225.273081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.402088:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1051, 7fb093206881
[1:1:0712/143225.417623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1017 0x7fb0908c1070 0x20227e609de0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143225.417846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1017 0x7fb0908c1070 0x20227e609de0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143225.418089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.418424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143225.418531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.418871:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143225.418978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143225.419160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1075
[1:1:0712/143225.419268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1075 0x7fb0908c1070 0x20227dfa6160 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1051 0x7fb0908c1070 0x20227e73d660 
[1:1:0712/143225.465986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143225.466174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.489948:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1056, 7fb093206881
[1:1:0712/143225.505141:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1029 0x7fb0908c1070 0x20227e3e7960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143225.505362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1029 0x7fb0908c1070 0x20227e3e7960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143225.505609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.505975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143225.506088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.506407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143225.506509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143225.506698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1078
[1:1:0712/143225.506810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1078 0x7fb0908c1070 0x20227e42f9e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1056 0x7fb0908c1070 0x20227e9c1fe0 
[1:1:0712/143225.612767:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.613255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , window._adstat_.window._lsf_, (){_adstat_.init()}
[1:1:0712/143225.613386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.618828:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.619698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.622845:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.626477:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.627002:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.627536:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[24593:24593:0712/143225.641084:INFO:CONSOLE(2)] "没有采集到fmp数据", source: http://hdjs.hiido.com/hiido_internal.js?siteid=news@duowan (2)
[1:1:0712/143225.647116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.723690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.772337:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.773866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f2f0
[1:1:0712/143225.774074:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143225.774450:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1086
[1:1:0712/143225.774647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7fb0908c1070 0x20227e72e060 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1068 0x7fb0927e92e0 0x20227e7348e0 
[1:1:0712/143225.775053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.776002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f1f0
[1:1:0712/143225.776333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143225.776852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1087
[1:1:0712/143225.777113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1087 0x7fb0908c1070 0x20227e7164e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1068 0x7fb0927e92e0 0x20227e7348e0 
[1:1:0712/143225.777510:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.778432:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f1f0
[1:1:0712/143225.778607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143225.778994:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1088
[1:1:0712/143225.779195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7fb0908c1070 0x20227ea3d760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1068 0x7fb0927e92e0 0x20227e7348e0 
[1:1:0712/143225.789625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1061, 7fb0932068db
[1:1:0712/143225.831875:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1014 0x7fb0908c1070 0x20227e9c2260 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143225.832231:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1014 0x7fb0908c1070 0x20227e9c2260 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143225.832635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1091
[1:1:0712/143225.832829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1091 0x7fb0908c1070 0x20227e735760 , 5:3_http://news.duowan.com/, 0, , 1061 0x7fb0908c1070 0x20227e744360 
[1:1:0712/143225.833199:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143225.833755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143225.833955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.925488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143225.925815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143225.999644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , document.readyState
[1:1:0712/143225.999912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143226.443883:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1086, 7fb093206881
[1:1:0712/143226.493625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1068 0x7fb0927e92e0 0x20227e7348e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.493966:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1068 0x7fb0927e92e0 0x20227e7348e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.494342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143226.495006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143226.495206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143226.495904:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143226.496064:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143226.496510:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1111
[1:1:0712/143226.496704:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1111 0x7fb0908c1070 0x20227ea3f2e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1086 0x7fb0908c1070 0x20227e72e060 
[1:1:0712/143226.498901:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1087, 7fb093206881
[1:1:0712/143226.525393:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1068 0x7fb0927e92e0 0x20227e7348e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.525733:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1068 0x7fb0927e92e0 0x20227e7348e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.526111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143226.526692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143226.526871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143226.527583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143226.527746:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143226.528178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1113
[1:1:0712/143226.528379:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1113 0x7fb0908c1070 0x20227e72e060 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1087 0x7fb0908c1070 0x20227e7164e0 
[1:1:0712/143226.529783:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1088, 7fb093206881
[1:1:0712/143226.575369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1068 0x7fb0927e92e0 0x20227e7348e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.575603:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1068 0x7fb0927e92e0 0x20227e7348e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.575816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143226.576210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143226.576327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143226.576652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143226.576755:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143226.576941:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1114
[1:1:0712/143226.577054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1114 0x7fb0908c1070 0x20227e730860 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1088 0x7fb0908c1070 0x20227ea3d760 
[1:1:0712/143226.611010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1012, 7fb093206881
[1:1:0712/143226.631561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"921 0x7fb0908c1070 0x20227dd7ad60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.631791:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"921 0x7fb0908c1070 0x20227dd7ad60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143226.632003:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143226.632364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , listenLoaded, () {
	if (document.readyState)// IE
	{
		if (document.readyState == "loaded"
				|| document.rea
[1:1:0712/143226.632479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143226.648978:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1101 0x7fb0927e92e0 0x20227e734de0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143226.654441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , if(String.prototype.trim=function(){return this.replace(/(^\s*)|(\s*$)/g,"")},String.prototype.repla
[1:1:0712/143226.654614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143226.686770:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.073083:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.073559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , d.onload, (){window[c]=null}
[1:1:0712/143227.073675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.153430:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.154019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){if(e.onload=e.onerror=e.onreadystatechange=null,!t&&!A.debug)try{H.removeChild(e)}catch(n){e.pare
[1:1:0712/143227.154160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.199179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x12fc2df229c8, 0x20227c12f210
[1:1:0712/143227.199375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 10000
[1:1:0712/143227.199571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1121
[1:1:0712/143227.199681:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1121 0x7fb0908c1070 0x20227ea3c060 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1109 0x7fb0927e92e0 0x20227bea6760 
[1:1:0712/143227.244974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1111, 7fb093206881
[1:1:0712/143227.297055:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1086 0x7fb0908c1070 0x20227e72e060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.297498:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1086 0x7fb0908c1070 0x20227e72e060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.297949:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.298769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143227.299001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.299893:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.300100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.300643:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1124
[1:1:0712/143227.300895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1124 0x7fb0908c1070 0x20227dfd2c60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1111 0x7fb0908c1070 0x20227ea3f2e0 
[1:1:0712/143227.303028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1113, 7fb093206881
[1:1:0712/143227.356235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1087 0x7fb0908c1070 0x20227e7164e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.356673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1087 0x7fb0908c1070 0x20227e7164e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.357130:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.357580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143227.357711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.358040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.358143:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.358410:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1126
[1:1:0712/143227.358534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1126 0x7fb0908c1070 0x20227dd69060 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1113 0x7fb0908c1070 0x20227e72e060 
[1:1:0712/143227.425637:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1114, 7fb093206881
[1:1:0712/143227.460064:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1088 0x7fb0908c1070 0x20227ea3d760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.460288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1088 0x7fb0908c1070 0x20227ea3d760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.460786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.461517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143227.461722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.462612:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.462823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.463290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1129
[1:1:0712/143227.463604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1129 0x7fb0908c1070 0x20227e6cbb60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1114 0x7fb0908c1070 0x20227e730860 
[1:1:0712/143227.465783:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1091, 7fb0932068db
[1:1:0712/143227.502953:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1061 0x7fb0908c1070 0x20227e744360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.503183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1061 0x7fb0908c1070 0x20227e744360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.503545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1131
[1:1:0712/143227.503792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1131 0x7fb0908c1070 0x20227ea3da60 , 5:3_http://news.duowan.com/, 0, , 1091 0x7fb0908c1070 0x20227e735760 
[1:1:0712/143227.504194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.504933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143227.505156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.506591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1124, 7fb093206881
[1:1:0712/143227.534175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1111 0x7fb0908c1070 0x20227ea3f2e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.534410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1111 0x7fb0908c1070 0x20227ea3f2e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.534624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.534959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143227.535063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.535395:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.535496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.535672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1133
[1:1:0712/143227.535775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1133 0x7fb0908c1070 0x20227ea418e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1124 0x7fb0908c1070 0x20227dfd2c60 
[1:1:0712/143227.551448:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1126, 7fb093206881
[1:1:0712/143227.567746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1113 0x7fb0908c1070 0x20227e72e060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.567947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1113 0x7fb0908c1070 0x20227e72e060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.568143:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.568635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143227.568873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.569742:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.569943:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.570426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1134
[1:1:0712/143227.570665:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1134 0x7fb0908c1070 0x20227e25ac60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1126 0x7fb0908c1070 0x20227dd69060 
[1:1:0712/143227.589921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1129, 7fb093206881
[1:1:0712/143227.605483:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1114 0x7fb0908c1070 0x20227e730860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.605696:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1114 0x7fb0908c1070 0x20227e730860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.605919:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.606258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143227.606377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.606694:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.606791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.606965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1139
[1:1:0712/143227.607070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1139 0x7fb0908c1070 0x20227e71d7e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1129 0x7fb0908c1070 0x20227e6cbb60 
[1:1:0712/143227.718695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1141 0x7fb0927e92e0 0x20227e72e0e0 , "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.719911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , jQuery111101134593418677805_1562967138393({"show":{"exist":1,"total_num":"1","com_num":"1","uniqid":
[1:1:0712/143227.720107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.721439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.850256:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1133, 7fb093206881
[1:1:0712/143227.865951:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1124 0x7fb0908c1070 0x20227dfd2c60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.866161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1124 0x7fb0908c1070 0x20227dfd2c60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.866362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.866695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143227.866821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.867137:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.867238:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.867496:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1154
[1:1:0712/143227.867616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1154 0x7fb0908c1070 0x20227e99d1e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1133 0x7fb0908c1070 0x20227ea418e0 
[1:1:0712/143227.884147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1134, 7fb093206881
[1:1:0712/143227.901213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1126 0x7fb0908c1070 0x20227dd69060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.901640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1126 0x7fb0908c1070 0x20227dd69060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143227.902072:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143227.902895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143227.903112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143227.903985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143227.904181:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143227.904702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1155
[1:1:0712/143227.904942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1155 0x7fb0908c1070 0x20227e73e0e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1134 0x7fb0908c1070 0x20227e25ac60 
[1:1:0712/143228.216993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1139, 7fb093206881
[1:1:0712/143228.264647:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1129 0x7fb0908c1070 0x20227e6cbb60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.264999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1129 0x7fb0908c1070 0x20227e6cbb60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.265360:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.265962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143228.266158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.266874:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.267042:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.267428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1163
[1:1:0712/143228.267652:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1163 0x7fb0908c1070 0x20227de52860 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1139 0x7fb0908c1070 0x20227e71d7e0 
[1:1:0712/143228.269370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1131, 7fb0932068db
[1:1:0712/143228.317119:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1091 0x7fb0908c1070 0x20227e735760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.317431:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1091 0x7fb0908c1070 0x20227e735760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.317853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1165
[1:1:0712/143228.318054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7fb0908c1070 0x20227e71b9e0 , 5:3_http://news.duowan.com/, 0, , 1131 0x7fb0908c1070 0x20227ea3da60 
[1:1:0712/143228.318370:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.318933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143228.319113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.369555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1154, 7fb093206881
[1:1:0712/143228.416829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1133 0x7fb0908c1070 0x20227ea418e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.417178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1133 0x7fb0908c1070 0x20227ea418e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.417534:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.418132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143228.418312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.419032:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.419205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.419620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1168
[1:1:0712/143228.419820:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1168 0x7fb0908c1070 0x20227e9d0d60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1154 0x7fb0908c1070 0x20227e99d1e0 
[1:1:0712/143228.421539:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1155, 7fb093206881
[1:1:0712/143228.471641:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1134 0x7fb0908c1070 0x20227e25ac60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.472059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1134 0x7fb0908c1070 0x20227e25ac60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.472422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.473097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143228.473279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.474059:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.474222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.474632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1170
[1:1:0712/143228.474831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7fb0908c1070 0x20227c57f760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1155 0x7fb0908c1070 0x20227e73e0e0 
[1:1:0712/143228.505499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1163, 7fb093206881
[1:1:0712/143228.521027:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1139 0x7fb0908c1070 0x20227e71d7e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.521251:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1139 0x7fb0908c1070 0x20227e71d7e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.521465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.521803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143228.521915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.522220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.522324:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.522507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1172
[1:1:0712/143228.522639:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7fb0908c1070 0x20227e9c62e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1163 0x7fb0908c1070 0x20227de52860 
[1:1:0712/143228.539153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1168, 7fb093206881
[1:1:0712/143228.557402:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1154 0x7fb0908c1070 0x20227e99d1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.557670:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1154 0x7fb0908c1070 0x20227e99d1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.557885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.558218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143228.558332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.558668:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.558810:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.559001:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1174
[1:1:0712/143228.559111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7fb0908c1070 0x20227d4a2ee0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1168 0x7fb0908c1070 0x20227e9d0d60 
[1:1:0712/143228.615149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1170, 7fb093206881
[1:1:0712/143228.630794:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1155 0x7fb0908c1070 0x20227e73e0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.631001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1155 0x7fb0908c1070 0x20227e73e0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.631206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.631549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143228.631681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.632003:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.632113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.632297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1176
[1:1:0712/143228.632409:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7fb0908c1070 0x20227e7004e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1170 0x7fb0908c1070 0x20227c57f760 
[1:1:0712/143228.632974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1172, 7fb093206881
[1:1:0712/143228.649061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1163 0x7fb0908c1070 0x20227de52860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.649287:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1163 0x7fb0908c1070 0x20227de52860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.649497:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.649865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143228.649983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.650303:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.650404:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.650591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1178
[1:1:0712/143228.650725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1178 0x7fb0908c1070 0x20227e7005e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1172 0x7fb0908c1070 0x20227e9c62e0 
[1:1:0712/143228.711688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1174, 7fb093206881
[1:1:0712/143228.759908:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1168 0x7fb0908c1070 0x20227e9d0d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.760252:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1168 0x7fb0908c1070 0x20227e9d0d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.760615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.761246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143228.761427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.761950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.762090:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.762335:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1180
[1:1:0712/143228.762458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1180 0x7fb0908c1070 0x20227d5c4be0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1174 0x7fb0908c1070 0x20227d4a2ee0 
[1:1:0712/143228.763167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1176, 7fb093206881
[1:1:0712/143228.814046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1170 0x7fb0908c1070 0x20227c57f760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.814470:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1170 0x7fb0908c1070 0x20227c57f760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.814936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.815663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143228.815887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.816806:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.817018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.817501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1184
[1:1:0712/143228.817763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7fb0908c1070 0x20227d3b41e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1176 0x7fb0908c1070 0x20227e7004e0 
[1:1:0712/143228.819881:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1178, 7fb093206881
[1:1:0712/143228.878603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1172 0x7fb0908c1070 0x20227e9c62e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.878964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1172 0x7fb0908c1070 0x20227e9c62e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.879328:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.879984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143228.880166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143228.880948:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143228.881117:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143228.881505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1186
[1:1:0712/143228.881726:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1186 0x7fb0908c1070 0x20227e9a5d60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1178 0x7fb0908c1070 0x20227e7005e0 
[1:1:0712/143228.883554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1165, 7fb0932068db
[1:1:0712/143228.938493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1131 0x7fb0908c1070 0x20227ea3da60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.938894:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1131 0x7fb0908c1070 0x20227ea3da60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143228.939389:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1191
[1:1:0712/143228.939629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1191 0x7fb0908c1070 0x20227e741ae0 , 5:3_http://news.duowan.com/, 0, , 1165 0x7fb0908c1070 0x20227e71b9e0 
[1:1:0712/143228.940089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143228.940782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143228.941000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.005510:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1180, 7fb093206881
[1:1:0712/143229.043130:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1174 0x7fb0908c1070 0x20227d4a2ee0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.043424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1174 0x7fb0908c1070 0x20227d4a2ee0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.043767:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.044206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.044354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.044808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.044917:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.045107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1195
[1:1:0712/143229.045231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7fb0908c1070 0x20227dcebe60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1180 0x7fb0908c1070 0x20227d5c4be0 
[1:1:0712/143229.090522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1184, 7fb093206881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/143229.149225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1176 0x7fb0908c1070 0x20227e7004e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.149577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1176 0x7fb0908c1070 0x20227e7004e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.149962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.150547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.150741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.151447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.151605:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.152068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1196
[1:1:0712/143229.152292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1196 0x7fb0908c1070 0x20227e71b9e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1184 0x7fb0908c1070 0x20227d3b41e0 
[1:1:0712/143229.154102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1186, 7fb093206881
[1:1:0712/143229.212781:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1178 0x7fb0908c1070 0x20227e7005e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.213203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1178 0x7fb0908c1070 0x20227e7005e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.213639:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.214434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143229.214654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.215526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.215723:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.216252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1199
[1:1:0712/143229.216513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1199 0x7fb0908c1070 0x20227e71b0e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1186 0x7fb0908c1070 0x20227e9a5d60 
[1:1:0712/143229.279851:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1195, 7fb093206881
[1:1:0712/143229.340466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1180 0x7fb0908c1070 0x20227d5c4be0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.340897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1180 0x7fb0908c1070 0x20227d5c4be0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.341337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.342061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.342280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.343164:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.343364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.343911:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1202
[1:1:0712/143229.344156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1202 0x7fb0908c1070 0x20227cb67f60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1195 0x7fb0908c1070 0x20227dcebe60 
[1:1:0712/143229.346335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1196, 7fb093206881
[1:1:0712/143229.406250:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1184 0x7fb0908c1070 0x20227d3b41e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.406587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1184 0x7fb0908c1070 0x20227d3b41e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.406958:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.407538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.407724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.408641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.408858:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.409338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1205
[1:1:0712/143229.409594:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1205 0x7fb0908c1070 0x20227e42f8e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1196 0x7fb0908c1070 0x20227e71b9e0 
[1:1:0712/143229.411674:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1199, 7fb093206881
[1:1:0712/143229.428447:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1186 0x7fb0908c1070 0x20227e9a5d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.428668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1186 0x7fb0908c1070 0x20227e9a5d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.428894:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.429249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143229.429357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.429672:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.429772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.430261:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1207
[1:1:0712/143229.430459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1207 0x7fb0908c1070 0x20227e9c8360 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1199 0x7fb0908c1070 0x20227e71b0e0 
[1:1:0712/143229.470287:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1202, 7fb093206881
[1:1:0712/143229.488862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1195 0x7fb0908c1070 0x20227dcebe60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.489080:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1195 0x7fb0908c1070 0x20227dcebe60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.489286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.489603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.489711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.490062:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.490167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.490357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1209
[1:1:0712/143229.490481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1209 0x7fb0908c1070 0x20227e609e60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1202 0x7fb0908c1070 0x20227cb67f60 
[1:1:0712/143229.560149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1205, 7fb093206881
[1:1:0712/143229.612675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1196 0x7fb0908c1070 0x20227e71b9e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.613137:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1196 0x7fb0908c1070 0x20227e71b9e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.613590:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.614332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.614566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.615466:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.615673:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.616212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1212
[1:1:0712/143229.616458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1212 0x7fb0908c1070 0x20227dd185e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1205 0x7fb0908c1070 0x20227e42f8e0 
[1:1:0712/143229.620059:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1207, 7fb093206881
[1:1:0712/143229.677230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1199 0x7fb0908c1070 0x20227e71b0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.677600:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1199 0x7fb0908c1070 0x20227e71b0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.677993:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.678638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143229.678815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.679559:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.679719:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.680187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1215
[1:1:0712/143229.680410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1215 0x7fb0908c1070 0x20227e6e86e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1207 0x7fb0908c1070 0x20227e9c8360 
[1:1:0712/143229.681953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1209, 7fb093206881
[1:1:0712/143229.734828:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1202 0x7fb0908c1070 0x20227cb67f60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.735266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1202 0x7fb0908c1070 0x20227cb67f60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.735700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.736458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.736680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.737552:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.737749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.738416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1217
[1:1:0712/143229.738653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1217 0x7fb0908c1070 0x20227e9aaa60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1209 0x7fb0908c1070 0x20227e609e60 
[1:1:0712/143229.740711:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1212, 7fb093206881
[1:1:0712/143229.792855:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1205 0x7fb0908c1070 0x20227e42f8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.793263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1205 0x7fb0908c1070 0x20227e42f8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.793627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.794231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.794413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.795281:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.795464:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.795985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1220
[1:1:0712/143229.796182:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1220 0x7fb0908c1070 0x20227e730760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1212 0x7fb0908c1070 0x20227dd185e0 
[1:1:0712/143229.824878:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1215, 7fb093206881
[1:1:0712/143229.848710:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1207 0x7fb0908c1070 0x20227e9c8360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.849020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1207 0x7fb0908c1070 0x20227e9c8360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.849306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.849773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143229.850027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.850490:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.850627:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.850890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1223
[1:1:0712/143229.851068:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1223 0x7fb0908c1070 0x20227e73c3e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1215 0x7fb0908c1070 0x20227e6e86e0 
[1:1:0712/143229.851845:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1191, 7fb0932068db
[1:1:0712/143229.871811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1165 0x7fb0908c1070 0x20227e71b9e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.872123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1165 0x7fb0908c1070 0x20227e71b9e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.872361:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1226
[1:1:0712/143229.872474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1226 0x7fb0908c1070 0x20227e734a60 , 5:3_http://news.duowan.com/, 0, , 1191 0x7fb0908c1070 0x20227e741ae0 
[1:1:0712/143229.872672:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.873085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143229.873280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.874783:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1217, 7fb093206881
[1:1:0712/143229.929392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1209 0x7fb0908c1070 0x20227e609e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.929729:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1209 0x7fb0908c1070 0x20227e609e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.930111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.930694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.930872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.931583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.931741:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.932178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1227
[1:1:0712/143229.932374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1227 0x7fb0908c1070 0x20227e9c6ce0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1217 0x7fb0908c1070 0x20227e9aaa60 
[1:1:0712/143229.934034:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1220, 7fb093206881
[1:1:0712/143229.983900:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1212 0x7fb0908c1070 0x20227dd185e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.984265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1212 0x7fb0908c1070 0x20227dd185e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143229.984636:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143229.985252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143229.985433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143229.986149:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143229.986311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143229.986692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1230
[1:1:0712/143229.986880:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1230 0x7fb0908c1070 0x20227e71d6e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1220 0x7fb0908c1070 0x20227e730760 
[1:1:0712/143230.045669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1223, 7fb093206881
[1:1:0712/143230.088773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1215 0x7fb0908c1070 0x20227e6e86e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.089028:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1215 0x7fb0908c1070 0x20227e6e86e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.089245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.089585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143230.089698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.090058:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.090163:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.090346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1234
[1:1:0712/143230.090458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1234 0x7fb0908c1070 0x20227e730660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1223 0x7fb0908c1070 0x20227e73c3e0 
[1:1:0712/143230.090979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1227, 7fb093206881
[1:1:0712/143230.109500:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1217 0x7fb0908c1070 0x20227e9aaa60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.109729:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1217 0x7fb0908c1070 0x20227e9aaa60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.109950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.110299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.110408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.110724:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.110822:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.111038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1236
[1:1:0712/143230.111159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1236 0x7fb0908c1070 0x20227e730860 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1227 0x7fb0908c1070 0x20227e9c6ce0 
[1:1:0712/143230.111660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1230, 7fb093206881
[1:1:0712/143230.136079:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1220 0x7fb0908c1070 0x20227e730760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.136415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1220 0x7fb0908c1070 0x20227e730760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.136771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.137366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.137550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.138268:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.138432:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.138817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1237
[1:1:0712/143230.139029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1237 0x7fb0908c1070 0x20227e735560 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1230 0x7fb0908c1070 0x20227e71d6e0 
[1:1:0712/143230.229402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1234, 7fb093206881
[1:1:0712/143230.245583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1223 0x7fb0908c1070 0x20227e73c3e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.245793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1223 0x7fb0908c1070 0x20227e73c3e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.246031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.246389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143230.246497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.246813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.246913:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.247123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1240
[1:1:0712/143230.247241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1240 0x7fb0908c1070 0x20227e73cf60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1234 0x7fb0908c1070 0x20227e730660 
[1:1:0712/143230.247830:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1236, 7fb093206881
[1:1:0712/143230.265807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1227 0x7fb0908c1070 0x20227e9c6ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.266051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1227 0x7fb0908c1070 0x20227e9c6ce0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.266269:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.266606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.266718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.267063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.267168:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.267352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1242
[1:1:0712/143230.267459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1242 0x7fb0908c1070 0x20227c7f1b60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1236 0x7fb0908c1070 0x20227e730860 
[1:1:0712/143230.267937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1237, 7fb093206881
[1:1:0712/143230.296481:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1230 0x7fb0908c1070 0x20227e71d6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.296817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1230 0x7fb0908c1070 0x20227e71d6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.297197:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.297776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.297945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.298632:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.298787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.299175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1243
[1:1:0712/143230.299363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1243 0x7fb0908c1070 0x20227e9d36e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1237 0x7fb0908c1070 0x20227e735560 
[1:1:0712/143230.395300:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1240, 7fb093206881
[1:1:0712/143230.411805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1234 0x7fb0908c1070 0x20227e730660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.412026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1234 0x7fb0908c1070 0x20227e730660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.412279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.412602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143230.412709:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.413023:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.413221:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.413606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1246
[1:1:0712/143230.413800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1246 0x7fb0908c1070 0x20227e6f7060 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1240 0x7fb0908c1070 0x20227e73cf60 
[1:1:0712/143230.415275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1242, 7fb093206881
[1:1:0712/143230.465582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1236 0x7fb0908c1070 0x20227e730860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.465943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1236 0x7fb0908c1070 0x20227e730860 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.466326:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.466962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.467159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.467852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.468011:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.468458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1248
[1:1:0712/143230.468650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1248 0x7fb0908c1070 0x20227e6f08e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1242 0x7fb0908c1070 0x20227c7f1b60 
[1:1:0712/143230.470758:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1243, 7fb093206881
[1:1:0712/143230.521735:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1237 0x7fb0908c1070 0x20227e735560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.522100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1237 0x7fb0908c1070 0x20227e735560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.522465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.523037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.523289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.524008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.524276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.524671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1250
[1:1:0712/143230.524864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1250 0x7fb0908c1070 0x20227e6e8e60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1243 0x7fb0908c1070 0x20227e9d36e0 
[1:1:0712/143230.526539:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1246, 7fb093206881
[1:1:0712/143230.577309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1240 0x7fb0908c1070 0x20227e73cf60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.577663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1240 0x7fb0908c1070 0x20227e73cf60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.578022:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.578618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143230.578796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.579514:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.579677:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.580251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1253
[1:1:0712/143230.580451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1253 0x7fb0908c1070 0x20227cb525e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1246 0x7fb0908c1070 0x20227e6f7060 
[1:1:0712/143230.633041:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1248, 7fb093206881
[1:1:0712/143230.685647:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1242 0x7fb0908c1070 0x20227c7f1b60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.685996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1242 0x7fb0908c1070 0x20227c7f1b60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.686387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.687029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.687224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.687940:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.688144:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.688545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1257
[1:1:0712/143230.688738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1257 0x7fb0908c1070 0x20227d4ae1e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1248 0x7fb0908c1070 0x20227e6f08e0 
[1:1:0712/143230.690390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1250, 7fb093206881
[1:1:0712/143230.724684:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1243 0x7fb0908c1070 0x20227e9d36e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.724988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1243 0x7fb0908c1070 0x20227e9d36e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.725283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.725711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.725853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.726325:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.726458:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.726716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1260
[1:1:0712/143230.726875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1260 0x7fb0908c1070 0x20227c7f0fe0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1250 0x7fb0908c1070 0x20227e6e8e60 
[1:1:0712/143230.727617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1253, 7fb093206881
[1:1:0712/143230.774940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1246 0x7fb0908c1070 0x20227e6f7060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.775390:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1246 0x7fb0908c1070 0x20227e6f7060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.775870:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.776640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143230.776870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.777759:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.777961:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.778471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1261
[1:1:0712/143230.778721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1261 0x7fb0908c1070 0x20227e7435e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1253 0x7fb0908c1070 0x20227cb525e0 
[1:1:0712/143230.816755:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1257, 7fb093206881
[1:1:0712/143230.834985:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1248 0x7fb0908c1070 0x20227e6f08e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.835262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1248 0x7fb0908c1070 0x20227e6f08e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.835485:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.835809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.835917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.836396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.836563:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.836949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1264
[1:1:0712/143230.837165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1264 0x7fb0908c1070 0x20227e6ec5e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1257 0x7fb0908c1070 0x20227d4ae1e0 
[1:1:0712/143230.838630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1226, 7fb0932068db
[1:1:0712/143230.896035:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1191 0x7fb0908c1070 0x20227e741ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.896393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1191 0x7fb0908c1070 0x20227e741ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.896798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1267
[1:1:0712/143230.896995:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1267 0x7fb0908c1070 0x20227e6f03e0 , 5:3_http://news.duowan.com/, 0, , 1226 0x7fb0908c1070 0x20227e734a60 
[1:1:0712/143230.897340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.897899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143230.898077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.900082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1260, 7fb093206881
[1:1:0712/143230.927191:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1250 0x7fb0908c1070 0x20227e6e8e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.927411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1250 0x7fb0908c1070 0x20227e6e8e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.927617:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.927968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143230.928076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.928456:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.928566:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.928753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1270
[1:1:0712/143230.928863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7fb0908c1070 0x20227e71bae0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1260 0x7fb0908c1070 0x20227c7f0fe0 
[1:1:0712/143230.929414:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1261, 7fb093206881
[1:1:0712/143230.946364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1253 0x7fb0908c1070 0x20227cb525e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.946583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1253 0x7fb0908c1070 0x20227cb525e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143230.946787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143230.947104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143230.947234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143230.947559:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143230.947658:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143230.947847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1271
[1:1:0712/143230.947956:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1271 0x7fb0908c1070 0x20227e71d5e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1261 0x7fb0908c1070 0x20227e7435e0 
[1:1:0712/143230.998576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1264, 7fb093206881
[1:1:0712/143231.044657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1257 0x7fb0908c1070 0x20227d4ae1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.044886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1257 0x7fb0908c1070 0x20227d4ae1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.045098:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.045474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.045586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.045912:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.046013:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.046217:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1273
[1:1:0712/143231.046337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1273 0x7fb0908c1070 0x20227e9d3660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1264 0x7fb0908c1070 0x20227e6ec5e0 
[1:1:0712/143231.046845:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1270, 7fb093206881
[1:1:0712/143231.065410:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1260 0x7fb0908c1070 0x20227c7f0fe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.065641:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1260 0x7fb0908c1070 0x20227c7f0fe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.065852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.066172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.066302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.066617:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.066719:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.066909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1275
[1:1:0712/143231.067022:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1275 0x7fb0908c1070 0x20227e0dc460 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1270 0x7fb0908c1070 0x20227e71bae0 
[1:1:0712/143231.067580:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1271, 7fb093206881
[1:1:0712/143231.126026:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1261 0x7fb0908c1070 0x20227e7435e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.126397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1261 0x7fb0908c1070 0x20227e7435e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.126763:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.127438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143231.127620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.128388:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.128593:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.129076:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1277
[1:1:0712/143231.129346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1277 0x7fb0908c1070 0x20227ea3fd60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1271 0x7fb0908c1070 0x20227e71d5e0 
[1:1:0712/143231.203511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1273, 7fb093206881
[1:1:0712/143231.266658:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1264 0x7fb0908c1070 0x20227e6ec5e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.267078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1264 0x7fb0908c1070 0x20227e6ec5e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.267534:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.268281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.268533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.269406:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.269603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.270088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1281
[1:1:0712/143231.270347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1281 0x7fb0908c1070 0x20227e71d6e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1273 0x7fb0908c1070 0x20227e9d3660 
[1:1:0712/143231.272448:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1275, 7fb093206881
[1:1:0712/143231.325150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1270 0x7fb0908c1070 0x20227e71bae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.325533:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1270 0x7fb0908c1070 0x20227e71bae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.325897:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.326508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.326690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.327418:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.327583:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.328109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1284
[1:1:0712/143231.328347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1284 0x7fb0908c1070 0x20227e72e8e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1275 0x7fb0908c1070 0x20227e0dc460 
[1:1:0712/143231.329996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1277, 7fb093206881
[1:1:0712/143231.369998:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1271 0x7fb0908c1070 0x20227e71d5e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.370225:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1271 0x7fb0908c1070 0x20227e71d5e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.370444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.370786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143231.370890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.371207:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.371333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.371521:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1286
[1:1:0712/143231.371627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1286 0x7fb0908c1070 0x20227e9a5d60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1277 0x7fb0908c1070 0x20227ea3fd60 
[1:1:0712/143231.372130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1281, 7fb093206881
[1:1:0712/143231.392497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1273 0x7fb0908c1070 0x20227e9d3660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.392726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1273 0x7fb0908c1070 0x20227e9d3660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.392938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.393289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.393410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.393729:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.393828:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.394014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1288
[1:1:0712/143231.394122:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1288 0x7fb0908c1070 0x20227d4b2c60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1281 0x7fb0908c1070 0x20227e71d6e0 
[1:1:0712/143231.461136:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1284, 7fb093206881
[1:1:0712/143231.509646:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1275 0x7fb0908c1070 0x20227e0dc460 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.509980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1275 0x7fb0908c1070 0x20227e0dc460 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.510353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.510940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.511122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.511840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.512003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.512434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1290
[1:1:0712/143231.512640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1290 0x7fb0908c1070 0x20227e9c6a60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1284 0x7fb0908c1070 0x20227e72e8e0 
[1:1:0712/143231.514627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1286, 7fb093206881
[1:1:0712/143231.580729:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1277 0x7fb0908c1070 0x20227ea3fd60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.581150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1277 0x7fb0908c1070 0x20227ea3fd60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.581631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.582451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143231.582682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.583583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.583792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.584279:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1294
[1:1:0712/143231.584605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1294 0x7fb0908c1070 0x20227e713560 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1286 0x7fb0908c1070 0x20227e9a5d60 
[1:1:0712/143231.586614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1288, 7fb093206881
[1:1:0712/143231.651055:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1281 0x7fb0908c1070 0x20227e71d6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.651490:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1281 0x7fb0908c1070 0x20227e71d6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.651931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.652559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.652702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.653035:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.653141:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.653329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1296
[1:1:0712/143231.653471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1296 0x7fb0908c1070 0x20227e7132e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1288 0x7fb0908c1070 0x20227d4b2c60 
[1:1:0712/143231.654107:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1290, 7fb093206881
[1:1:0712/143231.671675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1284 0x7fb0908c1070 0x20227e72e8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.671893:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1284 0x7fb0908c1070 0x20227e72e8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.672108:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.672468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.672580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.672893:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.672992:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.673189:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1299
[1:1:0712/143231.673298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1299 0x7fb0908c1070 0x20227e71b160 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1290 0x7fb0908c1070 0x20227e9c6a60 
[1:1:0712/143231.737531:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1294, 7fb093206881
[1:1:0712/143231.789111:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1286 0x7fb0908c1070 0x20227e9a5d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.789465:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1286 0x7fb0908c1070 0x20227e9a5d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.789829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.790423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143231.790605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.791322:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.791505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.791892:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1301
[1:1:0712/143231.792084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1301 0x7fb0908c1070 0x20227e735e60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1294 0x7fb0908c1070 0x20227e713560 
[1:1:0712/143231.793836:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1296, 7fb093206881
[1:1:0712/143231.831766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1288 0x7fb0908c1070 0x20227d4b2c60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.831999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1288 0x7fb0908c1070 0x20227d4b2c60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.832219:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.832613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.832725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.833039:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.833137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.833329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1305
[1:1:0712/143231.833465:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1305 0x7fb0908c1070 0x20227bec0560 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1296 0x7fb0908c1070 0x20227e7132e0 
[1:1:0712/143231.833997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1299, 7fb093206881
[1:1:0712/143231.854627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1290 0x7fb0908c1070 0x20227e9c6a60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.854848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1290 0x7fb0908c1070 0x20227e9c6a60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.855054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.855369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143231.855517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.855834:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.855939:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.856124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1307
[1:1:0712/143231.856233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1307 0x7fb0908c1070 0x20227e609e60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1299 0x7fb0908c1070 0x20227e71b160 
[1:1:0712/143231.856794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1267, 7fb0932068db
[1:1:0712/143231.876186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1226 0x7fb0908c1070 0x20227e734a60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.876528:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1226 0x7fb0908c1070 0x20227e734a60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.876944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1308
[1:1:0712/143231.877142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1308 0x7fb0908c1070 0x20227ea41d60 , 5:3_http://news.duowan.com/, 0, , 1267 0x7fb0908c1070 0x20227e6f03e0 
[1:1:0712/143231.877481:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.878032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143231.878207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.911871:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1301, 7fb093206881
[1:1:0712/143231.928733:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1294 0x7fb0908c1070 0x20227e713560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.928971:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1294 0x7fb0908c1070 0x20227e713560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143231.929175:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143231.929518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143231.929630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143231.929953:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143231.930054:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143231.930241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1310
[1:1:0712/143231.930353:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1310 0x7fb0908c1070 0x20227e72d0e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1301 0x7fb0908c1070 0x20227e735e60 
[1:1:0712/143231.993200:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1305, 7fb093206881
[1:1:0712/143232.045196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1296 0x7fb0908c1070 0x20227e7132e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.045546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1296 0x7fb0908c1070 0x20227e7132e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.045912:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.046572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.046768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.047481:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.047646:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.048030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1313
[1:1:0712/143232.048222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1313 0x7fb0908c1070 0x20227e99dbe0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1305 0x7fb0908c1070 0x20227bec0560 
[1:1:0712/143232.049936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1307, 7fb093206881
[1:1:0712/143232.102377:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1299 0x7fb0908c1070 0x20227e71b160 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.102766:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1299 0x7fb0908c1070 0x20227e71b160 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.103122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.103717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.103898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.104658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.104823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.105208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1316
[1:1:0712/143232.105400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1316 0x7fb0908c1070 0x20227e9c2d60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1307 0x7fb0908c1070 0x20227e609e60 
[1:1:0712/143232.106967:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1310, 7fb093206881
[1:1:0712/143232.166642:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1301 0x7fb0908c1070 0x20227e735e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.167046:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1301 0x7fb0908c1070 0x20227e735e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.167501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.168217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143232.168451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.169346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.169559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.170045:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1318
[1:1:0712/143232.170286:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1318 0x7fb0908c1070 0x20227df640e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1310 0x7fb0908c1070 0x20227e72d0e0 
[1:1:0712/143232.172410:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1313, 7fb093206881
[1:1:0712/143232.232655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1305 0x7fb0908c1070 0x20227bec0560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.233001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1305 0x7fb0908c1070 0x20227bec0560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.233362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.234018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.234197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.234909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.235074:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.235613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1321
[1:1:0712/143232.235837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1321 0x7fb0908c1070 0x20227e9c25e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1313 0x7fb0908c1070 0x20227e99dbe0 
[1:1:0712/143232.292147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1316, 7fb093206881
[1:1:0712/143232.346905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1307 0x7fb0908c1070 0x20227e609e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.347255:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1307 0x7fb0908c1070 0x20227e609e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.347630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.348217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.348407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.349149:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.349311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.349717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1325
[1:1:0712/143232.349919:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1325 0x7fb0908c1070 0x20227e728360 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1316 0x7fb0908c1070 0x20227e9c2d60 
[1:1:0712/143232.351632:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1318, 7fb093206881
[1:1:0712/143232.410555:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1310 0x7fb0908c1070 0x20227e72d0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.410973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1310 0x7fb0908c1070 0x20227e72d0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.411334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.411936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143232.412116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.412926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.413129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.413623:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1328
[1:1:0712/143232.413870:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1328 0x7fb0908c1070 0x20227d4ae1e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1318 0x7fb0908c1070 0x20227df640e0 
[1:1:0712/143232.416017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1321, 7fb093206881
[1:1:0712/143232.466547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1313 0x7fb0908c1070 0x20227e99dbe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.466785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1313 0x7fb0908c1070 0x20227e99dbe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.466993:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.467338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.467457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.467810:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.467913:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.468098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1330
[1:1:0712/143232.468209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1330 0x7fb0908c1070 0x20227e99f760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1321 0x7fb0908c1070 0x20227e9c25e0 
[1:1:0712/143232.469111:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1325, 7fb093206881
[1:1:0712/143232.518576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1316 0x7fb0908c1070 0x20227e9c2d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.519005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1316 0x7fb0908c1070 0x20227e9c2d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.519367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.519991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.520179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.520960:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.521126:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.521511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1333
[1:1:0712/143232.521743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1333 0x7fb0908c1070 0x20227e744960 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1325 0x7fb0908c1070 0x20227e728360 
[1:1:0712/143232.559160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1328, 7fb093206881
[1:1:0712/143232.614740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1318 0x7fb0908c1070 0x20227df640e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.615158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1318 0x7fb0908c1070 0x20227df640e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.615622:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.616354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143232.616642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.617524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.617810:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.618297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1336
[1:1:0712/143232.618541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1336 0x7fb0908c1070 0x20227dd5df60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1328 0x7fb0908c1070 0x20227d4ae1e0 
[1:1:0712/143232.620703:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1330, 7fb093206881
[1:1:0712/143232.686796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1321 0x7fb0908c1070 0x20227e9c25e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.687193:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1321 0x7fb0908c1070 0x20227e9c25e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.687641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.688416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.688689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.689557:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.689775:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.690247:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1339
[1:1:0712/143232.690483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1339 0x7fb0908c1070 0x20227ea3de60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1330 0x7fb0908c1070 0x20227e99f760 
[1:1:0712/143232.692614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1333, 7fb093206881
[1:1:0712/143232.747737:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1325 0x7fb0908c1070 0x20227e728360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.748052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1325 0x7fb0908c1070 0x20227e728360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.748403:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.749036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.749227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.749934:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.750097:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.750475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1342
[1:1:0712/143232.750686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1342 0x7fb0908c1070 0x20227d4ca760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1333 0x7fb0908c1070 0x20227e744960 
[1:1:0712/143232.752341:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1336, 7fb093206881
[1:1:0712/143232.809413:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1328 0x7fb0908c1070 0x20227d4ae1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.809843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1328 0x7fb0908c1070 0x20227d4ae1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.810304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.811029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143232.811212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.811945:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.812108:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.812493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1345
[1:1:0712/143232.812748:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7fb0908c1070 0x20227e9aa960 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1336 0x7fb0908c1070 0x20227dd5df60 
[1:1:0712/143232.849737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1339, 7fb093206881
[1:1:0712/143232.895855:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1330 0x7fb0908c1070 0x20227e99f760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.896084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1330 0x7fb0908c1070 0x20227e99f760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.896291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.896603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.896827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.897150:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.897247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.897428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1349
[1:1:0712/143232.897536:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1349 0x7fb0908c1070 0x20227e9a19e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1339 0x7fb0908c1070 0x20227ea3de60 
[1:1:0712/143232.898768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1308, 7fb0932068db
[1:1:0712/143232.915632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1267 0x7fb0908c1070 0x20227e6f03e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.915838:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1267 0x7fb0908c1070 0x20227e6f03e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.916052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1351
[1:1:0712/143232.916162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1351 0x7fb0908c1070 0x20227e3df660 , 5:3_http://news.duowan.com/, 0, , 1308 0x7fb0908c1070 0x20227ea41d60 
[1:1:0712/143232.916335:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.916626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143232.916778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.917297:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1342, 7fb093206881
[1:1:0712/143232.935675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1333 0x7fb0908c1070 0x20227e744960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.935899:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1333 0x7fb0908c1070 0x20227e744960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.936097:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.936427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143232.936529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.936871:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.936969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.937149:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1353
[1:1:0712/143232.937253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7fb0908c1070 0x20227d5bb8e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1342 0x7fb0908c1070 0x20227d4ca760 
[1:1:0712/143232.937724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1345, 7fb093206881
[1:1:0712/143232.971419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1336 0x7fb0908c1070 0x20227dd5df60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.971762:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1336 0x7fb0908c1070 0x20227dd5df60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143232.972132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143232.972774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143232.972959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143232.973647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143232.973870:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143232.974252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1354
[1:1:0712/143232.974443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1354 0x7fb0908c1070 0x20227cc578e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1345 0x7fb0908c1070 0x20227e9aa960 
[1:1:0712/143233.051967:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1349, 7fb093206881
[1:1:0712/143233.104136:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1339 0x7fb0908c1070 0x20227ea3de60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.104461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1339 0x7fb0908c1070 0x20227ea3de60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.104833:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.105411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.105586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.106303:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.106467:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.106875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1357
[1:1:0712/143233.107071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1357 0x7fb0908c1070 0x20227e9a1660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1349 0x7fb0908c1070 0x20227e9a19e0 
[1:1:0712/143233.108790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1353, 7fb093206881
[1:1:0712/143233.163019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1342 0x7fb0908c1070 0x20227d4ca760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.163357:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1342 0x7fb0908c1070 0x20227d4ca760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.163773:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.164413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.164591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.165299:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.165461:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.165866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1360
[1:1:0712/143233.166062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1360 0x7fb0908c1070 0x20227dfc98e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1353 0x7fb0908c1070 0x20227d5bb8e0 
[1:1:0712/143233.167622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1354, 7fb093206881
[1:1:0712/143233.232672:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1345 0x7fb0908c1070 0x20227e9aa960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.233074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1345 0x7fb0908c1070 0x20227e9aa960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.233499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.234208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143233.234425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.235308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.235502:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.236193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1362
[1:1:0712/143233.236442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1362 0x7fb0908c1070 0x20227e9ac560 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1354 0x7fb0908c1070 0x20227cc578e0 
[1:1:0712/143233.238472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1357, 7fb093206881
[1:1:0712/143233.276488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1349 0x7fb0908c1070 0x20227e9a19e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.276707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1349 0x7fb0908c1070 0x20227e9a19e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.277983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.278570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.278782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.279508:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.279666:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.280169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1365
[1:1:0712/143233.280371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1365 0x7fb0908c1070 0x20227e99dbe0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1357 0x7fb0908c1070 0x20227e9a1660 
[1:1:0712/143233.334708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1360, 7fb093206881
[1:1:0712/143233.393899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1353 0x7fb0908c1070 0x20227d5bb8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.394327:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1353 0x7fb0908c1070 0x20227d5bb8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.394757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.395549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.395808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.396682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.396890:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.397393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1367
[1:1:0712/143233.397627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1367 0x7fb0908c1070 0x20227e6f02e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1360 0x7fb0908c1070 0x20227dfc98e0 
[1:1:0712/143233.399691:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1362, 7fb093206881
[1:1:0712/143233.463082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1354 0x7fb0908c1070 0x20227cc578e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.463303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1354 0x7fb0908c1070 0x20227cc578e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.463519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.463875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143233.463986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.464293:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.464391:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.464573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1371
[1:1:0712/143233.464686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1371 0x7fb0908c1070 0x20227e9a43e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1362 0x7fb0908c1070 0x20227e9ac560 
[1:1:0712/143233.465527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1365, 7fb093206881
[1:1:0712/143233.503898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1357 0x7fb0908c1070 0x20227e9a1660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.504208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1357 0x7fb0908c1070 0x20227e9a1660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.504547:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.505112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.505285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.505976:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.506131:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.506495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1373
[1:1:0712/143233.506678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1373 0x7fb0908c1070 0x20227e9a5a60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1365 0x7fb0908c1070 0x20227e99dbe0 
[1:1:0712/143233.508077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1367, 7fb093206881
[1:1:0712/143233.547712:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1360 0x7fb0908c1070 0x20227dfc98e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.547961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1360 0x7fb0908c1070 0x20227dfc98e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.548173:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.548495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.548607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.548937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.549038:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.549216:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1375
[1:1:0712/143233.549322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1375 0x7fb0908c1070 0x20227e9ac560 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1367 0x7fb0908c1070 0x20227e6f02e0 
[1:1:0712/143233.626360:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1371, 7fb093206881
[1:1:0712/143233.679135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1362 0x7fb0908c1070 0x20227e9ac560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.679462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1362 0x7fb0908c1070 0x20227e9ac560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.679815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.680248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143233.680361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.680691:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.680791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.681003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1378
[1:1:0712/143233.681119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1378 0x7fb0908c1070 0x20227e9ba1e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1371 0x7fb0908c1070 0x20227e9a43e0 
[1:1:0712/143233.681741:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1373, 7fb093206881
[1:1:0712/143233.699749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1365 0x7fb0908c1070 0x20227e99dbe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.699990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1365 0x7fb0908c1070 0x20227e99dbe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.700205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.700522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.700629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.700969:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.701076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.701259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1381
[1:1:0712/143233.701367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1381 0x7fb0908c1070 0x20227e72e4e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1373 0x7fb0908c1070 0x20227e9a5a60 
[1:1:0712/143233.701871:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1375, 7fb093206881
[1:1:0712/143233.721037:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1367 0x7fb0908c1070 0x20227e6f02e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.721236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1367 0x7fb0908c1070 0x20227e6f02e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.721432:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.721754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.721897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.722217:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.722315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.722495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1382
[1:1:0712/143233.722604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1382 0x7fb0908c1070 0x20227e72e9e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1375 0x7fb0908c1070 0x20227e9ac560 
[1:1:0712/143233.854005:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1378, 7fb093206881
[1:1:0712/143233.909488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1371 0x7fb0908c1070 0x20227e9a43e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.909819:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1371 0x7fb0908c1070 0x20227e9a43e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.910209:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.910784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143233.910983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.911674:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.911834:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.912277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1387
[1:1:0712/143233.912470:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1387 0x7fb0908c1070 0x20227e6e85e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1378 0x7fb0908c1070 0x20227e9ba1e0 
[1:1:0712/143233.914162:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1381, 7fb093206881
[1:1:0712/143233.976197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1373 0x7fb0908c1070 0x20227e9a5a60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.976520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1373 0x7fb0908c1070 0x20227e9a5a60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143233.976874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143233.977467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143233.977656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143233.978369:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143233.978531:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143233.978928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1389
[1:1:0712/143233.979127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1389 0x7fb0908c1070 0x20227e99dbe0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1381 0x7fb0908c1070 0x20227e72e4e0 
[1:1:0712/143233.980756:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1382, 7fb093206881
[1:1:0712/143234.015457:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1375 0x7fb0908c1070 0x20227e9ac560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.015657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1375 0x7fb0908c1070 0x20227e9ac560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.015865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.016644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.016756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.017093:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.017197:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.017410:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1391
[1:1:0712/143234.017518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1391 0x7fb0908c1070 0x20227e7258e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1382 0x7fb0908c1070 0x20227e72e9e0 
[1:1:0712/143234.018034:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1351, 7fb0932068db
[1:1:0712/143234.052724:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1308 0x7fb0908c1070 0x20227ea41d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.053068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1308 0x7fb0908c1070 0x20227ea41d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.053560:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1393
[1:1:0712/143234.053769:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1393 0x7fb0908c1070 0x20227dd669e0 , 5:3_http://news.duowan.com/, 0, , 1351 0x7fb0908c1070 0x20227e3df660 
[1:1:0712/143234.054113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.054648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143234.054821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.110218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1387, 7fb093206881
[1:1:0712/143234.163622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1378 0x7fb0908c1070 0x20227e9ba1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.163941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1378 0x7fb0908c1070 0x20227e9ba1e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.164341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.164905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143234.165159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.165871:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.166048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.166434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1395
[1:1:0712/143234.166625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1395 0x7fb0908c1070 0x20227e9b39e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1387 0x7fb0908c1070 0x20227e6e85e0 
[1:1:0712/143234.168284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1389, 7fb093206881
[1:1:0712/143234.222186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1381 0x7fb0908c1070 0x20227e72e4e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.222512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1381 0x7fb0908c1070 0x20227e72e4e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.222875:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.223460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.223641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.224459:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.224668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.225160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1398
[1:1:0712/143234.225399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1398 0x7fb0908c1070 0x20227e72ee60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1389 0x7fb0908c1070 0x20227e99dbe0 
[1:1:0712/143234.227431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1391, 7fb093206881
[1:1:0712/143234.252579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1382 0x7fb0908c1070 0x20227e72e9e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.252944:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1382 0x7fb0908c1070 0x20227e72e9e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.253378:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.254157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.254391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.255259:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.255456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.255925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1400
[1:1:0712/143234.256240:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1400 0x7fb0908c1070 0x20227ea3d760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1391 0x7fb0908c1070 0x20227e7258e0 
[1:1:0712/143234.304348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1395, 7fb093206881
[1:1:0712/143234.320946:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1387 0x7fb0908c1070 0x20227e6e85e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.321132:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1387 0x7fb0908c1070 0x20227e6e85e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.321316:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.321624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143234.321730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.322073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.322187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.322369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1402
[1:1:0712/143234.322475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1402 0x7fb0908c1070 0x20227e6f7d60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1395 0x7fb0908c1070 0x20227e9b39e0 
[1:1:0712/143234.380093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1398, 7fb093206881
[1:1:0712/143234.431181:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1389 0x7fb0908c1070 0x20227e99dbe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.431391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1389 0x7fb0908c1070 0x20227e99dbe0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.431593:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.431914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.432075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.432404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.432505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.432695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1405
[1:1:0712/143234.432806:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1405 0x7fb0908c1070 0x20227d5bb8e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1398 0x7fb0908c1070 0x20227e72ee60 
[1:1:0712/143234.433449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1400, 7fb093206881
[1:1:0712/143234.450129:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1391 0x7fb0908c1070 0x20227e7258e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.450292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1391 0x7fb0908c1070 0x20227e7258e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.450468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.450735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.450836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.451156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.451264:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.451431:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1408
[1:1:0712/143234.451534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1408 0x7fb0908c1070 0x20227e6e8060 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1400 0x7fb0908c1070 0x20227ea3d760 
[1:1:0712/143234.452219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1402, 7fb093206881
[1:1:0712/143234.470038:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1395 0x7fb0908c1070 0x20227e9b39e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.470233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1395 0x7fb0908c1070 0x20227e9b39e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.470421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.470724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143234.470835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.471166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.471270:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.471447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1409
[1:1:0712/143234.471555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1409 0x7fb0908c1070 0x20227e9a5e60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1402 0x7fb0908c1070 0x20227e6f7d60 
[1:1:0712/143234.561488:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1405, 7fb093206881
[1:1:0712/143234.618626:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1398 0x7fb0908c1070 0x20227e72ee60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.619018:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1398 0x7fb0908c1070 0x20227e72ee60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.619475:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.620321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.620555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.621446:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.621670:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.622178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1412
[1:1:0712/143234.622428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1412 0x7fb0908c1070 0x20227dfa6660 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1405 0x7fb0908c1070 0x20227d5bb8e0 
[1:1:0712/143234.626259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1408, 7fb093206881
[1:1:0712/143234.682942:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1400 0x7fb0908c1070 0x20227ea3d760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.683298:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1400 0x7fb0908c1070 0x20227ea3d760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.683650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.684267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.684449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.685157:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.685320:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.685702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1415
[1:1:0712/143234.685890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1415 0x7fb0908c1070 0x20227e9ca2e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1408 0x7fb0908c1070 0x20227e6e8060 
[1:1:0712/143234.687480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1409, 7fb093206881
[1:1:0712/143234.742923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1402 0x7fb0908c1070 0x20227e6f7d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.743341:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1402 0x7fb0908c1070 0x20227e6f7d60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.743769:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.744534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143234.744753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.745631:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.745825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.746314:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1417
[1:1:0712/143234.746552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1417 0x7fb0908c1070 0x20227c7eef60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1409 0x7fb0908c1070 0x20227e9a5e60 
[1:1:0712/143234.748638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1412, 7fb093206881
[1:1:0712/143234.806599:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1405 0x7fb0908c1070 0x20227d5bb8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.806916:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1405 0x7fb0908c1070 0x20227d5bb8e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.807290:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.807930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.808146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.808851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.809009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.809410:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1420
[1:1:0712/143234.809606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1420 0x7fb0908c1070 0x20227cdd0de0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1412 0x7fb0908c1070 0x20227dfa6660 
[1:1:0712/143234.878597:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1415, 7fb093206881
[1:1:0712/143234.904699:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1408 0x7fb0908c1070 0x20227e6e8060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.904893:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1408 0x7fb0908c1070 0x20227e6e8060 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.905087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.905417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.905530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.905852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.905950:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.906145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1425
[1:1:0712/143234.906266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7fb0908c1070 0x20227e6e82e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1415 0x7fb0908c1070 0x20227e9ca2e0 
[1:1:0712/143234.906745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1393, 7fb0932068db
[1:1:0712/143234.924008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1351 0x7fb0908c1070 0x20227e3df660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.924208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1351 0x7fb0908c1070 0x20227e3df660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.924417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1426
[1:1:0712/143234.924541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1426 0x7fb0908c1070 0x20227e7342e0 , 5:3_http://news.duowan.com/, 0, , 1393 0x7fb0908c1070 0x20227dd669e0 
[1:1:0712/143234.924714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.924983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143234.925095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.925627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1417, 7fb093206881
[1:1:0712/143234.942682:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1409 0x7fb0908c1070 0x20227e9a5e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.942842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1409 0x7fb0908c1070 0x20227e9a5e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.943017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.943329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143234.943437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.943738:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.943836:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.944056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1428
[1:1:0712/143234.944208:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1428 0x7fb0908c1070 0x20227e6f0b60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1417 0x7fb0908c1070 0x20227c7eef60 
[1:1:0712/143234.944676:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1420, 7fb093206881
[1:1:0712/143234.967591:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1412 0x7fb0908c1070 0x20227dfa6660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.967772:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1412 0x7fb0908c1070 0x20227dfa6660 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143234.967956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143234.968345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143234.968458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143234.968770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143234.968867:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143234.969043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1429
[1:1:0712/143234.969175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1429 0x7fb0908c1070 0x20227e734ae0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1420 0x7fb0908c1070 0x20227cdd0de0 
[1:1:0712/143235.031381:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1425, 7fb093206881
[1:1:0712/143235.048104:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1415 0x7fb0908c1070 0x20227e9ca2e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.048321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1415 0x7fb0908c1070 0x20227e9ca2e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.048515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.048824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143235.048936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.049291:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.049398:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.049587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1431
[1:1:0712/143235.049710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1431 0x7fb0908c1070 0x20227e609360 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1425 0x7fb0908c1070 0x20227e6e82e0 
[1:1:0712/143235.050240:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1428, 7fb093206881
[1:1:0712/143235.067776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1417 0x7fb0908c1070 0x20227c7eef60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.067943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1417 0x7fb0908c1070 0x20227c7eef60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.068124:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.068486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143235.068594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.068903:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.068999:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.069196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1433
[1:1:0712/143235.069322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1433 0x7fb0908c1070 0x20227cb5f260 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1428 0x7fb0908c1070 0x20227e6f0b60 
[1:1:0712/143235.069804:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1429, 7fb093206881
[1:1:0712/143235.086820:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1420 0x7fb0908c1070 0x20227cdd0de0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.086990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1420 0x7fb0908c1070 0x20227cdd0de0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.087169:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.087485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143235.087602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.087898:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.087995:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.088171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1435
[1:1:0712/143235.088347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1435 0x7fb0908c1070 0x20227e71b0e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1429 0x7fb0908c1070 0x20227e734ae0 
[1:1:0712/143235.234696:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1431, 7fb093206881
[1:1:0712/143235.288905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1425 0x7fb0908c1070 0x20227e6e82e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.289223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1425 0x7fb0908c1070 0x20227e6e82e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.289600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.290195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143235.290454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.291204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.291390:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.291772:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1439
[1:1:0712/143235.291963:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1439 0x7fb0908c1070 0x20227e609e60 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1431 0x7fb0908c1070 0x20227e609360 
[1:1:0712/143235.293589:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1433, 7fb093206881
[1:1:0712/143235.348280:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1428 0x7fb0908c1070 0x20227e6f0b60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.348562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1428 0x7fb0908c1070 0x20227e6f0b60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.348899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.349459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143235.349639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.350341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.350503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.350873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1441
[1:1:0712/143235.351074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1441 0x7fb0908c1070 0x20227d5c4760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1433 0x7fb0908c1070 0x20227cb5f260 
[1:1:0712/143235.352751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1435, 7fb093206881
[1:1:0712/143235.406924:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1429 0x7fb0908c1070 0x20227e734ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.407215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1429 0x7fb0908c1070 0x20227e734ae0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.407622:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.408224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143235.408467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.409147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.409334:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.409715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1443
[1:1:0712/143235.409903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1443 0x7fb0908c1070 0x20227dd67960 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1435 0x7fb0908c1070 0x20227e71b0e0 
[1:1:0712/143235.411555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1439, 7fb093206881
[1:1:0712/143235.466125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1431 0x7fb0908c1070 0x20227e609360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.466458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1431 0x7fb0908c1070 0x20227e609360 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.466813:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.467391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143235.467572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.468256:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.468465:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.468857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1446
[1:1:0712/143235.469051:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1446 0x7fb0908c1070 0x20227dd67760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1439 0x7fb0908c1070 0x20227e609e60 
[1:1:0712/143235.526653:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1441, 7fb093206881
[1:1:0712/143235.583311:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1433 0x7fb0908c1070 0x20227cb5f260 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.583645:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1433 0x7fb0908c1070 0x20227cb5f260 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.584004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.584618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143235.584814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.585647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.585877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.586444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1450
[1:1:0712/143235.586730:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1450 0x7fb0908c1070 0x20227e6f7760 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1441 0x7fb0908c1070 0x20227d5c4760 
[1:1:0712/143235.588990:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1443, 7fb093206881
[1:1:0712/143235.646931:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1435 0x7fb0908c1070 0x20227e71b0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.647264:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1435 0x7fb0908c1070 0x20227e71b0e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.647723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[24593:24614:0712/143235.648033:ERROR:connection.cc(1888)] Cookie sqlite error 2067, errno 0: UNIQUE constraint failed: cookies.host_key, cookies.name, cookies.path, sql: INSERT INTO cookies (creation_utc, host_key, name, value, encrypted_value, path, expires_utc, is_secure, is_httponly, firstpartyonly, last_access_utc, has_expires, is_persistent, priority) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
[24593:24614:0712/143235.648135:WARNING:sqlite_persistent_cookie_store.cc(1332)] Could not add a cookie to the DB.
[1:1:0712/143235.648395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[24593:24614:0712/143235.648495:ERROR:connection.cc(1888)] Cookie sqlite error 2067, errno 0: UNIQUE constraint failed: cookies.host_key, cookies.name, cookies.path, sql: INSERT INTO cookies (creation_utc, host_key, name, value, encrypted_value, path, expires_utc, is_secure, is_httponly, firstpartyonly, last_access_utc, has_expires, is_persistent, priority) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
[24593:24614:0712/143235.648592:WARNING:sqlite_persistent_cookie_store.cc(1332)] Could not add a cookie to the DB.
[1:1:0712/143235.648589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.649279:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.649466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.649849:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1453
[1:1:0712/143235.650041:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7fb0908c1070 0x20227dd18560 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1443 0x7fb0908c1070 0x20227dd67960 
[1:1:0712/143235.651636:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1446, 7fb093206881
[1:1:0712/143235.707486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1439 0x7fb0908c1070 0x20227e609e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.707837:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1439 0x7fb0908c1070 0x20227e609e60 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.708196:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.708822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143235.709004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.709713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.709876:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.710257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1455
[1:1:0712/143235.710508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1455 0x7fb0908c1070 0x20227e6cb6e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1446 0x7fb0908c1070 0x20227dd67760 
[1:1:0712/143235.712133:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1450, 7fb093206881
[1:1:0712/143235.778235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1441 0x7fb0908c1070 0x20227d5c4760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.778556:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1441 0x7fb0908c1070 0x20227d5c4760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143235.778945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143235.779583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143235.779768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143235.780499:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143235.780703:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143235.781252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1461
[1:1:0712/143235.781462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1461 0x7fb0908c1070 0x20227e72e4e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1450 0x7fb0908c1070 0x20227e6f7760 
[24593:24593:0712/143235.783695:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/143235.884264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143235.884461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.133098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1453, 7fb093206881
[1:1:0712/143236.151486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1443 0x7fb0908c1070 0x20227dd67960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.151748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1443 0x7fb0908c1070 0x20227dd67960 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.152023:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143236.152556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143236.152785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.153252:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143236.153391:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143236.153670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1479
[1:1:0712/143236.153822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1479 0x7fb0908c1070 0x20227c2a88e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1453 0x7fb0908c1070 0x20227dd18560 
[1:1:0712/143236.154662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1455, 7fb093206881
[1:1:0712/143236.218001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1446 0x7fb0908c1070 0x20227dd67760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.218314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1446 0x7fb0908c1070 0x20227dd67760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.218733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143236.219339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143236.219570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.220279:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143236.220436:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143236.220861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1480
[1:1:0712/143236.221052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1480 0x7fb0908c1070 0x20227c2c0ae0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1455 0x7fb0908c1070 0x20227e6cb6e0 
[1:1:0712/143236.278973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1426, 7fb0932068db
[1:1:0712/143236.335002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1393 0x7fb0908c1070 0x20227dd669e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.335277:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1393 0x7fb0908c1070 0x20227dd669e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.335704:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1483
[1:1:0712/143236.335902:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1483 0x7fb0908c1070 0x20227dd18f60 , 5:3_http://news.duowan.com/, 0, , 1426 0x7fb0908c1070 0x20227e7342e0 
[1:1:0712/143236.336211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143236.336859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143236.337062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.395694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143236.395937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.399760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1461, 7fb093206881
[1:1:0712/143236.456220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1450 0x7fb0908c1070 0x20227e6f7760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.456550:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1450 0x7fb0908c1070 0x20227e6f7760 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.456939:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143236.457533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143236.457713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.458407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143236.458582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143236.458965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1488
[1:1:0712/143236.459154:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1488 0x7fb0908c1070 0x20227ea3d2e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1461 0x7fb0908c1070 0x20227e72e4e0 
[1:1:0712/143236.755826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1479, 7fb093206881
[1:1:0712/143236.812860:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1453 0x7fb0908c1070 0x20227dd18560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.813166:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1453 0x7fb0908c1070 0x20227dd18560 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.813575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143236.814255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143236.814431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.815143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143236.815312:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143236.815702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1497
[1:1:0712/143236.815911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1497 0x7fb0908c1070 0x20227e9c27e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1479 0x7fb0908c1070 0x20227c2a88e0 
[1:1:0712/143236.869892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1480, 7fb093206881
[1:1:0712/143236.889652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1455 0x7fb0908c1070 0x20227e6cb6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.889937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1455 0x7fb0908c1070 0x20227e6cb6e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143236.890336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143236.890926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/143236.891105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.891832:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143236.891993:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143236.892364:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1500
[1:1:0712/143236.892551:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1500 0x7fb0908c1070 0x20227e9c63e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1480 0x7fb0908c1070 0x20227c2c0ae0 
[1:1:0712/143236.957328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0712/143236.957568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143236.961885:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1488, 7fb093206881
[1:1:0712/143237.020471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3e0114742860","ptid":"1461 0x7fb0908c1070 0x20227e72e4e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143237.020801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.duowan.com/","ptid":"1461 0x7fb0908c1070 0x20227e72e4e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143237.021153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143237.021611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , a, (){clearTimeout(x);var d;z&&(d="visible"==document[z]);u&&(d=!document[u]);m="undefined"==typeof d?s
[1:1:0712/143237.021818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0712/143237.022317:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12fc2df229c8, 0x20227c12f150
[1:1:0712/143237.022467:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.duowan.com/1907/426683510504.html", 100
[1:1:0712/143237.022865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.duowan.com/, 1505
[1:1:0712/143237.023042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1505 0x7fb0908c1070 0x20227e9d02e0 , 5:3_http://news.duowan.com/, 1, -5:3_http://news.duowan.com/, 1488 0x7fb0908c1070 0x20227ea3d2e0 
[1:1:0712/143237.095378:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1483, 7fb0932068db
[1:1:0712/143237.113970:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1426 0x7fb0908c1070 0x20227e7342e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143237.114137:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1426 0x7fb0908c1070 0x20227e7342e0 ","rf":"5:3_http://news.duowan.com/"}
[1:1:0712/143237.114397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.duowan.com/, 1511
[1:1:0712/143237.114512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1511 0x7fb0908c1070 0x20227e9b31e0 , 5:3_http://news.duowan.com/, 0, , 1483 0x7fb0908c1070 0x20227dd18f60 
[1:1:0712/143237.114700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.duowan.com/1907/426683510504.html"
[1:1:0712/143237.115007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , , (){document.hasFocus()&&s++}
[1:1:0712/143237.115109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
[1:1:0100/000000.154464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.duowan.com/, 3e0114742860, , i, (){var o=new Date,r=o-n._ltStart;n.data.lt=n.data.lt+r,n._inactiveTime=n._inactiveTime+r,n._ltStart=
[1:1:0100/000000.166362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.duowan.com/1907/426683510504.html", "news.duowan.com", 3, 1, , , 0
