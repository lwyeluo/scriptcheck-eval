[0712/024400.004917:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/024400.005342:INFO:switcher_clone.cc(787)] backtrace rip is 7fa82c7f2891
[0712/024400.873488:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/024400.873918:INFO:switcher_clone.cc(787)] backtrace rip is 7f31e9820891
[1:1:0712/024400.880822:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/024400.881006:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/024400.886128:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/024402.122693:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/024402.123006:INFO:switcher_clone.cc(787)] backtrace rip is 7f9f273ee891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[63102:63102:0712/024402.307525:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[63133:63133:0712/024402.358503:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=63133
[63143:63143:0712/024402.358925:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=63143

DevTools listening on ws://127.0.0.1:9222/devtools/browser/08406a3b-60f4-4936-a460-e82f04d78f29
[63102:63102:0712/024402.927046:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[63102:63131:0712/024402.927840:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/024402.928084:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/024402.928329:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/024402.929052:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/024402.929256:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/024402.932265:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x23f189a9, 1
[1:1:0712/024402.932645:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x348f13ff, 0
[1:1:0712/024402.932839:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x41aa2c7, 3
[1:1:0712/024402.933060:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x58ea3be, 2
[1:1:0712/024402.933285:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffff13ffffff8f34 ffffffa9ffffff89fffffff123 ffffffbeffffffa3ffffff8e05 ffffffc7ffffffa21a04 , 10104, 4
[1:1:0712/024402.934329:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[63102:63131:0712/024402.934611:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��4���#���Ǣ=7q2
[63102:63131:0712/024402.934682:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��4���#���Ǣ؂=7q2
[1:1:0712/024402.934592:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f31e7a5b0a0, 3
[63102:63131:0712/024402.934957:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/024402.934832:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f31e7be6080, 2
[63102:63131:0712/024402.935059:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 63153, 4, ff138f34 a989f123 bea38e05 c7a21a04 
[1:1:0712/024402.935076:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f31d18a9d20, -2
[1:1:0712/024402.955444:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/024402.956640:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 58ea3be
[1:1:0712/024402.957814:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 58ea3be
[1:1:0712/024402.959702:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 58ea3be
[1:1:0712/024402.961398:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.961591:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.961762:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.961961:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.962598:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 58ea3be
[1:1:0712/024402.962905:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f31e98207ba
[1:1:0712/024402.963085:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f31e9817def, 7f31e982077a, 7f31e98220cf
[1:1:0712/024402.969083:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 58ea3be
[1:1:0712/024402.969520:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 58ea3be
[1:1:0712/024402.970296:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 58ea3be
[1:1:0712/024402.972354:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.972554:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.972753:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.972946:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 58ea3be
[1:1:0712/024402.974237:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 58ea3be
[1:1:0712/024402.974595:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f31e98207ba
[1:1:0712/024402.974731:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f31e9817def, 7f31e982077a, 7f31e98220cf
[1:1:0712/024402.982941:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/024402.983480:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/024402.983679:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcd8573ee8, 0x7ffcd8573e68)
[1:1:0712/024403.002466:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/024403.011057:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[63102:63102:0712/024403.557743:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[63102:63102:0712/024403.558402:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[63102:63112:0712/024403.565221:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[63102:63112:0712/024403.565311:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[63102:63102:0712/024403.565482:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[63102:63102:0712/024403.565562:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[63102:63102:0712/024403.565706:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,63153, 4
[1:7:0712/024403.586400:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[63102:63124:0712/024403.620088:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/024403.759761:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x35e22e539220
[1:1:0712/024403.760065:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/024404.027898:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[63102:63102:0712/024405.421591:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[63102:63102:0712/024405.421709:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/024405.434365:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024405.437922:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024406.552972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 125eb5c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/024406.553237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024406.569384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 125eb5c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/024406.569641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024406.599452:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024406.964021:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024406.964239:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024407.504865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 350, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024407.514879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 125eb5c81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/024407.515176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024407.540358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024407.548526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 125eb5c81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/024407.548832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024407.563868:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[63102:63102:0712/024407.566871:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/024407.567535:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x35e22e537e20
[1:1:0712/024407.567709:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[63102:63102:0712/024407.575572:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[63102:63102:0712/024407.605271:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[63102:63102:0712/024407.605478:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/024407.686085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024408.463862:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f31d34842e0 0x35e22e6ba0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024408.464579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 125eb5c81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/024408.464702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024408.465251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[63102:63102:0712/024408.510411:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/024408.512013:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x35e22e538820
[1:1:0712/024408.512244:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[63102:63102:0712/024408.521335:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/024408.531540:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/024408.531694:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[63102:63102:0712/024408.543447:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[63102:63102:0712/024408.555231:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[63102:63102:0712/024408.556276:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[63102:63102:0712/024408.564185:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[63102:63102:0712/024408.564270:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[63102:63112:0712/024408.564301:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[63102:63112:0712/024408.564383:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[63102:63102:0712/024408.564402:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,63153, 4
[1:7:0712/024408.565853:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/024409.131052:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/024409.556604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7f31d34842e0 0x35e22e8702e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024409.557608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 125eb5c81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/024409.557849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024409.558593:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[63102:63102:0712/024409.723850:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[63102:63102:0712/024409.723969:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/024409.751576:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024409.988059:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[63102:63102:0712/024410.091845:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[63102:63131:0712/024410.092723:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/024410.093052:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/024410.093519:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/024410.094311:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/024410.094667:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/024410.099812:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x229a306c, 1
[1:1:0712/024410.100390:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x7a2d197, 0
[1:1:0712/024410.100689:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x183ad492, 3
[1:1:0712/024410.100973:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3ea1d43e, 2
[1:1:0712/024410.101254:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff97ffffffd1ffffffa207 6c30ffffff9a22 3effffffd4ffffffa13e ffffff92ffffffd43a18 , 10104, 5
[1:1:0712/024410.102627:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[63102:63131:0712/024410.103162:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Ѣl0�">ԡ>��:�7q2
[63102:63131:0712/024410.103511:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Ѣl0�">ԡ>��:��7q2
[1:1:0712/024410.103104:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f31e7a5b0a0, 3
[1:1:0712/024410.103745:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f31e7be6080, 2
[63102:63131:0712/024410.103936:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 63198, 5, 97d1a207 6c309a22 3ed4a13e 92d43a18 
[1:1:0712/024410.104094:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f31d18a9d20, -2
[1:1:0712/024410.130550:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/024410.130934:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3ea1d43e
[1:1:0712/024410.131349:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3ea1d43e
[1:1:0712/024410.132108:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3ea1d43e
[1:1:0712/024410.133872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.134131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.134372:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.134596:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.135420:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3ea1d43e
[1:1:0712/024410.135775:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f31e98207ba
[1:1:0712/024410.135935:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f31e9817def, 7f31e982077a, 7f31e98220cf
[1:1:0712/024410.142873:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3ea1d43e
[1:1:0712/024410.143322:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3ea1d43e
[1:1:0712/024410.144265:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3ea1d43e
[1:1:0712/024410.146773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.147026:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.147281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.147509:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ea1d43e
[1:1:0712/024410.149082:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3ea1d43e
[1:1:0712/024410.149545:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f31e98207ba
[1:1:0712/024410.149706:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f31e9817def, 7f31e982077a, 7f31e98220cf
[1:1:0712/024410.159243:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/024410.159824:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/024410.160003:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcd8573ee8, 0x7ffcd8573e68)
[1:1:0712/024410.175930:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/024410.180825:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/024410.377322:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x35e22e4bf220
[1:1:0712/024410.377479:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/024410.468129:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024410.468437:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[63102:63102:0712/024410.815915:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[63102:63102:0712/024410.822517:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[63102:63112:0712/024410.858180:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[63102:63112:0712/024410.858317:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[63102:63102:0712/024410.858690:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://tieba.baidu.com/
[63102:63102:0712/024410.858771:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://tieba.baidu.com/, http://tieba.baidu.com/f?kw=miui, 1
[63102:63102:0712/024410.858925:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://tieba.baidu.com/, HTTP/1.1 200 OK Connection: keep-alive Content-Encoding: gzip Content-Type: text/html; charset=UTF-8 Date: Fri, 12 Jul 2019 09:44:05 GMT Server: Apache Set-Cookie: TIEBA_USERTYPE=d5f69cb65eae38354cc72545; expires=Thu, 31-Dec-2020 15:59:59 GMT; path=/; domain=tieba.baidu.com Tracecode: 26458227880690305546071217 Tracecode: 26458227880637286666071217 Vary: Accept-Encoding X-Bd-Id: 11494541884105723206 X-Bd-Oc: 0 X-Bd-Ul: 45370c1686822a2fc477999c28d7365a X-Tb-Frs: pcfrsui X-Xss-Protection: 1; mode=block Transfer-Encoding: chunked  ,63198, 5
[1:7:0712/024410.862959:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/024410.894176:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://tieba.baidu.com/
[63102:63102:0712/024411.066368:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://tieba.baidu.com/, http://tieba.baidu.com/, 1
[63102:63102:0712/024411.066475:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://tieba.baidu.com/, http://tieba.baidu.com
[1:1:0712/024411.080878:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/024411.085411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 125eb5db09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/024411.085687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/024411.093395:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/024411.103306:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024411.241329:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024411.316900:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024411.317157:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024411.354848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 117 0x7f31d155c070 0x35e22e23ae60 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024411.358253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , 
    void function(a,b,c,d,e,f,g){a.alogObjectName=e,a[e]=a[e]||function(){(a[e].q=a[e].q||[]).push(
[1:1:0712/024411.358505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024411.364734:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024411.486091:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024411.748590:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/024412.100672:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024412.171403:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024412.293818:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024412.338540:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024412.403157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 181 0x7f31d155c070 0x35e22e652860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024412.403921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , 
    // 页面的基本信息
    var PageData = {
        'tbs': "12c22666dc56864b1562924650"    };
[1:1:0712/024412.404040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024412.406985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 181 0x7f31d155c070 0x35e22e652860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024412.408304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 181 0x7f31d155c070 0x35e22e652860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024412.426306:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0197921, 76, 1
[1:1:0712/024412.426482:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024412.447176:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024412.448058:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024412.487761:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024412.487927:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024412.488352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f31d155c070 0x35e22e6655e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024412.488949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , 
if (window.alog && window.alog.fire) {
    alog('speed.set', 'c_widget_search_show', +new Date);
  
[1:1:0712/024412.489060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024412.538845:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024412.564793:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024412.565337:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024412.565720:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024412.566162:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024412.566508:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024412.675236:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024413.041161:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024413.083919:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024413.185477:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024413.337841:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024413.480442:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024413.543732:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 258 0x7f31d34842e0 0x35e22e665be0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024413.547160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , void function(a,b){function c(a){var c=D.get("alias")||{},d=c[a]||a+".js";if(!y[d]){y[d]=!0;var e="s
[1:1:0712/024413.547391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024413.817992:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024413.918775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 277 0x7f31d34842e0 0x35e22e668be0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024413.941196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , (function(){var h={},mt={},c={id:"98b9d8c2fd6608d564bf2ac2ae642948",dm:["tieba.baidu.com"],js:"tongj
[1:1:0712/024413.941492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024413.964075:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348190
[1:1:0712/024413.964330:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024413.964767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 282
[1:1:0712/024413.965001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 282 0x7f31d155c070 0x35e22e6d9760 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 277 0x7f31d34842e0 0x35e22e668be0 
[63102:63102:0712/024432.002140:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/024432.032743:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/024432.667174:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 600000
[1:1:0712/024432.667633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://tieba.baidu.com/, 339
[1:1:0712/024432.667898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 339 0x7f31d155c070 0x35e22e6d9e60 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 277 0x7f31d34842e0 0x35e22e668be0 
[1:1:0712/024432.756689:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024432.818078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/024432.818356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024433.267651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 282, 7f31d3ea1881
[1:1:0712/024433.284075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"277 0x7f31d34842e0 0x35e22e668be0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024433.284398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"277 0x7f31d34842e0 0x35e22e668be0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024433.284775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024433.285355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/024433.285592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024433.286423:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348150
[1:1:0712/024433.286632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024433.287057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 366
[1:1:0712/024433.287290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 366 0x7f31d155c070 0x35e22e5d6f60 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 282 0x7f31d155c070 0x35e22e6d9760 
[1:1:0712/024433.346295:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024433.494695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , document.readyState
[1:1:0712/024433.495021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024433.805131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 366, 7f31d3ea1881
[1:1:0712/024433.817564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"282 0x7f31d155c070 0x35e22e6d9760 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024433.817901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"282 0x7f31d155c070 0x35e22e6d9760 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024433.818365:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024433.818971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/024433.819186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024433.819872:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348150
[1:1:0712/024433.820099:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024433.820479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 396
[1:1:0712/024433.820712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 396 0x7f31d155c070 0x35e22e8e77e0 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 366 0x7f31d155c070 0x35e22e5d6f60 
[1:1:0712/024433.984119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , document.readyState
[1:1:0712/024433.984406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024434.120090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024434.166794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , window.Promise||function(){"use strict";function t(t){return"function"==typeof t||"object"==typeof t
[1:1:0712/024434.167142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024434.936442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.139752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.154651:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.162211:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.201366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.241996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.270915:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.294033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.308075:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.339260:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.400506:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f31d18c4bd0 0x35e22e666c58 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.467428:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.533939, 19, 0
[1:1:0712/024435.468082:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024435.534661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 396, 7f31d3ea1881
[1:1:0712/024435.555529:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"366 0x7f31d155c070 0x35e22e5d6f60 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024435.555855:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"366 0x7f31d155c070 0x35e22e5d6f60 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024435.556277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024435.556852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/024435.557077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024435.557961:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348150
[1:1:0712/024435.558185:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024435.558604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 469
[1:1:0712/024435.558831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f31d155c070 0x35e22f08f460 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 396 0x7f31d155c070 0x35e22e8e77e0 
[1:1:0712/024435.614817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , document.readyState
[1:1:0712/024435.615469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024436.818985:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024436.819268:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.821827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.822682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , Bigpipe.register("frs-list/pagelet/content", {"parent":"frs-base\/pagelet\/content","scripts":[],"st
[1:1:0712/024436.822804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024436.828786:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.834363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.906790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.920154:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.932917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.942648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.948077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.959828:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024436.975247:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.012150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.017713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.029375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.053440:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.069732:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.086557:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.100747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.124152:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.139036:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.157695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.176700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.209722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.229234:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.250925:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.269781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7f31d155c070 0x35e22f16efe0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.373165:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.552477, 51, 0
[1:1:0712/024437.373376:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024437.754953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , document.readyState
[1:1:0712/024437.755131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024437.872511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 469, 7f31d3ea1881
[1:1:0712/024437.906108:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"396 0x7f31d155c070 0x35e22e8e77e0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024437.906483:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"396 0x7f31d155c070 0x35e22e8e77e0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024437.906974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024437.907679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/024437.907903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024437.908784:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348150
[1:1:0712/024437.908988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024437.909522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 622
[1:1:0712/024437.909786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f31d155c070 0x35e22f1d8560 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 469 0x7f31d155c070 0x35e22f08f460 
[1:1:0712/024438.161798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7f31d34842e0 0x35e22e6645e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024438.163392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , try{!function(){function n(){var n=e("FP_LASTTIME");return o(n)?n:0}function e(n){return t(document.
[1:1:0712/024438.163578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024438.164978:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x1f452e5c29c8, 0x35e22e348190
[1:1:0712/024438.165142:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 60000
[1:1:0712/024438.165481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 640
[1:1:0712/024438.165684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7f31d155c070 0x35e22e7c9e60 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 486 0x7f31d34842e0 0x35e22e6645e0 
[1:1:0712/024438.168456:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024438.210865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f31d34842e0 0x35e22e66f060 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024438.226875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"tbui/widget/http_transform",sub:{initial:function(){window.BaiduHttps||(windo
[1:1:0712/024438.227100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024438.354643:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024438.446568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024438.447046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024438.447183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024438.965613:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024438.966052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024438.966166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024438.996089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024438.996488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024438.996595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024439.041145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 499 0x7f31d34842e0 0x35e22f2411e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024439.056157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-footer/pagelet/content_footer",sub:{initial:function(e){var t=$(".editor_
[1:1:0712/024439.056391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024439.117222:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024439.149237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 500 0x7f31d34842e0 0x35e22e72a860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024439.152406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-base/pagelet/content",sub:{initial:function(n){this.initialEvent(n)},init
[1:1:0712/024439.152607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024439.168957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.751156:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024441.751465:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.753468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f31d155c070 0x35e22f5ae860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.754810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , Bigpipe.register("frs-list/pagelet/thread_footer", {"parent":"frs-list\/pagelet\/thread","scripts":[
[1:1:0712/024441.755065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024441.787709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f31d155c070 0x35e22f5ae860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.794770:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024441.818338:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024441.818834:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024441.862132:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f31d155c070 0x35e22f5ae860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.907552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f31d155c070 0x35e22f5ae860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.929062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f31d155c070 0x35e22f5ae860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.953304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f31d155c070 0x35e22f5ae860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.967617:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f31d155c070 0x35e22f5ae860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.989561:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024441.991154:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024442.182824:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x1f452e5c29c8, 0x35e22e3481e0
[1:1:0712/024442.183044:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 300
[1:1:0712/024442.183414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 731
[1:1:0712/024442.183608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7f31d155c070 0x35e22fc33c60 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 597 0x7f31d155c070 0x35e22f5ae860 
[1:1:0712/024442.185455:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x1f452e5c29c8, 0x35e22e3481e0
[1:1:0712/024442.185623:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 300
[1:1:0712/024442.185954:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 733
[1:1:0712/024442.186151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f31d155c070 0x35e22fc171e0 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 597 0x7f31d155c070 0x35e22f5ae860 
[1:1:0712/024442.429985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 601 0x7f31d34842e0 0x35e22f1b55e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024442.453808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"encourage-payment/widget/tdou_view_check",requires:["encourage-payment/widget
[1:1:0712/024442.454067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024442.626360:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1f452e5c29c8, 0x35e22e348588
[1:1:0712/024442.626671:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 3000
[1:1:0712/024442.627144:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 743
[1:1:0712/024442.627430:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7f31d155c070 0x35e22ec5fbe0 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 601 0x7f31d34842e0 0x35e22f1b55e0 
[1:1:0712/024442.636088:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024442.826554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024442.827446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024442.827696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024442.879960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024442.880386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024442.880631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024442.896803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , document.readyState
[1:1:0712/024442.896969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024442.920198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024442.920686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024442.920814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024443.008616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 620 0x7f31d34842e0 0x35e22e669160 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024443.016249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"ueditor/widget/draft",sub:{initial:function(t,i){t=t||window.UE,i=i||window.E
[1:1:0712/024443.016426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024443.112662:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024443.340477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 622, 7f31d3ea1881
[1:1:0712/024443.354536:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"469 0x7f31d155c070 0x35e22f08f460 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024443.354765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"469 0x7f31d155c070 0x35e22f08f460 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024443.355017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024443.355336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/024443.355505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024443.355853:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348150
[1:1:0712/024443.355949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024443.356119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 764
[1:1:0712/024443.356224:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7f31d155c070 0x35e22ed192e0 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 622 0x7f31d155c070 0x35e22f1d8560 
[1:1:0712/024444.199330:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024444.200251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/024444.200487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/024445.464575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024445.465456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024445.465674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024445.548379:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024445.549113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024445.549341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024446.924235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024446.924968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024446.925212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024446.940586:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 731, 7f31d3ea1881
[1:1:0712/024446.959428:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"597 0x7f31d155c070 0x35e22f5ae860 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024446.959779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"597 0x7f31d155c070 0x35e22f5ae860 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024446.960205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024446.960806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , (){t.el.find("#j_head_focus_btn").click(function(){$.stats.track("\u5427\u5934-\u52a0\u5173\u6ce8","
[1:1:0712/024446.961015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024447.011962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 733, 7f31d3ea1881
[1:1:0712/024447.049869:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"597 0x7f31d155c070 0x35e22f5ae860 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024447.050236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"597 0x7f31d155c070 0x35e22f5ae860 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024447.050627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024447.051262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , (){e.el.on("click","a.j_th_tit",function(){var i=$(this);$.stats.track("\u5e16\u5b50\u5217\u8868-\u7
[1:1:0712/024447.051478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024447.085913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 749 0x7f31d34842e0 0x35e22fc1a460 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024447.104733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"tbui/widget/tb_skin",sub:{initial:function(i,s){if(i){var n=["//tb1",".bdstat
[1:1:0712/024447.105010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024447.389496:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024447.427343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 750 0x7f31d34842e0 0x35e22ec67de0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024447.431887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"forum/pagelet/focus_btn",sub:{initial:function(n){this.initialEvent(n)},initi
[1:1:0712/024447.432141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024447.470522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024447.604501:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024447.605353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024447.605570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024447.685319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , document.readyState
[1:1:0712/024447.685603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024447.893884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024447.894634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024447.894853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.013299:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 766 0x7f31d34842e0 0x35e22f3c3ee0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.017328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"entertainment-game/widget/GameRankInHead",requires:["tbui/widget/ScrollPanel"
[1:1:0712/024448.017613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.050007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.097310:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 767 0x7f31d34842e0 0x35e22ffd0ae0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.104003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"navigation/widget/navigator",sub:{initial:function(t,i){this.support=!!(windo
[1:1:0712/024448.104323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.147078:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.369360:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.370098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024448.370315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.461495:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.462201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024448.462449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.543248:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.544040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024448.544340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.651277:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.652073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024448.652335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.667058:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 764, 7f31d3ea1881
[1:1:0712/024448.689469:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"622 0x7f31d155c070 0x35e22f1d8560 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024448.689838:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"622 0x7f31d155c070 0x35e22f1d8560 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024448.690280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.691005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/024448.691238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.691985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348150
[1:1:0712/024448.692211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024448.692616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 921
[1:1:0712/024448.692857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f31d155c070 0x35e22e87b9e0 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 764 0x7f31d155c070 0x35e22ed192e0 
[1:1:0712/024448.721288:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.722038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024448.722255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024448.868491:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024448.869220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024448.869458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024449.101145:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.101925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024449.102162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024449.139251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 787 0x7f31d34842e0 0x35e22fff9560 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.140315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-list/pagelet/thread",sub:{initial:function(t){this.bindData(t)},bindData:
[1:1:0712/024449.140591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024449.156177:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.204209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7f31d34842e0 0x35e22ffe6ae0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.205907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"platform-activity/widget/fullWidthHead",requires:[],sub:{initial:function(){}
[1:1:0712/024449.206170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024449.238178:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.355012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790 0x7f31d34842e0 0x35e22f063d60 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.358596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"tbui/widget/js_redirect",requires:[],sub:{_track:function(e,a,t,o,n){t&&"obje
[1:1:0712/024449.358843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024449.909197:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.945183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 791 0x7f31d34842e0 0x35e22ecd0d60 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024449.946465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-aside/pagelet/base_aside",sub:{initial:function(e){1==e.brandAdsenseSwitc
[1:1:0712/024449.946743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024449.954484:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/024450.102971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 793 0x7f31d34842e0 0x35e22f85a960 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.112068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , window._.Module.define({path:"encourage-celebrity/widget/celebrity_widget",sub:{initial:function(){t
[1:1:0712/024450.112371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024450.192004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.228300:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 794 0x7f31d34842e0 0x35e22ffe9ee0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.229754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-aside/widget/hottopic",sub:{initial:function(t){function e(){var t,e,i=$(
[1:1:0712/024450.229977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024450.237796:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.269153:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x1f452e5c29c8, 0x35e22e348210
[1:1:0712/024450.269411:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 500
[1:1:0712/024450.269822:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 952
[1:1:0712/024450.270050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 952 0x7f31d155c070 0x35e23067ca60 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 794 0x7f31d34842e0 0x35e22ffe9ee0 
[1:1:0712/024450.379895:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 797 0x7f31d34842e0 0x35e22ed19860 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.381641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"adsense-base/widget/tpl_ext",requires:["adsense-base/widget/loader"],sub:{ini
[1:1:0712/024450.381909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024450.404630:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.490624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 798 0x7f31d34842e0 0x35e22faf4ce0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.492549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"platform-base/widget/professional_manager_tips",sub:{initial:function(s){this
[1:1:0712/024450.492799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024450.501063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.559442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 800 0x7f31d34842e0 0x35e22f069c60 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024450.589496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"tbui/widget/LoginDialog",sub:{_config:{apiOpt:{staticPage:$.tb.location.getPr
[1:1:0712/024450.589826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024450.930028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
		remove user.10_9515d246 -> 0
		remove user.11_966bb9d1 -> 0
		remove user.14_bf822bd -> 0
		remove user.12_b926e9bd -> 0
		remove user.13_c21db106 -> 0
		remove user.10_96554726 -> 0
		remove user.11_4903d9a5 -> 0
		remove user.12_41d653 -> 0
		remove user.13_633fc857 -> 0
[1:1:0712/024451.491804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 801 0x7f31d34842e0 0x35e22ffece60 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024451.494165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"tbui/widget/slide_show",sub:{defaultOptions:{delayLoadPic:!1,effect:"slide",a
[1:1:0712/024451.494402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024451.520579:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024451.585455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024451.586243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024451.586462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024451.766600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 808 0x7f31d34842e0 0x35e22f1b56e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024451.771378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , var QianbaoIframeMsg=function(t){this.initial(t)};QianbaoIframeMsg.prototype={sendNotice:null,notice
[1:1:0712/024451.771620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024451.798145:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024451.825709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 809 0x7f31d34842e0 0x35e22e6640e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024451.827171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-aside/widget/zyq",sub:{initial:function(){$(".j_zyq_mod_link").on("click"
[1:1:0712/024451.827415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024451.849728:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024452.148561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 812 0x7f31d34842e0 0x35e22f3f28e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024452.150074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-aside/widget/search_back",sub:{initial:function(e){function a(){var e=$("
[1:1:0712/024452.150298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024452.159626:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024452.214095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 813 0x7f31d34842e0 0x35e22e5d8ee0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024452.222483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , window._.Module.define({path:"encourage-tbguess/widget/mixin",requires:["encourage-payment/widget/ba
[1:1:0712/024452.222847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024452.252662:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024452.334747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 815 0x7f31d34842e0 0x35e22f46bce0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024452.364675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"frs-header/widget/head_main",sub:{initial:function(e){$(".j_brand_forum_still
[1:1:0712/024452.365089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024452.694662:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024453.844585:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 10000
[1:1:0712/024453.845116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://tieba.baidu.com/, 992
[1:1:0712/024453.845387:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 992 0x7f31d155c070 0x35e2311845e0 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 815 0x7f31d34842e0 0x35e22f46bce0 
[63102:63102:0712/024453.990174:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/024454.757080:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 816 0x7f31d34842e0 0x35e22fafe9e0 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024454.768129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , _.Module.define({path:"forum/widget/sign100",requires:["forum/widget/SignShai/FlashImageLoader"],sub
[1:1:0712/024454.768434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024454.881531:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024456.650185:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024456.650622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024456.650833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024457.274214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 743, 7f31d3ea1881
[1:1:0712/024457.299135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"601 0x7f31d34842e0 0x35e22f1b55e0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024457.299494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"601 0x7f31d34842e0 0x35e22f1b55e0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024457.299933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024457.300562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , i, (){$(".gift-goin-left").stop().animate({width:"50px"},3e3),$(".gift-goin-con").stop().animate({width
[1:1:0712/024457.300782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024457.358773:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024457.359505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024457.359734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024458.206759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024458.207471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024458.207659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024459.046263:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 500
[1:1:0712/024459.046673:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://tieba.baidu.com/, 1100
[1:1:0712/024459.046866:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7f31d155c070 0x35e230b84060 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 872 0x7f31d34842e0 0x35e22f1d6660 
[1:1:0712/024459.209529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024459.210236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024459.210416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024459.562307:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024459.562738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024459.562845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024500.176248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , document.readyState
[1:1:0712/024500.176514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024501.019502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 921, 7f31d3ea1881
[1:1:0712/024501.049046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"764 0x7f31d155c070 0x35e22ed192e0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024501.049243:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"764 0x7f31d155c070 0x35e22ed192e0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024501.049480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024501.049797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/024501.049902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024501.050213:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f452e5c29c8, 0x35e22e348150
[1:1:0712/024501.050311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 100
[1:1:0712/024501.050513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 1141
[1:1:0712/024501.050629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1141 0x7f31d155c070 0x35e230040260 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 921 0x7f31d155c070 0x35e22e87b9e0 
[1:1:0712/024501.153298:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024501.154000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r.onload, (){debug&&console.log("stylesheet ["+e+"] loaded"),t()}
[1:1:0712/024501.154199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/024502.913597:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 952, 7f31d3ea1881
[1:1:0712/024502.969281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"794 0x7f31d34842e0 0x35e22ffe9ee0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024502.969601:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"794 0x7f31d34842e0 0x35e22ffe9ee0 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024502.970043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024502.970754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , (){e()}
[1:1:0712/024502.970993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024505.852517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024505.853302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , r, (e,i){var s,u,c,f,d;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=H.noop,pn&&delet
[1:1:0712/024505.853530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024505.854781:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024505.857324:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024505.858006:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x34af109e8448
[1:1:0712/024505.971892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 977 0x7f31d34842e0 0x35e22ffde560 , "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024505.996312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , , !function(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==type
[1:1:0712/024505.996997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
[1:1:0712/024506.331076:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024506.349485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1f452e5c29c8, 0x35e22e348210
[1:1:0712/024506.349736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tieba.baidu.com/f?kw=miui", 5000
[1:1:0712/024506.350123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tieba.baidu.com/, 1294
[1:1:0712/024506.350410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1294 0x7f31d155c070 0x35e232294660 , 5:3_http://tieba.baidu.com/, 1, -5:3_http://tieba.baidu.com/, 977 0x7f31d34842e0 0x35e22ffde560 
[1:1:0712/024513.752828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://tieba.baidu.com/, 1100, 7f31d3ea18db
[1:1:0712/024513.814510:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23e251a42860","ptid":"872 0x7f31d34842e0 0x35e22f1d6660 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024513.814889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tieba.baidu.com/","ptid":"872 0x7f31d34842e0 0x35e22f1d6660 ","rf":"5:3_http://tieba.baidu.com/"}
[1:1:0712/024513.815333:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://tieba.baidu.com/, 1465
[1:1:0712/024513.815563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1465 0x7f31d155c070 0x35e23161ae60 , 5:3_http://tieba.baidu.com/, 0, , 1100 0x7f31d155c070 0x35e230b84060 
[1:1:0712/024513.815957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tieba.baidu.com/f?kw=miui"
[1:1:0712/024513.816508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tieba.baidu.com/, 23e251a42860, , o, (){return e.apply(n,i.concat(D.call(arguments)))}
[1:1:0712/024513.816747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tieba.baidu.com/f?kw=miui", "tieba.baidu.com", 3, 1, , , 0
