[0712/025432.636632:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/025432.636956:INFO:switcher_clone.cc(787)] backtrace rip is 7fc656c60891
[0712/025433.641117:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/025433.641548:INFO:switcher_clone.cc(787)] backtrace rip is 7f018743e891
[1:1:0712/025433.654867:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/025433.655176:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/025433.660508:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/025435.093387:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/025435.093832:INFO:switcher_clone.cc(787)] backtrace rip is 7f3079604891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[64557:64557:0712/025435.253523:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[64589:64589:0712/025435.310144:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=64589
[64599:64599:0712/025435.310556:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=64599

DevTools listening on ws://127.0.0.1:9222/devtools/browser/b4733af0-aabd-493a-9e17-0914fa11d25f
[64557:64557:0712/025435.903762:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[64557:64587:0712/025435.904663:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/025435.904945:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/025435.905163:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/025435.905761:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/025435.905909:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/025435.908841:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x248f64e1, 1
[1:1:0712/025435.909190:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x8d58a38, 0
[1:1:0712/025435.909346:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3e07bc13, 3
[1:1:0712/025435.909518:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ad85ee7, 2
[1:1:0712/025435.909744:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 38ffffff8affffffd508 ffffffe164ffffff8f24 ffffffe75effffffd81a 13ffffffbc073e , 10104, 4
[1:1:0712/025435.910721:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[64557:64587:0712/025435.910921:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING8���d�$�^��>C�
[64557:64587:0712/025435.910996:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 8���d�$�^��>��C�
[1:1:0712/025435.911129:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01856790a0, 3
[64557:64587:0712/025435.911311:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/025435.911328:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0185804080, 2
[64557:64587:0712/025435.911382:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 64609, 4, 388ad508 e1648f24 e75ed81a 13bc073e 
[1:1:0712/025435.911472:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f016f4c7d20, -2
[1:1:0712/025435.929739:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/025435.930600:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ad85ee7
[1:1:0712/025435.931531:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ad85ee7
[1:1:0712/025435.933073:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ad85ee7
[1:1:0712/025435.934520:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.934733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.934910:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.935098:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.935726:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ad85ee7
[1:1:0712/025435.936072:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f018743e7ba
[1:1:0712/025435.936200:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0187435def, 7f018743e77a, 7f01874400cf
[1:1:0712/025435.941751:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ad85ee7
[1:1:0712/025435.942095:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ad85ee7
[1:1:0712/025435.942809:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ad85ee7
[1:1:0712/025435.944882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.945244:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.945426:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.945601:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ad85ee7
[1:1:0712/025435.946799:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ad85ee7
[1:1:0712/025435.947139:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f018743e7ba
[1:1:0712/025435.947269:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0187435def, 7f018743e77a, 7f01874400cf
[1:1:0712/025435.956007:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/025435.956612:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/025435.956814:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5aea2028, 0x7ffd5aea1fa8)
[1:1:0712/025435.973850:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/025435.979709:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[64557:64557:0712/025436.527461:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[64557:64557:0712/025436.528884:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[64557:64557:0712/025436.541188:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[64557:64557:0712/025436.541305:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[64557:64557:0712/025436.541474:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,64609, 4
[64557:64568:0712/025436.559342:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[64557:64568:0712/025436.559440:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/025436.562820:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[64557:64581:0712/025436.582063:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/025436.701501:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1115ddf6220
[1:1:0712/025436.701750:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/025437.100554:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/025438.312931:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025438.314744:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[64557:64557:0712/025438.416018:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[64557:64557:0712/025438.416183:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/025439.124967:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025439.357702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 171f312a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/025439.357944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/025439.386814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 171f312a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/025439.387070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/025439.511395:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025439.511646:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/025440.007983:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/025440.016051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 171f312a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/025440.016261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/025440.053649:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/025440.064164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 171f312a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/025440.064427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/025440.076091:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/025440.079409:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1115ddf4e20
[1:1:0712/025440.079617:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[64557:64557:0712/025440.080605:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[64557:64557:0712/025440.102165:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[64557:64557:0712/025440.140498:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[64557:64557:0712/025440.140680:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/025440.155899:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/025441.119641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f01710a22e0 0x1115e06c5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/025441.120980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 171f312a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/025441.121172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/025441.122623:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[64557:64557:0712/025441.200969:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025441.206881:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1115ddf5820
[1:1:0712/025441.207364:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[64557:64557:0712/025441.224394:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/025441.240646:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/025441.240877:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[64557:64557:0712/025441.253549:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[64557:64557:0712/025441.264121:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[64557:64557:0712/025441.265104:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[64557:64568:0712/025441.270904:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[64557:64568:0712/025441.270992:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[64557:64557:0712/025441.271136:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[64557:64557:0712/025441.271209:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[64557:64557:0712/025441.271340:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,64609, 4
[1:7:0712/025441.274975:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/025441.735730:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/025442.199296:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f01710a22e0 0x1115de2abe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/025442.200431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 171f312a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/025442.200752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/025442.201599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[64557:64557:0712/025442.558995:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[64557:64557:0712/025442.559135:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/025442.569747:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025443.110506:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[64557:64557:0712/025443.368723:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[64557:64587:0712/025443.373381:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/025443.373578:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/025443.374104:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/025443.375148:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/025443.375571:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/025443.382186:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x311f441b, 1
[1:1:0712/025443.383090:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x21c3bbb2, 0
[1:1:0712/025443.383479:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26eac614, 3
[1:1:0712/025443.383818:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x193584fb, 2
[1:1:0712/025443.384179:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb2ffffffbbffffffc321 1b441f31 fffffffbffffff843519 14ffffffc6ffffffea26 , 10104, 5
[1:1:0712/025443.386492:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[64557:64587:0712/025443.386984:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���!D1��5��&q�
[64557:64587:0712/025443.387139:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���!D1��5��&�q�
[1:1:0712/025443.387460:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01856790a0, 3
[64557:64587:0712/025443.387829:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 64654, 5, b2bbc321 1b441f31 fb843519 14c6ea26 
[1:1:0712/025443.387867:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0185804080, 2
[1:1:0712/025443.388401:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f016f4c7d20, -2
[1:1:0712/025443.418899:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/025443.419318:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 193584fb
[1:1:0712/025443.419712:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 193584fb
[1:1:0712/025443.420519:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 193584fb
[1:1:0712/025443.422314:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.422544:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.422768:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.422989:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.423604:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 193584fb
[1:1:0712/025443.423931:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f018743e7ba
[1:1:0712/025443.424101:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0187435def, 7f018743e77a, 7f01874400cf
[1:1:0712/025443.427554:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 193584fb
[1:1:0712/025443.427899:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 193584fb
[1:1:0712/025443.428538:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 193584fb
[1:1:0712/025443.430125:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.430409:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.430615:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.430810:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 193584fb
[1:1:0712/025443.431862:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 193584fb
[1:1:0712/025443.432203:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f018743e7ba
[1:1:0712/025443.432439:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0187435def, 7f018743e77a, 7f01874400cf
[1:1:0712/025443.437586:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/025443.438193:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/025443.438409:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5aea2028, 0x7ffd5aea1fa8)
[1:1:0712/025443.453138:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/025443.457564:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/025443.678961:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1115ddd8220
[1:1:0712/025443.679184:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/025443.908596:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025443.908844:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025444.412350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025444.416930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/025444.417203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025444.425790:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025444.590467:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/025444.591289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 171f312a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/025444.591577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/025444.787060:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025444.791539:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/025444.792131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/025444.792834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025444.897676:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025444.898597:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/025444.898814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/025444.899090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[64557:64557:0712/025445.500900:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[64557:64557:0712/025445.507286:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/025445.538808:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[64557:64568:0712/025445.552311:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[64557:64568:0712/025445.552412:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[64557:64557:0712/025445.552940:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://game.xiaomi.com/
[64557:64557:0712/025445.553035:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://game.xiaomi.com/, http://game.xiaomi.com/, 1
[64557:64557:0712/025445.553192:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://game.xiaomi.com/, HTTP/1.1 200 OK Server: MiWebServer/2.0.2 Date: Fri, 12 Jul 2019 09:54:45 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Origin set-cookie: XSRF-TOKEN=Mp2eFdl4_Cp7GWTO8NjHolbK; path=/ set-cookie: mac=; path=/; expires=Fri, 19 Jul 2019 09:54:45 GMT X-Response-Time: 1216 x-frame-options: SAMEORIGIN x-xss-protection: 1; mode=block x-content-type-options: nosniff x-download-options: noopen x-readtime: 1216 Content-Encoding: gzip  ,64654, 5
[1:7:0712/025445.558955:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/025445.606548:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://game.xiaomi.com/
[1:1:0712/025445.637210:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/025445.692450:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://smallpdf.com/"
[1:1:0712/025445.731664:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[64557:64557:0712/025445.746060:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://game.xiaomi.com/, http://game.xiaomi.com/, 1
[64557:64557:0712/025445.746161:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://game.xiaomi.com/, http://game.xiaomi.com
[1:1:0712/025445.792936:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025445.809640:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025445.814038:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://expedia.com/"
[1:1:0712/025445.830164:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025445.830300:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025445.940997:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://cimaclub.com/"
[1:1:0712/025445.980820:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025445.991301:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025446.011433:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://91jm.com/"
[1:1:0712/025446.119999:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://seasonvar.ru/"
[1:1:0712/025446.178259:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://drom.ru/"
[1:1:0712/025446.221238:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025446.221472:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025446.233942:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025446.234804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/025446.235079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025446.389588:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025446.434147:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025446.650602:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025446.650864:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025446.685544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025446.686463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/025446.686735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025446.840690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025446.841605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/025446.841901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025446.878855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025446.879761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/025446.880104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025446.909519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025446.910413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/025446.910701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025446.953918:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025446.983858:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/025446.984782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 171f313d09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/025446.985078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/025446.992481:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025447.316406:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025447.316671:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025447.550730:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025447.603601:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025447.786558:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025447.786808:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025448.054318:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025448.082758:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025448.193783:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025448.194052:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025448.249863:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0556581, 501, 1
[1:1:0712/025448.250158:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025448.392018:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025448.583860:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025448.584120:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025448.588284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 240 0x7f016f17a070 0x1115df749e0 , "http://game.xiaomi.com/"
[1:1:0712/025448.591274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , ; (function (win, lib) {
	var doc = win.document;
	var docEl = doc.documentElement;
	var os = '';
	v
[1:1:0712/025448.591531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025448.593711:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025448.705564:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025448.737623:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025448.980345:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025449.125424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f016f4e2bd0 0x1115df56058 , "http://game.xiaomi.com/"
[1:1:0712/025449.134791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , /*! jQuery v1.12.4 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0712/025449.135074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025449.549236:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025449.831389:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025449.965858:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f016f4e2bd0 0x1115df64bd8 , "http://game.xiaomi.com/"
[1:1:0712/025449.978220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , /**
 * @license
 * Video.js 5.19.2 <http://videojs.com/>
 * Copyright Brightcove, Inc. <https://www.
[1:1:0712/025449.978497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025450.492651:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63160
[1:1:0712/025450.492955:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025450.493298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 324
[1:1:0712/025450.493523:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 324 0x7f016f17a070 0x1115df731e0 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 306 0x7f016f4e2bd0 0x1115df64bd8 
[1:1:0712/025450.610753:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025450.789155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 324, 7f0171abf881
[1:1:0712/025450.803798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"306 0x7f016f4e2bd0 0x1115df64bd8 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025450.804181:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"306 0x7f016f4e2bd0 0x1115df64bd8 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025450.804561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025450.805157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025450.805374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025450.827739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025450.828073:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025450.828549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 336
[1:1:0712/025450.828781:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 336 0x7f016f17a070 0x1115df4e960 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 324 0x7f016f17a070 0x1115df731e0 
[1:1:0712/025450.846321:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025450.877420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 336, 7f0171abf881
[1:1:0712/025450.892082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"324 0x7f016f17a070 0x1115df731e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025450.892399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"324 0x7f016f17a070 0x1115df731e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025450.892762:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025450.893325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025450.893537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025450.894823:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025450.895037:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025450.895395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 343
[1:1:0712/025450.895621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 343 0x7f016f17a070 0x1115de65ee0 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 336 0x7f016f17a070 0x1115df4e960 
[1:1:0712/025450.943487:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025450.989192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 343, 7f0171abf881
[1:1:0712/025451.005749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"336 0x7f016f17a070 0x1115df4e960 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.006161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"336 0x7f016f17a070 0x1115df4e960 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.006540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025451.007115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025451.007339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025451.008585:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025451.008805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025451.009186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 348
[1:1:0712/025451.009423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 348 0x7f016f17a070 0x1115debe160 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 343 0x7f016f17a070 0x1115de65ee0 
[1:1:0712/025451.045147:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025451.051307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 348, 7f0171abf881
[1:1:0712/025451.056287:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"343 0x7f016f17a070 0x1115de65ee0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.056443:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"343 0x7f016f17a070 0x1115de65ee0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.056635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025451.056971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025451.057097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025451.057547:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025451.057644:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025451.057806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 356
[1:1:0712/025451.057935:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 356 0x7f016f17a070 0x1115df4d3e0 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 348 0x7f016f17a070 0x1115debe160 
[1:1:0712/025451.076832:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025451.101994:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 356, 7f0171abf881
[1:1:0712/025451.111974:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"348 0x7f016f17a070 0x1115debe160 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.112262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"348 0x7f016f17a070 0x1115debe160 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.112601:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025451.113190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025451.113437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025451.114720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025451.114945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025451.115349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 364
[1:1:0712/025451.115596:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7f016f17a070 0x1115df762e0 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 356 0x7f016f17a070 0x1115df4d3e0 
[1:1:0712/025451.165087:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025451.249962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 364, 7f0171abf881
[1:1:0712/025451.272696:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"356 0x7f016f17a070 0x1115df4d3e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.273103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"356 0x7f016f17a070 0x1115df4d3e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025451.273538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025451.274208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025451.274433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025451.275720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025451.275921:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025451.276383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 376
[1:1:0712/025451.276650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 376 0x7f016f17a070 0x1115df68060 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 364 0x7f016f17a070 0x1115df762e0 
[1:1:0712/025451.358878:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025451.395759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f01710a22e0 0x1115df5a4e0 , "http://game.xiaomi.com/"
[1:1:0712/025451.409267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , (function(){var h={},mt={},c={id:"dc5de44cd3734df84e04c9751e18bde9",dm:["game.wali.com"],js:"tongji.
[1:1:0712/025451.409569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025451.458795:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2ff3143829c8, 0x1115dc63190
[1:1:0712/025451.459105:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 100
[1:1:0712/025451.459527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 384
[1:1:0712/025451.459769:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 384 0x7f016f17a070 0x1115df6d6e0 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 372 0x7f01710a22e0 0x1115df5a4e0 
[1:1:0712/025453.659296:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025453.659764:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025453.660160:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025453.660546:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025453.660871:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[64557:64557:0712/025504.142152:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/025504.154977:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/025514.303511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f016f4e2bd0 0x1115def2458 , "http://game.xiaomi.com/"
[1:1:0712/025514.342082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , /**
 * videojs-contrib-hls
 * @version 5.5.3
 * @copyright 2017 Brightcove, Inc
 * @license Apache-2
[1:1:0712/025514.342379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
		remove user.10_89b5d106 -> 0
[1:1:0712/025515.246609:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025515.247129:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025515.433375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f016f4e2bd0 0x1115def2458 , "http://game.xiaomi.com/"
[1:1:0712/025515.711685:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 376, 7f0171abf881
[1:1:0712/025515.733109:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"364 0x7f016f17a070 0x1115df762e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025515.733497:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"364 0x7f016f17a070 0x1115df762e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025515.733918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025515.734498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025515.734724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025515.762526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025515.762799:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025515.763182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 479
[1:1:0712/025515.763443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 479 0x7f016f17a070 0x1115de1cce0 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 376 0x7f016f17a070 0x1115df68060 
[1:1:0712/025515.813401:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025515.837790:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025516.019154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/025516.019507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025517.823536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 384, 7f0171abf881
[1:1:0712/025517.848008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"372 0x7f01710a22e0 0x1115df5a4e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025517.848360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"372 0x7f01710a22e0 0x1115df5a4e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025517.848790:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025517.849396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/025517.849614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025517.850424:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025517.850621:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 100
[1:1:0712/025517.850995:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 503
[1:1:0712/025517.851231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 503 0x7f016f17a070 0x1115df98660 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 384 0x7f016f17a070 0x1115df6d6e0 
[1:1:0712/025518.312794:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025518.313058:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025518.316337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 479, 7f0171abf881
[1:1:0712/025518.341069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"376 0x7f016f17a070 0x1115df68060 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025518.341434:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"376 0x7f016f17a070 0x1115df68060 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025518.341839:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025518.342445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025518.342678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025518.343756:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025518.344008:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025518.344374:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 512
[1:1:0712/025518.344599:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 512 0x7f016f17a070 0x1115f119c60 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 479 0x7f016f17a070 0x1115de1cce0 
[1:1:0712/025518.411075:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025518.437350:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025518.447091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , document.readyState
[1:1:0712/025518.447348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025520.206131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://game.xiaomi.com/"
[1:1:0712/025520.208122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/025520.208380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025520.215857:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 503, 7f0171abf881
[1:1:0712/025520.240718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"384 0x7f016f17a070 0x1115df6d6e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025520.241064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"384 0x7f016f17a070 0x1115df6d6e0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025520.241480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025520.242025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/025520.242235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025520.242901:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025520.243105:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 100
[1:1:0712/025520.243487:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 565
[1:1:0712/025520.243714:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f016f17a070 0x1115defc160 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 503 0x7f016f17a070 0x1115df98660 
[1:1:0712/025520.296996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 512, 7f0171abf881
[1:1:0712/025520.322682:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"479 0x7f016f17a070 0x1115de1cce0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025520.323050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"479 0x7f016f17a070 0x1115de1cce0 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025520.323493:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025520.324060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025520.324307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025520.325552:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025520.325754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025520.326138:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 569
[1:1:0712/025520.326403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f016f17a070 0x1115df98860 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 512 0x7f016f17a070 0x1115f119c60 
[1:1:0712/025520.353182:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025520.353485:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025520.406097:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025520.460289:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025520.485563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , document.readyState
[1:1:0712/025520.485834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025523.161198:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 569, 7f0171abf881
[1:1:0712/025523.192125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"512 0x7f016f17a070 0x1115f119c60 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025523.192461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"512 0x7f016f17a070 0x1115f119c60 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025523.192879:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025523.193469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025523.193690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025523.194764:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025523.195022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025523.195386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 719
[1:1:0712/025523.195612:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f016f17a070 0x1115e350160 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 569 0x7f016f17a070 0x1115df98860 
[1:1:0712/025523.227838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 565, 7f0171abf881
[1:1:0712/025523.258688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"503 0x7f016f17a070 0x1115df98660 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025523.259062:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"503 0x7f016f17a070 0x1115df98660 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025523.259453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025523.260082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/025523.260317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025523.261011:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025523.261207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 100
[1:1:0712/025523.261705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 723
[1:1:0712/025523.261959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7f016f17a070 0x1115df981e0 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 565 0x7f016f17a070 0x1115defc160 
[1:1:0712/025523.425701:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025523.425978:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025523.555006:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025523.620878:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025523.721503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , document.readyState
[1:1:0712/025523.721800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[64557:64557:0712/025526.177862:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/025529.231252:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 719, 7f0171abf881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025529.265076:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"569 0x7f016f17a070 0x1115df98860 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025529.265592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"569 0x7f016f17a070 0x1115df98860 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025529.266106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025529.266851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0712/025529.267166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025529.268610:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025529.268877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 1
[1:1:0712/025529.269353:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 1149
[1:1:0712/025529.269645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1149 0x7f016f17a070 0x1115f96df60 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 719 0x7f016f17a070 0x1115e350160 
[1:1:0712/025529.788470:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 723, 7f0171abf881
[1:1:0712/025529.832229:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28d207762860","ptid":"565 0x7f016f17a070 0x1115defc160 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025529.832657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://game.xiaomi.com/","ptid":"565 0x7f016f17a070 0x1115defc160 ","rf":"5:3_http://game.xiaomi.com/"}
[1:1:0712/025529.833195:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://game.xiaomi.com/"
[1:1:0712/025529.833826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/025529.834091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
[1:1:0712/025529.834821:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2ff3143829c8, 0x1115dc63150
[1:1:0712/025529.835034:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://game.xiaomi.com/", 100
[1:1:0712/025529.835441:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://game.xiaomi.com/, 1190
[1:1:0712/025529.835695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1190 0x7f016f17a070 0x1115f990360 , 5:3_http://game.xiaomi.com/, 1, -5:3_http://game.xiaomi.com/, 723 0x7f016f17a070 0x1115df981e0 
[1:1:0712/025530.454550:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025530.454835:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.xiaomi.com/"
[1:1:0712/025530.675747:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025530.731356:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/025531.108833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.xiaomi.com/, 28d207762860, , , document.readyState
[1:1:0712/025531.109139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.xiaomi.com/", "game.xiaomi.com", 3, 1, , , 0
