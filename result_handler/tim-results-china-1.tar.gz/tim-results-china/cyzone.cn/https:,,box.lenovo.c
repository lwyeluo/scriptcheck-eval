[0713/011046.013397:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011046.013734:INFO:switcher_clone.cc(787)] backtrace rip is 7f826dc07891
[0713/011047.108058:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011047.109646:INFO:switcher_clone.cc(787)] backtrace rip is 7fe74ad80891
[1:1:0713/011047.121386:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/011047.121606:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/011047.128981:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/011048.657574:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011048.657854:INFO:switcher_clone.cc(787)] backtrace rip is 7f223b02e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[32833:32833:0713/011048.831791:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[32866:32866:0713/011048.849439:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=32866
[32876:32876:0713/011048.849910:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=32876

DevTools listening on ws://127.0.0.1:9222/devtools/browser/8061ba4b-605b-47b8-806b-e8f5a5fa3515
[32833:32833:0713/011049.319943:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[32833:32864:0713/011049.320660:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/011049.320878:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011049.321088:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011049.321668:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011049.321858:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/011049.325138:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2696f967, 1
[1:1:0713/011049.325552:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x32b86b69, 0
[1:1:0713/011049.325743:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2758b96b, 3
[1:1:0713/011049.325960:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2b28706b, 2
[1:1:0713/011049.326197:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 696bffffffb832 67fffffff9ffffff9626 6b70282b 6bffffffb95827 , 10104, 4
[1:1:0713/011049.327482:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[32833:32864:0713/011049.327716:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGik�2g��&kp(+k�X'F�%
[32833:32864:0713/011049.327822:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ik�2g��&kp(+k�X'xF�%
[32833:32864:0713/011049.328139:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[32833:32864:0713/011049.328219:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 32886, 4, 696bb832 67f99626 6b70282b 6bb95827 
[1:1:0713/011049.328796:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe748fbb0a0, 3
[1:1:0713/011049.329068:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe749146080, 2
[1:1:0713/011049.329261:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe732e09d20, -2
[1:1:0713/011049.352395:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011049.353482:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b28706b
[1:1:0713/011049.354645:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b28706b
[1:1:0713/011049.356609:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b28706b
[1:1:0713/011049.358469:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.358696:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.358962:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.359200:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.359998:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b28706b
[1:1:0713/011049.360397:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe74ad807ba
[1:1:0713/011049.360560:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe74ad77def, 7fe74ad8077a, 7fe74ad820cf
[1:1:0713/011049.367599:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b28706b
[1:1:0713/011049.368055:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b28706b
[1:1:0713/011049.368969:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b28706b
[1:1:0713/011049.371539:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.371783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.372029:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.372255:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b28706b
[1:1:0713/011049.373828:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b28706b
[1:1:0713/011049.374283:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe74ad807ba
[1:1:0713/011049.374444:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe74ad77def, 7fe74ad8077a, 7fe74ad820cf
[1:1:0713/011049.384119:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011049.384828:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011049.385007:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff54ec8368, 0x7fff54ec82e8)
[1:1:0713/011049.401869:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011049.409265:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[32833:32833:0713/011050.001452:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32833:32833:0713/011050.002861:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32833:32845:0713/011050.026664:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[32833:32845:0713/011050.026766:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[32833:32833:0713/011050.026906:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[32833:32833:0713/011050.027031:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[32833:32833:0713/011050.027177:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,32886, 4
[1:7:0713/011050.032886:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[32833:32856:0713/011050.075776:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/011050.137343:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1123f63b3220
[1:1:0713/011050.137629:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/011050.490951:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/011052.130875:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011052.135051:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[32833:32833:0713/011052.193367:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[32833:32833:0713/011052.193501:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011053.106317:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011053.279947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28cec0c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011053.280274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011053.298372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28cec0c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011053.298689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011053.429569:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011053.429742:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011053.808389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011053.816710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28cec0c21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011053.816962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011053.854786:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011053.863302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28cec0c21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011053.863455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011053.868015:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/011053.871180:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1123f63b1e20
[1:1:0713/011053.871360:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[32833:32833:0713/011053.872976:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[32833:32833:0713/011053.884359:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[32833:32833:0713/011053.901602:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[32833:32833:0713/011053.901697:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011053.956309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011054.754998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fe7349e42e0 0x1123f63b9360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011054.755724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28cec0c21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/011054.755846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011054.756407:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[32833:32833:0713/011054.784147:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/011054.785358:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1123f63b2820
[1:1:0713/011054.785553:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[32833:32833:0713/011054.791002:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/011054.804100:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/011054.804317:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[32833:32833:0713/011054.809852:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[32833:32833:0713/011054.818055:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32833:32833:0713/011054.819434:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32833:32845:0713/011054.826003:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[32833:32845:0713/011054.826086:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[32833:32833:0713/011054.826247:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[32833:32833:0713/011054.826350:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[32833:32833:0713/011054.826485:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,32886, 4
[1:7:0713/011054.829254:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011055.472673:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/011055.843948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fe7349e42e0 0x1123f6744d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011055.844993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28cec0c21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/011055.845275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011055.846083:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[32833:32833:0713/011056.132291:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[32833:32833:0713/011056.132387:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/011056.167367:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[32833:32833:0713/011056.572202:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[32833:32864:0713/011056.572914:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/011056.573277:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011056.573575:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011056.573993:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011056.574132:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/011056.577431:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x6bd76b7, 1
[1:1:0713/011056.578084:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x28637616, 0
[1:1:0713/011056.578424:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x34fba1dc, 3
[1:1:0713/011056.578797:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd4d9202, 2
[1:1:0713/011056.579117:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 16766328 ffffffb776ffffffbd06 02ffffff924d0d ffffffdcffffffa1fffffffb34 , 10104, 5
[1:1:0713/011056.581061:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[32833:32864:0713/011056.581486:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGvc(�v��Mܡ�4}�%
[1:1:0713/011056.581435:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe748fbb0a0, 3
[32833:32864:0713/011056.581634:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is vc(�v��Mܡ�4��}�%
[1:1:0713/011056.581761:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe749146080, 2
[32833:32864:0713/011056.582213:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 32930, 5, 16766328 b776bd06 02924d0d dca1fb34 
[1:1:0713/011056.582117:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe732e09d20, -2
[1:1:0713/011056.601845:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011056.602335:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d4d9202
[1:1:0713/011056.602715:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d4d9202
[1:1:0713/011056.603443:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d4d9202
[1:1:0713/011056.604968:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.605239:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.605501:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.605766:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.606529:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d4d9202
[1:1:0713/011056.606963:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe74ad807ba
[1:1:0713/011056.607178:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe74ad77def, 7fe74ad8077a, 7fe74ad820cf
[1:1:0713/011056.614103:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d4d9202
[1:1:0713/011056.614646:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d4d9202
[1:1:0713/011056.615701:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d4d9202
[1:1:0713/011056.618663:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.619045:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.619345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.619642:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d4d9202
[1:1:0713/011056.621434:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d4d9202
[1:1:0713/011056.621996:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe74ad807ba
[1:1:0713/011056.622235:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe74ad77def, 7fe74ad8077a, 7fe74ad820cf
[1:1:0713/011056.632114:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011056.632648:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011056.632846:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff54ec8368, 0x7fff54ec82e8)
[1:1:0713/011056.646065:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011056.650198:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/011056.670985:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011056.873752:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1123f637b220
[1:1:0713/011056.875044:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/011057.207793:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011057.208124:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011057.443934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011057.449076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 28cec0d4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/011057.449454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011057.458091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011057.573715:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011057.574503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28cec0c21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/011057.574716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[32833:32833:0713/011057.625336:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32833:32833:0713/011057.631732:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32833:32845:0713/011057.672684:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[32833:32845:0713/011057.672786:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[32833:32833:0713/011057.673191:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://box.lenovo.com/
[32833:32833:0713/011057.673277:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://box.lenovo.com/, https://box.lenovo.com/?C=CYB, 1
[32833:32833:0713/011057.673403:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://box.lenovo.com/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 08:10:57 GMT Content-Type: text/html;Charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: acw_tc=7b39758515630054575432630e963b89914aac73826d1866422246cd0285ae;path=/;HttpOnly;Max-Age=2678401 Server: nginx P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" X-Powered-By: LENOVO.CLOUD Set-Cookie: promo_code=CYB; path=/; domain=box.lenovo.com Expires: Thu, 19 Nov 1981 08:52:00 GMT Pragma: no-cache cache-control: no-cache Browser: Chrome X-HIT: zb-v-cld-app-01 Strict-Transport-Security: max-age=86400;  ,32930, 5
[1:7:0713/011057.679053:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011057.724576:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://box.lenovo.com/
[32833:32833:0713/011057.887016:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://box.lenovo.com/, https://box.lenovo.com/, 1
[32833:32833:0713/011057.887174:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://box.lenovo.com/, https://box.lenovo.com
[1:1:0713/011057.896454:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011057.898241:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/011057.898478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 28cec0d4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/011057.898741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011057.901705:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/011057.981229:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011058.022462:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011058.046486:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://box.lenovo.com/?C=CYB"
[1:1:0713/011058.070703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011058.071806:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/011058.072081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 28cec0d4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/011058.072383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011058.120567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 136 0x7fe732abc070 0x1123f64a5560 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011058.123182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'})
[1:1:0713/011058.123418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011058.127657:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011058.518386:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011058.616620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fe7349e42e0 0x1123f654ede0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011058.626554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0713/011058.626802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011058.654244:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151160
[1:1:0713/011058.654559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011058.655034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 223
[1:1:0713/011058.655285:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 223 0x7fe732abc070 0x1123f6547060 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 211 0x7fe7349e42e0 0x1123f654ede0 
[1:1:0713/011058.803555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 223, 7fe735401881
[1:1:0713/011058.814314:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"211 0x7fe7349e42e0 0x1123f654ede0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011058.814863:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"211 0x7fe7349e42e0 0x1123f654ede0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011058.815463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011058.816138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0713/011058.816438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011058.944018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fe732abc070 0x1123f64a27e0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011058.945237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , 
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}

[1:1:0713/011058.945505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011059.199616:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.043781, 112, 1
[1:1:0713/011059.199933:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011059.505108:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011059.505423:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://box.lenovo.com/?C=CYB"
[1:1:0713/011059.514707:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7fe732abc070 0x1123f672f460 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011059.559246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , /*! jQuery v1.10.2 | (c) 2005, 2013 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingUR
[1:1:0713/011059.559646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/011059.825018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7fe732abc070 0x1123f672f460 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011059.826923:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x35247be29c8, 0x1123f61511b0
[1:1:0713/011059.827152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 2500
[1:1:0713/011059.827591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 289
[1:1:0713/011059.827841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 289 0x7fe732abc070 0x1123f6779be0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 250 0x7fe732abc070 0x1123f672f460 
[1:1:0713/011059.902142:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x35247be29c8, 0x1123f61511b0
[1:1:0713/011059.902412:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 2000
[1:1:0713/011059.902829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 295
[1:1:0713/011059.903062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 295 0x7fe732abc070 0x1123f6729160 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 250 0x7fe732abc070 0x1123f672f460 
[1:1:0713/011100.103435:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011100.108306:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011100.108852:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011100.109316:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011100.109730:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011101.104050:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7fe7349e42e0 0x1123f64a9ce0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011101.132183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0713/011101.132485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011101.181651:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151190
[1:1:0713/011101.181958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011101.182553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 341
[1:1:0713/011101.182844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 341 0x7fe732abc070 0x1123f64a7660 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 317 0x7fe7349e42e0 0x1123f64a9ce0 
[1:1:0713/011101.207026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 318 0x7fe7349e42e0 0x1123f64a2fe0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011101.237340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0713/011101.237606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
		remove user.10_2dc48ea0 -> 0
		remove user.10_176ee94c -> 0
		remove user.11_a9f77fbc -> 0
		remove user.12_ae46054a -> 0
		remove user.13_cb252da5 -> 0
		remove user.14_eecad9f4 -> 0
[1:1:0713/011102.007232:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011102.414921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7fe7349e42e0 0x1123f64a4be0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011102.415856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , cb({"ret":false})
[1:1:0713/011102.416083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011102.416996:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011102.482945:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 341, 7fe735401881
[1:1:0713/011102.508987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"317 0x7fe7349e42e0 0x1123f64a9ce0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011102.509793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"317 0x7fe7349e42e0 0x1123f64a9ce0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011102.510180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011102.510778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0713/011102.511005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011102.592597:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011102.592875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011102.593286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 388
[1:1:0713/011102.593575:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7fe732abc070 0x1123f67be860 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 341 0x7fe732abc070 0x1123f64a7660 
[1:1:0713/011102.598064:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011102.598291:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011102.598691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 389
[1:1:0713/011102.598912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 389 0x7fe732abc070 0x1123f6daa1e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 341 0x7fe732abc070 0x1123f64a7660 
[1:1:0713/011102.605932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011102.606153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011102.606550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 390
[1:1:0713/011102.606777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 390 0x7fe732abc070 0x1123f6daf4e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 341 0x7fe732abc070 0x1123f64a7660 
[1:1:0713/011102.613385:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011102.613612:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011102.614093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 391
[1:1:0713/011102.614344:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 391 0x7fe732abc070 0x1123f63cc2e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 341 0x7fe732abc070 0x1123f64a7660 
[1:1:0713/011102.621350:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011102.621579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011102.621948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 392
[1:1:0713/011102.622256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 392 0x7fe732abc070 0x1123f6729ee0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 341 0x7fe732abc070 0x1123f64a7660 
[1:1:0713/011102.630203:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011102.630501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011102.630886:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 393
[1:1:0713/011102.631118:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 393 0x7fe732abc070 0x1123f6dac760 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 341 0x7fe732abc070 0x1123f64a7660 
[1:1:0713/011102.635012:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011102.635202:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011102.635575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 394
[1:1:0713/011102.635822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 394 0x7fe732abc070 0x1123f64a6c60 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 341 0x7fe732abc070 0x1123f64a7660 
[1:1:0713/011103.321503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7fe732e24bd0 0x1123f6544dd8 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.341349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , /**
 * @license
 * Video.js 5.18.4 <http://videojs.com/>
 * Copyright Brightcove, Inc. <https://www.
[1:1:0713/011103.341681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011103.742035:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x35247be29c8, 0x1123f6151160
[1:1:0713/011103.742320:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 1
[1:1:0713/011103.742714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 420
[1:1:0713/011103.742941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 420 0x7fe732abc070 0x1123f6393360 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 387 0x7fe732e24bd0 0x1123f6544dd8 
[1:1:0713/011103.785776:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0371721, 469, 1
[1:1:0713/011103.786051:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011103.799590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 388, 7fe735401881
[1:1:0713/011103.806705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.806977:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.807340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.807902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/011103.808112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011103.811422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 389, 7fe735401881
[1:1:0713/011103.830212:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.830592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.830979:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.831522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/011103.831757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011103.834074:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 390, 7fe735401881
[1:1:0713/011103.852740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.853068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.853442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.854059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/011103.854275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011103.898790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 391, 7fe735401881
[1:1:0713/011103.917331:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.917640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.918043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.918605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/011103.918832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011103.921232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 392, 7fe735401881
[1:1:0713/011103.928118:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.928411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.928778:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.929275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/011103.929483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011103.931735:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 393, 7fe735401881
[1:1:0713/011103.940858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.941144:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.941496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.942052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/011103.942287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011103.979240:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 394, 7fe735401881
[1:1:0713/011103.988822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.989147:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"341 0x7fe732abc070 0x1123f64a7660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011103.989520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011103.990088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/011103.990327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011104.362940:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011104.587780:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011104.588059:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://box.lenovo.com/?C=CYB"
[1:1:0713/011104.588808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7fe732abc070 0x1123f6db6de0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011104.589599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , 


[1:1:0713/011104.589834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011104.669456:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.081311, 387, 1
[1:1:0713/011104.669731:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011104.671820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 420, 7fe735401881
[1:1:0713/011104.693413:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"387 0x7fe732e24bd0 0x1123f6544dd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011104.693751:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"387 0x7fe732e24bd0 0x1123f6544dd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011104.694271:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011104.694883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , q, (){if(h.isReal()){var a=l["default"].getElementsByTagName("video"),b=l["default"].getElementsByTagNa
[1:1:0713/011104.695102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
		remove user.11_9de0d194 -> 0
[1:1:0713/011105.050424:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011105.050690:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 1
[1:1:0713/011105.051099:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 480
[1:1:0713/011105.051329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 480 0x7fe732abc070 0x1123f66fbae0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 420 0x7fe732abc070 0x1123f6393360 
[1:1:0713/011105.055463:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011105.055661:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 1
[1:1:0713/011105.056011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 481
[1:1:0713/011105.056281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7fe732abc070 0x1123f6a4c960 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 420 0x7fe732abc070 0x1123f6393360 
[1:1:0713/011105.137554:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011105.254935:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011105.255198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 1
[1:1:0713/011105.255583:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 482
[1:1:0713/011105.255809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7fe732abc070 0x1123f6daede0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 420 0x7fe732abc070 0x1123f6393360 
[1:1:0713/011105.691280:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011105.691565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 1
[1:1:0713/011105.691957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 483
[1:1:0713/011105.692184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7fe732abc070 0x1123f71be3e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 420 0x7fe732abc070 0x1123f6393360 
[1:1:0713/011106.134064:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011106.134365:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 1
[1:1:0713/011106.134825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 484
[1:1:0713/011106.135069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7fe732abc070 0x1123f7566160 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 420 0x7fe732abc070 0x1123f6393360 
[1:1:0713/011106.167509:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011106.167783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 1
[1:1:0713/011106.168502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 485
[1:1:0713/011106.168804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7fe732abc070 0x1123f69cd3e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 420 0x7fe732abc070 0x1123f6393360 
[1:1:0713/011107.853164:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 250
[1:1:0713/011107.853428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 486
[1:1:0713/011107.853539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 486 0x7fe732abc070 0x1123f7b6e7e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 420 0x7fe732abc070 0x1123f6393360 
[1:1:0713/011108.000711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.001566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0713/011108.001791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011108.083079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.083410:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.083885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , d.dispatcher.d.dispatcher, (b,c){if(!d.disabled){b=h(b);var e=d.handlers[b.type];if(e)for(var f=e.slice(0),g=0,i=f.length;g<i&&
[1:1:0713/011108.084042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011108.405726:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011108.405887:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.407482:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fe732abc070 0x1123f6dba9e0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.413164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , /*! jQuery v1.10.2 | (c) 2005, 2013 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingUR
[1:1:0713/011108.413375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011108.621611:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fe732abc070 0x1123f6dba9e0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.903750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 480, 7fe735401881
[1:1:0713/011108.929518:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011108.929827:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011108.930206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.930727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011108.930901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011108.940461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 481, 7fe735401881
[1:1:0713/011108.963150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011108.963548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011108.963989:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.964647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011108.964867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011108.974358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 482, 7fe735401881
[1:1:0713/011108.996172:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011108.996469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011108.996821:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011108.997384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011108.997537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011109.029968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 483, 7fe735401881
[1:1:0713/011109.054811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.055135:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.055534:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.056035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011109.056231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011109.059599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 484, 7fe735401881
[1:1:0713/011109.087709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.088091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.088559:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.089266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011109.089503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011109.094690:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 485, 7fe735401881
[1:1:0713/011109.108650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.108936:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.109323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.109826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011109.110011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011109.167422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 486, 7fe7354018db
[1:1:0713/011109.174282:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.174451:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"420 0x7fe732abc070 0x1123f6393360 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.174675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 522
[1:1:0713/011109.174792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 522 0x7fe732abc070 0x1123f6546ce0 , 5:3_https://box.lenovo.com/, 0, , 486 0x7fe732abc070 0x1123f7b6e7e0 
[1:1:0713/011109.174945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.175285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011109.175415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011109.177175:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011109.177285:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 2000
[1:1:0713/011109.177456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 523
[1:1:0713/011109.177564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7fe732abc070 0x1123f64a3360 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 486 0x7fe732abc070 0x1123f7b6e7e0 
[1:1:0713/011109.362642:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "stalled", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.363351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , d.dispatcher.d.dispatcher, (b,c){if(!d.disabled){b=h(b);var e=d.handlers[b.type];if(e)for(var f=e.slice(0),g=0,i=f.length;g<i&&
[1:1:0713/011109.363552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:2:0713/011109.565420:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011109.584756:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 521, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.591663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (function(){function p(){this.c="1258671077";this.ca="z";this.Y="";this.V="";this.X="";this.D="15630
[1:1:0713/011109.591898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011109.753057:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 522, 7fe7354018db
[1:1:0713/011109.776424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"486 0x7fe732abc070 0x1123f7b6e7e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.776726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"486 0x7fe732abc070 0x1123f7b6e7e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011109.777182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 555
[1:1:0713/011109.777424:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 555 0x7fe732abc070 0x1123f6dae960 , 5:3_https://box.lenovo.com/, 0, , 522 0x7fe732abc070 0x1123f6546ce0 
[1:1:0713/011109.777751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.778282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011109.778540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011109.826590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.827072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011109.827767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , d.dispatcher.d.dispatcher, (b,c){if(!d.disabled){b=h(b);var e=d.handlers[b.type];if(e)for(var f=e.slice(0),g=0,i=f.length;g<i&&
[1:1:0713/011109.827986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011110.367608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.371615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0713/011110.371830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011110.394886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.582377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.590232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.602444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.613840:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.618060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.694007:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.740904:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 555, 7fe7354018db
[1:1:0713/011110.766618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"522 0x7fe732abc070 0x1123f6546ce0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011110.766946:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"522 0x7fe732abc070 0x1123f6546ce0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011110.767395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 598
[1:1:0713/011110.767616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7fe732abc070 0x1123f7ab18e0 , 5:3_https://box.lenovo.com/, 0, , 555 0x7fe732abc070 0x1123f6dae960 
[1:1:0713/011110.767905:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011110.768396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011110.768580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011111.022423:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011111.022725:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011111.023050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , d.dispatcher.d.dispatcher, (b,c){if(!d.disabled){b=h(b);var e=d.handlers[b.type];if(e)for(var f=e.slice(0),g=0,i=f.length;g<i&&
[1:1:0713/011111.023154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011112.639159:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 598, 7fe7354018db
[1:1:0713/011112.664646:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"555 0x7fe732abc070 0x1123f6dae960 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011112.664877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"555 0x7fe732abc070 0x1123f6dae960 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011112.665250:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 634
[1:1:0713/011112.665439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7fe732abc070 0x1123f7a2bde0 , 5:3_https://box.lenovo.com/, 0, , 598 0x7fe732abc070 0x1123f7ab18e0 
[1:1:0713/011112.665720:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011112.666245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011112.666427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011112.795381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011112.796178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/011112.796407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011112.870224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 523, 7fe735401881
[1:1:0713/011112.895966:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"486 0x7fe732abc070 0x1123f7b6e7e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011112.896233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"486 0x7fe732abc070 0x1123f7b6e7e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011112.896554:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011112.897019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011112.897211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011113.027247:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 615 0x7fe7349e42e0 0x1123f7e2fa60 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011113.030252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (function(){var h={},mt={},c={id:"52c6ec3627dd160fd780297908356375",dm:["box.lenovo.com"],js:"tongji
[1:1:0713/011113.030380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011113.054753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35247be29c8, 0x1123f6151140
[1:1:0713/011113.054953:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 100
[1:1:0713/011113.055302:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 649
[1:1:0713/011113.055488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7fe732abc070 0x1123f7e0e760 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 615 0x7fe7349e42e0 0x1123f7e2fa60 
[32833:32833:0713/011139.574044:INFO:CONSOLE(840)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s95.cnzz.com/z_stat.php?id=1258671077, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://box.lenovo.com/?C=CYB (840)
[32833:32833:0713/011139.574829:INFO:CONSOLE(840)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s95.cnzz.com/z_stat.php?id=1258671077, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://box.lenovo.com/?C=CYB (840)
[32833:32833:0713/011139.580556:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1258671077&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/z_stat.php?id=1258671077 (17)
[32833:32833:0713/011139.581283:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1258671077&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/z_stat.php?id=1258671077 (17)
[32833:32833:0713/011139.587382:INFO:CONSOLE(43)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://care.live800.com/live800/chatClient/script/monitorStatic8.js?v=20190403, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://care.live800.com/live800/chatClient/monitor.js?companyID=85755&configID=114683&codeType=custom&lan=en&ss=1 (43)
[32833:32833:0713/011139.588369:INFO:CONSOLE(43)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://care.live800.com/live800/chatClient/script/monitorStatic8.js?v=20190403, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://care.live800.com/live800/chatClient/monitor.js?companyID=85755&configID=114683&codeType=custom&lan=en&ss=1 (43)
[32833:32833:0713/011139.603734:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/011139.629008:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/011140.887309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011140.887866:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011140.888706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , d.dispatcher.d.dispatcher, (b,c){if(!d.disabled){b=h(b);var e=d.handlers[b.type];if(e)for(var f=e.slice(0),g=0,i=f.length;g<i&&
[1:1:0713/011140.888938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011141.356105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 634, 7fe7354018db
[1:1:0713/011141.387738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"598 0x7fe732abc070 0x1123f7ab18e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011141.388060:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"598 0x7fe732abc070 0x1123f7ab18e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011141.388489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 748
[1:1:0713/011141.388715:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7fe732abc070 0x1123f6dbafe0 , 5:3_https://box.lenovo.com/, 0, , 634 0x7fe732abc070 0x1123f7a2bde0 
[1:1:0713/011141.389039:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011141.389572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011141.389783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011141.722118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011141.728307:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011141.728791:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011141.736338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/011141.736569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011144.611527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 649, 7fe735401881
[1:1:0713/011144.639091:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"615 0x7fe7349e42e0 0x1123f7e2fa60 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011144.666378:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"615 0x7fe7349e42e0 0x1123f7e2fa60 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011144.666973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011144.668265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/011144.668612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011144.669607:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011144.669874:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 100
[1:1:0713/011144.670430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 784
[1:1:0713/011144.670742:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7fe732abc070 0x1123f84a5fe0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 649 0x7fe732abc070 0x1123f7e0e760 
[1:17:0713/011144.755165:ERROR:render_media_log.cc(30)] MediaEvent: MEDIA_ERROR_LOG_ENTRY {"error":"FFmpegDemuxer: no supported streams"}
[1:1:0713/011144.908129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "stalled", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011144.908872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , d.dispatcher.d.dispatcher, (b,c){if(!d.disabled){b=h(b);var e=d.handlers[b.type];if(e)for(var f=e.slice(0),g=0,i=f.length;g<i&&
[1:1:0713/011144.909114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011144.912952:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "suspend", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.071561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 750 0x7fe732e24bd0 0x1123f649dcd8 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.082124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , /*!
 * Live800 Copyright 2019 GoldArmor Technology Inc.
 */
!function(d){if(!d.body||"1"!==d.body.ge
[1:1:0713/011145.082450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011145.167601:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/011145.171668:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1123f843a420
[1:1:0713/011145.171987:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[32833:32833:0713/011145.173585:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[32833:32833:0713/011145.179558:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: lim:share, 5, 4, 
[1:1:0713/011145.193533:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/011145.193780:INFO:render_frame_impl.cc(7019)] 	 [url] = https://box.lenovo.com
[32833:32833:0713/011145.196776:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://box.lenovo.com/
[1:1:0713/011145.207263:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151160
[1:1:0713/011145.207568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011145.208317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 808
[1:1:0713/011145.208576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7fe732abc070 0x1123f7f9b260 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011145.209890:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x35247be29c8, 0x1123f6151160
[1:1:0713/011145.210081:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 3000
[1:1:0713/011145.210473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 809
[1:1:0713/011145.210703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7fe732abc070 0x1123f7e089e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011145.250783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 15000
[1:1:0713/011145.251397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 813
[1:1:0713/011145.251590:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 813 0x7fe732abc070 0x1123f84f5be0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011145.252496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 5000
[1:1:0713/011145.252826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 814
[1:1:0713/011145.253034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7fe732abc070 0x1123f82813e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011145.273797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 750 0x7fe732e24bd0 0x1123f649dcd8 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.294611:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.296223:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151210
[1:1:0713/011145.296397:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011145.296728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 821
[1:1:0713/011145.296974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7fe732abc070 0x1123f7f18860 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011145.297526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.299117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f61511e0
[1:1:0713/011145.299335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011145.299709:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 822
[1:1:0713/011145.299952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 822 0x7fe732abc070 0x1123f7daf9e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011145.301388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.301763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.431345:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011145.432052:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://box.lenovo.com/?C=CYB"
[32833:32833:0713/011145.442618:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32833:32833:0713/011145.448965:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32833:32845:0713/011145.490195:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[32833:32845:0713/011145.490302:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[32833:32833:0713/011145.490468:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://care.live800.com/
[32833:32833:0713/011145.490552:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://care.live800.com/, https://care.live800.com/live800/chatClient/shared.html?companyID=85755&configID=114683, 4
[32833:32833:0713/011145.490695:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://care.live800.com/, HTTP/1.1 200 OK Server: Tengine Date: Sat, 13 Jul 2019 08:11:45 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding ETag: W/"1466-1348588961000" Last-Modified: Tue, 25 Sep 2012 16:02:41 GMT Expires: Sat, 20 Jul 2019 08:11:45 GMT Cache-Control: max-age=604800 Content-Encoding: gzip  ,32930, 5
[1:7:0713/011145.495180:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011146.297934:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 5000
[1:1:0713/011146.298224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 829
[1:1:0713/011146.298342:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7fe732abc070 0x1123f813e860 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011146.306909:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 4000
[1:1:0713/011146.307172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 830
[1:1:0713/011146.307294:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7fe732abc070 0x1123f6daf7e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011146.318612:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 5000
[1:1:0713/011146.318858:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 831
[1:1:0713/011146.318970:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7fe732abc070 0x1123f7fbc5e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011146.333856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 4000
[1:1:0713/011146.334365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 832
[1:1:0713/011146.334636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 832 0x7fe732abc070 0x1123f7f18760 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011146.348214:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011146.409950:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 50
[1:1:0713/011146.410386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 833
[1:1:0713/011146.410583:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7fe732abc070 0x1123f8125660 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 750 0x7fe732e24bd0 0x1123f649dcd8 
[1:1:0713/011146.411900:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011146.462967:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 748, 7fe7354018db
[1:1:0713/011146.476135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"634 0x7fe732abc070 0x1123f7a2bde0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011146.476503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"634 0x7fe732abc070 0x1123f7a2bde0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011146.477044:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 843
[1:1:0713/011146.477308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 843 0x7fe732abc070 0x1123f84f57e0 , 5:3_https://box.lenovo.com/, 0, , 748 0x7fe732abc070 0x1123f6dbafe0 
[1:1:0713/011146.477665:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011146.478319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011146.478544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011146.556746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , document.readyState
[1:1:0713/011146.556998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011146.614423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , () {                    return f.customStyle(a, b, d, c, e)                }
[1:1:0713/011146.614668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011148.230794:ERROR:render_media_log.cc(30)] MediaEvent: PIPELINE_ERROR DEMUXER_ERROR_NO_SUPPORTED_STREAMS
[1:1:0713/011148.233025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 784, 7fe735401881
[1:1:0713/011148.251902:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"649 0x7fe732abc070 0x1123f7e0e760 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011148.252068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"649 0x7fe732abc070 0x1123f7e0e760 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011148.252304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011148.252630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/011148.252757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011148.253132:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011148.253228:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 100
[1:1:0713/011148.253391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 878
[1:1:0713/011148.253496:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 878 0x7fe732abc070 0x1123f84e8f60 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 784 0x7fe732abc070 0x1123f84a5fe0 
[1:1:0713/011148.337368:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011148.338073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/011148.338250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011148.861031:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://care.live800.com/
[1:1:0713/011148.936087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 808, 7fe735401881
[1:1:0713/011148.976334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011148.976714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011148.977166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011148.977818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){e.pageChater=new PageChater,"undefined"!=typeof autoChat&&1==autoChat&&(fn.get("chat_frame")||glo
[1:1:0713/011148.978062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011149.007416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 821, 7fe735401881
[1:1:0713/011149.030387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.030760:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.031249:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011149.031897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0713/011149.032165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011149.148389:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 822, 7fe735401881
[1:1:0713/011149.178376:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.178568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.178806:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011149.179142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0713/011149.179248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011149.193736:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 833, 7fe7354018db
[1:1:0713/011149.214294:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.214488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.214816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 897
[1:1:0713/011149.215063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 897 0x7fe732abc070 0x1123f84cb6e0 , 5:3_https://box.lenovo.com/, 0, , 833 0x7fe732abc070 0x1123f8125660 
[1:1:0713/011149.215362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011149.215884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , () {            return a.apply(b, arguments)        }
[1:1:0713/011149.216111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011149.349746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , document.readyState
[1:1:0713/011149.349930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011149.620235:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 843, 7fe7354018db
[1:1:0713/011149.660336:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"748 0x7fe732abc070 0x1123f6dbafe0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.660612:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"748 0x7fe732abc070 0x1123f6dbafe0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011149.661042:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 904
[1:1:0713/011149.661237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 904 0x7fe732abc070 0x1123f7fc0960 , 5:3_https://box.lenovo.com/, 0, , 843 0x7fe732abc070 0x1123f84f57e0 
[1:1:0713/011149.661504:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011149.662006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011149.662301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011149.970631:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011149.971330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , () {            return a.apply(b, arguments)        }
[1:1:0713/011149.971514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011150.443815:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 809, 7fe735401881
[1:1:0713/011150.469424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011150.469624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011150.469861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011150.470187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){var t,i=fn.getCookie("autoChatCount");if(t=null!=i?parseInt(i):0,isMobile)e.pageChater.start(!1,"
[1:1:0713/011150.470408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[32833:32833:0713/011150.485724:INFO:CONSOLE(4)] "Uncaught TypeError: Cannot read property 'style' of null", source: https://care.live800.com/live800/chatClient/script/monitorStatic8.js?v=20190403 (4)
[1:1:0713/011150.686956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 878, 7fe735401881
[1:1:0713/011150.709284:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"784 0x7fe732abc070 0x1123f84a5fe0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011150.709572:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"784 0x7fe732abc070 0x1123f84a5fe0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011150.709903:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011150.710362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/011150.710508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011150.710954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011150.711093:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 100
[1:1:0713/011150.711369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 932
[1:1:0713/011150.711514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7fe732abc070 0x1123f6cb5960 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 878 0x7fe732abc070 0x1123f84e8f60 
[1:1:0713/011150.860402:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[32833:32833:0713/011150.869814:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://care.live800.com/, https://care.live800.com/, 4
[32833:32833:0713/011150.869884:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 5, https://care.live800.com/, https://care.live800.com
[1:1:0713/011151.019416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 889 0x7fe7349e42e0 0x1123f8498ae0 , "https://box.lenovo.com/?C=CYB"
[1:1:0713/011151.021949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , /*!
 * Live800 Copyright 2019 GoldArmor Technology Inc.
 */
"undefined"==typeof LIM&&(window.LIM={})
[1:1:0713/011151.022219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[32833:32833:0713/011151.039480:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/011151.041558:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x1123f8439020
[1:1:0713/011151.041804:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[32833:32833:0713/011151.046369:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 5, 
[1:1:0713/011151.062772:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/011151.062999:INFO:render_frame_impl.cc(7019)] 	 [url] = https://box.lenovo.com
[32833:32833:0713/011151.066709:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://box.lenovo.com/
[1:1:0713/011151.076711:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x35247be29c8, 0x1123f61511b8
[1:1:0713/011151.076933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 500
[1:1:0713/011151.077280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 956
[1:1:0713/011151.077491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7fe732abc070 0x1123f7fae0e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 889 0x7fe7349e42e0 0x1123f8498ae0 
[32833:32833:0713/011151.139255:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32833:32833:0713/011151.142155:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32833:32845:0713/011151.157132:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[32833:32833:0713/011151.157175:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://care.live800.com/
[32833:32833:0713/011151.157305:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://care.live800.com/, https://care.live800.com/live800/chatClient/spacer.gif, 5
[32833:32845:0713/011151.157299:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[32833:32833:0713/011151.157472:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://care.live800.com/, HTTP/1.1 200 OK Server: Tengine Date: Sat, 13 Jul 2019 08:11:51 GMT Content-Type: image/gif Content-Length: 43 Connection: keep-alive ETag: W/"43-1317393948000" Last-Modified: Fri, 30 Sep 2011 14:45:48 GMT Expires: Mon, 12 Aug 2019 08:11:51 GMT Cache-Control: max-age=2592000 Accept-Ranges: bytes  ,32930, 5
[1:1:0713/011151.160453:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:7:0713/011151.164082:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011151.175684:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 50
[1:1:0713/011151.176089:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 961
[1:1:0713/011151.176285:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7fe732abc070 0x1123f6cc3160 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 889 0x7fe7349e42e0 0x1123f8498ae0 
[1:1:0713/011151.177488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 200
[1:1:0713/011151.177821:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 962
[1:1:0713/011151.178015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7fe732abc070 0x1123f813fbe0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 889 0x7fe7349e42e0 0x1123f8498ae0 
[1:1:0713/011151.324764:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011151.325699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , tagImage.onload, (){i.onTagSuccess(this.width)}
[1:1:0713/011151.325988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011151.354073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 897, 7fe7354018db
[1:1:0713/011151.370851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"833 0x7fe732abc070 0x1123f8125660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011151.371162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"833 0x7fe732abc070 0x1123f8125660 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011151.371556:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 971
[1:1:0713/011151.371677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7fe732abc070 0x1123f80a44e0 , 5:3_https://box.lenovo.com/, 0, , 897 0x7fe732abc070 0x1123f84cb6e0 
[1:1:0713/011151.371818:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011151.372139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , () {            return a.apply(b, arguments)        }
[1:1:0713/011151.372249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011151.471870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , document.readyState
[1:1:0713/011151.472043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011151.700726:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 904, 7fe7354018db
[1:1:0713/011151.724251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"843 0x7fe732abc070 0x1123f84f57e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011151.724437:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"843 0x7fe732abc070 0x1123f84f57e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011151.724694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 981
[1:1:0713/011151.724809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7fe732abc070 0x1123f92b5e60 , 5:3_https://box.lenovo.com/, 0, , 904 0x7fe732abc070 0x1123f7fc0960 
[1:1:0713/011151.724956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011151.725242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011151.725355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011152.127883:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 814, 7fe735401881
[1:1:0713/011152.142885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.143078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.143309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011152.143925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , globalSendDriver.startFlowCapacity()
[1:1:0713/011152.144128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/011152.363621:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 830, 7fe7354018db
[1:1:0713/011152.412903:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.414208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.415422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1008
[1:1:0713/011152.415712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1008 0x7fe732abc070 0x1123f6548ce0 , 5:3_https://box.lenovo.com/, 0, , 830 0x7fe732abc070 0x1123f6daf7e0 
[1:1:0713/011152.416361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011152.417113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto2, () {
        var left = parseInt($('#banner2').css('left'));
        if (width2 - left >= countwidth
[1:1:0713/011152.417437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011152.429289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 832, 7fe7354018db
[1:1:0713/011152.474546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.474746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.475127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1016
[1:1:0713/011152.475259:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7fe732abc070 0x1123f92cdae0 , 5:3_https://box.lenovo.com/, 0, , 832 0x7fe732abc070 0x1123f7f18760 
[1:1:0713/011152.475448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011152.475775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto2, () {
            var left = parseInt($('#banner2').css('left'));
            if (width2 - left >= co
[1:1:0713/011152.475901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011152.634174:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011152.779046:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 932, 7fe735401881
[1:1:0713/011152.819111:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"878 0x7fe732abc070 0x1123f84e8f60 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.819433:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"878 0x7fe732abc070 0x1123f84e8f60 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011152.819788:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011152.820681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/011152.820941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011152.821591:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011152.821751:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 100
[1:1:0713/011152.822126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1021
[1:1:0713/011152.822319:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7fe732abc070 0x1123f95329e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 932 0x7fe732abc070 0x1123f6cb5960 
[1:1:0713/011153.282470:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://care.live800.com/
[1:1:0713/011153.348287:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 961, 7fe7354018db
[1:1:0713/011153.373749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"889 0x7fe7349e42e0 0x1123f8498ae0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011153.374078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"889 0x7fe7349e42e0 0x1123f8498ae0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011153.374488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1027
[1:1:0713/011153.374688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1027 0x7fe732abc070 0x1123f95edb60 , 5:3_https://box.lenovo.com/, 0, , 961 0x7fe732abc070 0x1123f6cc3160 
[1:1:0713/011153.375052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011153.375593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){if(fn.get("lim_mini")&&fn.get("lim_mini_wrap")){function t(){var e=(window.innerHeight||document.
[1:1:0713/011153.375776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011153.411741:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 829, 7fe7354018db
[1:1:0713/011153.431594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011153.431899:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011153.432338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1033
[1:1:0713/011153.432531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1033 0x7fe732abc070 0x1123f9686ce0 , 5:3_https://box.lenovo.com/, 0, , 829 0x7fe732abc070 0x1123f813e860 
[1:1:0713/011153.432840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011153.433418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto, () {
            now_index = (now_index == (count - 1)) ? 0 : now_index += 1;
            $("#banner
[1:1:0713/011153.433593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011153.492591:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011153.492749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011153.492922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1034
[1:1:0713/011153.493029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1034 0x7fe732abc070 0x1123f5ff52e0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 829 0x7fe732abc070 0x1123f813e860 
[1:1:0713/011153.507697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 13
[1:1:0713/011153.507947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1035
[1:1:0713/011153.508082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7fe732abc070 0x1123f92bcb60 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 829 0x7fe732abc070 0x1123f813e860 
[32833:32833:0713/011153.573870:INFO:CONSOLE(207)] "切了！", source: https://box.lenovo.com/public/js/HomeIndex.js?v=5.0.9.3 (207)
[1:1:0713/011153.596930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011153.736346:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011153.737354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011153.789361:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 831, 7fe7354018db
[1:1:0713/011153.831693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011153.832066:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"750 0x7fe732e24bd0 0x1123f649dcd8 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011153.832541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1042
[1:1:0713/011153.832790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1042 0x7fe732abc070 0x1123f9528f60 , 5:3_https://box.lenovo.com/, 0, , 831 0x7fe732abc070 0x1123f7fbc5e0 
[1:1:0713/011153.833133:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011153.833726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto, () {
                now_index = (now_index == (count - 1)) ? 0 : now_index += 1;
                $(
[1:1:0713/011153.833959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011154.044165:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011154.236849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011154.237549:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011154.242212:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 962, 7fe7354018db
[1:1:0713/011154.257873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"889 0x7fe7349e42e0 0x1123f8498ae0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.258324:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"889 0x7fe7349e42e0 0x1123f8498ae0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.258920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1047
[1:1:0713/011154.259144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1047 0x7fe732abc070 0x1123f92c9f60 , 5:3_https://box.lenovo.com/, 0, , 962 0x7fe732abc070 0x1123f813fbe0 
[1:1:0713/011154.259496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011154.260068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){window.LIM&&LIM.completed&&("1"!=fn.getCookie("forInitial")||globalVisitClient.pageChating||globa
[1:1:0713/011154.260342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011154.284782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , document.readyState
[1:1:0713/011154.285063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011154.289344:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 971, 7fe7354018db
[1:1:0713/011154.306533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"897 0x7fe732abc070 0x1123f84cb6e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.306841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"897 0x7fe732abc070 0x1123f84cb6e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.307309:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1050
[1:1:0713/011154.307550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1050 0x7fe732abc070 0x1123f6db74e0 , 5:3_https://box.lenovo.com/, 0, , 971 0x7fe732abc070 0x1123f80a44e0 
[1:1:0713/011154.307898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011154.308471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , () {            return a.apply(b, arguments)        }
[1:1:0713/011154.308714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011154.356959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 956, 7fe735401881
[1:1:0713/011154.400172:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"889 0x7fe7349e42e0 0x1123f8498ae0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.400554:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"889 0x7fe7349e42e0 0x1123f8498ae0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.400981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011154.401610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){e.generate()}
[1:1:0713/011154.401845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011154.444666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 981, 7fe7354018db
[1:1:0713/011154.491368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"904 0x7fe732abc070 0x1123f7fc0960 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.491683:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"904 0x7fe732abc070 0x1123f7fc0960 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011154.492145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1060
[1:1:0713/011154.492410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7fe732abc070 0x1123f94add60 , 5:3_https://box.lenovo.com/, 0, , 981 0x7fe732abc070 0x1123f92b5e60 
[1:1:0713/011154.492800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011154.493370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011154.493582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011155.291761:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011155.292016:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://care.live800.com/live800/chatClient/shared.html?companyID=85755&configID=114683"
[1:1:0713/011155.306296:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011155.307009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){vis.completed=!0}
[1:1:0713/011155.307230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011155.312105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1021, 7fe735401881
[1:1:0713/011155.336086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"932 0x7fe732abc070 0x1123f6cb5960 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011155.336455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"932 0x7fe732abc070 0x1123f6cb5960 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011155.336836:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011155.337619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/011155.337832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011155.338477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011155.338711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 100
[1:1:0713/011155.339062:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1088
[1:1:0713/011155.339278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7fe732abc070 0x1123f93ec560 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 1021 0x7fe732abc070 0x1123f95329e0 
[32833:32833:0713/011155.489399:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://care.live800.com/, https://care.live800.com/, 5
[32833:32833:0713/011155.489556:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 6, https://care.live800.com/, https://care.live800.com
[1:1:0713/011155.947339:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1034, 7fe735401881
[1:1:0713/011155.963784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"829 0x7fe732abc070 0x1123f813e860 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011155.964150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"829 0x7fe732abc070 0x1123f813e860 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011155.964602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011155.965157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){Xn=t}
[1:1:0713/011155.965397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011155.967347:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1035, 7fe7354018db
[1:1:0713/011156.013675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"829 0x7fe732abc070 0x1123f813e860 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.014032:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"829 0x7fe732abc070 0x1123f813e860 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.014546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1142
[1:1:0713/011156.014800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1142 0x7fe732abc070 0x1123f6dafb60 , 5:3_https://box.lenovo.com/, 0, , 1035 0x7fe732abc070 0x1123f92bcb60 
[1:1:0713/011156.015164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011156.015744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , x.fx.tick, (){var e,n=x.timers,r=0;for(Xn=x.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0713/011156.015984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011156.470240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , document.readyState
[1:1:0713/011156.470512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011156.473280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1008, 7fe7354018db
[1:1:0713/011156.490636:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"830 0x7fe732abc070 0x1123f6daf7e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.490976:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"830 0x7fe732abc070 0x1123f6daf7e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.491449:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1153
[1:1:0713/011156.491687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1153 0x7fe732abc070 0x1123f95f2b60 , 5:3_https://box.lenovo.com/, 0, , 1008 0x7fe732abc070 0x1123f6548ce0 
[1:1:0713/011156.492081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011156.492631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto2, () {
        var left = parseInt($('#banner2').css('left'));
        if (width2 - left >= countwidth
[1:1:0713/011156.492840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011156.495560:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1050, 7fe7354018db
[1:1:0713/011156.544164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"971 0x7fe732abc070 0x1123f80a44e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.544508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"971 0x7fe732abc070 0x1123f80a44e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.544986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1154
[1:1:0713/011156.545215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1154 0x7fe732abc070 0x1123f7f879e0 , 5:3_https://box.lenovo.com/, 0, , 1050 0x7fe732abc070 0x1123f6db74e0 
[1:1:0713/011156.545587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011156.546119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , () {            return a.apply(b, arguments)        }
[1:1:0713/011156.546376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011156.548506:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1016, 7fe7354018db
[1:1:0713/011156.576277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"832 0x7fe732abc070 0x1123f7f18760 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.576571:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"832 0x7fe732abc070 0x1123f7f18760 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.576978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1156
[1:1:0713/011156.577216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1156 0x7fe732abc070 0x1123f9614be0 , 5:3_https://box.lenovo.com/, 0, , 1016 0x7fe732abc070 0x1123f92cdae0 
[1:1:0713/011156.577649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011156.578215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto2, () {
            var left = parseInt($('#banner2').css('left'));
            if (width2 - left >= co
[1:1:0713/011156.578444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011156.700739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1047, 7fe7354018db
[1:1:0713/011156.727288:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"962 0x7fe732abc070 0x1123f813fbe0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.727595:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"962 0x7fe732abc070 0x1123f813fbe0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.728022:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1159
[1:1:0713/011156.728248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1159 0x7fe732abc070 0x1123f96c07e0 , 5:3_https://box.lenovo.com/, 0, , 1047 0x7fe732abc070 0x1123f92c9f60 
[1:1:0713/011156.728627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011156.729189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , , (){window.LIM&&LIM.completed&&("1"!=fn.getCookie("forInitial")||globalVisitClient.pageChating||globa
[1:1:0713/011156.729492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011156.778977:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1060, 7fe7354018db
[1:1:0713/011156.806380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"981 0x7fe732abc070 0x1123f92b5e60 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.806692:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"981 0x7fe732abc070 0x1123f92b5e60 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011156.807173:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1162
[1:1:0713/011156.807418:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1162 0x7fe732abc070 0x1123f6cb90e0 , 5:3_https://box.lenovo.com/, 0, , 1060 0x7fe732abc070 0x1123f94add60 
[1:1:0713/011156.807797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011156.808357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , e, (){return b.apply(a,arguments)}
[1:1:0713/011156.808578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011156.905801:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011156.906619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , rpcImage.onload, (){n.onRpcSuccess(this.offsetWidth,this.offsetHeight)}
[1:1:0713/011156.906842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011157.520963:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1088, 7fe735401881
[1:1:0713/011157.568895:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"106efbb02860","ptid":"1021 0x7fe732abc070 0x1123f95329e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011157.569229:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://box.lenovo.com/","ptid":"1021 0x7fe732abc070 0x1123f95329e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011157.569641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011157.570251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/011157.570460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011157.571116:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011157.571314:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 100
[1:1:0713/011157.571667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1174
[1:1:0713/011157.571885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7fe732abc070 0x1123f95f2560 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 1088 0x7fe732abc070 0x1123f93ec560 
[1:1:0713/011158.568384:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011158.569104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , i.onload, (){"1"===cfg.invite.pageChatVisible?fn.get("lim_mini").style.display="block":fn.get("lim_mini").styl
[1:1:0713/011158.569317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011159.165263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1033, 7fe7354018db
[1:1:0713/011159.215133:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"829 0x7fe732abc070 0x1123f813e860 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011159.215453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"829 0x7fe732abc070 0x1123f813e860 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011159.215919:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1215
[1:1:0713/011159.216147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1215 0x7fe732abc070 0x1123f9c6b660 , 5:3_https://box.lenovo.com/, 0, , 1033 0x7fe732abc070 0x1123f9686ce0 
[1:1:0713/011159.216512:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011159.217059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto, () {
            now_index = (now_index == (count - 1)) ? 0 : now_index += 1;
            $("#banner
[1:1:0713/011159.217274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011159.299932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x35247be29c8, 0x1123f6151150
[1:1:0713/011159.300222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 0
[1:1:0713/011159.300686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://box.lenovo.com/, 1216
[1:1:0713/011159.300936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1216 0x7fe732abc070 0x1123f6dc0d60 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 1033 0x7fe732abc070 0x1123f9686ce0 
[1:1:0713/011159.325451:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://box.lenovo.com/?C=CYB", 13
[1:1:0713/011159.325950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1217
[1:1:0713/011159.326249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1217 0x7fe732abc070 0x1123f9c78ae0 , 5:3_https://box.lenovo.com/, 1, -5:3_https://box.lenovo.com/, 1033 0x7fe732abc070 0x1123f9686ce0 
[1:1:0713/011159.454738:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011159.592329:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011159.593024:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
[1:1:0713/011159.595866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1042, 7fe7354018db
[1:1:0713/011159.646636:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"831 0x7fe732abc070 0x1123f7fbc5e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011159.646976:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"831 0x7fe732abc070 0x1123f7fbc5e0 ","rf":"5:3_https://box.lenovo.com/"}
[1:1:0713/011159.647451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://box.lenovo.com/, 1221
[1:1:0713/011159.647652:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1221 0x7fe732abc070 0x1123f80b91e0 , 5:3_https://box.lenovo.com/, 0, , 1042 0x7fe732abc070 0x1123f9528f60 
[1:1:0713/011159.648012:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://box.lenovo.com/?C=CYB"
[1:1:0713/011159.648543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://box.lenovo.com/, 106efbb02860, , showAuto, () {
                now_index = (now_index == (count - 1)) ? 0 : now_index += 1;
                $(
[1:1:0713/011159.648776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://box.lenovo.com/?C=CYB", "box.lenovo.com", 3, 1, , , 0
[1:1:0713/011159.767830:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://box.lenovo.com/?C=CYB"
