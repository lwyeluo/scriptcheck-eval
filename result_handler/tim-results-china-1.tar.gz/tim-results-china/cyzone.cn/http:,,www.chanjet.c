[0713/010930.922993:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010930.923330:INFO:switcher_clone.cc(787)] backtrace rip is 7f00caaa1891
[0713/010931.990964:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010931.991357:INFO:switcher_clone.cc(787)] backtrace rip is 7fde0c19c891
[1:1:0713/010932.006867:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/010932.007167:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/010932.020031:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/010933.659907:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010933.660242:INFO:switcher_clone.cc(787)] backtrace rip is 7ff3514b4891
[32698:32698:0713/010933.746006:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f4c2add3-4c21-4e57-b5af-167979708bad
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[32732:32732:0713/010933.901465:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=32732
[32743:32743:0713/010933.901895:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=32743
[32698:32698:0713/010934.238774:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[32698:32730:0713/010934.240109:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/010934.240374:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/010934.240663:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/010934.241228:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/010934.241378:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/010934.244225:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33abf241, 1
[1:1:0713/010934.244671:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e572a4, 0
[1:1:0713/010934.244910:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x331a637c, 3
[1:1:0713/010934.245126:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2635786f, 2
[1:1:0713/010934.245355:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa472ffffffe502 41fffffff2ffffffab33 6f783526 7c631a33 , 10104, 4
[1:1:0713/010934.246313:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[32698:32730:0713/010934.246601:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�r�A�3ox5&|c3��j
[32698:32730:0713/010934.246675:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �r�A�3ox5&|c3�+��j
[1:1:0713/010934.246593:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fde0a3d70a0, 3
[1:1:0713/010934.246816:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fde0a562080, 2
[32698:32730:0713/010934.247046:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/010934.246980:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fddf4225d20, -2
[32698:32730:0713/010934.247115:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 32751, 4, a472e502 41f2ab33 6f783526 7c631a33 
[1:1:0713/010934.269616:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/010934.270484:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2635786f
[1:1:0713/010934.271450:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2635786f
[1:1:0713/010934.273066:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2635786f
[1:1:0713/010934.274864:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.275114:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.275348:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.275605:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.276379:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2635786f
[1:1:0713/010934.276792:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fde0c19c7ba
[1:1:0713/010934.276965:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fde0c193def, 7fde0c19c77a, 7fde0c19e0cf
[1:1:0713/010934.283998:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2635786f
[1:1:0713/010934.284527:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2635786f
[1:1:0713/010934.285438:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2635786f
[1:1:0713/010934.288281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.288549:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.288783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.289009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2635786f
[1:1:0713/010934.290620:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2635786f
[1:1:0713/010934.291072:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fde0c19c7ba
[1:1:0713/010934.291239:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fde0c193def, 7fde0c19c77a, 7fde0c19e0cf
[1:1:0713/010934.300030:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/010934.300482:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/010934.300653:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd6a883d08, 0x7ffd6a883c88)
[1:1:0713/010934.321930:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/010934.328308:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[32698:32698:0713/010934.956886:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32698:32698:0713/010934.959231:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32698:32710:0713/010934.978748:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[32698:32710:0713/010934.978856:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[32698:32698:0713/010934.979117:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[32698:32698:0713/010934.979215:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[32698:32698:0713/010934.979404:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,32751, 4
[1:7:0713/010934.987898:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[32698:32722:0713/010935.009364:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/010935.072351:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2520c84c2220
[1:1:0713/010935.072608:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/010935.578527:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[32698:32698:0713/010937.283097:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[32698:32698:0713/010937.283167:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/010937.339197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010937.343586:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/010938.368089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 128427521f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/010938.368383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010938.384506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 128427521f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/010938.384817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010938.469255:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010938.742543:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010938.742751:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010939.085618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010939.093937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 128427521f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/010939.094241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010939.129820:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010939.136141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 128427521f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/010939.136414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010939.150132:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[32698:32698:0713/010939.152143:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/010939.153956:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2520c84c0e20
[1:1:0713/010939.154179:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[32698:32698:0713/010939.154739:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[32698:32698:0713/010939.189754:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[32698:32698:0713/010939.189933:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/010939.242906:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010940.023566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fddf5e002e0 0x2520c86b0fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010940.024298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 128427521f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/010940.024422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010940.024943:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010940.066641:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2520c84c1820
[1:1:0713/010940.066864:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[32698:32698:0713/010940.085233:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/010940.087676:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/010940.087876:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[32698:32698:0713/010940.099247:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[32698:32698:0713/010940.126481:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[32698:32698:0713/010940.141068:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32698:32698:0713/010940.142173:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32698:32710:0713/010940.148437:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[32698:32710:0713/010940.148532:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[32698:32698:0713/010940.148661:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[32698:32698:0713/010940.148736:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[32698:32698:0713/010940.148870:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,32751, 4
[1:7:0713/010940.151370:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010940.720774:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/010941.132421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fddf5e002e0 0x2520c8871ce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010941.133486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 128427521f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/010941.133717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010941.134516:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[32698:32698:0713/010941.206430:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[32698:32698:0713/010941.206529:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/010941.207581:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[32698:32698:0713/010941.255857:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[32698:32730:0713/010941.256434:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/010941.256639:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/010941.256894:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/010941.257301:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/010941.257509:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/010941.260717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x28aefdf, 1
[1:1:0713/010941.261061:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1c9e0244, 0
[1:1:0713/010941.261211:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x229e7804, 3
[1:1:0713/010941.261347:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e5f2508, 2
[1:1:0713/010941.261526:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4402ffffff9e1c ffffffdfffffffefffffff8a02 08255f3e 0478ffffff9e22 , 10104, 5
[1:1:0713/010941.262476:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[32698:32730:0713/010941.262720:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGD���%_>x�"��j
[32698:32730:0713/010941.262790:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is D���%_>x�"�!��j
[1:1:0713/010941.262708:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fde0a3d70a0, 3
[1:1:0713/010941.262892:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fde0a562080, 2
[32698:32730:0713/010941.263022:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 32797, 5, 44029e1c dfef8a02 08255f3e 04789e22 
[1:1:0713/010941.263060:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fddf4225d20, -2
[1:1:0713/010941.284157:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/010941.284556:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e5f2508
[1:1:0713/010941.284863:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e5f2508
[1:1:0713/010941.285472:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e5f2508
[1:1:0713/010941.286853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.287030:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.287196:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.287363:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.288146:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e5f2508
[1:1:0713/010941.288493:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fde0c19c7ba
[1:1:0713/010941.288635:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fde0c193def, 7fde0c19c77a, 7fde0c19e0cf
[1:1:0713/010941.294592:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e5f2508
[1:1:0713/010941.294941:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e5f2508
[1:1:0713/010941.295732:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e5f2508
[1:1:0713/010941.298248:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.298538:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.298784:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.299020:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e5f2508
[1:1:0713/010941.300606:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e5f2508
[1:1:0713/010941.301054:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fde0c19c7ba
[1:1:0713/010941.301215:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fde0c193def, 7fde0c19c77a, 7fde0c19e0cf
[1:1:0713/010941.310800:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/010941.311390:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/010941.311589:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd6a883d08, 0x7ffd6a883c88)
[1:1:0713/010941.328057:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/010941.333389:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/010941.541793:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010941.548588:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2520c848b220
[1:1:0713/010941.548836:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[32698:32698:0713/010942.065663:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32698:32698:0713/010942.071473:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32698:32710:0713/010942.109047:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[32698:32710:0713/010942.109146:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[32698:32698:0713/010942.110766:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.chanjet.com/
[32698:32698:0713/010942.110872:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.chanjet.com/, http://www.chanjet.com/, 1
[32698:32698:0713/010942.111038:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.chanjet.com/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 08:09:42 GMT Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: acw_tc=7b39759815630053819906935e06801e022e2c7fb01a764c76ae4b49768318;path=/;HttpOnly;Max-Age=2678401 Vary: Accept-Encoding Content-Language: en-US Server: Tengine-chanjet-prod Set-Cookie: wwwchanjet=ab2787a2d9e3f77c17a55471a0d1f75b;Path=/ Content-Encoding: gzip  ,32797, 5
[1:7:0713/010942.113471:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010942.137045:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.chanjet.com/
[1:1:0713/010942.253335:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[32698:32698:0713/010942.259992:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.chanjet.com/, http://www.chanjet.com/, 1
[32698:32698:0713/010942.260100:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.chanjet.com/, http://www.chanjet.com
[1:1:0713/010942.319996:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010942.320274:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/010942.322283:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010942.356900:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/010942.420768:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010942.420968:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chanjet.com/"
[1:1:0713/010942.840397:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/010943.630486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 217 0x7fddf4240bd0 0x2520c85e2fd8 , "http://www.chanjet.com/"
[1:1:0713/010943.636395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , /*! jQuery v1.11.3 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0713/010943.636659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010943.647644:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010943.879168:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 217 0x7fddf4240bd0 0x2520c85e2fd8 , "http://www.chanjet.com/"
[1:1:0713/010943.889965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010943.890612:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010943.890967:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010943.891369:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010943.891708:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010944.268119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fddf4240bd0 0x2520c85f9bd8 , "http://www.chanjet.com/"
[1:1:0713/010944.277367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , /** layui-v2.2.6 MIT License By https://www.layui.com */
 ;!function(e){"use strict";var t=document,
[1:1:0713/010944.277666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010944.725041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fddf4240bd0 0x2520c85f9bd8 , "http://www.chanjet.com/"
[1:1:0713/010944.731852:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fddf4240bd0 0x2520c85f9bd8 , "http://www.chanjet.com/"
[1:1:0713/010944.752824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fddf4240bd0 0x2520c85f9bd8 , "http://www.chanjet.com/"
[1:1:0713/010944.764950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fddf4240bd0 0x2520c85f9bd8 , "http://www.chanjet.com/"
[1:1:0713/010944.793488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fddf4240bd0 0x2520c85f9bd8 , "http://www.chanjet.com/"
[1:1:0713/010944.814818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7fddf4240bd0 0x2520c85f9bd8 , "http://www.chanjet.com/"
[1:1:0713/010945.228986:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.504764, 4, 0
[1:1:0713/010945.229242:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010945.931720:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010945.932020:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chanjet.com/"
[1:1:0713/010945.937787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fddf3ed8070 0x2520c859c660 , "http://www.chanjet.com/"
[1:1:0713/010945.946794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , /*!
 * SuperSlide v2.1.1 
 * 轻松解决网站大部分特效展示问题
 * 详尽信息请看官�
[1:1:0713/010945.947038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010945.957987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fddf3ed8070 0x2520c859c660 , "http://www.chanjet.com/"
[1:1:0713/010945.969762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fddf3ed8070 0x2520c859c660 , "http://www.chanjet.com/"
[1:1:0713/010945.998321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fddf3ed8070 0x2520c859c660 , "http://www.chanjet.com/"
[1:1:0713/010946.007648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fddf3ed8070 0x2520c859c660 , "http://www.chanjet.com/"
[1:1:0713/010946.142485:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.210442, 573, 1
[1:1:0713/010946.142833:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010947.524967:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010947.525235:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chanjet.com/"
[1:1:0713/010947.526041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364 0x7fddf3ed8070 0x2520c8b17ce0 , "http://www.chanjet.com/"
[1:1:0713/010947.527180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , 
                    var headerUrl={
                        "/t":1,"/gzq":1,"/b2b":1,"/crm":1,
    
[1:1:0713/010947.527363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010947.615900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364 0x7fddf3ed8070 0x2520c8b17ce0 , "http://www.chanjet.com/"
[1:1:0713/010947.695301:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.169962, 1192, 1
[1:1:0713/010947.695488:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010949.130663:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010949.130856:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chanjet.com/"
[1:1:0713/010949.131355:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.132493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , 
function IsDigit(cCheck)
{  
    return (('0'<=cCheck) && (cCheck<='9'));  
}	
function tianjia6(nF
[1:1:0713/010949.132698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010949.135173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.143688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.151261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.161071:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.163958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.169663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.177881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fddf3ed8070 0x2520c8c517e0 , "http://www.chanjet.com/"
[1:1:0713/010949.405223:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7fddf5e002e0 0x2520c8b123e0 , "http://www.chanjet.com/"
[1:1:0713/010949.406342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , var _hmt=_hmt||[];(function(){var e=document.createElement("script");e.src="//hm.baidu.com/hm.js?"+b
[1:1:0713/010949.406542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010949.418455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7fddf5e002e0 0x2520c81eace0 , "http://www.chanjet.com/"
[1:1:0713/010949.435576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , try{!function(sd){function app_js_bridge(){function e(e){n=e,_.isJSONString(n)&&(n=JSON.parse(n)),i&
[1:1:0713/010949.435798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010950.534979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fddf5e002e0 0x2520c8c51860 , "http://www.chanjet.com/"
[1:1:0713/010950.547706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , !function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var u="function"==typeof require&&require;if(
[1:1:0713/010950.547992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010950.592712:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010950.593205:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_d2b0fccd -> 0
		remove user.11_358b63c5 -> 0
		remove user.12_73992bc6 -> 0
		remove user.13_907c2bde -> 0
		remove user.14_d6d05f48 -> 0
[1:1:0713/010953.927212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "http://www.chanjet.com/"
[1:1:0713/010953.932116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , /* eslint-disable */
!function(e){function t(e){var t=!0;return/^\d{11,12}$/.test(e)||(t=!1,alert(y
[1:1:0713/010953.932401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010954.092148:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/010954.097068:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2520c8488020
[1:1:0713/010954.097264:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0713/010954.170546:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0212121, 116, 1
[1:1:0713/010954.170790:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010954.492129:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568 0x7fddf5e002e0 0x2520c85f28e0 , "http://www.chanjet.com/"
[1:1:0713/010954.502853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (function(){var h={},mt={},c={id:"338fa58da093fe8c8cfbbcb1b1ca9854",dm:["chanjet.com"],js:"tongji.ba
[1:1:0713/010954.503150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/010954.546468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308948
[1:1:0713/010954.546769:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/010954.547213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 650
[1:1:0713/010954.547462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7fddf3ed8070 0x2520c85a8e60 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 568 0x7fddf5e002e0 0x2520c85f28e0 
[32698:32698:0713/011019.524921:INFO:CONSOLE(1500)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://lxbjs.baidu.com/api/asset/api.js?t=1563005389179, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.chanjet.com/ (1500)
[32698:32698:0713/011019.526325:INFO:CONSOLE(1500)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://lxbjs.baidu.com/api/asset/api.js?t=1563005389179, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.chanjet.com/ (1500)
[32698:32698:0713/011019.529650:INFO:CONSOLE(1)] "{"distinct_id":"16bea618ac00-008d48675e953a-612a7221-825572-16bea618ada4","lib":{"$lib":"js","$lib_method":"code","$lib_version":"1.7.11"},"properties":{"$first_visit_time":"2019-07-13 01:09:49.582","$first_referrer":"","$first_browser_language":"en-US","$first_referrer_host":""},"type":"profile_set_once","_nocache":"003076423047611"}", source: https://bd.static.chanjet.com/static/sensorsdata.min.js (1)
[32698:32698:0713/011019.531049:INFO:CONSOLE(1)] "{"distinct_id":"16bea618ac00-008d48675e953a-612a7221-825572-16bea618ada4","lib":{"$lib":"js","$lib_method":"code","$lib_version":"1.7.11"},"properties":{"$screen_height":647,"$screen_width":1276,"$lib":"js","$lib_version":"1.7.11","$latest_referrer":"","$latest_referrer_host":"","$referrer":"","$referrer_host":"","$url":"http://www.chanjet.com/","$url_path":"/","$title":"畅捷通-在线财务软件_云进销存管理软件_移动办公软件","$is_first_day":true,"$is_first_time":true},"type":"track","event":"$pageview","_nocache":"043310308075670"}", source: https://bd.static.chanjet.com/static/sensorsdata.min.js (1)
[32698:32698:0713/011019.570483:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[32698:32698:0713/011019.575583:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: lxbHideIframe, 4, 4, 
[32698:32698:0713/011019.591522:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://www.chanjet.com/, http://www.chanjet.com/, 4
[32698:32698:0713/011019.591707:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://www.chanjet.com/, http://www.chanjet.com
[32698:32698:0713/011019.645649:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/011019.656723:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[32698:32698:0713/011019.785226:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0713/011021.831661:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 600000
[1:1:0713/011021.832224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 766
[1:1:0713/011021.832543:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 766 0x7fddf3ed8070 0x2520c945d260 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 568 0x7fddf5e002e0 0x2520c85f28e0 
[1:1:0713/011021.833459:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011021.833799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 767
[1:1:0713/011021.834016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 767 0x7fddf3ed8070 0x2520c945ebe0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 568 0x7fddf5e002e0 0x2520c85f28e0 
[1:1:0713/011021.970441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7fddf5e002e0 0x2520c8594a60 , "http://www.chanjet.com/"
[1:1:0713/011021.973772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (function(){var h={},mt={},c={id:"338fa58da093fe8c8cfbbcb1b1ca9854",dm:["chanjet.com"],js:"tongji.ba
[1:1:0713/011021.974020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011022.003012:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308938
[1:1:0713/011022.003276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011022.003667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 785
[1:1:0713/011022.003895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7fddf3ed8070 0x2520c945efe0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 569 0x7fddf5e002e0 0x2520c8594a60 
[1:1:0713/011022.397282:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011022.399275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0713/011022.399507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011022.400244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011022.402956:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011022.408649:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0xec2836e29c8, 0x2520c8308a10
[1:1:0713/011022.408888:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 300
[1:1:0713/011022.409264:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 797
[1:1:0713/011022.409500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7fddf3ed8070 0x2520c96c2ce0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 588
[1:1:0713/011022.455354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011022.456096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0713/011022.456323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011022.457362:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011022.463390:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011022.569243:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 595 0x7fddf5e002e0 0x2520c85a79e0 , "http://www.chanjet.com/"
[1:1:0713/011022.572606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (function(){var h={},mt={},c={id:"338fa58da093fe8c8cfbbcb1b1ca9854",dm:["chanjet.com"],js:"tongji.ba
[1:1:0713/011022.572878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011022.596741:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308938
[1:1:0713/011022.597004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011022.597399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 801
[1:1:0713/011022.597661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 801 0x7fddf3ed8070 0x2520c96b5c60 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 595 0x7fddf5e002e0 0x2520c85a79e0 
[1:1:0713/011022.646492:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 596 0x7fddf5e002e0 0x2520c8b18de0 , "http://www.chanjet.com/"
[1:1:0713/011022.648589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , ,     (function(para) {
        var p = para.sdk_url, n = para.name, w = window, d = document, s = 'sc
[1:1:0713/011022.648820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011022.682701:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7fddf5e002e0 0x2520c8ad54e0 , "http://www.chanjet.com/"
[1:1:0713/011022.687644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , window.lxb=window.lxb||{};lxb.instance=lxb.instance||0;lxb.instance++;(function(){var a={};lxb.add=l
[1:1:0713/011022.687900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011023.280167:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/011023.280439:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.chanjet.com
[32698:32698:0713/011023.285642:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.chanjet.com/
[32698:32698:0713/011023.345149:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32698:32698:0713/011023.348342:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32698:32710:0713/011023.361050:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[32698:32698:0713/011023.361091:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://lxbjs.baidu.com/
[32698:32698:0713/011023.361145:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://lxbjs.baidu.com/, http://lxbjs.baidu.com/vt/lxb.gif, 4
[32698:32710:0713/011023.361154:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[32698:32698:0713/011023.361207:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://lxbjs.baidu.com/, HTTP/1.1 200 OK Cache-Control: no-cache Content-Type: image/jpeg;charset=utf-8 Date: Sat, 13 Jul 2019 08:10:23 GMT Expires: Thu, 01 Jan 1970 00:00:00 GMT Pragma: no-cache Server: Apache-Coyote/1.1 Content-Length: 181  ,32797, 5
[1:7:0713/011023.366046:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011023.494736:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011023.495019:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chanjet.com/"
[1:1:0713/011023.498005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7fddf3ed8070 0x2520c8595f60 , "http://www.chanjet.com/"
[1:1:0713/011023.499213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , function g(o){return document.getElementById(o);}
//window.onload=function()
//{
//
//	$(".top_searc
[1:1:0713/011023.499448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011023.502185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7fddf3ed8070 0x2520c8595f60 , "http://www.chanjet.com/"
[1:1:0713/011023.510521:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7fddf3ed8070 0x2520c8595f60 , "http://www.chanjet.com/"
[1:1:0713/011023.523559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011023.528104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011023.573713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6, 0xec2836e29c8, 0x2520c8308a10
[1:1:0713/011023.574005:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 6
[1:1:0713/011023.574445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 824
[1:1:0713/011023.574686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 824 0x7fddf3ed8070 0x2520c9718860 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 640 0x7fddf3ed8070 0x2520c8595f60 
[1:1:0713/011023.872834:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011023.873395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 832
[1:1:0713/011023.873711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 832 0x7fddf3ed8070 0x2520c968cf60 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 640 0x7fddf3ed8070 0x2520c8595f60 
[1:1:0713/011024.549606:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011024.550040:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 846
[1:1:0713/011024.550325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 846 0x7fddf3ed8070 0x2520c9ff86e0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 640 0x7fddf3ed8070 0x2520c8595f60 
[1:1:0713/011025.589280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011025.589807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 851
[1:1:0713/011025.590043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7fddf3ed8070 0x2520c8aed0e0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 640 0x7fddf3ed8070 0x2520c8595f60 
[1:1:0713/011026.436811:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011026.437211:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011026.525730:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011026.526222:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 858
[1:1:0713/011026.526467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7fddf3ed8070 0x2520ca4711e0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 640 0x7fddf3ed8070 0x2520c8595f60 
[1:1:0713/011026.691550:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0xec2836e29c8, 0x2520c8308a10
[1:1:0713/011026.691746:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011026.691934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 863
[1:1:0713/011026.692038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 863 0x7fddf3ed8070 0x2520ca783ae0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 640 0x7fddf3ed8070 0x2520c8595f60 
[1:1:0713/011026.699386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011026.739142:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011026.759529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011026.776482:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0xec2836e29c8, 0x2520c83089e0
[1:1:0713/011026.776770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 1500
[1:1:0713/011026.777172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 871
[1:1:0713/011026.777413:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7fddf3ed8070 0x2520c8ad2fe0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 640 0x7fddf3ed8070 0x2520c8595f60 
[1:1:0713/011026.784233:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011026.785975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011026.787093:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011026.788189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chanjet.com/"
[1:1:0713/011027.140493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/011027.140664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011032.088282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 650, 7fddf681d881
[1:1:0713/011032.117034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"568 0x7fddf5e002e0 0x2520c85f28e0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011032.117385:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"568 0x7fddf5e002e0 0x2520c85f28e0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011032.117770:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011032.122199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0713/011032.122421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011032.124599:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011032.124830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011032.125242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 946
[1:1:0713/011032.125475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 946 0x7fddf3ed8070 0x2520ca9e2ee0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 650 0x7fddf3ed8070 0x2520c85a8e60 
[1:1:0713/011032.607780:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.chanjet.com/"
[1:1:0713/011032.608547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , (anonymous function).onload.(anonymous function).onerror, (e){i[n].onload=null,i[n].onerror=null,delete i[n],++i._complete,"function"==typeof t&&t()}
[1:1:0713/011032.608765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011032.735348:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.chanjet.com/"
[1:1:0713/011032.736054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , (anonymous function).onload.(anonymous function).onerror, (e){i[n].onload=null,i[n].onerror=null,delete i[n],++i._complete,"function"==typeof t&&t()}
[1:1:0713/011032.736269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011032.738023:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 785, 7fddf681d881
[1:1:0713/011032.770430:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"569 0x7fddf5e002e0 0x2520c8594a60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011032.770764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"569 0x7fddf5e002e0 0x2520c8594a60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011032.771174:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011032.771742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0713/011032.771955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011032.772732:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011032.772926:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011032.773278:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 965
[1:1:0713/011032.773512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7fddf3ed8070 0x2520ca9ee160 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 785 0x7fddf3ed8070 0x2520c945efe0 
[1:1:0713/011033.007921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 801, 7fddf681d881
[1:1:0713/011033.048918:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"595 0x7fddf5e002e0 0x2520c85a79e0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011033.049261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"595 0x7fddf5e002e0 0x2520c85a79e0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011033.049692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011033.050266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0713/011033.050522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011033.051308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011033.051531:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011033.052046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 970
[1:1:0713/011033.052272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 970 0x7fddf3ed8070 0x2520ca9da760 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 801 0x7fddf3ed8070 0x2520c96b5c60 
[1:1:0713/011033.084059:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 797, 7fddf681d881
[1:1:0713/011033.130584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"588","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011033.130919:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"588","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011033.131277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011033.131825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (){return r.sendPV(t,e)}
[1:1:0713/011033.132041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011033.689715:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://lxbjs.baidu.com/
[1:1:0713/011035.271682:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011035.272397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xb[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0713/011035.272946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011035.274518:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011035.277417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011035.278077:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3fb2526741c8
[1:1:0713/011035.437000:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011035.437395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0713/011035.437503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011035.437714:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011035.439196:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011035.571106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 824, 7fddf681d881
[1:1:0713/011035.616591:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011035.616891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011035.617286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011035.617901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (){//规避页面加载不完整高度获取异常
    $(window).scroll(function() {
        roll();
[1:1:0713/011035.618074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011035.812816:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 767, 7fddf681d8db
[1:1:0713/011035.858046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"568 0x7fddf5e002e0 0x2520c85f28e0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011035.858398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"568 0x7fddf5e002e0 0x2520c85f28e0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011035.858811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 1013
[1:1:0713/011035.859005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7fddf3ed8070 0x2520ca94b160 , 5:3_http://www.chanjet.com/, 0, , 767 0x7fddf3ed8070 0x2520c945ebe0 
[1:1:0713/011035.859350:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011035.859841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/011035.860019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011036.133019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , document.readyState
[1:1:0713/011036.133273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011037.054289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 871, 7fddf681d881
[1:1:0713/011037.106324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011037.106703:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011037.107064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011037.107612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (){return t.registerDomObserver()}
[1:1:0713/011037.107792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011041.461038:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011041.461268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 0
[1:1:0713/011041.461602:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1070
[1:1:0713/011041.461817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1070 0x7fddf3ed8070 0x2520ca956b60 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 871 0x7fddf3ed8070 0x2520c8ad2fe0 
[1:1:0713/011041.673096:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 832, 7fddf681d8db
[1:1:0713/011041.709872:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011041.710074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011041.710292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 1074
[1:1:0713/011041.710403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1074 0x7fddf3ed8070 0x2520c93c6160 , 5:3_http://www.chanjet.com/, 0, , 832 0x7fddf3ed8070 0x2520c968cf60 
[1:1:0713/011041.710585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011041.710900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (){e.stop(!0,!0);var b=n+1<C?n+1:0;(a.pager||a.manualControls)&&r(b);z(b)}
[1:1:0713/011041.711014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011041.743127:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011041.743288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 1500
[1:1:0713/011041.743455:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1076
[1:1:0713/011041.743563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1076 0x7fddf3ed8070 0x2520c968cae0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 832 0x7fddf3ed8070 0x2520c968cf60 
[32698:32698:0713/011041.905143:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0713/011041.957451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 846, 7fddf681d8db
[1:1:0713/011042.004879:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011042.005194:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011042.006373:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 1080
[1:1:0713/011042.006643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7fddf3ed8070 0x2520ca46f160 , 5:3_http://www.chanjet.com/, 0, , 846 0x7fddf3ed8070 0x2520c9ff86e0 
[1:1:0713/011042.007037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011042.007586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , () {
                base.next(true);
            }
[1:1:0713/011042.007825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011042.021157:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011042.021386:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 1000
[1:1:0713/011042.021741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1081
[1:1:0713/011042.022003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1081 0x7fddf3ed8070 0x2520ca786de0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 846 0x7fddf3ed8070 0x2520c9ff86e0 
[1:1:0713/011042.354341:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 851, 7fddf681d8db
[1:1:0713/011042.391041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011042.391349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011042.391772:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 1083
[1:1:0713/011042.391991:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7fddf3ed8070 0x2520ca9519e0 , 5:3_http://www.chanjet.com/, 0, , 851 0x7fddf3ed8070 0x2520c8aed0e0 
[1:1:0713/011042.392304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011042.392787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , () {
                base.next(true);
            }
[1:1:0713/011042.392978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011042.401765:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011042.401885:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 800
[1:1:0713/011042.402112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1084
[1:1:0713/011042.402221:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7fddf3ed8070 0x2520ca784560 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 851 0x7fddf3ed8070 0x2520c8aed0e0 
[1:1:0713/011042.423892:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011042.424142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 1085
[1:1:0713/011042.424253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7fddf3ed8070 0x2520ca9fb060 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 851 0x7fddf3ed8070 0x2520c8aed0e0 
[1:1:0713/011043.271070:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 858, 7fddf681d8db
[1:1:0713/011043.285891:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011043.286071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"640 0x7fddf3ed8070 0x2520c8595f60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011043.286354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 1099
[1:1:0713/011043.286487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7fddf3ed8070 0x2520c9784560 , 5:3_http://www.chanjet.com/, 0, , 858 0x7fddf3ed8070 0x2520ca4711e0 
[1:1:0713/011043.286662:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011043.286943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , () {
                base.next(true);
            }
[1:1:0713/011043.287046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.291541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011043.291656:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 800
[1:1:0713/011043.291817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1100
[1:1:0713/011043.291927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7fddf3ed8070 0x2520c92aa460 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 858 0x7fddf3ed8070 0x2520ca4711e0 
[1:1:0713/011043.313468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 5000
[1:1:0713/011043.313834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.chanjet.com/, 1101
[1:1:0713/011043.314026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7fddf3ed8070 0x2520c96c1be0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 858 0x7fddf3ed8070 0x2520ca4711e0 
[1:1:0713/011043.452437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 946, 7fddf681d881
[1:1:0713/011043.468373:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"650 0x7fddf3ed8070 0x2520c85a8e60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011043.468541:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"650 0x7fddf3ed8070 0x2520c85a8e60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011043.468749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011043.469047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0713/011043.469151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.469473:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011043.469572:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011043.469728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1105
[1:1:0713/011043.469843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7fddf3ed8070 0x2520c92aa960 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 946 0x7fddf3ed8070 0x2520ca9e2ee0 
[1:1:0713/011043.586923:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 954 0x7fddf5e002e0 0x2520ca7a9160 , "http://www.chanjet.com/"
[1:1:0713/011043.592032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , window.lxb=window.lxb||{};lxb.instance=lxb.instance||0;lxb.instance++;(function(){var a={};lxb.add=l
[1:1:0713/011043.592217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.668712:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 955 0x7fddf5e002e0 0x2520c9718ce0 , "http://www.chanjet.com/"
[1:1:0713/011043.671799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , window.lxb=window.lxb||{};lxb.instance=lxb.instance||0;lxb.instance++;(function(){var a={};lxb.add=l
[1:1:0713/011043.672031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.694824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 956 0x7fddf5e002e0 0x2520c97dc260 , "http://www.chanjet.com/"
[1:1:0713/011043.695654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , window.lxb=window.lxb||{};lxb.instance=lxb.instance||0;lxb.instance++;(function(){var a={};lxb.add=l
[1:1:0713/011043.695769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.732820:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 957 0x7fddf5e002e0 0x2520c81d05e0 , "http://www.chanjet.com/"
[1:1:0713/011043.733320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , 
[1:1:0713/011043.733431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.749581:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 959 0x7fddf5e002e0 0x2520ca9e9160 , "http://www.chanjet.com/"
[1:1:0713/011043.750335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , /**/_lxb_jsonp_jy192mql_({"status":0,"data":{"position":"51","phone":"","closeModule":"<ins class=\"
[1:1:0713/011043.750451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.753937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xec2836e29c8, 0x2520c8308988
[1:1:0713/011043.754052:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 0
[1:1:0713/011043.754215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1114
[1:1:0713/011043.754374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1114 0x7fddf3ed8070 0x2520ca134b60 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 959 0x7fddf5e002e0 0x2520ca9e9160 
[1:1:0713/011043.799960:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 960 0x7fddf5e002e0 0x2520ca9e43e0 , "http://www.chanjet.com/"
[1:1:0713/011043.800537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , jQuery111306266948764227036_1563005383852({"auth_code":"L7T387"});
[1:1:0713/011043.800654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011043.801081:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.chanjet.com/"
[1:1:0713/011044.091217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 965, 7fddf681d881
[1:1:0713/011044.105955:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"785 0x7fddf3ed8070 0x2520c945efe0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011044.106119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"785 0x7fddf3ed8070 0x2520c945efe0 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011044.106327:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011044.106664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0713/011044.106766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011044.107059:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011044.107153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011044.107308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1122
[1:1:0713/011044.107524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1122 0x7fddf3ed8070 0x2520c96bbbe0 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 965 0x7fddf3ed8070 0x2520ca9ee160 
[1:1:0713/011044.184441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 970, 7fddf681d881
[1:1:0713/011044.199338:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26794aae2860","ptid":"801 0x7fddf3ed8070 0x2520c96b5c60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011044.199533:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chanjet.com/","ptid":"801 0x7fddf3ed8070 0x2520c96b5c60 ","rf":"5:3_http://www.chanjet.com/"}
[1:1:0713/011044.199717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chanjet.com/"
[1:1:0713/011044.200016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0713/011044.200128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011044.200443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xec2836e29c8, 0x2520c8308950
[1:1:0713/011044.200559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chanjet.com/", 100
[1:1:0713/011044.200716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chanjet.com/, 1124
[1:1:0713/011044.200821:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1124 0x7fddf3ed8070 0x2520ca91fe60 , 5:3_http://www.chanjet.com/, 1, -5:3_http://www.chanjet.com/, 970 0x7fddf3ed8070 0x2520ca9da760 
[1:1:0713/011044.233704:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[1:1:0713/011044.234086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chanjet.com/, 26794aae2860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0713/011044.234193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chanjet.com/", "www.chanjet.com", 3, 1, , , 0
[1:1:0713/011044.234381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chanjet.com/"
[32698:32698:0713/011044.549987:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://lxbjs.baidu.com/, http://lxbjs.baidu.com/, 4
[32698:32698:0713/011044.550090:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://lxbjs.baidu.com/, http://lxbjs.baidu.com
