[0713/011901.282492:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011901.282895:INFO:switcher_clone.cc(787)] backtrace rip is 7f78e0685891
[0713/011902.376293:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011902.376593:INFO:switcher_clone.cc(787)] backtrace rip is 7fc45d533891
[1:1:0713/011902.380666:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/011902.380833:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/011902.385942:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/011903.814385:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011903.814745:INFO:switcher_clone.cc(787)] backtrace rip is 7ff09784b891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[33788:33788:0713/011904.032923:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33788
[33799:33799:0713/011904.033329:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33799
[33755:33755:0713/011904.210540:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/7f7a9624-159c-4869-a5e8-9a0fcc3ce7d7
[33755:33755:0713/011904.872240:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[33755:33786:0713/011904.873761:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/011904.874204:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011904.874708:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011904.875985:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011904.876342:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/011904.882816:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd3d4afb, 1
[1:1:0713/011904.883701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36fc73c2, 0
[1:1:0713/011904.884142:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x17968d7b, 3
[1:1:0713/011904.884559:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x38aee6fc, 2
[1:1:0713/011904.885098:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc273fffffffc36 fffffffb4a3d0d fffffffcffffffe6ffffffae38 7bffffff8dffffff9617 , 10104, 4
[1:1:0713/011904.886454:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33755:33786:0713/011904.886838:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�s�6�J=��8{���A�
[1:1:0713/011904.886807:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45b76e0a0, 3
[33755:33786:0713/011904.887050:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �s�6�J=��8{��8^�A�
[1:1:0713/011904.887116:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45b8f9080, 2
[1:1:0713/011904.887337:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc4455bcd20, -2
[33755:33786:0713/011904.887621:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[33755:33786:0713/011904.887753:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33809, 4, c273fc36 fb4a3d0d fce6ae38 7b8d9617 
[1:1:0713/011904.914380:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011904.915274:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38aee6fc
[1:1:0713/011904.916230:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38aee6fc
[1:1:0713/011904.917811:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38aee6fc
[1:1:0713/011904.919315:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.919503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.919704:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.919899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.920538:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38aee6fc
[1:1:0713/011904.920877:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc45d5337ba
[1:1:0713/011904.921014:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc45d52adef, 7fc45d53377a, 7fc45d5350cf
[1:1:0713/011904.926679:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38aee6fc
[1:1:0713/011904.927018:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38aee6fc
[1:1:0713/011904.927751:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38aee6fc
[1:1:0713/011904.929738:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.929953:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.930133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.930316:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38aee6fc
[1:1:0713/011904.931563:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38aee6fc
[1:1:0713/011904.931945:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc45d5337ba
[1:1:0713/011904.932076:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc45d52adef, 7fc45d53377a, 7fc45d5350cf
[1:1:0713/011904.939758:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011904.940183:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011904.940327:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc11b0468, 0x7ffcc11b03e8)
[1:1:0713/011904.961838:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011904.968198:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[33755:33755:0713/011905.624906:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33755:33755:0713/011905.625930:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33755:33768:0713/011905.643954:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[33755:33768:0713/011905.644050:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[33755:33755:0713/011905.644196:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[33755:33755:0713/011905.644272:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[33755:33755:0713/011905.644409:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,33809, 4
[1:7:0713/011905.646000:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[33755:33781:0713/011905.722910:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/011905.801047:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x88e0a8cf220
[1:1:0713/011905.801366:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/011906.235706:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/011907.498737:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011907.503424:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[33755:33755:0713/011907.748402:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[33755:33755:0713/011907.748508:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011908.383643:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011908.536624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d60fadc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011908.536896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011908.553105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d60fadc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011908.553360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011908.760950:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011908.761104:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011909.114473:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011909.122823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d60fadc1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011909.123104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011909.181563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011909.188828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d60fadc1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011909.189095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011909.197006:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/011909.200387:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x88e0a8cde20
[1:1:0713/011909.200615:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[33755:33755:0713/011909.202291:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[33755:33755:0713/011909.214373:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[33755:33755:0713/011909.243797:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[33755:33755:0713/011909.243996:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011909.284564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011910.095453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fc4471972e0 0x88e0ab53ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011910.096800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d60fadc1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/011910.097054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011910.098564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[33755:33755:0713/011910.172800:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/011910.174913:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x88e0a8ce820
[1:1:0713/011910.175204:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[33755:33755:0713/011910.179151:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/011910.186091:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/011910.186388:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[33755:33755:0713/011910.192990:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[33755:33755:0713/011910.206345:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33755:33755:0713/011910.208293:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33755:33768:0713/011910.215731:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[33755:33768:0713/011910.215814:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[33755:33755:0713/011910.216112:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[33755:33755:0713/011910.216213:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[33755:33755:0713/011910.216389:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,33809, 4
[1:7:0713/011910.220115:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011910.816844:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/011911.436874:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fc4471972e0 0x88e0ac59f60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011911.437964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d60fadc1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/011911.438250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011911.439024:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011911.633960:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[33755:33755:0713/011911.638108:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[33755:33755:0713/011911.638204:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[33755:33755:0713/011911.982070:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[33755:33786:0713/011911.982535:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/011911.982745:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011911.982960:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011911.983335:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011911.983500:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/011911.986544:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3fbb4b7d, 1
[1:1:0713/011911.986909:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x7cb7dc9, 0
[1:1:0713/011911.987091:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xac28e99, 3
[1:1:0713/011911.987269:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb4e55f3, 2
[1:1:0713/011911.987439:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc97dffffffcb07 7d4bffffffbb3f fffffff3554e0b ffffff99ffffff8effffffc20a , 10104, 5
[1:1:0713/011911.988441:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33755:33786:0713/011911.988779:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�}�}K�?�UN���
<B�
[33755:33786:0713/011911.988845:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �}�}K�?�UN���
�I<B�
[1:1:0713/011911.988777:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45b76e0a0, 3
[1:1:0713/011911.988998:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45b8f9080, 2
[33755:33786:0713/011911.989168:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33852, 5, c97dcb07 7d4bbb3f f3554e0b 998ec20a 
[1:1:0713/011911.989239:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc4455bcd20, -2
[1:1:0713/011912.009956:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011912.010335:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b4e55f3
[1:1:0713/011912.010696:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b4e55f3
[1:1:0713/011912.011332:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b4e55f3
[1:1:0713/011912.012722:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.012934:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.013142:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.013349:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.014022:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b4e55f3
[1:1:0713/011912.014361:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc45d5337ba
[1:1:0713/011912.014547:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc45d52adef, 7fc45d53377a, 7fc45d5350cf
[1:1:0713/011912.020121:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b4e55f3
[1:1:0713/011912.020520:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b4e55f3
[1:1:0713/011912.021235:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b4e55f3
[1:1:0713/011912.023224:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.023479:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.023709:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.023930:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e55f3
[1:1:0713/011912.025147:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b4e55f3
[1:1:0713/011912.025545:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc45d5337ba
[1:1:0713/011912.025713:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc45d52adef, 7fc45d53377a, 7fc45d5350cf
[1:1:0713/011912.033224:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011912.033770:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011912.033956:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc11b0468, 0x7ffcc11b03e8)
[1:1:0713/011912.047339:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011912.051077:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/011912.053138:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011912.209387:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x88e0a89f220
[1:1:0713/011912.209693:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/011912.579684:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011912.579963:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011912.935624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011912.940312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d60faeee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/011912.940626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011912.947138:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[33755:33755:0713/011912.976150:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33755:33755:0713/011913.008967:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[33755:33786:0713/011913.009332:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0713/011913.009541:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011913.009784:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011913.010203:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011913.010367:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0713/011913.013740:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x223e1e20, 1
[1:1:0713/011913.014111:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3c94add8, 0
[1:1:0713/011913.014341:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x232eef8e, 3
[1:1:0713/011913.014535:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x186f12e, 2
[1:1:0713/011913.014712:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd8ffffffadffffff943c 201e3e22 2efffffff1ffffff8601 ffffff8effffffef2e23 , 10104, 6
[1:1:0713/011913.016095:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33755:33786:0713/011913.016441:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGح�< >".���.#�D�
[33755:33786:0713/011913.016521:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ح�< >".���.#�îD�
[33755:33786:0713/011913.016823:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33868, 6, d8ad943c 201e3e22 2ef18601 8eef2e23 
[1:1:0713/011913.017182:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45b76e0a0, 3
[1:1:0713/011913.017394:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45b8f9080, 2
[1:1:0713/011913.017596:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc4455bcd20, -2
[1:1:0713/011913.043314:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011913.043691:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 186f12e
[1:1:0713/011913.044016:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 186f12e
[1:1:0713/011913.044711:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 186f12e
[33755:33755:0713/011913.045572:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/011913.046440:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.046688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.046963:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.047179:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.047985:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 186f12e
[1:1:0713/011913.048334:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc45d5337ba
[1:1:0713/011913.048495:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc45d52adef, 7fc45d53377a, 7fc45d5350cf
[1:1:0713/011913.055422:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 186f12e
[1:1:0713/011913.055898:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 186f12e
[1:1:0713/011913.056808:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 186f12e
[1:1:0713/011913.059302:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.059560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.059812:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.060048:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 186f12e
[1:1:0713/011913.061575:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 186f12e
[1:1:0713/011913.062042:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc45d5337ba
[1:1:0713/011913.062222:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc45d52adef, 7fc45d53377a, 7fc45d5350cf
[1:1:0713/011913.071666:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011913.072261:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011913.072435:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc11b0468, 0x7ffcc11b03e8)
[1:1:0713/011913.087819:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011913.092008:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[33755:33768:0713/011913.094857:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[33755:33768:0713/011913.094942:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[33755:33755:0713/011913.095354:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://zhugeio.com/
[33755:33755:0713/011913.095434:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://zhugeio.com/, https://zhugeio.com/, 1
[33755:33755:0713/011913.095555:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://zhugeio.com/, HTTP/1.1 200 status:200 date:Sat, 13 Jul 2019 08:19:12 GMT content-type:text/html server:nginx last-modified:Fri, 21 Jun 2019 09:22:35 GMT content-encoding:gzip  ,0, 6
[3:3:0713/011913.147233:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/011913.149157:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011913.149845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d60fadc1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/011913.150057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:7:0713/011913.207945:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011913.305266:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x88e0a8ad220
[1:1:0713/011913.305421:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/011913.366973:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://zhugeio.com/
[33755:33755:0713/011913.520047:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://zhugeio.com/, https://zhugeio.com/, 1
[33755:33755:0713/011913.520102:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://zhugeio.com/, https://zhugeio.com
[1:1:0713/011913.556329:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/011913.602259:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011913.603959:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/011913.604182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d60faeee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/011913.604456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011913.673421:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011913.683785:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/011913.684034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d60faeee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/011913.684302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011913.720745:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011913.786966:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011913.787124:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zhugeio.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/011914.706450:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011914.707283:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011914.707720:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011914.708216:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011914.708636:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011917.133738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7fc44526f070 0x88e0accf1e0 , "https://zhugeio.com/"
[1:1:0713/011917.136530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , var _hmt=_hmt||[];!function(){var e=document.createElement("script");e.src="https://hm.baidu.com/hm.
[1:1:0713/011917.136772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/011917.138263:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_d678e91c -> 0
		remove user.11_93da0d8a -> 0
		remove user.12_ce2da5f7 -> 0
		remove user.13_e44dbc05 -> 0
		remove user.14_1c2da78a -> 0
[1:1:0713/011917.351634:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.192033, 823, 1
[1:1:0713/011917.351865:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011918.384965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011919.003960:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011919.004173:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zhugeio.com/"
[1:1:0713/011919.011722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fc44526f070 0x88e0a938860 , "https://zhugeio.com/"
[1:1:0713/011919.051199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , !function(e,t){"object"==typeof module&&"object"==typeof module.exports?module.exports=e.document?t(
[1:1:0713/011919.051423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/011919.366194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fc44526f070 0x88e0a938860 , "https://zhugeio.com/"
[1:1:0713/011920.927552:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.92333, 0, 0
[1:1:0713/011920.927811:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011921.111050:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fc4471972e0 0x88e0aab7ee0 , "https://zhugeio.com/"
[1:1:0713/011921.120249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (function(){var h={},mt={},c={id:"5e3cb1a4d6d94b24154c753e64074c73",dm:["zhugeio.com"],js:"tongji.ba
[1:1:0713/011921.120486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/011921.154582:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a0842029c8, 0x88e0a708148
[1:1:0713/011921.154829:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 100
[1:1:0713/011921.155188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 498
[1:1:0713/011921.155410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7fc44526f070 0x88e0aa49060 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 470 0x7fc4471972e0 0x88e0aab7ee0 
[33755:33755:0713/011955.536362:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/011955.545349:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/011955.632103:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011956.319765:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011956.320153:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zhugeio.com/"
[1:1:0713/011956.323537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7fc44526f070 0x88e0acc0960 , "https://zhugeio.com/"
[1:1:0713/011956.325321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , $(function(){function t(){$(window).scrollTop()>=100?($(".header").addClass("header-fixed"),$(".upda
[1:1:0713/011956.325568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/011956.335368:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7fc44526f070 0x88e0acc0960 , "https://zhugeio.com/"
[1:1:0713/011956.347269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zhugeio.com/"
[1:1:0713/011957.318932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a0842029c8, 0x88e0a708440
[1:1:0713/011957.319205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 0
[1:1:0713/011957.319593:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 573
[1:1:0713/011957.319823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7fc44526f070 0x88e0acc1760 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 488 0x7fc44526f070 0x88e0acc0960 
[1:1:0713/011957.432331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 13
[1:1:0713/011957.432908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 574
[1:1:0713/011957.433225:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7fc44526f070 0x88e0a982ae0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 488 0x7fc44526f070 0x88e0acc0960 
[1:1:0713/011957.890917:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2a0842029c8, 0x88e0a708440
[1:1:0713/011957.891193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 5000
[1:1:0713/011957.891575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 575
[1:1:0713/011957.891815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7fc44526f070 0x88e0abb8c60 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 488 0x7fc44526f070 0x88e0acc0960 
[1:1:0713/011958.156448:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zhugeio.com/"
[1:1:0713/011958.453358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/011958.453733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/011959.360291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 498, 7fc447bb4881
[1:1:0713/011959.381979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"470 0x7fc4471972e0 0x88e0aab7ee0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/011959.382339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"470 0x7fc4471972e0 0x88e0aab7ee0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/011959.382855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/011959.383433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/011959.383667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/011959.384433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a0842029c8, 0x88e0a708150
[1:1:0713/011959.384661:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 100
[1:1:0713/011959.385046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 597
[1:1:0713/011959.385277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 597 0x7fc44526f070 0x88e0acc3c60 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 498 0x7fc44526f070 0x88e0aa49060 
[1:1:0713/011959.610779:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556 0x7fc4471972e0 0x88e0aa9dc60 , "https://zhugeio.com/"
[1:1:0713/011959.618921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0713/011959.619190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
		remove user.10_1a4d4a03 -> 0
		remove user.11_6a3fed77 -> 0
[1:1:0713/012000.129526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7fc4471972e0 0x88e0a9f1be0 , "https://zhugeio.com/"
[1:1:0713/012000.135125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , window._zhugeSdk=function(e){var t={};function i(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1
[1:1:0713/012000.136523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012000.330666:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2a0842029c8, 0x88e0a708140
[1:1:0713/012000.331007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 500
[1:1:0713/012000.331410:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 643
[1:1:0713/012000.331639:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7fc44526f070 0x88e0ab9e7e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 557 0x7fc4471972e0 0x88e0a9f1be0 
[1:1:0713/012000.393183:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2a0842029c8, 0x88e0a708140
[1:1:0713/012000.393495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 500
[1:1:0713/012000.393870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 648
[1:1:0713/012000.394158:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7fc44526f070 0x88e0aabfde0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 557 0x7fc4471972e0 0x88e0a9f1be0 
[1:1:0713/012000.407130:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 12000
[1:1:0713/012000.407548:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 650
[1:1:0713/012000.407777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7fc44526f070 0x88e0ab558e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 557 0x7fc4471972e0 0x88e0a9f1be0 
[1:1:0713/012000.502786:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2a0842029c8, 0x88e0a708140
[1:1:0713/012000.503062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 500
[1:1:0713/012000.503514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 653
[1:1:0713/012000.503808:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 653 0x7fc44526f070 0x88e0acbaae0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 557 0x7fc4471972e0 0x88e0a9f1be0 
[1:1:0713/012000.506907:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2a0842029c8, 0x88e0a708140
[1:1:0713/012000.507131:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 1000
[1:1:0713/012000.507508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 654
[1:1:0713/012000.507740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7fc44526f070 0x88e0a99aa60 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 557 0x7fc4471972e0 0x88e0a9f1be0 
[1:1:0713/012000.516179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012000.552625:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2a0842029c8, 0x88e0a708140
[1:1:0713/012000.552890:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 500
[1:1:0713/012000.553261:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 657
[1:1:0713/012000.553507:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 657 0x7fc44526f070 0x88e0a997f60 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 557 0x7fc4471972e0 0x88e0a9f1be0 
[1:1:0713/012000.633465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7fc4471972e0 0x88e0a98da60 , "https://zhugeio.com/"
[1:1:0713/012000.634393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , 
[1:1:0713/012000.634672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012000.808187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012000.808684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , n, (e,r){var o,u,l;if(n&&(r||4===a.readyState))if(delete lr[s],n=void 0,a.onreadystatechange=pt.noop,r)
[1:1:0713/012000.808810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012000.809351:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012000.810638:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012000.810955:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x294d9e5beb8
[1:1:0713/012000.905309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 573, 7fc447bb4881
[1:1:0713/012000.935473:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"488 0x7fc44526f070 0x88e0acc0960 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012000.935781:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"488 0x7fc44526f070 0x88e0acc0960 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012000.936157:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012000.936644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (){kn=void 0}
[1:1:0713/012000.936823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012000.970961:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 574, 7fc447bb48db
[1:1:0713/012000.984413:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"488 0x7fc44526f070 0x88e0acc0960 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012000.984644:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"488 0x7fc44526f070 0x88e0acc0960 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012000.984912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 680
[1:1:0713/012000.985028:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7fc44526f070 0x88e0b6b64e0 , 6:3_https://zhugeio.com/, 0, , 574 0x7fc44526f070 0x88e0a982ae0 
[1:1:0713/012000.985183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012000.985514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , pt.fx.tick, (){var e,t=pt.timers,n=0;for(kn=pt.now();n<t.length;n++)e=t[n],e()||t[n]!==e||t.splice(n--,1);t.leng
[1:1:0713/012000.985622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012001.196532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012001.197190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , n, (e,r){var o,u,l;if(n&&(r||4===a.readyState))if(delete lr[s],n=void 0,a.onreadystatechange=pt.noop,r)
[1:1:0713/012001.197368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012001.197979:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012001.200789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012001.201425:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x294d9e5beb8
[1:1:0713/012001.240031:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2a0842029c8, 0x88e0a708210
[1:1:0713/012001.240266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 1000
[1:1:0713/012001.240616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 687
[1:1:0713/012001.240812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7fc44526f070 0x88e0b6d7660 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 583
[1:1:0713/012001.260460:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2a0842029c8, 0x88e0a708210
[1:1:0713/012001.260768:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 1000
[1:1:0713/012001.261217:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 688
[1:1:0713/012001.261484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7fc44526f070 0x88e0b7944e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 583
[1:1:0713/012001.359892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , document.readyState
[1:1:0713/012001.360148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012001.911706:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012001.912379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , f.onload, (){f.onload=v;f=window[d]=v;a&&a(b)}
[1:1:0713/012001.912574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012001.921716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 597, 7fc447bb4881
[1:1:0713/012001.953047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"498 0x7fc44526f070 0x88e0aa49060 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012001.953277:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"498 0x7fc44526f070 0x88e0aa49060 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012001.953517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012001.953872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/012001.954018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012001.954446:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a0842029c8, 0x88e0a708150
[1:1:0713/012001.954590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 100
[1:1:0713/012001.954863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 733
[1:1:0713/012001.955057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7fc44526f070 0x88e0a9f13e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 597 0x7fc44526f070 0x88e0acc3c60 
[1:1:0713/012002.017076:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 604 0x7fc4471972e0 0x88e0acbb660 , "https://zhugeio.com/"
[1:1:0713/012002.026045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (function umd(require){if("object"==typeof exports){module.exports=require("1")}else if("function"==
[1:1:0713/012002.026371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012002.035236:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012002.035746:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012002.212959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012003.015616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 605 0x7fc4471972e0 0x88e0a9fb260 , "https://zhugeio.com/"
[1:1:0713/012003.022193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , !function(e){var r={};function o(t){if(r[t])return r[t].exports;var n=r[t]={i:t,l:!1,exports:{}};ret
[1:1:0713/012003.022486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[33755:33755:0713/012003.059533:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/012003.060557:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x88e0b15b820
[1:1:0713/012003.060807:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[33755:33755:0713/012003.068508:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[33755:33755:0713/012003.096248:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://zhugeio.com/, https://zhugeio.com/, 4
[33755:33755:0713/012003.096338:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://zhugeio.com/, https://zhugeio.com
[1:1:0713/012003.163717:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 1cd4f6cedca8, 6:3_https://zhugeio.com/, 6:4_https://zhugeio.com/, about:blank
[1:1:0713/012003.164042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -6:3_https://zhugeio.com/-6:4_https://zhugeio.com/, 1cd4f6cedca8, 1cd4f6c22860, setAttribute, 
[1:1:0713/012003.164362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "zhugeio.com", 4, 2, https://zhugeio.com, zhugeio.com, 3
[1:1:0713/012003.165510:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	M (https://js.intercomcdn.com/shim.latest.js:1:1)
	w (https://js.intercomcdn.com/shim.latest.js:1:1)
	Module.985 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	Object.944 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	14 (https://js.intercomcdn.com/shim.latest.js:1:1)
	https://js.intercomcdn.com/shim.latest.js:1:1

[1:1:0713/012003.166420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/, 1cd4f6c22860, 1cd4f6cedca8, , (){return k}
[1:1:0713/012003.166690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 3, , , 0
[1:1:0713/012003.167715:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	w (https://js.intercomcdn.com/shim.latest.js:1:1)
	Module.985 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	Object.944 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	14 (https://js.intercomcdn.com/shim.latest.js:1:1)
	https://js.intercomcdn.com/shim.latest.js:1:1

[1:1:0713/012003.169049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/-6:4_https://zhugeio.com/, 1cd4f6cedca8, 1cd4f6c22860, appendChild, 
[1:1:0713/012003.169423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "zhugeio.com", 4, 4, https://zhugeio.com, zhugeio.com, 3
[1:1:0713/012003.170638:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	w (https://js.intercomcdn.com/shim.latest.js:1:1)
	Module.985 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	Object.944 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	14 (https://js.intercomcdn.com/shim.latest.js:1:1)
	https://js.intercomcdn.com/shim.latest.js:1:1

[1:1:0713/012003.173871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/, 1cd4f6c22860, 1cd4f6cedca8, , (){return k}
[1:1:0713/012003.174320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 5, , , 0
[1:1:0713/012003.175535:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	w (https://js.intercomcdn.com/shim.latest.js:1:1)
	Module.985 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	Object.944 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	14 (https://js.intercomcdn.com/shim.latest.js:1:1)
	https://js.intercomcdn.com/shim.latest.js:1:1

[1:1:0713/012003.176511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/-6:4_https://zhugeio.com/, 1cd4f6cedca8, 1cd4f6c22860, appendChild, 
[1:1:0713/012003.176852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "zhugeio.com", 4, 6, https://zhugeio.com, zhugeio.com, 3
[1:1:0713/012003.177848:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	w (https://js.intercomcdn.com/shim.latest.js:1:1)
	Module.985 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	Object.944 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	14 (https://js.intercomcdn.com/shim.latest.js:1:1)
	https://js.intercomcdn.com/shim.latest.js:1:1

[1:1:0713/012003.180989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/-6:4_https://zhugeio.com/-6:3_https://zhugeio.com/, 1cd4f6c22860, 1cd4f6cedca8, forEach, 
[1:1:0713/012003.181382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 7, , , 0
[1:1:0713/012003.182422:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Module.985 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	Object.944 (https://js.intercomcdn.com/shim.latest.js:1:1)
	o (https://js.intercomcdn.com/shim.latest.js:1:1)
	14 (https://js.intercomcdn.com/shim.latest.js:1:1)
	https://js.intercomcdn.com/shim.latest.js:1:1

[1:1:0713/012003.185663:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012004.648062:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012004.648715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , i.onreadystatechange, (){if(i.readyState===o.DONE)if(i.status>=200&&i.status<=299)try{s("success")}catch(e){s("error")}els
[1:1:0713/012004.648947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012004.649521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012004.651922:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012005.014680:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 671 0x7fc4471972e0 0x88e0aaf4360 , "https://zhugeio.com/"
[1:1:0713/012005.015852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , callback8443240659006868({"code":10001,"msg":"Request success","visual_events":[{"event_name":"免�
[1:1:0713/012005.016067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012005.098868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 643, 7fc447bb4881
[1:1:0713/012005.117421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.117811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.118254:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012005.118812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (){!n&&t&&(t(),n=!0)}
[1:1:0713/012005.119053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012005.120920:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 648, 7fc447bb4881
[1:1:0713/012005.158220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.158623:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.160000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012005.160689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (){!n&&t&&(t(),n=!0)}
[1:1:0713/012005.160932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012005.255617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 680, 7fc447bb48db
[1:1:0713/012005.274362:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"574 0x7fc44526f070 0x88e0a982ae0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.274721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"574 0x7fc44526f070 0x88e0a982ae0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.275175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 825
[1:1:0713/012005.275405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 825 0x7fc44526f070 0x88e0b5ed060 , 6:3_https://zhugeio.com/, 0, , 680 0x7fc44526f070 0x88e0b6b64e0 
[1:1:0713/012005.275771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012005.276284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , pt.fx.tick, (){var e,t=pt.timers,n=0;for(kn=pt.now();n<t.length;n++)e=t[n],e()||t[n]!==e||t.splice(n--,1);t.leng
[1:1:0713/012005.276495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012005.433229:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 653, 7fc447bb4881
[1:1:0713/012005.473456:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.473842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.474283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012005.474872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (){!n&&t&&(t(),n=!0)}
[1:1:0713/012005.475124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012005.476983:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 657, 7fc447bb4881
[1:1:0713/012005.520694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.521065:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.521503:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012005.522080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (){!n&&t&&(t(),n=!0)}
[1:1:0713/012005.522296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012005.651907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , document.readyState
[1:1:0713/012005.652201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012005.915574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 654, 7fc447bb4881
[1:1:0713/012005.942716:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.943201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"557 0x7fc4471972e0 0x88e0a9f1be0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012005.943744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012005.944350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (){e._checkPermissions()}
[1:1:0713/012005.944591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/012008.314076:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 733, 7fc447bb4881
[1:1:0713/012008.337933:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"597 0x7fc44526f070 0x88e0acc3c60 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.338390:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"597 0x7fc44526f070 0x88e0acc3c60 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.338794:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012008.339416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/012008.339659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012008.340277:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a0842029c8, 0x88e0a708150
[1:1:0713/012008.340463:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 100
[1:1:0713/012008.340783:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 877
[1:1:0713/012008.340972:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 877 0x7fc44526f070 0x88e0c35e9e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 733 0x7fc44526f070 0x88e0a9f13e0 
[1:1:0713/012008.342609:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 687, 7fc447bb4881
[1:1:0713/012008.383578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"583","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.383975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"583","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.384415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012008.384899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , a, (){pt.dequeue(e,t)}
[1:1:0713/012008.385074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012008.413265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a0842029c8, 0x88e0a708150
[1:1:0713/012008.413496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 0
[1:1:0713/012008.413819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 878
[1:1:0713/012008.414017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 878 0x7fc44526f070 0x88e0c3193e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 687 0x7fc44526f070 0x88e0b6d7660 
[1:1:0713/012008.516104:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 688, 7fc447bb4881
[1:1:0713/012008.549758:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"583","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.549951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"583","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.550184:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012008.550512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , a, (){pt.dequeue(e,t)}
[1:1:0713/012008.550626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012008.605836:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 575, 7fc447bb4881
[1:1:0713/012008.639923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"488 0x7fc44526f070 0x88e0acc0960 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.640121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"488 0x7fc44526f070 0x88e0acc0960 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012008.640352:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012008.640817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , e, (){o.timer&&clearTimeout(o.timer);for(var t=$(".board-chart span"),n=0;n<t.length;n++)t.eq(n).animat
[1:1:0713/012008.640997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012008.985435:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2a0842029c8, 0x88e0a708150
[1:1:0713/012008.985729:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 5000
[1:1:0713/012008.986038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 887
[1:1:0713/012008.986234:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 887 0x7fc44526f070 0x88e0c3762e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 575 0x7fc44526f070 0x88e0abb8c60 
[1:1:0713/012009.825869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012009.826721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , xhr.onreadystatechange, (){if(xhr.readyState===4){callback(xhr.status,xhr.responseText)}}
[1:1:0713/012009.827010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012009.827765:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012009.830523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhugeio.com/"
[1:1:0713/012010.330497:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012010.331245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , r, (){!n&&t&&(clearTimeout(o),t())}
[1:1:0713/012010.331495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012010.383114:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012010.383837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , r, (){!n&&t&&(clearTimeout(o),t())}
[1:1:0713/012010.384100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012010.478227:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012010.478908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , r, (){!n&&t&&(clearTimeout(o),t())}
[1:1:0713/012010.479198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012010.563367:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012010.564109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , r, (){!n&&t&&(clearTimeout(o),t())}
[1:1:0713/012010.564332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012010.665942:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 825, 7fc447bb48db
[1:1:0713/012010.705442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"680 0x7fc44526f070 0x88e0b6b64e0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012010.705763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"680 0x7fc44526f070 0x88e0b6b64e0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012010.706252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 917
[1:1:0713/012010.706493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7fc44526f070 0x88e0c146fe0 , 6:3_https://zhugeio.com/, 0, , 825 0x7fc44526f070 0x88e0b5ed060 
[1:1:0713/012010.706816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012010.707347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , pt.fx.tick, (){var e,t=pt.timers,n=0;for(kn=pt.now();n<t.length;n++)e=t[n],e()||t[n]!==e||t.splice(n--,1);t.leng
[1:1:0713/012010.707561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012011.143025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , document.readyState
[1:1:0713/012011.143409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012011.514605:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 878, 7fc447bb4881
[1:1:0713/012011.555180:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"687 0x7fc44526f070 0x88e0b6d7660 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012011.555519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"687 0x7fc44526f070 0x88e0b6d7660 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012011.555918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012011.556457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , (){kn=void 0}
[1:1:0713/012011.556653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012011.558116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 877, 7fc447bb4881
[1:1:0713/012011.598216:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"733 0x7fc44526f070 0x88e0a9f13e0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012011.598608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"733 0x7fc44526f070 0x88e0a9f13e0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012011.599000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012011.599525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/012011.599704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012011.600309:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a0842029c8, 0x88e0a708150
[1:1:0713/012011.600469:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 100
[1:1:0713/012011.600931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 926
[1:1:0713/012011.601132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7fc44526f070 0x88e0b5ed1e0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 877 0x7fc44526f070 0x88e0c35e9e0 
[1:1:0713/012011.972346:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhugeio.com/"
[1:1:0713/012011.972766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0713/012011.972880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012012.349662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 917, 7fc447bb48db
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/012012.400062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"825 0x7fc44526f070 0x88e0b5ed060 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012012.400548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"825 0x7fc44526f070 0x88e0b5ed060 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012012.401169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://zhugeio.com/, 952
[1:1:0713/012012.401486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 952 0x7fc44526f070 0x88e0c2c9460 , 6:3_https://zhugeio.com/, 0, , 917 0x7fc44526f070 0x88e0c146fe0 
[1:1:0713/012012.401800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012012.402518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , pt.fx.tick, (){var e,t=pt.timers,n=0;for(kn=pt.now();n<t.length;n++)e=t[n],e()||t[n]!==e||t.splice(n--,1);t.leng
[1:1:0713/012012.402866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012012.731069:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 926, 7fc447bb4881
[1:1:0713/012012.776058:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cd4f6c22860","ptid":"877 0x7fc44526f070 0x88e0c35e9e0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012012.776569:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://zhugeio.com/","ptid":"877 0x7fc44526f070 0x88e0c35e9e0 ","rf":"6:3_https://zhugeio.com/"}
[1:1:0713/012012.777004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhugeio.com/"
[1:1:0713/012012.777578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/012012.777797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
[1:1:0713/012012.778427:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a0842029c8, 0x88e0a708150
[1:1:0713/012012.778710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 100
[1:1:0713/012012.779103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 962
[1:1:0713/012012.779387:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7fc44526f070 0x88e0c319de0 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 926 0x7fc44526f070 0x88e0b5ed1e0 
[1:1:0713/012013.046305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 939 0x7fc4471972e0 0x88e0c35c760 , "https://zhugeio.com/"
[1:1:0713/012013.095216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://zhugeio.com/, 1cd4f6c22860, , , !function(t){var e={};function r(n){if(e[n])return e[n].exports;var o=e[n]={i:n,l:!1,exports:{}};ret
[1:1:0713/012013.095532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhugeio.com/", "zhugeio.com", 3, 1, , , 0
		remove user.12_5e65ceeb -> 0
		remove user.13_c6bb8dc -> 0
[1:1:0713/012013.327900:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x2a0842029c8, 0x88e0a708348
[1:1:0713/012013.328192:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhugeio.com/", 20000
[1:1:0713/012013.328668:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://zhugeio.com/, 976
[1:1:0713/012013.328971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 976 0x7fc44526f070 0x88e0b7dca60 , 6:3_https://zhugeio.com/, 1, -6:3_https://zhugeio.com/, 939 0x7fc4471972e0 0x88e0c35c760 
