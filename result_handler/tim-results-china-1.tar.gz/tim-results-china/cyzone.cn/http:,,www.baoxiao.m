[0713/012346.082119:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/012346.082740:INFO:switcher_clone.cc(787)] backtrace rip is 7fab16fce891
[0713/012347.151843:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/012347.152280:INFO:switcher_clone.cc(787)] backtrace rip is 7f89eae8c891
[1:1:0713/012347.164989:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/012347.165266:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/012347.170577:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/012348.564699:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/012348.565176:INFO:switcher_clone.cc(787)] backtrace rip is 7f89d49c4891
[34308:34308:0713/012348.664244:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ce24324a-38cd-4e8f-9224-0adafb6cdfa6
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[34341:34341:0713/012348.780025:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=34341
[34352:34352:0713/012348.780450:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=34352
[34308:34308:0713/012349.209418:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[34308:34338:0713/012349.210259:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/012349.210453:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/012349.210887:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/012349.211488:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/012349.211645:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/012349.214633:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x30bbcd8, 1
[1:1:0713/012349.215016:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x29b2b2c2, 0
[1:1:0713/012349.215207:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb3a099b, 3
[1:1:0713/012349.215399:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e53223, 2
[1:1:0713/012349.215617:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc2ffffffb2ffffffb229 ffffffd8ffffffbc0b03 2332ffffffe502 ffffff9b093a0b , 10104, 4
[1:1:0713/012349.216626:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34308:34338:0713/012349.216892:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING²�)ؼ#2��	:��?
[34308:34338:0713/012349.216978:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ²�)ؼ#2��	:�W��?
[1:1:0713/012349.216877:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89e90c70a0, 3
[1:1:0713/012349.217117:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89e9252080, 2
[34308:34338:0713/012349.217266:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/012349.217278:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89d2f15d20, -2
[34308:34338:0713/012349.217337:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 34360, 4, c2b2b229 d8bc0b03 2332e502 9b093a0b 
[1:1:0713/012349.236152:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/012349.237017:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e53223
[1:1:0713/012349.238008:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e53223
[1:1:0713/012349.239573:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e53223
[1:1:0713/012349.241099:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.241334:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.241515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.241708:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.242368:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e53223
[1:1:0713/012349.242708:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89eae8c7ba
[1:1:0713/012349.242887:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89eae83def, 7f89eae8c77a, 7f89eae8e0cf
[1:1:0713/012349.249682:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e53223
[1:1:0713/012349.250183:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e53223
[1:1:0713/012349.251119:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e53223
[1:1:0713/012349.253613:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.253843:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.254088:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.254315:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e53223
[1:1:0713/012349.255882:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e53223
[1:1:0713/012349.256352:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89eae8c7ba
[1:1:0713/012349.256525:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89eae83def, 7f89eae8c77a, 7f89eae8e0cf
[1:1:0713/012349.265619:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/012349.266100:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/012349.266248:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc521e4708, 0x7ffc521e4688)
[1:1:0713/012349.282101:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/012349.287923:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[34308:34308:0713/012349.786843:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34308:34308:0713/012349.787732:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[34308:34319:0713/012349.812693:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[34308:34319:0713/012349.812795:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[34308:34308:0713/012349.812989:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[34308:34308:0713/012349.813091:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[34308:34308:0713/012349.813293:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,34360, 4
[1:7:0713/012349.814919:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[34308:34330:0713/012349.874514:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/012349.936454:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x32da2c6f5220
[1:1:0713/012349.936817:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/012350.286034:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[34308:34308:0713/012352.025482:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[34308:34308:0713/012352.025558:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/012352.030240:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012352.033842:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/012353.376598:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/012353.469845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f4ed3c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/012353.470244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012353.515212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f4ed3c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/012353.515512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012353.676209:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/012353.676499:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012353.985146:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012353.993338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f4ed3c21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/012353.993586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012354.020913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012354.031430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f4ed3c21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/012354.031672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012354.043773:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/012354.047382:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x32da2c6f3e20
[1:1:0713/012354.047609:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[34308:34308:0713/012354.055763:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[34308:34308:0713/012354.062673:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[34308:34308:0713/012354.098316:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[34308:34308:0713/012354.098524:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/012354.156601:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012355.109215:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f89d4af02e0 0x32da2c83d760 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012355.110611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f4ed3c21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/012355.110893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012355.112440:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[34308:34308:0713/012355.187686:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/012355.188217:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x32da2c6f4820
[1:1:0713/012355.188491:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[34308:34308:0713/012355.199253:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/012355.203137:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/012355.203420:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[34308:34308:0713/012355.213532:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[34308:34308:0713/012355.225811:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34308:34308:0713/012355.226949:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[34308:34319:0713/012355.234001:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[34308:34319:0713/012355.234095:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[34308:34308:0713/012355.234339:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[34308:34308:0713/012355.234437:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[34308:34308:0713/012355.234643:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,34360, 4
[1:7:0713/012355.237634:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/012355.864184:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/012356.180468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7f89d4af02e0 0x32da2c8f19e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012356.181534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f4ed3c21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/012356.181846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012356.182698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[34308:34308:0713/012356.262270:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[34308:34308:0713/012356.262412:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/012356.286290:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[34308:34308:0713/012356.424260:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[34308:34338:0713/012356.424741:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/012356.424973:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/012356.425173:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/012356.425565:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/012356.425710:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/012356.428989:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3beef815, 1
[1:1:0713/012356.429447:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x26d5eddd, 0
[1:1:0713/012356.429644:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x7343025, 3
[1:1:0713/012356.429881:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b1b2f33, 2
[1:1:0713/012356.430085:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffddffffffedffffffd526 15fffffff8ffffffee3b 332f1b1b 25303407 , 10104, 5
[1:1:0713/012356.431330:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34308:34338:0713/012356.431617:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���&��;3/%04[�?
[34308:34338:0713/012356.431707:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���&��;3/%04�[�?
[1:1:0713/012356.431847:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89e90c70a0, 3
[34308:34338:0713/012356.432014:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 34404, 5, ddedd526 15f8ee3b 332f1b1b 25303407 
[1:1:0713/012356.432126:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89e9252080, 2
[1:1:0713/012356.432362:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89d2f15d20, -2
[1:1:0713/012356.459850:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/012356.460240:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b1b2f33
[1:1:0713/012356.460560:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b1b2f33
[1:1:0713/012356.461222:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b1b2f33
[1:1:0713/012356.462690:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.462923:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.463046:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.463144:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.463396:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b1b2f33
[1:1:0713/012356.463529:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89eae8c7ba
[1:1:0713/012356.463616:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89eae83def, 7f89eae8c77a, 7f89eae8e0cf
[1:1:0713/012356.465156:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b1b2f33
[1:1:0713/012356.465325:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b1b2f33
[1:1:0713/012356.465602:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b1b2f33
[1:1:0713/012356.466327:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.466450:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.466559:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.466660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1b2f33
[1:1:0713/012356.467146:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b1b2f33
[1:1:0713/012356.467314:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89eae8c7ba
[1:1:0713/012356.467394:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89eae83def, 7f89eae8c77a, 7f89eae8e0cf
[1:1:0713/012356.469686:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/012356.470049:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/012356.470164:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc521e4708, 0x7ffc521e4688)
[1:1:0713/012356.483124:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/012356.487669:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/012356.690182:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/012356.701994:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x32da2c6ba220
[1:1:0713/012356.702244:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/012357.340216:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/012357.340450:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012357.579674:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012357.584400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f4ed3d4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/012357.584667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/012357.592141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012357.779905:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012357.780698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f4ed3c21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/012357.781158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012357.944407:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012357.946362:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/012357.946595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f4ed3d4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/012357.946882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/012358.089643:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012358.099195:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/012358.099412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f4ed3d4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/012358.099674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[34308:34308:0713/012358.157530:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34308:34308:0713/012358.186422:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[34308:34338:0713/012358.186858:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0713/012358.187049:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/012358.187283:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/012358.187568:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/012358.187666:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0713/012358.189562:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x35c6056f, 1
[1:1:0713/012358.189859:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1c130cd, 0
[1:1:0713/012358.190048:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x16a85a6f, 3
[1:1:0713/012358.190208:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x150737b0, 2
[1:1:0713/012358.190418:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcd30ffffffc101 6f05ffffffc635 ffffffb0370715 6f5affffffa816 , 10104, 6
[1:1:0713/012358.191310:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34308:34338:0713/012358.191588:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�0�o�5�7oZ�V�?
[34308:34338:0713/012358.191655:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �0�o�5�7oZ�(;V�?
[1:1:0713/012358.191758:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89e90c70a0, 3
[34308:34338:0713/012358.191914:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 34420, 6, cd30c101 6f05c635 b0370715 6f5aa816 
[1:1:0713/012358.191935:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89e9252080, 2
[1:1:0713/012358.192108:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89d2f15d20, -2
[1:1:0713/012358.206474:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/012358.206689:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 150737b0
[1:1:0713/012358.206827:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 150737b0
[1:1:0713/012358.207059:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 150737b0
[1:1:0713/012358.207534:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.207653:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.207749:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.207839:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.208064:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 150737b0
[1:1:0713/012358.208183:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89eae8c7ba
[1:1:0713/012358.208256:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89eae83def, 7f89eae8c77a, 7f89eae8e0cf
[1:1:0713/012358.209717:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 150737b0
[1:1:0713/012358.209876:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 150737b0
[1:1:0713/012358.210143:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 150737b0
[1:1:0713/012358.210839:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.210962:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.211065:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.211157:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 150737b0
[1:1:0713/012358.211607:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 150737b0
[1:1:0713/012358.211769:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89eae8c7ba
[1:1:0713/012358.211844:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89eae83def, 7f89eae8c77a, 7f89eae8e0cf
[1:1:0713/012358.214016:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/012358.214367:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/012358.214462:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc521e4708, 0x7ffc521e4688)
[34308:34308:0713/012358.223832:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/012358.226637:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/012358.231775:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[34308:34319:0713/012358.242852:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[34308:34319:0713/012358.242942:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[34308:34308:0713/012358.243355:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.deallinker.cn/
[34308:34308:0713/012358.243458:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.deallinker.cn/, https://www.deallinker.cn/, 1
[34308:34308:0713/012358.243597:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.deallinker.cn/, HTTP/1.1 200 OK Server: nginx/1.4.6 (Ubuntu) Date: Sat, 13 Jul 2019 08:23:58 GMT Content-Type: text/html Last-Modified: Fri, 15 Jun 2018 09:53:30 GMT Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip  ,0, 6
[3:3:0713/012358.250270:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0713/012358.314125:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/012358.387488:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0713/012358.502515:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x32da2c6da220
[1:1:0713/012358.502796:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/012358.588343:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.deallinker.cn/
[1:1:0713/012358.600234:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0713/012358.867037:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mobile.zol.com.cn/"
[34308:34308:0713/012358.876904:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.deallinker.cn/, https://www.deallinker.cn/, 1
[34308:34308:0713/012358.877046:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.deallinker.cn/, https://www.deallinker.cn
[1:1:0713/012358.904954:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/012358.960710:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.researchgate.net/?_sg=GTTcjmmIjXiKFH9nfUmSzdlSVNCfHlOW5NedMmBB5tECtK-L3s9hJP_gtJf5_sYEDAmD6IvCizZl"
[1:1:0713/012359.000788:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://stackoverflow.com/"
[1:1:0713/012359.043032:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/012359.067344:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.fandom.com/"
[1:1:0713/012359.127218:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/012359.127464:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.deallinker.cn/"
[1:1:0713/012359.142246:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0713/012359.232329:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.springer.com/"
[1:1:0713/012359.589071:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012359.835864:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012359.836880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f4ed3d4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/012359.837185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/012359.920398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012359.921341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f4ed3d4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/012359.921620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/012359.983256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 163 0x7f89d2f30bd0 0x32da2c748ad8 , "https://www.deallinker.cn/"
[1:1:0713/012359.993460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , /*! jQuery v3.1.0 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"use strict";"objec
[1:1:0713/012359.993707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012400.013420:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012400.018183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012400.019047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f4ed3d4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/012400.019314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/012400.137361:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012400.138280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f4ed3d4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/012400.138581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/012400.183944:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 163 0x7f89d2f30bd0 0x32da2c748ad8 , "https://www.deallinker.cn/"
[1:1:0713/012400.188462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 163 0x7f89d2f30bd0 0x32da2c748ad8 , "https://www.deallinker.cn/"
		remove user.f_e5cfa0e9 -> 0
[1:1:0713/012400.204120:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 163 0x7f89d2f30bd0 0x32da2c748ad8 , "https://www.deallinker.cn/"
[1:1:0713/012400.237768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 163 0x7f89d2f30bd0 0x32da2c748ad8 , "https://www.deallinker.cn/"
[1:1:0713/012400.360632:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.180735, 532, 1
[1:1:0713/012400.360931:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/012400.859224:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[34308:34333:0713/012400.901703:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/012400.908212:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/012400.908412:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.deallinker.cn/"
[1:1:0713/012400.909253:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f89d2bc8070 0x32da2c8b7060 , "https://www.deallinker.cn/"
[1:1:0713/012400.910728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , 
        $(document).ready(function() {
            $("#sw-online-consult").click(function(e) {
    
[1:1:0713/012400.910916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012400.953831:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.deallinker.cn/"
[1:1:0713/012400.957242:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d97edb629c8, 0x32da2c552440
[1:1:0713/012400.957356:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 0
[1:1:0713/012400.957519:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 247
[1:1:0713/012400.957624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 247 0x7f89d2bc8070 0x32da2c81ad60 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 206 0x7f89d2bc8070 0x32da2c8b7060 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/012404.120270:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://www.deallinker.cn/"
[1:1:0713/012405.407968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 247, 7f89d550d881
[1:1:0713/012405.426136:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"206 0x7f89d2bc8070 0x32da2c8b7060 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012405.426556:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"206 0x7f89d2bc8070 0x32da2c8b7060 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012405.426972:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012405.427629:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0713/012405.427844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012405.600817:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012405.601065:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012405.601514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 363
[1:1:0713/012405.601709:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 363 0x7f89d2bc8070 0x32da2c7b73e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012405.711924:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012405.712177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012405.712574:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 364
[1:1:0713/012405.712817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7f89d2bc8070 0x32da2c8bd060 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012405.812427:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012405.812647:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012405.812986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 365
[1:1:0713/012405.813175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 365 0x7f89d2bc8070 0x32da2ca38260 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012405.897848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012405.898073:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012405.898554:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 366
[1:1:0713/012405.898776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 366 0x7f89d2bc8070 0x32da2ca1fc60 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012406.013727:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012406.013956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012406.014306:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 367
[1:1:0713/012406.014555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 367 0x7f89d2bc8070 0x32da2c74b9e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012406.118062:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012406.118249:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012406.118540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 369
[1:1:0713/012406.118697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 369 0x7f89d2bc8070 0x32da2ca60260 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012406.232579:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012406.232880:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012406.233305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 370
[1:1:0713/012406.233582:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7f89d2bc8070 0x32da2ca1f5e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012406.313305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012406.313510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 20
[1:1:0713/012406.313723:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 371
[1:1:0713/012406.313836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 371 0x7f89d2bc8070 0x32da2c82c660 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012406.354358:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012406.354641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 0
[1:1:0713/012406.354980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 372
[1:1:0713/012406.355169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 372 0x7f89d2bc8070 0x32da2c8d1e60 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 247 0x7f89d2bc8070 0x32da2c81ad60 
[1:1:0713/012406.943099:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 324 0x7f89d4af02e0 0x32da2c8bc5e0 , "https://www.deallinker.cn/"
[1:1:0713/012406.952716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (function(){var h={},mt={},c={id:"8a985b676a94907e01ba772586df30c0",dm:["deallinker.cn"],js:"tongji.
[1:1:0713/012406.952938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012406.984442:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552148
[1:1:0713/012406.984606:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012406.984807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 391
[1:1:0713/012406.984919:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 391 0x7f89d2bc8070 0x32da2cc00860 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 324 0x7f89d4af02e0 0x32da2c8bc5e0 
[1:1:0713/012407.439013:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012407.439613:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012407.440171:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012407.441316:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012407.441810:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[34308:34308:0713/012438.632297:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/012438.647348:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/012438.765220:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012438.782846:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 600000
[1:1:0713/012438.783570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.deallinker.cn/, 433
[1:1:0713/012438.783801:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 433 0x7f89d2bc8070 0x32da2c8c25e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 324 0x7f89d4af02e0 0x32da2c8bc5e0 
[1:1:0713/012438.784663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 5000
[1:1:0713/012438.785037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.deallinker.cn/, 434
[1:1:0713/012438.785264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 434 0x7f89d2bc8070 0x32da2c07d160 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 324 0x7f89d4af02e0 0x32da2c8bc5e0 
[1:1:0713/012438.853084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 325 0x7f89d4af02e0 0x32da2c8c4d60 , "https://www.deallinker.cn/"
[1:1:0713/012438.855394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , window._zhugeSdk=function(e){var t={};function i(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1
[1:1:0713/012438.855661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012439.105937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2d97edb629c8, 0x32da2c552148
[1:1:0713/012439.106184:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 500
[1:1:0713/012439.106524:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 458
[1:1:0713/012439.106712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 458 0x7f89d2bc8070 0x32da2c81aae0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 325 0x7f89d4af02e0 0x32da2c8c4d60 
[1:1:0713/012439.197398:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2d97edb629c8, 0x32da2c552148
[1:1:0713/012439.197614:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 500
[1:1:0713/012439.197949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 461
[1:1:0713/012439.198184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 461 0x7f89d2bc8070 0x32da2cbfeae0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 325 0x7f89d4af02e0 0x32da2c8c4d60 
[1:1:0713/012439.214257:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 12000
[1:1:0713/012439.214616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.deallinker.cn/, 463
[1:1:0713/012439.214804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 463 0x7f89d2bc8070 0x32da2c8d1a60 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 325 0x7f89d4af02e0 0x32da2c8c4d60 
[1:1:0713/012440.008444:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 363, 7f89d550d881
[1:1:0713/012440.027978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.028304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.028680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.029225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.029454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.035268:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 364, 7f89d550d881
[1:1:0713/012440.054420:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.054770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.055170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.055721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.055998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.061066:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 365, 7f89d550d881
[1:1:0713/012440.080466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.080852:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.081275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.081894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.082176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.126280:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://www.deallinker.cn/"
[1:1:0713/012440.127888:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 366, 7f89d550d881
[1:1:0713/012440.147258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.147593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.147967:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.148525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.148739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.153748:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 367, 7f89d550d881
[1:1:0713/012440.172975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.173261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.173623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.174103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.174342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.179122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 369, 7f89d550d881
[1:1:0713/012440.198897:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.199248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.199646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.200180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.200414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.245199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 370, 7f89d550d881
[1:1:0713/012440.264590:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.264933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.265339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.265898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.266136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.271625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 371, 7f89d550d881
[1:1:0713/012440.291012:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.291304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.291670:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.292165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){var d=b.setting.speed/1e3||.5;c.css({transition:"all "+d+"s ease-out"}),"function"==typeof a&&a.c
[1:1:0713/012440.292373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.297305:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 372, 7f89d550d881
[1:1:0713/012440.316703:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.317014:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"247 0x7f89d2bc8070 0x32da2c81ad60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.317384:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.317899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0713/012440.318127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.460181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/012440.460494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.949352:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 391, 7f89d550d881
[1:1:0713/012440.969943:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"324 0x7f89d4af02e0 0x32da2c8bc5e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.970290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"324 0x7f89d4af02e0 0x32da2c8bc5e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012440.970709:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012440.971325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012440.971536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012440.972320:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012440.972511:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012440.972885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 491
[1:1:0713/012440.973108:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 491 0x7f89d2bc8070 0x32da2cbfa2e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 391 0x7f89d2bc8070 0x32da2cc00860 
[1:1:0713/012441.442446:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 458, 7f89d550d881
[1:2:0713/012441.447876:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012441.464261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"325 0x7f89d4af02e0 0x32da2c8c4d60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012441.464594:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"325 0x7f89d4af02e0 0x32da2c8c4d60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012441.465039:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012441.465595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){!n&&t&&(t(),n=!0)}
[1:1:0713/012441.465854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012441.467560:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 461, 7f89d550d881
[1:1:0713/012441.488766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"325 0x7f89d4af02e0 0x32da2c8c4d60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012441.489091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"325 0x7f89d4af02e0 0x32da2c8c4d60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012441.489486:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012441.490016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , (){!n&&t&&(t(),n=!0)}
[1:1:0713/012441.490253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012441.513297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , document.readyState
[1:1:0713/012441.513519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.087743:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 491, 7f89d550d881
[1:1:0713/012442.110442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"391 0x7f89d2bc8070 0x32da2cc00860 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012442.110782:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"391 0x7f89d2bc8070 0x32da2cc00860 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012442.111224:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012442.111953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012442.112206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.112971:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012442.113175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012442.113544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 545
[1:1:0713/012442.113777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 545 0x7f89d2bc8070 0x32da2cc9b060 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 491 0x7f89d2bc8070 0x32da2cbfa2e0 
[1:1:0713/012442.225463:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.deallinker.cn/"
[1:1:0713/012442.226507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0713/012442.226740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.248208:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.deallinker.cn/"
[1:1:0713/012442.248893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , r, (){!n&&t&&(clearTimeout(o),t())}
[1:1:0713/012442.249118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.319383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.deallinker.cn/"
[1:1:0713/012442.320136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , r, (){!n&&t&&(clearTimeout(o),t())}
[1:1:0713/012442.320402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.440251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , document.readyState
[1:1:0713/012442.440515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.631524:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.deallinker.cn/"
[1:1:0713/012442.632244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , q.handle, (b){return"undefined"!=typeof r&&r.event.triggered!==b.type?r.event.dispatch.apply(a,arguments):void
[1:1:0713/012442.632482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.946021:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 545, 7f89d550d881
[1:1:0713/012442.969556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"491 0x7f89d2bc8070 0x32da2cbfa2e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012442.969901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"491 0x7f89d2bc8070 0x32da2cbfa2e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012442.970344:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012442.970917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012442.971145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012442.971833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012442.972024:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012442.972528:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 572
[1:1:0713/012442.972766:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 572 0x7f89d2bc8070 0x32da2cda53e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 545 0x7f89d2bc8070 0x32da2cc9b060 
[1:1:0713/012443.082277:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.deallinker.cn/"
[1:1:0713/012443.083003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , window.onload, () {
                    if ($(window).width() < 768) {
                        $(".list-title ul").
[1:1:0713/012443.083237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012443.110713:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.deallinker.cn/"
[1:1:0713/012443.114118:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://www.deallinker.cn/"
[1:1:0713/012443.115565:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c5522f0
[1:1:0713/012443.115768:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012443.116133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 580
[1:1:0713/012443.116374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7f89d2bc8070 0x32da2ca3ace0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 555 0x7f89e9252080 0x32da2dd01b00 1 0 0x32da2dd01b18 
[1:1:0713/012443.155113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , , document.readyState
[1:1:0713/012443.155380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012443.796039:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 580, 7f89d550d881
[1:1:0713/012443.823438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"555 0x7f89e9252080 0x32da2dd01b00 1 0 0x32da2dd01b18 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012443.823715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"555 0x7f89e9252080 0x32da2dd01b00 1 0 0x32da2dd01b18 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012443.824040:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012443.824568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012443.824744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012443.825416:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012443.825609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012443.826182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 609
[1:1:0713/012443.826488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f89d2bc8070 0x32da2c6f75e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 580 0x7f89d2bc8070 0x32da2ca3ace0 
[1:1:0713/012444.287732:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.deallinker.cn/, 434, 7f89d550d8db
[1:1:0713/012444.312575:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"324 0x7f89d4af02e0 0x32da2c8bc5e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012444.312827:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"324 0x7f89d4af02e0 0x32da2c8bc5e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012444.313259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.deallinker.cn/, 622
[1:1:0713/012444.313447:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f89d2bc8070 0x32da2c6ea6e0 , 6:3_https://www.deallinker.cn/, 0, , 434 0x7f89d2bc8070 0x32da2c07d160 
[1:1:0713/012444.313726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012444.314197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/012444.314367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012444.486924:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 609, 7f89d550d881
[1:1:0713/012444.513631:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"580 0x7f89d2bc8070 0x32da2ca3ace0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012444.513900:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"580 0x7f89d2bc8070 0x32da2ca3ace0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012444.514278:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012444.514825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012444.515006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012444.515701:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012444.515864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012444.516193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 632
[1:1:0713/012444.516384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 632 0x7f89d2bc8070 0x32da2ddcd9e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 609 0x7f89d2bc8070 0x32da2c6f75e0 
[1:1:0713/012444.861336:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://www.deallinker.cn/"
[1:1:0713/012444.920398:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 632, 7f89d550d881
[1:1:0713/012444.946052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"609 0x7f89d2bc8070 0x32da2c6f75e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012444.946301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"609 0x7f89d2bc8070 0x32da2c6f75e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012444.946609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012444.947221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012444.947398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012444.948064:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012444.948222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012444.948538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 654
[1:1:0713/012444.948748:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f89d2bc8070 0x32da2c6f7ae0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 632 0x7f89d2bc8070 0x32da2ddcd9e0 
[1:1:0713/012445.405653:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 654, 7f89d550d881
[1:1:0713/012445.431728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"632 0x7f89d2bc8070 0x32da2ddcd9e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012445.432007:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"632 0x7f89d2bc8070 0x32da2ddcd9e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012445.432340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012445.432856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012445.433063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012445.433705:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012445.433883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012445.434197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 664
[1:1:0713/012445.434381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f89d2bc8070 0x32da2dd2b2e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 654 0x7f89d2bc8070 0x32da2c6f7ae0 
[1:1:0713/012445.678480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://www.deallinker.cn/"
[1:1:0713/012445.680160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 664, 7f89d550d881
[1:1:0713/012445.711414:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"654 0x7f89d2bc8070 0x32da2c6f7ae0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012445.711764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"654 0x7f89d2bc8070 0x32da2c6f7ae0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012445.712217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012445.712803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012445.713054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012445.713767:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012445.713987:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012445.714398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 692
[1:1:0713/012445.714632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7f89d2bc8070 0x32da2c27c3e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 664 0x7f89d2bc8070 0x32da2dd2b2e0 
[1:7:0713/012445.887965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012446.440689:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 692, 7f89d550d881
[1:1:0713/012446.469341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"664 0x7f89d2bc8070 0x32da2dd2b2e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012446.470244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"664 0x7f89d2bc8070 0x32da2dd2b2e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012446.471301:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012446.472759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012446.473216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012446.475204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012446.475570:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012446.476460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 713
[1:1:0713/012446.476965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f89d2bc8070 0x32da2c357f60 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 692 0x7f89d2bc8070 0x32da2c27c3e0 
[1:1:0713/012447.193760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "durationchange", "https://www.deallinker.cn/"
[1:1:0713/012447.195318:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadedmetadata", "https://www.deallinker.cn/"
[1:1:0713/012447.196757:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadeddata", "https://www.deallinker.cn/"
[1:1:0713/012447.336033:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 713, 7f89d550d881
[1:1:0713/012447.353694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"692 0x7f89d2bc8070 0x32da2c27c3e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012447.353877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"692 0x7f89d2bc8070 0x32da2c27c3e0 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0713/012447.354128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.deallinker.cn/"
[1:1:0713/012447.354436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.deallinker.cn/, 35ffa9522860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/012447.354569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.deallinker.cn/", "www.deallinker.cn", 3, 1, , , 0
[1:1:0713/012447.354873:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d97edb629c8, 0x32da2c552150
[1:1:0713/012447.354986:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.deallinker.cn/", 100
[1:1:0713/012447.355153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 754
[1:1:0713/012447.355263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7f89d2bc8070 0x32da2dde65e0 , 6:3_https://www.deallinker.cn/, 1, -6:3_https://www.deallinker.cn/, 713 0x7f89d2bc8070 0x32da2c357f60 
[1:1:0713/012448.198265:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.deallinker.cn/, 754, 7f89d550d881
[1:1:0100/000000.262700:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35ffa9522860","ptid":"713 0x7f89d2bc8070 0x32da2c357f60 ","rf":"6:3_https://www.deallinker.cn/"}
[1:1:0100/000000.263355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.deallinker.cn/","ptid":"713 0x7f89d2bc8070 0x32da2c357f60 ","rf":"6:3_https://www.deallinker.cn/"}
