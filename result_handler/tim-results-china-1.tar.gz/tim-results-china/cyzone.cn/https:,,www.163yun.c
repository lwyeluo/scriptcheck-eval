[0713/011746.252324:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011746.252661:INFO:switcher_clone.cc(787)] backtrace rip is 7fcfbcfa3891
[0713/011747.285726:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011747.286102:INFO:switcher_clone.cc(787)] backtrace rip is 7f246c943891
[1:1:0713/011747.290214:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/011747.290392:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/011747.295381:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[33626:33626:0713/011748.773986:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0713/011748.850995:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/011748.851504:INFO:switcher_clone.cc(787)] backtrace rip is 7efca3d00891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6582a569-7ead-41f0-a0fc-6d5a88395e8b
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[33658:33658:0713/011749.089312:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33658
[33671:33671:0713/011749.089830:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33671
[33626:33626:0713/011749.285480:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[33626:33656:0713/011749.286451:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/011749.286692:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011749.286899:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011749.287436:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011749.287610:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/011749.290526:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x32f0cd19, 1
[1:1:0713/011749.290871:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x184ed5bd, 0
[1:1:0713/011749.291062:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3fb1a682, 3
[1:1:0713/011749.291265:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2406c732, 2
[1:1:0713/011749.291461:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbdffffffd54e18 19ffffffcdfffffff032 32ffffffc70624 ffffff82ffffffa6ffffffb13f , 10104, 4
[1:1:0713/011749.292534:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33626:33656:0713/011749.292848:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��N��22�$���?ׅ"
[33626:33656:0713/011749.292937:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��N��22�$���?xLׅ"
[1:1:0713/011749.292836:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f246ab7e0a0, 3
[33626:33656:0713/011749.293251:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/011749.293048:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f246ad09080, 2
[33626:33656:0713/011749.293343:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33679, 4, bdd54e18 19cdf032 32c70624 82a6b13f 
[1:1:0713/011749.293410:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f24549ccd20, -2
[1:1:0713/011749.312104:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011749.313171:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2406c732
[1:1:0713/011749.314286:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2406c732
[1:1:0713/011749.316264:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2406c732
[1:1:0713/011749.317984:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.318315:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.318537:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.318804:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.319492:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2406c732
[1:1:0713/011749.319871:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f246c9437ba
[1:1:0713/011749.320042:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f246c93adef, 7f246c94377a, 7f246c9450cf
[1:1:0713/011749.325836:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2406c732
[1:1:0713/011749.326304:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2406c732
[1:1:0713/011749.327105:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2406c732
[1:1:0713/011749.329193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.329420:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.329676:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.329898:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2406c732
[1:1:0713/011749.331194:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2406c732
[1:1:0713/011749.331604:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f246c9437ba
[1:1:0713/011749.331776:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f246c93adef, 7f246c94377a, 7f246c9450cf
[1:1:0713/011749.339528:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011749.339995:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011749.340172:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffca1654088, 0x7ffca1654008)
[1:1:0713/011749.356458:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011749.362440:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[33626:33626:0713/011749.952165:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33626:33626:0713/011749.952654:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33626:33638:0713/011749.968532:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[33626:33638:0713/011749.968634:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[33626:33626:0713/011749.968795:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[33626:33626:0713/011749.968874:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[33626:33626:0713/011749.969019:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,33679, 4
[1:7:0713/011749.971276:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[33626:33650:0713/011750.043163:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/011750.066512:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x378614e6220
[1:1:0713/011750.066818:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/011750.435241:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/011752.111443:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011752.116092:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[33626:33626:0713/011752.123940:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[33626:33626:0713/011752.124050:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011753.290045:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011753.450516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33b84c9a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011753.450831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011753.467852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33b84c9a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/011753.468073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011753.670395:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011753.670569:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011754.025674:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011754.033725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33b84c9a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011754.033967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011754.070620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011754.081160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33b84c9a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/011754.081405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011754.093396:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/011754.097749:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x378614e4e20
[1:1:0713/011754.098025:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[33626:33626:0713/011754.103238:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[33626:33626:0713/011754.125327:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[33626:33626:0713/011754.142383:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[33626:33626:0713/011754.142474:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/011754.201040:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011755.092628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f24565a72e0 0x3786179a160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011755.093386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33b84c9a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/011755.093799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011755.095344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[33626:33626:0713/011755.167037:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/011755.169337:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x378614e5820
[1:1:0713/011755.169971:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[33626:33626:0713/011755.174603:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/011755.187884:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/011755.188100:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[33626:33626:0713/011755.195401:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[33626:33626:0713/011755.206739:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33626:33626:0713/011755.207968:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33626:33638:0713/011755.214837:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[33626:33626:0713/011755.214919:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[33626:33638:0713/011755.214944:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[33626:33626:0713/011755.215018:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[33626:33626:0713/011755.215205:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,33679, 4
[1:7:0713/011755.219453:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011755.787315:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/011756.397641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f24565a72e0 0x37861757960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011756.398724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33b84c9a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/011756.398973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/011756.399757:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[33626:33626:0713/011756.537882:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[33626:33626:0713/011756.538118:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/011756.557986:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[33626:33626:0713/011756.607210:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[33626:33656:0713/011756.607647:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/011756.607870:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/011756.608185:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/011756.608749:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/011756.609010:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/011756.612842:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26acba60, 1
[1:1:0713/011756.613196:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x27bfc081, 0
[1:1:0713/011756.613347:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x31ac17c, 3
[1:1:0713/011756.613512:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1473c97a, 2
[1:1:0713/011756.613664:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff81ffffffc0ffffffbf27 60ffffffbaffffffac26 7affffffc97314 7cffffffc11a03 , 10104, 5
[1:1:0713/011756.614789:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33626:33656:0713/011756.615070:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���'`��&z�s|�T�"
[33626:33656:0713/011756.615170:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���'`��&z�s|�H
T�"
[33626:33656:0713/011756.615442:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33723, 5, 81c0bf27 60baac26 7ac97314 7cc11a03 
[1:1:0713/011756.615321:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f246ab7e0a0, 3
[1:1:0713/011756.615621:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f246ad09080, 2
[1:1:0713/011756.615849:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f24549ccd20, -2
[1:1:0713/011756.639808:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/011756.640258:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1473c97a
[1:1:0713/011756.640650:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1473c97a
[1:1:0713/011756.641376:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1473c97a
[1:1:0713/011756.643094:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.643320:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.643557:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.643802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.644578:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1473c97a
[1:1:0713/011756.644947:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f246c9437ba
[1:1:0713/011756.645123:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f246c93adef, 7f246c94377a, 7f246c9450cf
[1:1:0713/011756.647691:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1473c97a
[1:1:0713/011756.647874:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1473c97a
[1:1:0713/011756.648143:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1473c97a
[1:1:0713/011756.648839:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.648954:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.649057:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.649155:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1473c97a
[1:1:0713/011756.649637:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1473c97a
[1:1:0713/011756.649801:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f246c9437ba
[1:1:0713/011756.649877:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f246c93adef, 7f246c94377a, 7f246c9450cf
[1:1:0713/011756.652126:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/011756.652482:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/011756.652598:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffca1654088, 0x7ffca1654008)
[1:1:0713/011756.665357:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/011756.671151:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/011756.883013:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x378614be220
[1:1:0713/011756.883280:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/011756.942341:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011757.837729:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011757.838027:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[33626:33626:0713/011758.166293:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33626:33626:0713/011758.168779:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33626:33638:0713/011758.215813:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[33626:33638:0713/011758.215963:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[33626:33626:0713/011758.216302:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.163yun.com/
[33626:33626:0713/011758.216384:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.163yun.com/, https://www.163yun.com/, 1
[33626:33626:0713/011758.216531:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.163yun.com/, HTTP/1.1 200 OK Server: nginx/1.10.1 Date: Sat, 13 Jul 2019 08:17:58 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked X-Application-Context: homesite:homesite,identity_data_local,identity_rest_local,prod:8182 Set-Cookie: logStashId=308409317544554497; Domain=163yun.com; Expires=Sun, 14-Jul-2019 08:17:57 GMT; Path=/; HttpOnly Set-Cookie: wyy_uid=4e9b12ea-cf58-4110-bf8b-8725c346fb60; Domain=163yun.com; Expires=Sun, 12-Jul-2020 08:17:57 GMT; Path=/; HttpOnly Set-Cookie: pageContentBiz=market; Domain=163yun.com; Expires=Mon, 12-Aug-2019 08:17:57 GMT; Path=/; HttpOnly Content-Language: en-US Content-Encoding: gzip  ,33723, 5
[1:7:0713/011758.221468:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/011758.248666:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.163yun.com/
[1:1:0713/011758.264439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/011758.269235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33b84cace5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/011758.269596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/011758.278539:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[33626:33626:0713/011758.351580:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.163yun.com/, https://www.163yun.com/, 1
[33626:33626:0713/011758.351713:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.163yun.com/, https://www.163yun.com
[1:1:0713/011758.392088:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/011758.504045:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011758.586449:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/011758.652539:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011758.652827:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.163yun.com/"
[1:1:0713/011758.772267:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/011758.773005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33b84c9a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/011758.773248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/011800.667618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f245467f070 0x3786168b7e0 , "https://www.163yun.com/"
[1:1:0713/011800.668516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , 
var _hmt = _hmt || [];
(function()
{ var hm = document.createElement("script"); hm.src = "https://h
[1:1:0713/011800.668655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011800.669214:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011800.918543:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.244362, 1177, 1
[1:1:0713/011800.918879:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011803.010315:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011803.010549:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.163yun.com/"
[1:1:0713/011803.011342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 349 0x7f245467f070 0x37861877be0 , "https://www.163yun.com/"
[1:1:0713/011803.012165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , 
window['commonHeaderOptions'] = [{"text":"容器服务"},{"text":"云服务器"},{"text":"云硬盘
[1:1:0713/011803.012379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011803.327488:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.316868, 2120, 1
[1:1:0713/011803.327749:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011804.441792:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011806.562319:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[33626:33651:0713/011806.609416:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/011806.620390:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011806.620645:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.163yun.com/"
[1:1:0713/011806.630852:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7f245467f070 0x3786186dd60 , "https://www.163yun.com/"
[1:1:0713/011806.643631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , !function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==type
[1:1:0713/011806.643915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011807.100657:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011807.101057:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011807.101554:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011807.103645:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7f245467f070 0x3786186dd60 , "https://www.163yun.com/"
[1:1:0713/011807.103882:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011807.104218:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011807.122627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7f245467f070 0x3786186dd60 , "https://www.163yun.com/"
		remove user.10_dbeac542 -> 0
		remove user.11_648fcd -> 0
[1:1:0713/011807.184357:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.563626, 0, 0
[1:1:0713/011807.184643:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011808.572818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7f24565a72e0 0x378615f0360 , "https://www.163yun.com/"
[1:1:0713/011808.582721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , (function(){var h={},mt={},c={id:"34b4e2ce36a1bc364012b1aa8161c8b8",dm:["www.163yun.com","id.163yun.
[1:1:0713/011808.583013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011808.607384:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b148
[1:1:0713/011808.607644:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011808.608011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 691
[1:1:0713/011808.608237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f245467f070 0x378619c47e0 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 557 0x7f24565a72e0 0x378615f0360 
[33626:33626:0713/011835.958846:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/011835.963982:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/011840.271097:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 600000
[1:1:0713/011840.271533:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.163yun.com/, 814
[1:1:0713/011840.271774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7f245467f070 0x3786201d2e0 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 557 0x7f24565a72e0 0x378615f0360 
[1:1:0713/011840.272614:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 5000
[1:1:0713/011840.273086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.163yun.com/, 815
[1:1:0713/011840.273312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f245467f070 0x37861e43560 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 557 0x7f24565a72e0 0x378615f0360 
[1:1:0713/011840.287606:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/011842.809420:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://www.163yun.com/"
[1:1:0713/011843.324813:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/011843.324990:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.163yun.com/"
[1:1:0713/011843.796393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/011843.796652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011848.592794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 691, 7f2456fc4881
[1:1:0713/011848.610384:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"557 0x7f24565a72e0 0x378615f0360 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011848.610693:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"557 0x7f24565a72e0 0x378615f0360 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011848.611112:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011848.611699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0713/011848.611915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011848.612685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b150
[1:1:0713/011848.612887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011848.613241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 906
[1:1:0713/011848.613492:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 906 0x7f245467f070 0x378627420e0 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 691 0x7f245467f070 0x378619c47e0 
[1:1:0713/011849.397242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , document.readyState
[1:1:0713/011849.397567:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011850.357896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.163yun.com/, 815, 7f2456fc48db
[1:1:0713/011850.380089:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"557 0x7f24565a72e0 0x378615f0360 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011850.380399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"557 0x7f24565a72e0 0x378615f0360 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011850.380846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.163yun.com/, 953
[1:1:0713/011850.381071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 953 0x7f245467f070 0x378627a2c60 , 5:3_https://www.163yun.com/, 0, , 815 0x7f245467f070 0x37861e43560 
[1:1:0713/011850.381357:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011850.381878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/011850.382119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011851.913729:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 906, 7f2456fc4881
[1:1:0713/011851.957960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"691 0x7f245467f070 0x378619c47e0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011851.958342:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"691 0x7f245467f070 0x378619c47e0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011851.959462:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011851.960130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0713/011851.960351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011851.961002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b150
[1:1:0713/011851.961217:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011851.961578:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 988
[1:1:0713/011851.961803:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 988 0x7f245467f070 0x378619fcce0 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 906 0x7f245467f070 0x378627420e0 
[1:1:0713/011852.052580:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.163yun.com/"
[1:1:0713/011852.054643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , g.onload, (){g.onload=w;g=window[d]=w;a&&a(b)}
[1:1:0713/011852.054876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011852.197189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f24565a72e0 0x37861a526e0 , "https://www.163yun.com/"
[1:1:0713/011852.198338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , 
[1:1:0713/011852.198555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:17:0713/011852.326564:ERROR:render_media_log.cc(30)] MediaEvent: MEDIA_ERROR_LOG_ENTRY {"error":"FFmpegDemuxer: no supported streams"}
[1:1:0713/011852.537147:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://www.163yun.com/"
[1:1:0713/011852.537759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://www.163yun.com/"
[1:1:0713/011852.580792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , document.readyState
[1:1:0713/011852.581064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011854.903725:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 988, 7f2456fc4881
[1:1:0713/011854.922667:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"906 0x7f245467f070 0x378627420e0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011854.923020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"906 0x7f245467f070 0x378627420e0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011854.923444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011854.924062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0713/011854.924306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011854.925034:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b150
[1:1:0713/011854.925233:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011854.925630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1029
[1:1:0713/011854.925862:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f245467f070 0x37861e34e60 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 988 0x7f245467f070 0x378619fcce0 
[1:1:0713/011855.171664:ERROR:render_media_log.cc(30)] MediaEvent: PIPELINE_ERROR DEMUXER_ERROR_NO_SUPPORTED_STREAMS
[1:1:0713/011855.360312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , document.readyState
[1:1:0713/011855.360583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011855.997739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1029, 7f2456fc4881
[1:1:0713/011856.012916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"988 0x7f245467f070 0x378619fcce0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011856.013089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"988 0x7f245467f070 0x378619fcce0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011856.013316:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011856.013613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0713/011856.013720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011856.014016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b150
[1:1:0713/011856.014113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011856.014310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1065
[1:1:0713/011856.014427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1065 0x7f245467f070 0x37861b7fce0 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 1029 0x7f245467f070 0x37861e34e60 
[1:1:0713/011856.309726:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.163yun.com/, 953, 7f2456fc48db
[1:1:0713/011856.323892:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"815 0x7f245467f070 0x37861e43560 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011856.324044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"815 0x7f245467f070 0x37861e43560 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011856.324262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.163yun.com/, 1072
[1:1:0713/011856.324402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1072 0x7f245467f070 0x37861bc5be0 , 5:3_https://www.163yun.com/, 0, , 953 0x7f245467f070 0x378627a2c60 
[1:1:0713/011856.324584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011856.324861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/011856.324964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011856.821667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1065, 7f2456fc4881
[1:1:0713/011856.845317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"1029 0x7f245467f070 0x37861e34e60 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011856.845528:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"1029 0x7f245467f070 0x37861e34e60 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011856.845737:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011856.846058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0713/011856.846165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011856.846521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b150
[1:1:0713/011856.846627:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011856.846798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1089
[1:1:0713/011856.846909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7f245467f070 0x37861654d60 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 1065 0x7f245467f070 0x37861b7fce0 
[1:1:0713/011857.333310:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1089, 7f2456fc4881
[1:1:0713/011857.382656:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"1065 0x7f245467f070 0x37861b7fce0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011857.383040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"1065 0x7f245467f070 0x37861b7fce0 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011857.383503:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011857.384204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0713/011857.384425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011857.385027:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b150
[1:1:0713/011857.385158:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011857.385332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1100
[1:1:0713/011857.385452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7f245467f070 0x37861b7fc60 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 1089 0x7f245467f070 0x37861654d60 
[1:1:0713/011857.562326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7f24549e7bd0 0x378627c9858 , "https://www.163yun.com/"
[1:1:0713/011857.570762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , , !function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==type
[1:1:0713/011857.570897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
		remove user.12_887cf37f -> 0
[33626:33626:0713/011857.982850:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0713/011859.254242:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7f24549e7bd0 0x378627c9858 , "https://www.163yun.com/"
[1:1:0713/011859.269939:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7f24549e7bd0 0x378627c9858 , "https://www.163yun.com/"
[1:1:0713/011859.539762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7f24549e7bd0 0x378627c9858 , "https://www.163yun.com/"
[1:1:0713/011859.566979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7f24549e7bd0 0x378627c9858 , "https://www.163yun.com/"
[1:1:0713/011859.753834:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.503544, 0, 0
[1:1:0713/011859.754054:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/011859.910491:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1100, 7f2456fc4881
[1:1:0713/011859.960605:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f73f4702860","ptid":"1089 0x7f245467f070 0x37861654d60 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011859.960803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.163yun.com/","ptid":"1089 0x7f245467f070 0x37861654d60 ","rf":"5:3_https://www.163yun.com/"}
[1:1:0713/011859.961045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.163yun.com/"
[1:1:0713/011859.961408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.163yun.com/, 3f73f4702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0713/011859.961537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.163yun.com/", "www.163yun.com", 3, 1, , , 0
[1:1:0713/011859.961841:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2465b69629c8, 0x3786112b150
[1:1:0713/011859.961942:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.163yun.com/", 100
[1:1:0713/011859.962137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.163yun.com/, 1128
[1:1:0713/011859.962359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1128 0x7f245467f070 0x378617eebe0 , 5:3_https://www.163yun.com/, 1, -5:3_https://www.163yun.com/, 1100 0x7f245467f070 0x37861b7fc60 
