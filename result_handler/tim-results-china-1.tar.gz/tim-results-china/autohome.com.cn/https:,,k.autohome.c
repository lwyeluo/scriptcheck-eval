[0712/032047.145546:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/032047.145962:INFO:switcher_clone.cc(787)] backtrace rip is 7f5af1d2f891
[0712/032048.133822:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/032048.134232:INFO:switcher_clone.cc(787)] backtrace rip is 7efe26e5e891
[1:1:0712/032048.145945:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/032048.146195:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/032048.151581:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/032049.480808:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/032049.481340:INFO:switcher_clone.cc(787)] backtrace rip is 7f63b747f891
[68330:68330:0712/032049.508483:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/255aaf19-254e-4393-96ce-f3f5a9cb7015
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[68361:68361:0712/032049.709517:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68361
[68373:68373:0712/032049.709932:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68373
[68330:68330:0712/032050.069868:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[68330:68359:0712/032050.070713:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/032050.070927:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/032050.071136:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/032050.071749:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/032050.071906:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/032050.074873:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x254d8cdc, 1
[1:1:0712/032050.075210:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36aa9d48, 0
[1:1:0712/032050.075415:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x25cf5a61, 3
[1:1:0712/032050.075583:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x22132bc0, 2
[1:1:0712/032050.075761:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 48ffffff9dffffffaa36 ffffffdcffffff8c4d25 ffffffc02b1322 615affffffcf25 , 10104, 4
[1:1:0712/032050.076826:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68330:68359:0712/032050.077098:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGH��6܌M%�+"aZ�%R��=
[68330:68359:0712/032050.077202:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is H��6܌M%�+"aZ�%�)R��=
[1:1:0712/032050.077085:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efe250990a0, 3
[1:1:0712/032050.077378:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efe25224080, 2
[68330:68359:0712/032050.077555:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/032050.077553:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efe0eee7d20, -2
[68330:68359:0712/032050.077645:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 68381, 4, 489daa36 dc8c4d25 c02b1322 615acf25 
[1:1:0712/032050.096827:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/032050.097685:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22132bc0
[1:1:0712/032050.098654:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22132bc0
[1:1:0712/032050.100624:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22132bc0
[1:1:0712/032050.102170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.102379:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.102556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.102736:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.103369:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22132bc0
[1:1:0712/032050.103680:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efe26e5e7ba
[1:1:0712/032050.103822:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efe26e55def, 7efe26e5e77a, 7efe26e600cf
[1:1:0712/032050.109289:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22132bc0
[1:1:0712/032050.109619:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22132bc0
[1:1:0712/032050.110337:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22132bc0
[1:1:0712/032050.112369:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.112557:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.112731:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.112910:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22132bc0
[1:1:0712/032050.114250:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22132bc0
[1:1:0712/032050.114596:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efe26e5e7ba
[1:1:0712/032050.114729:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efe26e55def, 7efe26e5e77a, 7efe26e600cf
[1:1:0712/032050.122100:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/032050.122533:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/032050.122668:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc16e6e5b8, 0x7ffc16e6e538)
[1:1:0712/032050.137530:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/032050.143469:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[68330:68330:0712/032050.746929:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68330:68330:0712/032050.747368:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68330:68340:0712/032050.756239:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[68330:68340:0712/032050.756339:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[68330:68330:0712/032050.756528:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[68330:68330:0712/032050.756606:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[68330:68330:0712/032050.756752:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,68381, 4
[1:7:0712/032050.761932:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[68330:68353:0712/032050.810215:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/032050.917795:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3c8ec3682220
[1:1:0712/032050.918073:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/032051.263661:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/032052.721890:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032052.725467:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[68330:68330:0712/032052.732500:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[68330:68330:0712/032052.732606:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/032053.562500:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032053.716182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 105fdeb41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/032053.716531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032053.732951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 105fdeb41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/032053.733242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032053.919932:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032053.920201:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032054.177010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032054.185253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 105fdeb41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/032054.185568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032054.221691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032054.232259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 105fdeb41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/032054.232580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032054.246884:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[68330:68330:0712/032054.248518:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/032054.251051:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c8ec3680e20
[1:1:0712/032054.251236:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[68330:68330:0712/032054.255488:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[68330:68330:0712/032054.288915:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[68330:68330:0712/032054.289114:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/032054.357472:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032055.231808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7efe10ac22e0 0x3c8ec3856ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032055.232512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 105fdeb41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/032055.232672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032055.233221:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68330:68330:0712/032055.264609:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/032055.266967:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c8ec3681820
[1:1:0712/032055.267222:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[68330:68330:0712/032055.271310:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/032055.276555:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/032055.276732:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[68330:68330:0712/032055.287762:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[68330:68330:0712/032055.301209:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68330:68330:0712/032055.302261:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68330:68340:0712/032055.308246:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[68330:68340:0712/032055.308342:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[68330:68330:0712/032055.308489:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[68330:68330:0712/032055.308568:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[68330:68330:0712/032055.308725:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,68381, 4
[1:7:0712/032055.311766:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/032055.952980:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/032056.387193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7efe10ac22e0 0x3c8ec3a32a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032056.388348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 105fdeb41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/032056.388591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032056.389373:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68330:68330:0712/032056.505757:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[68330:68330:0712/032056.505825:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/032056.531754:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032057.086981:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[68330:68330:0712/032057.371646:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[68330:68359:0712/032057.372110:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/032057.372434:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/032057.372696:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/032057.373156:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/032057.373376:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/032057.376745:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1a06562b, 1
[1:1:0712/032057.377142:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x33ffd779, 0
[1:1:0712/032057.377369:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x776b030, 3
[1:1:0712/032057.377568:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2194f5c4, 2
[1:1:0712/032057.377754:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 79ffffffd7ffffffff33 2b56061a ffffffc4fffffff5ffffff9421 30ffffffb07607 , 10104, 5
[1:1:0712/032057.378673:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68330:68359:0712/032057.378968:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGy��3+V���!0�v{��=
[68330:68359:0712/032057.379049:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is y��3+V���!0�vx�{��=
[1:1:0712/032057.378956:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efe250990a0, 3
[68330:68359:0712/032057.379347:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 68426, 5, 79d7ff33 2b56061a c4f59421 30b07607 
[1:1:0712/032057.379268:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efe25224080, 2
[1:1:0712/032057.379557:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efe0eee7d20, -2
[1:1:0712/032057.421746:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/032057.422150:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2194f5c4
[1:1:0712/032057.422517:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2194f5c4
[1:1:0712/032057.423185:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2194f5c4
[1:1:0712/032057.424664:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.424889:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.425120:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.425354:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.426048:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2194f5c4
[1:1:0712/032057.426403:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efe26e5e7ba
[1:1:0712/032057.426577:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efe26e55def, 7efe26e5e77a, 7efe26e600cf
[1:1:0712/032057.432111:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2194f5c4
[1:1:0712/032057.432529:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2194f5c4
[1:1:0712/032057.433264:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2194f5c4
[1:1:0712/032057.434632:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.434893:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.435116:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.435330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2194f5c4
[1:1:0712/032057.436790:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2194f5c4
[1:1:0712/032057.437195:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efe26e5e7ba
[1:1:0712/032057.437425:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efe26e55def, 7efe26e5e77a, 7efe26e600cf
[1:1:0712/032057.447080:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/032057.447887:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/032057.448100:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc16e6e5b8, 0x7ffc16e6e538)
[1:1:0712/032057.464735:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/032057.469749:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/032057.635960:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c8ec3630220
[1:1:0712/032057.636209:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/032057.705468:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032057.705713:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/032058.230222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 566, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/032058.235606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 105fdec709f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/032058.235957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/032058.244178:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/032058.336237:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032058.337008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 105fdeb41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/032058.337267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032058.529383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/032058.531004:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/032058.531207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 105fdec709f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/032058.531481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/032058.639811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/032058.640740:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/032058.640982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 105fdec709f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/032058.641318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[68330:68330:0712/032059.247992:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68330:68330:0712/032059.260295:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68330:68340:0712/032059.275740:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[68330:68340:0712/032059.275918:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[68330:68330:0712/032059.281312:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://k.autohome.com.cn/
[68330:68330:0712/032059.281417:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://k.autohome.com.cn/, https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390, 1
[68330:68330:0712/032059.281590:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://k.autohome.com.cn/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 10:20:59 GMT content-type:text/html; charset=gb2312 server:5.71 cache-control:public,max-age=1800 content-encoding:gzip x-powered-by:ASP.NET x-ip:74.99 powered-by-scs:MISS BY SCS_5.71 FROM c4 strict-transport-security:max-age=31622400 x-cache:MISS from cache.51cdn.com x-via:1.1 PSshzk2ph199:1 (Cdn Cache Server V2.0)  ,68426, 5
[1:7:0712/032059.286250:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/032059.322492:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://k.autohome.com.cn/
[68330:68330:0712/032059.462608:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://k.autohome.com.cn/, https://k.autohome.com.cn/, 1
[68330:68330:0712/032059.462686:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://k.autohome.com.cn/, https://k.autohome.com.cn
[1:1:0712/032059.524348:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032059.584556:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/032059.656907:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032059.692718:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032059.693043:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032059.738268:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/032059.807849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 146, "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032059.816314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , /*! Autoshow - V(2.0.5) - build(2014.12.19) */
!function(e,t){function r(e){return function(t){retu
[1:1:0712/032059.816590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032059.822055:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032059.827489:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/032100.010306:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032100.052898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 165 0x7efe25224080 0x3c8ec35e6420 1 0 0x3c8ec35e6438 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032100.068733:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://usatoday.com/"
[1:1:0712/032100.110757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow
[1:1:0712/032100.111068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032100.126028:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gome.com.cn/"
[1:1:0712/032100.201708:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/032100.348704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 165 0x7efe25224080 0x3c8ec35e6420 1 0 0x3c8ec35e6438 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032100.368558:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/032100.442552:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/032100.530559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/032100.531337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 105fdec709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/032100.531593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/032100.540685:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032100.706620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 190 0x7efe0eb9a070 0x3c8ec375e660 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032100.709070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , 
!function(){window._smReadyFuncs=[],window.SMSdk={ready:function(t){t&&_smReadyFuncs.push(t)}},wind
[1:1:0712/032100.709323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032100.717937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 190 0x7efe0eb9a070 0x3c8ec375e660 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032100.909190:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 190 0x7efe0eb9a070 0x3c8ec375e660 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032101.064218:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 190 0x7efe0eb9a070 0x3c8ec375e660 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032101.159346:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 194, "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032101.161595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , var _trackEvent=_trackEvent||[];!function(t){var r=_trackEvent;t._trackEvent={url:"http://pv.alert.a
[1:1:0712/032101.161908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032101.165809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 194, "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032101.168822:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 3000
[1:1:0712/032101.169419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 254
[1:1:0712/032101.169723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 254 0x7efe0eb9a070 0x3c8ec36411e0 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 194
[1:1:0712/032101.171313:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/032101.177729:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c8ec362da20
[1:1:0712/032101.177948:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/032101.273724:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.109056, 365, 1
[1:1:0712/032101.274015:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032101.385888:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/032102.246976:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032102.247259:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.249147:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7efe0eb9a070 0x3c8ec38fa3e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.258328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , 
    //sync-login.js
    !function(e){function n(e,n){var o,t,i=e+"=",u=m.cookie.split(";");for(o=0;
[1:1:0712/032102.258571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032102.275829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 43200000, 0xfc3b49c29c8, 0x3c8ec33f71b8
[1:1:0712/032102.276117:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 43200000
[1:1:0712/032102.276690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 327
[1:1:0712/032102.276924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 327 0x7efe0eb9a070 0x3c8ec38eb4e0 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 269 0x7efe0eb9a070 0x3c8ec38fa3e0 
[1:1:0712/032102.294807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7efe0eb9a070 0x3c8ec38fa3e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.303351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7efe0eb9a070 0x3c8ec38fa3e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.324261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7efe0eb9a070 0x3c8ec38fa3e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.405252:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/032102.409240:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x3c8ec362e420
[1:1:0712/032102.409489:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/032102.433089:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/032102.433360:INFO:render_frame_impl.cc(7019)] 	 [url] = https://k.autohome.com.cn
[1:1:0712/032102.436121:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.188555, 93, 1
[1:1:0712/032102.436367:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032102.659551:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032102.895367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 295 0x7efe10ac22e0 0x3c8ec38e1660 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.896913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("imgLazyLoad",["jquery"],function(t,o,e){var i=t("jquery");i(function(t){"use strict";functio
[1:1:0712/032102.897139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032102.906067:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.950034:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 296 0x7efe10ac22e0 0x3c8ec3489360 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032102.955640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("commentfunmodle", ["formmodle", "jquery", "jqueryimagescroll"], function (require, exports, 
[1:1:0712/032102.955960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032102.971211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.013373:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7efe10ac22e0 0x3c8ec3a466e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.015379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("commentlistmodle", ['paginationmodle', 'jquerytmplmodle', "jquery"], function (require, expo
[1:1:0712/032103.015604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.030960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.064399:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 301 0x7efe10ac22e0 0x3c8ec3a46860 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.071583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("formmodle", ["jquery"], function (require, exports, module) {
    var $ = require('jquery')
[1:1:0712/032103.071937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.079436:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.132132:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 303 0x7efe10ac22e0 0x3c8ec38f39e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.134505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("searchmodle",["jquery"],function(D,H,G){var F=D("jquery");var B={QueryString:function(K){var
[1:1:0712/032103.134761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.143413:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.163686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7efe10ac22e0 0x3c8ec38cece0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.167759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("picviewmodle", ["jquery"], function (require, exports, module) {
    var $ = require('jquer
[1:1:0712/032103.168059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.174071:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.218592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7efe10ac22e0 0x3c8ec36b3be0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.221051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("paginationmodle",["jquery"],function(A,C,B){var D=A("jquery");D.fn.pagination=function(E,F){
[1:1:0712/032103.221290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.230026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.261291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7efe10ac22e0 0x3c8ec3760de0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.267639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("jquerytmplmodle", ["jquery"], function (require, exports, module) {
    var $ = require('jq
[1:1:0712/032103.267986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.277285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.343100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7efe10ac22e0 0x3c8ec3a83d60 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.344984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , define("jqueryimagescroll", ["jquery"], function (require, exports, module) {
    var $ = require('
[1:1:0712/032103.345256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.354062:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.392564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7efe10ac22e0 0x3c8ec3962560 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032103.413029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , /* Append File:/as/js-2.0.5/jquery.js */
/*! Autoshow - V(2.0.5) - build(2014.12.15) */
define("jq
[1:1:0712/032103.413341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032103.459530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.241941:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032105.242272:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.306640:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032105.413111:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032105.467075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.468019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , cimg.onload, () {
                window._fmOpt.imgLoaded = true;
            }
[1:1:0712/032105.468270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032105.521584:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 371 0x7efe10ac22e0 0x3c8ec38fa2e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.528715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , AutoHeartBeat = {
    ALInkCount: 0, FingerId: 0, OnKeyDownCount: 0, OnKeyDownStr: "", Aleng: 0, He
[1:1:0712/032105.528974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032105.533285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.604762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0xfc3b49c29c8, 0x3c8ec33f7210
[1:1:0712/032105.605006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 4000
[1:1:0712/032105.605553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 424
[1:1:0712/032105.605879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 424 0x7efe0eb9a070 0x3c8ec3af8b60 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 371 0x7efe10ac22e0 0x3c8ec38fa2e0 
[1:1:0712/032105.609605:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 5000
[1:1:0712/032105.610123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 426
[1:1:0712/032105.610346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 426 0x7efe0eb9a070 0x3c8ec3767a60 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 371 0x7efe10ac22e0 0x3c8ec38fa2e0 
[1:1:0712/032105.654850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7efe10ac22e0 0x3c8ec3b2c7e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.656114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , var areaData = {"Status":true,"AreaInfo":[{"CityId":110100,"CityName":"北京","DealerCityId":646,"P
[1:1:0712/032105.656348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032105.657821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.906369:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 254, 7efe114df881
[1:1:0712/032105.924941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"194","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032105.925264:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"194","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032105.925561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032105.926582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , func_stats()
[1:1:0712/032105.926819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032106.063967:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7efe10ac22e0 0x3c8ec38eaf60 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032106.101511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , var _0xd2f6=['c2V0dW5pTXRlZw\x3d\x3d','bW9kbmFy','cnRzYnVz','ZXNhQ3Jld29Mb3Q\x3d','dHNldA\x3d\x3d','
[1:1:0712/032106.101816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032106.836350:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032106.836895:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032108.753874:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032108.754367:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032108.754720:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032108.755112:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032108.755460:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032111.709621:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xfc3b49c29c8, 0x3c8ec33f71a0
[1:1:0712/032111.709863:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 0
[1:1:0712/032111.710550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 443
[1:1:0712/032111.710775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 443 0x7efe0eb9a070 0x3c8ec40641e0 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 395 0x7efe10ac22e0 0x3c8ec38eaf60 
[1:1:0712/032111.758488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7efe10ac22e0 0x3c8ec3a709e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032111.763296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , eval('(function(OoQOOo,QQooOQ){QQooOQ()})(this,function(){var Oo0O0o="length";var O00QQo="charCodeAt
[1:1:0712/032111.763523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[68330:68330:0712/032116.530498:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[68330:68330:0712/032116.537443:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[68330:68330:0712/032116.561927:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://k.autohome.com.cn/, https://k.autohome.com.cn/, 4
[68330:68330:0712/032116.562070:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://k.autohome.com.cn/, https://k.autohome.com.cn
[68330:68330:0712/032116.592816:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[68330:68330:0712/032116.594747:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[68330:68330:0712/032116.597885:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://k.autohome.com.cn/
[68330:68330:0712/032116.659008:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[68330:68330:0712/032116.663040:INFO:CONSOLE(1)] "", source:  (1)
[68330:68330:0712/032116.666757:INFO:CONSOLE(1)] "[object HTMLImageElement]", source:  (1)
[3:3:0712/032116.673887:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/032116.740693:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xfc3b49c29c8, 0x3c8ec33f7188
[1:1:0712/032116.740949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 0
[1:1:0712/032116.741479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 492
[1:1:0712/032116.741726:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 492 0x7efe0eb9a070 0x3c8ec3ea9460 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 396 0x7efe10ac22e0 0x3c8ec3a709e0 
[68330:68330:0712/032116.752641:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[68330:68330:0712/032116.782916:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68330:68330:0712/032116.789283:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68330:68340:0712/032116.796875:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[68330:68340:0712/032116.796972:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[68330:68330:0712/032116.797153:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://k.autohome.com.cn/
[68330:68330:0712/032116.797230:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://k.autohome.com.cn/, https://k.autohome.com.cn/pclive/Detail?vid=8995&type=1, 5
[68330:68330:0712/032116.797365:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://k.autohome.com.cn/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 10:21:16 GMT content-type:text/html; charset=gb2312 content-length:1395 server:5.72 cache-control:private content-encoding:gzip x-powered-by:ASP.NET x-ip:74.99 powered-by-scs:MISS BY SCS_5.72 FROM c2 strict-transport-security:max-age=31622400 x-cache:MISS from cache.51cdn.com x-via:1.1 PSshzk2hi198:3 (Cdn Cache Server V2.0)  ,68426, 5
[1:7:0712/032116.804238:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/032117.415735:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/032117.416004:INFO:render_frame_impl.cc(7019)] 	 [url] = https://k.autohome.com.cn
[1:1:0712/032117.480109:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7efe10ac22e0 0x3c8ec3af5b60 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032117.483546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , /*
* fingerprintJS 0.5.4 - Fast browser fingerprint library
* https://github.com/Valve/fingerprintjs
[1:1:0712/032117.483787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032117.487342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032117.627481:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 20000
[1:1:0712/032117.628156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 526
[1:1:0712/032117.628540:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 526 0x7efe0eb9a070 0x3c8ec6ac87e0 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 436 0x7efe10ac22e0 0x3c8ec3af5b60 
[1:1:0712/032117.661919:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 437 0x7efe10ac22e0 0x3c8ec3ed5a60 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032117.663116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , Jsonp_023045711534594604({"message":"fail","result":0,"returncode":0})
[1:1:0712/032117.663357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[68330:68330:0712/032117.749715:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://k.autohome.com.cn/
[1:1:0712/032117.870672:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 424, 7efe114df881
[1:1:0712/032117.893686:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"371 0x7efe10ac22e0 0x3c8ec38fa2e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032117.894025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"371 0x7efe10ac22e0 0x3c8ec38fa2e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032117.894296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032117.894984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , () { AutoHeartBeat.GetheaderMess(); AutoHeartBeat.IsFaSong = true }
[1:1:0712/032117.895180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032117.932067:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 426, 7efe114df8db
[1:1:0712/032117.941045:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"371 0x7efe10ac22e0 0x3c8ec38fa2e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032117.941362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"371 0x7efe10ac22e0 0x3c8ec38fa2e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032117.941675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 538
[1:1:0712/032117.941854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 538 0x7efe0eb9a070 0x3c8ec6ac8de0 , 5:3_https://k.autohome.com.cn/, 0, , 426 0x7efe0eb9a070 0x3c8ec3767a60 
[1:1:0712/032117.942107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032117.942450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , () { if (AutoHeartBeat.ClientX != AutoHeartBeat.ClientXEnd || AutoHeartBeat.ClientY != AutoHeartBeat
[1:1:0712/032117.942555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032117.950553:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 443, 7efe114df881
[1:1:0712/032117.958143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"395 0x7efe10ac22e0 0x3c8ec38eaf60 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032117.958335:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"395 0x7efe10ac22e0 0x3c8ec38eaf60 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032117.958502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032117.959057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (){_0x549299[_0x29cbde](_0x21fe03,_0x389f43);}
[1:1:0712/032117.959252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[68330:68330:0712/032117.970554:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68330:68330:0712/032117.975798:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68330:68340:0712/032117.990327:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[68330:68330:0712/032117.990383:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://al.autohome.com.cn/
[68330:68330:0712/032117.990438:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://al.autohome.com.cn/, https://al.autohome.com.cn/pv_count.php?SiteId=30&CategoryId=312&objectid=2531485&seriesid=4370&type=0&typeid=0&specid=39032&jbid=0&dealerid=0&ref=&cur=https%3A//k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html%23pvareaid%3D3311390&rnd=0.3738291294855187, 4
[68330:68340:0712/032117.990427:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[68330:68330:0712/032117.990503:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://al.autohome.com.cn/, HTTP/1.1 200 OK Server: 240.23 Date: Fri, 12 Jul 2019 10:21:18 GMT Content-Type: text/html;charset=UTF-8 Content-Length: 0 Connection: keep-alive Set-Cookie: ref=0%7C0%7C0%7C0%7C2019-07-12+18%3A21%3A17.994%7C2019-07-12+18%3A06%3A10.717;Path=/;Domain=.autohome.com.cn;Expires=Wed, 08-Jan-2020 10:21:17 GMT Expires: Thu, 01 Jan 1970 00:00:00 GMT P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Set-Cookie: sessionvid=04EEA2F6-9D2B-4B58-AA8F-6A4A2B779225;Path=/;Domain=.autohome.com.cn;Expires=Fri, 12-Jul-2019 10:51:17 GMT P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Set-Cookie: area=110108;Path=/;Domain=.autohome.com.cn;Expires=Mon, 09-Jul-2029 10:21:17 GMT P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Pragma: No-cache Cache-Control: no-cache Strict-Transport-Security: max-age=31622400  ,68426, 5
[1:7:0712/032117.993562:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[68330:68330:0712/032118.207736:INFO:CONSOLE(1)] "[object HTMLImageElement]", source: https://static.fengkongcloud.com/fpv2.js (1)
[1:1:0712/032135.434512:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0xfc3b49c29c8, 0x3c8ec33f7150
[1:1:0712/032135.434744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 10000
[1:1:0712/032135.435296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 555
[1:1:0712/032135.435491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 555 0x7efe0eb9a070 0x3c8ecce47060 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 443 0x7efe0eb9a070 0x3c8ec40641e0 
[1:1:0712/032135.519780:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xfc3b49c29c8, 0x3c8ec33f7150
[1:1:0712/032135.520072:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 2000
[1:1:0712/032135.520581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 557
[1:1:0712/032135.520775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7efe0eb9a070 0x3c8ecce2e960 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 443 0x7efe0eb9a070 0x3c8ec40641e0 
[1:1:0712/032135.606595:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032135.607814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (){var _0x4296f2=_0x383597[_0x37c531](_0x17ad2b);_0x4296f2[_0x30a940]=_0x30a940;_0x383597=_0x4296f2[
[1:1:0712/032135.608068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032135.609572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032135.638763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032135.684536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/032135.684725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032136.583567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 492, 7efe114df881
[1:1:0712/032136.608659:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"396 0x7efe10ac22e0 0x3c8ec3a709e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032136.608964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"396 0x7efe10ac22e0 0x3c8ec3a709e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032136.609257:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032136.610043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (){try{_fmOpt[QoOo0o]=O00oQO[Oo0OO0];oooo0Q[OooOOQ]();QQ0QO0[OooOOQ]();QO0OOo(OoOQ0O,QoO0oO,_fmOpt||
[1:1:0712/032136.610234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032136.626429:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032136.626788:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032136.627968:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:20:0712/032136.632425:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/032136.688652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xfc3b49c29c8, 0x3c8ec33f7158
[1:1:0712/032136.688929:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 2000
[1:1:0712/032136.689514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 591
[1:1:0712/032136.689760:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7efe0eb9a070 0x3c8ecd077860 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 492 0x7efe0eb9a070 0x3c8ec3ea9460 
[1:1:0712/032136.827043:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://k.autohome.com.cn/
[1:1:0712/032137.067116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7efe0ef02bd0 0x3c8ec3960858 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032137.081036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , /*!
 * autohome.media.platform - liveplayer
 * version:2.1.8
 * build:2019-6-5 15:17:45
 */
!fu
[1:1:0712/032137.081216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
		remove user.13_8276ffad -> 0
		remove user.14_da7fd66e -> 0
		remove user.15_1ba52a98 -> 0
		remove user.16_362a4c94 -> 0
		remove user.17_80066892 -> 0
[1:1:0712/032137.544589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7efe0ef02bd0 0x3c8ec3960858 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032137.617643:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xfc3b49c29c8, 0x3c8ec33f71a0
[1:1:0712/032137.617823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 2000
[1:1:0712/032137.618052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 605
[1:1:0712/032137.618173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 605 0x7efe0eb9a070 0x3c8ec3ea6960 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 514 0x7efe0ef02bd0 0x3c8ec3960858 
[1:1:0712/032137.635646:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0xfc3b49c29c8, 0x3c8ec33f71a0
[1:1:0712/032137.635919:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 10000
[1:1:0712/032137.636588:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 608
[1:1:0712/032137.636853:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7efe0eb9a070 0x3c8ecd050d60 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 514 0x7efe0ef02bd0 0x3c8ec3960858 
[1:1:0712/032137.637667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xfc3b49c29c8, 0x3c8ec33f71a0
[1:1:0712/032137.637773:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 0
[1:1:0712/032137.637968:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 609
[1:1:0712/032137.638076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7efe0eb9a070 0x3c8ec4192260 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 514 0x7efe0ef02bd0 0x3c8ec3960858 
[1:1:0712/032137.646954:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 6000
[1:1:0712/032137.647228:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 611
[1:1:0712/032137.647357:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7efe0eb9a070 0x3c8ecd228ee0 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 514 0x7efe0ef02bd0 0x3c8ec3960858 
[1:1:0712/032137.658798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7efe0ef02bd0 0x3c8ec3960858 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032137.713655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7efe0ef02bd0 0x3c8ec3960858 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032137.765732:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.221835, 248, 1
[1:1:0712/032137.765919:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032138.193767:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://al.autohome.com.cn/
[1:1:0712/032138.652650:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 538, 7efe114df8db
[1:22:0712/032138.670850:WARNING:paced_sender.cc(261)] Elapsed time (2010 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032138.686886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"426 0x7efe0eb9a070 0x3c8ec3767a60 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032138.687245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"426 0x7efe0eb9a070 0x3c8ec3767a60 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032138.687843:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 650
[1:1:0712/032138.688094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7efe0eb9a070 0x3c8ec64993e0 , 5:3_https://k.autohome.com.cn/, 0, , 538 0x7efe0eb9a070 0x3c8ec6ac8de0 
[1:1:0712/032138.688413:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032138.689294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , () { if (AutoHeartBeat.ClientX != AutoHeartBeat.ClientXEnd || AutoHeartBeat.ClientY != AutoHeartBeat
[1:1:0712/032138.689518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[68330:68330:0712/032138.729895:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/032138.798603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , document.readyState
[1:1:0712/032138.798802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032138.830258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , d, (){i(),o=s(d)}
[1:1:0712/032138.830440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032139.172922:WARNING:paced_sender.cc(261)] Elapsed time (2512 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032139.674730:WARNING:paced_sender.cc(261)] Elapsed time (3013 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032139.765068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (QOQ0O0){QOQQoo[oQoOoo](QOQ0O0)}
[1:1:0712/032139.765358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032139.859518:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[68330:68330:0712/032139.867047:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://k.autohome.com.cn/, https://k.autohome.com.cn/, 5
[68330:68330:0712/032139.867184:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://k.autohome.com.cn/, https://k.autohome.com.cn
[1:22:0712/032140.177173:WARNING:paced_sender.cc(261)] Elapsed time (3516 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032140.485704:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032140.485998:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032140.495581:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 623 0x7efe0eb9a070 0x3c8eccf461e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032140.512140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , !function(e,t){function n(e){var t,n,r=O[e]={};for(e=e.split(/\s+/),t=0,n=e.length;t<n;t++)r[e[t]]=!
[1:1:0712/032140.512469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032140.661531:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.175234, 301, 1
[1:1:0712/032140.661798:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032140.664848:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 557, 7efe114df881
[1:22:0712/032140.676135:WARNING:paced_sender.cc(261)] Elapsed time (4015 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032140.681422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"443 0x7efe0eb9a070 0x3c8ec40641e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032140.681745:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"443 0x7efe0eb9a070 0x3c8ec40641e0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032140.682187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032140.682949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (){_0x1aa493[_0x6d2f('0x1b3')](clearTimeout,_0x176eb5);}
[1:1:0712/032140.683252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032140.701550:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 526, 7efe114df8db
[1:1:0712/032140.724153:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"436 0x7efe10ac22e0 0x3c8ec3af5b60 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032140.724583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"436 0x7efe10ac22e0 0x3c8ec3af5b60 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032140.725072:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 725
[1:1:0712/032140.725340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7efe0eb9a070 0x3c8ecd3a0e60 , 5:3_https://k.autohome.com.cn/, 0, , 526 0x7efe0eb9a070 0x3c8ec6ac87e0 
[1:1:0712/032140.725639:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032140.726551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , GetheaderMess, (b) {
        var a = AutoHeartBeat.MouseL + "_" + AutoHeartBeat.MouseR; AutoHeartBeat.HeartBeat = 
[1:1:0712/032140.726797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032140.747123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 609, 7efe114df881
[1:1:0712/032140.779205:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"514 0x7efe0ef02bd0 0x3c8ec3960858 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032140.779606:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"514 0x7efe0ef02bd0 0x3c8ec3960858 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032140.780131:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032140.780907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (){i=document.createElement('script'),i.src=e,r.insertBefore(i,r.firstChild)}
[1:1:0712/032140.781154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032140.906780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 633 0x7efe10ac22e0 0x3c8ecd040ee0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032140.907904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , 

[1:1:0712/032140.908170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032140.942504:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 634 0x7efe10ac22e0 0x3c8ec68cd960 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032140.943526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , 
[1:1:0712/032140.943743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032141.024321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 636 0x7efe10ac22e0 0x3c8ec3eb11e0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032141.025446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , 

[1:1:0712/032141.025735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032141.040412:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 637 0x7efe10ac22e0 0x3c8ec6932ce0 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032141.041582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , smCB_1562926895426({"code":1100,"detail":{"len":"12","sign":"Y3aC/fAnw/8PwKLjmNjRGg==","timestamp":"
[1:1:0712/032141.041804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032141.176829:WARNING:paced_sender.cc(261)] Elapsed time (4515 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032141.184536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xfc3b49c29c8, 0x3c8ec33f7188
[1:1:0712/032141.184779:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 0
[1:1:0712/032141.185320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 741
[1:1:0712/032141.185580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7efe0eb9a070 0x3c8ecda71d60 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 637 0x7efe10ac22e0 0x3c8ec6932ce0 
[1:22:0712/032141.678608:WARNING:paced_sender.cc(261)] Elapsed time (5017 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032142.180729:WARNING:paced_sender.cc(261)] Elapsed time (5520 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032142.682889:WARNING:paced_sender.cc(261)] Elapsed time (6022 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032143.185035:WARNING:paced_sender.cc(261)] Elapsed time (6524 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032143.687170:WARNING:paced_sender.cc(261)] Elapsed time (7026 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032144.188325:WARNING:paced_sender.cc(261)] Elapsed time (7527 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032144.690440:WARNING:paced_sender.cc(261)] Elapsed time (8029 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032144.984582:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[68330:68330:0712/032145.132055:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://al.autohome.com.cn/, https://al.autohome.com.cn/, 4
[68330:68330:0712/032145.132137:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://al.autohome.com.cn/, https://al.autohome.com.cn
[1:22:0712/032145.193598:WARNING:paced_sender.cc(261)] Elapsed time (8532 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032145.210938:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 643 0x7efe10ac22e0 0x3c8ecd3a0f60 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032145.216480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , if(typeof JSON!=="object"){JSON={}}(function(){"use strict";var rx_one=/^[\],:{}\s]*$/;var rx_two=/\
[1:1:0712/032145.216810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:1:0712/032145.333097:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 591, 7efe114df881
[1:1:0712/032145.367965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"492 0x7efe0eb9a070 0x3c8ec3ea9460 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032145.368350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"492 0x7efe0eb9a070 0x3c8ec3ea9460 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032145.368858:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032145.369731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , oOOOOo, (){if(arguments[oQQOoO][Q0QQQo]||!o0Qo0O[O0OOoQ]){return}arguments[oQQOoO][Q0QQQo]=true;o0Qo0O[o0ooO
[1:1:0712/032145.369951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032145.694718:WARNING:paced_sender.cc(261)] Elapsed time (9034 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032146.199915:WARNING:paced_sender.cc(261)] Elapsed time (9539 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032146.701996:WARNING:paced_sender.cc(261)] Elapsed time (10041 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032146.847864:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:22:0712/032147.204122:WARNING:paced_sender.cc(261)] Elapsed time (10543 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032147.706258:WARNING:paced_sender.cc(261)] Elapsed time (11045 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032148.208076:WARNING:paced_sender.cc(261)] Elapsed time (11547 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032148.709551:WARNING:paced_sender.cc(261)] Elapsed time (12048 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032149.211687:WARNING:paced_sender.cc(261)] Elapsed time (12550 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032149.478349:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032149.478842:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032149.479251:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:22:0712/032149.713829:WARNING:paced_sender.cc(261)] Elapsed time (13053 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032150.215621:WARNING:paced_sender.cc(261)] Elapsed time (13554 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032150.717082:WARNING:paced_sender.cc(261)] Elapsed time (14056 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032151.219233:WARNING:paced_sender.cc(261)] Elapsed time (14558 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032151.721379:WARNING:paced_sender.cc(261)] Elapsed time (15060 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032152.223502:WARNING:paced_sender.cc(261)] Elapsed time (15562 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032152.727149:WARNING:paced_sender.cc(261)] Elapsed time (16066 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032153.227937:WARNING:paced_sender.cc(261)] Elapsed time (16567 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032153.729935:WARNING:paced_sender.cc(261)] Elapsed time (17069 ms) longer than expected, limiting to 2000 ms
[68330:68330:0712/032153.969354:INFO:CONSOLE(1)] "The AudioContext was not allowed to start. It must be resume (or created) after a user gesture on the page. https://goo.gl/7K7WLu", source:  (1)
[1:22:0712/032154.232052:WARNING:paced_sender.cc(261)] Elapsed time (17571 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032154.734237:WARNING:paced_sender.cc(261)] Elapsed time (18073 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032154.892691:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xfc3b49c29c8, 0x3c8ec33f7158
[1:1:0712/032154.892973:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 2000
[1:1:0712/032154.893543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 1042
[1:1:0712/032154.893774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1042 0x7efe0eb9a070 0x3c8ed0d4bd60 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 591 0x7efe0eb9a070 0x3c8ecd077860 
[1:22:0712/032155.236367:WARNING:paced_sender.cc(261)] Elapsed time (18575 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032155.738492:WARNING:paced_sender.cc(261)] Elapsed time (19077 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032155.841667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xfc3b49c29c8, 0x3c8ec33f7158
[1:1:0712/032155.841944:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 0
[1:1:0712/032155.842507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 1048
[1:1:0712/032155.842764:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1048 0x7efe0eb9a070 0x3c8ed0d4b760 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 591 0x7efe0eb9a070 0x3c8ecd077860 
[1:22:0712/032156.241622:WARNING:paced_sender.cc(261)] Elapsed time (19580 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032156.442950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xfc3b49c29c8, 0x3c8ec33f7158
[1:1:0712/032156.443218:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", 0
[1:1:0712/032156.443805:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 1052
[1:1:0712/032156.444081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1052 0x7efe0eb9a070 0x3c8ed11fe860 , 5:3_https://k.autohome.com.cn/, 1, -5:3_https://k.autohome.com.cn/, 591 0x7efe0eb9a070 0x3c8ecd077860 
[1:1:0712/032156.653814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , document.readyState
[1:1:0712/032156.654111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032156.743789:WARNING:paced_sender.cc(261)] Elapsed time (20083 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032157.009558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , d, (){i(),o=s(d)}
[1:1:0712/032157.009848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032157.245917:WARNING:paced_sender.cc(261)] Elapsed time (20585 ms) longer than expected, limiting to 2000 ms
[1:22:0712/032157.748059:WARNING:paced_sender.cc(261)] Elapsed time (21087 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032157.983825:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 605, 7efe114df881
[1:1:0712/032158.008145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"514 0x7efe0ef02bd0 0x3c8ec3960858 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032158.008497:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"514 0x7efe0ef02bd0 0x3c8ec3960858 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032158.008974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032158.009852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (){delete i[e],c.removeChild(l),s(e,!1,null)}
[1:1:0712/032158.010160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032158.250174:WARNING:paced_sender.cc(261)] Elapsed time (21589 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032158.598034:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:22:0712/032158.752312:WARNING:paced_sender.cc(261)] Elapsed time (22091 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032158.909542:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032158.910501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , l.onload, (){l.onload=null,clearTimeout(f),u.state=1,s(e,!0,l)}
[1:1:0712/032158.910741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032159.254481:WARNING:paced_sender.cc(261)] Elapsed time (22593 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032159.422488:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032159.422833:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032159.424724:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719 0x7efe0eb9a070 0x3c8eccfe2a60 , "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032159.437104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (function(aJ_){function oX_(){if (OD_()) {if(Ie_('Aa_')=='Aa_'){zH_();}}if(!OD_()) {if(Ie_('qo_')!='
[1:1:0712/032159.437379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032159.757581:WARNING:paced_sender.cc(261)] Elapsed time (23096 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032200.192813:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.769691, 0, 1
[1:1:0712/032200.193075:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:22:0712/032200.259757:WARNING:paced_sender.cc(261)] Elapsed time (23599 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032200.265542:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 650, 7efe114df8db
[1:1:0712/032200.296459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"538 0x7efe0eb9a070 0x3c8ec6ac8de0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032200.296831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"538 0x7efe0eb9a070 0x3c8ec6ac8de0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032200.297404:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://k.autohome.com.cn/, 1105
[1:1:0712/032200.297640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7efe0eb9a070 0x3c8ec3ea1960 , 5:3_https://k.autohome.com.cn/, 0, , 650 0x7efe0eb9a070 0x3c8ec64993e0 
[1:1:0712/032200.298053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032200.298882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , () { if (AutoHeartBeat.ClientX != AutoHeartBeat.ClientXEnd || AutoHeartBeat.ClientY != AutoHeartBeat
[1:1:0712/032200.299135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
[1:22:0712/032200.761868:WARNING:paced_sender.cc(261)] Elapsed time (24101 ms) longer than expected, limiting to 2000 ms
[1:1:0712/032200.828160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://k.autohome.com.cn/, 741, 7efe114df881
[1:1:0712/032200.857093:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ea9d6f02860","ptid":"637 0x7efe10ac22e0 0x3c8ec6932ce0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032200.857441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://k.autohome.com.cn/","ptid":"637 0x7efe10ac22e0 0x3c8ec6932ce0 ","rf":"5:3_https://k.autohome.com.cn/"}
[1:1:0712/032200.857957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390"
[1:1:0712/032200.858670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://k.autohome.com.cn/, 3ea9d6f02860, , , (){_0xdf267a();}
[1:1:0712/032200.858927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://k.autohome.com.cn/detail/view_01d97z83fm68tk6c9m70tg0000.html#pvareaid=3311390", "k.autohome.com.cn", 3, 1, , , 0
