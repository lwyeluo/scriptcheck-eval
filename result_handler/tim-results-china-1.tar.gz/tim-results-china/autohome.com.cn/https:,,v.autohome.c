[0712/031425.872461:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/031425.872910:INFO:switcher_clone.cc(787)] backtrace rip is 7fc7b7c31891
[0712/031426.994598:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/031426.995117:INFO:switcher_clone.cc(787)] backtrace rip is 7f013f049891
[1:1:0712/031427.009566:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/031427.009885:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/031427.015061:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[67454:67454:0712/031428.293677:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/28926b10-5d8c-4181-a484-d0072d72ae67
[0712/031428.386945:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/031428.387405:INFO:switcher_clone.cc(787)] backtrace rip is 7fa3449dd891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[67487:67487:0712/031428.608215:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=67487
[67500:67500:0712/031428.608664:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=67500
[67454:67454:0712/031428.909482:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[67454:67485:0712/031428.910215:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/031428.910435:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/031428.910669:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/031428.911253:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/031428.911410:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/031428.914386:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1af2a98b, 1
[1:1:0712/031428.914800:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x68c58a0, 0
[1:1:0712/031428.915004:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3963adf4, 3
[1:1:0712/031428.915198:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b424755, 2
[1:1:0712/031428.915439:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa058ffffff8c06 ffffff8bffffffa9fffffff21a 5547421b fffffff4ffffffad6339 , 10104, 4
[1:1:0712/031428.916742:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[67454:67485:0712/031428.916973:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�X����UGB��c9=�o9
[67454:67485:0712/031428.917039:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �X����UGB��c98^=�o9
[1:1:0712/031428.916968:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f013d2840a0, 3
[1:1:0712/031428.917180:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f013d40f080, 2
[67454:67485:0712/031428.917385:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/031428.917371:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01270d2d20, -2
[67454:67485:0712/031428.917459:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 67508, 4, a0588c06 8ba9f21a 5547421b f4ad6339 
[1:1:0712/031428.938123:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/031428.939004:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b424755
[1:1:0712/031428.939955:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b424755
[1:1:0712/031428.941574:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b424755
[1:1:0712/031428.943072:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.943291:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.943473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.943682:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.944325:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b424755
[1:1:0712/031428.944625:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f013f0497ba
[1:1:0712/031428.944825:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f013f040def, 7f013f04977a, 7f013f04b0cf
[1:1:0712/031428.950531:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b424755
[1:1:0712/031428.950899:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b424755
[1:1:0712/031428.951627:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b424755
[1:1:0712/031428.953656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.953849:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.954034:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.954216:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b424755
[1:1:0712/031428.955517:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b424755
[1:1:0712/031428.955906:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f013f0497ba
[1:1:0712/031428.956062:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f013f040def, 7f013f04977a, 7f013f04b0cf
[1:1:0712/031428.964036:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/031428.964466:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/031428.964614:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff9f625648, 0x7fff9f6255c8)
[1:1:0712/031428.979462:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/031428.982084:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[67454:67454:0712/031429.650569:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[67454:67454:0712/031429.651291:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[67454:67467:0712/031429.657291:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[67454:67454:0712/031429.657328:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[67454:67467:0712/031429.657395:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[67454:67454:0712/031429.657415:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[67454:67454:0712/031429.657563:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,67508, 4
[1:7:0712/031429.659656:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[67454:67478:0712/031429.701327:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/031429.720235:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x383903c1e220
[1:1:0712/031429.720866:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/031430.074823:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[67454:67454:0712/031432.138689:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[67454:67454:0712/031432.138813:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/031432.190887:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031432.195048:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/031433.553088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 273474041f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/031433.553356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/031433.569343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 273474041f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/031433.569556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/031433.651963:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/031434.019254:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/031434.019579:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/031434.478978:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/031434.486941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 273474041f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/031434.487183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/031434.522881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/031434.534305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 273474041f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/031434.534540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/031434.546777:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[67454:67454:0712/031434.548782:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/031434.550112:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x383903c1ce20
[1:1:0712/031434.550292:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[67454:67454:0712/031434.554304:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[67454:67454:0712/031434.575832:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[67454:67454:0712/031434.575969:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/031434.598602:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/031435.422005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7f0128cad2e0 0x383903e425e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/031435.422775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 273474041f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/031435.422900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/031435.423517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[67454:67454:0712/031435.462886:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/031435.464334:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x383903c1d820
[1:1:0712/031435.464534:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[67454:67454:0712/031435.475173:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/031435.484545:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/031435.484807:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[67454:67454:0712/031435.495246:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[67454:67454:0712/031435.508756:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[67454:67454:0712/031435.511989:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[67454:67467:0712/031435.519524:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[67454:67467:0712/031435.519615:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[67454:67454:0712/031435.519890:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[67454:67454:0712/031435.519989:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[67454:67454:0712/031435.520165:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,67508, 4
[1:7:0712/031435.523356:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[67454:67454:0712/031435.696056:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[67454:67485:0712/031435.696588:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/031435.696859:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/031435.697099:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/031435.697531:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/031435.697694:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/031435.700843:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xb47cbc, 1
[1:1:0712/031435.701277:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x26ba1cde, 0
[1:1:0712/031435.701478:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x7f7f001, 3
[1:1:0712/031435.701687:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd516286, 2
[1:1:0712/031435.701916:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffde1cffffffba26 ffffffbc7cffffffb400 ffffff8662510d 01fffffff0fffffff707 , 10104, 5
[1:1:0712/031435.703066:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[67454:67485:0712/031435.703371:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��&�|�
[67454:67485:0712/031435.703439:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��&�|�
[1:1:0712/031435.703556:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f013d2840a0, 3
[67454:67485:0712/031435.703732:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 67553, 5, de1cba26 bc7cb400 8662510d 01f0f707 
[1:1:0712/031435.703729:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f013d40f080, 2
[1:1:0712/031435.703946:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01270d2d20, -2
[1:1:0712/031435.718759:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/031435.719094:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d516286
[1:1:0712/031435.719433:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d516286
[1:1:0712/031435.720049:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d516286
[1:1:0712/031435.721588:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.721779:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.721955:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.722130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.722825:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d516286
[1:1:0712/031435.723119:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f013f0497ba
[1:1:0712/031435.723278:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f013f040def, 7f013f04977a, 7f013f04b0cf
[1:1:0712/031435.729053:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d516286
[1:1:0712/031435.729485:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d516286
[1:1:0712/031435.730204:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d516286
[1:1:0712/031435.733066:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.733301:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.733491:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.733684:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d516286
[1:1:0712/031435.734919:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d516286
[1:1:0712/031435.735315:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f013f0497ba
[1:1:0712/031435.735511:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f013f040def, 7f013f04977a, 7f013f04b0cf
[1:1:0712/031435.744973:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/031435.745607:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/031435.745792:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff9f625648, 0x7fff9f6255c8)
[1:1:0712/031435.762618:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/031435.765060:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/031436.003558:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x383903bd2220
[1:1:0712/031436.003856:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/031436.190757:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[67454:67454:0712/031437.025195:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[67454:67454:0712/031437.032853:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[67454:67467:0712/031437.058812:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[67454:67467:0712/031437.058916:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[67454:67454:0712/031437.059451:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://v.autohome.com.cn/
[67454:67454:0712/031437.059551:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://v.autohome.com.cn/, https://v.autohome.com.cn/u/78216589, 1
[67454:67454:0712/031437.059742:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://v.autohome.com.cn/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 10:14:37 GMT content-type:text/html;charset=UTF-8 expires:Fri, 12 Jul 2019 10:29:37 GMT server:193.131 s-r:41.61 cache-control:public, max-age=900 content-language:en-US powered-by-scs:EXPIRED BY SCS_193.131 FROM c3 strict-transport-security:max-age=31622400 content-encoding:gzip x-cache:MISS from cache.51cdn.com x-via:1.1 PShbsjzsxqo180:9 (Cdn Cache Server V2.0), 1.1 PSsdzbwt4qa113:5 (Cdn Cache Server V2.0), 1.1 PSshzk2hi198:0 (Cdn Cache Server V2.0)  ,67553, 5
[1:7:0712/031437.066473:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/031437.088090:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://v.autohome.com.cn/
[1:1:0712/031437.129691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 500 0x7f0128cad2e0 0x383903fec3e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/031437.130721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 273474041f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/031437.130981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/031437.131760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/031437.246383:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[67454:67454:0712/031437.248833:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://v.autohome.com.cn/, https://v.autohome.com.cn/, 1
[67454:67454:0712/031437.248931:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://v.autohome.com.cn/, https://v.autohome.com.cn
[1:1:0712/031437.253425:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/031437.318726:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/031437.360209:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/031437.432776:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/031437.433034:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031437.615692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031437.620558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , window._mda_ahas=window._mda_ahas||[];window._AHAS_OBJ=window._AHAS_OBJ||{};function trackMdaEvent(a
[1:1:0712/031437.620840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031437.651306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031437.657162:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031438.057141:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 197 0x7f0126d85070 0x383903e12fe0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031438.058777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , 
    var pvTrack = function () { };
    pvTrack.site = 1;
    pvTrack.category = 155;
    pvTrack.su
[1:1:0712/031438.059036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031438.062583:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 197 0x7f0126d85070 0x383903e12fe0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031438.067080:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 3000
[1:1:0712/031438.067731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 224
[1:1:0712/031438.068148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 224 0x7f0126d85070 0x383903dd8960 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 197 0x7f0126d85070 0x383903e12fe0 
[1:1:0712/031438.166932:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.105506, 197, 1
[1:1:0712/031438.167193:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/031438.781197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031438.874169:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/031438.874436:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031438.875268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f0126d85070 0x383903df3a60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031438.876750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , 
  !function(e){function n(e,n){var o,t,i=e+"=",u=m.cookie.split(";");for(o=0;o<u.length;o+=1){for(t
[1:1:0712/031438.876978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031438.890773:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 43200000, 0x281f5aa629c8, 0x3839037f39a0
[1:1:0712/031438.891052:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 43200000
[1:1:0712/031438.891456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 274
[1:1:0712/031438.891691:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 274 0x7f0126d85070 0x383903cfbde0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 243 0x7f0126d85070 0x383903df3a60 
[1:1:0712/031438.892999:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f0126d85070 0x383903df3a60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031438.917711:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f0126d85070 0x383903df3a60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031438.934357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f0126d85070 0x383903df3a60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031438.998529:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f0126d85070 0x383903df3a60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031439.007693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f0126d85070 0x383903df3a60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031439.084986:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.210441, 440, 1
[1:1:0712/031439.085278:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/031439.120329:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031439.124409:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031439.125276:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031439.125714:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031439.126092:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031439.930659:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/031439.930822:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031439.934750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031439.977912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , /* Append File:/as/seajs/2.3.0/bundle.js */
!function(e,r){function t(e){return function(r){return{
[1:1:0712/031439.978159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031440.182443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.188944:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.203412:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.213200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.226881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.231804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.235629:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.350089:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f0126d85070 0x383903dc54e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031440.405239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.299870:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7f0128cad2e0 0x383903dd5fe0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.303332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , window._mda_ahas=window._mda_ahas||[];window._AHAS_OBJ=window._AHAS_OBJ||{};if(window._trackPVTrigge
[1:1:0712/031442.303578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
		remove user.10_a139e20 -> 0
		remove user.11_8529cbcb -> 0
		remove user.12_45d23380 -> 0
		remove user.13_e4fdf7b5 -> 0
		remove user.14_4f14a0de -> 0
[1:1:0712/031442.357500:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x281f5aa629c8, 0x3839037f39a0
[1:1:0712/031442.357778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 3000
[1:1:0712/031442.358215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 407
[1:1:0712/031442.358443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 407 0x7f0126d85070 0x383903d25ee0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 322 0x7f0128cad2e0 0x383903dd5fe0 
[1:1:0712/031442.410447:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f0128cad2e0 0x383903d254e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.411574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , var areaData = {"Status":true,"AreaInfo":[{"CityId":110100,"CityName":"北京","DealerCityId":646,"P
[1:1:0712/031442.411856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031442.413035:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.509480:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f0128cad2e0 0x383903e00fe0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.514942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , AutoHeartBeat={ALInkCount:0,FingerId:0,OnKeyDownCount:0,OnKeyDownStr:"",Aleng:0,HeartBeat:0,AutoComp
[1:1:0712/031442.515234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031442.518901:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.549623:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x281f5aa629c8, 0x3839037f3a10
[1:1:0712/031442.549935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 4000
[1:1:0712/031442.550349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 420
[1:1:0712/031442.550578:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 420 0x7f0126d85070 0x383903cf94e0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 328 0x7f0128cad2e0 0x383903e00fe0 
[1:1:0712/031442.554174:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 5000
[1:1:0712/031442.554613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 422
[1:1:0712/031442.554861:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 422 0x7f0126d85070 0x38390422fa60 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 328 0x7f0128cad2e0 0x383903e00fe0 
[1:1:0712/031442.581068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329 0x7f0128cad2e0 0x383903dfb360 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.597975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , window.Sou=window.Sou||{},window.Sou.util=window.Sou.util||{},Sou.util.newGuid=function(){for(var e=
[1:1:0712/031442.598258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031442.680352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.719026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7f0128cad2e0 0x383903e121e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031442.727475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , var _0xd2f6=['c2V0dW5pTXRlZw\x3d\x3d','bW9kbmFy','cnRzYnVz','ZXNhQ3Jld29Mb3Q\x3d','dHNldA\x3d\x3d','
[1:1:0712/031442.727656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031446.076939:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031446.077407:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/031448.293610:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x281f5aa629c8, 0x3839037f39a0
[1:1:0712/031448.293876:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 0
[1:1:0712/031448.294408:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 440
[1:1:0712/031448.294746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 440 0x7f0126d85070 0x3839065a1260 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 332 0x7f0128cad2e0 0x383903e121e0 
[1:1:0712/031448.773383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 224, 7f01296ca881
[1:1:0712/031448.786005:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"197 0x7f0126d85070 0x383903e12fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031448.786377:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"197 0x7f0126d85070 0x383903e12fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031448.786786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031448.787678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , func_stats()
[1:1:0712/031448.787922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031449.028634:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 412 0x7f0128cad2e0 0x383904230e60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031449.033156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , /* Append File:/car/sidebar/common/js/toolbar-1.1.0.js */
define("toolbar",["jquery","toolCookie"],
[1:1:0712/031449.033439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031449.045854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031449.101237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7f0128cad2e0 0x3839042309e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031449.103469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , func_6502827416([{"data":[{"desc":"","link":{"desc":"图片点击链接","reports":[],"jumptype":"1"
[1:1:0712/031449.103715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031449.149154:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x281f5aa629c8, 0x3839037f3988
[1:1:0712/031449.149431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 0
[1:1:0712/031449.149841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 469
[1:1:0712/031449.150067:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f0126d85070 0x383904236460 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 413 0x7f0128cad2e0 0x3839042309e0 
[1:1:0712/031449.165078:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031449.198365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031449.199158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , r, (e,i){var s,u,c,f,d;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=H.noop,dt&&delet
[1:1:0712/031449.199385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031449.201547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031449.205219:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031449.205990:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x8983e218a68
[1:1:0712/031450.313406:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x281f5aa629c8, 0x3839037f3ba0
[1:1:0712/031450.313710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 0
[1:1:0712/031450.314165:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 482
[1:1:0712/031450.314395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7f0126d85070 0x38390443f9e0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 414
[1:1:0712/031450.319995:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 13
[1:1:0712/031450.320407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 483
[1:1:0712/031450.320643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7f0126d85070 0x383903db4760 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 414
[1:1:0712/031450.673024:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 407, 7f01296ca881
[1:1:0712/031450.693885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"322 0x7f0128cad2e0 0x383903dd5fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.694206:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"322 0x7f0128cad2e0 0x383903dd5fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.694590:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031450.695209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , sendPVDelay, (){var fvlid=oThis.ahCookie.readCookie("fvlid");var pvDelayPath=config.pvDelayPath+oThis.getNessInfo
[1:1:0712/031450.695423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031450.722512:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 420, 7f01296ca881
[1:1:0712/031450.744196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"328 0x7f0128cad2e0 0x383903e00fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.744520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"328 0x7f0128cad2e0 0x383903e00fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.744934:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031450.745487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , (){AutoHeartBeat.GetheaderMess(),AutoHeartBeat.IsFaSong=!0}
[1:1:0712/031450.745698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031450.778005:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 422, 7f01296ca8db
[1:1:0712/031450.800337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"328 0x7f0128cad2e0 0x383903e00fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.800649:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"328 0x7f0128cad2e0 0x383903e00fe0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.801094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 525
[1:1:0712/031450.801321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7f0126d85070 0x3839065bcb60 , 5:3_https://v.autohome.com.cn/, 0, , 422 0x7f0126d85070 0x38390422fa60 
[1:1:0712/031450.801625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031450.802233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , (){if(AutoHeartBeat.ClientX!=AutoHeartBeat.ClientXEnd||AutoHeartBeat.ClientY!=AutoHeartBeat.ClientYE
[1:1:0712/031450.802445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031450.850390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 440, 7f01296ca881
[1:1:0712/031450.872687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"332 0x7f0128cad2e0 0x383903e121e0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.873109:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"332 0x7f0128cad2e0 0x383903e121e0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031450.873530:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031450.874213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , (){_0x549299[_0x29cbde](_0x21fe03,_0x389f43);}
[1:1:0712/031450.874433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[67454:67454:0712/031455.241159:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/031455.308217:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[67454:67454:0712/031456.166681:INFO:CONSOLE(1)] "[object HTMLImageElement]", source: https://static.fengkongcloud.com/fpv2.js (1)
[1:1:0712/031514.013884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x281f5aa629c8, 0x3839037f3950
[1:1:0712/031514.014123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 10000
[1:1:0712/031514.014512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 573
[1:1:0712/031514.014781:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f0126d85070 0x38390bde39e0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 440 0x7f0126d85070 0x3839065a1260 
[1:1:0712/031514.103446:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x281f5aa629c8, 0x3839037f3950
[1:1:0712/031514.103673:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 2000
[1:1:0712/031514.104046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 575
[1:1:0712/031514.104241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f0126d85070 0x38390bbdc5e0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 440 0x7f0126d85070 0x3839065a1260 
[1:1:0712/031514.174713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7f0128cad2e0 0x383903df9fe0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031514.177154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , /*
* fingerprintJS 0.5.4 - Fast browser fingerprint library
* https://github.com/Valve/fingerprintjs
[1:1:0712/031514.177304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031514.179054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
		remove user.11_b7b52090 -> 0
		remove user.12_425294e6 -> 0
[1:1:0712/031514.318151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 20000
[1:1:0712/031514.318605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 584
[1:1:0712/031514.318795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7f0126d85070 0x38390bde3fe0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 451 0x7f0128cad2e0 0x383903df9fe0 
[1:1:0712/031514.353512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7f0128cad2e0 0x38390443d260 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031514.354859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , func_1781714972([{"meta":{"tplInfo":{"width":"","templateId":"","height":""},"posInfo":{"psid":"6259
[1:1:0712/031514.355044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031514.365368:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x281f5aa629c8, 0x3839037f3988
[1:1:0712/031514.365500:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 0
[1:1:0712/031514.365687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 588
[1:1:0712/031514.365798:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7f0126d85070 0x383903df42e0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 452 0x7f0128cad2e0 0x38390443d260 
[1:1:0712/031514.389263:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031514.443567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7f0128cad2e0 0x383903dc5a60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031514.444156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , jsonp1562927310415({"returncode":0,"message":"","result":{"url":"https://www.che168.com/nlist/beijin
[1:1:0712/031514.444271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031514.765564:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 469, 7f01296ca881
[1:1:0712/031514.782672:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"413 0x7f0128cad2e0 0x3839042309e0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031514.782935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"413 0x7f0128cad2e0 0x3839042309e0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031514.783257:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031514.783820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , le, (){T(pt,function(e,t){e&&e.tag?(e.exposeLinks.length&&!0!==e.exposeSend&&I(e.el)&&N(e.el)&&(se(e.exp
[1:1:0712/031514.783994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031515.371785:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 482, 7f01296ca881
[1:1:0712/031515.404296:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"414","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031515.404721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"414","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031515.405155:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031515.405835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , A, (){yt=t}
[1:1:0712/031515.406058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031515.408113:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 483, 7f01296ca8db
[1:1:0712/031515.437420:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"414","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031515.437741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"414","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031515.438122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 615
[1:1:0712/031515.438302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7f0126d85070 0x38390422e6e0 , 5:3_https://v.autohome.com.cn/, 0, , 483 0x7f0126d85070 0x383903db4760 
[1:1:0712/031515.438632:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031515.439161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , tick, (){for(var e,t=H.timers,n=0;n<t.length;n++)e=t[n],e()||t[n]!==e||t.splice(n--,1);t.length||H.fx.stop
[1:1:0712/031515.439329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031515.440647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x281f5aa629c8, 0x3839037f3950
[1:1:0712/031515.440837:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 0
[1:1:0712/031515.441169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 616
[1:1:0712/031515.441346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f0126d85070 0x383904244760 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 483 0x7f0126d85070 0x383903db4760 
[1:1:0712/031515.496600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7f0128cad2e0 0x383906752ae0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031515.497918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , /* Append File:/car/sidebar/common/js/tool-cookie.js */
define("toolCookie",[],function(e,t,o){"use
[1:1:0712/031515.498099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031515.502046:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031515.596860:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[67454:67454:0712/031515.607877:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/031515.609115:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3839067d9e20
[1:1:0712/031515.609298:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[67454:67454:0712/031515.614592:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[67454:67454:0712/031515.662489:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://v.autohome.com.cn/, https://v.autohome.com.cn/, 4
[67454:67454:0712/031515.662633:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://v.autohome.com.cn/, https://v.autohome.com.cn
[1:1:0712/031516.304908:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031516.305628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , image.onload.image.onerror, (){image.onload=image.onerror=null;image=null}
[1:1:0712/031516.305810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031517.135074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/031517.135418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031517.139948:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[67454:67454:0712/031517.161382:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/031518.461811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 525, 7f01296ca8db
[1:1:0712/031518.494955:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"422 0x7f0126d85070 0x38390422fa60 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031518.495300:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"422 0x7f0126d85070 0x38390422fa60 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031518.495856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 699
[1:1:0712/031518.496119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f0126d85070 0x38390c3d2be0 , 5:3_https://v.autohome.com.cn/, 0, , 525 0x7f0126d85070 0x3839065bcb60 
[1:1:0712/031518.496420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031518.497031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , (){if(AutoHeartBeat.ClientX!=AutoHeartBeat.ClientXEnd||AutoHeartBeat.ClientY!=AutoHeartBeat.ClientYE
[1:1:0712/031518.497250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031518.777519:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 588, 7f01296ca881
[1:1:0712/031518.794522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"452 0x7f0128cad2e0 0x38390443d260 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031518.794898:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"452 0x7f0128cad2e0 0x38390443d260 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031518.795286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031518.795968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , le, (){T(pt,function(e,t){e&&e.tag?(e.exposeLinks.length&&!0!==e.exposeSend&&I(e.el)&&N(e.el)&&(se(e.exp
[1:1:0712/031518.796195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031518.969521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031518.970298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , image.onload.image.onerror, () {
            image.onload = image.onerror = null;
            image = null;
        }
[1:1:0712/031518.970543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031519.071864:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 600 0x7f0128cad2e0 0x38390be2e860 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031519.072798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , 

[1:1:0712/031519.073180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031519.109976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 601 0x7f0128cad2e0 0x383904248ae0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031519.111032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , smCB_1562926514005({"code":1100,"detail":{"len":"12","sign":"Y3aC/fAnw/8PwKLjmNjRGg==","timestamp":"
[1:1:0712/031519.111262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031519.271955:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x281f5aa629c8, 0x3839037f3988
[1:1:0712/031519.272267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 0
[1:1:0712/031519.272699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 722
[1:1:0712/031519.272966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7f0126d85070 0x383906747960 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 601 0x7f0128cad2e0 0x383904248ae0 
		remove user.13_f5e50d21 -> 0
[1:1:0712/031524.089788:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031524.368465:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031524.371248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , (){var _0x4296f2=_0x383597[_0x37c531](_0x17ad2b);_0x4296f2[_0x30a940]=_0x30a940;_0x383597=_0x4296f2[
[1:1:0712/031524.371553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031524.374991:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031524.418794:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031524.823540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 616, 7f01296ca881
[1:1:0712/031524.841884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"483 0x7f0126d85070 0x383903db4760 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031524.842227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"483 0x7f0126d85070 0x383903db4760 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031524.842647:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031524.843218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , A, (){yt=t}
[1:1:0712/031524.843430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031524.845332:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 615, 7f01296ca8db
[1:1:0712/031524.866014:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"483 0x7f0126d85070 0x383903db4760 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031524.866336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"483 0x7f0126d85070 0x383903db4760 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031524.866788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://v.autohome.com.cn/, 747
[1:1:0712/031524.867018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 747 0x7f0126d85070 0x38390423ed60 , 5:3_https://v.autohome.com.cn/, 0, , 615 0x7f0126d85070 0x38390422e6e0 
[1:1:0712/031524.867343:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031524.867933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , tick, (){for(var e,t=H.timers,n=0;n<t.length;n++)e=t[n],e()||t[n]!==e||t.splice(n--,1);t.length||H.fx.stop
[1:1:0712/031524.868175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031524.869267:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x281f5aa629c8, 0x3839037f3950
[1:1:0712/031524.869476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://v.autohome.com.cn/u/78216589", 0
[1:1:0712/031524.869915:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 748
[1:1:0712/031524.870156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f0126d85070 0x3839065a11e0 , 5:3_https://v.autohome.com.cn/, 1, -5:3_https://v.autohome.com.cn/, 615 0x7f0126d85070 0x38390422e6e0 
[1:1:0712/031525.196615:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 575, 7f01296ca881
[1:1:0712/031525.227880:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"440 0x7f0126d85070 0x3839065a1260 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031525.228226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"440 0x7f0126d85070 0x3839065a1260 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031525.228645:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031525.229307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , (){_0x1aa493[_0x6d2f('0x1b3')](clearTimeout,_0x176eb5);}
[1:1:0712/031525.229546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031526.111263:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031526.112081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , image.onload.image.onerror, (){image.onload=image.onerror=null;image=null}
[1:1:0712/031526.112301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031526.379231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 685 0x7f0128cad2e0 0x3839042456e0 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031526.380156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , 

[1:1:0712/031526.380387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031526.422212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 686 0x7f0128cad2e0 0x38390674ad60 , "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031526.423439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , jsonp1562926880581({"returncode":0,"message":"ok","result":{"id":0,"name":"大众","match_word":"大
[1:1:0712/031526.423679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031526.426405:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031526.448233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , document.readyState
[1:1:0712/031526.448510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
[1:1:0712/031527.610914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://v.autohome.com.cn/, 722, 7f01296ca881
[1:1:0712/031527.622088:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"240cf7462860","ptid":"601 0x7f0128cad2e0 0x383904248ae0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031527.622478:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://v.autohome.com.cn/","ptid":"601 0x7f0128cad2e0 0x383904248ae0 ","rf":"5:3_https://v.autohome.com.cn/"}
[1:1:0712/031527.622876:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://v.autohome.com.cn/u/78216589"
[1:1:0712/031527.623459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://v.autohome.com.cn/, 240cf7462860, , , (){_0xdf267a();}
[1:1:0712/031527.623673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://v.autohome.com.cn/u/78216589", "v.autohome.com.cn", 3, 1, , , 0
