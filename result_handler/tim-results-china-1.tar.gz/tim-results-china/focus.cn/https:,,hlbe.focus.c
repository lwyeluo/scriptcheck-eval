[0712/010607.662998:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010607.663416:INFO:switcher_clone.cc(787)] backtrace rip is 7faa82c24891
[0712/010608.630739:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010608.631098:INFO:switcher_clone.cc(787)] backtrace rip is 7f65ce18e891
[1:1:0712/010608.642783:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/010608.643041:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/010608.648251:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[49972:49972:0712/010609.901967:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/524112c7-b310-46ef-a926-4d0dd5f4a053
[0712/010610.064042:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010610.064317:INFO:switcher_clone.cc(787)] backtrace rip is 7fb656be7891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[50003:50003:0712/010610.287110:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=50003
[50016:50016:0712/010610.287543:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=50016
[49972:49972:0712/010610.553760:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[49972:50001:0712/010610.554421:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/010610.554647:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/010610.554879:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/010610.555431:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/010610.555589:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/010610.558395:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c32aa80, 1
[1:1:0712/010610.558706:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x135a1532, 0
[1:1:0712/010610.558888:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26501460, 3
[1:1:0712/010610.559060:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2ab9a7c6, 2
[1:1:0712/010610.559258:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 32155a13 ffffff80ffffffaa323c ffffffc6ffffffa7ffffffb92a 60145026 , 10104, 4
[1:1:0712/010610.560213:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[49972:50001:0712/010610.560417:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING2Z��2<Ƨ�*`P&kLc&
[49972:50001:0712/010610.560482:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 2Z��2<Ƨ�*`P&UkLc&
[1:1:0712/010610.560591:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f65cc3c90a0, 3
[49972:50001:0712/010610.560750:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[49972:50001:0712/010610.560807:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 50024, 4, 32155a13 80aa323c c6a7b92a 60145026 
[1:1:0712/010610.560800:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f65cc554080, 2
[1:1:0712/010610.560949:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f65b6217d20, -2
[1:1:0712/010610.579490:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/010610.580363:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ab9a7c6
[1:1:0712/010610.581328:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ab9a7c6
[1:1:0712/010610.582929:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ab9a7c6
[1:1:0712/010610.584425:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.584610:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.584817:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.585006:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.585625:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ab9a7c6
[1:1:0712/010610.585963:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f65ce18e7ba
[1:1:0712/010610.586097:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f65ce185def, 7f65ce18e77a, 7f65ce1900cf
[1:1:0712/010610.591711:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ab9a7c6
[1:1:0712/010610.592092:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ab9a7c6
[1:1:0712/010610.592826:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ab9a7c6
[1:1:0712/010610.594842:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.595033:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.595213:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.595394:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ab9a7c6
[1:1:0712/010610.596627:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ab9a7c6
[1:1:0712/010610.597017:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f65ce18e7ba
[1:1:0712/010610.597163:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f65ce185def, 7f65ce18e77a, 7f65ce1900cf
[1:1:0712/010610.604817:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/010610.605227:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/010610.605371:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd3c2d32d8, 0x7ffd3c2d3258)
[1:1:0712/010610.620607:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/010610.626270:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[49972:49972:0712/010611.010652:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[49972:49972:0712/010611.010892:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[49972:49972:0712/010611.230363:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49972:49972:0712/010611.230787:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49972:49983:0712/010611.233971:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[49972:49983:0712/010611.234074:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[49972:49972:0712/010611.234307:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[49972:49972:0712/010611.234399:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[49972:49972:0712/010611.234569:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,50024, 4
[1:7:0712/010611.248575:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[49972:49994:0712/010611.309374:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/010611.402576:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x698b03cc220
[1:1:0712/010611.402924:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/010611.699590:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[49972:49972:0712/010613.190371:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[49972:49972:0712/010613.190491:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/010613.196856:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010613.200505:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010614.461928:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010614.537204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 13871ed81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/010614.537478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010614.553990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 13871ed81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/010614.554128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010614.807680:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010614.807927:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010615.268868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 350, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010615.276948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 13871ed81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/010615.277181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010615.313010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010615.325545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 13871ed81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/010615.325819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010615.337729:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[49972:49972:0712/010615.340438:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/010615.341104:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x698b03cae20
[1:1:0712/010615.341279:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[49972:49972:0712/010615.347460:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[49972:49972:0712/010615.383298:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[49972:49972:0712/010615.383492:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/010615.441958:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010616.288523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f65b7df22e0 0x698b05560e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010616.289838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 13871ed81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/010616.290029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010616.291411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[49972:49972:0712/010616.353505:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/010616.354571:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x698b03cb820
[1:1:0712/010616.354859:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[49972:49972:0712/010616.363928:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/010616.373413:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/010616.373606:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[49972:49972:0712/010616.384895:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[49972:49972:0712/010616.396922:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49972:49972:0712/010616.397944:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49972:49983:0712/010616.405574:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[49972:49983:0712/010616.405672:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[49972:49972:0712/010616.405855:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[49972:49972:0712/010616.405934:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[49972:49972:0712/010616.406072:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,50024, 4
[1:7:0712/010616.409192:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010616.826823:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/010617.394973:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f65b7df22e0 0x698b06f74e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010617.396112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 13871ed81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/010617.396343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010617.397121:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010617.570880:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49972:49972:0712/010617.577152:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[49972:49972:0712/010617.577254:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[49972:49972:0712/010617.995009:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[49972:50001:0712/010617.995415:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/010617.995604:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/010617.995804:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/010617.996237:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/010617.996382:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/010617.999386:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x7c92905, 1
[1:1:0712/010617.999717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x33839d60, 0
[1:1:0712/010617.999865:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2df73b77, 3
[1:1:0712/010618.000047:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xf266dd, 2
[1:1:0712/010618.000192:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 60ffffff9dffffff8333 0529ffffffc907 ffffffdd66fffffff200 773bfffffff72d , 10104, 5
[1:1:0712/010618.001135:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[49972:50001:0712/010618.001358:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING`��3)��f�
[49972:50001:0712/010618.001431:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is `��3)��f�
[49972:50001:0712/010618.001651:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 50071, 5, 609d8333 0529c907 dd66f200 773bf72d 
[1:1:0712/010618.001886:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f65cc3c90a0, 3
[1:1:0712/010618.002223:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f65cc554080, 2
[1:1:0712/010618.002407:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f65b6217d20, -2
[1:1:0712/010618.017048:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/010618.017258:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal f266dd
[1:1:0712/010618.017433:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal f266dd
[1:1:0712/010618.017699:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal f266dd
[1:1:0712/010618.018318:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.018504:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.018649:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.018788:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.019188:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal f266dd
[1:1:0712/010618.019380:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f65ce18e7ba
[1:1:0712/010618.019496:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f65ce185def, 7f65ce18e77a, 7f65ce1900cf
[1:1:0712/010618.020127:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010618.021904:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal f266dd
[1:1:0712/010618.022158:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal f266dd
[1:1:0712/010618.022571:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal f266dd
[1:1:0712/010618.023589:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.023744:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.023885:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.024093:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f266dd
[1:1:0712/010618.024755:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal f266dd
[1:1:0712/010618.025004:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f65ce18e7ba
[1:1:0712/010618.025118:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f65ce185def, 7f65ce18e77a, 7f65ce1900cf
[1:1:0712/010618.028073:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/010618.028429:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/010618.028525:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd3c2d32d8, 0x7ffd3c2d3258)
[1:1:0712/010618.039808:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/010618.044165:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/010618.209092:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x698b0343220
[1:1:0712/010618.209250:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/010618.650225:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010618.650513:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[49972:49972:0712/010619.109470:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49972:49972:0712/010619.118755:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49972:49972:0712/010619.134894:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://hlbe.focus.cn/
[49972:49972:0712/010619.135008:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://hlbe.focus.cn/, https://hlbe.focus.cn/, 1
[49972:49972:0712/010619.135167:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://hlbe.focus.cn/, HTTP/1.1 200 OK Server: NWSs Date: Fri, 12 Jul 2019 07:59:23 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip X-NWS-UUID-VERIFY: b9eb3dcf3d0ed2dd9d05587e578fb8aa Vary: Accept-Encoding Set-Cookie: focus_mes_info=direct%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40null%40%40null%40%40null%40%40;Max-Age=1800;domain=focus.cn;path=/ Set-Cookie: focus_pc_city_p=hlbe;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: focus_city_p=hlbe;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: focus_city_c=150700;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: focus_city_s=hlbe;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: pc_ad_feed=1;Max-Age=1296000;path=focus.cn Content-Language: en-US X-Daa-Tunnel: hop_count=2 X-NWS-LOG-UUID: d8176144-ed71-44bc-98c2-dd2c3e26a2b1  ,50071, 5
[49972:49983:0712/010619.136222:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[49972:49983:0712/010619.136335:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/010619.137929:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010619.182116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010619.184420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 13871eeb09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/010619.184718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/010619.190477:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://hlbe.focus.cn/
[1:1:0712/010619.192568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[49972:49972:0712/010619.306440:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://hlbe.focus.cn/, https://hlbe.focus.cn/, 1
[49972:49972:0712/010619.306552:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://hlbe.focus.cn/, https://hlbe.focus.cn
[1:1:0712/010619.332716:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010619.429923:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010619.510571:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010619.511376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 13871ed81f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/010619.511620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010619.537495:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010619.607799:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010619.608003:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hlbe.focus.cn/"
[1:1:0712/010619.810198:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010620.331297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f65b5eca070 0x698b0471160 , "https://hlbe.focus.cn/"
[1:1:0712/010620.334391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , ,  !function(e,t,n,g,i){e[i]=e[i]||function(){(e[i].q=e[i].q||[]).push(arguments)},n=t.createElement("
[1:1:0712/010620.334640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[1:1:0712/010620.336887:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010620.350532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f65b5eca070 0x698b0471160 , "https://hlbe.focus.cn/"
[1:1:0712/010620.355193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f65b5eca070 0x698b0471160 , "https://hlbe.focus.cn/"
[1:1:0712/010620.573711:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.223718, 116, 1
[1:1:0712/010620.573891:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/010620.684039:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://hlbe.focus.cn/"
[1:1:0712/010620.687320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&a(+n.data.slice(t.length))}
[1:1:0712/010620.687634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[1:1:0712/010621.081245:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010621.085082:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010621.085546:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010621.085962:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010621.086344:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010621.316325:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010621.316559:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hlbe.focus.cn/"
[1:1:0712/010621.719936:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.403388, 5435, 1
[1:1:0712/010621.720179:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010622.577263:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010623.212411:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010623.212749:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hlbe.focus.cn/"
[1:1:0712/010623.242449:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.029551, 158, 1
[1:1:0712/010623.242742:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010624.696341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f65b7df22e0 0x698b05c4ce0 , "https://hlbe.focus.cn/"
[1:1:0712/010624.700841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , try{!function(e,t,n,i){"use strict";function r(e){for(var t in e)k.has(e,t)&&(this[t]=e[t])}function
[1:1:0712/010624.701131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[49972:49972:0712/010635.851797:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/010635.859378:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/010636.066294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f65b7df22e0 0x698b05fe4e0 , "https://hlbe.focus.cn/"
[1:1:0712/010636.070230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , !function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var u="function"==typeof require&&require;if(
[1:1:0712/010636.072108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
		remove user.10_da14948 -> 0
		remove user.11_58a3742 -> 0
		remove user.12_d490352a -> 0
		remove user.13_7e2716d0 -> 0
		remove user.14_faa9f3a9 -> 0
[1:1:0712/010637.357268:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010637.357549:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hlbe.focus.cn/"
[1:1:0712/010637.358361:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f65b5eca070 0x698b064fe60 , "https://hlbe.focus.cn/"
[1:1:0712/010637.358845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , var _focus_pv_id = "focus.shengtai.all";
[1:1:0712/010637.358952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[1:1:0712/010637.363862:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f65b5eca070 0x698b064fe60 , "https://hlbe.focus.cn/"
[49972:49972:0712/010637.514982:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/010637.517207:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x698b045fe20
[1:1:0712/010637.517412:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[49972:49972:0712/010637.522009:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[49972:49972:0712/010637.557404:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://hlbe.focus.cn/, https://hlbe.focus.cn/, 4
[49972:49972:0712/010637.557537:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://hlbe.focus.cn/, https://hlbe.focus.cn
[1:1:0712/010637.575023:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1fb1cc6629c8, 0x698b011f1a8
[1:1:0712/010637.575319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 1000
[1:1:0712/010637.575716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 596
[1:1:0712/010637.575968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7f65b5eca070 0x698b0b4ee60 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 464 0x7f65b5eca070 0x698b064fe60 
[1:1:0712/010637.586825:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f65b5eca070 0x698b064fe60 , "https://hlbe.focus.cn/"
[1:1:0712/010637.671052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f65b5eca070 0x698b064fe60 , "https://hlbe.focus.cn/"
[1:1:0712/010638.739908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/010638.740167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[1:1:0712/010639.636014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010639.636476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , r.onreadystatechange, (){if(4===r.readyState)if(200===r.status)i&&i(k.JSONDecode(r.responseText));else{var e="Bad HTTP sta
[1:1:0712/010639.636626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[1:1:0712/010639.637091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010639.638439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010640.104544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010640.105383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0712/010640.105623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[1:1:0712/010640.106637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010640.476087:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/010640.476388:INFO:render_frame_impl.cc(7019)] 	 [url] = https://hlbe.focus.cn
[49972:49972:0712/010640.478971:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://hlbe.focus.cn/
[49972:49972:0712/010640.498499:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49972:49972:0712/010640.502793:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49972:49983:0712/010640.514254:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[49972:49972:0712/010640.514298:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://zhibo-focus.sohu.com/
[49972:49972:0712/010640.514355:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://zhibo-focus.sohu.com/, https://zhibo-focus.sohu.com/xcookie.html?SUV, 4
[49972:49983:0712/010640.514362:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[49972:49972:0712/010640.514420:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://zhibo-focus.sohu.com/, HTTP/1.1 200 OK Server: NWSs Date: Fri, 12 Jul 2019 07:58:16 GMT Cache-Control: max-age=600 Expires: Fri, 12 Jul 2019 08:08:16 GMT X-NWS-LOG-UUID: 4e39c130-f0c4-4969-8eff-5b42c007c575 X-Daa-Tunnel: hop_count=1 Content-Type: text/html Content-Length: 2087 Last-Modified: Tue, 04 Sep 2018 07:56:22 GMT Content-Encoding: gzip X-Cache-Lookup: Hit From Disktank3 Gz Accept-Ranges: bytes X-Cache-Lookup: Hit From Inner Cluster  ,50071, 5
[1:7:0712/010640.518215:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010640.936908:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f65b6232bd0 0x698aff4ef58 , "https://hlbe.focus.cn/"
[1:1:0712/010640.959339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , webpackJsonp([1,8],{0:function(e,t,n){n(159),n(160),n(161),n(163),e.exports=n(165)},159:function(e,t
[1:1:0712/010640.959615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "hlbe.focus.cn", 3, 1, , , 0
[1:1:0712/010643.283963:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010643.284432:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010643.433305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f65b6232bd0 0x698aff4ef58 , "https://hlbe.focus.cn/"
[1:1:0712/010643.577705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 5000
[1:1:0712/010643.578118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 663
[1:1:0712/010643.578398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f65b5eca070 0x698b0adf260 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 611 0x7f65b6232bd0 0x698aff4ef58 
[1:1:0712/010643.980276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1fb1cc6629c8, 0x698b011f8a8
[1:1:0712/010643.980527:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 0
[1:1:0712/010643.980952:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 665
[1:1:0712/010643.981144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7f65b5eca070 0x698b05c1fe0 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 611 0x7f65b6232bd0 0x698aff4ef58 
[1:1:0712/010644.040135:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 13
[1:1:0712/010644.040627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 666
[1:1:0712/010644.040829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7f65b5eca070 0x698b0826760 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 611 0x7f65b6232bd0 0x698aff4ef58 
[1:1:0712/010644.411527:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 6000
[1:1:0712/010644.411930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 671
[1:1:0712/010644.412132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 671 0x7f65b5eca070 0x698b09289e0 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 611 0x7f65b6232bd0 0x698aff4ef58 
[1:1:0712/010645.179901:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010645.202266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 5000
[1:1:0712/010645.202546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 681
[1:1:0712/010645.202675:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f65b5eca070 0x698b0f13260 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 611 0x7f65b6232bd0 0x698aff4ef58 
[1:1:0712/010645.443787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010645.825469:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010646.002609:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "hlbe.focus.cn", "focus.cn"
[1:1:0712/010646.016721:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.59015, 0, 0
[1:1:0712/010646.016974:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010646.823294:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 596, 7f65b880f881
[1:1:0712/010646.854749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"464 0x7f65b5eca070 0x698b064fe60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010646.855113:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"464 0x7f65b5eca070 0x698b064fe60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010646.855538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010646.856137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){i({},a);try{window.document.body.removeChild(d)}catch(e){}}
[1:1:0712/010646.856352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010646.923487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1fb1cc6629c8, 0x698b011f150
[1:1:0712/010646.923817:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 1000
[1:1:0712/010646.924188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 723
[1:1:0712/010646.924417:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7f65b5eca070 0x698b08ba7e0 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 596 0x7f65b5eca070 0x698b0b4ee60 
[1:1:0712/010647.052993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , document.readyState
[1:1:0712/010647.053274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010648.046152:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://hlbe.focus.cn/"
[1:1:0712/010648.046854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , n.onload, (){k.retCodeService("/pixel",!0,0,i)}
[1:1:0712/010648.047107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010648.650709:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010648.651444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0712/010648.651691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010648.652332:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010648.983552:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010648.984336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , e.onreadystatechange, (){if(4==e.readyState)return 200==e.status?i(JSON.parse(e.responseText)):t._handleError("error",a)}
[1:1:0712/010648.984579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010648.986824:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010648.991369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010649.150048:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010649.150773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , e.onreadystatechange, (){if(4==e.readyState)return 200==e.status?i(JSON.parse(e.responseText)):t._handleError("error",a)}
[1:1:0712/010649.150994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010649.151479:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010649.153856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010649.327021:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010649.327783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , e.onreadystatechange, (){if(4==e.readyState)return 200==e.status?i(JSON.parse(e.responseText)):t._handleError("error",a)}
[1:1:0712/010649.328050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010649.328561:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010649.331339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010649.390483:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010649.390745:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hlbe.focus.cn/"
[1:1:0712/010649.393691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 694 0x7f65b5eca070 0x698b0481e60 , "https://hlbe.focus.cn/"
[1:1:0712/010649.395044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , !function(n){function o(t){if(e[t])return e[t].exports;var i=e[t]={exports:{},id:t,loaded:!1};return
[1:1:0712/010649.395280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010649.496751:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 694 0x7f65b5eca070 0x698b0481e60 , "https://hlbe.focus.cn/"
[1:1:0712/010649.562237:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://hlbe.focus.cn/"
[1:1:0712/010649.563751:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://hlbe.focus.cn/"
[1:1:0712/010649.583601:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x1fb1cc6629c8, 0x698b011f1e0
[1:1:0712/010649.583897:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 1500
[1:1:0712/010649.584292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 799
[1:1:0712/010649.584526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7f65b5eca070 0x698b1ab0a60 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 694 0x7f65b5eca070 0x698b0481e60 
[1:1:0712/010649.587041:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://hlbe.focus.cn/"
[1:1:0712/010649.607550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://hlbe.focus.cn/"
[1:1:0712/010649.687080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://hlbe.focus.cn/"
[1:1:0712/010650.648583:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 665, 7f65b880f881
[1:1:0712/010650.684182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010650.684543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010650.684900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010650.685411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){Yt=a}
[1:1:0712/010650.685629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010650.733233:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 666, 7f65b880f8db
[1:1:0712/010650.770317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010650.770637:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010650.771056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 822
[1:1:0712/010650.771250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 822 0x7f65b5eca070 0x698b0428560 , 5:3_https://hlbe.focus.cn/, 0, , 666 0x7f65b5eca070 0x698b0826760 
[1:1:0712/010650.771565:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010650.772051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , re.fx.tick, (){var e,t=re.timers,n=0;for(Yt=re.now();n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.len
[1:1:0712/010650.772332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010650.910129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010650.910834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , t, (n,o){var s,u,l,f,p;try{if(t&&(o||4===c.readyState))if(t=a,i&&(c.onreadystatechange=re.noop,Jt&&dele
[1:1:0712/010650.911027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010650.912192:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010650.914790:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010650.915445:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xdaeb4ce860
[1:1:0712/010651.842827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , document.readyState
[1:1:0712/010651.843016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/010653.372842:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 723, 7f65b880f881
[1:1:0712/010653.413097:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"596 0x7f65b5eca070 0x698b0b4ee60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010653.413411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"596 0x7f65b5eca070 0x698b0b4ee60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010653.413825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010653.414348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){r||(r=!0,t&&t(!1))}
[1:1:0712/010653.414524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010653.709760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 663, 7f65b880f8db
[1:1:0712/010653.746663:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010653.746975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010653.747437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 870
[1:1:0712/010653.747634:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f65b5eca070 0x698b1b4b6e0 , 5:3_https://hlbe.focus.cn/, 0, , 663 0x7f65b5eca070 0x698b0adf260 
[1:1:0712/010653.747904:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010653.748445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){t.$imgList.animate({top:"-35px"},"slow",function(){var e=t.$imgList.find(".hexin-item").eq(0).rem
[1:1:0712/010653.748662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010653.778341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1fb1cc6629c8, 0x698b011f150
[1:1:0712/010653.778569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 0
[1:1:0712/010653.778931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 871
[1:1:0712/010653.779130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7f65b5eca070 0x698b04719e0 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 663 0x7f65b5eca070 0x698b0adf260 
[1:1:0712/010653.796508:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 13
[1:1:0712/010653.796981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 872
[1:1:0712/010653.797247:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 872 0x7f65b5eca070 0x698b1ab0f60 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 663 0x7f65b5eca070 0x698b0adf260 
[1:1:0712/010653.958369:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f65b7df22e0 0x698aff4ed60 , "https://hlbe.focus.cn/"
[1:1:0712/010653.959148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0712/010653.959289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010653.994262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 778 0x7f65b7df22e0 0x698b124aa60 , "https://hlbe.focus.cn/"
[1:1:0712/010653.995949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , document.write('<script charset="utf-8" src="https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js"></scri
[1:1:0712/010653.996185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[49972:49972:0712/010654.016463:INFO:CONSOLE(1)] "Failed to execute 'write' on 'Document': It isn't possible to write into a document from an asynchronously-loaded external script unless it is explicitly opened.", source: https://jspassport.ssl.qhimg.com/11.0.1.js?0f9a4c405bb4b8c85687f52b6e595997 (1)
[1:1:0712/010654.070133:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 780 0x7f65b7df22e0 0x698b05c42e0 , "https://hlbe.focus.cn/"
[1:1:0712/010654.070767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , /**/jsonp_1562918805972({"code":401,"msg":"用户未登录","errorCode":401,"errorMessage":"用户�
[1:1:0712/010654.070886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010654.086698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010654.126079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 781 0x7f65b7df22e0 0x698b08fbc60 , "https://hlbe.focus.cn/"
[1:1:0712/010654.126581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , 
[1:1:0712/010654.126692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010654.126904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://hlbe.focus.cn/"
[1:1:0712/010654.787625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010654.788338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0712/010654.788596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010654.789502:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010654.791852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010654.851838:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010654.852559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , t, (n,o){var s,u,l,f,p;try{if(t&&(o||4===c.readyState))if(t=a,i&&(c.onreadystatechange=re.noop,Jt&&dele
[1:1:0712/010654.852750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010654.853185:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010654.855824:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010654.856514:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xdaeb4ce860
[1:1:0712/010654.910870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 681, 7f65b880f8db
[1:1:0712/010654.923676:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010654.923874:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010654.924170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 918
[1:1:0712/010654.924287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7f65b5eca070 0x698b1ad4a60 , 5:3_https://hlbe.focus.cn/, 0, , 681 0x7f65b5eca070 0x698b0f13260 
[1:1:0712/010654.924446:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010654.924804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){t.$imgList.animate({top:"-30px"},"slow",function(){var e=t.$imgList.find(".roll-item").eq(0).remo
[1:1:0712/010654.924964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010654.927411:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 671, 7f65b880f8db
[1:1:0712/010654.966883:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010654.967271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"611 0x7f65b6232bd0 0x698aff4ef58 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010654.967847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 919
[1:1:0712/010654.968098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7f65b5eca070 0x698b082f760 , 5:3_https://hlbe.focus.cn/, 0, , 671 0x7f65b5eca070 0x698b09289e0 
[1:1:0712/010654.968409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010654.969023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , t, (){n.page>=n.total-1&&(n.page=-1),n.page++,n.animate(n.page)}
[1:1:0712/010654.969248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010655.618745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 799, 7f65b880f881
[1:1:0712/010655.638904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"694 0x7f65b5eca070 0x698b0481e60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010655.639302:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"694 0x7f65b5eca070 0x698b0481e60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010655.639807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010655.640446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){return t.registerDomObserver()}
[1:1:0712/010655.640715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[49972:49972:0712/010657.815094:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
		remove user.11_22724c4c -> 0
		remove user.12_1365150f -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/010703.648706:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010707.459726:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010707.460323:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010711.272011:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1fb1cc6629c8, 0x698b011f150
[1:1:0712/010711.272258:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 0
[1:1:0712/010711.272862:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 944
[1:1:0712/010711.273075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 944 0x7f65b5eca070 0x698b3897d60 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 799 0x7f65b5eca070 0x698b1ab0a60 
[1:1:0712/010711.429471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 834 0x7f65b7df22e0 0x698b0f1f060 , "https://hlbe.focus.cn/"
[1:1:0712/010711.434622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , !function(t){function e(n){if(i[n])return i[n].exports;var o=i[n]={exports:{},id:n,loaded:!1};return
[1:1:0712/010711.434830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010711.659359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 10
[1:1:0712/010711.659783:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 960
[1:1:0712/010711.659987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7f65b5eca070 0x698b08f9760 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 834 0x7f65b7df22e0 0x698b0f1f060 
[1:1:0712/010711.662848:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://hlbe.focus.cn/"
[1:1:0712/010711.832901:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://hlbe.focus.cn/"
[1:1:0712/010711.833335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , e.onload.e.onerror, (){window[n]=null}
[1:1:0712/010711.833445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010711.933464:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://hlbe.focus.cn/"
[1:1:0712/010711.934163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , e.onload.e.onerror, (){window[n]=null}
[1:1:0712/010711.934356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010712.028875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://hlbe.focus.cn/"
[1:1:0712/010712.029663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , e.onload.e.onerror, (){window[n]=null}
[1:1:0712/010712.029934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010712.165315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , document.readyState
[1:1:0712/010712.165492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010712.387148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 871, 7f65b880f881
[1:1:0712/010712.401301:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"663 0x7f65b5eca070 0x698b0adf260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010712.401493:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"663 0x7f65b5eca070 0x698b0adf260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010712.401738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010712.402065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){Yt=a}
[1:1:0712/010712.402172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010712.416073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 872, 7f65b880f8db
[1:1:0712/010712.456421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"663 0x7f65b5eca070 0x698b0adf260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010712.456732:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"663 0x7f65b5eca070 0x698b0adf260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010712.457205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 971
[1:1:0712/010712.457400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7f65b5eca070 0x698b1a981e0 , 5:3_https://hlbe.focus.cn/, 0, , 872 0x7f65b5eca070 0x698b1ab0f60 
[1:1:0712/010712.457695:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010712.458216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , re.fx.tick, (){var e,t=re.timers,n=0;for(Yt=re.now();n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.len
[1:1:0712/010712.458394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010713.973161:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 918, 7f65b880f8db
[1:1:0712/010713.987098:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"681 0x7f65b5eca070 0x698b0f13260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010713.987300:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"681 0x7f65b5eca070 0x698b0f13260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010713.987522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 1010
[1:1:0712/010713.987633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7f65b5eca070 0x698b0bc7260 , 5:3_https://hlbe.focus.cn/, 0, , 918 0x7f65b5eca070 0x698b1ad4a60 
[1:1:0712/010713.987820:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010713.988159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){t.$imgList.animate({top:"-30px"},"slow",function(){var e=t.$imgList.find(".roll-item").eq(0).remo
[1:1:0712/010713.988278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010714.151061:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010714.151496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0712/010714.151615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010714.151800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://hlbe.focus.cn/"
[1:1:0712/010714.384471:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 919, 7f65b880f8db
[1:1:0712/010714.405189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"671 0x7f65b5eca070 0x698b09289e0 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010714.405376:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"671 0x7f65b5eca070 0x698b09289e0 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010714.405604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 1014
[1:1:0712/010714.405717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7f65b5eca070 0x698b0921560 , 5:3_https://hlbe.focus.cn/, 0, , 919 0x7f65b5eca070 0x698b082f760 
[1:1:0712/010714.405927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010714.406244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , t, (){n.page>=n.total-1&&(n.page=-1),n.page++,n.animate(n.page)}
[1:1:0712/010714.406352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010714.440985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1fb1cc6629c8, 0x698b011f150
[1:1:0712/010714.441189:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 0
[1:1:0712/010714.441391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 1016
[1:1:0712/010714.441514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7f65b5eca070 0x698b0546be0 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 919 0x7f65b5eca070 0x698b082f760 
[1:1:0712/010714.465598:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 13
[1:1:0712/010714.465866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 1017
[1:1:0712/010714.465985:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7f65b5eca070 0x698b03ac0e0 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 919 0x7f65b5eca070 0x698b082f760 
[1:1:0712/010714.914305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1fb1cc6629c8, 0x698b011f270
[1:1:0712/010714.914619:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hlbe.focus.cn/", 10
[1:1:0712/010714.915036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 1023
[1:1:0712/010714.915308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f65b5eca070 0x698b231dee0 , 5:3_https://hlbe.focus.cn/, 1, -5:3_https://hlbe.focus.cn/, 919 0x7f65b5eca070 0x698b082f760 
[1:1:0712/010714.980387:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 870, 7f65b880f8db
[1:1:0712/010715.026217:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"663 0x7f65b5eca070 0x698b0adf260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010715.026591:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"663 0x7f65b5eca070 0x698b0adf260 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010715.027134:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hlbe.focus.cn/, 1033
[1:1:0712/010715.027411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1033 0x7f65b5eca070 0x698b0636960 , 5:3_https://hlbe.focus.cn/, 0, , 870 0x7f65b5eca070 0x698b1b4b6e0 
[1:1:0712/010715.027820:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010715.028500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){t.$imgList.animate({top:"-35px"},"slow",function(){var e=t.$imgList.find(".hexin-item").eq(0).rem
[1:1:0712/010715.028753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010715.142627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hlbe.focus.cn/, 944, 7f65b880f881
[1:1:0712/010715.197441:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3fdea1b02860","ptid":"799 0x7f65b5eca070 0x698b1ab0a60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010715.197760:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hlbe.focus.cn/","ptid":"799 0x7f65b5eca070 0x698b1ab0a60 ","rf":"5:3_https://hlbe.focus.cn/"}
[1:1:0712/010715.198161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hlbe.focus.cn/"
[1:1:0712/010715.198722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hlbe.focus.cn/, 3fdea1b02860, , , (){i.mirror.initialize(n)}
[1:1:0712/010715.198904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hlbe.focus.cn/", "focus.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[49972:49972:0712/010721.439400:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
