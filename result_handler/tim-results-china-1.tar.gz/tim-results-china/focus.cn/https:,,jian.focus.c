[0712/010337.517892:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010337.518281:INFO:switcher_clone.cc(787)] backtrace rip is 7fdea30f8891
[0712/010338.378457:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010338.378875:INFO:switcher_clone.cc(787)] backtrace rip is 7ff35ccb2891
[1:1:0712/010338.390669:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/010338.390949:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/010338.396333:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[49705:49705:0712/010339.634781:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/90042db2-6c32-46db-b592-8d7e8baef161
[0712/010339.824864:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010339.825249:INFO:switcher_clone.cc(787)] backtrace rip is 7f66316cd891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[49737:49737:0712/010340.077384:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=49737
[49749:49749:0712/010340.077803:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=49749
[49705:49705:0712/010340.170423:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[49705:49735:0712/010340.171135:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/010340.171357:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/010340.171574:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/010340.172189:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/010340.172352:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/010340.175196:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c08d136, 1
[1:1:0712/010340.175515:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x13c2a6c8, 0
[1:1:0712/010340.175692:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2ef56a62, 3
[1:1:0712/010340.175865:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1f695318, 2
[1:1:0712/010340.176095:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc8ffffffa6ffffffc213 36ffffffd1083c 1853691f 626afffffff52e , 10104, 4
[1:1:0712/010340.177004:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[49705:49735:0712/010340.177220:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGȦ�6�<Sibj�.�lv
[49705:49735:0712/010340.177296:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ȧ�6�<Sibj�.���lv
[49705:49735:0712/010340.177555:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[49705:49735:0712/010340.177639:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 49757, 4, c8a6c213 36d1083c 1853691f 626af52e 
[1:1:0712/010340.178053:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff35aeed0a0, 3
[1:1:0712/010340.178262:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff35b078080, 2
[1:1:0712/010340.178418:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff344d3bd20, -2
[1:1:0712/010340.197093:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/010340.197890:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f695318
[1:1:0712/010340.198842:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f695318
[1:1:0712/010340.200471:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f695318
[1:1:0712/010340.201959:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.202202:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.202381:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.202573:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.203206:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f695318
[1:1:0712/010340.203524:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff35ccb27ba
[1:1:0712/010340.203657:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff35cca9def, 7ff35ccb277a, 7ff35ccb40cf
[1:1:0712/010340.209362:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f695318
[1:1:0712/010340.209722:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f695318
[1:1:0712/010340.210479:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f695318
[1:1:0712/010340.212476:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.212669:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.212871:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.213071:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f695318
[1:1:0712/010340.214303:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f695318
[1:1:0712/010340.214675:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff35ccb27ba
[1:1:0712/010340.214813:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff35cca9def, 7ff35ccb277a, 7ff35ccb40cf
[1:1:0712/010340.222541:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/010340.222961:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/010340.223131:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdb5f48928, 0x7ffdb5f488a8)
[1:1:0712/010340.238454:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/010340.244302:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[49705:49705:0712/010340.851823:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49705:49705:0712/010340.852970:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49705:49716:0712/010340.864490:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[49705:49716:0712/010340.864586:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[49705:49705:0712/010340.864724:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[49705:49705:0712/010340.864815:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[49705:49705:0712/010340.864955:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,49757, 4
[1:7:0712/010340.870802:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[49705:49728:0712/010340.908718:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/010341.029612:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x33ceb52dd220
[1:1:0712/010341.029888:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/010341.318544:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[49705:49705:0712/010343.113234:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[49705:49705:0712/010343.113357:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/010343.148164:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010343.152319:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010343.728648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15d8832a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/010343.728967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010343.745030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15d8832a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/010343.745306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010343.810526:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010344.065345:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010344.065658:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010344.363561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010344.371714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15d8832a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/010344.371961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010344.408433:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010344.414998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15d8832a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/010344.415320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010344.427447:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/010344.431190:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x33ceb52dbe20
[1:1:0712/010344.431388:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[49705:49705:0712/010344.441867:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[49705:49705:0712/010344.450609:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[49705:49705:0712/010344.485591:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[49705:49705:0712/010344.485773:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/010344.507859:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010345.155633:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7ff3469162e0 0x33ceb53941e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010345.157097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15d8832a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/010345.157367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010345.159020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[49705:49705:0712/010345.210071:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/010345.212135:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x33ceb52dc820
[1:1:0712/010345.212382:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[49705:49705:0712/010345.217058:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/010345.231227:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/010345.231453:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[49705:49705:0712/010345.234166:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[49705:49705:0712/010345.242719:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49705:49705:0712/010345.243794:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49705:49716:0712/010345.248558:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[49705:49705:0712/010345.248597:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[49705:49705:0712/010345.248637:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[49705:49716:0712/010345.248644:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[49705:49705:0712/010345.248702:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,49757, 4
[1:7:0712/010345.255849:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010345.784407:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/010346.268517:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7ff3469162e0 0x33ceb56473e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010346.269589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15d8832a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/010346.270247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010346.271020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010346.335326:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49705:49705:0712/010346.338873:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[49705:49705:0712/010346.338989:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/010346.710569:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010347.344348:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010347.344641:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010347.827766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010347.832410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 15d8833d09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/010347.832699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/010347.840862:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[49705:49705:0712/010347.985042:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[49705:49735:0712/010347.985506:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/010347.985714:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/010347.985914:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/010347.986312:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/010347.986453:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/010347.989068:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8e97692, 1
[1:1:0712/010347.989454:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2fb0a685, 0
[1:1:0712/010347.989641:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10f3fbb2, 3
[1:1:0712/010347.989824:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e138f14, 2
[1:1:0712/010347.989999:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff85ffffffa6ffffffb02f ffffff9276ffffffe908 14ffffff8f133e ffffffb2fffffffbfffffff310 , 10104, 5
[1:1:0712/010347.991009:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[49705:49735:0712/010347.991303:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���/�v��>���&mv
[49705:49735:0712/010347.991397:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���/�v��>���x�&mv
[1:1:0712/010347.991293:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff35aeed0a0, 3
[49705:49735:0712/010347.991752:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 49804, 5, 85a6b02f 9276e908 148f133e b2fbf310 
[1:1:0712/010347.991673:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff35b078080, 2
[1:1:0712/010347.992310:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff344d3bd20, -2
[1:1:0712/010348.013818:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/010348.014201:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e138f14
[1:1:0712/010348.014592:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e138f14
[1:1:0712/010348.015266:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e138f14
[1:1:0712/010348.016732:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.016969:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.017205:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.017427:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.018105:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e138f14
[1:1:0712/010348.018431:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff35ccb27ba
[1:1:0712/010348.018603:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff35cca9def, 7ff35ccb277a, 7ff35ccb40cf
[1:1:0712/010348.024591:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e138f14
[1:1:0712/010348.025054:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e138f14
[1:1:0712/010348.026038:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e138f14
[1:1:0712/010348.028397:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.028694:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.028933:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.029178:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e138f14
[1:1:0712/010348.030554:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e138f14
[1:1:0712/010348.030973:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff35ccb27ba
[1:1:0712/010348.031179:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff35cca9def, 7ff35ccb277a, 7ff35ccb40cf
[1:1:0712/010348.038998:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/010348.039612:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/010348.039822:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdb5f48928, 0x7ffdb5f488a8)
[1:1:0712/010348.053379:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/010348.056989:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/010348.076202:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010348.076971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15d8832a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/010348.077217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010348.227993:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x33ceb528e220
[1:1:0712/010348.228357:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/010348.269126:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010348.270809:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/010348.271041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 15d8833d09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/010348.271415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/010348.418115:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010348.422158:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/010348.422402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 15d8833d09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/010348.422673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[49705:49705:0712/010349.083381:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49705:49705:0712/010349.090985:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49705:49716:0712/010349.126662:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[49705:49716:0712/010349.126764:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[49705:49705:0712/010349.127144:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://jian.focus.cn/
[49705:49705:0712/010349.127221:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://jian.focus.cn/, https://jian.focus.cn/, 1
[49705:49705:0712/010349.127370:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://jian.focus.cn/, HTTP/1.1 200 OK Server: NWSs Date: Fri, 12 Jul 2019 07:56:53 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip X-NWS-UUID-VERIFY: 40b44cde9a93fe45425d19f3349c8db0 Vary: Accept-Encoding Set-Cookie: focus_mes_info=direct%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40%40null%40%40null%40%40null%40%40;Max-Age=1800;domain=focus.cn;path=/ Set-Cookie: focus_pc_city_p=jian;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: focus_city_p=jian;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: focus_city_c=360800;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: focus_city_s=jian;Max-Age=1296000;domain=focus.cn;path=/ Set-Cookie: pc_ad_feed=1;Max-Age=1296000;path=focus.cn Content-Language: en-US X-Daa-Tunnel: hop_count=2 X-NWS-LOG-UUID: c5fc7ae8-de55-4969-af64-c7fc9cd0f0ba  ,49804, 5
[1:7:0712/010349.132977:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010349.175428:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://jian.focus.cn/
[49705:49705:0712/010349.299061:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://jian.focus.cn/, https://jian.focus.cn/, 1
[49705:49705:0712/010349.299121:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://jian.focus.cn/, https://jian.focus.cn
[1:1:0712/010349.347275:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010349.396708:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/010349.463727:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010349.505546:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/010349.541029:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0712/010349.558351:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010349.601288:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010349.601588:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jian.focus.cn/"
[1:1:0712/010349.636600:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0712/010349.701052:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0712/010349.754149:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0712/010349.754579:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010349.830568:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0712/010349.885038:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0712/010350.031973:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010350.304084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7ff3449ee070 0x33ceb537d5e0 , "https://jian.focus.cn/"
[1:1:0712/010350.306641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , ,  !function(e,t,n,g,i){e[i]=e[i]||function(){(e[i].q=e[i].q||[]).push(arguments)},n=t.createElement("
[1:1:0712/010350.306875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010350.308881:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010350.318432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7ff3449ee070 0x33ceb537d5e0 , "https://jian.focus.cn/"
[1:1:0712/010350.333584:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7ff3449ee070 0x33ceb537d5e0 , "https://jian.focus.cn/"
[1:1:0712/010350.610869:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.293057, 116, 1
[1:1:0712/010350.611234:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010350.770886:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://jian.focus.cn/"
[1:1:0712/010350.773863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&a(+n.data.slice(t.length))}
[1:1:0712/010350.774158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/010351.788449:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010351.788767:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jian.focus.cn/"
[1:1:0712/010352.388524:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.599689, 4108, 0
[1:1:0712/010352.388843:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010354.008889:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010354.622987:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010354.623343:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jian.focus.cn/"
[1:1:0712/010354.978399:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.354918, 2814, 1
[1:1:0712/010354.978708:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010357.422390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7ff3469162e0 0x33ceb55216e0 , "https://jian.focus.cn/"
[1:1:0712/010357.426680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , try{!function(e,t,n,i){"use strict";function r(e){for(var t in e)k.has(e,t)&&(this[t]=e[t])}function
[1:1:0712/010357.426900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010358.535950:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010358.536425:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010358.536898:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010358.537293:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010358.539044:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[49705:49705:0712/010407.398456:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/010407.406600:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/010407.543076:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7ff3469162e0 0x33ceb55238e0 , "https://jian.focus.cn/"
[1:1:0712/010407.557559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , !function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var u="function"==typeof require&&require;if(
[1:1:0712/010407.557916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
		remove user.10_ec1f3cd7 -> 0
[1:1:0712/010411.212610:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010411.212904:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jian.focus.cn/"
[1:1:0712/010411.239359:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0263889, 158, 1
[1:1:0712/010411.239656:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010416.914363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/010416.914668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010418.210053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010418.210849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , r.onreadystatechange, (){if(4===r.readyState)if(200===r.status)i&&i(k.JSONDecode(r.responseText));else{var e="Bad HTTP sta
[1:1:0712/010418.211089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010418.211975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010418.214661:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010418.526695:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010418.527438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0712/010418.527753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010418.528713:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010418.979771:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010418.980084:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jian.focus.cn/"
[1:1:0712/010418.980911:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 731 0x7ff3449ee070 0x33ceb5514560 , "https://jian.focus.cn/"
[1:1:0712/010418.981737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , var _focus_pv_id = "focus.shengtai.all";
[1:1:0712/010418.981986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010418.990929:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 731 0x7ff3449ee070 0x33ceb5514560 , "https://jian.focus.cn/"
[49705:49705:0712/010419.168482:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/010419.170753:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x33ceb5f47e20
[1:1:0712/010419.171015:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[49705:49705:0712/010419.175858:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[49705:49705:0712/010419.216730:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://jian.focus.cn/, https://jian.focus.cn/, 4
[49705:49705:0712/010419.216904:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://jian.focus.cn/, https://jian.focus.cn
[1:1:0712/010419.234238:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2f66b81a29c8, 0x33ceb4c4a9a8
[1:1:0712/010419.234500:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 1000
[1:1:0712/010419.234946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 809
[1:1:0712/010419.235202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7ff3449ee070 0x33ceb5aa5560 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 731 0x7ff3449ee070 0x33ceb5514560 
[1:1:0712/010419.244768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 731 0x7ff3449ee070 0x33ceb5514560 , "https://jian.focus.cn/"
[1:1:0712/010419.399135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 731 0x7ff3449ee070 0x33ceb5514560 , "https://jian.focus.cn/"
[1:1:0712/010420.363630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , document.readyState
[1:1:0712/010420.364044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010424.042586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://jian.focus.cn/"
[1:1:0712/010424.043299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , n.onload, (){k.retCodeService("/pixel",!0,0,i)}
[1:1:0712/010424.043768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010424.692127:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/010424.692396:INFO:render_frame_impl.cc(7019)] 	 [url] = https://jian.focus.cn
[49705:49705:0712/010424.695660:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://jian.focus.cn/
[49705:49705:0712/010424.810042:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49705:49705:0712/010424.816140:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49705:49716:0712/010424.842417:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[49705:49716:0712/010424.842599:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[49705:49705:0712/010424.842771:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://zhibo-focus.sohu.com/
[49705:49705:0712/010424.842866:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://zhibo-focus.sohu.com/, https://zhibo-focus.sohu.com/xcookie.html?SUV, 4
[49705:49705:0712/010424.843035:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://zhibo-focus.sohu.com/, HTTP/1.1 200 OK Server: NWSs Date: Fri, 12 Jul 2019 07:58:16 GMT Cache-Control: max-age=600 Expires: Fri, 12 Jul 2019 08:08:16 GMT X-NWS-LOG-UUID: 4e39c130-f0c4-4969-8eff-5b42c007c575 X-Daa-Tunnel: hop_count=1 Content-Type: text/html Content-Length: 2087 Last-Modified: Tue, 04 Sep 2018 07:56:22 GMT Content-Encoding: gzip X-Cache-Lookup: Hit From Disktank3 Gz Accept-Ranges: bytes X-Cache-Lookup: Hit From Inner Cluster  ,49804, 5
[1:7:0712/010424.848840:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010425.317739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 809, 7ff347333881
[1:1:0712/010425.349896:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f02e5dc2860","ptid":"731 0x7ff3449ee070 0x33ceb5514560 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010425.350114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jian.focus.cn/","ptid":"731 0x7ff3449ee070 0x33ceb5514560 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010425.350367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jian.focus.cn/"
[1:1:0712/010425.350696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){i({},a);try{window.document.body.removeChild(d)}catch(e){}}
[1:1:0712/010425.350805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010425.403118:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2f66b81a29c8, 0x33ceb4c4a950
[1:1:0712/010425.403340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 1000
[1:1:0712/010425.403686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 888
[1:1:0712/010425.403875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7ff3449ee070 0x33ceb648bc60 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 809 0x7ff3449ee070 0x33ceb5aa5560 
[1:1:0712/010425.474992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , document.readyState
[1:1:0712/010425.475281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010427.453755:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 870 0x7ff344d56bd0 0x33ceb5784cd8 , "https://jian.focus.cn/"
[1:1:0712/010427.470571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , webpackJsonp([1,8],{0:function(e,t,n){n(159),n(160),n(161),n(163),e.exports=n(165)},159:function(e,t
[1:1:0712/010427.470763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "jian.focus.cn", 3, 1, , , 0
[1:1:0712/010427.612524:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010427.736509:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010427.736833:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010427.957716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 870 0x7ff344d56bd0 0x33ceb5784cd8 , "https://jian.focus.cn/"
[1:1:0712/010428.098956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 5000
[1:1:0712/010428.099441:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 919
[1:1:0712/010428.099705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7ff3449ee070 0x33ceb5cbec60 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 870 0x7ff344d56bd0 0x33ceb5784cd8 
[1:1:0712/010429.138742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010429.214381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 5000
[1:1:0712/010429.214704:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 930
[1:1:0712/010429.214863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 930 0x7ff3449ee070 0x33ceb5a76d60 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 870 0x7ff344d56bd0 0x33ceb5784cd8 
[1:1:0712/010429.265502:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f66b81a29c8, 0x33ceb4c4b0a8
[1:1:0712/010429.265777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 0
[1:1:0712/010429.266271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 931
[1:1:0712/010429.266520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7ff3449ee070 0x33ceb59d7260 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 870 0x7ff344d56bd0 0x33ceb5784cd8 
[1:1:0712/010429.341044:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 13
[1:1:0712/010429.341342:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 933
[1:1:0712/010429.341471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 933 0x7ff3449ee070 0x33ceb5a888e0 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 870 0x7ff344d56bd0 0x33ceb5784cd8 
[49705:49705:0712/010429.566372:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/010429.810533:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010430.100875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010430.296581:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "jian.focus.cn", "focus.cn"
[1:1:0712/010430.312945:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.36501, 0, 0
[1:1:0712/010430.313210:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010432.457592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , document.readyState
[1:1:0712/010432.457886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010432.598328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 888, 7ff347333881
[1:1:0712/010432.631021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f02e5dc2860","ptid":"809 0x7ff3449ee070 0x33ceb5aa5560 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010432.631408:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jian.focus.cn/","ptid":"809 0x7ff3449ee070 0x33ceb5aa5560 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010432.631864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jian.focus.cn/"
[1:1:0712/010432.632415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){r||(r=!0,t&&t(!1))}
[1:1:0712/010432.632645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010433.266621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.267385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , e.onreadystatechange, (){if(4==e.readyState)return 200==e.status?i(JSON.parse(e.responseText)):t._handleError("error",a)}
[1:1:0712/010433.267629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010433.272110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.401557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.402248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , e.onreadystatechange, (){if(4==e.readyState)return 200==e.status?i(JSON.parse(e.responseText)):t._handleError("error",a)}
[1:1:0712/010433.402465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010433.402963:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.405374:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.552019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.552702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , e.onreadystatechange, (){if(4==e.readyState)return 200==e.status?i(JSON.parse(e.responseText)):t._handleError("error",a)}
[1:1:0712/010433.552943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010433.553401:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.555868:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010433.784691:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010433.784965:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jian.focus.cn/"
[1:1:0712/010433.787578:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 947 0x7ff3449ee070 0x33ceb641a960 , "https://jian.focus.cn/"
[1:1:0712/010433.788940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , !function(n){function o(t){if(e[t])return e[t].exports;var i=e[t]={exports:{},id:t,loaded:!1};return
[1:1:0712/010433.789180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010433.909732:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 947 0x7ff3449ee070 0x33ceb641a960 , "https://jian.focus.cn/"
[1:1:0712/010433.976974:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://jian.focus.cn/"
[1:1:0712/010433.978468:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://jian.focus.cn/"
[1:1:0712/010434.001264:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x2f66b81a29c8, 0x33ceb4c4a9e0
[1:1:0712/010434.001569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 1500
[1:1:0712/010434.002029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 1013
[1:1:0712/010434.002305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7ff3449ee070 0x33ceb753b860 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 947 0x7ff3449ee070 0x33ceb641a960 
[1:1:0712/010434.008177:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://jian.focus.cn/"
[1:1:0712/010434.053696:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://jian.focus.cn/"
[1:1:0712/010434.580856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://jian.focus.cn/"
[1:1:0712/010435.489590:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "focus.cn", "focus.cn"
[1:1:0712/010435.956437:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010435.957168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , t, (n,o){var s,u,l,f,p;try{if(t&&(o||4===c.readyState))if(t=a,i&&(c.onreadystatechange=re.noop,Jt&&dele
[1:1:0712/010435.957388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010435.958576:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010435.960805:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010435.961509:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2a60a603c508
[1:1:0712/010436.159500:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 931, 7ff347333881
[1:1:0712/010436.208891:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f02e5dc2860","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010436.209362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jian.focus.cn/","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010436.209817:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jian.focus.cn/"
[1:1:0712/010436.210381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){Yt=a}
[1:1:0712/010436.210627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010436.212739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 933, 7ff3473338db
[1:1:0712/010436.262677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f02e5dc2860","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010436.263052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jian.focus.cn/","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010436.263523:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 1058
[1:1:0712/010436.263784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7ff3449ee070 0x33ceb75375e0 , 5:3_https://jian.focus.cn/, 0, , 933 0x7ff3449ee070 0x33ceb5a888e0 
[1:1:0712/010436.264262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jian.focus.cn/"
[1:1:0712/010436.264791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , re.fx.tick, (){var e,t=re.timers,n=0;for(Yt=re.now();n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.len
[1:1:0712/010436.265189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/010437.629169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , document.readyState
[1:1:0712/010437.629592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010437.684574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 986 0x7ff3469162e0 0x33ceb7568160 , "https://jian.focus.cn/"
[1:1:0712/010437.685561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , 
[1:1:0712/010437.685778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010437.686239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://jian.focus.cn/"
[1:1:0712/010437.736127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7ff3469162e0 0x33ceb753a3e0 , "https://jian.focus.cn/"
[1:1:0712/010437.737415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0712/010437.737640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010437.874697:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 990 0x7ff3469162e0 0x33ceb6520c60 , "https://jian.focus.cn/"
[1:1:0712/010437.875654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , document.write('<script charset="utf-8" src="https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js"></scri
[1:1:0712/010437.875920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[49705:49705:0712/010437.880941:INFO:CONSOLE(1)] "Failed to execute 'write' on 'Document': It isn't possible to write into a document from an asynchronously-loaded external script unless it is explicitly opened.", source: https://jspassport.ssl.qhimg.com/11.0.1.js?0f9a4c405bb4b8c85687f52b6e595997 (1)
[1:1:0712/010437.894717:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7ff3469162e0 0x33ceb4e68f60 , "https://jian.focus.cn/"
[1:1:0712/010437.895638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , /**/jsonp_1562918670259({"code":401,"msg":"用户未登录","errorCode":401,"errorMessage":"用户�
[1:1:0712/010437.895869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010437.947892:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010437.957488:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 919, 7ff3473338db
[1:1:0712/010438.004539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f02e5dc2860","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010438.004891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jian.focus.cn/","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010438.005322:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 1094
[1:1:0712/010438.005582:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1094 0x7ff3449ee070 0x33ceb76bd7e0 , 5:3_https://jian.focus.cn/, 0, , 919 0x7ff3449ee070 0x33ceb5cbec60 
[1:1:0712/010438.005952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jian.focus.cn/"
[1:1:0712/010438.006487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){t.$imgList.animate({top:"-35px"},"slow",function(){var e=t.$imgList.find(".hexin-item").eq(0).rem
[1:1:0712/010438.006699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010438.038088:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f66b81a29c8, 0x33ceb4c4a950
[1:1:0712/010438.038355:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jian.focus.cn/", 0
[1:1:0712/010438.038742:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 1095
[1:1:0712/010438.038986:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7ff3449ee070 0x33ceb7538d60 , 5:3_https://jian.focus.cn/, 1, -5:3_https://jian.focus.cn/, 919 0x7ff3449ee070 0x33ceb5cbec60 
[1:1:0712/010438.248315:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010438.249112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , e.onreadystatechange, (){if(4==e.readyState)return 200==e.status?i(JSON.parse(e.responseText)):t._handleError("error",a)}
[1:1:0712/010438.249343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010439.133963:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.134687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0712/010439.134909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010439.135633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.138068:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.203110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.204001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , t, (n,o){var s,u,l,f,p;try{if(t&&(o||4===c.readyState))if(t=a,i&&(c.onreadystatechange=re.noop,Jt&&dele
[1:1:0712/010439.204258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010439.204729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.207684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.208392:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2a60a603c508
[1:1:0712/010439.598083:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.598777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0712/010439.598966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010439.599335:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://jian.focus.cn/"
[1:1:0712/010439.903098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 930, 7ff3473338db
[1:1:0712/010439.949789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f02e5dc2860","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010439.950095:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jian.focus.cn/","ptid":"870 0x7ff344d56bd0 0x33ceb5784cd8 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010439.950500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jian.focus.cn/, 1155
[1:1:0712/010439.950687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1155 0x7ff3449ee070 0x33ceb56cc060 , 5:3_https://jian.focus.cn/, 0, , 930 0x7ff3449ee070 0x33ceb5a76d60 
[1:1:0712/010439.951027:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jian.focus.cn/"
[1:1:0712/010439.951508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){t.$imgList.animate({top:"-30px"},"slow",function(){var e=t.$imgList.find(".roll-item").eq(0).remo
[1:1:0712/010439.951678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
[1:1:0712/010440.032521:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jian.focus.cn/, 1013, 7ff347333881
[1:1:0712/010440.085284:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f02e5dc2860","ptid":"947 0x7ff3449ee070 0x33ceb641a960 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010440.085473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jian.focus.cn/","ptid":"947 0x7ff3449ee070 0x33ceb641a960 ","rf":"5:3_https://jian.focus.cn/"}
[1:1:0712/010440.085699:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jian.focus.cn/"
[1:1:0712/010440.086018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jian.focus.cn/, 2f02e5dc2860, , , (){return t.registerDomObserver()}
[1:1:0712/010440.086124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jian.focus.cn/", "focus.cn", 3, 1, , , 0
		remove user.11_40729784 -> 0
		remove user.12_ed2b612a -> 0
		remove user.13_7b5675bc -> 0
[1:1:0712/010450.353452:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010450.353872:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010450.354187:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
