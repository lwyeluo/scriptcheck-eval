[0712/063752.775103:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/063752.775992:INFO:switcher_clone.cc(787)] backtrace rip is 7f66c8779891
[0712/063753.941344:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/063753.941722:INFO:switcher_clone.cc(787)] backtrace rip is 7fefe1437891
[1:1:0712/063753.957930:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/063753.958427:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/063753.969396:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/063755.438002:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/063755.438399:INFO:switcher_clone.cc(787)] backtrace rip is 7f91306a7891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[93050:93050:0712/063755.602173:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[93083:93083:0712/063755.686207:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=93083
[93093:93093:0712/063755.687504:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=93093

DevTools listening on ws://127.0.0.1:9222/devtools/browser/85d88aa3-c206-4544-a38f-78c4d0d4a325
[93050:93050:0712/063756.197874:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[93050:93081:0712/063756.198882:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/063756.199169:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/063756.199511:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/063756.200362:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/063756.200514:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/063756.203437:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2c6a1f, 1
[1:1:0712/063756.203899:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x30d289a6, 0
[1:1:0712/063756.204127:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26a71437, 3
[1:1:0712/063756.204338:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26855d7a, 2
[1:1:0712/063756.204580:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa6ffffff89ffffffd230 1f6a2c00 7a5dffffff8526 3714ffffffa726 , 10104, 4
[1:1:0712/063756.205856:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[93050:93081:0712/063756.206147:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���0j,
[93050:93081:0712/063756.206235:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���0j,
[1:1:0712/063756.206126:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fefdf6720a0, 3
[1:1:0712/063756.206432:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fefdf7fd080, 2
[93050:93081:0712/063756.206659:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/063756.206624:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fefc94c0d20, -2
[93050:93081:0712/063756.206816:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 93103, 4, a689d230 1f6a2c00 7a5d8526 3714a726 
[1:1:0712/063756.232076:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/063756.233215:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26855d7a
[1:1:0712/063756.234169:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26855d7a
[1:1:0712/063756.235214:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26855d7a
[1:1:0712/063756.235737:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.235930:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.236029:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.236117:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.236358:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26855d7a
[1:1:0712/063756.236574:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fefe14377ba
[1:1:0712/063756.236652:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fefe142edef, 7fefe143777a, 7fefe14390cf
[1:1:0712/063756.238151:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26855d7a
[1:1:0712/063756.238310:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26855d7a
[1:1:0712/063756.238572:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26855d7a
[1:1:0712/063756.239269:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.239375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.239465:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.239556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26855d7a
[1:1:0712/063756.240020:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26855d7a
[1:1:0712/063756.240176:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fefe14377ba
[1:1:0712/063756.240259:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fefe142edef, 7fefe143777a, 7fefe14390cf
[1:1:0712/063756.246883:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/063756.247345:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/063756.247493:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffefb9c7fc8, 0x7ffefb9c7f48)
[1:1:0712/063756.262699:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/063756.269261:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[93050:93050:0712/063756.829624:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[93050:93050:0712/063756.831462:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[93050:93062:0712/063756.844048:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[93050:93050:0712/063756.844203:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[93050:93062:0712/063756.844175:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[93050:93050:0712/063756.844262:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[93050:93050:0712/063756.844362:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,93103, 4
[1:7:0712/063756.849189:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[93050:93074:0712/063756.894711:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/063757.020819:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x23e7e7205220
[1:1:0712/063757.021104:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/063757.403238:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[93050:93050:0712/063758.818717:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[93050:93050:0712/063758.818873:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/063758.864499:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063758.869364:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/063800.215264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35b14bf61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/063800.215606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/063800.235904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35b14bf61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/063800.236167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/063800.312505:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063800.623487:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063800.623781:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/063800.978114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/063800.986474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35b14bf61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/063800.986776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/063801.008953:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/063801.019516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35b14bf61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/063801.019777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/063801.023902:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/063801.028150:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x23e7e7203e20
[1:1:0712/063801.028381:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[93050:93050:0712/063801.029817:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[93050:93050:0712/063801.042880:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[93050:93050:0712/063801.070652:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[93050:93050:0712/063801.070951:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/063801.082617:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[93050:93050:0712/063801.100279:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/063802.189846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7fefcb09b2e0 0x23e7e7494b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/063802.191567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35b14bf61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/063802.191873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/063802.193416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[93050:93050:0712/063802.237857:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/063802.239894:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x23e7e7204820
[1:1:0712/063802.240173:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[93050:93050:0712/063802.248474:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/063802.259525:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/063802.259790:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[93050:93050:0712/063802.270397:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[93050:93050:0712/063802.285918:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[93050:93050:0712/063802.289013:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[93050:93062:0712/063802.296480:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[93050:93062:0712/063802.296579:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[93050:93050:0712/063802.296826:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[93050:93050:0712/063802.296924:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[93050:93050:0712/063802.297097:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,93103, 4
[1:7:0712/063802.310988:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/063802.955626:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[93050:93050:0712/063803.028043:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[93050:93081:0712/063803.028476:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/063803.028726:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/063803.029071:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/063803.029658:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/063803.029837:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/063803.033064:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2a1cd257, 1
[1:1:0712/063803.033449:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2267ab19, 0
[1:1:0712/063803.033660:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x56d70ae, 3
[1:1:0712/063803.033864:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xae177d1, 2
[1:1:0712/063803.034041:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 19ffffffab6722 57ffffffd21c2a ffffffd177ffffffe10a ffffffae706d05 , 10104, 5
[1:1:0712/063803.035009:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[93050:93081:0712/063803.035248:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�g"W�*�w�
�pm>
[93050:93081:0712/063803.035316:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �g"W�*�w�
�pmXf>
[1:1:0712/063803.035429:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fefdf6720a0, 3
[93050:93081:0712/063803.035607:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 93149, 5, 19ab6722 57d21c2a d177e10a ae706d05 
[1:1:0712/063803.035660:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fefdf7fd080, 2
[1:1:0712/063803.035844:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fefc94c0d20, -2
[1:1:0712/063803.053195:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/063803.053552:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ae177d1
[1:1:0712/063803.053879:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ae177d1
[1:1:0712/063803.054493:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ae177d1
[1:1:0712/063803.055938:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.056142:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.056331:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.056508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.057249:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ae177d1
[1:1:0712/063803.057537:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fefe14377ba
[1:1:0712/063803.057701:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fefe142edef, 7fefe143777a, 7fefe14390cf
[1:1:0712/063803.063456:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ae177d1
[1:1:0712/063803.063865:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ae177d1
[1:1:0712/063803.064623:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ae177d1
[1:1:0712/063803.066686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.066900:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.067087:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.067280:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ae177d1
[1:1:0712/063803.068551:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ae177d1
[1:1:0712/063803.068951:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fefe14377ba
[1:1:0712/063803.069114:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fefe142edef, 7fefe143777a, 7fefe14390cf
[1:1:0712/063803.076874:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/063803.077398:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/063803.077555:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffefb9c7fc8, 0x7ffefb9c7f48)
[1:1:0712/063803.091556:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/063803.095851:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/063803.302658:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 491 0x7fefcb09b2e0 0x23e7e759f2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/063803.303701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35b14bf61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/063803.303966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/063803.304759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/063803.323383:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x23e7e71c5220
[1:1:0712/063803.323661:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[93050:93050:0712/063803.354354:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[93050:93050:0712/063803.354458:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/063803.362861:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/063803.999940:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[93050:93050:0712/063804.143245:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[93050:93050:0712/063804.148435:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[93050:93062:0712/063804.163557:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[93050:93062:0712/063804.163660:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[93050:93050:0712/063804.164239:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.jmw.com.cn/
[93050:93050:0712/063804.164343:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.jmw.com.cn/, http://www.jmw.com.cn/category/putaojiu/, 1
[93050:93050:0712/063804.164513:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.jmw.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 13:38:04 GMT Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Server: waf/2.15.0-21.el6 Content-Encoding: gzip X-Via: 1.1 PSjsczBGPqr175:0 (Cdn Cache Server V2.0), 1.1 PSshzk2os163:6 (Cdn Cache Server V2.0), 1.1 hkuan177:6 (Cdn Cache Server V2.0)  ,93149, 5
[1:7:0712/063804.168799:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/063804.214148:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.jmw.com.cn/
[1:1:0712/063804.335759:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[93050:93050:0712/063804.366821:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.jmw.com.cn/, http://www.jmw.com.cn/, 1
[93050:93050:0712/063804.366965:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.jmw.com.cn/, http://www.jmw.com.cn
[1:1:0712/063804.384543:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063804.408113:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/063804.470577:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063804.470866:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063804.612816:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063804.613103:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/063804.637738:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/063804.956883:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063805.115526:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/063805.262459:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7fefdf7fd080 0x23e7e73364c0 1 0 0x23e7e73364d8 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063805.264480:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063805.268875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/063805.269130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063805.451698:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7fefdf7fd080 0x23e7e73364c0 1 0 0x23e7e73364d8 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063805.464688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7fefdf7fd080 0x23e7e73364c0 1 0 0x23e7e73364d8 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063805.570186:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7fefdf7fd080 0x23e7e73364c0 1 0 0x23e7e73364d8 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063805.628913:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.179042, 947, 1
[1:1:0712/063805.629208:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063805.859551:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/063806.135275:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063806.135982:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063806.136469:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063806.136923:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063806.137366:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063806.572531:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063806.572786:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063806.573641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fefc9173070 0x23e7e754a3e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063806.574769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , 
    $(
        function () {
            $.ajax({
                type:"get",
                url:"
[1:1:0712/063806.574976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063806.612511:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0396609, 243, 1
[1:1:0712/063806.612818:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063808.771296:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063808.771597:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063808.776064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 335 0x7fefc9173070 0x23e7e76991e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063808.777843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , /**
 * 展会倒计时
 * @param obj
 * @param type 1: 1200*90 2: 1200*80 3: 1200*45 4: 1200*45(�
[1:1:0712/063808.778032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063808.783276:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 335 0x7fefc9173070 0x23e7e76991e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063808.965257:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.19349, 1506, 1
[1:1:0712/063808.965448:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063812.212060:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063812.212265:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063812.212746:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7fefc9173070 0x23e7e79234e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063812.213495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , 
    window.NVC_Opt = {
        //无痕配置 && 滑动验证、刮刮卡通用配置
        appke
[1:1:0712/063812.213613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063812.215545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7fefc9173070 0x23e7e79234e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063812.228740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7fefc9173070 0x23e7e79234e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063812.237838:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0255382, 126, 1
[1:1:0712/063812.238002:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063814.395111:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063814.395936:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063814.397143:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 630 0x7fefc9173070 0x23e7e75299e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063814.398904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , 
                    $('.provinceArea .divCity').click(function(e){
                        e = wind
[1:1:0712/063814.399136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063814.439114:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0428751, 63, 1
[1:1:0712/063814.439413:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063814.858142:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 642 0x7fefcb09b2e0 0x23e7e73429e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063814.870916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , !function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var u="function"==typeof require&&require;if(
[1:1:0712/063814.871216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063815.333331:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 643 0x7fefcb09b2e0 0x23e7e74f9d60 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063815.334693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , jsonp_06177336938942517({"success":true,"result":{"success":true,"msg":"nvc","code":200,"result":{"c
[1:1:0712/063815.334948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063816.739495:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063816.739668:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063816.741265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7fefc9173070 0x23e7e77e0960 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063816.741979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , /**
lt
M站留言功能公共方法
*/
var mes_mobile = "";
var mes_content = "";
var mes_gend
[1:1:0712/063816.742091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063816.745406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7fefc9173070 0x23e7e77e0960 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063816.746931:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7fefc9173070 0x23e7e77e0960 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063817.199356:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.459753, 1957, 1
[1:1:0712/063817.199619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063818.226179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063818.227074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0712/063818.227201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063818.227702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063820.094026:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063820.094228:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063820.094668:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fefc9173070 0x23e7e74d2460 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063820.095258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , 
            //精选项目推荐
$('.jingMeng_zx .list li').click(function(){
    $(this).addClass(
[1:1:0712/063820.095372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063820.127380:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.033211, 155, 1
[1:1:0712/063820.127639:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/063820.212024:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 800 0x7fefcb09b2e0 0x23e7e74cbe60 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063820.212938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , /*! 12/19/2018, 4:23:17 PM */
!function(t){var e={};function n(o){if(e[o])return e[o].exports;var a=
[1:1:0712/063820.213055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063820.225839:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x21b2865e29c8, 0x23e7e704d1c0
[1:1:0712/063820.225998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 3000
[1:1:0712/063820.226225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 819
[1:1:0712/063820.226347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 819 0x7fefc9173070 0x23e7e74cbbe0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 800 0x7fefcb09b2e0 0x23e7e74cbe60 
[1:1:0712/063820.229596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x21b2865e29c8, 0x23e7e704d1c0
[1:1:0712/063820.229725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 3000
[1:1:0712/063820.229893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 820
[1:1:0712/063820.230003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 820 0x7fefc9173070 0x23e7e74f9fe0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 800 0x7fefcb09b2e0 0x23e7e74cbe60 
[1:1:0712/063820.844132:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063820.844325:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063820.844796:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 818 0x7fefc9173070 0x23e7e791d760 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063820.845760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , 
    function showGrade(tag)
    {
    if(tag == 1)
    {
    $('.ruzhu_dj').show();$('.grayBlack1')
[1:1:0712/063820.845879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063820.858880:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 818 0x7fefc9173070 0x23e7e791d760 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063822.734963:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 851 0x7fefcb09b2e0 0x23e7e7699b60 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063822.735645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , !function(t,a){var r=1e4,g_moduleConfig={uabModule:{stable:["AWSC/uab/117.js"],grey:["AWSC/uab/118.j
[1:1:0712/063822.735764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063822.740328:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063822.741615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d210
[1:1:0712/063822.741726:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063822.741934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 892
[1:1:0712/063822.742048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7fefc9173070 0x23e7e7341360 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 851 0x7fefcb09b2e0 0x23e7e7699b60 
[1:1:0712/063822.755333:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 852 0x7fefcb09b2e0 0x23e7e74f9960 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063822.756469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , /* 2018-01-17 14:18:05 */
!function(e){function t(r){if(n[r])return n[r].exports;var i=n[r]={exports
[1:1:0712/063822.756597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063822.784678:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063822.785146:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063822.786172:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:18:0712/063822.793123:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/063822.817099:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x21b2865e29c8, 0x23e7e704d218
[1:1:0712/063822.817308:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 1500
[1:1:0712/063822.817666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 901
[1:1:0712/063822.817876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7fefc9173070 0x23e7e72dd760 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 852 0x7fefcb09b2e0 0x23e7e74f9960 
[1:1:0712/063822.822702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 50
[1:1:0712/063822.823105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 902
[1:1:0712/063822.823294:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 902 0x7fefc9173070 0x23e7e765e560 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 852 0x7fefcb09b2e0 0x23e7e74f9960 
[1:20:0712/063824.833438:WARNING:paced_sender.cc(261)] Elapsed time (2010 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063825.336576:WARNING:paced_sender.cc(261)] Elapsed time (2513 ms) longer than expected, limiting to 2000 ms
[93050:93050:0712/063825.488785:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/063825.584357:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/063825.634622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063825.639748:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d210
[1:1:0712/063825.640000:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063825.640420:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 927
[1:1:0712/063825.640680:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 927 0x7fefc9173070 0x23e7e79b39e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 852 0x7fefcb09b2e0 0x23e7e74f9960 
[1:20:0712/063825.837708:WARNING:paced_sender.cc(261)] Elapsed time (3014 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063825.851571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 856 0x7fefcb09b2e0 0x23e7e74945e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063825.853217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , jQuery18308569025475511565_1562938685433({"6569446":{"content":"","money":0,"number":0,"is_full":0,"
[1:1:0712/063825.853485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063825.856158:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063825.933814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 857 0x7fefcb09b2e0 0x23e7e7517360 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063825.935173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , jQuery18308569025475511565_1562938685432({"6569446":{"address":"","num":4},"6595156":{"address":"","
[1:1:0712/063825.935413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063825.937004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:20:0712/063826.339187:WARNING:paced_sender.cc(261)] Elapsed time (3515 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063826.372603:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 866 0x7fefcb09b2e0 0x23e7e765e960 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063826.374040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , jQuery18308569025475511565_1562938685434({"6569446":{"certified":"http:\/\/image1.jmw.com.cn\/1831ic
[1:1:0712/063826.374270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063826.376359:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063826.513581:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 867 0x7fefcb09b2e0 0x23e7e74812e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063826.515240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , jQuery18308569025475511565_1562938685435({"6569446":"<span>\u5b9e\u5730\u8003\u5bdf\u9009\u5740<\/sp
[1:1:0712/063826.515533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063826.516773:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063826.626532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 871 0x7fefcb09b2e0 0x23e7e75c4e60 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063826.627998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , jQuery18308569025475511565_1562938685436({"6569446":["\u5b9e\u5730\u8003\u5bdf\u9009\u5740","\u603b\
[1:1:0712/063826.628222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063826.629553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063826.782837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 872 0x7fefcb09b2e0 0x23e7e76385e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063826.784731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , !function(e){function t(o){if(i[o])return i[o].exports;var r=i[o]={exports:{},id:o,loaded:!1};return
[1:1:0712/063826.784988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063826.840965:WARNING:paced_sender.cc(261)] Elapsed time (4017 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063827.342305:WARNING:paced_sender.cc(261)] Elapsed time (4518 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063827.371950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (e){if(r.setLocalDescription(e,function(){},function(){}),e.sdp){var t=e.sdp.split("\n");t.forEach(f
[1:1:0712/063827.372299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063827.514359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/063827.514728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063827.842539:WARNING:paced_sender.cc(261)] Elapsed time (5019 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063828.328304:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 892, 7fefcbab8881
[1:20:0712/063828.345359:WARNING:paced_sender.cc(261)] Elapsed time (5521 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063828.366073:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"851 0x7fefcb09b2e0 0x23e7e7699b60 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.366451:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"851 0x7fefcb09b2e0 0x23e7e7699b60 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.366816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063828.367485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){l(e,function(t){try{t(n)}catch(t){}})}
[1:1:0712/063828.368110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063828.414044:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 902, 7fefcbab88db
[1:1:0712/063828.447865:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"852 0x7fefcb09b2e0 0x23e7e74f9960 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.448252:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"852 0x7fefcb09b2e0 0x23e7e74f9960 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.448650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 986
[1:1:0712/063828.448884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7fefc9173070 0x23e7e8370260 , 5:3_http://www.jmw.com.cn/, 0, , 902 0x7fefc9173070 0x23e7e765e560 
[1:1:0712/063828.449210:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063828.449781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , o, (){var t=e();return t?(n(t),1):0}
[1:1:0712/063828.450015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063828.461398:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 819, 7fefcbab8881
[1:1:0712/063828.500205:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"800 0x7fefcb09b2e0 0x23e7e74cbe60 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.500801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"800 0x7fefcb09b2e0 0x23e7e74cbe60 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.501218:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063828.501872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){e.reject()}
[1:1:0712/063828.502088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063828.555275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 820, 7fefcbab8881
[1:1:0712/063828.599759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"800 0x7fefcb09b2e0 0x23e7e74cbe60 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.600122:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"800 0x7fefcb09b2e0 0x23e7e74cbe60 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.600446:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063828.600997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){e.reject()}
[1:1:0712/063828.601246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063828.646810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 901, 7fefcbab8881
[1:1:0712/063828.673797:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"852 0x7fefcb09b2e0 0x23e7e74f9960 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.674176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"852 0x7fefcb09b2e0 0x23e7e74f9960 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.674537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063828.675180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , o, (){return e.apply(this instanceof i?this:t,r.concat(n.call(arguments)))}
[1:1:0712/063828.675472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063828.685487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 927, 7fefcbab8881
[1:1:0712/063828.727909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"852 0x7fefcb09b2e0 0x23e7e74f9960 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.728268:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"852 0x7fefcb09b2e0 0x23e7e74f9960 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063828.728591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063828.729174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){l(e,function(t){try{t(n)}catch(t){}})}
[1:1:0712/063828.729408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063828.847492:WARNING:paced_sender.cc(261)] Elapsed time (6024 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063829.350628:WARNING:paced_sender.cc(261)] Elapsed time (6527 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063829.852757:WARNING:paced_sender.cc(261)] Elapsed time (7029 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063830.353633:WARNING:paced_sender.cc(261)] Elapsed time (7530 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063830.855007:WARNING:paced_sender.cc(261)] Elapsed time (8031 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063831.357148:WARNING:paced_sender.cc(261)] Elapsed time (8533 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063831.859272:WARNING:paced_sender.cc(261)] Elapsed time (9035 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063832.361419:WARNING:paced_sender.cc(261)] Elapsed time (9538 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063832.862620:WARNING:paced_sender.cc(261)] Elapsed time (10039 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063833.365706:WARNING:paced_sender.cc(261)] Elapsed time (10542 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063833.866685:WARNING:paced_sender.cc(261)] Elapsed time (11043 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063834.368925:WARNING:paced_sender.cc(261)] Elapsed time (11545 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063834.869878:WARNING:paced_sender.cc(261)] Elapsed time (12046 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063835.371775:WARNING:paced_sender.cc(261)] Elapsed time (12548 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063835.745214:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:20:0712/063835.873357:WARNING:paced_sender.cc(261)] Elapsed time (13049 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063836.375474:WARNING:paced_sender.cc(261)] Elapsed time (13552 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063836.877593:WARNING:paced_sender.cc(261)] Elapsed time (14054 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063837.378951:WARNING:paced_sender.cc(261)] Elapsed time (14555 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063837.881206:WARNING:paced_sender.cc(261)] Elapsed time (15057 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063838.383000:WARNING:paced_sender.cc(261)] Elapsed time (15559 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063838.883745:WARNING:paced_sender.cc(261)] Elapsed time (16060 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063839.386281:WARNING:paced_sender.cc(261)] Elapsed time (16562 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063839.888418:WARNING:paced_sender.cc(261)] Elapsed time (17065 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063840.389887:WARNING:paced_sender.cc(261)] Elapsed time (17566 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063840.817256:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063840.817498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 3000
[1:1:0712/063840.817909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1043
[1:1:0712/063840.818109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1043 0x7fefc9173070 0x23e7e8491de0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 927 0x7fefc9173070 0x23e7e79b39e0 
[1:1:0712/063840.834989:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063840.835177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 5000
[1:1:0712/063840.835366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1044
[1:1:0712/063840.835483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7fefc9173070 0x23e7ea341360 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 927 0x7fefc9173070 0x23e7e79b39e0 
[1:1:0712/063840.836050:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063840.836157:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 3000
[1:1:0712/063840.836321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1045
[1:1:0712/063840.836430:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7fefc9173070 0x23e7e7dbf360 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 927 0x7fefc9173070 0x23e7e79b39e0 
[1:1:0712/063840.846428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063840.846727:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 1000
[1:1:0712/063840.847236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1047
[1:1:0712/063840.847497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1047 0x7fefc9173070 0x23e7e83e9060 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 927 0x7fefc9173070 0x23e7e79b39e0 
[1:1:0712/063840.849370:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 50
[1:1:0712/063840.849560:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1048
[1:1:0712/063840.849716:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1048 0x7fefc9173070 0x23e7e84ef2e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 927 0x7fefc9173070 0x23e7e79b39e0 
[1:20:0712/063840.891699:WARNING:paced_sender.cc(261)] Elapsed time (18068 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063841.393845:WARNING:paced_sender.cc(261)] Elapsed time (18570 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063841.550965:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063841.551292:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063841.551933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1050
[1:1:0712/063841.552198:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1050 0x7fefc9173070 0x23e7e857bc60 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 927 0x7fefc9173070 0x23e7e79b39e0 
[1:20:0712/063841.894962:WARNING:paced_sender.cc(261)] Elapsed time (19071 ms) longer than expected, limiting to 2000 ms
[0712/063842.037840:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/063842.038458:INFO:switcher_clone.cc(787)] backtrace rip is 7fbaa5d7f891
[1:20:0712/063842.396119:WARNING:paced_sender.cc(261)] Elapsed time (19572 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063842.660556:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063842.696934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , /*! jQuery UI - v1.11.4 - 2015-03-11
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.js,
[1:1:0712/063842.697289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063842.898218:WARNING:paced_sender.cc(261)] Elapsed time (20074 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063843.400358:WARNING:paced_sender.cc(261)] Elapsed time (20576 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063843.901458:WARNING:paced_sender.cc(261)] Elapsed time (21078 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063843.967594:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063843.988762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063844.334455:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d1a0
[1:1:0712/063844.334716:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063844.335094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1082
[1:1:0712/063844.335288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1082 0x7fefc9173070 0x23e7eb2484e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 
[1:20:0712/063844.404597:WARNING:paced_sender.cc(261)] Elapsed time (21581 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063844.415669:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 13
[1:1:0712/063844.416272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1084
[1:1:0712/063844.416469:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7fefc9173070 0x23e7e8624660 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 
[1:1:0712/063844.900386:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.937762, 0, 0
[1:1:0712/063844.900560:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:20:0712/063844.906733:WARNING:paced_sender.cc(261)] Elapsed time (22083 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063844.953739:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 954 0x7fefcb09b2e0 0x23e7e74b0ce0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063844.955237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , !function(e){function t(o){if(i[o])return i[o].exports;var r=i[o]={exports:{},id:o,loaded:!1};return
[1:1:0712/063844.955473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063845.408867:WARNING:paced_sender.cc(261)] Elapsed time (22585 ms) longer than expected, limiting to 2000 ms
[1:18:0712/063845.742686:WARNING:stunport.cc(403)] Port[0x23e7e8822a20:data:1:0:local:Net[any:::/0:Unknown]]: StunPort: stun host lookup received error 0
[1:1:0712/063845.771141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){}
[1:1:0712/063845.771423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:18:0712/063845.833541:WARNING:p2ptransportchannel.cc(714)] Port[0x23e7e7531020:data:1:0:local:Net[any:0.0.0.0/0:Unknown]]: SetOption(5, 0) failed: 0
[1:18:0712/063845.834495:WARNING:p2ptransportchannel.cc(714)] Port[0x23e7e74d0420:data:1:0:local:Net[any:::/0:Unknown]]: SetOption(5, 0) failed: 0
[1:20:0712/063845.910995:WARNING:paced_sender.cc(261)] Elapsed time (23087 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063845.934540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , document.readyState
[1:1:0712/063845.934840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063846.413134:WARNING:paced_sender.cc(261)] Elapsed time (23589 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063846.915274:WARNING:paced_sender.cc(261)] Elapsed time (24091 ms) longer than expected, limiting to 2000 ms
[93050:93050:0712/063847.360659:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:20:0712/063847.416921:WARNING:paced_sender.cc(261)] Elapsed time (24593 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063847.789011:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://www.jmw.com.cn/category/images/new_search/dian2_62.png"
[1:20:0712/063847.918544:WARNING:paced_sender.cc(261)] Elapsed time (25095 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063848.420745:WARNING:paced_sender.cc(261)] Elapsed time (25597 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063848.921788:WARNING:paced_sender.cc(261)] Elapsed time (26098 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063849.423985:WARNING:paced_sender.cc(261)] Elapsed time (26600 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063849.925064:WARNING:paced_sender.cc(261)] Elapsed time (27101 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063849.937625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1048, 7fefcbab88db
[1:1:0712/063849.986841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063849.987120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063849.987370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1207
[1:1:0712/063849.987487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1207 0x7fefc9173070 0x23e7ebf45460 , 5:3_http://www.jmw.com.cn/, 0, , 1048 0x7fefc9173070 0x23e7e84ef2e0 
[1:1:0712/063849.987703:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063849.987993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , o, (){var t=e();return t?(n(t),1):0}
[1:1:0712/063849.988135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063849.988841:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1050, 7fefcbab8881
[1:1:0712/063850.005876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063850.006126:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063850.006434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063850.007037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){l(e,function(t){try{t(n)}catch(t){}})}
[1:1:0712/063850.007223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063850.178534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1047, 7fefcbab8881
[1:1:0712/063850.240579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063850.240973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063850.241439:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063850.242132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , o, (){return e.apply(this instanceof i?this:t,r.concat(n.call(arguments)))}
[1:1:0712/063850.242362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063850.354996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (t){var n=t.map(function(e){return e.deviceId});return n?void e.resolve(n.join(",")):void e.reject()
[1:1:0712/063850.355221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063850.426203:WARNING:paced_sender.cc(261)] Elapsed time (27602 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063850.927334:WARNING:paced_sender.cc(261)] Elapsed time (28103 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063851.397058:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1093 0x7fefcb09b2e0 0x23e7ebe4ab60 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063851.397621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , 

[1:1:0712/063851.397733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063851.397957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063851.417715:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063851.417878:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063851.419539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1094 0x7fefc9173070 0x23e7eaf235e0 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063851.420273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , $('.phonrLoad .li0').mouseover(function(){
	$('.reXian_boxwai').show();
});

$('.phonrLoad .li0'
[1:1:0712/063851.420429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063851.429506:WARNING:paced_sender.cc(261)] Elapsed time (28606 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063851.690302:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/063851.690811:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:20:0712/063851.932514:WARNING:paced_sender.cc(261)] Elapsed time (29109 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063852.434716:WARNING:paced_sender.cc(261)] Elapsed time (29611 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063852.936360:WARNING:paced_sender.cc(261)] Elapsed time (30112 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063852.973139:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 4000
[1:1:0712/063852.973409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1232
[1:1:0712/063852.973537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1232 0x7fefc9173070 0x23e7ebfaece0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1094 0x7fefc9173070 0x23e7eaf235e0 
[1:1:0712/063853.167461:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 50
[1:1:0712/063853.167948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1233
[1:1:0712/063853.168162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1233 0x7fefc9173070 0x23e7eb6579e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1094 0x7fefc9173070 0x23e7eaf235e0 
[1:1:0712/063853.359250:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.94147, 0, 0
[1:1:0712/063853.359574:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:20:0712/063853.437979:WARNING:paced_sender.cc(261)] Elapsed time (30614 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063853.637245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1043, 7fefcbab8881
[1:1:0712/063853.673108:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063853.673323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063853.673560:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063853.673888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){o.reject(i+": timeout")}
[1:1:0712/063853.674016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063853.674956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1045, 7fefcbab8881
[1:1:0712/063853.693889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063853.694107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063853.694314:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063853.694626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){o.reject(i+": timeout")}
[1:1:0712/063853.694731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063853.940118:WARNING:paced_sender.cc(261)] Elapsed time (31116 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063853.982464:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063853.982710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 5000
[1:1:0712/063853.983118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1240
[1:1:0712/063853.983330:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1240 0x7fefc9173070 0x23e7ebb32160 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1045 0x7fefc9173070 0x23e7e7dbf360 
[1:1:0712/063854.068593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1082, 7fefcbab8881
[1:1:0712/063854.088044:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063854.088315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063854.088555:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063854.088943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){qn=t}
[1:1:0712/063854.089059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063854.089690:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1084, 7fefcbab88db
[1:1:0712/063854.142157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063854.142487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"951 0x7fefdf7fd080 0x23e7e776d2e0 1 0 0x23e7e776d2f8 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063854.142914:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1244
[1:1:0712/063854.143132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1244 0x7fefc9173070 0x23e7ebf5c4e0 , 5:3_http://www.jmw.com.cn/, 0, , 1084 0x7fefc9173070 0x23e7e8624660 
[1:1:0712/063854.143486:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063854.144051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/063854.144295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063854.442237:WARNING:paced_sender.cc(261)] Elapsed time (31618 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063854.655456:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "icecandidate", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063854.656835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , r.onicecandidate, (e){e.candidate&&n(e.candidate.candidate)}
[1:1:0712/063854.657096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063854.692321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1044, 7fefcbab8881
[1:1:0712/063854.759100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063854.759482:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"927 0x7fefc9173070 0x23e7e79b39e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063854.759881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063854.760536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){o=-1,t.reject(),e()}
[1:1:0712/063854.760753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063854.811662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , document.readyState
[1:1:0712/063854.812033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063854.944406:WARNING:paced_sender.cc(261)] Elapsed time (32121 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063855.446519:WARNING:paced_sender.cc(261)] Elapsed time (32623 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063855.949658:WARNING:paced_sender.cc(261)] Elapsed time (33126 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063856.451294:WARNING:paced_sender.cc(261)] Elapsed time (33627 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063856.952925:WARNING:paced_sender.cc(261)] Elapsed time (34129 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063857.455062:WARNING:paced_sender.cc(261)] Elapsed time (34631 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063857.957193:WARNING:paced_sender.cc(261)] Elapsed time (35133 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063858.458325:WARNING:paced_sender.cc(261)] Elapsed time (35634 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063858.960467:WARNING:paced_sender.cc(261)] Elapsed time (36137 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063859.008853:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/063859.009146:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063859.014095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1234 0x7fefc9173070 0x23e7ebf71260 , "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063859.015980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , ,   var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-4873603-1']);
  _gaq.push(['_setDomainNam
[1:1:0712/063859.016219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063859.091551:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063859.402573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 1000
[1:1:0712/063859.403014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1335
[1:1:0712/063859.403226:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1335 0x7fefc9173070 0x23e7ec757060 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1234 0x7fefc9173070 0x23e7ebf71260 
[1:20:0712/063859.463417:WARNING:paced_sender.cc(261)] Elapsed time (36640 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063859.500136:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063859.520748:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x21b2865e29c8, 0x23e7e704d1e0
[1:1:0712/063859.520974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 1500
[1:1:0712/063859.521370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1340
[1:1:0712/063859.521613:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1340 0x7fefc9173070 0x23e7e841cd60 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1234 0x7fefc9173070 0x23e7ebf71260 
[1:1:0712/063859.528051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063859.534851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d1e0
[1:1:0712/063859.535098:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063859.535522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1342
[1:1:0712/063859.535740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1342 0x7fefc9173070 0x23e7e8575260 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1234 0x7fefc9173070 0x23e7ebf71260 
[1:1:0712/063859.537918:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d1e0
[1:1:0712/063859.538084:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063859.538439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1343
[1:1:0712/063859.538658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1343 0x7fefc9173070 0x23e7e841c0e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1234 0x7fefc9173070 0x23e7ebf71260 
[1:1:0712/063859.540889:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x21b2865e29c8, 0x23e7e704d1e0
[1:1:0712/063859.541124:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 3000
[1:1:0712/063859.541598:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1344
[1:1:0712/063859.541843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1344 0x7fefc9173070 0x23e7e841ec60 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1234 0x7fefc9173070 0x23e7ebf71260 
[1:1:0712/063859.752669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1233, 7fefcbab88db
[1:1:0712/063859.824158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1094 0x7fefc9173070 0x23e7eaf235e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063859.824553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1094 0x7fefc9173070 0x23e7eaf235e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063859.825123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1355
[1:1:0712/063859.825395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1355 0x7fefc9173070 0x23e7e83f96e0 , 5:3_http://www.jmw.com.cn/, 0, , 1233 0x7fefc9173070 0x23e7eb6579e0 
[1:1:0712/063859.825830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063859.826503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , zMarquee, (){ 
if(zjdemo.scrollTop>=zjdemo1.offsetHeight){
zjdemo.scrollTop=0; 
}
else{ 
zjdemo.scrollTop
[1:1:0712/063859.826753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063859.963711:WARNING:paced_sender.cc(261)] Elapsed time (37140 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063859.968799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063859.970166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , a, (){var e=i&&i.responseText;n(l(e||"{}"))}
[1:1:0712/063859.970414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063900.117725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , document.readyState
[1:1:0712/063900.118067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063900.465855:WARNING:paced_sender.cc(261)] Elapsed time (37642 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063900.683891:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1232, 7fefcbab88db
[1:1:0712/063900.744129:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1094 0x7fefc9173070 0x23e7eaf235e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063900.744489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1094 0x7fefc9173070 0x23e7eaf235e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063900.744948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1378
[1:1:0712/063900.745181:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1378 0x7fefc9173070 0x23e7e6f7fae0 , 5:3_http://www.jmw.com.cn/, 0, , 1232 0x7fefc9173070 0x23e7ebfaece0 
[1:1:0712/063900.745569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063900.746141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){w?p--:p++,ab()}
[1:1:0712/063900.746356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063900.802677:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063900.803006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063900.803454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1379
[1:1:0712/063900.803687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1379 0x7fefc9173070 0x23e7e83ae3e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1232 0x7fefc9173070 0x23e7ebfaece0 
[1:1:0712/063900.819226:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 13
[1:1:0712/063900.819681:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1380
[1:1:0712/063900.819982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1380 0x7fefc9173070 0x23e7ec755b60 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1232 0x7fefc9173070 0x23e7ebfaece0 
[1:20:0712/063900.967982:WARNING:paced_sender.cc(261)] Elapsed time (38144 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063901.327104:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1240, 7fefcbab8881
[1:1:0712/063901.365634:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1045 0x7fefc9173070 0x23e7e7dbf360 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063901.365998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1045 0x7fefc9173070 0x23e7e7dbf360 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063901.366411:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063901.366996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , o, (){return e.apply(this instanceof i?this:t,r.concat(n.call(arguments)))}
[1:1:0712/063901.367241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063901.440116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "scroll", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063901.440886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (t){return window.vds.impCtrlDua?window.grImpCtrl=Date.now():void 0}
[1:1:0712/063901.441144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063901.470139:WARNING:paced_sender.cc(261)] Elapsed time (38646 ms) longer than expected, limiting to 2000 ms
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:20:0712/063901.972265:WARNING:paced_sender.cc(261)] Elapsed time (39148 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063902.472275:WARNING:paced_sender.cc(261)] Elapsed time (39648 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063902.726338:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063902.727058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0712/063902.727239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063902.728014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063902.730530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063902.943887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1342, 7fefcbab8881
[1:20:0712/063902.973182:WARNING:paced_sender.cc(261)] Elapsed time (40149 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063902.982862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063902.983051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063902.983277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063902.983615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){l(e,function(t){try{t(n)}catch(t){}})}
[1:1:0712/063902.983725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063902.984846:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063902.984956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063902.985132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1452
[1:1:0712/063902.985241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1452 0x7fefc9173070 0x23e7e851f2e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1342 0x7fefc9173070 0x23e7e8575260 
[1:1:0712/063902.985754:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1343, 7fefcbab8881
[1:1:0712/063903.045900:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.046226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.046628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063903.047220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){l(e,function(t){try{t(n)}catch(t){}})}
[1:1:0712/063903.047404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063903.049908:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063903.050086:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063903.050480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1453
[1:1:0712/063903.050679:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7fefc9173070 0x23e7eb972d60 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1343 0x7fefc9173070 0x23e7e841c0e0 
[1:1:0712/063903.051903:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063903.052067:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063903.052421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1454
[1:1:0712/063903.052639:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1454 0x7fefc9173070 0x23e7e80cf7e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1343 0x7fefc9173070 0x23e7e841c0e0 
[1:1:0712/063903.225291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1355, 7fefcbab88db
[1:1:0712/063903.287961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1233 0x7fefc9173070 0x23e7eb6579e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.288239:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1233 0x7fefc9173070 0x23e7eb6579e0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.288685:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1460
[1:1:0712/063903.288883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1460 0x7fefc9173070 0x23e7e83ffe60 , 5:3_http://www.jmw.com.cn/, 0, , 1355 0x7fefc9173070 0x23e7e83f96e0 
[1:1:0712/063903.289230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063903.289827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , zMarquee, (){ 
if(zjdemo.scrollTop>=zjdemo1.offsetHeight){
zjdemo.scrollTop=0; 
}
else{ 
zjdemo.scrollTop
[1:1:0712/063903.290034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063903.473636:WARNING:paced_sender.cc(261)] Elapsed time (40650 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063903.672044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , document.readyState
[1:1:0712/063903.672291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063903.772885:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1335, 7fefcbab88db
[1:1:0712/063903.794273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.794473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.794755:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1470
[1:1:0712/063903.794876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1470 0x7fefc9173070 0x23e7ebf778e0 , 5:3_http://www.jmw.com.cn/, 0, , 1335 0x7fefc9173070 0x23e7ec757060 
[1:1:0712/063903.795074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063903.795398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , () {
			if(sys_second >= 1) {
				sys_second -= 1;
				var day = Math.floor((sys_second / 3600) / 24
[1:1:0712/063903.795530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063903.894264:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1379, 7fefcbab8881
[1:1:0712/063903.956950:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1232 0x7fefc9173070 0x23e7ebfaece0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.957321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1232 0x7fefc9173070 0x23e7ebfaece0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063903.957694:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063903.958252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){qn=t}
[1:1:0712/063903.958425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:20:0712/063903.975783:WARNING:paced_sender.cc(261)] Elapsed time (41152 ms) longer than expected, limiting to 2000 ms
[1:1:0712/063904.082611:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1380, 7fefcbab88db
[1:1:0712/063904.144857:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1232 0x7fefc9173070 0x23e7ebfaece0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063904.145161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1232 0x7fefc9173070 0x23e7ebfaece0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063904.145572:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1475
[1:1:0712/063904.145785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1475 0x7fefc9173070 0x23e7ec757be0 , 5:3_http://www.jmw.com.cn/, 0, , 1380 0x7fefc9173070 0x23e7ec755b60 
[1:1:0712/063904.146120:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063904.146635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/063904.146820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063904.159049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1378, 7fefcbab88db
[1:1:0712/063904.208592:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1232 0x7fefc9173070 0x23e7ebfaece0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063904.208809:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1232 0x7fefc9173070 0x23e7ebfaece0 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063904.209034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1477
[1:1:0712/063904.209147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1477 0x7fefc9173070 0x23e7e84a20e0 , 5:3_http://www.jmw.com.cn/, 0, , 1378 0x7fefc9173070 0x23e7e6f7fae0 
[1:1:0712/063904.209332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063904.209621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){w?p--:p++,ab()}
[1:1:0712/063904.209725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
[1:1:0712/063904.235762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21b2865e29c8, 0x23e7e704d150
[1:1:0712/063904.236067:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 0
[1:1:0712/063904.236551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1478
[1:1:0712/063904.236821:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1478 0x7fefc9173070 0x23e7ebfb66e0 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1378 0x7fefc9173070 0x23e7e6f7fae0 
[1:1:0712/063904.283719:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jmw.com.cn/category/putaojiu/", 13
[1:1:0712/063904.284235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.jmw.com.cn/, 1480
[1:1:0712/063904.284426:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1480 0x7fefc9173070 0x23e7e837e660 , 5:3_http://www.jmw.com.cn/, 1, -5:3_http://www.jmw.com.cn/, 1378 0x7fefc9173070 0x23e7e6f7fae0 
[1:1:0712/063904.307283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jmw.com.cn/, 1340, 7fefcbab8881
[1:1:0712/063904.354582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"358bab5e2860","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063904.354917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jmw.com.cn/","ptid":"1234 0x7fefc9173070 0x23e7ebf71260 ","rf":"5:3_http://www.jmw.com.cn/"}
[1:1:0712/063904.355319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jmw.com.cn/category/putaojiu/"
[1:1:0712/063904.355908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jmw.com.cn/, 358bab5e2860, , , (){return t.registerDomObserver()}
[1:1:0712/063904.356092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jmw.com.cn/category/putaojiu/", "www.jmw.com.cn", 3, 1, , , 0
		remove user.16_be6a2b67 -> 0
		remove user.17_b1da4dc6 -> 0
		remove user.18_377e5b86 -> 0
[1:20:0712/063904.476921:WARNING:paced_sender.cc(261)] Elapsed time (41653 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063904.979035:WARNING:paced_sender.cc(261)] Elapsed time (42155 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063905.480749:WARNING:paced_sender.cc(261)] Elapsed time (42657 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063905.983297:WARNING:paced_sender.cc(261)] Elapsed time (43159 ms) longer than expected, limiting to 2000 ms
[1:20:0712/063906.485440:WARNING:paced_sender.cc(261)] Elapsed time (43662 ms) longer than expected, limiting to 2000 ms
