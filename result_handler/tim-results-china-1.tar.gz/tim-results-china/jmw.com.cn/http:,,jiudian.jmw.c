[0712/062638.516874:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/062638.517142:INFO:switcher_clone.cc(787)] backtrace rip is 7f7f0e3ca891
[0712/062639.545945:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/062639.546187:INFO:switcher_clone.cc(787)] backtrace rip is 7f968e007891
[1:1:0712/062639.550302:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/062639.550477:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/062639.555262:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[91518:91518:0712/062641.109172:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/062641.142382:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/062641.142682:INFO:switcher_clone.cc(787)] backtrace rip is 7f6033f59891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/37627fd6-33d8-4d3d-ae90-0468bf1c226d
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[91551:91551:0712/062641.380793:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=91551
[91563:91563:0712/062641.381265:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=91563
[91518:91518:0712/062641.695757:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[91518:91549:0712/062641.696315:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/062641.696587:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/062641.696986:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/062641.698176:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/062641.698496:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/062641.703247:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3055887a, 1
[1:1:0712/062641.703579:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x16de504e, 0
[1:1:0712/062641.703740:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x130c38bb, 3
[1:1:0712/062641.703902:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26458319, 2
[1:1:0712/062641.704102:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4e50ffffffde16 7affffff885530 19ffffff834526 ffffffbb380c13 , 10104, 4
[1:1:0712/062641.705074:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[91518:91549:0712/062641.705319:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGNP�z�U0�E&�8�a�8
[91518:91549:0712/062641.705386:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is NP�z�U0�E&�8���a�8
[1:1:0712/062641.705306:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f968c2420a0, 3
[1:1:0712/062641.705524:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f968c3cd080, 2
[91518:91549:0712/062641.705854:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/062641.705836:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9676090d20, -2
[91518:91549:0712/062641.705923:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 91571, 4, 4e50de16 7a885530 19834526 bb380c13 
[1:1:0712/062641.724668:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/062641.725517:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26458319
[1:1:0712/062641.726468:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26458319
[1:1:0712/062641.728068:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26458319
[1:1:0712/062641.729593:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.729814:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.730001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.730206:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.730858:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26458319
[1:1:0712/062641.731176:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f968e0077ba
[1:1:0712/062641.731324:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f968dffedef, 7f968e00777a, 7f968e0090cf
[1:1:0712/062641.736961:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26458319
[1:1:0712/062641.737327:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26458319
[1:1:0712/062641.738049:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26458319
[1:1:0712/062641.740048:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.740272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.740458:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.740643:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26458319
[1:1:0712/062641.741865:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26458319
[1:1:0712/062641.742238:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f968e0077ba
[1:1:0712/062641.742401:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f968dffedef, 7f968e00777a, 7f968e0090cf
[1:1:0712/062641.750067:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/062641.750501:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/062641.750646:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffeae4f588, 0x7fffeae4f508)
[1:1:0712/062641.766144:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/062641.771935:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[91518:91518:0712/062642.414038:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[91518:91518:0712/062642.415631:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[91518:91530:0712/062642.425728:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[91518:91530:0712/062642.425846:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[91518:91518:0712/062642.426033:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[91518:91518:0712/062642.426112:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[91518:91518:0712/062642.426670:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,91571, 4
[1:7:0712/062642.433427:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[91518:91543:0712/062642.493017:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/062642.562780:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x278ddac7c220
[1:1:0712/062642.563059:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/062642.822322:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[91518:91518:0712/062644.350481:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[91518:91518:0712/062644.350604:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/062644.402158:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062644.405376:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/062645.530796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28394cda1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/062645.531382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/062645.573228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28394cda1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/062645.573721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/062645.617129:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/062645.783979:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/062645.784431:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/062646.252067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/062646.265942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28394cda1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/062646.266389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/062646.320001:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/062646.323205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28394cda1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/062646.323479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/062646.335312:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[91518:91518:0712/062646.337712:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/062646.338928:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x278ddac7ae20
[1:1:0712/062646.339474:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[91518:91518:0712/062646.345199:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[91518:91518:0712/062646.374842:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[91518:91518:0712/062646.374998:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/062646.437948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/062647.344289:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f9677c6b2e0 0x278ddad9d360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/062647.345685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28394cda1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/062647.345896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/062647.347343:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[91518:91518:0712/062647.409091:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/062647.409379:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x278ddac7b820
[1:1:0712/062647.409812:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/062647.433251:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/062647.433509:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[91518:91518:0712/062647.443034:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[91518:91518:0712/062647.473225:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[91518:91518:0712/062647.480867:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[91518:91518:0712/062647.481859:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[91518:91530:0712/062647.490546:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[91518:91518:0712/062647.491157:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[91518:91530:0712/062647.491635:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[91518:91518:0712/062647.491719:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[91518:91518:0712/062647.491984:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,91571, 4
[1:7:0712/062647.496018:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/062648.008043:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/062648.369079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f9677c6b2e0 0x278ddaf451e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/062648.370081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 28394cda1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/062648.370278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/062648.371012:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[91518:91518:0712/062648.797712:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[91518:91518:0712/062648.797819:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/062648.810795:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[91518:91518:0712/062649.226936:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[91518:91549:0712/062649.227354:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/062649.227547:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/062649.227758:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/062649.228200:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/062649.228345:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/062649.231433:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x310b773e, 1
[1:1:0712/062649.231828:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xa14c57f, 0
[1:1:0712/062649.232062:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3bc91f05, 3
[1:1:0712/062649.232288:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x34130b55, 2
[1:1:0712/062649.232467:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7fffffffc5140a 3e770b31 550b1334 051fffffffc93b , 10104, 5
[1:1:0712/062649.233523:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[91518:91549:0712/062649.233800:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�
>w1U4�;xc�8
[91518:91549:0712/062649.233875:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �
>w1U4�;�=xc�8
[1:1:0712/062649.233888:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f968c2420a0, 3
[91518:91549:0712/062649.234230:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 91616, 5, 7fc5140a 3e770b31 550b1334 051fc93b 
[1:1:0712/062649.234155:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f968c3cd080, 2
[1:1:0712/062649.234716:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9676090d20, -2
[1:1:0712/062649.254273:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/062649.254629:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34130b55
[1:1:0712/062649.255039:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34130b55
[1:1:0712/062649.255730:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34130b55
[1:1:0712/062649.257273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.257507:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.257733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.257958:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.258695:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34130b55
[1:1:0712/062649.259054:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f968e0077ba
[1:1:0712/062649.259238:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f968dffedef, 7f968e00777a, 7f968e0090cf
[1:1:0712/062649.265131:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34130b55
[1:1:0712/062649.265543:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34130b55
[1:1:0712/062649.266373:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34130b55
[1:1:0712/062649.268605:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.268876:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.269115:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.269364:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34130b55
[1:1:0712/062649.270732:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34130b55
[1:1:0712/062649.271195:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f968e0077ba
[1:1:0712/062649.271401:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f968dffedef, 7f968e00777a, 7f968e0090cf
[1:1:0712/062649.279723:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/062649.280256:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/062649.280463:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffeae4f588, 0x7fffeae4f508)
[1:1:0712/062649.285807:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/062649.295422:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/062649.300348:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/062649.450408:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x278ddac58220
[1:1:0712/062649.450699:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/062649.949706:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/062649.950040:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[91518:91518:0712/062650.070883:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[91518:91518:0712/062650.076527:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[91518:91530:0712/062650.105816:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[91518:91530:0712/062650.105918:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[91518:91518:0712/062650.106428:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://jiudian.jmw.com.cn/
[91518:91518:0712/062650.106536:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://jiudian.jmw.com.cn/, http://jiudian.jmw.com.cn/jd_xmpd/17580346.html, 1
[91518:91518:0712/062650.106708:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://jiudian.jmw.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 13:26:49 GMT Server: waf/2.15.0-21.el6 Content-Type: text/html Transfer-Encoding: chunked Last-Modified: Tue, 11 Jun 2019 03:33:35 GMT ETag: W/"1fa5b8f-15a6f-58b03f62f21c0" Set-Cookie: _Jo0OQK=6BCA4218027E76FDE6CA4A0BDA0203F73DF93D7CB0BB038FD1731A26C4DD4D324675909BB65CD36DCE875B1EEF8FE33BAE3B2EFC74A9A66FCDADB55F3DF767FE30047FA188EE3E66C860EC912722D7E13D10EC912722D7E13D165F0A235487C483EGJ1Z1UQ==; path=/; expires=Sat, 13-Jul-19 13:26:49 GMT Cache-Control: no-store Content-Encoding: gzip X-Via: 1.1 wj85:3 (Cdn Cache Server V2.0), 1.1 bj170:4 (Cdn Cache Server V2.0) Connection: keep-alive  ,91616, 5
[1:7:0712/062650.110757:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/062650.147127:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://jiudian.jmw.com.cn/
[91518:91518:0712/062650.226831:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://jiudian.jmw.com.cn/, http://jiudian.jmw.com.cn/, 1
[91518:91518:0712/062650.226892:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://jiudian.jmw.com.cn/, http://jiudian.jmw.com.cn
[1:1:0712/062650.289343:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/062650.411004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/062650.414764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 28394ced09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/062650.415071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/062650.418974:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/062650.450628:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/062650.497420:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/062650.545431:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/062650.545681:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062650.636173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 120 0x7f9675d43070 0x278ddad30e60 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062650.638866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , 
        var sqcatid = '147';
        var projectId='208543';
        var cat_id = '2561';
        f
[1:1:0712/062650.639122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062651.050936:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150, "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.051866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , 
[1:1:0712/062651.052130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062651.058051:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150, "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.081881:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062651.089062:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad39c0
[1:1:0712/062651.089282:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062651.089791:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 173
[1:1:0712/062651.090021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 173 0x7f9675d43070 0x278ddac5c8e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 150
[1:1:0712/062651.108297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150, "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.183757:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062651.365966:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 173, 7f9678688881
[1:1:0712/062651.370237:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"150","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062651.370512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"150","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062651.370822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.371462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062651.371684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062651.372430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062651.372641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062651.373057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 200
[1:1:0712/062651.373279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 200 0x7f9675d43070 0x278ddace2ce0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 173 0x7f9675d43070 0x278ddac5c8e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/062651.451623:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 200, 7f9678688881
[1:1:0712/062651.461125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"173 0x7f9675d43070 0x278ddac5c8e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062651.461449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"173 0x7f9675d43070 0x278ddac5c8e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062651.461769:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.462403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062651.462648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062651.463377:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062651.463603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062651.464066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 208
[1:1:0712/062651.464302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 208 0x7f9675d43070 0x278ddae2a060 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 200 0x7f9675d43070 0x278ddace2ce0 
[1:1:0712/062651.499387:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7f96760abbd0 0x278ddae2a658 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.519771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/062651.520095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062651.681824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7f96760abbd0 0x278ddae2a658 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.691350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7f96760abbd0 0x278ddae2a658 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.798620:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062651.799174:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062651.802114:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062651.802501:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062651.803053:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062651.918193:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.240692, 1305, 1
[1:1:0712/062651.918441:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/062651.952385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 208, 7f9678688881
[1:1:0712/062651.961723:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"200 0x7f9675d43070 0x278ddace2ce0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062651.962025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"200 0x7f9675d43070 0x278ddace2ce0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062651.962302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062651.962937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062651.963152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062651.963816:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062651.964008:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062651.964422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 283
[1:1:0712/062651.964645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 283 0x7f9675d43070 0x278ddaead4e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 208 0x7f9675d43070 0x278ddae2a060 
[1:1:0712/062652.563193:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/062652.563442:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062652.570988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 273 0x7f9675d43070 0x278ddb094de0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062652.603031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/062652.603306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062652.822032:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 273 0x7f9675d43070 0x278ddb094de0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062653.056586:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.493109, 511, 1
[1:1:0712/062653.056938:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/062653.241337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 283, 7f9678688881
[1:1:0712/062653.255770:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"208 0x7f9675d43070 0x278ddae2a060 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062653.256129:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"208 0x7f9675d43070 0x278ddae2a060 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062653.256456:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062653.257113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062653.257326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062653.257944:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062653.258153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062653.258675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 342
[1:1:0712/062653.258918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 342 0x7f9675d43070 0x278ddae28ee0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 283 0x7f9675d43070 0x278ddaead4e0 
[1:1:0712/062654.101195:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/062654.101456:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.105448:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 330 0x7f9675d43070 0x278ddb1a6ee0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.111941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , /*!
 * SuperSlide v2.1.1 
 * 轻松解决网站大部分特效展示问题
 * 详尽信息请看�
[1:1:0712/062654.112147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062654.122113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 330 0x7f9675d43070 0x278ddb1a6ee0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.124574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 330 0x7f9675d43070 0x278ddb1a6ee0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.247834:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 342, 7f9678688881
[1:1:0712/062654.269697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"283 0x7f9675d43070 0x278ddaead4e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062654.270044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"283 0x7f9675d43070 0x278ddaead4e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062654.270389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.271121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062654.271351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062654.272159:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062654.272374:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062654.272845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 425
[1:1:0712/062654.273074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 425 0x7f9675d43070 0x278ddadddae0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 342 0x7f9675d43070 0x278ddae28ee0 
[1:1:0712/062654.742450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 383 0x7f9677c6b2e0 0x278ddb088c60 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.743909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , try {
    (function(a,b,c,d){
    a[c]=function(){a[c]['ar']=a[c]['ar']||[];a[c]['ar'].push(argume
[1:1:0712/062654.744171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062654.802919:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f9677c6b2e0 0x278ddaeb1460 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.806346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (function(){if(window._mvq&&!(window._mvq instanceof Array)){return}var c=window._mv_loader={};c._cm
[1:1:0712/062654.806605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062654.874299:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7f9677c6b2e0 0x278dda6511e0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.875410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , function getLinkTrack(sq_hyid)
{
	var from_url = encodeURIComponent(window.location.href);
	// fr
[1:1:0712/062654.875615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062654.898457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7f9677c6b2e0 0x278ddb0863e0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.899702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/062654.899885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062654.964892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389 0x7f9677c6b2e0 0x278ddae6ec60 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062654.965791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012762(0)
[1:1:0712/062654.965975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062654.966785:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062655.006918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f9677c6b2e0 0x278ddb0889e0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062655.007764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012761(0)
[1:1:0712/062655.007963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062655.008644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062655.067791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f9677c6b2e0 0x278ddb07e660 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062655.070369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (function(){var E;var g=window,n=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0712/062655.070504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062658.103885:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7f9677c6b2e0 0x278ddaead460 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062658.115710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , !function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var u="function"==typeof require&&require;if(
[1:1:0712/062658.115996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062659.081321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f9677c6b2e0 0x278ddadb08e0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062659.086102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (function(){var h={},mt={},c={id:"a106c437d4a312c39ce75b83f27c57aa",dm:["jmw.com.cn"],js:"tongji.bai
[1:1:0712/062659.086344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062659.120002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3990
[1:1:0712/062659.120268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062659.120728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 549
[1:1:0712/062659.120961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 549 0x7f9675d43070 0x278ddaea4ee0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 419 0x7f9677c6b2e0 0x278ddadb08e0 
[91518:91518:0712/062716.226689:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/062716.268401:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/062716.706971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 425, 7f9678688881
[1:1:0712/062716.734284:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"342 0x7f9675d43070 0x278ddae28ee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062716.734697:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"342 0x7f9675d43070 0x278ddae28ee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062716.735010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062716.735690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062716.736032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062716.736837:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062716.737071:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062716.737450:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 610
[1:1:0712/062716.737682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f9675d43070 0x278ddb424ee0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 425 0x7f9675d43070 0x278ddadddae0 
[91518:91518:0712/062717.354746:INFO:CONSOLE(30)] "Failed to execute 'write' on 'Document': It isn't possible to write into a document from an asynchronously-loaded external script unless it is explicitly opened.", source: https://hm.baidu.com/h.js?a106c437d4a312c39ce75b83f27c57aa (30)
[1:1:0712/062719.452147:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544 0x7f9677c6b2e0 0x278ddaeac660 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062719.462504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , !function(){var a=window.mediav||{};window.mediav=a,a.paramFilter=function(a,b,c){var d,e,f;if(docum
[1:1:0712/062719.462773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062719.477230:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062719.477754:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/062719.587893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545 0x7f9677c6b2e0 0x278ddb057ee0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062719.591959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , var $mvt=new Object({A:"1.4.13.5",r:undefined,X:"length",hI:document,x:{},hO:"_mvq",z:function(a,b){
[1:1:0712/062719.592249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062720.016061:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062720.016513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0712/062720.016650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062720.017103:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062720.032200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/062720.032391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062721.090813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 549, 7f9678688881
[1:1:0712/062721.115795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"419 0x7f9677c6b2e0 0x278ddadb08e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062721.116227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"419 0x7f9677c6b2e0 0x278ddadb08e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062721.116734:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062721.117366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);l="undefined"==typeof b?u
[1:1:0712/062721.117611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062721.118522:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062721.118731:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062721.119154:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 731
[1:1:0712/062721.119381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7f9675d43070 0x278ddad2cc60 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 549 0x7f9675d43070 0x278ddaea4ee0 
[1:1:0712/062721.415137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 610, 7f9678688881
[1:1:0712/062721.447316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"425 0x7f9675d43070 0x278ddadddae0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062721.447718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"425 0x7f9675d43070 0x278ddadddae0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062721.448171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062721.448913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062721.449153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062721.449808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062721.450008:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062721.450431:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 748
[1:1:0712/062721.450728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f9675d43070 0x278ddc06fd60 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 610 0x7f9675d43070 0x278ddb424ee0 
[1:1:0712/062721.809288:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 625 0x7f9677c6b2e0 0x278dda6d8fe0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062721.810244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , 
[1:1:0712/062721.810463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062721.857680:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626 0x7f9677c6b2e0 0x278ddae2bbe0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062721.863113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window.lxb=window.lxb||{};lxb.instance=lxb.instance||0;lxb.instance++;(function(){var a={};lxb.add=l
[1:1:0712/062721.863447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062722.015567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 628 0x7f9677c6b2e0 0x278ddb26b460 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062722.019596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , /*! ag_track 2018-08-14 */

!function(a,b){function c(a,b,c,d){var e,f,g,h,i,j,k,m,o,p;if((b?b.owner
[1:1:0712/062722.019923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062722.073363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 20000
[1:1:0712/062722.073909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 771
[1:1:0712/062722.074168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 771 0x7f9675d43070 0x278ddbfd0960 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 628 0x7f9677c6b2e0 0x278ddb26b460 
[1:1:0712/062724.680939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , document.readyState
[1:1:0712/062724.681276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062725.312998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 737 0x7f9677c6b2e0 0x278ddbff6060 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062725.314023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jsonp15629380395598433("1")
[1:1:0712/062725.314515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062725.412516:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738 0x7f9677c6b2e0 0x278ddc04a560 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062725.413531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jsonp15629380397574448("1")
[1:1:0712/062725.413856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062725.429327:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 731, 7f9678688881
[1:1:0712/062725.466608:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"549 0x7f9675d43070 0x278ddaea4ee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062725.466998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"549 0x7f9675d43070 0x278ddaea4ee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062725.467423:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062725.468362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);l="undefined"==typeof b?u
[1:1:0712/062725.468645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062725.469431:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062725.469666:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062725.470114:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 855
[1:1:0712/062725.470345:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 855 0x7f9675d43070 0x278ddc04a560 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 731 0x7f9675d43070 0x278ddad2cc60 
[1:1:0712/062725.506608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 742 0x7f9677c6b2e0 0x278ddbff4ce0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062725.507690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jsonp15629380398911346("1")
[1:1:0712/062725.507932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062725.686451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 748, 7f9678688881
[1:1:0712/062725.726522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"610 0x7f9675d43070 0x278ddb424ee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062725.726872:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"610 0x7f9675d43070 0x278ddb424ee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062725.727270:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062725.727991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062725.728236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062725.729002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062725.729204:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062725.729712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 863
[1:1:0712/062725.729966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 863 0x7f9675d43070 0x278ddbff4a60 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 748 0x7f9675d43070 0x278ddc06fd60 
[1:1:0712/062727.144580:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062727.145345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/062727.145528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062727.567786:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 811 0x7f9677c6b2e0 0x278ddc1d6460 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062727.568665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , /**/_lxb_jsonp_jy04yfcu_({"status":0,"data":{"position":50,"phone":"","float_window":0,"imagePath":"
[1:1:0712/062727.568786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062727.573152:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3980
[1:1:0712/062727.573309:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062727.573495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 889
[1:1:0712/062727.573604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 889 0x7f9675d43070 0x278dda651ae0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 811 0x7f9677c6b2e0 0x278ddc1d6460 
[1:1:0712/062727.717897:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062727.718418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , c.onload, (){c.onload=null,b&&b()}
[1:1:0712/062727.718559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062728.015700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , document.readyState
[1:1:0712/062728.015888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062729.032807:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062729.033543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , f.onload, (){f.onload=v;f=window[d]=v;a&&a(b)}
[1:1:0712/062729.033762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062729.290024:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 855, 7f9678688881
[1:1:0712/062729.303643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"731 0x7f9675d43070 0x278ddad2cc60 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062729.303862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"731 0x7f9675d43070 0x278ddad2cc60 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062729.304089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062729.304416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);l="undefined"==typeof b?u
[1:1:0712/062729.304537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062729.304878:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062729.304979:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062729.305169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 914
[1:1:0712/062729.305280:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 914 0x7f9675d43070 0x278ddc8b3be0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 855 0x7f9675d43070 0x278ddc04a560 
[1:1:0712/062729.719666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 863, 7f9678688881
[1:1:0712/062729.761186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"748 0x7f9675d43070 0x278ddc06fd60 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062729.761507:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"748 0x7f9675d43070 0x278ddc06fd60 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062729.761923:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062729.762550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062729.762728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062729.763337:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062729.763497:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062729.763913:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 933
[1:1:0712/062729.764048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 933 0x7f9675d43070 0x278ddbc4dee0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 863 0x7f9675d43070 0x278ddbff4a60 
[1:1:0712/062730.624226:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 889, 7f9678688881
[1:1:0712/062730.666484:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"811 0x7f9677c6b2e0 0x278ddc1d6460 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062730.666816:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"811 0x7f9677c6b2e0 0x278ddc1d6460 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062730.667223:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062730.667848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){var i=lxb.use("base").g(f);i.parentNode.removeChild(i)}
[1:1:0712/062730.668055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062730.754596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , document.readyState
[1:1:0712/062730.754829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062731.198921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 914, 7f9678688881
[1:1:0712/062731.225941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"855 0x7f9675d43070 0x278ddc04a560 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062731.226131:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"855 0x7f9675d43070 0x278ddc04a560 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062731.226421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062731.226787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);l="undefined"==typeof b?u
[1:1:0712/062731.226894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062731.227263:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062731.227367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062731.227552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 955
[1:1:0712/062731.227661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 955 0x7f9675d43070 0x278dda8b5ae0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 914 0x7f9675d43070 0x278ddc8b3be0 
[1:1:0712/062731.478806:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 933, 7f9678688881
[1:1:0712/062731.492693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"863 0x7f9675d43070 0x278ddbff4a60 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062731.492903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"863 0x7f9675d43070 0x278ddbff4a60 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062731.493110:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062731.493466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062731.493574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062731.493836:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062731.493933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062731.494141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 962
[1:1:0712/062731.494322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7f9675d43070 0x278ddc99f7e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 933 0x7f9675d43070 0x278ddbc4dee0 
[1:1:0712/062731.792101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 943 0x7f968c3cd080 0x278ddc923ec0 1 0 0x278ddc923ed8 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062731.798706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , /*! jQuery UI - v1.11.4 - 2015-03-11
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.js,
[1:1:0712/062731.798857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062733.038999:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 943 0x7f968c3cd080 0x278ddc923ec0 1 0 0x278ddc923ed8 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062733.046411:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 943 0x7f968c3cd080 0x278ddc923ec0 1 0 0x278ddc923ed8 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062733.052977:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 943 0x7f968c3cd080 0x278ddc923ec0 1 0 0x278ddc923ed8 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062733.103723:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 943 0x7f968c3cd080 0x278ddc923ec0 1 0 0x278ddc923ed8 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062733.698957:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.663392, 0, 0
[1:1:0712/062733.699323:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/062734.061961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , document.readyState
[1:1:0712/062734.062180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062734.100701:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 955, 7f9678688881
[1:1:0712/062734.136763:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"914 0x7f9675d43070 0x278ddc8b3be0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062734.137167:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"914 0x7f9675d43070 0x278ddc8b3be0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062734.137603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062734.138285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);l="undefined"==typeof b?u
[1:1:0712/062734.138470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062734.139461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062734.139662:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062734.140133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1014
[1:1:0712/062734.140376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7f9675d43070 0x278ddc8d6ce0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 955 0x7f9675d43070 0x278dda8b5ae0 
[1:1:0712/062734.455998:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 962, 7f9678688881
[1:1:0712/062734.470396:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"933 0x7f9675d43070 0x278ddbc4dee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062734.470591:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"933 0x7f9675d43070 0x278ddbc4dee0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062734.470815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062734.471277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062734.471466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062734.472120:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062734.472295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062734.472621:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1024
[1:1:0712/062734.472810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1024 0x7f9675d43070 0x278ddc9f37e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 962 0x7f9675d43070 0x278ddc99f7e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/062735.569934:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/062735.570111:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.571735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 994 0x7f9675d43070 0x278ddb49b160 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.572748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , $(document).ready(function() {
    $('.phonrLoad .li2').mouseover(function () {
        $('.weiXin
[1:1:0712/062735.572875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062735.575190:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 994 0x7f9675d43070 0x278ddb49b160 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.578529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.581191:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 500
[1:1:0712/062735.581527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1063
[1:1:0712/062735.581673:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1063 0x7f9675d43070 0x278ddc98e1e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 994 0x7f9675d43070 0x278ddb49b160 
[1:1:0712/062735.583365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.584515:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.586733:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.589779:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062735.637002:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062736.266300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 1000
[1:1:0712/062736.266971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1087
[1:1:0712/062736.268153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1087 0x7f9675d43070 0x278ddc99ff60 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 994 0x7f9675d43070 0x278ddb49b160 
[1:1:0712/062736.480073:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062736.497700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0xe820c3829c8, 0x278ddaad39e0
[1:1:0712/062736.497969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 1500
[1:1:0712/062736.498419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1089
[1:1:0712/062736.498669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7f9675d43070 0x278ddc4e2f60 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 994 0x7f9675d43070 0x278ddb49b160 
[1:1:0712/062736.504045:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062736.505892:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062736.506524:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062736.515684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[91518:91518:0712/062736.520722:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/062736.521286:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x278ddb7c4220
[1:1:0712/062736.521520:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[91518:91518:0712/062736.529159:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/062736.547867:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/062736.548034:INFO:render_frame_impl.cc(7019)] 	 [url] = http://jiudian.jmw.com.cn
[91518:91518:0712/062736.550886:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://jiudian.jmw.com.cn/
[91518:91518:0712/062736.582209:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[91518:91518:0712/062736.589403:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[91518:91530:0712/062736.628936:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[91518:91530:0712/062736.629125:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[91518:91518:0712/062736.629267:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://vid.agrant.cn/
[91518:91518:0712/062736.629368:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://vid.agrant.cn/, https://vid.agrant.cn/store-1.2.html, 4
[91518:91518:0712/062736.629543:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://vid.agrant.cn/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html content-length:2381 x-amz-request-id:1574b18b-9e33-48b8-99e2-e6dda16f432e x-ba-request-id:1574b18b-9e33-48b8-99e2-e6dda16f432e x-scs-request-id:1574b18b-9e33-48b8-99e2-e6dda16f432e date:2019-07-06 22:29:53 access-control-allow-origin:* meta-source:CUBE cache-control:max-age=600000 last-modified:Mon, 05 Feb 2018 03:46:29 GMT accept-ranges:bytes data-source:PALLAS content-md5:5d1715c65eb9ac1537cebaa069999026 etag:"5d1715c65eb9ac1537cebaa069999026" via:cache3.l2nu29-1[0,304-0,H], cache35.l2nu29-1[0,0], cache1.cn765[0,200-0,H], cache1.cn765[0,0] expires:Sun, 05 May 2019 02:28:01 GMT ali-swift-global-savetime:1545574963 age:513158 x-cache:HIT TCP_MEM_HIT dirn:10:410441767 x-swift-savetime:Sat, 06 Jul 2019 14:44:54 GMT x-swift-cachetime:600000 timing-allow-origin:* eagleid:7cc8719515629374520052520e  ,91616, 5
[1:7:0712/062736.633857:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/062737.234179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , document.readyState
[1:1:0712/062737.234496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062737.238884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1014, 7f9678688881
[1:1:0712/062737.301485:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"955 0x7f9675d43070 0x278dda8b5ae0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062737.301942:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"955 0x7f9675d43070 0x278dda8b5ae0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062737.302470:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062737.303236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);l="undefined"==typeof b?u
[1:1:0712/062737.303564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062737.304732:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062737.304978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062737.305499:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1119
[1:1:0712/062737.305759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1119 0x7f9675d43070 0x278ddc9961e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1014 0x7f9675d43070 0x278ddc8d6ce0 
[1:1:0712/062737.471924:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1024, 7f9678688881
[1:1:0712/062737.498403:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"962 0x7f9675d43070 0x278ddc99f7e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062737.498608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"962 0x7f9675d43070 0x278ddc99f7e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062737.498872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062737.499410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){
				if (isReady) return;
				if (document.readyState != "loaded" && document.readyState != "comp
[1:1:0712/062737.499584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[91518:91518:0712/062738.351855:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/062738.764548:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1053 0x7f9677c6b2e0 0x278ddd273b60 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062738.765696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012761({"code":"1","visit":"983"})
[1:1:0712/062738.765882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062738.766690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062738.868461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1054 0x7f9677c6b2e0 0x278ddc244360 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062738.869081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012762({"status":"unlogin","user_id":0})
[1:1:0712/062738.869253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062738.869648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062738.962025:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1056 0x7f9677c6b2e0 0x278ddbfd6260 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062738.965349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/062738.965568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062739.052928:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad39c8
[1:1:0712/062739.053109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062739.053323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1156
[1:1:0712/062739.053445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1156 0x7f9675d43070 0x278ddd4992e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1056 0x7f9677c6b2e0 0x278ddbfd6260 
[1:1:0712/062739.062728:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad39c8
[1:1:0712/062739.063003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062739.063512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1157
[1:1:0712/062739.063763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1157 0x7f9675d43070 0x278ddbffc760 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1056 0x7f9677c6b2e0 0x278ddbfd6260 
[1:1:0712/062739.079588:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad39c8
[1:1:0712/062739.079877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062739.080512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1161
[1:1:0712/062739.080774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1161 0x7f9675d43070 0x278ddd4e38e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1056 0x7f9677c6b2e0 0x278ddbfd6260 
[1:1:0712/062739.093926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad39c8
[1:1:0712/062739.094198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062739.094709:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1164
[1:1:0712/062739.094983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1164 0x7f9675d43070 0x278ddd453560 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1056 0x7f9677c6b2e0 0x278ddbfd6260 
[1:1:0712/062739.110215:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad39c8
[1:1:0712/062739.110514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062739.111035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1167
[1:1:0712/062739.111304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7f9675d43070 0x278ddbff4260 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1056 0x7f9677c6b2e0 0x278ddbfd6260 
[1:1:0712/062739.124910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad39c8
[1:1:0712/062739.125189:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062739.125762:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1170
[1:1:0712/062739.126015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7f9675d43070 0x278ddd26efe0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1056 0x7f9677c6b2e0 0x278ddbfd6260 
[1:1:0712/062739.134210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe820c3829c8, 0x278ddaad39c8
[1:1:0712/062739.134508:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 3000
[1:1:0712/062739.134989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1172
[1:1:0712/062739.135237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7f9675d43070 0x278ddb432e60 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1056 0x7f9677c6b2e0 0x278ddbfd6260 
[1:1:0712/062739.343532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062739.344545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , acakjksja2, () {         if (nIwngNc9[_$dsadksal[1]] == 4) {             if (nIwngNc9[_$dsadksal[77]] == 200) { 
[1:1:0712/062739.344787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062739.345496:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062739.349049:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062740.068182:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062740.069151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0712/062740.069436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062740.070477:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062740.073966:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062740.711645:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://vid.agrant.cn/
[1:1:0712/062740.792549:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1063, 7f96786888db
[1:1:0712/062740.849467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"994 0x7f9675d43070 0x278ddb49b160 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062740.849806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"994 0x7f9675d43070 0x278ddb49b160 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062740.850244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1214
[1:1:0712/062740.850450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1214 0x7f9675d43070 0x278ddc99cfe0 , 5:3_http://jiudian.jmw.com.cn/, 0, , 1063 0x7f9675d43070 0x278ddc98e1e0 
[1:1:0712/062740.850825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062740.851414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){    if(EI16>1){       sendFlags();    }else{      clearInterval(_zXrZQyj17);    }    EI16--;}
[1:1:0712/062740.851620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062740.854683:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062741.012422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1115 0x7f9677c6b2e0 0x278ddc9ce560 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062741.013238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012763("2")
[1:1:0712/062741.013410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062741.013893:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062741.176830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1116 0x7f9677c6b2e0 0x278ddc9f3b60 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062741.178156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012764(31)
[1:1:0712/062741.178397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062741.179167:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062741.269296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , document.readyState
[1:1:0712/062741.269640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062741.274399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1087, 7f96786888db
[1:1:0712/062741.318031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"994 0x7f9675d43070 0x278ddb49b160 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062741.318313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"994 0x7f9675d43070 0x278ddb49b160 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062741.318678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1226
[1:1:0712/062741.318916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1226 0x7f9675d43070 0x278dda7a1160 , 5:3_http://jiudian.jmw.com.cn/, 0, , 1087 0x7f9675d43070 0x278ddc99ff60 
[1:1:0712/062741.319249:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062741.319812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , () {
        if(sys_second >= 1) {
            sys_second -= 1;
            var day = Math.floor(
[1:1:0712/062741.320051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062741.425372:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1119, 7f9678688881
[1:1:0712/062741.452139:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"1014 0x7f9675d43070 0x278ddc8d6ce0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062741.452357:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"1014 0x7f9675d43070 0x278ddc8d6ce0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062741.452583:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062741.453023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);l="undefined"==typeof b?u
[1:1:0712/062741.453300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062741.454271:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062741.454486:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 100
[1:1:0712/062741.455017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1231
[1:1:0712/062741.455278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1231 0x7f9675d43070 0x278dda866860 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1119 0x7f9675d43070 0x278ddc9961e0 
[1:1:0712/062742.101582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1089, 7f9678688881
[1:1:0712/062742.134028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b2041602860","ptid":"994 0x7f9675d43070 0x278ddb49b160 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062742.134363:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jiudian.jmw.com.cn/","ptid":"994 0x7f9675d43070 0x278ddb49b160 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062742.134755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062742.135437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){return t.registerDomObserver()}
[1:1:0712/062742.135686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
		remove user.11_fbf991d7 -> 0
		remove user.12_a6c7a5d0 -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/062746.638837:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3950
[1:1:0712/062746.639178:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062746.639889:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1250
[1:1:0712/062746.640176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1250 0x7f9675d43070 0x278ddd7d1f60 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1089 0x7f9675d43070 0x278ddc4e2f60 
[1:1:0712/062747.943610:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1183 0x7f9677c6b2e0 0x278ddadc43e0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062747.944615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012765("            <div class=\"first\">\r\n            <dl> \r\
[1:1:0712/062747.944734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062747.945194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062748.691307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe820c3829c8, 0x278ddaad3bf0
[1:1:0712/062748.691616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 0
[1:1:0712/062748.692243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1303
[1:1:0712/062748.692490:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7f9675d43070 0x278ddc002ae0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1183 0x7f9677c6b2e0 0x278ddadc43e0 
[1:1:0712/062748.725755:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 13
[1:1:0712/062748.726281:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1304
[1:1:0712/062748.726524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1304 0x7f9675d43070 0x278ddd476560 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1183 0x7f9677c6b2e0 0x278ddadc43e0 
[1:1:0712/062750.103090:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xe820c3829c8, 0x278ddaad3de0
[1:1:0712/062750.103375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 10
[1:1:0712/062750.103826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1307
[1:1:0712/062750.104168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1307 0x7f9675d43070 0x278ddee38060 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1183 0x7f9677c6b2e0 0x278ddadc43e0 
[1:1:0712/062750.161644:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1184 0x7f9677c6b2e0 0x278ddc99f2e0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.162645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012766(8)
[1:1:0712/062750.162874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062750.163613:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.407167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1187 0x7f9677c6b2e0 0x278ddd453de0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.409105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , !function(e){function t(o){if(i[o])return i[o].exports;var r=i[o]={exports:{},id:o,loaded:!1};return
[1:1:0712/062750.409363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062750.480502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1188 0x7f9677c6b2e0 0x278ddd478460 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.482088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/062750.482371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062750.504040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad3990
[1:1:0712/062750.504347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062750.504810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1320
[1:1:0712/062750.505072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7f9675d43070 0x278ddd277ae0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1188 0x7f9677c6b2e0 0x278ddd478460 
[1:1:0712/062750.531419:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad3990
[1:1:0712/062750.531674:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062750.532146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1323
[1:1:0712/062750.532383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1323 0x7f9675d43070 0x278ddac69fe0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1188 0x7f9677c6b2e0 0x278ddd478460 
[1:1:0712/062750.540435:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.639064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1192 0x7f9677c6b2e0 0x278ddc19f660 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.640102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/062750.640386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062750.671717:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0xe820c3829c8, 0x278ddaad3990
[1:1:0712/062750.672009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", 15000
[1:1:0712/062750.672469:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jiudian.jmw.com.cn/, 1328
[1:1:0712/062750.672703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1328 0x7f9675d43070 0x278ddee384e0 , 5:3_http://jiudian.jmw.com.cn/, 1, -5:3_http://jiudian.jmw.com.cn/, 1192 0x7f9677c6b2e0 0x278ddc19f660 
[1:1:0712/062750.679587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.743280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1193 0x7f9677c6b2e0 0x278ddaeb0160 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.744654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window._bd_share_main.F.module("share/select_api",function(e,t,n){var r=e("base/tangram").T,i=e("bas
[1:1:0712/062750.744889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062750.758093:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.886170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1196 0x7f9677c6b2e0 0x278ddc91d360 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.887728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window._bd_share_main.F.module("view/select_view",function(e,t,n){var r=e("base/tangram").T,i=e("bas
[1:1:0712/062750.888038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062750.922951:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.990014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1197 0x7f9677c6b2e0 0x278ddd14cc60 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062750.991655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window._bd_share_main.F.module("share/image_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/062750.991964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062751.019223:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062751.415365:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[91518:91518:0712/062751.417538:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://vid.agrant.cn/, https://vid.agrant.cn/, 4
[91518:91518:0712/062751.417623:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://vid.agrant.cn/, https://vid.agrant.cn
[1:1:0712/062751.603398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062751.604223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , acakjksja2, () {         if (nIwngNc9[_$dsadksal[1]] == 4) {             if (nIwngNc9[_$dsadksal[77]] == 200) { 
[1:1:0712/062751.604494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062751.605112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062751.607705:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062751.679111:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1214, 7f96786888db
[1:1:0712/062751.736344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1063 0x7f9675d43070 0x278ddc98e1e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062751.736811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1063 0x7f9675d43070 0x278ddc98e1e0 ","rf":"5:3_http://jiudian.jmw.com.cn/"}
[1:1:0712/062751.737205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jiudian.jmw.com.cn/, 1356
[1:1:0712/062751.737444:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1356 0x7f9675d43070 0x278ddefa2060 , 5:3_http://jiudian.jmw.com.cn/, 0, , 1214 0x7f9675d43070 0x278ddc99cfe0 
[1:1:0712/062751.737864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062751.738548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , (){    if(EI16>1){       sendFlags();    }else{      clearInterval(_zXrZQyj17);    }    EI16--;}
[1:1:0712/062751.738779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062751.911476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , document.readyState
[1:1:0712/062751.911846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/062752.308469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1236 0x7f9677c6b2e0 0x278ddd79a7e0 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062752.311602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , window._bd_share_main.F.module("view/image_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/062752.311923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062752.338106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062752.471613:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f9677c6b2e0 0x278dda7a3060 , "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
[1:1:0712/062752.474967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jiudian.jmw.com.cn/, 2b2041602860, , , jQuery183004161861550797741_1562938012763("        <div class=\"plBottom\" id=\"plBottom\">\r\n     
[1:1:0712/062752.475206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html", "jiudian.jmw.com.cn", 3, 1, , , 0
[1:1:0712/062752.476126:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jiudian.jmw.com.cn/jd_xmpd/17580346.html"
