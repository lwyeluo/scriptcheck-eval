[0713/002210.818935:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002210.819253:INFO:switcher_clone.cc(787)] backtrace rip is 7ff5ccf99891
[0713/002211.916828:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002211.917137:INFO:switcher_clone.cc(787)] backtrace rip is 7f38c57f1891
[1:1:0713/002211.928803:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/002211.929045:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/002211.938916:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/002213.252222:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002213.252555:INFO:switcher_clone.cc(787)] backtrace rip is 7f1e0244b891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[26848:26848:0713/002213.449509:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26848
[26858:26858:0713/002213.449909:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26858
[26816:26816:0713/002213.467565:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/877959fb-f430-4c1e-a17a-cf70089e03a4
[26816:26816:0713/002213.992503:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26816:26846:0713/002213.993280:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/002213.993526:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002213.993835:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002213.994618:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002213.995083:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/002214.000056:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x7442a6a, 1
[1:1:0713/002214.000775:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x138d1521, 0
[1:1:0713/002214.001124:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x132bca55, 3
[1:1:0713/002214.001516:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x35f40592, 2
[1:1:0713/002214.001957:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2115ffffff8d13 6a2a4407 ffffff9205fffffff435 55ffffffca2b13 , 10104, 4
[1:1:0713/002214.004343:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26816:26846:0713/002214.004829:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING!�j*D��5U�+��
[26816:26846:0713/002214.005004:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is !�j*D��5U�+�h��
[26816:26846:0713/002214.005795:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[26816:26846:0713/002214.005884:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26868, 4, 21158d13 6a2a4407 9205f435 55ca2b13 
[1:1:0713/002214.005413:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38c3a2c0a0, 3
[1:1:0713/002214.006446:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38c3bb7080, 2
[1:1:0713/002214.006719:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38ad87ad20, -2
[1:1:0713/002214.032677:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002214.033745:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 35f40592
[1:1:0713/002214.035018:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 35f40592
[1:1:0713/002214.036679:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 35f40592
[1:1:0713/002214.038132:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.038372:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.038593:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.038815:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.039490:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 35f40592
[1:1:0713/002214.039857:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38c57f17ba
[1:1:0713/002214.040032:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38c57e8def, 7f38c57f177a, 7f38c57f30cf
[1:1:0713/002214.045686:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 35f40592
[1:1:0713/002214.046058:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 35f40592
[1:1:0713/002214.046490:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 35f40592
[1:1:0713/002214.048522:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.048767:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.048985:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.049207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35f40592
[1:1:0713/002214.050496:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 35f40592
[1:1:0713/002214.050885:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38c57f17ba
[1:1:0713/002214.051054:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38c57e8def, 7f38c57f177a, 7f38c57f30cf
[1:1:0713/002214.058799:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002214.059314:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002214.059517:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc666b8448, 0x7ffc666b83c8)
[1:1:0713/002214.074738:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002214.081423:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26816:26816:0713/002214.743693:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26816:26816:0713/002214.745051:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26816:26827:0713/002214.758507:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26816:26827:0713/002214.758630:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[26816:26816:0713/002214.758742:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26816:26816:0713/002214.758818:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26816:26816:0713/002214.758956:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26868, 4
[1:7:0713/002214.761723:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[26816:26839:0713/002214.818407:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/002214.928876:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xf5640ff220
[1:1:0713/002214.929151:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/002215.304965:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/002216.763429:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002216.766873:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26816:26816:0713/002216.793098:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26816:26816:0713/002216.793149:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002217.488118:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002217.534018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 266507881f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002217.534354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002217.550183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 266507881f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002217.550444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002217.714360:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002217.714624:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002218.234520:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002218.242323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 266507881f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002218.242453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002218.256357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002218.266655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 266507881f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002218.266836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002218.278242:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[26816:26816:0713/002218.280434:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002218.281467:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf5640fde20
[1:1:0713/002218.281638:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26816:26816:0713/002218.286965:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26816:26816:0713/002218.338446:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26816:26816:0713/002218.338598:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002218.348285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002218.935107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f38af4552e0 0xf56418c060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002218.935818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 266507881f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/002218.935940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002218.936492:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26816:26816:0713/002219.027313:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002219.030690:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xf5640fe820
[1:1:0713/002219.030918:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[26816:26816:0713/002219.033984:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/002219.052432:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/002219.052627:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26816:26816:0713/002219.056459:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26816:26816:0713/002219.066713:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26816:26816:0713/002219.067694:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26816:26827:0713/002219.071579:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26816:26816:0713/002219.071607:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26816:26827:0713/002219.071670:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[26816:26816:0713/002219.071696:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26816:26816:0713/002219.071829:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26868, 4
[1:7:0713/002219.078378:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002219.641098:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/002220.247535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f38af4552e0 0xf56434a8e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002220.248637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 266507881f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/002220.248898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002220.249679:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26816:26816:0713/002220.430505:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26816:26816:0713/002220.430625:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/002220.466662:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/002220.899052:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[26816:26816:0713/002221.145772:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26816:26846:0713/002221.153565:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/002221.153758:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002221.154089:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002221.154603:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002221.154820:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/002221.157976:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1d0ae3f6, 1
[1:1:0713/002221.158420:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1477f6b5, 0
[1:1:0713/002221.158586:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xc7aea20, 3
[1:1:0713/002221.158737:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xfa9ae64, 2
[1:1:0713/002221.158892:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb5fffffff67714 fffffff6ffffffe30a1d 64ffffffaeffffffa90f 20ffffffea7a0c , 10104, 5
[1:1:0713/002221.159906:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26816:26846:0713/002221.160145:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��w��
d�� �z,�
[26816:26846:0713/002221.160217:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��w��
d�� �z�W,�
[1:1:0713/002221.160325:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38c3a2c0a0, 3
[26816:26846:0713/002221.160459:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26913, 5, b5f67714 f6e30a1d 64aea90f 20ea7a0c 
[1:1:0713/002221.160506:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38c3bb7080, 2
[1:1:0713/002221.160726:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38ad87ad20, -2
[1:1:0713/002221.182635:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002221.182980:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal fa9ae64
[1:1:0713/002221.183413:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal fa9ae64
[1:1:0713/002221.184184:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal fa9ae64
[1:1:0713/002221.186224:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.186446:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.186663:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.186873:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.187678:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal fa9ae64
[1:1:0713/002221.188052:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38c57f17ba
[1:1:0713/002221.188214:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38c57e8def, 7f38c57f177a, 7f38c57f30cf
[1:1:0713/002221.195548:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal fa9ae64
[1:1:0713/002221.195972:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal fa9ae64
[1:1:0713/002221.196866:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal fa9ae64
[1:1:0713/002221.199401:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.199677:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.199909:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.200156:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal fa9ae64
[1:1:0713/002221.201670:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal fa9ae64
[1:1:0713/002221.202149:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38c57f17ba
[1:1:0713/002221.202315:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38c57e8def, 7f38c57f177a, 7f38c57f30cf
[1:1:0713/002221.210707:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002221.211269:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002221.211421:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc666b8448, 0x7ffc666b83c8)
[1:1:0713/002221.224938:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002221.230278:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/002221.289196:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002221.289959:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002221.407522:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf5640ad220
[1:1:0713/002221.407735:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/002221.768306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002221.773139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2665079b09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/002221.773474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002221.781565:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[26816:26816:0713/002221.841500:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26816:26816:0713/002221.846053:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26816:26827:0713/002221.876107:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[26816:26827:0713/002221.876225:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[26816:26816:0713/002221.876313:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://sx.cncn.org.cn/
[26816:26816:0713/002221.876366:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sx.cncn.org.cn/, http://sx.cncn.org.cn/yangquan/honglou1/, 1
[26816:26816:0713/002221.876425:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://sx.cncn.org.cn/, HTTP/1.1 200 OK Server: nginx Date: Sat, 13 Jul 2019 07:22:18 GMT Content-Type: text/html Last-Modified: Mon, 06 May 2019 09:38:30 GMT Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,26913, 5
[1:7:0713/002221.882096:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002221.925718:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://sx.cncn.org.cn/
[1:1:0713/002222.036882:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002222.037672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 266507881f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/002222.037920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[26816:26816:0713/002222.068435:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sx.cncn.org.cn/, http://sx.cncn.org.cn/, 1
[26816:26816:0713/002222.068527:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://sx.cncn.org.cn/, http://sx.cncn.org.cn
[1:1:0713/002222.131290:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/002222.214389:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002222.294799:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002222.295062:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002222.425656:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.130373, 155, 1
[1:1:0713/002222.425884:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002222.853694:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002222.853855:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/002223.424048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213, "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002223.425029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , ,  
[1:1:0713/002223.425206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002223.446346:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0196149, 171, 1
[1:1:0713/002223.446525:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002223.566073:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002223.566265:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002223.732080:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002223.732775:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002223.733198:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002223.733620:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002223.733996:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002223.914306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 261, "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002223.915189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , ,  
[1:1:0713/002223.915365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002223.931669:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.014883, 150, 1
[1:1:0713/002223.931925:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002223.992303:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002223.992514:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.247051:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328, "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.249071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , ,  
document.writeln('<div class="ad"><a href="#" target="_blank"><img src="http://file3.cncn.org.cn/
[1:1:0713/002231.249258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002231.263702:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00927091, 72, 1
[1:1:0713/002231.263894:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002231.352320:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002231.352523:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.355393:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f38ad52d070 0xf56424cbe0 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.356267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , ,  
document.writeln('<div class="ad"><a href="#" target="_blank"><img src="http://file3.cncn.org.cn/
[1:1:0713/002231.356444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002231.386861:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0341718, 192, 1
[1:1:0713/002231.387045:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002231.561030:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002231.561239:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.564209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 348 0x7f38ad52d070 0xf564264ee0 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.564977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , ,  
[1:1:0713/002231.565160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002231.586665:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0253, 78, 1
[1:1:0713/002231.586881:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002231.723377:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002231.723585:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.724311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365 0x7f38ad52d070 0xf564352360 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002231.725375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.
[1:1:0713/002231.725553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002231.727424:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_ec8bcc4e -> 0
		remove user.11_20ac2068 -> 0
		remove user.12_cee97985 -> 0
		remove user.13_66c58bbb -> 0
		remove user.14_dc6c46ef -> 0
[1:1:0713/002231.751747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365 0x7f38ad52d070 0xf564352360 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.016734:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365 0x7f38ad52d070 0xf564352360 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.037956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365 0x7f38ad52d070 0xf564352360 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.153656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365 0x7f38ad52d070 0xf564352360 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.165248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365 0x7f38ad52d070 0xf564352360 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.508661:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.784906, 2, 0
[1:1:0713/002232.508856:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002232.805640:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002232.805901:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.809797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f38ad52d070 0xf564332d60 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.810884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , myFocus.pattern.extend({//*********************YSlide--翻页效果******************
	'mF_YSlider'
[1:1:0713/002232.811147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002232.817985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f38ad52d070 0xf564332d60 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.827713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f38ad52d070 0xf564332d60 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.837879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f38ad52d070 0xf564332d60 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.848063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f38ad52d070 0xf564332d60 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.854470:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f38ad52d070 0xf564332d60 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002232.867659:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002234.297780:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002234.298357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 442
[1:1:0713/002234.298605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 442 0x7f38ad52d070 0xf5640bf260 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 382 0x7f38ad52d070 0xf564332d60 
[1:1:0713/002234.300819:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002234.301230:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 443
[1:1:0713/002234.301489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 443 0x7f38ad52d070 0xf564af9260 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 382 0x7f38ad52d070 0xf564332d60 
[1:1:0713/002234.302884:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 4000
[1:1:0713/002234.303320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 444
[1:1:0713/002234.303565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 444 0x7f38ad52d070 0xf56464bee0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 382 0x7f38ad52d070 0xf564332d60 
[1:1:0713/002234.900168:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002235.700477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 442, 7f38afe728db
[1:1:0713/002235.721125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"382 0x7f38ad52d070 0xf564332d60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002235.721442:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"382 0x7f38ad52d070 0xf564332d60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002235.721878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 482
[1:1:0713/002235.722103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7f38ad52d070 0xf5641b55e0 , 5:3_http://sx.cncn.org.cn/, 0, , 442 0x7f38ad52d070 0xf5640bf260 
[1:1:0713/002235.722425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002235.723028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002235.723249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002235.747930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 443, 7f38afe728db
[1:1:0713/002235.768281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"382 0x7f38ad52d070 0xf564332d60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002235.768581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"382 0x7f38ad52d070 0xf564332d60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002235.768999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 483
[1:1:0713/002235.769222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7f38ad52d070 0xf564af90e0 , 5:3_http://sx.cncn.org.cn/, 0, , 443 0x7f38ad52d070 0xf564af9260 
[1:1:0713/002235.769528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002235.770085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002235.770342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002235.842905:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 463 0x7f38af4552e0 0xf564c3ce60 , "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002235.847538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (function(){var h={},mt={},c={id:"248191fc7c19ee68f4abb0a43bfc4f52",dm:["cncn.org.cn"],js:"tongji.ba
[1:1:0713/002235.847792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002235.872497:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e190
[1:1:0713/002235.872745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002235.873141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 488
[1:1:0713/002235.873373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 488 0x7f38ad52d070 0xf563cd2660 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 463 0x7f38af4552e0 0xf564c3ce60 
[1:1:0713/002235.891593:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002235.892097:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[26816:26816:0713/002259.191342:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/002259.233779:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/002300.046750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/002300.047033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002301.088691:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 488, 7f38afe72881
[1:1:0713/002301.114204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"463 0x7f38af4552e0 0xf564c3ce60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002301.114565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"463 0x7f38af4552e0 0xf564c3ce60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002301.115005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002301.115593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002301.115801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002301.116606:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002301.116798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002301.117211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 569
[1:1:0713/002301.117436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f38ad52d070 0xf564247160 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 488 0x7f38ad52d070 0xf563cd2660 
[1:1:0713/002301.118808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 444, 7f38afe728db
[1:1:0713/002301.143741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"382 0x7f38ad52d070 0xf564332d60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002301.144102:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"382 0x7f38ad52d070 0xf564332d60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002301.144562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 574
[1:1:0713/002301.144791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f38ad52d070 0xf56468bb60 , 5:3_http://sx.cncn.org.cn/, 0, , 444 0x7f38ad52d070 0xf56464bee0 
[1:1:0713/002301.145109:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002301.145704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){f.run('+=1')}
[1:1:0713/002301.145915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002301.154463:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002301.154897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 575
[1:1:0713/002301.155157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f38ad52d070 0xf5641b5360 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 444 0x7f38ad52d070 0xf56464bee0 
[1:1:0713/002301.157025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002301.157426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 576
[1:1:0713/002301.157650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 576 0x7f38ad52d070 0xf56464bd60 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 444 0x7f38ad52d070 0xf56464bee0 
[1:1:0713/002302.004247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , document.readyState
[1:1:0713/002302.004565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002302.282972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 575, 7f38afe728db
[1:1:0713/002302.309324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"444 0x7f38ad52d070 0xf56464bee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002302.309656:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"444 0x7f38ad52d070 0xf56464bee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002302.310098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 616
[1:1:0713/002302.310358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f38ad52d070 0xf564650ce0 , 5:3_http://sx.cncn.org.cn/, 0, , 575 0x7f38ad52d070 0xf5641b5360 
[1:1:0713/002302.310658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002302.311247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002302.311503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002302.314676:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 576, 7f38afe728db
[1:1:0713/002302.341753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"444 0x7f38ad52d070 0xf56464bee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002302.342090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"444 0x7f38ad52d070 0xf56464bee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002302.342573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 618
[1:1:0713/002302.342809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f38ad52d070 0xf5642d0f60 , 5:3_http://sx.cncn.org.cn/, 0, , 576 0x7f38ad52d070 0xf56464bd60 
[1:1:0713/002302.343142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002302.343732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002302.343940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002302.347123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 569, 7f38afe72881
[1:1:0713/002302.368738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"488 0x7f38ad52d070 0xf563cd2660 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002302.369069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"488 0x7f38ad52d070 0xf563cd2660 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002302.369501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002302.370091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002302.370356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002302.371051:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002302.371242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002302.371674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 619
[1:1:0713/002302.371899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f38ad52d070 0xf564cd62e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 569 0x7f38ad52d070 0xf564247160 
[1:1:0713/002303.094875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , document.readyState
[1:1:0713/002303.095192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002303.432747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002303.433501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/002303.433732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002303.442639:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002303.443956:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002303.447193:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002303.448746:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e2f0
[1:1:0713/002303.448943:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002303.449351:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 639
[1:1:0713/002303.449631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7f38ad52d070 0xf564d80f60 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 613 0x7f38ad52d070 0xf5642a7a60 
[1:1:0713/002303.484654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 574, 7f38afe728db
[1:1:0713/002303.506255:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"444 0x7f38ad52d070 0xf56464bee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002303.506588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"444 0x7f38ad52d070 0xf56464bee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002303.507016:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 642
[1:1:0713/002303.507242:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 642 0x7f38ad52d070 0xf563cb9be0 , 5:3_http://sx.cncn.org.cn/, 0, , 574 0x7f38ad52d070 0xf56468bb60 
[1:1:0713/002303.507524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002303.508077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){f.run('+=1')}
[1:1:0713/002303.508291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002303.515678:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002303.516085:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 643
[1:1:0713/002303.516313:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7f38ad52d070 0xf563cb95e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 574 0x7f38ad52d070 0xf56468bb60 
[1:1:0713/002303.518143:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002303.518548:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 644
[1:1:0713/002303.518788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7f38ad52d070 0xf5646853e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 574 0x7f38ad52d070 0xf56468bb60 
[1:1:0713/002303.847525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , document.readyState
[1:1:0713/002303.847845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002304.128697:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 643, 7f38afe728db
[1:1:0713/002304.162868:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"574 0x7f38ad52d070 0xf56468bb60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.163186:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"574 0x7f38ad52d070 0xf56468bb60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.163620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 669
[1:1:0713/002304.163857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f38ad52d070 0xf564af8b60 , 5:3_http://sx.cncn.org.cn/, 0, , 643 0x7f38ad52d070 0xf563cb95e0 
[1:1:0713/002304.164170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002304.164788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002304.165027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002304.167608:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 644, 7f38afe728db
[1:1:0713/002304.196444:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"574 0x7f38ad52d070 0xf56468bb60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.196801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"574 0x7f38ad52d070 0xf56468bb60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.197242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 671
[1:1:0713/002304.197470:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 671 0x7f38ad52d070 0xf56464b4e0 , 5:3_http://sx.cncn.org.cn/, 0, , 644 0x7f38ad52d070 0xf5646853e0 
[1:1:0713/002304.197812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002304.198466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002304.198738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002304.223213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 639, 7f38afe72881
[1:1:0713/002304.250689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"613 0x7f38ad52d070 0xf5642a7a60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.250999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"613 0x7f38ad52d070 0xf5642a7a60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.251389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002304.251975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002304.252185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002304.252891:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002304.253080:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002304.253470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 672
[1:1:0713/002304.253689:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7f38ad52d070 0xf5646e6860 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 639 0x7f38ad52d070 0xf564d80f60 
[1:1:0713/002304.748573:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 672, 7f38afe72881
[1:1:0713/002304.776600:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"639 0x7f38ad52d070 0xf564d80f60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.776854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"639 0x7f38ad52d070 0xf564d80f60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002304.777195:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002304.777733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002304.777925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002304.778583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002304.778739:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002304.779153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 687
[1:1:0713/002304.779340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f38ad52d070 0xf56411c760 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 672 0x7f38ad52d070 0xf5646e6860 
[1:1:0713/002305.005207:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://sx.cncn.org.cn/favicon.ico"
[1:1:0713/002305.040277:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 687, 7f38afe72881
[1:1:0713/002305.070063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"672 0x7f38ad52d070 0xf5646e6860 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.070328:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"672 0x7f38ad52d070 0xf5646e6860 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.070650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002305.071375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002305.071699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002305.072827:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002305.073124:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002305.073717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 695
[1:1:0713/002305.074055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f38ad52d070 0xf56408c7e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 687 0x7f38ad52d070 0xf56411c760 
[1:1:0713/002305.186068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 695, 7f38afe72881
[1:1:0713/002305.202487:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"687 0x7f38ad52d070 0xf56411c760 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.202733:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"687 0x7f38ad52d070 0xf56411c760 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.203088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002305.203615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002305.203784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002305.204454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002305.204617:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002305.204964:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 701
[1:1:0713/002305.205177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f38ad52d070 0xf564267a60 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 695 0x7f38ad52d070 0xf56408c7e0 
[1:1:0713/002305.323127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 701, 7f38afe72881
[1:1:0713/002305.351505:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"695 0x7f38ad52d070 0xf56408c7e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.351753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"695 0x7f38ad52d070 0xf56408c7e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.352077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002305.352558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002305.352729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002305.353406:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002305.353559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002305.353903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 707
[1:1:0713/002305.354130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f38ad52d070 0xf5643288e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 701 0x7f38ad52d070 0xf564267a60 
[1:1:0713/002305.455163:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 707, 7f38afe72881
[1:1:0713/002305.463516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"701 0x7f38ad52d070 0xf564267a60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.463644:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"701 0x7f38ad52d070 0xf564267a60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.463804:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002305.464092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002305.464194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002305.464485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002305.464591:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002305.465314:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 715
[1:1:0713/002305.465423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f38ad52d070 0xf5642dba60 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 707 0x7f38ad52d070 0xf5643288e0 
[1:1:0713/002305.591693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 715, 7f38afe72881
[1:1:0713/002305.620870:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"707 0x7f38ad52d070 0xf5643288e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.621175:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"707 0x7f38ad52d070 0xf5643288e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.621525:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002305.622065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002305.622283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002305.622936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002305.623108:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002305.623474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 722
[1:1:0713/002305.623663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7f38ad52d070 0xf564140ae0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 715 0x7f38ad52d070 0xf5642dba60 
[1:1:0713/002305.765358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 722, 7f38afe72881
[1:1:0713/002305.790223:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"715 0x7f38ad52d070 0xf5642dba60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.790428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"715 0x7f38ad52d070 0xf5642dba60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.790638:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002305.790956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002305.791064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002305.791404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002305.791506:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002305.791698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 724
[1:1:0713/002305.791809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7f38ad52d070 0xf564c3c9e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 722 0x7f38ad52d070 0xf564140ae0 
[1:1:0713/002305.919877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 724, 7f38afe72881
[1:1:0713/002305.954666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"722 0x7f38ad52d070 0xf564140ae0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.954918:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"722 0x7f38ad52d070 0xf564140ae0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002305.955280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002305.955822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002305.955995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002305.956670:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002305.956825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002305.957207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 726
[1:1:0713/002305.957396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7f38ad52d070 0xf563e1fd60 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 724 0x7f38ad52d070 0xf564c3c9e0 
[1:1:0713/002306.110497:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 726, 7f38afe72881
[1:1:0713/002306.144424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"724 0x7f38ad52d070 0xf564c3c9e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.144672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"724 0x7f38ad52d070 0xf564c3c9e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.144990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002306.145555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002306.145728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002306.146422:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002306.146580:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002306.146943:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 732
[1:1:0713/002306.147130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 732 0x7f38ad52d070 0xf56523f360 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 726 0x7f38ad52d070 0xf563e1fd60 
[1:1:0713/002306.278984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 732, 7f38afe72881
[1:1:0713/002306.306254:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"726 0x7f38ad52d070 0xf563e1fd60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.306546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"726 0x7f38ad52d070 0xf563e1fd60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.306886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002306.307459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002306.307640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002306.308337:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002306.308500:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002306.308870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 734
[1:1:0713/002306.309060:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7f38ad52d070 0xf564af7ee0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 732 0x7f38ad52d070 0xf56523f360 
[1:1:0713/002306.310971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 642, 7f38afe728db
[1:1:0713/002306.341859:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"574 0x7f38ad52d070 0xf56468bb60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.342081:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"574 0x7f38ad52d070 0xf56468bb60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.342493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 736
[1:1:0713/002306.342695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 736 0x7f38ad52d070 0xf5641bcce0 , 5:3_http://sx.cncn.org.cn/, 0, , 642 0x7f38ad52d070 0xf563cb9be0 
[1:1:0713/002306.342931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002306.343421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){f.run('+=1')}
[1:1:0713/002306.343600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002306.362063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002306.362486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 738
[1:1:0713/002306.362682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7f38ad52d070 0xf56464ece0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 642 0x7f38ad52d070 0xf563cb9be0 
[1:1:0713/002306.364596:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 13
[1:1:0713/002306.364965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 739
[1:1:0713/002306.365157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 739 0x7f38ad52d070 0xf565271ae0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 642 0x7f38ad52d070 0xf563cb9be0 
[1:1:0713/002306.825838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 738, 7f38afe728db
[1:1:0713/002306.857426:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"642 0x7f38ad52d070 0xf563cb9be0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.857683:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"642 0x7f38ad52d070 0xf563cb9be0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.858136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 753
[1:1:0713/002306.858334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7f38ad52d070 0xf5646fcf60 , 5:3_http://sx.cncn.org.cn/, 0, , 738 0x7f38ad52d070 0xf56464ece0 
[1:1:0713/002306.858638:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002306.859181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002306.859363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002306.862453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 739, 7f38afe728db
[1:1:0713/002306.894105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"642 0x7f38ad52d070 0xf563cb9be0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.894362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"642 0x7f38ad52d070 0xf563cb9be0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.894849:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 754
[1:1:0713/002306.895045:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7f38ad52d070 0xf56526ac60 , 5:3_http://sx.cncn.org.cn/, 0, , 739 0x7f38ad52d070 0xf565271ae0 
[1:1:0713/002306.895282:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002306.895826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002306.896004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002306.898955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 734, 7f38afe72881
[1:1:0713/002306.930613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"732 0x7f38ad52d070 0xf56523f360 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.930866:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"732 0x7f38ad52d070 0xf56523f360 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002306.931249:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002306.931811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002306.931990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002306.932703:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002306.932864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002306.933229:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 756
[1:1:0713/002306.933440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f38ad52d070 0xf5641bdc60 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 734 0x7f38ad52d070 0xf564af7ee0 
[1:1:0713/002307.232561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 753, 7f38afe728db
[1:1:0713/002307.271782:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"738 0x7f38ad52d070 0xf56464ece0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.272138:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"738 0x7f38ad52d070 0xf56464ece0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.272634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sx.cncn.org.cn/, 765
[1:1:0713/002307.272881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 765 0x7f38ad52d070 0xf564719960 , 5:3_http://sx.cncn.org.cn/, 0, , 753 0x7f38ad52d070 0xf5646fcf60 
[1:1:0713/002307.273237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002307.273941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002307.274161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002307.315408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 756, 7f38afe72881
[1:1:0713/002307.363978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"734 0x7f38ad52d070 0xf564af7ee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.364240:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"734 0x7f38ad52d070 0xf564af7ee0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.364584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002307.365113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002307.365303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002307.366001:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002307.366165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002307.366580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 766
[1:1:0713/002307.366779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 766 0x7f38ad52d070 0xf564278460 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 756 0x7f38ad52d070 0xf5641bdc60 
[1:1:0713/002307.539906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 766, 7f38afe72881
[1:1:0713/002307.570316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"756 0x7f38ad52d070 0xf5641bdc60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.570653:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"756 0x7f38ad52d070 0xf5641bdc60 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.571087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002307.571640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002307.571815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002307.572521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002307.572705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002307.573061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 770
[1:1:0713/002307.573245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7f38ad52d070 0xf563cbe360 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 766 0x7f38ad52d070 0xf564278460 
[1:1:0713/002307.725060:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 770, 7f38afe72881
[1:1:0713/002307.755372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"766 0x7f38ad52d070 0xf564278460 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.755613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"766 0x7f38ad52d070 0xf564278460 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.755937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002307.756417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002307.756593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002307.757244:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002307.757396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002307.757759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 772
[1:1:0713/002307.757944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 772 0x7f38ad52d070 0xf56464e760 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 770 0x7f38ad52d070 0xf563cbe360 
[1:1:0713/002307.907838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 772, 7f38afe72881
[1:1:0713/002307.944620:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"770 0x7f38ad52d070 0xf563cbe360 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.944935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"770 0x7f38ad52d070 0xf563cbe360 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002307.945238:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002307.945733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002307.945908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002307.946549:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002307.946761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002307.947111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 774
[1:1:0713/002307.947293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7f38ad52d070 0xf56464bde0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 772 0x7f38ad52d070 0xf56464e760 
[1:1:0713/002308.085841:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 774, 7f38afe72881
[1:1:0713/002308.101133:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"772 0x7f38ad52d070 0xf56464e760 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.101267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"772 0x7f38ad52d070 0xf56464e760 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.101492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002308.101779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002308.101894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002308.102185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002308.102280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002308.102452:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 776
[1:1:0713/002308.102566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 776 0x7f38ad52d070 0xf564afc9e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 774 0x7f38ad52d070 0xf56464bde0 
[1:1:0713/002308.246550:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 776, 7f38afe72881
[1:1:0713/002308.278940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"774 0x7f38ad52d070 0xf56464bde0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.279195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"774 0x7f38ad52d070 0xf56464bde0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.279516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002308.280055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002308.280238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002308.280932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002308.281094:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002308.281459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 778
[1:1:0713/002308.281648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 778 0x7f38ad52d070 0xf565271be0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 776 0x7f38ad52d070 0xf564afc9e0 
[1:1:0713/002308.424150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 778, 7f38afe72881
[1:1:0713/002308.456643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"776 0x7f38ad52d070 0xf564afc9e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.456919:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"776 0x7f38ad52d070 0xf564afc9e0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.457248:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002308.457772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002308.457968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002308.458645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002308.458854:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002308.459226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 780
[1:1:0713/002308.459418:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f38ad52d070 0xf565261de0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 778 0x7f38ad52d070 0xf565271be0 
[1:1:0713/002308.569096:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 780, 7f38afe72881
[1:1:0713/002308.602525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"778 0x7f38ad52d070 0xf565271be0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.602786:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"778 0x7f38ad52d070 0xf565271be0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.603194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002308.603715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002308.603916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002308.604590:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002308.604749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002308.605142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 784
[1:1:0713/002308.605369:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7f38ad52d070 0xf5640bf960 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 780 0x7f38ad52d070 0xf565261de0 
[1:1:0713/002308.763621:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 784, 7f38afe72881
[1:1:0713/002308.792516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"207e47de2860","ptid":"780 0x7f38ad52d070 0xf565261de0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.792651:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sx.cncn.org.cn/","ptid":"780 0x7f38ad52d070 0xf565261de0 ","rf":"5:3_http://sx.cncn.org.cn/"}
[1:1:0713/002308.792823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sx.cncn.org.cn/yangquan/honglou1/"
[1:1:0713/002308.793137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sx.cncn.org.cn/, 207e47de2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002308.793244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sx.cncn.org.cn/yangquan/honglou1/", "sx.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002308.793552:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x173f1e1a29c8, 0xf563f2e150
[1:1:0713/002308.793651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sx.cncn.org.cn/yangquan/honglou1/", 100
[1:1:0713/002308.793867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sx.cncn.org.cn/, 786
[1:1:0713/002308.794012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7f38ad52d070 0xf5640b28e0 , 5:3_http://sx.cncn.org.cn/, 1, -5:3_http://sx.cncn.org.cn/, 784 0x7f38ad52d070 0xf5640bf960 
