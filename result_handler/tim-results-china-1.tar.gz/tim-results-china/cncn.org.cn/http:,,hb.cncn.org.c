[0713/001951.374345:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001951.374689:INFO:switcher_clone.cc(787)] backtrace rip is 7f74efb9a891
[0713/001952.329206:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001952.329502:INFO:switcher_clone.cc(787)] backtrace rip is 7f408c5d7891
[1:1:0713/001952.333591:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/001952.333810:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/001952.339055:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[26553:26553:0713/001953.587368:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dee83050-0e05-40da-8c95-db2fe6949bb4
[0713/001953.726818:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001953.727353:INFO:switcher_clone.cc(787)] backtrace rip is 7fb72650c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[26585:26585:0713/001953.941724:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26585
[26598:26598:0713/001953.942162:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26598
[26553:26553:0713/001954.103629:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26553:26583:0713/001954.449803:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/001954.450073:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/001954.450288:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/001954.450968:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/001954.451117:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/001954.454048:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x292a0ac4, 1
[1:1:0713/001954.454350:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3c594f2, 0
[1:1:0713/001954.454560:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x49516dd, 3
[1:1:0713/001954.454721:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2d5c924e, 2
[1:1:0713/001954.454907:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff2ffffff94ffffffc503 ffffffc40a2a29 4effffff925c2d ffffffdd16ffffff9504 , 10104, 4
[1:1:0713/001954.456002:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26553:26583:0713/001954.456262:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���
*)N�\-��{�$
[26553:26583:0713/001954.456330:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���
*)N�\-����{�$
[1:1:0713/001954.456265:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f408a8120a0, 3
[1:1:0713/001954.456519:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f408a99d080, 2
[26553:26583:0713/001954.456629:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[26553:26583:0713/001954.456717:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26606, 4, f294c503 c40a2a29 4e925c2d dd169504 
[1:1:0713/001954.456706:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4074660d20, -2
[1:1:0713/001954.475408:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/001954.476264:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d5c924e
[1:1:0713/001954.477234:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d5c924e
[1:1:0713/001954.478846:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d5c924e
[1:1:0713/001954.480325:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.480552:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.480741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.480926:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.481580:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d5c924e
[1:1:0713/001954.481885:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f408c5d77ba
[1:1:0713/001954.482020:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f408c5cedef, 7f408c5d777a, 7f408c5d90cf
[1:1:0713/001954.487670:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d5c924e
[1:1:0713/001954.488010:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d5c924e
[1:1:0713/001954.488760:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d5c924e
[1:1:0713/001954.490758:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.490947:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.491131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.491313:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d5c924e
[1:1:0713/001954.492568:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d5c924e
[1:1:0713/001954.492920:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f408c5d77ba
[1:1:0713/001954.493074:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f408c5cedef, 7f408c5d777a, 7f408c5d90cf
[1:1:0713/001954.500747:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/001954.501176:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/001954.501316:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffcb4af418, 0x7fffcb4af398)
[1:1:0713/001954.518610:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/001954.525598:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26553:26553:0713/001955.178066:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26553:26553:0713/001955.179452:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26553:26553:0713/001955.195164:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26553:26553:0713/001955.195248:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26553:26553:0713/001955.195387:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26606, 4
[26553:26565:0713/001955.198228:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26553:26565:0713/001955.198318:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/001955.204228:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[26553:26576:0713/001955.263521:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/001955.289008:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x21937055d220
[1:1:0713/001955.289760:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/001955.654703:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/001957.264100:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001957.267410:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26553:26553:0713/001957.386985:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26553:26553:0713/001957.387090:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/001958.213873:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001958.463268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11669ec61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/001958.463618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001958.479891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11669ec61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/001958.480127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001958.558088:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001958.558368:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001959.018512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001959.027178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11669ec61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/001959.027432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001959.077278:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001959.087718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11669ec61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/001959.087971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001959.099986:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/001959.103286:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x21937055be20
[1:1:0713/001959.103487:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26553:26553:0713/001959.103955:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[26553:26553:0713/001959.118057:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26553:26553:0713/001959.159040:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26553:26553:0713/001959.159196:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/001959.200873:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001959.947068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f407623b2e0 0x2193706b57e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001959.948467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11669ec61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/001959.948748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001959.950348:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26553:26553:0713/002000.023364:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002000.025264:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x21937055c820
[1:1:0713/002000.025545:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[26553:26553:0713/002000.030366:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/002000.043758:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/002000.044049:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26553:26553:0713/002000.045954:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26553:26553:0713/002000.056956:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26553:26553:0713/002000.057923:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26553:26565:0713/002000.063698:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26553:26565:0713/002000.063787:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[26553:26553:0713/002000.063950:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26553:26553:0713/002000.064026:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26553:26553:0713/002000.064156:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26606, 4
[1:7:0713/002000.067691:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002000.702837:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/002001.284811:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7f407623b2e0 0x21937093a5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002001.286876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11669ec61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/002001.287441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002001.289124:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26553:26553:0713/002001.609658:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26553:26553:0713/002001.609812:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/002001.636490:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26553:26553:0713/002001.993681:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26553:26583:0713/002001.994017:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/002001.994185:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002001.994450:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002001.994944:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002001.995120:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/002001.997673:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x7763aeb, 1
[1:1:0713/002001.998038:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e1760fb, 0
[1:1:0713/002001.998198:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38fc0475, 3
[1:1:0713/002001.998394:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x17dc447c, 2
[1:1:0713/002001.998597:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffb60172e ffffffeb3a7607 7c44ffffffdc17 7504fffffffc38 , 10104, 5
[1:1:0713/002001.999973:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26553:26583:0713/002002.000246:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�`.�:v|D�u�8�}�$
[26553:26583:0713/002002.000355:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �`.�:v|D�u�88��}�$
[1:1:0713/002002.000498:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f408a8120a0, 3
[26553:26583:0713/002002.000642:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26653, 5, fb60172e eb3a7607 7c44dc17 7504fc38 
[1:1:0713/002002.000712:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f408a99d080, 2
[1:1:0713/002002.000943:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4074660d20, -2
[1:1:0713/002002.026894:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002002.027093:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 17dc447c
[1:1:0713/002002.027283:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 17dc447c
[1:1:0713/002002.027663:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 17dc447c
[1:1:0713/002002.028106:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.028207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.028297:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.028413:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.028661:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 17dc447c
[1:1:0713/002002.028792:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f408c5d77ba
[1:1:0713/002002.028874:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f408c5cedef, 7f408c5d777a, 7f408c5d90cf
[1:1:0713/002002.030326:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 17dc447c
[1:1:0713/002002.030524:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 17dc447c
[1:1:0713/002002.030791:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 17dc447c
[1:1:0713/002002.031515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.031637:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.031753:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.031853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17dc447c
[1:1:0713/002002.032298:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 17dc447c
[1:1:0713/002002.032478:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f408c5d77ba
[1:1:0713/002002.032564:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f408c5cedef, 7f408c5d777a, 7f408c5d90cf
[1:1:0713/002002.034695:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002002.035025:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002002.035119:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffcb4af418, 0x7fffcb4af398)
[1:1:0713/002002.038777:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002002.047505:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002002.051473:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/002002.256730:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x21937052e220
[1:1:0713/002002.256877:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/002002.627203:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002002.627557:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[26553:26553:0713/002002.963510:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26553:26553:0713/002002.968219:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26553:26565:0713/002003.010396:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[26553:26565:0713/002003.010495:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[26553:26553:0713/002003.010894:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://hb.cncn.org.cn/
[26553:26553:0713/002003.010974:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hb.cncn.org.cn/, http://hb.cncn.org.cn/wuhan/tazihu/, 1
[26553:26553:0713/002003.011103:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://hb.cncn.org.cn/, HTTP/1.1 200 OK Server: nginx Date: Sat, 13 Jul 2019 07:19:59 GMT Content-Type: text/html Last-Modified: Thu, 06 Jun 2019 08:28:30 GMT Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,26653, 5
[1:7:0713/002003.016431:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002003.035371:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://hb.cncn.org.cn/
[1:1:0713/002003.141692:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26553:26553:0713/002003.150720:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hb.cncn.org.cn/, http://hb.cncn.org.cn/, 1
[26553:26553:0713/002003.150827:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://hb.cncn.org.cn/, http://hb.cncn.org.cn
[1:1:0713/002003.151808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 566, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002003.156363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11669ed909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/002003.156696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002003.164816:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002003.239996:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002003.262867:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002003.263532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11669ec61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/002003.263763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002003.362938:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002003.363189:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002003.468005:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.104701, 155, 1
[1:1:0713/002003.468252:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002003.660776:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002003.661019:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/002004.718712:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002004.719343:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002004.719682:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002004.722996:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002004.723363:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002008.893929:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 271, "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002008.894880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , ,  
[1:1:0713/002008.895169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002008.917037:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0203738, 171, 1
[1:1:0713/002008.917282:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.049568:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.049797:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.053755:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f4074313070 0x2193706e7ee0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.054537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , ,  
[1:1:0713/002009.054764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002009.074792:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0248082, 198, 1
[1:1:0713/002009.075019:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.140504:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.140729:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.143704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289 0x7f4074313070 0x2193706f5f60 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.145694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , ,  
document.writeln('<div class="ad"><a href="#" target="_blank"><img src="http://file3.cncn.org.cn/
[1:1:0713/002009.145947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002009.158887:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0180249, 72, 1
[1:1:0713/002009.159106:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.240090:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.240322:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.243264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 295 0x7f4074313070 0x2193706d89e0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.244112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , ,  
document.writeln('<div class="ad"><a href="#" target="_blank"><img src="http://file3.cncn.org.cn/
[1:1:0713/002009.244328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002009.273985:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0335751, 192, 1
[1:1:0713/002009.274253:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.426062:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.426302:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.429130:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 303 0x7f4074313070 0x2193706d8160 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.429898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , ,  
[1:1:0713/002009.430141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002009.447850:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.021409, 78, 1
[1:1:0713/002009.448060:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.786268:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002009.786535:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.787259:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7f4074313070 0x2193705386e0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002009.788349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.
[1:1:0713/002009.788565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002009.790505:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002009.814850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7f4074313070 0x2193705386e0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002010.193313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7f4074313070 0x2193705386e0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002010.223553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7f4074313070 0x2193705386e0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002010.985700:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.19899, 2, 0
[1:1:0713/002010.985875:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002011.179566:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002011.179784:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002011.181505:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f4074313070 0x21937073aee0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002011.182765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , /*!
 * Distpicker v@VERSION
 * https://github.com/fengyuanchen/distpicker
 *
 * Copyright (c) 2014-@
[1:1:0713/002011.182885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002011.188063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f4074313070 0x21937073aee0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002011.617259:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f4074313070 0x21937073aee0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002011.626042:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f4074313070 0x21937073aee0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002011.639692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f4074313070 0x21937073aee0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002011.649574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f4074313070 0x21937073aee0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002011.809404:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002012.085613:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364 0x7f407623b2e0 0x2193706671e0 , "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002012.091338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (function(){var h={},mt={},c={id:"248191fc7c19ee68f4abb0a43bfc4f52",dm:["cncn.org.cn"],js:"tongji.ba
[1:1:0713/002012.091564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002012.120678:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4990
[1:1:0713/002012.120805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002012.120993:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 370
[1:1:0713/002012.121102:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7f4074313070 0x219370659160 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 364 0x7f407623b2e0 0x2193706671e0 
[26553:26553:0713/002043.094663:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/002043.104976:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/002044.659777:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 502 (Bad Gateway)","http://cms.cncn.org.cn/plugin/bizinfo/reloadInfos.php?communityid=1456&longitude=114.285628&latitude=30.643924"
[1:1:0713/002044.689713:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 502 (Bad Gateway)","http://cms.cncn.org.cn/plugin/bizinfo/display.php?communityid=1456"
[1:1:0713/002044.696210:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002044.698104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , K, (){(d.addEventListener||"load"===a.event.type||"complete"===d.readyState)&&(J(),n.ready())}
[1:1:0713/002044.698290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002045.226180:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002045.387565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 13
[1:1:0713/002045.387830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 484
[1:1:0713/002045.387945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7f4074313070 0x2193705f6ae0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 379
[1:1:0713/002045.388860:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 13
[1:1:0713/002045.389031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 485
[1:1:0713/002045.389142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7f4074313070 0x219371022a60 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 379
[1:1:0713/002045.389767:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 4000
[1:1:0713/002045.389935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 486
[1:1:0713/002045.390037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 486 0x7f4074313070 0x219371025fe0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 379
[1:1:0713/002045.408211:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002045.408737:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002045.698082:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002045.797229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/002045.797527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002047.394180:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 370, 7f4076c58881
[1:1:0713/002047.417135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"364 0x7f407623b2e0 0x2193706671e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002047.417466:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"364 0x7f407623b2e0 0x2193706671e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002047.417918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002047.418549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002047.418842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002047.419677:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002047.419880:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002047.420274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 530
[1:1:0713/002047.420497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7f4074313070 0x21937118f5e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 370 0x7f4074313070 0x219370659160 
[1:1:0713/002047.720232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 484, 7f4076c588db
[1:1:0713/002047.742922:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"379","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002047.743262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"379","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002047.744350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 534
[1:1:0713/002047.744627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f4074313070 0x219370b31960 , 5:3_http://hb.cncn.org.cn/, 0, , 484 0x7f4074313070 0x2193705f6ae0 
[1:1:0713/002047.745055:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002047.745658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002047.745912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002047.749147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 485, 7f4076c588db
[1:1:0713/002047.772111:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"379","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002047.772441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"379","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002047.772886:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 535
[1:1:0713/002047.773114:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 535 0x7f4074313070 0x2193711cf060 , 5:3_http://hb.cncn.org.cn/, 0, , 485 0x7f4074313070 0x219371022a60 
[1:1:0713/002047.773402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002047.773979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002047.774215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002047.839443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , document.readyState
[1:1:0713/002047.839723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002048.842912:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 530, 7f4076c58881
[1:1:0713/002048.867679:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"370 0x7f4074313070 0x219370659160 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002048.868011:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"370 0x7f4074313070 0x219370659160 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002048.868429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002048.869036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002048.869245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002048.869948:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002048.870207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002048.870597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 565
[1:1:0713/002048.870825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f4074313070 0x219371161ce0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 530 0x7f4074313070 0x21937118f5e0 
[1:1:0713/002048.954136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , document.readyState
[1:1:0713/002048.954409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002049.624540:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002049.625298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/002049.625521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002049.634723:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002049.635427:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002049.639029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002049.640441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4af0
[1:1:0713/002049.640639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002049.641022:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 586
[1:1:0713/002049.641275:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 586 0x7f4074313070 0x219370664ae0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 563 0x7f4074313070 0x2193708fa360 
[1:1:0713/002049.718972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , document.readyState
[1:1:0713/002049.719240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002049.869173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 486, 7f4076c588db
[1:1:0713/002049.894980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"379","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002049.895364:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"379","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002049.895789:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 598
[1:1:0713/002049.896015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7f4074313070 0x21937037bd60 , 5:3_http://hb.cncn.org.cn/, 0, , 486 0x7f4074313070 0x219371025fe0 
[1:1:0713/002049.896340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002049.896877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){f.run('+=1')}
[1:1:0713/002049.897085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002049.905688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 13
[1:1:0713/002049.906079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 600
[1:1:0713/002049.906347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f4074313070 0x219370640460 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 486 0x7f4074313070 0x219371025fe0 
[1:1:0713/002049.908234:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 13
[1:1:0713/002049.908625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 601
[1:1:0713/002049.908847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 601 0x7f4074313070 0x219370c3d8e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 486 0x7f4074313070 0x219371025fe0 
[1:1:0713/002050.127784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 586, 7f4076c58881
[1:1:0713/002050.159292:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"563 0x7f4074313070 0x2193708fa360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.159661:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"563 0x7f4074313070 0x2193708fa360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.160069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002050.160682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002050.160911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002050.161635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002050.161836:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002050.162217:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 609
[1:1:0713/002050.162484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f4074313070 0x219370b55b60 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 586 0x7f4074313070 0x219370664ae0 
[1:1:0713/002050.435215:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 600, 7f4076c588db
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/002050.462125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"486 0x7f4074313070 0x219371025fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.462548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"486 0x7f4074313070 0x219371025fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.463011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 621
[1:1:0713/002050.463266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7f4074313070 0x2193708fa1e0 , 5:3_http://hb.cncn.org.cn/, 0, , 600 0x7f4074313070 0x219370640460 
[1:1:0713/002050.463629:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002050.464237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002050.464561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002050.467377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 601, 7f4076c588db
[1:1:0713/002050.496984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"486 0x7f4074313070 0x219371025fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.497327:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"486 0x7f4074313070 0x219371025fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.497784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 623
[1:1:0713/002050.498020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7f4074313070 0x21937078ac60 , 5:3_http://hb.cncn.org.cn/, 0, , 601 0x7f4074313070 0x219370c3d8e0 
[1:1:0713/002050.498367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002050.498939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002050.499149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002050.560496:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 609, 7f4076c58881
[1:1:0713/002050.587021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"586 0x7f4074313070 0x219370664ae0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.587344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"586 0x7f4074313070 0x219370664ae0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.587764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002050.588324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002050.588544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002050.589220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002050.589407:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002050.589803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 625
[1:1:0713/002050.590025:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7f4074313070 0x2193705b9be0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 609 0x7f4074313070 0x219370b55b60 
[1:1:0713/002050.947389:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://hb.cncn.org.cn/favicon.ico"
[1:1:0713/002050.951279:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 625, 7f4076c58881
[1:1:0713/002050.973448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"609 0x7f4074313070 0x219370b55b60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.973634:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"609 0x7f4074313070 0x219370b55b60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002050.973812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002050.974090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002050.974214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002050.974494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002050.974644:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002050.974809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 635
[1:1:0713/002050.974909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f4074313070 0x219370ba6760 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 625 0x7f4074313070 0x2193705b9be0 
[1:1:0713/002051.086301:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 635, 7f4076c58881
[1:1:0713/002051.093504:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"625 0x7f4074313070 0x2193705b9be0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.093657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"625 0x7f4074313070 0x2193705b9be0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.093830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002051.094118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002051.094217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002051.094499:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002051.094628:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002051.094799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 638
[1:1:0713/002051.094899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 638 0x7f4074313070 0x219370a3fb60 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 635 0x7f4074313070 0x219370ba6760 
[1:1:0713/002051.223112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 638, 7f4076c58881
[1:1:0713/002051.249892:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"635 0x7f4074313070 0x219370ba6760 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.250274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"635 0x7f4074313070 0x219370ba6760 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.250733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002051.251403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002051.251656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002051.252463:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002051.252679:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002051.253122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 640
[1:1:0713/002051.253363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7f4074313070 0x219370b58ce0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 638 0x7f4074313070 0x219370a3fb60 
[1:1:0713/002051.380555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 640, 7f4076c58881
[1:1:0713/002051.395891:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"638 0x7f4074313070 0x219370a3fb60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.396063:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"638 0x7f4074313070 0x219370a3fb60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.396253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002051.396559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002051.396690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002051.396998:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002051.397097:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002051.397269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 642
[1:1:0713/002051.397376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 642 0x7f4074313070 0x21937004ea60 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 640 0x7f4074313070 0x219370b58ce0 
[1:1:0713/002051.529028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 642, 7f4076c58881
[1:1:0713/002051.559854:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"640 0x7f4074313070 0x219370b58ce0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.560232:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"640 0x7f4074313070 0x219370b58ce0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.560657:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002051.561345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002051.561580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002051.562273:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002051.562441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002051.562821:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 644
[1:1:0713/002051.563010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7f4074313070 0x2193704f59e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 642 0x7f4074313070 0x21937004ea60 
[1:1:0713/002051.687636:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 644, 7f4076c58881
[1:1:0713/002051.695387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"642 0x7f4074313070 0x21937004ea60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.695520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"642 0x7f4074313070 0x21937004ea60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.695694:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002051.696021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002051.696125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002051.696415:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002051.696511:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002051.696678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 646
[1:1:0713/002051.696800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 646 0x7f4074313070 0x219371025de0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 644 0x7f4074313070 0x2193704f59e0 
[1:1:0713/002051.807619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 646, 7f4076c58881
[1:1:0713/002051.835168:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"644 0x7f4074313070 0x2193704f59e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.835460:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"644 0x7f4074313070 0x2193704f59e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002051.835840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002051.836379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002051.836564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002051.837251:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002051.837407:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002051.837752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 648
[1:1:0713/002051.837965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7f4074313070 0x2193705be060 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 646 0x7f4074313070 0x219371025de0 
[1:1:0713/002051.973528:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 648, 7f4076c58881
[1:1:0713/002052.000470:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"646 0x7f4074313070 0x219371025de0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.000781:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"646 0x7f4074313070 0x219371025de0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.001138:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002052.001672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002052.001869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002052.002514:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002052.002670:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002052.003052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 650
[1:1:0713/002052.003241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7f4074313070 0x219371226560 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 648 0x7f4074313070 0x2193705be060 
[1:1:0713/002052.153669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 650, 7f4076c58881
[1:1:0713/002052.182451:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"648 0x7f4074313070 0x2193705be060 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.182769:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"648 0x7f4074313070 0x2193705be060 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.183263:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002052.184020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002052.184245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002052.184928:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002052.185089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002052.185445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 654
[1:1:0713/002052.185635:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f4074313070 0x2193712266e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 650 0x7f4074313070 0x219371226560 
[1:1:0713/002052.316014:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 654, 7f4076c58881
[1:1:0713/002052.344332:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"650 0x7f4074313070 0x219371226560 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.344662:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"650 0x7f4074313070 0x219371226560 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.345086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002052.345774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002052.346012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002052.346817:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002052.347066:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002052.347507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 656
[1:1:0713/002052.347741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f4074313070 0x2193711bdce0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 654 0x7f4074313070 0x2193712266e0 
[1:1:0713/002052.461203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 656, 7f4076c58881
[1:1:0713/002052.471238:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"654 0x7f4074313070 0x2193712266e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.471433:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"654 0x7f4074313070 0x2193712266e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.471629:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002052.471964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002052.472072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002052.472378:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002052.472477:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002052.472652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 658
[1:1:0713/002052.472758:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7f4074313070 0x219370651c60 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 656 0x7f4074313070 0x2193711bdce0 
[1:1:0713/002052.606741:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 658, 7f4076c58881
[1:1:0713/002052.616164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"656 0x7f4074313070 0x2193711bdce0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.616336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"656 0x7f4074313070 0x2193711bdce0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.616528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002052.616836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002052.616942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002052.617281:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002052.617379:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002052.617555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 660
[1:1:0713/002052.617661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 660 0x7f4074313070 0x219370b55360 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 658 0x7f4074313070 0x219370651c60 
[1:1:0713/002052.750819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 660, 7f4076c58881
[1:1:0713/002052.784678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"658 0x7f4074313070 0x219370651c60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.785019:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"658 0x7f4074313070 0x219370651c60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.785377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002052.785920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002052.786169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002052.786837:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002052.786995:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002052.787372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 662
[1:1:0713/002052.787563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7f4074313070 0x219370b1e0e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 660 0x7f4074313070 0x219370b55360 
[1:1:0713/002052.917247:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 662, 7f4076c58881
[1:1:0713/002052.945613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"660 0x7f4074313070 0x219370b55360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.945923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"660 0x7f4074313070 0x219370b55360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002052.946325:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002052.946865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002052.947054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002052.947699:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002052.947853:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002052.948232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 664
[1:1:0713/002052.948425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f4074313070 0x219370b58360 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 662 0x7f4074313070 0x219370b1e0e0 
[1:1:0713/002053.104858:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 664, 7f4076c58881
[1:1:0713/002053.137609:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"662 0x7f4074313070 0x219370b1e0e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.137962:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"662 0x7f4074313070 0x219370b1e0e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.138401:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.138950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002053.139145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.139807:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002053.139963:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002053.140343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 667
[1:1:0713/002053.140534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f4074313070 0x219370c4e8e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 664 0x7f4074313070 0x219370b58360 
[1:1:0713/002053.274301:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 667, 7f4076c58881
[1:1:0713/002053.283493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"664 0x7f4074313070 0x219370b58360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.283695:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"664 0x7f4074313070 0x219370b58360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.283889:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.284336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002053.284563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.285106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002053.285231:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002053.285409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 669
[1:1:0713/002053.285514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f4074313070 0x219370ba62e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 667 0x7f4074313070 0x219370c4e8e0 
[1:1:0713/002053.414334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 669, 7f4076c58881
[1:1:0713/002053.442883:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"667 0x7f4074313070 0x219370c4e8e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.443218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"667 0x7f4074313070 0x219370c4e8e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.443571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.444111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002053.444312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.444958:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002053.445125:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002053.445510:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 672
[1:1:0713/002053.445701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7f4074313070 0x219370b6b8e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 669 0x7f4074313070 0x219370ba62e0 
[1:1:0713/002053.447177:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 598, 7f4076c588db
[1:1:0713/002053.481701:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"486 0x7f4074313070 0x219371025fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.482004:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"486 0x7f4074313070 0x219371025fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.482423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 673
[1:1:0713/002053.482618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f4074313070 0x219370b56d60 , 5:3_http://hb.cncn.org.cn/, 0, , 598 0x7f4074313070 0x21937037bd60 
[1:1:0713/002053.482872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.483405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){f.run('+=1')}
[1:1:0713/002053.483580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.490961:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 13
[1:1:0713/002053.491349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 674
[1:1:0713/002053.491539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 674 0x7f4074313070 0x219371150d60 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 598 0x7f4074313070 0x21937037bd60 
[1:1:0713/002053.493413:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 13
[1:1:0713/002053.493754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 675
[1:1:0713/002053.493938:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7f4074313070 0x219371027fe0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 598 0x7f4074313070 0x21937037bd60 
[1:1:0713/002053.536770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 674, 7f4076c588db
[1:1:0713/002053.558623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"598 0x7f4074313070 0x21937037bd60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.558795:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"598 0x7f4074313070 0x21937037bd60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.559012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 678
[1:1:0713/002053.559120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f4074313070 0x219370b46060 , 5:3_http://hb.cncn.org.cn/, 0, , 674 0x7f4074313070 0x219371150d60 
[1:1:0713/002053.559288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.559581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.559684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.560993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 675, 7f4076c588db
[1:1:0713/002053.569523:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"598 0x7f4074313070 0x21937037bd60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.569687:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"598 0x7f4074313070 0x21937037bd60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.569900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 680
[1:1:0713/002053.570004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f4074313070 0x219370c51660 , 5:3_http://hb.cncn.org.cn/, 0, , 675 0x7f4074313070 0x219371027fe0 
[1:1:0713/002053.570164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.570466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.570593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.571666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 672, 7f4076c58881
[1:1:0713/002053.605451:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"669 0x7f4074313070 0x219370ba62e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.605787:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"669 0x7f4074313070 0x219370ba62e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.606188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.606855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002053.607070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.607899:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002053.608094:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002053.608546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 682
[1:1:0713/002053.608783:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7f4074313070 0x2193705bc360 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 672 0x7f4074313070 0x219370b6b8e0 
[1:1:0713/002053.610381:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 678, 7f4076c588db
[1:1:0713/002053.641603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"674 0x7f4074313070 0x219371150d60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.641912:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"674 0x7f4074313070 0x219371150d60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.642394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 684
[1:1:0713/002053.642632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7f4074313070 0x21937118f6e0 , 5:3_http://hb.cncn.org.cn/, 0, , 678 0x7f4074313070 0x219370b46060 
[1:1:0713/002053.642964:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.643580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.643798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.674638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 680, 7f4076c588db
[1:1:0713/002053.703424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"675 0x7f4074313070 0x219371027fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.703693:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"675 0x7f4074313070 0x219371027fe0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.704081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 686
[1:1:0713/002053.704291:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f4074313070 0x2193706f5d60 , 5:3_http://hb.cncn.org.cn/, 0, , 680 0x7f4074313070 0x219370c51660 
[1:1:0713/002053.704545:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.705059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.705243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.707661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 684, 7f4076c588db
[1:1:0713/002053.737741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"678 0x7f4074313070 0x219370b46060 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.737999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"678 0x7f4074313070 0x219370b46060 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.738410:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 687
[1:1:0713/002053.738604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f4074313070 0x2193711cf4e0 , 5:3_http://hb.cncn.org.cn/, 0, , 684 0x7f4074313070 0x21937118f6e0 
[1:1:0713/002053.738851:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.739397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.739574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.741946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 682, 7f4076c58881
[1:1:0713/002053.772590:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"672 0x7f4074313070 0x219370b6b8e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.772978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"672 0x7f4074313070 0x219370b6b8e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.773432:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.774100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002053.774363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.775179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002053.775400:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002053.775864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 690
[1:1:0713/002053.776105:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7f4074313070 0x219370b5e460 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 682 0x7f4074313070 0x2193705bc360 
[1:1:0713/002053.777578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 686, 7f4076c588db
[1:1:0713/002053.806322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"680 0x7f4074313070 0x219370c51660 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.806596:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"680 0x7f4074313070 0x219370c51660 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.806988:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 692
[1:1:0713/002053.807179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7f4074313070 0x219370b22be0 , 5:3_http://hb.cncn.org.cn/, 0, , 686 0x7f4074313070 0x2193706f5d60 
[1:1:0713/002053.807481:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.807996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.808170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.847683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 687, 7f4076c588db
[1:1:0713/002053.876070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"684 0x7f4074313070 0x21937118f6e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.876383:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"684 0x7f4074313070 0x21937118f6e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.876774:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 694
[1:1:0713/002053.876961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f4074313070 0x219370599ce0 , 5:3_http://hb.cncn.org.cn/, 0, , 687 0x7f4074313070 0x2193711cf4e0 
[1:1:0713/002053.877211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.877755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.877935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.880303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 692, 7f4076c588db
[1:1:0713/002053.909822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"686 0x7f4074313070 0x2193706f5d60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.910078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"686 0x7f4074313070 0x2193706f5d60 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.910471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 696
[1:1:0713/002053.910655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 696 0x7f4074313070 0x219370c4f9e0 , 5:3_http://hb.cncn.org.cn/, 0, , 692 0x7f4074313070 0x219370b22be0 
[1:1:0713/002053.910886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.911399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.911579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.913791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 690, 7f4076c58881
[1:1:0713/002053.943427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"682 0x7f4074313070 0x2193705bc360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.943766:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"682 0x7f4074313070 0x2193705bc360 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.944169:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.944868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002053.945088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002053.945911:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002053.946106:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002053.946584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 698
[1:1:0713/002053.946822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7f4074313070 0x219371021ae0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 690 0x7f4074313070 0x219370b5e460 
[1:1:0713/002053.948377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 694, 7f4076c588db
[1:1:0713/002053.978079:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"687 0x7f4074313070 0x2193711cf4e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.978348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"687 0x7f4074313070 0x2193711cf4e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002053.978718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 700
[1:1:0713/002053.978903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f4074313070 0x2193711bd4e0 , 5:3_http://hb.cncn.org.cn/, 0, , 694 0x7f4074313070 0x219370599ce0 
[1:1:0713/002053.979171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002053.979680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002053.979860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.011096:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 696, 7f4076c588db
[1:1:0713/002054.043831:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"692 0x7f4074313070 0x219370b22be0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.044076:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"692 0x7f4074313070 0x219370b22be0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.044464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 702
[1:1:0713/002054.044654:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f4074313070 0x2193711495e0 , 5:3_http://hb.cncn.org.cn/, 0, , 696 0x7f4074313070 0x219370c4f9e0 
[1:1:0713/002054.044899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002054.045475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002054.045650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.048399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 700, 7f4076c588db
[1:1:0713/002054.083687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"694 0x7f4074313070 0x219370599ce0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.083932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"694 0x7f4074313070 0x219370599ce0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.084295:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hb.cncn.org.cn/, 704
[1:1:0713/002054.084500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 704 0x7f4074313070 0x21937065c6e0 , 5:3_http://hb.cncn.org.cn/, 0, , 700 0x7f4074313070 0x2193711bd4e0 
[1:1:0713/002054.084770:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002054.085251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0713/002054.085445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.087659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 698, 7f4076c58881
[1:1:0713/002054.115978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"690 0x7f4074313070 0x219370b5e460 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.116267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"690 0x7f4074313070 0x219370b5e460 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.116650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002054.117141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002054.117344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.117981:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002054.118133:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002054.118517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 705
[1:1:0713/002054.118703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7f4074313070 0x219370fc6de0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 698 0x7f4074313070 0x219371021ae0 
[1:1:0713/002054.242997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 705, 7f4076c58881
[1:1:0713/002054.256762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"698 0x7f4074313070 0x219371021ae0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.257006:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"698 0x7f4074313070 0x219371021ae0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.257260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002054.257675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002054.257819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.258235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002054.258406:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002054.258664:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 707
[1:1:0713/002054.258806:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f4074313070 0x219370b227e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 705 0x7f4074313070 0x219370fc6de0 
[1:1:0713/002054.388729:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 707, 7f4076c58881
[1:1:0713/002054.402594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"705 0x7f4074313070 0x219370fc6de0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.402836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"705 0x7f4074313070 0x219370fc6de0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.403110:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002054.403547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002054.403715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.404187:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002054.404326:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002054.404608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 709
[1:1:0713/002054.404777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f4074313070 0x219370b623e0 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 707 0x7f4074313070 0x219370b227e0 
[1:1:0713/002054.542860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 709, 7f4076c58881
[1:1:0713/002054.579383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"707 0x7f4074313070 0x219370b227e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.579775:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"707 0x7f4074313070 0x219370b227e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.580200:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002054.580896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002054.581119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.581954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002054.582152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002054.582642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 711
[1:1:0713/002054.582887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f4074313070 0x219370c4e560 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 709 0x7f4074313070 0x219370b623e0 
[1:1:0713/002054.713208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 711, 7f4076c58881
[1:1:0713/002054.743039:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3c8dc9fe2860","ptid":"709 0x7f4074313070 0x219370b623e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.743240:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hb.cncn.org.cn/","ptid":"709 0x7f4074313070 0x219370b623e0 ","rf":"5:3_http://hb.cncn.org.cn/"}
[1:1:0713/002054.743442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hb.cncn.org.cn/wuhan/tazihu/"
[1:1:0713/002054.743784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hb.cncn.org.cn/, 3c8dc9fe2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/002054.743907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hb.cncn.org.cn/wuhan/tazihu/", "hb.cncn.org.cn", 3, 1, , , 0
[1:1:0713/002054.744203:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f6639429c8, 0x2193703a4950
[1:1:0713/002054.744301:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hb.cncn.org.cn/wuhan/tazihu/", 100
[1:1:0713/002054.744477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hb.cncn.org.cn/, 713
[1:1:0713/002054.744607:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f4074313070 0x2193705bc860 , 5:3_http://hb.cncn.org.cn/, 1, -5:3_http://hb.cncn.org.cn/, 711 0x7f4074313070 0x219370c4e560 
