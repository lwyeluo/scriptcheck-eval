[0713/001059.425725:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001059.425977:INFO:switcher_clone.cc(787)] backtrace rip is 7f472db8e891
[0713/001100.427442:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001100.427683:INFO:switcher_clone.cc(787)] backtrace rip is 7fab7dcb2891
[1:1:0713/001100.431687:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/001100.431883:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/001100.441139:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/001101.858604:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001101.858922:INFO:switcher_clone.cc(787)] backtrace rip is 7fc47a3b6891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[25521:25521:0713/001102.057379:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25521
[25532:25532:0713/001102.057813:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25532
[25488:25488:0713/001102.414844:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4d378e38-28cd-4c7f-ab6b-239e4adf6e5b
[25488:25488:0713/001102.805945:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[25488:25519:0713/001102.807561:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/001102.807804:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/001102.808916:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/001102.810154:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/001102.810574:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/001102.815492:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1fb11238, 1
[1:1:0713/001102.815811:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x19ba2cef, 0
[1:1:0713/001102.815976:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2ac5250a, 3
[1:1:0713/001102.816151:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xbb0a52, 2
[1:1:0713/001102.816360:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffef2cffffffba19 3812ffffffb11f 520affffffbb00 0a25ffffffc52a , 10104, 4
[1:1:0713/001102.817737:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25488:25519:0713/001102.817883:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�,�8�R
�
[25488:25519:0713/001102.817918:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �,�8�R
�
[1:1:0713/001102.817978:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab7beed0a0, 3
[1:1:0713/001102.818110:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab7c078080, 2
[1:1:0713/001102.818201:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab65d3bd20, -2
[25488:25519:0713/001102.818489:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[25488:25519:0713/001102.818631:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25542, 4, ef2cba19 3812b11f 520abb00 0a25c52a 
[1:1:0713/001102.834335:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/001102.835560:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bb0a52
[1:1:0713/001102.836879:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bb0a52
[1:1:0713/001102.838969:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bb0a52
[1:1:0713/001102.840217:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.840469:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.840712:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.840913:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.841405:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bb0a52
[1:1:0713/001102.841736:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fab7dcb27ba
[1:1:0713/001102.841901:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fab7dca9def, 7fab7dcb277a, 7fab7dcb40cf
[1:1:0713/001102.845300:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bb0a52
[1:1:0713/001102.845683:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bb0a52
[1:1:0713/001102.846297:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bb0a52
[1:1:0713/001102.847924:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.848145:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.848360:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.848632:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bb0a52
[1:1:0713/001102.849697:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bb0a52
[1:1:0713/001102.850037:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fab7dcb27ba
[1:1:0713/001102.850192:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fab7dca9def, 7fab7dcb277a, 7fab7dcb40cf
[1:1:0713/001102.854032:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/001102.854316:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/001102.854405:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc9e902ab8, 0x7ffc9e902a38)
[1:1:0713/001102.870615:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/001102.876640:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[25488:25488:0713/001103.469273:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25488:25488:0713/001103.470422:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25488:25501:0713/001103.490812:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[25488:25501:0713/001103.490946:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[25488:25488:0713/001103.491061:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[25488:25488:0713/001103.491162:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[25488:25488:0713/001103.491339:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,25542, 4
[1:7:0713/001103.497256:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/001103.561531:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x4ece9949220
[1:1:0713/001103.561765:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[25488:25513:0713/001103.569848:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/001103.825819:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/001105.274578:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001105.276204:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[25488:25488:0713/001105.617459:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[25488:25488:0713/001105.617599:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/001106.256552:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001106.474667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24eb66801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/001106.474914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001106.490742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24eb66801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/001106.490937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001106.584481:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001106.584686:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001106.985837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001106.993826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24eb66801f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/001106.994057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001107.027996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001107.038279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24eb66801f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/001107.038550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001107.052230:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[25488:25488:0713/001107.055354:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/001107.055507:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x4ece9947e20
[1:1:0713/001107.056171:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[25488:25488:0713/001107.071467:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[25488:25488:0713/001107.118872:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[25488:25488:0713/001107.119059:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/001107.152446:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001108.052864:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fab679162e0 0x4ece9bb8ce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001108.054191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24eb66801f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/001108.054504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001108.056025:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001108.126725:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x4ece9948820
[1:1:0713/001108.127151:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[25488:25488:0713/001108.134902:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[25488:25488:0713/001108.142245:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/001108.145495:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/001108.145727:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[25488:25488:0713/001108.159406:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[25488:25488:0713/001108.167751:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25488:25488:0713/001108.168901:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25488:25501:0713/001108.176879:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[25488:25501:0713/001108.177006:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[25488:25488:0713/001108.177110:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[25488:25488:0713/001108.177198:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[25488:25488:0713/001108.177346:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,25542, 4
[1:7:0713/001108.179278:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/001108.796410:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/001108.951060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7fab679162e0 0x4ece9cd7260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001108.952132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24eb66801f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/001108.952429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001108.953272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[25488:25488:0713/001109.420182:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[25488:25488:0713/001109.420294:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/001109.435429:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[25488:25488:0713/001109.781842:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[25488:25519:0713/001109.782417:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/001109.782623:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/001109.782856:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/001109.783302:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/001109.783458:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/001109.786463:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d4a8dec, 1
[1:1:0713/001109.786828:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2567c90e, 0
[1:1:0713/001109.787016:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10cdbbe2, 3
[1:1:0713/001109.787226:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x120f8cb0, 2
[1:1:0713/001109.787410:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 0effffffc96725 ffffffecffffff8d4a2d ffffffb0ffffff8c0f12 ffffffe2ffffffbbffffffcd10 , 10104, 5
[1:1:0713/001109.788461:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25488:25519:0713/001109.788750:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�g%�J-����d�$
[25488:25519:0713/001109.788825:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �g%�J-������d�$
[1:1:0713/001109.788744:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab7beed0a0, 3
[1:1:0713/001109.788944:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab7c078080, 2
[25488:25519:0713/001109.789068:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25586, 5, 0ec96725 ec8d4a2d b08c0f12 e2bbcd10 
[1:1:0713/001109.789128:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab65d3bd20, -2
[1:1:0713/001109.810532:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/001109.810922:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 120f8cb0
[1:1:0713/001109.811317:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 120f8cb0
[1:1:0713/001109.811932:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 120f8cb0
[1:1:0713/001109.813382:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.813590:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.813767:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.813942:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.814614:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 120f8cb0
[1:1:0713/001109.814909:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fab7dcb27ba
[1:1:0713/001109.815041:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fab7dca9def, 7fab7dcb277a, 7fab7dcb40cf
[1:1:0713/001109.820894:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 120f8cb0
[1:1:0713/001109.821265:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 120f8cb0
[1:1:0713/001109.821985:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 120f8cb0
[1:1:0713/001109.823975:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001109.824011:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.824329:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.824530:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.824721:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120f8cb0
[1:1:0713/001109.826324:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 120f8cb0
[1:1:0713/001109.826835:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fab7dcb27ba
[1:1:0713/001109.827018:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fab7dca9def, 7fab7dcb277a, 7fab7dcb40cf
[1:1:0713/001109.835688:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/001109.836172:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/001109.836331:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc9e902ab8, 0x7ffc9e902a38)
[1:1:0713/001109.848779:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/001109.853253:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/001110.126573:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x4ece9927220
[1:1:0713/001110.126766:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/001110.471936:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001110.472241:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[25488:25488:0713/001110.893779:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0713/001110.917506:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[25488:25488:0713/001110.918593:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[25488:25519:0713/001110.918959:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0713/001110.919155:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/001110.919349:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/001110.919758:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/001110.919905:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0713/001110.922396:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3e7fa070, 1
[1:1:0713/001110.922440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 24eb6692e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/001110.922766:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3b3c43e, 0
[1:1:0713/001110.923029:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x30b28c06, 3
[1:1:0713/001110.922846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/001110.923233:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x237063cb, 2
[1:1:0713/001110.923419:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3effffffc4ffffffb303 70ffffffa07f3e ffffffcb637023 06ffffff8cffffffb230 , 10104, 6
[1:1:0713/001110.924395:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25488:25519:0713/001110.924728:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING>ĳp�>�cp#��0��$
[25488:25519:0713/001110.924808:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is >ĳp�>�cp#��0��$
[25488:25519:0713/001110.925128:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25602, 6, 3ec4b303 70a07f3e cb637023 068cb230 
[1:1:0713/001110.924946:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab7beed0a0, 3
[1:1:0713/001110.925543:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab7c078080, 2
[1:1:0713/001110.925710:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fab65d3bd20, -2
[1:1:0713/001110.930778:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[25488:25488:0713/001110.948991:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/001110.949949:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/001110.950322:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 237063cb
[1:1:0713/001110.950667:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 237063cb
[1:1:0713/001110.951394:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 237063cb
[1:1:0713/001110.953199:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[1:1:0713/001110.953441:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[1:1:0713/001110.953698:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[1:1:0713/001110.953918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[1:1:0713/001110.954784:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 237063cb
[1:1:0713/001110.955142:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fab7dcb27ba
[1:1:0713/001110.955309:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fab7dca9def, 7fab7dcb277a, 7fab7dcb40cf
[1:1:0713/001110.962404:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 237063cb
[1:1:0713/001110.962897:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 237063cb
[1:1:0713/001110.963850:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 237063cb
[25488:25501:0713/001110.964063:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[25488:25501:0713/001110.964146:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[25488:25488:0713/001110.964220:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.cvf.org.cn/
[25488:25488:0713/001110.964261:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.cvf.org.cn/, https://www.cvf.org.cn/, 1
[25488:25488:0713/001110.964320:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.cvf.org.cn/, HTTP/1.1 200 status:200 server:Tengine date:Sat, 13 Jul 2019 07:09:06 GMT content-type:text/html; charset=utf-8 content-length:14446 set-cookie:PHPSESSID=39rrl7tdef630dm8ber1hbsev4; path=/; HttpOnly set-cookie:HttpOnly=true expires:Thu, 19 Nov 1981 08:52:00 GMT cache-control:no-store, no-cache, must-revalidate pragma:no-cache content-encoding:gzip vary:Accept-Encoding x-frame-options:SAMEORIGIN  ,0, 6
[1:1:0713/001110.966414:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[3:3:0713/001110.966583:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/001110.966739:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[1:1:0713/001110.967508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[1:1:0713/001110.967765:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 237063cb
[1:1:0713/001110.969234:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 237063cb
[1:1:0713/001110.969726:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fab7dcb27ba
[1:1:0713/001110.969896:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fab7dca9def, 7fab7dcb277a, 7fab7dcb40cf
[1:1:0713/001110.979435:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/001110.980222:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/001110.980396:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc9e902ab8, 0x7ffc9e902a38)
[1:1:0713/001110.996896:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/001111.001412:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0713/001111.058177:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/001111.227888:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x4ece993a220
[1:1:0713/001111.228712:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/001111.254736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001111.255470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24eb66801f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/001111.255726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001111.318298:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.cvf.org.cn/
[1:1:0713/001111.510573:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[25488:25488:0713/001111.541930:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.cvf.org.cn/, https://www.cvf.org.cn/, 1
[25488:25488:0713/001111.542059:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.cvf.org.cn/, https://www.cvf.org.cn
[1:1:0713/001111.628564:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001111.651009:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/001111.810845:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001111.811095:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.cvf.org.cn/"
[1:1:0713/001111.905518:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/001111.907413:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/001111.907624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 24eb6692e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/001111.907917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[25488:25501:0713/001111.964748:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0713/001112.046547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/001112.059606:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/001112.059880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 24eb6692e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/001112.060147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/001112.188069:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001112.327984:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_SSL_VERSION_INTERFERENCE","https://v.cvf.org.cn/app/api/site.all.js"
[1:1:0713/001112.495451:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fab65d56bd0 0x4ece9a31058 , "https://www.cvf.org.cn/"
[1:1:0713/001112.505095:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001112.514084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , /*! jQuery v1.7.1 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow
[1:1:0713/001112.514312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
		remove user.f_2a0b26ea -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/001112.733272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fab65d56bd0 0x4ece9a31058 , "https://www.cvf.org.cn/"
[1:1:0713/001112.759512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fab65d56bd0 0x4ece9a31058 , "https://www.cvf.org.cn/"
[1:1:0713/001112.763400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fab65d56bd0 0x4ece9a31058 , "https://www.cvf.org.cn/"
[1:1:0713/001112.771849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fab65d56bd0 0x4ece9a31058 , "https://www.cvf.org.cn/"
[1:1:0713/001112.778445:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fab65d56bd0 0x4ece9a31058 , "https://www.cvf.org.cn/"
[1:1:0713/001112.783402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fab65d56bd0 0x4ece9a31058 , "https://www.cvf.org.cn/"
[1:1:0713/001113.045429:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001113.047875:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001113.048267:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001113.048665:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001113.049092:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[25488:25501:0713/001133.211373:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0713/001133.301652:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_SSL_VERSION_INTERFERENCE","https://v.cvf.org.cn/app/api/top.status.php"
[1:1:0713/001133.310945:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/001133.314799:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x4ece9937a20
[1:1:0713/001133.315637:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0713/001133.323324:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/001133.323547:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.cvf.org.cn
[1:1:0713/001133.326256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 499 0x7fab7c078080 0x4ece9dbfce0 1 0 0x4ece9dbfcf8 , "https://www.cvf.org.cn/"
[1:1:0713/001133.327277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , 
            	function hasClass(ele,cls) { 
            		return ele.className.match(new RegExp('(\\
[1:1:0713/001133.327499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001133.486197:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.183323, 1072, 1
[1:1:0713/001133.486475:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001133.781806:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[25488:25515:0713/001133.815102:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/001135.138090:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001135.138351:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.cvf.org.cn/"
[1:1:0713/001135.139340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 594 0x7fab659ee070 0x4ecea03c560 , "https://www.cvf.org.cn/"
[1:1:0713/001135.140576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , 

        //飘窗
        $(function(){

            function rigScroll(){
                var winW
[1:1:0713/001135.140804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001135.145018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 594 0x7fab659ee070 0x4ecea03c560 , "https://www.cvf.org.cn/"
[1:1:0713/001135.152631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 594 0x7fab659ee070 0x4ecea03c560 , "https://www.cvf.org.cn/"
[1:1:0713/001135.165875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.cvf.org.cn/"
[1:1:0713/001137.255009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 6000
[1:1:0713/001137.255459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 676
[1:1:0713/001137.255683:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7fab659ee070 0x4ecea0ecf60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 594 0x7fab659ee070 0x4ecea03c560 
[1:1:0713/001137.439787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 4000
[1:1:0713/001137.440257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 688
[1:1:0713/001137.440509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7fab659ee070 0x4ecea605a60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 594 0x7fab659ee070 0x4ecea03c560 
[1:1:0713/001137.623098:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 3000
[1:1:0713/001137.623586:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 691
[1:1:0713/001137.623824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7fab659ee070 0x4ecea12fde0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 594 0x7fab659ee070 0x4ecea03c560 
[1:1:0713/001137.789443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://www.cvf.org.cn/"
[1:1:0713/001138.573350:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 ()","https://www.cvf.org.cn/templates/pc/zg/css/img/more_old.png"
[1:1:0713/001139.970765:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://www.cvf.org.cn/"
[1:1:0713/001140.486200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 721 0x7fab679162e0 0x4ece9f8c160 , "https://www.cvf.org.cn/"
[1:1:0713/001140.489522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (function(){var h={},mt={},c={id:"6587ec7f7f5cc8d073892a723bd81669",dm:["cvf.org.cn"],js:"tongji.bai
[1:1:0713/001140.489763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001140.520777:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af148
[1:1:0713/001140.521048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001140.521494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 743
[1:1:0713/001140.521713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7fab659ee070 0x4ece9a766e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 721 0x7fab679162e0 0x4ece9f8c160 
[25488:25488:0713/001150.031296:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[25488:25488:0713/001150.040578:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[25488:25488:0713/001150.047881:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[25488:25488:0713/001150.064020:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
[25488:25488:0713/001150.116929:INFO:CONSOLE(792)] "Uncaught TypeError: $(...).lazyload is not a function", source: https://www.cvf.org.cn/ (792)
[3:3:0713/001150.206177:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[25488:25488:0713/001150.374741:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25488:25488:0713/001150.381303:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25488:25501:0713/001150.422118:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[25488:25501:0713/001150.422233:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[25488:25488:0713/001150.427363:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://i.tianqi.com/
[25488:25488:0713/001150.427448:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://i.tianqi.com/, https://i.tianqi.com/index.php?c=code&id=11&icon=1, 4
[25488:25488:0713/001150.427581:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://i.tianqi.com/, HTTP/1.1 200 status:200 server:Tengine date:Sat, 13 Jul 2019 07:11:50 GMT content-type:text/html; charset=UTF-8 vary:Accept-Encoding expires:Sat, 13 Jul 2019 07:16:50 GMT pragma:cache cache-control:max-age=300 set-cookie:ipPy=beijing; expires=Mon, 12-Aug-2019 07:11:50 GMT; Max-Age=2592000; path=/ content-encoding:gzip  ,25602, 6
[1:7:0713/001150.429092:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:7:0713/001152.233319:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001152.403552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/001152.403868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001153.923502:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://i.tianqi.com/
[1:1:0713/001154.222928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 743, 7fab68333881
[1:1:0713/001154.247732:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"721 0x7fab679162e0 0x4ece9f8c160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.247928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"721 0x7fab679162e0 0x4ece9f8c160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.248162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001154.248481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001154.248589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001154.248977:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001154.249092:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001154.249278:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 837
[1:1:0713/001154.249391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7fab659ee070 0x4ecea95c7e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 743 0x7fab659ee070 0x4ece9a766e0 
[1:1:0713/001154.249878:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 691, 7fab683338db
[1:1:0713/001154.268557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"594 0x7fab659ee070 0x4ecea03c560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.268793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"594 0x7fab659ee070 0x4ecea03c560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.269017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 838
[1:1:0713/001154.269132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 838 0x7fab659ee070 0x4ecea9664e0 , 0:0_switcher://chrome, 0, , 691 0x7fab659ee070 0x4ecea12fde0 
[1:1:0713/001154.269297:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001154.269591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
				if(pagesize < img_size && pagesize >= 0)
				{
					silderList_li.eq(pagesize).fadeIn(100
[1:1:0713/001154.269728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001154.342073:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001154.470857:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 688, 7fab683338db
[1:1:0713/001154.505745:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"594 0x7fab659ee070 0x4ecea03c560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.506076:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"594 0x7fab659ee070 0x4ecea03c560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.506465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 841
[1:1:0713/001154.506668:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7fab659ee070 0x4ecea8ec8e0 , 0:0_switcher://chrome, 0, , 688 0x7fab659ee070 0x4ecea605a60 
[1:1:0713/001154.506901:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001154.507380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001154.507568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001154.519727:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001154.519942:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001154.520275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 842
[1:1:0713/001154.520461:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7fab659ee070 0x4ecea9bf5e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 688 0x7fab659ee070 0x4ecea605a60 
[1:1:0713/001154.569726:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 676, 7fab683338db
[1:1:0713/001154.606798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"594 0x7fab659ee070 0x4ecea03c560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.607141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"594 0x7fab659ee070 0x4ecea03c560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001154.608301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 849
[1:1:0713/001154.608495:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7fab659ee070 0x4ecea0adbe0 , 0:0_switcher://chrome, 0, , 676 0x7fab659ee070 0x4ecea0ecf60 
[1:1:0713/001154.608784:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001154.609287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001154.609464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001154.610391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001154.610552:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001154.610877:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 850
[1:1:0713/001154.611065:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7fab659ee070 0x4ecea8c4fe0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 676 0x7fab659ee070 0x4ecea0ecf60 
[1:1:0713/001155.497073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001155.497314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001156.245170:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[25488:25488:0713/001156.251853:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://i.tianqi.com/, https://i.tianqi.com/, 4
[25488:25488:0713/001156.251941:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://i.tianqi.com/, https://i.tianqi.com
[1:1:0713/001156.424572:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 837, 7fab68333881
[1:1:0713/001156.462753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"743 0x7fab659ee070 0x4ece9a766e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.463150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"743 0x7fab659ee070 0x4ece9a766e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.463570:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001156.464235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001156.464482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001156.465318:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001156.465540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001156.465960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 912
[1:1:0713/001156.466493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7fab659ee070 0x4ecea0a6260 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 837 0x7fab659ee070 0x4ecea95c7e0 
[1:1:0713/001156.657904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.cvf.org.cn/"
[1:1:0713/001156.658623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/001156.659348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001156.669406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 842, 7fab68333881
[1:1:0713/001156.713963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"688 0x7fab659ee070 0x4ecea605a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.714516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"688 0x7fab659ee070 0x4ecea605a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.714884:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001156.715602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001156.715867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001156.718240:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001156.718466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001156.718839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 918
[1:1:0713/001156.719080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7fab659ee070 0x4ecea2e68e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 842 0x7fab659ee070 0x4ecea9bf5e0 
[1:1:0713/001156.720649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 850, 7fab68333881
[1:1:0713/001156.735227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"676 0x7fab659ee070 0x4ecea0ecf60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.735559:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"676 0x7fab659ee070 0x4ecea0ecf60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.735895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001156.736522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001156.736730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001156.738562:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001156.738763:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001156.739114:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 920
[1:1:0713/001156.739358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7fab659ee070 0x4ecea8cf360 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 850 0x7fab659ee070 0x4ecea8c4fe0 
[1:1:0713/001156.872717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "durationchange", "https://www.cvf.org.cn/"
[1:1:0713/001156.874209:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadedmetadata", "https://www.cvf.org.cn/"
[1:1:0713/001156.875748:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadeddata", "https://www.cvf.org.cn/"
[1:1:0713/001156.877391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 849, 7fab683338db
[1:1:0713/001156.916241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"676 0x7fab659ee070 0x4ecea0ecf60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.916530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"676 0x7fab659ee070 0x4ecea0ecf60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001156.916895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 923
[1:1:0713/001156.917158:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 923 0x7fab659ee070 0x4ecea0d37e0 , 0:0_switcher://chrome, 0, , 849 0x7fab659ee070 0x4ecea0adbe0 
[1:1:0713/001156.917434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001156.917956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001156.918195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001156.926363:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001156.926609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001156.926969:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 924
[1:1:0713/001156.927207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 924 0x7fab659ee070 0x4ece9f6be60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 849 0x7fab659ee070 0x4ecea0adbe0 
[25488:25628:0713/001157.093428:WARNING:audio_sync_reader.cc(175)] ASR: No room in socket buffer.: Broken pipe (32)
[1:1:0713/001157.253450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001157.253798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001157.370341:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 838, 7fab683338db
[1:1:0713/001157.384414:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"691 0x7fab659ee070 0x4ecea12fde0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001157.384624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"691 0x7fab659ee070 0x4ecea12fde0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001157.384847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 933
[1:1:0713/001157.384968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 933 0x7fab659ee070 0x4ecea0dafe0 , 0:0_switcher://chrome, 0, , 838 0x7fab659ee070 0x4ecea9664e0 
[1:1:0713/001157.385122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001157.385455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
				if(pagesize < img_size && pagesize >= 0)
				{
					silderList_li.eq(pagesize).fadeIn(100
[1:1:0713/001157.385569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001157.397248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001157.397416:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001157.397591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 934
[1:1:0713/001157.397702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 934 0x7fab659ee070 0x4ece9c26ce0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 838 0x7fab659ee070 0x4ecea9664e0 
[1:1:0713/001157.400178:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 13
[1:1:0713/001157.400373:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 935
[1:1:0713/001157.400500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7fab659ee070 0x4ecea537e60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 838 0x7fab659ee070 0x4ecea9664e0 
[1:1:0713/001158.614409:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.cvf.org.cn/"
[1:1:0713/001158.614845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/001158.614964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001158.754290:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001159.043655:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 912, 7fab68333881
[1:1:0713/001159.083542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"837 0x7fab659ee070 0x4ecea95c7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.083839:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"837 0x7fab659ee070 0x4ecea95c7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.084162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001159.084688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001159.084871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001159.085529:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001159.085688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001159.086026:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 961
[1:1:0713/001159.086216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7fab659ee070 0x4ecea63fde0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 912 0x7fab659ee070 0x4ecea0a6260 
[1:1:0713/001159.254803:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 918, 7fab68333881
[1:1:0713/001159.282447:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"842 0x7fab659ee070 0x4ecea9bf5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.282636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"842 0x7fab659ee070 0x4ecea9bf5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.282830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001159.283140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001159.283258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001159.283688:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001159.283806:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001159.283976:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 964
[1:1:0713/001159.284083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 964 0x7fab659ee070 0x4ecea0d8660 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 918 0x7fab659ee070 0x4ecea2e68e0 
[1:1:0713/001159.298391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 924, 7fab68333881
[1:1:0713/001159.318013:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"849 0x7fab659ee070 0x4ecea0adbe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.318338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"849 0x7fab659ee070 0x4ecea0adbe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.318625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001159.319217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001159.319409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001159.322647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001159.322856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001159.323179:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 967
[1:1:0713/001159.323381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7fab659ee070 0x4eceaf216e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 924 0x7fab659ee070 0x4ece9f6be60 
[1:1:0713/001159.518593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001159.518830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001159.563980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 934, 7fab68333881
[1:1:0713/001159.605380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"838 0x7fab659ee070 0x4ecea9664e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.605672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"838 0x7fab659ee070 0x4ecea9664e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.606134:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001159.606864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001159.607127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001159.608890:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 935, 7fab683338db
[1:1:0713/001159.650817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"838 0x7fab659ee070 0x4ecea9664e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.651117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"838 0x7fab659ee070 0x4ecea9664e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.651506:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 973
[1:1:0713/001159.651990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7fab659ee070 0x4eceaf21e60 , 0:0_switcher://chrome, 0, , 935 0x7fab659ee070 0x4ecea537e60 
[1:1:0713/001159.652320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001159.652711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/001159.652837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001159.653496:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001159.653612:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001159.653793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 974
[1:1:0713/001159.653905:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7fab659ee070 0x4eceaf28ce0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 935 0x7fab659ee070 0x4ecea537e60 
[1:1:0713/001159.754920:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 841, 7fab683338db
[1:1:0713/001159.775790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"688 0x7fab659ee070 0x4ecea605a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.775993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"688 0x7fab659ee070 0x4ecea605a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001159.776186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 977
[1:1:0713/001159.776298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7fab659ee070 0x4ece9a3bee0 , 0:0_switcher://chrome, 0, , 841 0x7fab659ee070 0x4ecea8ec8e0 
[1:1:0713/001159.776441:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001159.776740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001159.776845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001159.780771:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001159.780899:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001159.781086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 978
[1:1:0713/001159.781205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 978 0x7fab659ee070 0x4ecea624260 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 841 0x7fab659ee070 0x4ecea8ec8e0 
[1:1:0713/001200.075681:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 933, 7fab683338db
[1:1:0713/001200.116967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"838 0x7fab659ee070 0x4ecea9664e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001200.117181:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"838 0x7fab659ee070 0x4ecea9664e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001200.117394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 982
[1:1:0713/001200.117542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7fab659ee070 0x4eceaa1d5e0 , 0:0_switcher://chrome, 0, , 933 0x7fab659ee070 0x4ecea0dafe0 
[1:1:0713/001200.117693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001200.118017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
				if(pagesize < img_size && pagesize >= 0)
				{
					silderList_li.eq(pagesize).fadeIn(100
[1:1:0713/001200.118128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001200.129397:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 13
[1:1:0713/001200.129656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 983
[1:1:0713/001200.129774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7fab659ee070 0x4eceab3f060 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 933 0x7fab659ee070 0x4ecea0dafe0 
[1:1:0713/001200.479287:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001200.479561:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001200.692736:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 961, 7fab68333881
[1:1:0713/001200.735123:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"912 0x7fab659ee070 0x4ecea0a6260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001200.735415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"912 0x7fab659ee070 0x4ecea0a6260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001200.735752:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001200.736285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001200.736490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001200.737133:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001200.737291:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001200.737769:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1001
[1:1:0713/001200.737984:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7fab659ee070 0x4eceb03aa60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 961 0x7fab659ee070 0x4ecea63fde0 
[1:1:0713/001200.939193:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 967, 7fab68333881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/001200.984265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"924 0x7fab659ee070 0x4ece9f6be60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001200.984551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"924 0x7fab659ee070 0x4ece9f6be60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001200.984798:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001200.985155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001200.985289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001200.986051:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001200.986158:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001200.986360:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1009
[1:1:0713/001200.986477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1009 0x7fab659ee070 0x4ecea96a860 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 967 0x7fab659ee070 0x4eceaf216e0 
[1:1:0713/001201.078603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001201.078868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001201.082317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 974, 7fab68333881
[1:1:0713/001201.128505:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"935 0x7fab659ee070 0x4ecea537e60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.128828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"935 0x7fab659ee070 0x4ecea537e60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.129174:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001201.129678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001201.129850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001201.131199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 978, 7fab68333881
[1:1:0713/001201.171322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"841 0x7fab659ee070 0x4ecea8ec8e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.171491:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"841 0x7fab659ee070 0x4ecea8ec8e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.171696:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001201.171977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001201.172081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001201.172529:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001201.172642:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001201.172807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1013
[1:1:0713/001201.172913:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7fab659ee070 0x4ecea96abe0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 978 0x7fab659ee070 0x4ecea624260 
[1:1:0713/001201.281158:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 983, 7fab683338db
[1:1:0713/001201.326389:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"933 0x7fab659ee070 0x4ecea0dafe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.326732:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"933 0x7fab659ee070 0x4ecea0dafe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.327112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1017
[1:1:0713/001201.327352:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7fab659ee070 0x4ecea0f9f60 , 0:0_switcher://chrome, 0, , 983 0x7fab659ee070 0x4eceab3f060 
[1:1:0713/001201.327730:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001201.328272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/001201.328508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001201.329563:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001201.329762:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001201.330124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1018
[1:1:0713/001201.330375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1018 0x7fab659ee070 0x4eceb0590e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 983 0x7fab659ee070 0x4eceab3f060 
[1:1:0713/001201.892925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1001, 7fab68333881
[1:1:0713/001201.925671:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"961 0x7fab659ee070 0x4ecea63fde0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.926033:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"961 0x7fab659ee070 0x4ecea63fde0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001201.926402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001201.926958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001201.927197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001201.927882:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001201.928041:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001201.928387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1033
[1:1:0713/001201.928577:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1033 0x7fab659ee070 0x4eceab417e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1001 0x7fab659ee070 0x4eceb03aa60 
[1:1:0713/001202.332509:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1009, 7fab68333881
[1:1:0713/001202.375891:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"967 0x7fab659ee070 0x4eceaf216e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.376192:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"967 0x7fab659ee070 0x4eceaf216e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.376528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001202.377121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001202.377298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.378951:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001202.379153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001202.379476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1043
[1:1:0713/001202.379666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1043 0x7fab659ee070 0x4eceb0e75e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1009 0x7fab659ee070 0x4ecea96a860 
[1:1:0713/001202.381069:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1013, 7fab68333881
[1:1:0713/001202.423432:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"978 0x7fab659ee070 0x4ecea624260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.423720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"978 0x7fab659ee070 0x4ecea624260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.424053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001202.424615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001202.424789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.425683:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001202.425841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001202.426170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1045
[1:1:0713/001202.426356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7fab659ee070 0x4eceaff97e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1013 0x7fab659ee070 0x4ecea96abe0 
[1:1:0713/001202.473335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001202.473513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.474770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 923, 7fab683338db
[1:1:0713/001202.488905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"849 0x7fab659ee070 0x4ecea0adbe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.489087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"849 0x7fab659ee070 0x4ecea0adbe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.489304:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1049
[1:1:0713/001202.489430:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1049 0x7fab659ee070 0x4ecea0f9560 , 0:0_switcher://chrome, 0, , 923 0x7fab659ee070 0x4ecea0d37e0 
[1:1:0713/001202.489633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001202.489939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001202.490049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.490470:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001202.490570:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001202.490729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1050
[1:1:0713/001202.490845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1050 0x7fab659ee070 0x4ecea8d8f60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 923 0x7fab659ee070 0x4ecea0d37e0 
[1:1:0713/001202.506185:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1018, 7fab68333881
[1:1:0713/001202.520062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"983 0x7fab659ee070 0x4eceab3f060 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.520242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"983 0x7fab659ee070 0x4eceab3f060 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.520443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001202.520740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001202.520845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.521400:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 977, 7fab683338db
[1:1:0713/001202.540364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"841 0x7fab659ee070 0x4ecea8ec8e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.540636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"841 0x7fab659ee070 0x4ecea8ec8e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.540995:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1052
[1:1:0713/001202.541209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1052 0x7fab659ee070 0x4eceb03a660 , 0:0_switcher://chrome, 0, , 977 0x7fab659ee070 0x4ece9a3bee0 
[1:1:0713/001202.541520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001202.542034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001202.542213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.543173:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001202.543326:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001202.543619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1053
[1:1:0713/001202.543797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1053 0x7fab659ee070 0x4eceb0edc60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 977 0x7fab659ee070 0x4ece9a3bee0 
[1:1:0713/001202.586144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 982, 7fab683338db
[1:1:0713/001202.603534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"933 0x7fab659ee070 0x4ecea0dafe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.603721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"933 0x7fab659ee070 0x4ecea0dafe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.603961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1055
[1:1:0713/001202.604078:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1055 0x7fab659ee070 0x4eceab41d60 , 0:0_switcher://chrome, 0, , 982 0x7fab659ee070 0x4eceaa1d5e0 
[1:1:0713/001202.604264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001202.604556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
				if(pagesize < img_size && pagesize >= 0)
				{
					silderList_li.eq(pagesize).fadeIn(100
[1:1:0713/001202.604664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.614341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001202.614502:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001202.614673:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1056
[1:1:0713/001202.614786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1056 0x7fab659ee070 0x4eceaf28ce0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 982 0x7fab659ee070 0x4eceaa1d5e0 
[1:1:0713/001202.616055:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 13
[1:1:0713/001202.616226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1057
[1:1:0713/001202.616335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1057 0x7fab659ee070 0x4eceb0387e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 982 0x7fab659ee070 0x4eceaa1d5e0 
[1:1:0713/001202.967885:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1033, 7fab68333881
[1:1:0713/001202.991791:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1001 0x7fab659ee070 0x4eceb03aa60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.991989:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1001 0x7fab659ee070 0x4eceb03aa60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001202.992261:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001202.992571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001202.992680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001202.992990:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001202.993107:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001202.993284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1068
[1:1:0713/001202.993400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1068 0x7fab659ee070 0x4ecea0e9760 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1033 0x7fab659ee070 0x4eceab417e0 
[1:1:0713/001203.476956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001203.477222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001203.480390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1050, 7fab68333881
[1:1:0713/001203.524095:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"923 0x7fab659ee070 0x4ecea0d37e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.524417:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"923 0x7fab659ee070 0x4ecea0d37e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.524709:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001203.525301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001203.525479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001203.527163:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001203.527452:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001203.527920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1077
[1:1:0713/001203.528244:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7fab659ee070 0x4eceaf89e60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1050 0x7fab659ee070 0x4ecea8d8f60 
[1:1:0713/001203.529807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1053, 7fab68333881
[1:1:0713/001203.574047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"977 0x7fab659ee070 0x4ece9a3bee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.574401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"977 0x7fab659ee070 0x4ece9a3bee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.574722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001203.575311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001203.575486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001203.576421:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001203.576581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001203.577037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1079
[1:1:0713/001203.577249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7fab659ee070 0x4eceab41f60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1053 0x7fab659ee070 0x4eceb0edc60 
[1:1:0713/001203.632749:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1056, 7fab68333881
[1:1:0713/001203.678129:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"982 0x7fab659ee070 0x4eceaa1d5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.678588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"982 0x7fab659ee070 0x4eceaa1d5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.679058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001203.679602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001203.679777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001203.725626:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1057, 7fab683338db
[1:1:0713/001203.770058:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"982 0x7fab659ee070 0x4eceaa1d5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.770372:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"982 0x7fab659ee070 0x4eceaa1d5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001203.770701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1082
[1:1:0713/001203.770892:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1082 0x7fab659ee070 0x4eceb0e9de0 , 0:0_switcher://chrome, 0, , 1057 0x7fab659ee070 0x4eceb0387e0 
[1:1:0713/001203.771227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001203.771718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/001203.771903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001203.772838:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001203.773097:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001203.773459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1083
[1:1:0713/001203.773660:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7fab659ee070 0x4eceb0667e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1057 0x7fab659ee070 0x4eceb0387e0 
[1:1:0713/001203.943220:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1066 0x7fab65d56bd0 0x4eceb0e58d8 , "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001203.964238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , , /*! jQuery v1.8.2 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};ret
[1:1:0713/001203.964549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001204.195902:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001204.196409:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001204.207448:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1066 0x7fab65d56bd0 0x4eceb0e58d8 , "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001204.220059:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1066 0x7fab65d56bd0 0x4eceb0e58d8 , "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001204.226792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1", 40
[1:1:0713/001204.227390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1097
[1:1:0713/001204.227589:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7fab659ee070 0x4ecea0abfe0 , 6:4_https://i.tianqi.com/, 1, -6:4_https://i.tianqi.com/, 1066 0x7fab65d56bd0 0x4eceb0e58d8 
[1:1:0713/001204.230730:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1066 0x7fab65d56bd0 0x4eceb0e58d8 , "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001204.321997:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1069, "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001204.325800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , , (function(){function p(){this.c="1277635480";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0713/001204.326005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001204.447642:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1068, 7fab68333881
[1:1:0713/001204.487988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1033 0x7fab659ee070 0x4eceab417e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001204.488293:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1033 0x7fab659ee070 0x4eceab417e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001204.488705:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001204.489248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001204.489486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001204.490113:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001204.490269:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001204.490706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1119
[1:1:0713/001204.490974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1119 0x7fab659ee070 0x4ecea622fe0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1068 0x7fab659ee070 0x4ecea0e9760 
[1:1:0713/001204.594007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001204.594193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001204.865700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1077, 7fab68333881
[1:1:0713/001204.916355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1050 0x7fab659ee070 0x4ecea8d8f60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001204.916714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1050 0x7fab659ee070 0x4ecea8d8f60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001204.917122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001204.917822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001204.918104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001204.919731:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001204.919932:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001204.920325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1139
[1:1:0713/001204.920590:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1139 0x7fab659ee070 0x4ecea95c2e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1077 0x7fab659ee070 0x4eceaf89e60 
[1:1:0713/001204.962644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1079, 7fab68333881
[1:1:0713/001205.008135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1053 0x7fab659ee070 0x4eceb0edc60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001205.008477:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1053 0x7fab659ee070 0x4eceb0edc60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001205.008886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001205.009530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001205.009749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001205.010755:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001205.010977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001205.011343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1143
[1:1:0713/001205.011628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1143 0x7fab659ee070 0x4eceb1c8260 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1079 0x7fab659ee070 0x4eceab41f60 
[1:1:0713/001205.106925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1083, 7fab68333881
[1:1:0713/001205.131814:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1057 0x7fab659ee070 0x4eceb0387e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001205.132149:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1057 0x7fab659ee070 0x4eceb0387e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001205.132584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001205.133115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001205.133324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001205.622399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1097, 7fab683338db
[1:1:0713/001205.669063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af407b3678","ptid":"1066 0x7fab65d56bd0 0x4eceb0e58d8 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001205.669404:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:4_https://i.tianqi.com/","ptid":"1066 0x7fab65d56bd0 0x4eceb0e58d8 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001205.669910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1153
[1:1:0713/001205.670184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1153 0x7fab659ee070 0x4ece96a74e0 , 6:4_https://i.tianqi.com/, 0, , 1097 0x7fab659ee070 0x4ecea0abfe0 
[1:1:0713/001205.670563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001205.671169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , Marquee, (){
    if(header_demo2.offsetWidth-header_demo.scrollLeft<=0)
    header_demo.scrollLeft-=header_
[1:1:0713/001205.671425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001206.199262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1118, "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001206.201178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0713/001206.201458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001206.215499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1118, "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001206.224731:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001206.285932:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1119, 7fab68333881
[1:1:0713/001206.337079:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1068 0x7fab659ee070 0x4ecea0e9760 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001206.337372:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1068 0x7fab659ee070 0x4ecea0e9760 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001206.337740:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001206.338328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001206.338503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001206.339179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001206.339338:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001206.339649:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1167
[1:1:0713/001206.339850:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7fab659ee070 0x4eceb3b99e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1119 0x7fab659ee070 0x4ecea622fe0 
[1:1:0713/001206.394378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001206.394677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001206.518028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1055, 7fab683338db
[1:1:0713/001206.539021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"982 0x7fab659ee070 0x4eceaa1d5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001206.539293:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"982 0x7fab659ee070 0x4eceaa1d5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001206.539679:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1176
[1:1:0713/001206.539876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7fab659ee070 0x4eceb1cab60 , 0:0_switcher://chrome, 0, , 1055 0x7fab659ee070 0x4eceab41d60 
[1:1:0713/001206.540206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001206.540712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
				if(pagesize < img_size && pagesize >= 0)
				{
					silderList_li.eq(pagesize).fadeIn(100
[1:1:0713/001206.540900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001206.565592:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001206.565811:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001206.566158:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1177
[1:1:0713/001206.566350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7fab659ee070 0x4eceb3a2c60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1055 0x7fab659ee070 0x4eceab41d60 
[1:1:0713/001206.569018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 13
[1:1:0713/001206.569462:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1178
[1:1:0713/001206.569648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1178 0x7fab659ee070 0x4eceb0e75e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1055 0x7fab659ee070 0x4eceab41d60 
[1:1:0713/001207.408157:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1139, 7fab68333881
[1:1:0713/001207.447613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1077 0x7fab659ee070 0x4eceaf89e60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001207.447805:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1077 0x7fab659ee070 0x4eceaf89e60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001207.448026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001207.448394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001207.448505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001207.449313:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001207.449425:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001207.449610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1193
[1:1:0713/001207.449734:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1193 0x7fab659ee070 0x4eceb45e560 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1139 0x7fab659ee070 0x4ecea95c2e0 
[1:1:0713/001207.529961:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1143, 7fab68333881
[1:1:0713/001207.546559:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1079 0x7fab659ee070 0x4eceab41f60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001207.546749:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1079 0x7fab659ee070 0x4eceab41f60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001207.546944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001207.547382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001207.547566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001207.548288:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001207.548393:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001207.548564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1197
[1:1:0713/001207.548674:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1197 0x7fab659ee070 0x4eceaa57be0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1143 0x7fab659ee070 0x4eceb1c8260 
[1:1:0713/001207.549209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1052, 7fab683338db
[1:1:0713/001207.565109:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"977 0x7fab659ee070 0x4ece9a3bee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001207.565308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"977 0x7fab659ee070 0x4ece9a3bee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001207.565509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1198
[1:1:0713/001207.565623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1198 0x7fab659ee070 0x4ecea0d6660 , 0:0_switcher://chrome, 0, , 1052 0x7fab659ee070 0x4eceb03a660 
[1:1:0713/001207.565819:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001207.566101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001207.566257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001207.566671:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001207.566770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001207.566936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1199
[1:1:0713/001207.567044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1199 0x7fab659ee070 0x4eceb1ca260 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1052 0x7fab659ee070 0x4eceb03a660 
[1:1:0713/001207.603459:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1151 0x7fab679162e0 0x4eceab9e260 , "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001207.606626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , , (function(){var h={},mt={},c={id:"86f43783acc56b0c8abb5bb039edc763",dm:["tianqi3.com"],js:"tongji.ba
[1:1:0713/001207.606781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001207.627132:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27d2ff08, 0x4ece97af140
[1:1:0713/001207.627360:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1", 100
[1:1:0713/001207.627751:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://i.tianqi.com/, 1202
[1:1:0713/001207.627939:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1202 0x7fab659ee070 0x4ecea9517e0 , 6:4_https://i.tianqi.com/, 1, -6:4_https://i.tianqi.com/, 1151 0x7fab679162e0 0x4eceab9e260 
[1:1:0713/001207.798326:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1153, 7fab683338db
[1:1:0713/001207.847837:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1097 0x7fab659ee070 0x4ecea0abfe0 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001207.848117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1097 0x7fab659ee070 0x4ecea0abfe0 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001207.848545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1232
[1:1:0713/001207.848738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1232 0x7fab659ee070 0x4eceb2b28e0 , 6:4_https://i.tianqi.com/, 0, , 1153 0x7fab659ee070 0x4ece96a74e0 
[1:1:0713/001207.849081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001207.849676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , Marquee, (){
    if(header_demo2.offsetWidth-header_demo.scrollLeft<=0)
    header_demo.scrollLeft-=header_
[1:1:0713/001207.849905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001208.031675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001208.031848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001208.068781:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1167, 7fab68333881
[1:1:0713/001208.097247:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1119 0x7fab659ee070 0x4ecea622fe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.097456:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1119 0x7fab659ee070 0x4ecea622fe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.097680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001208.097991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001208.098095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001208.098441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001208.098546:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001208.098716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1239
[1:1:0713/001208.098830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1239 0x7fab659ee070 0x4eceb48e8e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1167 0x7fab659ee070 0x4eceb3b99e0 
[1:1:0713/001208.235191:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001208.235697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/001208.235847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001208.360425:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1177, 7fab68333881
[1:1:0713/001208.377114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1055 0x7fab659ee070 0x4eceab41d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.377288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1055 0x7fab659ee070 0x4eceab41d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.377517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001208.377821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001208.377926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001208.378408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1178, 7fab683338db
[1:1:0713/001208.401801:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1055 0x7fab659ee070 0x4eceab41d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.402098:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1055 0x7fab659ee070 0x4eceab41d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.402477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1244
[1:1:0713/001208.402685:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1244 0x7fab659ee070 0x4eceaf5cb60 , 0:0_switcher://chrome, 0, , 1178 0x7fab659ee070 0x4eceb0e75e0 
[1:1:0713/001208.403021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001208.403533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/001208.403711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001208.404645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001208.404804:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001208.405255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1245
[1:1:0713/001208.405460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1245 0x7fab659ee070 0x4eceb4984e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1178 0x7fab659ee070 0x4eceb0e75e0 
[1:1:0713/001208.579877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1049, 7fab683338db
[1:1:0713/001208.621170:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"923 0x7fab659ee070 0x4ecea0d37e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.621462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"923 0x7fab659ee070 0x4ecea0d37e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001208.621830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1253
[1:1:0713/001208.622034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1253 0x7fab659ee070 0x4ece96a7160 , 0:0_switcher://chrome, 0, , 1049 0x7fab659ee070 0x4ecea0f9560 
[1:1:0713/001208.622337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001208.622842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001208.623014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001208.634743:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001208.635029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001208.635504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1254
[1:1:0713/001208.635781:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1254 0x7fab659ee070 0x4ece96aad60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1049 0x7fab659ee070 0x4ecea0f9560 
[1:1:0713/001209.052660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1199, 7fab68333881
[1:1:0713/001209.113926:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1052 0x7fab659ee070 0x4eceb03a660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001209.114310:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1052 0x7fab659ee070 0x4eceb03a660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001209.114808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001209.115519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001209.115762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001209.116905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001209.117104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001209.117508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1270
[1:1:0713/001209.117773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7fab659ee070 0x4eceb3755e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1199 0x7fab659ee070 0x4eceb1ca260 
[1:1:0713/001210.259654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1176, 7fab683338db
[1:1:0713/001210.302990:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1055 0x7fab659ee070 0x4eceab41d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001210.303173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1055 0x7fab659ee070 0x4eceab41d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001210.303390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1287
[1:1:0713/001210.303516:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1287 0x7fab659ee070 0x4ecea0d2560 , 0:0_switcher://chrome, 0, , 1176 0x7fab659ee070 0x4eceb1cab60 
[1:1:0713/001210.303732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001210.304060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
				if(pagesize < img_size && pagesize >= 0)
				{
					silderList_li.eq(pagesize).fadeIn(100
[1:1:0713/001210.304168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001210.314534:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 13
[1:1:0713/001210.314744:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1288
[1:1:0713/001210.314881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1288 0x7fab659ee070 0x4eceb372be0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1176 0x7fab659ee070 0x4eceb1cab60 
[1:1:0713/001210.550272:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://i.tianqi.com/, 1202, 7fab68333881
[1:1:0713/001210.597465:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af407b3678","ptid":"1151 0x7fab679162e0 0x4eceab9e260 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001210.597787:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:4_https://i.tianqi.com/","ptid":"1151 0x7fab679162e0 0x4eceab9e260 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001210.598212:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001210.598807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001210.599059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001210.599847:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27d2ff08, 0x4ece97af150
[1:1:0713/001210.600028:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1", 100
[1:1:0713/001210.600423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://i.tianqi.com/, 1295
[1:1:0713/001210.600609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1295 0x7fab659ee070 0x4eceb1c7060 , 6:4_https://i.tianqi.com/, 1, -6:4_https://i.tianqi.com/, 1202 0x7fab659ee070 0x4ecea9517e0 
[1:1:0713/001210.695282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1232, 7fab683338db
[1:1:0713/001210.722404:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1153 0x7fab659ee070 0x4ece96a74e0 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001210.722688:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1153 0x7fab659ee070 0x4ece96a74e0 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001210.723166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1303
[1:1:0713/001210.723363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7fab659ee070 0x4eceb574de0 , 6:4_https://i.tianqi.com/, 0, , 1232 0x7fab659ee070 0x4eceb2b28e0 
[1:1:0713/001210.723685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001210.724270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , Marquee, (){
    if(header_demo2.offsetWidth-header_demo.scrollLeft<=0)
    header_demo.scrollLeft-=header_
[1:1:0713/001210.724499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001210.855213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , document.readyState
[1:1:0713/001210.855453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001210.966930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001210.967682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/001210.967901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001210.970217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1239, 7fab68333881
[1:1:0713/001211.019398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1167 0x7fab659ee070 0x4eceb3b99e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.019707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1167 0x7fab659ee070 0x4eceb3b99e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.021167:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001211.021702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001211.021880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001211.022580:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001211.022740:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001211.023094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1309
[1:1:0713/001211.023304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1309 0x7fab659ee070 0x4ece99590e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1239 0x7fab659ee070 0x4eceb48e8e0 
[1:1:0713/001211.114370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1245, 7fab68333881
[1:1:0713/001211.131205:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1178 0x7fab659ee070 0x4eceb0e75e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.131380:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1178 0x7fab659ee070 0x4eceb0e75e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.131609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001211.131917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001211.132097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001211.274735:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1254, 7fab68333881
[1:1:0713/001211.323033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1049 0x7fab659ee070 0x4ecea0f9560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.323350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1049 0x7fab659ee070 0x4ecea0f9560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.323689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001211.324279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001211.324462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001211.326308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001211.326537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001211.326973:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1314
[1:1:0713/001211.327237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7fab659ee070 0x4eceb5861e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1254 0x7fab659ee070 0x4ece96aad60 
[1:1:0713/001211.652388:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1270, 7fab68333881
[1:1:0713/001211.703753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1199 0x7fab659ee070 0x4eceb1ca260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.704052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1199 0x7fab659ee070 0x4eceb1ca260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.704466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001211.705042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001211.705263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001211.706254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001211.706417:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001211.706738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1320
[1:1:0713/001211.706921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7fab659ee070 0x4eceb586ae0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1270 0x7fab659ee070 0x4eceb3755e0 
[1:1:0713/001211.749517:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1198, 7fab683338db
[1:1:0713/001211.799440:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1052 0x7fab659ee070 0x4eceb03a660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.799703:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1052 0x7fab659ee070 0x4eceb03a660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001211.800105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1326
[1:1:0713/001211.800315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7fab659ee070 0x4eceb36a6e0 , 0:0_switcher://chrome, 0, , 1198 0x7fab659ee070 0x4ecea0d6660 
[1:1:0713/001211.800621:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001211.801126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
					rollFunc();
				}
[1:1:0713/001211.801322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001211.802179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001211.802366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001211.802668:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1327
[1:1:0713/001211.802851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7fab659ee070 0x4eceb577760 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1198 0x7fab659ee070 0x4ecea0d6660 
[1:1:0713/001212.099309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1288, 7fab683338db
[1:1:0713/001212.156980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1176 0x7fab659ee070 0x4eceb1cab60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.157308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1176 0x7fab659ee070 0x4eceb1cab60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.157723:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1338
[1:1:0713/001212.157916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7fab659ee070 0x4eceb5a2ae0 , 0:0_switcher://chrome, 0, , 1288 0x7fab659ee070 0x4eceb372be0 
[1:1:0713/001212.158256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001212.158785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/001212.158965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001212.159894:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001212.160053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001212.160380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1339
[1:1:0713/001212.160568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1339 0x7fab659ee070 0x4eceb5922e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1288 0x7fab659ee070 0x4eceb372be0 
[25488:25488:0713/001212.281364:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0713/001212.301786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1287, 7fab683338db
[1:1:0713/001212.351124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1176 0x7fab659ee070 0x4eceb1cab60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.351310:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1176 0x7fab659ee070 0x4eceb1cab60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.351549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1345
[1:1:0713/001212.351662:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7fab659ee070 0x4eceb48e8e0 , 0:0_switcher://chrome, 0, , 1287 0x7fab659ee070 0x4ecea0d2560 
[1:1:0713/001212.351847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001212.352144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , , (){
				if(pagesize < img_size && pagesize >= 0)
				{
					silderList_li.eq(pagesize).fadeIn(100
[1:1:0713/001212.352252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001212.366161:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 13
[1:1:0713/001212.366493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1346
[1:1:0713/001212.366631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1346 0x7fab659ee070 0x4ece995c7e0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1287 0x7fab659ee070 0x4ecea0d2560 
[1:1:0713/001212.468040:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001212.468786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/001212.469009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001212.477392:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001212.478181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001212.481916:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001212.483698:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27d2ff08, 0x4ece97af2f0
[1:1:0713/001212.483933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1", 100
[1:1:0713/001212.484447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://i.tianqi.com/, 1351
[1:1:0713/001212.484711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1351 0x7fab659ee070 0x4eceb36aa60 , 6:4_https://i.tianqi.com/, 1, -6:4_https://i.tianqi.com/, 1301 0x7fab659ee070 0x4eceb45ede0 
[1:1:0713/001212.492712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.cvf.org.cn/"
[1:1:0713/001212.493318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -6:4_https://i.tianqi.com/-6:3_https://www.cvf.org.cn/, 24af406a2860, 24af407b3678, ready, (a){if(a===!0&&!--e.readyWait||a!==!0&&!e.isReady){if(!c.body)return setTimeout(e.ready,1);e.isReady
[1:1:0713/001212.493536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 2, , , 0
[1:1:0713/001212.493879:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0713/001212.494092:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.cvf.org.cn/"
[1:1:0713/001212.496233:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://www.cvf.org.cn/"
[1:1:0713/001212.497437:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1eba27c229c8, 0x4ece97af268
[1:1:0713/001212.497598:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 100
[1:1:0713/001212.497907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://i.tianqi.com/, 1354
[1:1:0713/001212.498093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1354 0x7fab659ee070 0x4eceb48ece0 , 6:4_https://i.tianqi.com/, 2, -6:4_https://i.tianqi.com/-6:3_https://www.cvf.org.cn/, 1301 0x7fab659ee070 0x4eceb45ede0 
[1:1:0713/001212.540744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1303, 7fab683338db
[1:1:0713/001212.594845:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1232 0x7fab659ee070 0x4eceb2b28e0 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001212.595106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1232 0x7fab659ee070 0x4eceb2b28e0 ","rf":"6:4_https://i.tianqi.com/"}
[1:1:0713/001212.595532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://i.tianqi.com/, 1358
[1:1:0713/001212.595722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1358 0x7fab659ee070 0x4eceb5868e0 , 6:4_https://i.tianqi.com/, 0, , 1303 0x7fab659ee070 0x4eceb574de0 
[1:1:0713/001212.596039:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://i.tianqi.com/index.php?c=code&id=11&icon=1"
[1:1:0713/001212.596645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://i.tianqi.com/, 24af407b3678, , Marquee, (){
    if(header_demo2.offsetWidth-header_demo.scrollLeft<=0)
    header_demo.scrollLeft-=header_
[1:1:0713/001212.596867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://i.tianqi.com/index.php?c=code&id=11&icon=1", "i.tianqi.com", 4, 1, https://www.cvf.org.cn, www.cvf.org.cn, 3
[1:1:0713/001212.716515:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1314, 7fab68333881
[1:1:0713/001212.767485:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1254 0x7fab659ee070 0x4ece96aad60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.767740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1254 0x7fab659ee070 0x4ece96aad60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.768106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001212.768678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001212.768853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001212.770307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001212.770507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001212.770815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1365
[1:1:0713/001212.770997:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1365 0x7fab659ee070 0x4eceb59de60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1314 0x7fab659ee070 0x4eceb5861e0 
[1:1:0713/001212.903144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1327, 7fab68333881
[1:1:0713/001212.919203:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1198 0x7fab659ee070 0x4ecea0d6660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.919385:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1198 0x7fab659ee070 0x4ecea0d6660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001212.919575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001212.919888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0713/001212.919992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001212.920417:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001212.920579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 10
[1:1:0713/001212.920963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1370
[1:1:0713/001212.921151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1370 0x7fab659ee070 0x4eceb59dce0 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1327 0x7fab659ee070 0x4eceb577760 
[1:1:0713/001213.289730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1339, 7fab68333881
[1:1:0713/001213.325054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1288 0x7fab659ee070 0x4eceb372be0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001213.325237:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1288 0x7fab659ee070 0x4eceb372be0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001213.325480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001213.325898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , ct, (){cr=b}
[1:1:0713/001213.326066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001213.390615:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1346, 7fab683338db
[1:1:0713/001213.449368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24af406a2860","ptid":"1287 0x7fab659ee070 0x4ecea0d2560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001213.449725:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.cvf.org.cn/","ptid":"1287 0x7fab659ee070 0x4ecea0d2560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/001213.450085:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1384
[1:1:0713/001213.450272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1384 0x7fab659ee070 0x4eceb5823e0 , 0:0_switcher://chrome, 0, , 1346 0x7fab659ee070 0x4ece995c7e0 
[1:1:0713/001213.450578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.cvf.org.cn/"
[1:1:0713/001213.451118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.cvf.org.cn/, 24af406a2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0713/001213.451357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.cvf.org.cn/", "www.cvf.org.cn", 3, 1, , , 0
[1:1:0713/001213.452327:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1eba27c229c8, 0x4ece97af150
[1:1:0713/001213.452487:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.cvf.org.cn/", 0
[1:1:0713/001213.452816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1385
[1:1:0713/001213.453001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1385 0x7fab659ee070 0x4eceb59ad60 , 0:0_switcher://chrome, 1, -6:3_https://www.cvf.org.cn/, 1346 0x7fab659ee070 0x4ece995c7e0 
