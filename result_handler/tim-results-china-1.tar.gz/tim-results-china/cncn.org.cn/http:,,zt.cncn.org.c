[0713/001527.528107:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001527.528506:INFO:switcher_clone.cc(787)] backtrace rip is 7f48f9009891
[0713/001528.574777:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001528.575041:INFO:switcher_clone.cc(787)] backtrace rip is 7fac06554891
[1:1:0713/001528.579022:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/001528.579206:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/001528.584212:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[26023:26023:0713/001529.699753:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/efb877eb-c540-441a-b1cb-9e4f473bbe3e
[0713/001529.859035:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/001529.859430:INFO:switcher_clone.cc(787)] backtrace rip is 7fb077877891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[26056:26056:0713/001530.063333:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26056
[26068:26068:0713/001530.063794:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26068
[26023:26023:0713/001530.234669:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26023:26054:0713/001530.235523:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/001530.235714:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/001530.235985:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/001530.236546:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/001530.236687:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/001530.239508:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xa097eaa, 1
[1:1:0713/001530.239903:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x258428f5, 0
[1:1:0713/001530.240095:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d07e150, 3
[1:1:0713/001530.240284:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3beb184d, 2
[1:1:0713/001530.240507:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff528ffffff8425 ffffffaa7e090a 4d18ffffffeb3b 50ffffffe1072d , 10104, 4
[1:1:0713/001530.241481:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26023:26054:0713/001530.241762:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�(�%�~	
M�;P�-h�

[26023:26054:0713/001530.241827:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �(�%�~	
M�;P�-(�h�

[1:1:0713/001530.241765:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac0478f0a0, 3
[1:1:0713/001530.242006:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac0491a080, 2
[26023:26054:0713/001530.242137:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/001530.242154:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fabee5ddd20, -2
[26023:26054:0713/001530.242209:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26076, 4, f5288425 aa7e090a 4d18eb3b 50e1072d 
[1:1:0713/001530.265355:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/001530.266130:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3beb184d
[1:1:0713/001530.266814:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3beb184d
[1:1:0713/001530.267865:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3beb184d
[1:1:0713/001530.268386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.268488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.268586:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.268689:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.268925:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3beb184d
[1:1:0713/001530.269063:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac065547ba
[1:1:0713/001530.269140:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac0654bdef, 7fac0655477a, 7fac065560cf
[1:1:0713/001530.271116:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3beb184d
[1:1:0713/001530.271340:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3beb184d
[1:1:0713/001530.271763:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3beb184d
[1:1:0713/001530.272808:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.272955:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.273094:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.273227:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3beb184d
[1:1:0713/001530.273928:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3beb184d
[1:1:0713/001530.274144:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac065547ba
[1:1:0713/001530.274252:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac0654bdef, 7fac0655477a, 7fac065560cf
[1:1:0713/001530.277666:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/001530.278008:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/001530.278132:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe90bd46c8, 0x7ffe90bd4648)
[1:1:0713/001530.295944:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/001530.301860:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26023:26023:0713/001530.916787:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26023:26023:0713/001530.917965:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26023:26035:0713/001530.938235:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26023:26035:0713/001530.938358:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[26023:26023:0713/001530.938528:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26023:26023:0713/001530.938675:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26023:26023:0713/001530.938845:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26076, 4
[1:7:0713/001530.944193:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[26023:26048:0713/001530.991401:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/001531.035058:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xbf706f6b220
[1:1:0713/001531.035354:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/001531.463612:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[26023:26023:0713/001533.099106:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26023:26023:0713/001533.099222:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/001533.144965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001533.148534:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/001534.332579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e1c07481f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/001534.332894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001534.348990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e1c07481f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/001534.349180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001534.437531:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001534.679720:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001534.679915:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001534.897269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001534.905264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e1c07481f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/001534.905450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001534.939498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001534.949789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e1c07481f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/001534.950081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001534.961929:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[26023:26023:0713/001534.964500:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/001534.965112:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xbf706f69e20
[1:1:0713/001534.965274:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26023:26023:0713/001534.970586:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26023:26023:0713/001534.995685:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26023:26023:0713/001534.995839:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/001535.031136:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001535.965367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7fabf01b82e0 0xbf70701cc60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001535.966648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e1c07481f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/001535.966844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001535.968298:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26023:26023:0713/001536.034942:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/001536.036831:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xbf706f6a820
[1:1:0713/001536.038359:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[26023:26023:0713/001536.043172:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/001536.060236:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/001536.060472:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26023:26023:0713/001536.063612:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26023:26023:0713/001536.077799:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26023:26023:0713/001536.078824:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26023:26035:0713/001536.084756:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26023:26035:0713/001536.084879:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[26023:26023:0713/001536.084932:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26023:26023:0713/001536.085008:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26023:26023:0713/001536.085138:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26076, 4
[1:7:0713/001536.086833:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/001536.759435:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/001537.204544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fabf01b82e0 0xbf7071e2660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001537.205514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e1c07481f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/001537.205740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001537.206517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26023:26023:0713/001537.429473:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26023:26023:0713/001537.429591:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/001537.431925:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26023:26023:0713/001537.725405:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26023:26054:0713/001537.725877:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/001537.726060:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/001537.726306:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/001537.726713:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/001537.726854:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/001537.729995:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3703b972, 1
[1:1:0713/001537.730421:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x37f509f1, 0
[1:1:0713/001537.730608:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1a291e12, 3
[1:1:0713/001537.730847:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3fd27798, 2
[1:1:0713/001537.731039:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff109fffffff537 72ffffffb90337 ffffff9877ffffffd23f 121e291a , 10104, 5
[1:1:0713/001537.732292:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26023:26054:0713/001537.732556:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�	�7r�7�w�?)��

[26023:26054:0713/001537.732657:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �	�7r�7�w�?)�Q��

[1:1:0713/001537.732768:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac0478f0a0, 3
[26023:26054:0713/001537.732910:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26120, 5, f109f537 72b90337 9877d23f 121e291a 
[1:1:0713/001537.732965:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac0491a080, 2
[1:1:0713/001537.733142:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fabee5ddd20, -2
[1:1:0713/001537.745453:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001537.754894:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/001537.755227:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fd27798
[1:1:0713/001537.755528:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fd27798
[1:1:0713/001537.756167:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fd27798
[1:1:0713/001537.757557:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.757761:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.757940:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.758114:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.758794:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fd27798
[1:1:0713/001537.759086:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac065547ba
[1:1:0713/001537.759217:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac0654bdef, 7fac0655477a, 7fac065560cf
[1:1:0713/001537.764927:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fd27798
[1:1:0713/001537.765274:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fd27798
[1:1:0713/001537.766002:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fd27798
[1:1:0713/001537.768019:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.768244:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.768435:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.768643:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd27798
[1:1:0713/001537.769885:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fd27798
[1:1:0713/001537.770241:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac065547ba
[1:1:0713/001537.770371:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac0654bdef, 7fac0655477a, 7fac065560cf
[1:1:0713/001537.778080:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/001537.778602:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/001537.778775:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe90bd46c8, 0x7ffe90bd4648)
[1:1:0713/001537.794491:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/001537.798694:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/001538.044977:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xbf706f30220
[1:1:0713/001538.045129:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/001538.196846:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001538.197106:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[26023:26023:0713/001538.354523:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26023:26023:0713/001538.360561:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26023:26035:0713/001538.380948:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[26023:26035:0713/001538.381041:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[26023:26023:0713/001538.381951:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://zt.cncn.org.cn/
[26023:26023:0713/001538.382052:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zt.cncn.org.cn/, http://zt.cncn.org.cn/2019/shds/, 1
[26023:26023:0713/001538.382216:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://zt.cncn.org.cn/, HTTP/1.1 200 OK Server: nginx Date: Sat, 13 Jul 2019 07:15:36 GMT Content-Type: text/html Last-Modified: Mon, 01 Jul 2019 07:43:28 GMT Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding ETag: W/"5d19b9a0-8449" Content-Encoding: gzip  ,26120, 5
[1:7:0713/001538.384831:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/001538.430681:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://zt.cncn.org.cn/
[1:1:0713/001538.506062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/001538.510567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0e1c075ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/001538.510971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/001538.518893:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/001538.587736:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26023:26023:0713/001538.600713:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zt.cncn.org.cn/, http://zt.cncn.org.cn/, 1
[26023:26023:0713/001538.600804:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://zt.cncn.org.cn/, http://zt.cncn.org.cn
[1:1:0713/001538.650434:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001538.776461:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001538.776710:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001538.955597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/001538.956368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e1c07481f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/001538.956571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/001539.114019:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 140 0x7fabee290070 0xbf7070477e0 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001539.115099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , function uaredirect(f) {
    try {
        if (document.getElementById("bdmark") != null) {
     
[1:1:0713/001539.115347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001539.116539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 140 0x7fabee290070 0xbf7070477e0 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001539.192360:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.076297, 614, 1
[1:1:0713/001539.192585:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/001539.281413:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/001539.281642:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001539.375409:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001539.578627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fabee5f8bd0 0xbf70704a2d8 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001539.586628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , /*! jQuery v1.11.2 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0713/001539.586877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001539.600778:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/001539.842109:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fabee5f8bd0 0xbf70704a2d8 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001539.849676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fabee5f8bd0 0xbf70704a2d8 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001539.861297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fabee5f8bd0 0xbf70704a2d8 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001539.876032:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fabee5f8bd0 0xbf70704a2d8 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001540.137914:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fabee5f8bd0 0xbf70704a2d8 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001540.142555:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001540.190065:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001540.190745:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001540.191816:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001540.192202:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001540.192550:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001541.685931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x2d66324429c8, 0xbf706da9c40
[1:1:0713/001541.686184:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 4500
[1:1:0713/001541.686568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 268
[1:1:0713/001541.686807:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 268 0x7fabee290070 0xbf7072c7060 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 192 0x7fabee5f8bd0 0xbf70704a2d8 
[1:1:0713/001542.229148:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001542.229907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xc[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0713/001542.230169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001542.231417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001542.234443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001542.235223:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1c74fe791330
[1:1:0713/001542.567986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7fabf01b82e0 0xbf70704d360 , "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001542.569891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , (function(){var h={},mt={},c={id:"248191fc7c19ee68f4abb0a43bfc4f52",dm:["cncn.org.cn"],js:"tongji.ba
[1:1:0713/001542.570152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001542.595551:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9990
[1:1:0713/001542.595785:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001542.596164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 313
[1:1:0713/001542.596382:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 313 0x7fabee290070 0xbf70704b060 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 297 0x7fabf01b82e0 0xbf70704d360 
[26023:26023:0713/001615.948131:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/001615.992248:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/001616.607148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/001616.607437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001617.382213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 313, 7fabf0bd5881
[1:1:0713/001617.388709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"297 0x7fabf01b82e0 0xbf70704d360 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001617.389328:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"297 0x7fabf01b82e0 0xbf70704d360 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001617.389528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001617.389842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001617.389947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001617.390306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001617.390406:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001617.390622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 394
[1:1:0713/001617.390744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 394 0x7fabee290070 0xbf707499be0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 313 0x7fabee290070 0xbf70704b060 
[1:1:0713/001617.391182:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 268, 7fabf0bd5881
[1:1:0713/001617.396323:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"192 0x7fabee5f8bd0 0xbf70704a2d8 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001617.396454:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"192 0x7fabee5f8bd0 0xbf70704a2d8 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001617.396677:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001617.397034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , () {
                o++, e.eq(o - 1).removeClass(n), o == g && (o = 0), r(), e.eq(o).addClass(n), 
[1:1:0713/001617.397133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001617.426398:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001617.426760:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 0
[1:1:0713/001617.427155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 395
[1:1:0713/001617.427381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7fabee290070 0xbf707a314e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 268 0x7fabee290070 0xbf7072c7060 
[1:1:0713/001617.455387:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 13
[1:1:0713/001617.455952:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 396
[1:1:0713/001617.456145:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 396 0x7fabee290070 0xbf707a25260 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 268 0x7fabee290070 0xbf7072c7060 
[1:1:0713/001617.471791:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001617.472009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 4500
[1:1:0713/001617.472356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 397
[1:1:0713/001617.472568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 397 0x7fabee290070 0xbf7074a36e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 268 0x7fabee290070 0xbf7072c7060 
[1:1:0713/001618.196748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , document.readyState
[1:1:0713/001618.197042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001618.301619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 395, 7fabf0bd5881
[1:1:0713/001618.320691:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"268 0x7fabee290070 0xbf7072c7060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001618.320918:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"268 0x7fabee290070 0xbf7072c7060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001618.321102:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001618.321430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , (){$b=void 0}
[1:1:0713/001618.321559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001618.322150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 396, 7fabf0bd58db
[1:1:0713/001618.328204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"268 0x7fabee290070 0xbf7072c7060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001618.328370:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"268 0x7fabee290070 0xbf7072c7060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001618.328538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 439
[1:1:0713/001618.328646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 439 0x7fabee290070 0xbf707488260 , 5:3_http://zt.cncn.org.cn/, 0, , 396 0x7fabee290070 0xbf707a25260 
[1:1:0713/001618.328843:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001618.329137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001618.329239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001618.342038:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/001618.353247:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 394, 7fabf0bd5881
[1:1:0713/001618.359218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"313 0x7fabee290070 0xbf70704b060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001618.359375:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"313 0x7fabee290070 0xbf70704b060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001618.359558:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001618.359928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001618.360044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001618.360346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001618.360446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001618.360626:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 441
[1:1:0713/001618.360732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 441 0x7fabee290070 0xbf7074a3d60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 394 0x7fabee290070 0xbf707499be0 
[1:1:0713/001618.408102:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001618.408624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/001618.408742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001618.412966:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001618.413906:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001618.414531:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9af0
[1:1:0713/001618.414635:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001618.414840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 445
[1:1:0713/001618.414954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 445 0x7fabee290070 0xbf707987460 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 403 0x7fabee290070 0xbf707a2d4e0 
[1:1:0713/001618.681966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , document.readyState
[1:1:0713/001618.682132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001618.879666:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001618.880108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , r.handle, (a){return typeof m===K||a&&m.event.triggered===a.type?void 0:m.event.dispatch.apply(k.elem,argument
[1:1:0713/001618.880217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.034096:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 445, 7fabf0bd5881
[1:1:0713/001619.040080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"403 0x7fabee290070 0xbf707a2d4e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.040225:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"403 0x7fabee290070 0xbf707a2d4e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.040396:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001619.040687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001619.040787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.041117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001619.041215:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001619.041379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 464
[1:1:0713/001619.041484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 464 0x7fabee290070 0xbf706ff9f60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 445 0x7fabee290070 0xbf707987460 
[1:1:0713/001619.175808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 464, 7fabf0bd5881
[1:1:0713/001619.182132:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"445 0x7fabee290070 0xbf707987460 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.182288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"445 0x7fabee290070 0xbf707987460 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.182468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001619.182763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001619.182863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.183202:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001619.183299:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001619.183471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 477
[1:1:0713/001619.183575:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 477 0x7fabee290070 0xbf706f848e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 464 0x7fabee290070 0xbf706ff9f60 
[1:1:0713/001619.335232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 477, 7fabf0bd5881
[1:1:0713/001619.355677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"464 0x7fabee290070 0xbf706ff9f60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.356036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"464 0x7fabee290070 0xbf706ff9f60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.356391:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001619.356917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001619.357114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.357761:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001619.357916:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001619.358339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 484
[1:1:0713/001619.358528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7fabee290070 0xbf7076dbd60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 477 0x7fabee290070 0xbf706f848e0 
[1:1:0713/001619.482477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 484, 7fabf0bd5881
[1:1:0713/001619.491565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"477 0x7fabee290070 0xbf706f848e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.491775:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"477 0x7fabee290070 0xbf706f848e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.491995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001619.492339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001619.492445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.492745:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001619.492841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001619.493018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 487
[1:1:0713/001619.493147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 487 0x7fabee290070 0xbf7076dc9e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 484 0x7fabee290070 0xbf7076dbd60 
[1:1:0713/001619.629801:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 487, 7fabf0bd5881
[1:1:0713/001619.654043:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"484 0x7fabee290070 0xbf7076dbd60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.654467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"484 0x7fabee290070 0xbf7076dbd60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.654908:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001619.655574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001619.655790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.656605:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001619.656805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001619.657265:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 489
[1:1:0713/001619.657467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 489 0x7fabee290070 0xbf706f4cb60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 487 0x7fabee290070 0xbf7076dc9e0 
[1:1:0713/001619.789117:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 489, 7fabf0bd5881
[1:1:0713/001619.810467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"487 0x7fabee290070 0xbf7076dc9e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.810855:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"487 0x7fabee290070 0xbf7076dc9e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.811298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001619.811953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001619.812193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.812993:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001619.813207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001619.813641:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 493
[1:1:0713/001619.813877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 493 0x7fabee290070 0xbf706f38d60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 489 0x7fabee290070 0xbf706f4cb60 
[1:1:0713/001619.939449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 493, 7fabf0bd5881
[1:1:0713/001619.960198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"489 0x7fabee290070 0xbf706f4cb60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.960502:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"489 0x7fabee290070 0xbf706f4cb60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001619.960859:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001619.961407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001619.961583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001619.962264:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001619.962432:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001619.962780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 495
[1:1:0713/001619.962968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7fabee290070 0xbf7072ce760 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 493 0x7fabee290070 0xbf706f38d60 
[1:1:0713/001620.083888:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 495, 7fabf0bd5881
[1:1:0713/001620.090090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"493 0x7fabee290070 0xbf706f38d60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.090289:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"493 0x7fabee290070 0xbf706f38d60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.090486:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001620.090776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001620.090873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001620.091158:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001620.091278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001620.091445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 497
[1:1:0713/001620.091548:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 497 0x7fabee290070 0xbf707771560 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 495 0x7fabee290070 0xbf7072ce760 
[1:1:0713/001620.204009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 497, 7fabf0bd5881
[1:1:0713/001620.210374:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"495 0x7fabee290070 0xbf7072ce760 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.210546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"495 0x7fabee290070 0xbf7072ce760 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.210758:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001620.211060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001620.211162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001620.211477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001620.211572:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001620.211748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 499
[1:1:0713/001620.211854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 499 0x7fabee290070 0xbf70748ade0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 497 0x7fabee290070 0xbf707771560 
[1:1:0713/001620.326358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 499, 7fabf0bd5881
[1:1:0713/001620.346121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"497 0x7fabee290070 0xbf707771560 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.346530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"497 0x7fabee290070 0xbf707771560 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.346915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001620.347492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001620.347701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001620.348364:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001620.348561:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001620.348893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 503
[1:1:0713/001620.349104:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 503 0x7fabee290070 0xbf706f59f60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 499 0x7fabee290070 0xbf70748ade0 
[1:1:0713/001620.490136:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 503, 7fabf0bd5881
[1:1:0713/001620.508869:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"499 0x7fabee290070 0xbf70748ade0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.509093:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"499 0x7fabee290070 0xbf70748ade0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.509314:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001620.509642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001620.509745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001620.510060:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001620.510159:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001620.510391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 505
[1:1:0713/001620.510514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 505 0x7fabee290070 0xbf707773ae0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 503 0x7fabee290070 0xbf706f59f60 
[1:1:0713/001620.636423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 505, 7fabf0bd5881
[1:1:0713/001620.663492:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"503 0x7fabee290070 0xbf706f59f60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.663952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"503 0x7fabee290070 0xbf706f59f60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.664408:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001620.665068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001620.665288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001620.666114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001620.666311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001620.666795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 507
[1:1:0713/001620.667036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 507 0x7fabee290070 0xbf70703ee60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 505 0x7fabee290070 0xbf707773ae0 
[1:1:0713/001620.793181:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 507, 7fabf0bd5881
[1:1:0713/001620.821492:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"505 0x7fabee290070 0xbf707773ae0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.821908:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"505 0x7fabee290070 0xbf707773ae0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.822351:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001620.823058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001620.823297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001620.824126:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001620.824325:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001620.824779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 509
[1:1:0713/001620.824977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 509 0x7fabee290070 0xbf706d95b60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 507 0x7fabee290070 0xbf70703ee60 
[1:1:0713/001620.949823:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 509, 7fabf0bd5881
[1:1:0713/001620.963344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"507 0x7fabee290070 0xbf70703ee60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.963547:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"507 0x7fabee290070 0xbf70703ee60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001620.963739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001620.964080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001620.964248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001620.964617:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001620.964713:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001620.964893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 511
[1:1:0713/001620.964995:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7fabee290070 0xbf706f25260 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 509 0x7fabee290070 0xbf706d95b60 
[1:1:0713/001621.089888:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 511, 7fabf0bd5881
[1:1:0713/001621.114980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"509 0x7fabee290070 0xbf706d95b60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.115361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"509 0x7fabee290070 0xbf706d95b60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.115821:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001621.116492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001621.116721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001621.117525:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001621.117718:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001621.118139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 513
[1:1:0713/001621.118496:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7fabee290070 0xbf7070f4560 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 511 0x7fabee290070 0xbf706f25260 
[1:1:0713/001621.242172:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 513, 7fabf0bd5881
[1:1:0713/001621.263319:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"511 0x7fabee290070 0xbf706f25260 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.263604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"511 0x7fabee290070 0xbf706f25260 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.263943:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001621.264464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001621.264652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001621.265287:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001621.265440:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001621.265801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 516
[1:1:0713/001621.265987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7fabee290070 0xbf706f877e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 513 0x7fabee290070 0xbf7070f4560 
[1:1:0713/001621.377413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 516, 7fabf0bd5881
[1:1:0713/001621.383558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"513 0x7fabee290070 0xbf7070f4560 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.383711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"513 0x7fabee290070 0xbf7070f4560 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.383884:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001621.384167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001621.384276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001621.384590:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001621.384687:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001621.384848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 519
[1:1:0713/001621.384951:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 519 0x7fabee290070 0xbf70748ade0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 516 0x7fabee290070 0xbf706f877e0 
[1:1:0713/001621.514057:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 519, 7fabf0bd5881
[1:1:0713/001621.535836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"516 0x7fabee290070 0xbf706f877e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.536175:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"516 0x7fabee290070 0xbf706f877e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.536596:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001621.537251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001621.537471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001621.538292:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001621.538490:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001621.539143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 521
[1:1:0713/001621.539380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 521 0x7fabee290070 0xbf706f51660 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 519 0x7fabee290070 0xbf70748ade0 
[1:1:0713/001621.666698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 521, 7fabf0bd5881
[1:1:0713/001621.690316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"519 0x7fabee290070 0xbf70748ade0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.690568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"519 0x7fabee290070 0xbf70748ade0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.690962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001621.691475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001621.691668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001621.692324:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001621.692477:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001621.692836:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 523
[1:1:0713/001621.693023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7fabee290070 0xbf7074980e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 521 0x7fabee290070 0xbf706f51660 
[1:1:0713/001621.815882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 523, 7fabf0bd5881
[1:1:0713/001621.837463:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"521 0x7fabee290070 0xbf706f51660 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.837780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"521 0x7fabee290070 0xbf706f51660 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.838120:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001621.838746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001621.838922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001621.839584:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001621.839760:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001621.840104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 525
[1:1:0713/001621.840288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7fabee290070 0xbf707487760 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 523 0x7fabee290070 0xbf7074980e0 
[1:1:0713/001621.973112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 525, 7fabf0bd5881
[1:1:0713/001621.993472:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"523 0x7fabee290070 0xbf7074980e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.993753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"523 0x7fabee290070 0xbf7074980e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001621.994064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001621.994555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001621.994758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001621.995371:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001621.995520:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001621.995865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 528
[1:1:0713/001621.996044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7fabee290070 0xbf7077727e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 525 0x7fabee290070 0xbf707487760 
[1:1:0713/001621.997230:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 397, 7fabf0bd5881
[1:1:0713/001622.023907:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"268 0x7fabee290070 0xbf7072c7060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.024242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"268 0x7fabee290070 0xbf7072c7060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.024639:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.025164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , () {
                o++, e.eq(o - 1).removeClass(n), o == g && (o = 0), r(), e.eq(o).addClass(n), 
[1:1:0713/001622.025335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.068647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001622.068913:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 0
[1:1:0713/001622.069331:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 530
[1:1:0713/001622.069563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7fabee290070 0xbf7070495e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 397 0x7fabee290070 0xbf7074a36e0 
[1:1:0713/001622.102247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 13
[1:1:0713/001622.102622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 531
[1:1:0713/001622.102855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7fabee290070 0xbf706fe43e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 397 0x7fabee290070 0xbf7074a36e0 
[1:1:0713/001622.115872:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001622.115986:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 4500
[1:1:0713/001622.116142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 532
[1:1:0713/001622.116246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7fabee290070 0xbf706f38d60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 397 0x7fabee290070 0xbf7074a36e0 
[1:1:0713/001622.164412:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 530, 7fabf0bd5881
[1:1:0713/001622.185921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"397 0x7fabee290070 0xbf7074a36e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.186169:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"397 0x7fabee290070 0xbf7074a36e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.186511:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.187010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , , (){$b=void 0}
[1:1:0713/001622.187186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.206806:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 528, 7fabf0bd5881
[1:1:0713/001622.218680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"525 0x7fabee290070 0xbf707487760 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.218981:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"525 0x7fabee290070 0xbf707487760 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.219313:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.219854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001622.220026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.220648:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001622.220825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001622.221158:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 538
[1:1:0713/001622.221340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 538 0x7fabee290070 0xbf706f4cd60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 528 0x7fabee290070 0xbf7077727e0 
[1:1:0713/001622.222506:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 531, 7fabf0bd58db
[1:1:0713/001622.244213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"397 0x7fabee290070 0xbf7074a36e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.244535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"397 0x7fabee290070 0xbf7074a36e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.244918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 539
[1:1:0713/001622.245115:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 539 0x7fabee290070 0xbf706f1bfe0 , 5:3_http://zt.cncn.org.cn/, 0, , 531 0x7fabee290070 0xbf706fe43e0 
[1:1:0713/001622.245375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.245855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.246028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.275001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 539, 7fabf0bd58db
[1:1:0713/001622.296680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"531 0x7fabee290070 0xbf706fe43e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.296954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"531 0x7fabee290070 0xbf706fe43e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.297303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 542
[1:1:0713/001622.297481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 542 0x7fabee290070 0xbf707482ae0 , 5:3_http://zt.cncn.org.cn/, 0, , 539 0x7fabee290070 0xbf706f1bfe0 
[1:1:0713/001622.297767:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.298250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.298414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.352992:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 542, 7fabf0bd58db
[1:1:0713/001622.375522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"539 0x7fabee290070 0xbf706f1bfe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.375800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"539 0x7fabee290070 0xbf706f1bfe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.376203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 546
[1:1:0713/001622.376392:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 546 0x7fabee290070 0xbf706f1bfe0 , 5:3_http://zt.cncn.org.cn/, 0, , 542 0x7fabee290070 0xbf707482ae0 
[1:1:0713/001622.376663:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.377177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.377350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.381156:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 538, 7fabf0bd5881
[1:1:0713/001622.392649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"528 0x7fabee290070 0xbf7077727e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.392799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"528 0x7fabee290070 0xbf7077727e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.392997:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.393238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001622.393344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.393624:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001622.393717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001622.393902:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 548
[1:1:0713/001622.394006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 548 0x7fabee290070 0xbf707090fe0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 538 0x7fabee290070 0xbf706f4cd60 
[1:1:0713/001622.443119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 546, 7fabf0bd58db
[1:1:0713/001622.468452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"542 0x7fabee290070 0xbf707482ae0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.468761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"542 0x7fabee290070 0xbf707482ae0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.469272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 551
[1:1:0713/001622.469521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 551 0x7fabee290070 0xbf7074a8e60 , 5:3_http://zt.cncn.org.cn/, 0, , 546 0x7fabee290070 0xbf706f1bfe0 
[1:1:0713/001622.469887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.470520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.470735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.566295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 551, 7fabf0bd58db
[1:1:0713/001622.589394:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"546 0x7fabee290070 0xbf706f1bfe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.589673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"546 0x7fabee290070 0xbf706f1bfe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.590071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 556
[1:1:0713/001622.590263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 556 0x7fabee290070 0xbf7076dcbe0 , 5:3_http://zt.cncn.org.cn/, 0, , 551 0x7fabee290070 0xbf7074a8e60 
[1:1:0713/001622.590550:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.591095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.591278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.595082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 548, 7fabf0bd5881
[1:1:0713/001622.603901:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"538 0x7fabee290070 0xbf706f4cd60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.604050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"538 0x7fabee290070 0xbf706f4cd60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.604228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.604494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001622.604601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.604954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001622.605062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001622.605229:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 558
[1:1:0713/001622.605338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7fabee290070 0xbf706f4c060 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 548 0x7fabee290070 0xbf707090fe0 
[1:1:0713/001622.660028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 556, 7fabf0bd58db
[1:1:0713/001622.666949:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"551 0x7fabee290070 0xbf7074a8e60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.667150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"551 0x7fabee290070 0xbf7074a8e60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.667339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 561
[1:1:0713/001622.667456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7fabee290070 0xbf707dd4e60 , 5:3_http://zt.cncn.org.cn/, 0, , 556 0x7fabee290070 0xbf7076dcbe0 
[1:1:0713/001622.667604:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.667904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.668007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.772057:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 561, 7fabf0bd58db
[1:1:0713/001622.784991:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"556 0x7fabee290070 0xbf7076dcbe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.785248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"556 0x7fabee290070 0xbf7076dcbe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.785661:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 567
[1:1:0713/001622.785877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7fabee290070 0xbf706f59f60 , 5:3_http://zt.cncn.org.cn/, 0, , 561 0x7fabee290070 0xbf707dd4e60 
[1:1:0713/001622.786164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.786663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.786834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.800926:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 558, 7fabf0bd5881
[1:1:0713/001622.811904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"548 0x7fabee290070 0xbf707090fe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.812118:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"548 0x7fabee290070 0xbf707090fe0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.812395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.812809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001622.813035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001622.813458:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001622.813591:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001622.813835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 570
[1:1:0713/001622.814003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 570 0x7fabee290070 0xbf7072cb0e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 558 0x7fabee290070 0xbf706f4c060 
[1:1:0713/001622.856211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 567, 7fabf0bd58db
[1:1:0713/001622.879661:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"561 0x7fabee290070 0xbf707dd4e60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.879919:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"561 0x7fabee290070 0xbf707dd4e60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001622.880316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zt.cncn.org.cn/, 572
[1:1:0713/001622.880505:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 572 0x7fabee290070 0xbf70759b860 , 5:3_http://zt.cncn.org.cn/, 0, , 567 0x7fabee290070 0xbf706f59f60 
[1:1:0713/001622.880778:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001622.881288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/001622.881461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001623.057692:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 570, 7fabf0bd5881
[1:1:0713/001623.081488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"558 0x7fabee290070 0xbf706f4c060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.081758:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"558 0x7fabee290070 0xbf706f4c060 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.082129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001623.082643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001623.082813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001623.083459:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001623.083616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001623.083965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 578
[1:1:0713/001623.084152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 578 0x7fabee290070 0xbf70691a860 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 570 0x7fabee290070 0xbf7072cb0e0 
[1:1:0713/001623.214100:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 578, 7fabf0bd5881
[1:1:0713/001623.240357:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"570 0x7fabee290070 0xbf7072cb0e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.240641:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"570 0x7fabee290070 0xbf7072cb0e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.240998:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001623.241526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001623.241710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001623.242375:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001623.242532:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001623.242875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 580
[1:1:0713/001623.243097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7fabee290070 0xbf7077722e0 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 578 0x7fabee290070 0xbf70691a860 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/001623.353821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 580, 7fabf0bd5881
[1:1:0713/001623.361009:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"578 0x7fabee290070 0xbf70691a860 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.361164:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"578 0x7fabee290070 0xbf70691a860 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.361346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001623.361646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001623.361748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001623.362086:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001623.362187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001623.362369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 582
[1:1:0713/001623.362473:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7fabee290070 0xbf706f88a60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 580 0x7fabee290070 0xbf7077722e0 
[1:1:0713/001623.477525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 582, 7fabf0bd5881
[1:1:0713/001623.499901:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"580 0x7fabee290070 0xbf7077722e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.500181:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"580 0x7fabee290070 0xbf7077722e0 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.500503:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001623.501008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001623.501204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001623.501810:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001623.501964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001623.502341:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 584
[1:1:0713/001623.502519:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7fabee290070 0xbf7072cbd60 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 582 0x7fabee290070 0xbf706f88a60 
[1:1:0713/001623.626629:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 584, 7fabf0bd5881
[1:1:0713/001623.640690:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08e190da2860","ptid":"582 0x7fabee290070 0xbf706f88a60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.640839:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zt.cncn.org.cn/","ptid":"582 0x7fabee290070 0xbf706f88a60 ","rf":"5:3_http://zt.cncn.org.cn/"}
[1:1:0713/001623.641016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zt.cncn.org.cn/2019/shds/"
[1:1:0713/001623.641330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zt.cncn.org.cn/, 08e190da2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/001623.641430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zt.cncn.org.cn/2019/shds/", "zt.cncn.org.cn", 3, 1, , , 0
[1:1:0713/001623.641713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d66324429c8, 0xbf706da9950
[1:1:0713/001623.641805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zt.cncn.org.cn/2019/shds/", 100
[1:1:0713/001623.641979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zt.cncn.org.cn/, 586
[1:1:0713/001623.642127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 586 0x7fabee290070 0xbf707599060 , 5:3_http://zt.cncn.org.cn/, 1, -5:3_http://zt.cncn.org.cn/, 584 0x7fabee290070 0xbf7072cbd60 
