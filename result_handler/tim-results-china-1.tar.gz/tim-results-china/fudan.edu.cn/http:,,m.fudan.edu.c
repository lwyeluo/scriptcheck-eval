[0712/002534.820895:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/002534.821322:INFO:switcher_clone.cc(787)] backtrace rip is 7fa55055d891
[0712/002536.236154:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/002536.236427:INFO:switcher_clone.cc(787)] backtrace rip is 7f4ffacf3891
[1:1:0712/002536.240454:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/002536.240638:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/002536.245876:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[43499:43499:0712/002537.264188:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/2c2f31c4-7581-49df-9770-dc69aab65cd4
[0712/002537.596166:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/002537.596593:INFO:switcher_clone.cc(787)] backtrace rip is 7f26980c6891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[43529:43529:0712/002537.811839:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=43529
[43542:43542:0712/002537.812404:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=43542
[43499:43499:0712/002537.845786:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[43499:43527:0712/002537.846728:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/002537.847005:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/002537.847317:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/002537.847907:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/002537.848080:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/002537.850461:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x129f85ac, 1
[1:1:0712/002537.850761:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x30faa631, 0
[1:1:0712/002537.850912:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x316cfb90, 3
[1:1:0712/002537.851092:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x359a8fba, 2
[1:1:0712/002537.851375:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 31ffffffa6fffffffa30 ffffffacffffff85ffffff9f12 ffffffbaffffff8fffffff9a35 ffffff90fffffffb6c31 , 10104, 4
[1:1:0712/002537.852392:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[43499:43527:0712/002537.852636:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING1��0������5��l1M
..
[43499:43527:0712/002537.852730:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 1��0������5��l1xUM
..
[43499:43527:0712/002537.853053:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[43499:43527:0712/002537.853145:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 43550, 4, 31a6fa30 ac859f12 ba8f9a35 90fb6c31 
[1:1:0712/002537.853638:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff8f2e0a0, 3
[1:1:0712/002537.853845:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff90b9080, 2
[1:1:0712/002537.853995:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fe2d7cd20, -2
[1:1:0712/002537.872078:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/002537.873135:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 359a8fba
[1:1:0712/002537.874329:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 359a8fba
[1:1:0712/002537.875895:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 359a8fba
[1:1:0712/002537.877300:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.877482:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.877654:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.877839:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.878443:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 359a8fba
[1:1:0712/002537.878749:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ffacf37ba
[1:1:0712/002537.878875:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ffaceadef, 7f4ffacf377a, 7f4ffacf50cf
[1:1:0712/002537.883614:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 359a8fba
[1:1:0712/002537.883878:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 359a8fba
[1:1:0712/002537.884158:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 359a8fba
[1:1:0712/002537.884876:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.884985:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.885075:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.885164:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 359a8fba
[1:1:0712/002537.885611:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 359a8fba
[1:1:0712/002537.885769:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ffacf37ba
[1:1:0712/002537.885839:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ffaceadef, 7f4ffacf377a, 7f4ffacf50cf
[1:1:0712/002537.888012:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/002537.888306:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/002537.888398:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdf05615d8, 0x7ffdf0561558)
[1:1:0712/002537.901572:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/002537.907504:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[43499:43520:0712/002538.468654:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[43499:43499:0712/002538.498669:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43499:43499:0712/002538.499872:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43499:43509:0712/002538.511938:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[43499:43509:0712/002538.512040:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[43499:43499:0712/002538.512215:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[43499:43499:0712/002538.512302:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[43499:43499:0712/002538.512439:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,43550, 4
[1:7:0712/002538.528310:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/002538.628326:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x24c92696e220
[1:1:0712/002538.628585:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/002538.920592:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[43499:43499:0712/002540.271525:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[43499:43499:0712/002540.271597:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/002540.288623:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/002540.292289:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002541.184957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 276765dc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/002541.185260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/002541.192551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 276765dc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/002541.192806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/002541.211338:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/002541.560005:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/002541.560353:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002541.959486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002541.967772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 276765dc1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/002541.968003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/002542.020427:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002542.030924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 276765dc1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/002542.031176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/002542.043288:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[43499:43499:0712/002542.046423:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/002542.046832:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x24c92696ce20
[1:1:0712/002542.047020:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[43499:43499:0712/002542.055316:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[43499:43499:0712/002542.085290:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[43499:43499:0712/002542.085458:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/002542.147603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002542.909917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7f4fe49572e0 0x24c926c5af60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002542.911283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 276765dc1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/002542.911481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/002542.912971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002542.964010:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x24c92696d820
[1:1:0712/002542.964226:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[43499:43499:0712/002542.970165:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[43499:43499:0712/002542.977111:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/002542.984360:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/002542.984610:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[43499:43499:0712/002542.989314:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[43499:43499:0712/002543.002059:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43499:43499:0712/002543.003099:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43499:43509:0712/002543.009613:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[43499:43509:0712/002543.009709:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[43499:43499:0712/002543.009860:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[43499:43499:0712/002543.009942:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[43499:43499:0712/002543.010090:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,43550, 4
[1:7:0712/002543.011376:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/002543.533761:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/002543.983589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f4fe49572e0 0x24c926db4a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002543.984642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 276765dc1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/002543.984927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/002543.985735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[43499:43499:0712/002544.147076:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[43499:43499:0712/002544.147192:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/002544.166377:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002544.566238:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[43499:43499:0712/002544.886691:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[43499:43527:0712/002544.887267:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/002544.887458:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/002544.887668:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/002544.888025:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/002544.888157:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/002544.890609:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3bed528a, 1
[1:1:0712/002544.890871:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x338d6e75, 0
[1:1:0712/002544.890959:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x494dd07, 3
[1:1:0712/002544.891032:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3718e220, 2
[1:1:0712/002544.891111:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 756effffff8d33 ffffff8a52ffffffed3b 20ffffffe21837 07ffffffddffffff9404 , 10104, 5
[1:1:0712/002544.891776:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[43499:43527:0712/002544.891926:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGun�3�R�; �7ݔ�
..
[43499:43527:0712/002544.891968:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is un�3�R�; �7ݔ8P�
..
[43499:43527:0712/002544.892105:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 43596, 5, 756e8d33 8a52ed3b 20e21837 07dd9404 
[1:1:0712/002544.892290:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff8f2e0a0, 3
[1:1:0712/002544.892405:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff90b9080, 2
[1:1:0712/002544.892501:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fe2d7cd20, -2
[1:1:0712/002544.911565:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/002544.911957:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3718e220
[1:1:0712/002544.912261:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3718e220
[1:1:0712/002544.912904:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3718e220
[1:1:0712/002544.914299:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.914506:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.914699:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.914882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.915546:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3718e220
[1:1:0712/002544.915847:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ffacf37ba
[1:1:0712/002544.915983:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ffaceadef, 7f4ffacf377a, 7f4ffacf50cf
[1:1:0712/002544.921747:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3718e220
[1:1:0712/002544.922117:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3718e220
[1:1:0712/002544.922754:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3718e220
[1:1:0712/002544.923899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.924055:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.924156:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.924250:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3718e220
[1:1:0712/002544.924873:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3718e220
[1:1:0712/002544.925359:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ffacf37ba
[1:1:0712/002544.925555:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ffaceadef, 7f4ffacf377a, 7f4ffacf50cf
[1:1:0712/002544.935436:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/002544.936206:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/002544.936428:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdf05615d8, 0x7ffdf0561558)
[1:1:0712/002544.952010:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/002544.956009:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/002545.128028:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x24c926935220
[1:1:0712/002545.128182:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/002545.250325:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/002545.250600:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/002545.767013:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.767430:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.767745:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.768091:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.768394:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.768699:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.769039:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.769344:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.769672:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.770064:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.770977:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.771300:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.771612:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.772001:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[43499:43499:0712/002545.772338:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[1:1:0712/002545.772314:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[43499:43499:0712/002545.772541:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0712/002545.772626:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.772971:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.773292:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.773630:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.773972:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.774288:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.774602:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.774957:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.775329:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.775681:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.776070:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.776392:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.776702:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.777053:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.777358:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.777662:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.777988:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.778341:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.778664:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.778995:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.779359:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.779687:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.780104:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.780430:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.780747:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.781135:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.781450:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/002545.891104:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/002545.896707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 276765ef09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/002545.897077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/002545.906461:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/002545.912504:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/002546.035419:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/002546.036260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 276765dc1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/002546.036496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/002546.200280:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/002546.267666:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/002546.267929:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/002546.291238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4fe2a2f070 0x24c9269d91e0 , "chrome-error://chromewebdata/"
[1:1:0712/002546.295352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4fe2a2f070 0x24c9269d91e0 , "chrome-error://chromewebdata/"
[1:1:0712/002546.299297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4fe2a2f070 0x24c9269d91e0 , "chrome-error://chromewebdata/"
[1:1:0712/002546.307837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4fe2a2f070 0x24c9269d91e0 , "chrome-error://chromewebdata/"
[1:1:0712/002546.353804:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.085824, 81, 1
[1:1:0712/002546.354168:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[3:3:0712/002546.861568:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/002547.217295:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/002547.217594:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/002547.219212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7f4fe2a2f070 0x24c92695e3e0 , "chrome-error://chromewebdata/"
[1:1:0712/002547.226045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7f4fe2a2f070 0x24c92695e3e0 , "chrome-error://chromewebdata/"
[1:1:0712/002547.230305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7f4fe2a2f070 0x24c92695e3e0 , "chrome-error://chromewebdata/"
[1:1:0712/002547.269295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7f4fe2a2f070 0x24c92695e3e0 , "chrome-error://chromewebdata/"
[1:1:0712/002547.276603:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7f4fe2a2f070 0x24c92695e3e0 , "chrome-error://chromewebdata/"
[1:1:0712/002547.347718:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/002547.353472:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/002547.933971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/002547.951508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/002547.974546:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/002547.990399:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
[1:1:0712/002548.154367:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/002548.154616:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[43499:43499:0712/002548.155677:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
