[0713/025430.663137:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/025430.663467:INFO:switcher_clone.cc(787)] backtrace rip is 7f3011e97891
[0713/025431.656317:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/025431.656801:INFO:switcher_clone.cc(787)] backtrace rip is 7f9573a56891
[1:1:0713/025431.669354:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/025431.669607:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/025431.674883:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/025433.010873:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/025433.011177:INFO:switcher_clone.cc(787)] backtrace rip is 7f422827a891
[45644:45644:0713/025433.095728:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/8e335f05-e454-4016-982f-b2309c06ef05
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[45677:45677:0713/025433.185146:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=45677
[45689:45689:0713/025433.185534:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=45689
[45644:45644:0713/025433.709538:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[45644:45675:0713/025433.710446:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/025433.710664:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/025433.710880:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/025433.711499:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/025433.711662:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/025433.714592:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x7a856f8, 1
[1:1:0713/025433.714935:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x159ca02a, 0
[1:1:0713/025433.715136:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10361bc, 3
[1:1:0713/025433.715383:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb1b9cb7, 2
[1:1:0713/025433.715613:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2affffffa0ffffff9c15 fffffff856ffffffa807 ffffffb7ffffff9c1b0b ffffffbc610301 , 10104, 4
[1:1:0713/025433.716623:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[45644:45675:0713/025433.716893:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING*���V����a�s
[45644:45675:0713/025433.716976:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is *���V����aX��s
[1:1:0713/025433.716878:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9571c910a0, 3
[1:1:0713/025433.717123:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9571e1c080, 2
[45644:45675:0713/025433.717312:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/025433.717302:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f955badfd20, -2
[45644:45675:0713/025433.717379:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 45697, 4, 2aa09c15 f856a807 b79c1b0b bc610301 
[1:1:0713/025433.737330:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/025433.738428:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b1b9cb7
[1:1:0713/025433.739632:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b1b9cb7
[1:1:0713/025433.741539:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b1b9cb7
[1:1:0713/025433.743438:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.743673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.743897:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.744126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.744916:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b1b9cb7
[1:1:0713/025433.745326:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9573a567ba
[1:1:0713/025433.745498:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9573a4ddef, 7f9573a5677a, 7f9573a580cf
[1:1:0713/025433.751668:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b1b9cb7
[1:1:0713/025433.752030:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b1b9cb7
[1:1:0713/025433.752772:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b1b9cb7
[1:1:0713/025433.754806:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.755011:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.755194:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.755401:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b1b9cb7
[1:1:0713/025433.756636:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b1b9cb7
[1:1:0713/025433.756997:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9573a567ba
[1:1:0713/025433.757127:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9573a4ddef, 7f9573a5677a, 7f9573a580cf
[1:1:0713/025433.766112:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/025433.766765:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/025433.766958:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcb320c6b8, 0x7ffcb320c638)
[1:1:0713/025433.783751:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/025433.789826:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[45644:45644:0713/025434.380720:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[45644:45644:0713/025434.381843:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[45644:45656:0713/025434.390655:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[45644:45656:0713/025434.390784:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[45644:45644:0713/025434.390979:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[45644:45644:0713/025434.391071:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[45644:45644:0713/025434.391247:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,45697, 4
[1:7:0713/025434.397995:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/025434.465193:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xbf6773a5220
[1:1:0713/025434.465478:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[45644:45668:0713/025434.482349:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/025434.860352:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/025436.475158:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025436.478925:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[45644:45644:0713/025436.606151:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[45644:45644:0713/025436.606267:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/025437.358541:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/025437.679565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24fd7d301f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/025437.679871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/025437.698582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24fd7d301f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/025437.698876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/025437.776118:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/025437.776407:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025438.165264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025438.175082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24fd7d301f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/025438.175381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/025438.195934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025438.208413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24fd7d301f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/025438.208758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/025438.221344:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/025438.225049:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xbf6773a3e20
[1:1:0713/025438.225311:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[45644:45644:0713/025438.227838:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[45644:45644:0713/025438.242144:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[45644:45644:0713/025438.286087:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[45644:45644:0713/025438.286255:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/025438.338690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025439.003694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f955d6ba2e0 0xbf6774af260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025439.005179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24fd7d301f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/025439.005399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/025439.006939:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[45644:45644:0713/025439.079836:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/025439.082093:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xbf6773a4820
[1:1:0713/025439.082334:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[45644:45644:0713/025439.087212:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/025439.089563:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/025439.089691:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[45644:45644:0713/025439.106359:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[45644:45644:0713/025439.119219:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[45644:45644:0713/025439.120457:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[45644:45656:0713/025439.128296:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[45644:45656:0713/025439.128400:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[45644:45644:0713/025439.128640:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[45644:45644:0713/025439.128736:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[45644:45644:0713/025439.128936:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,45697, 4
[1:7:0713/025439.134381:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/025439.634809:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/025439.917183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f955d6ba2e0 0xbf6775a5e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025439.918283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24fd7d301f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/025439.918519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/025439.919397:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025439.990636:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[45644:45644:0713/025439.994140:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[45644:45644:0713/025439.994240:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/025440.530713:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[45644:45644:0713/025440.759351:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[45644:45675:0713/025440.759865:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/025440.760118:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/025440.760437:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/025440.760973:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/025440.761186:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/025440.765110:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x20bda791, 1
[1:1:0713/025440.765586:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3de79ef3, 0
[1:1:0713/025440.765782:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x35778575, 3
[1:1:0713/025440.765962:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3c92f569, 2
[1:1:0713/025440.766149:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff3ffffff9effffffe73d ffffff91ffffffa7ffffffbd20 69fffffff5ffffff923c 75ffffff857735 , 10104, 5
[1:1:0713/025440.767173:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[45644:45675:0713/025440.767533:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��=��� i��<u�w5�"s
[45644:45675:0713/025440.767628:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��=��� i��<u�w5hB�"s
[1:1:0713/025440.767788:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9571c910a0, 3
[45644:45675:0713/025440.767954:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 45740, 5, f39ee73d 91a7bd20 69f5923c 75857735 
[1:1:0713/025440.768076:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9571e1c080, 2
[1:1:0713/025440.768336:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f955badfd20, -2
[1:1:0713/025440.793202:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/025440.793670:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c92f569
[1:1:0713/025440.794121:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c92f569
[1:1:0713/025440.794845:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c92f569
[1:1:0713/025440.796518:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.796786:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.797024:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.797255:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.797959:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c92f569
[1:1:0713/025440.798378:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9573a567ba
[1:1:0713/025440.798574:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9573a4ddef, 7f9573a5677a, 7f9573a580cf
[1:1:0713/025440.804151:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c92f569
[1:1:0713/025440.804715:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c92f569
[1:1:0713/025440.805551:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c92f569
[1:1:0713/025440.807611:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.807877:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.808104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.808345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c92f569
[1:1:0713/025440.809568:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c92f569
[1:1:0713/025440.809951:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9573a567ba
[1:1:0713/025440.810126:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9573a4ddef, 7f9573a5677a, 7f9573a580cf
[1:1:0713/025440.819718:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/025440.820313:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/025440.820508:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcb320c6b8, 0x7ffcb320c638)
[1:1:0713/025440.834689:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/025440.839416:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/025440.986617:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/025440.986863:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/025441.108889:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xbf677370220
[1:1:0713/025441.109188:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/025441.569240:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/025441.573955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 24fd7d42e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/025441.574328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/025441.582576:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[45644:45644:0713/025441.804108:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[45644:45644:0713/025441.812091:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[45644:45656:0713/025441.831955:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[45644:45656:0713/025441.832054:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[45644:45644:0713/025441.832519:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.google.cn/
[45644:45644:0713/025441.832659:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.google.cn/, https://www.google.cn/chrome/, 1
[45644:45644:0713/025441.832830:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.google.cn/, HTTP/1.1 200 status:200 accept-ranges:bytes vary:Accept-Encoding content-encoding:gzip content-type:text/html content-length:37655 date:Sat, 13 Jul 2019 09:54:41 GMT expires:Sat, 13 Jul 2019 09:54:41 GMT cache-control:private, max-age=0 last-modified:Tue, 09 Jul 2019 19:00:00 GMT x-content-type-options:nosniff server:sffe x-xss-protection:0 alt-svc:quic=":443"; ma=2592000; v="46,43,39"  ,45740, 5
[1:7:0713/025441.838086:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/025441.867921:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.google.cn/
[1:1:0713/025441.875050:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/025441.875829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 24fd7d301f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/025441.876098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[45644:45644:0713/025441.996630:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.google.cn/, https://www.google.cn/, 1
[45644:45644:0713/025441.996725:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.google.cn/, https://www.google.cn
[1:1:0713/025441.998334:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/025442.103628:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/025442.139588:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/025442.185812:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/025442.186094:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.google.cn/chrome/"
[1:1:0713/025442.238921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 130 0x7f955b792070 0xbf6773480e0 , "https://www.google.cn/chrome/"
[1:1:0713/025442.241608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , 
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||
[1:1:0713/025442.241952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025442.244863:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025442.264827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 130 0x7f955b792070 0xbf6773480e0 , "https://www.google.cn/chrome/"
[1:1:0713/025442.303563:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/025442.305321:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/025442.305533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 24fd7d42e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/025442.305817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/025442.358702:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/025442.460218:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/025442.461155:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/025442.461487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 24fd7d42e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/025442.461824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/025442.827899:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192, "https://www.google.cn/chrome/"
[1:1:0713/025442.835290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , /**
 * @license
 * MIT License
 * Copyright (c) 2009–2011
 * Permission is hereby granted, free of
[1:1:0713/025442.835557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/025443.701494:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025443.702009:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025443.702444:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025443.702938:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025443.703347:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[45644:45644:0713/025521.869692:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/025521.876630:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/025522.014925:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025522.160294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f955d6ba2e0 0xbf677444460 , "https://www.google.cn/chrome/"
[1:1:0713/025522.175097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , /**
 * @license
 * Copyright 2016 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache L
[1:1:0713/025522.175396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025522.382438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/025522.382708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025523.288612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , document.readyState
[1:1:0713/025523.288920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025523.335557:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 276 0x7f955b792070 0xbf6774a0060 , "https://www.google.cn/chrome/"
[1:1:0713/025523.337318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , 
  /*! loadCSS rel=preload polyfill. [c]2017 Filament Group, Inc. MIT License */
!function(n){"use s
[1:1:0713/025523.337597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025523.591816:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.249074, 1304, 1
[1:1:0713/025523.592083:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/025523.707701:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/025523.897269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.google.cn/chrome/"
[1:1:0713/025523.899587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , onload, this.onload=null;this.rel='stylesheet'
[1:1:0713/025523.899832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025526.093455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , document.readyState
[1:1:0713/025526.093856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025526.317313:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/025526.317575:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.google.cn/chrome/"
[1:1:0713/025526.322123:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f955b792070 0xbf6775746e0 , "https://www.google.cn/chrome/"
[1:1:0713/025526.330686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , /** @license ScrollMagic v2.0.6 | (c) 2018 Jan Paepke (@janpaepke) | license & info: http://scrollma
[1:1:0713/025526.330924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025526.343224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f955b792070 0xbf6775746e0 , "https://www.google.cn/chrome/"
[1:1:0713/025526.353797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f955b792070 0xbf6775746e0 , "https://www.google.cn/chrome/"
[1:1:0713/025526.413893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f955b792070 0xbf6775746e0 , "https://www.google.cn/chrome/"
[1:1:0713/025526.487881:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.google.cn/chrome/"
[1:1:0713/025526.524236:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7240
[1:1:0713/025526.524495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025526.524894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 414
[1:1:0713/025526.525123:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 414 0x7f955b792070 0xbf6779a1ce0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 314 0x7f955b792070 0xbf6775746e0 
[1:1:0713/025526.614498:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.google.cn/chrome/"
[1:1:0713/025526.822306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f955d6ba2e0 0xbf6774a7260 , "https://www.google.cn/chrome/"
[1:1:0713/025526.834065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0713/025526.834359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
		remove user.10_94e564c7 -> 0
		remove user.11_16879e83 -> 0
[1:1:0713/025527.739836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , document.readyState
[1:1:0713/025527.740013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025527.864938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , F, (){if(S&&p){var e=i.type.Array(p)?p:g.slice(0);p=!1;var t=v;v=d.scrollPos();var n=v-t;0!==n&&(m=n>0?
[1:1:0713/025527.865198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025528.673296:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 414, 7f955e0d7881
[1:1:0713/025528.687836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"314 0x7f955b792070 0xbf6775746e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025528.688188:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"314 0x7f955b792070 0xbf6775746e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025528.688602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025528.689275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025528.689580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025528.693716:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025528.694040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025528.694459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 486
[1:1:0713/025528.694797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 486 0x7f955b792070 0xbf677561160 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 414 0x7f955b792070 0xbf6779a1ce0 
[1:1:0713/025529.025642:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 465 0x7f955d6ba2e0 0xbf67778bce0 , "https://www.google.cn/chrome/"
[1:1:0713/025529.036052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0713/025529.036313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025529.097151:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7148
[1:1:0713/025529.097416:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025529.097820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 490
[1:1:0713/025529.098052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7f955b792070 0xbf6773e5560 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 465 0x7f955d6ba2e0 0xbf67778bce0 
[1:1:0713/025529.099378:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7148
[1:1:0713/025529.099605:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025529.099959:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 491
[1:1:0713/025529.100179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 491 0x7f955b792070 0xbf6777833e0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 465 0x7f955d6ba2e0 0xbf67778bce0 
[1:1:0713/025529.165788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , document.readyState
[1:1:0713/025529.166066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025529.363278:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 486, 7f955e0d7881
[1:1:0713/025529.383279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"414 0x7f955b792070 0xbf6779a1ce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025529.383612:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"414 0x7f955b792070 0xbf6779a1ce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025529.383974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025529.384537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025529.384762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025529.387580:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025529.387798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025529.388178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 500
[1:1:0713/025529.388401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 500 0x7f955b792070 0xbf67796fae0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 486 0x7f955b792070 0xbf677561160 
[1:1:0713/025529.507003:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.google.cn/chrome/"
[1:1:0713/025529.507722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , b, (c){return a.call(b.src,b.listener,c)}
[1:1:0713/025529.507938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025529.541748:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.google.cn/chrome/"
[1:1:0713/025529.542830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7200
[1:1:0713/025529.543033:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025529.543529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 511
[1:1:0713/025529.543759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7f955b792070 0xbf67745d6e0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 492 0x7f955b792070 0xbf6777ae9e0 
[1:1:0713/025529.579981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 490, 7f955e0d7881
[1:1:0713/025529.601108:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"465 0x7f955d6ba2e0 0xbf67778bce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025529.601409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"465 0x7f955d6ba2e0 0xbf67778bce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025529.601798:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025529.602328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0713/025529.602563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025529.805656:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025529.805983:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025529.806504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 520
[1:1:0713/025529.806785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 520 0x7f955b792070 0xbf67796e660 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 490 0x7f955b792070 0xbf6773e5560 
[1:1:0713/025530.659307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025530.659634:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025530.660159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 553
[1:1:0713/025530.660451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 553 0x7f955b792070 0xbf677956a60 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 490 0x7f955b792070 0xbf6773e5560 
[1:1:0713/025530.669835:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025530.670181:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025530.670705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 554
[1:1:0713/025530.671055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7f955b792070 0xbf677564360 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 490 0x7f955b792070 0xbf6773e5560 
[1:1:0713/025530.676106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025530.676383:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025530.676916:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 555
[1:1:0713/025530.677238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 555 0x7f955b792070 0xbf6774b6a60 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 490 0x7f955b792070 0xbf6773e5560 
[1:1:0713/025530.686858:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025530.687197:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025530.687787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 556
[1:1:0713/025530.688169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 556 0x7f955b792070 0xbf677567be0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 490 0x7f955b792070 0xbf6773e5560 
[1:1:0713/025530.699064:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025530.699280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 0
[1:1:0713/025530.699657:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 557
[1:1:0713/025530.699921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7f955b792070 0xbf676fbe5e0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 490 0x7f955b792070 0xbf6773e5560 
[1:1:0713/025530.740666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 491, 7f955e0d7881
[1:1:0713/025530.765120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"465 0x7f955d6ba2e0 0xbf67778bce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025530.765446:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"465 0x7f955d6ba2e0 0xbf67778bce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025530.765888:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025530.766453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0713/025530.766667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025530.879242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , document.readyState
[1:1:0713/025530.879532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025531.121476:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 500, 7f955e0d7881
[1:1:0713/025531.139497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"486 0x7f955b792070 0xbf677561160 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025531.139804:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"486 0x7f955b792070 0xbf677561160 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025531.140218:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025531.140819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025531.141082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025531.153198:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025531.153573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025531.154366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 583
[1:1:0713/025531.154701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7f955b792070 0xbf67775fce0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 500 0x7f955b792070 0xbf67796fae0 
[1:1:0713/025531.156863:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 511, 7f955e0d7881
[1:1:0713/025531.184009:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"492 0x7f955b792070 0xbf6777ae9e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025531.184745:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"492 0x7f955b792070 0xbf6777ae9e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025531.185636:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025531.186829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , (){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))}
[1:1:0713/025531.187321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.412015:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551 0x7f955d6ba2e0 0xbf676fa56e0 , "https://www.google.cn/chrome/"
[1:1:0713/025532.415268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0713/025532.415513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.508647:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.google.cn/chrome/"
[1:1:0713/025532.598732:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 520, 7f955e0d7881
[1:1:0713/025532.621808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.622106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.622499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025532.623029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/025532.623241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.651314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 553, 7f955e0d7881
[1:1:0713/025532.674450:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.674759:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.675102:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025532.675667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/025532.675878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.712270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 554, 7f955e0d7881
[1:1:0713/025532.735734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.736031:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.736386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025532.736903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/025532.737113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.739685:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 555, 7f955e0d7881
[1:1:0713/025532.777036:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.777384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.777812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025532.778350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/025532.778626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.804464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 556, 7f955e0d7881
[1:1:0713/025532.827706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.828002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.828359:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025532.828912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/025532.829177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.856280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 557, 7f955e0d7881
[1:1:0713/025532.890336:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.890699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"490 0x7f955b792070 0xbf6773e5560 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.891056:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025532.891562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , w.vtp_gtmOnSuccess, (){if(!x){x=!0;var B=xa()-C;fd(c.id,Sb[a],"5");Od(c.id,y,"success",B);h()}}
[1:1:0713/025532.891777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025532.971499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 583, 7f955e0d7881
[1:1:0713/025532.996341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"500 0x7f955b792070 0xbf67796fae0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.996952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"500 0x7f955b792070 0xbf67796fae0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025532.997697:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025532.998820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025532.999288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025533.004381:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025533.004800:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025533.005505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 619
[1:1:0713/025533.005944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f955b792070 0xbf6773ba360 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 583 0x7f955b792070 0xbf67775fce0 
[1:1:0713/025533.171072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.google.cn/chrome/"
[1:1:0713/025533.171848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0713/025533.172130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025533.176490:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 619, 7f955e0d7881
[1:1:0713/025533.213515:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"583 0x7f955b792070 0xbf67775fce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.214164:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"583 0x7f955b792070 0xbf67775fce0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.215065:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025533.216365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025533.216853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025533.221345:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025533.221548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025533.221935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 633
[1:1:0713/025533.222153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f955b792070 0xbf677375ee0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 619 0x7f955b792070 0xbf6773ba360 
[1:1:0713/025533.381965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 633, 7f955e0d7881
[1:1:0713/025533.406062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"619 0x7f955b792070 0xbf6773ba360 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.406635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"619 0x7f955b792070 0xbf6773ba360 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.407348:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025533.408398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025533.408859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025533.413983:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025533.414429:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025533.415184:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 644
[1:1:0713/025533.415642:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7f955b792070 0xbf677419a60 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 633 0x7f955b792070 0xbf677375ee0 
[1:1:0713/025533.570907:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 644, 7f955e0d7881
[1:1:0713/025533.595460:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"633 0x7f955b792070 0xbf677375ee0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.595841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"633 0x7f955b792070 0xbf677375ee0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.596268:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025533.596868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025533.597145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025533.599680:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025533.599908:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025533.600272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 655
[1:1:0713/025533.600496:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7f955b792070 0xbf678825b60 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 644 0x7f955b792070 0xbf677419a60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/025533.710122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 655, 7f955e0d7881
[1:1:0713/025533.746611:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"644 0x7f955b792070 0xbf677419a60 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.747044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"644 0x7f955b792070 0xbf677419a60 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025533.747541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025533.748192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025533.748471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025533.756181:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025533.756394:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025533.756799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 669
[1:1:0713/025533.757297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f955b792070 0xbf6782a8060 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 655 0x7f955b792070 0xbf678825b60 
[1:1:0713/025533.989397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 669, 7f955e0d7881
[1:1:0713/025534.038651:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"655 0x7f955b792070 0xbf678825b60 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.039118:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"655 0x7f955b792070 0xbf678825b60 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.039549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025534.040194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025534.040475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025534.043153:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025534.043418:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025534.043873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 681
[1:1:0713/025534.044173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f955b792070 0xbf678823be0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 669 0x7f955b792070 0xbf6782a8060 
[1:1:0713/025534.320577:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 681, 7f955e0d7881
[1:1:0713/025534.346277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"669 0x7f955b792070 0xbf6782a8060 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.347100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"669 0x7f955b792070 0xbf6782a8060 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.347991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025534.349314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025534.349721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025534.353701:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025534.354211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025534.355166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 687
[1:1:0713/025534.355667:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f955b792070 0xbf677419be0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 681 0x7f955b792070 0xbf678823be0 
[1:1:0713/025534.479657:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 687, 7f955e0d7881
[1:1:0713/025534.513339:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"681 0x7f955b792070 0xbf678823be0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.513679:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"681 0x7f955b792070 0xbf678823be0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.514099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025534.514649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025534.514876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025534.517980:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025534.518233:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025534.518612:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 700
[1:1:0713/025534.518842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f955b792070 0xbf6788949e0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 687 0x7f955b792070 0xbf677419be0 
[1:1:0713/025534.630816:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 700, 7f955e0d7881
[1:1:0713/025534.656547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"687 0x7f955b792070 0xbf677419be0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.656934:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"687 0x7f955b792070 0xbf677419be0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.657429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025534.657986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025534.658328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025534.662773:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025534.663013:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025534.663398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 704
[1:1:0713/025534.663624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 704 0x7f955b792070 0xbf6788942e0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 700 0x7f955b792070 0xbf6788949e0 
[1:1:0713/025534.805203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 704, 7f955e0d7881
[1:1:0713/025534.832249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"700 0x7f955b792070 0xbf6788949e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.832850:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"700 0x7f955b792070 0xbf6788949e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025534.833631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025534.834844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025534.835294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025534.841360:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025534.841716:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025534.842564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 706
[1:1:0713/025534.842989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7f955b792070 0xbf6774196e0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 704 0x7f955b792070 0xbf6788942e0 
[1:1:0713/025534.981428:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 706, 7f955e0d7881
[1:1:0713/025535.010174:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"704 0x7f955b792070 0xbf6788942e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.010594:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"704 0x7f955b792070 0xbf6788942e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.011061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025535.012222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025535.012661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025535.015433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025535.015696:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025535.016166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 708
[1:1:0713/025535.016479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7f955b792070 0xbf67749b460 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 706 0x7f955b792070 0xbf6774196e0 
[1:1:0713/025535.139781:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 708, 7f955e0d7881
[1:1:0713/025535.174064:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"706 0x7f955b792070 0xbf6774196e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.174811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"706 0x7f955b792070 0xbf6774196e0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.175759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025535.177131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025535.177694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025535.184804:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025535.185327:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025535.186366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 711
[1:1:0713/025535.186937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f955b792070 0xbf678823660 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 708 0x7f955b792070 0xbf67749b460 
[1:1:0713/025535.316035:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 711, 7f955e0d7881
[1:1:0713/025535.348625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"708 0x7f955b792070 0xbf67749b460 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.349426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"708 0x7f955b792070 0xbf67749b460 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.349925:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025535.350609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025535.350911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025535.353527:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025535.354019:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025535.354980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 713
[1:1:0713/025535.355498:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f955b792070 0xbf678894be0 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 711 0x7f955b792070 0xbf678823660 
[1:1:0713/025535.492067:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 713, 7f955e0d7881
[1:1:0713/025535.520059:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"711 0x7f955b792070 0xbf678823660 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.520747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"711 0x7f955b792070 0xbf678823660 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.521628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025535.522996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025535.523460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025535.530538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025535.531023:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025535.531998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 715
[1:1:0713/025535.532601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f955b792070 0xbf6779b0c60 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 713 0x7f955b792070 0xbf678894be0 
[1:1:0713/025535.680029:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 715, 7f955e0d7881
[1:1:0713/025535.706104:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"713 0x7f955b792070 0xbf678894be0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.706526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"713 0x7f955b792070 0xbf678894be0 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.706899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025535.707444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025535.707663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025535.711326:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025535.711709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025535.712529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 717
[1:1:0713/025535.713056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7f955b792070 0xbf6782a6260 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 715 0x7f955b792070 0xbf6779b0c60 
[1:1:0713/025535.851820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 717, 7f955e0d7881
[1:1:0713/025535.860913:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1c2aacf22860","ptid":"715 0x7f955b792070 0xbf6779b0c60 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.861295:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.google.cn/","ptid":"715 0x7f955b792070 0xbf6779b0c60 ","rf":"5:3_https://www.google.cn/"}
[1:1:0713/025535.861777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.google.cn/chrome/"
[1:1:0713/025535.862432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.google.cn/, 1c2aacf22860, , A, (){if(!w&&y!=z()){var e;try{e=new Event("resize",{bubbles:!1,cancelable:!1})}catch(t){e=document.cre
[1:1:0713/025535.862741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.google.cn/chrome/", "www.google.cn", 3, 1, , , 0
[1:1:0713/025535.865384:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2b5c2e2c29c8, 0xbf6771e7150
[1:1:0713/025535.865697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.google.cn/chrome/", 100
[1:1:0713/025535.866162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.google.cn/, 719
[1:1:0713/025535.866570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f955b792070 0xbf678822460 , 5:3_https://www.google.cn/, 1, -5:3_https://www.google.cn/, 717 0x7f955b792070 0xbf6782a6260 
