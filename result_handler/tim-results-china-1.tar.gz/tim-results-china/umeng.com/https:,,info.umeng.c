[0713/024229.872734:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/024229.873191:INFO:switcher_clone.cc(787)] backtrace rip is 7f1125c24891
[0713/024230.828334:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/024230.828746:INFO:switcher_clone.cc(787)] backtrace rip is 7f81ab4f0891
[1:1:0713/024230.839925:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/024230.840157:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/024230.845371:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[44296:44296:0713/024232.336707:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0713/024232.389551:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/024232.389939:INFO:switcher_clone.cc(787)] backtrace rip is 7f3395ed2891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/3acf4946-291f-4b2d-9a88-6c6a40994830
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[44327:44327:0713/024232.637543:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=44327
[44340:44340:0713/024232.637962:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=44340
[44296:44296:0713/024232.923927:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[44296:44325:0713/024232.924339:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/024232.924514:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/024232.924724:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/024232.925316:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/024232.925464:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/024232.929642:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x289f2ce3, 1
[1:1:0713/024232.929966:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1c492d90, 0
[1:1:0713/024232.930165:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x387e1cfe, 3
[1:1:0713/024232.930331:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x24d6dec9, 2
[1:1:0713/024232.930518:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff902d491c ffffffe32cffffff9f28 ffffffc9ffffffdeffffffd624 fffffffe1c7e38 , 10104, 4
[1:1:0713/024232.931475:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[44296:44325:0713/024232.931672:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�-I�,�(���$�~8�B
[44296:44325:0713/024232.931749:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �-I�,�(���$�~88��B
[1:1:0713/024232.931897:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f81a972b0a0, 3
[44296:44325:0713/024232.932068:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/024232.932110:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f81a98b6080, 2
[44296:44325:0713/024232.932190:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 44348, 4, 902d491c e32c9f28 c9ded624 fe1c7e38 
[1:1:0713/024232.932284:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8193579d20, -2
[1:1:0713/024232.951092:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/024232.951962:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 24d6dec9
[1:1:0713/024232.952956:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 24d6dec9
[1:1:0713/024232.954549:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 24d6dec9
[1:1:0713/024232.956043:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.956277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.956460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.956647:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.957300:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 24d6dec9
[1:1:0713/024232.957712:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f81ab4f07ba
[1:1:0713/024232.957849:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f81ab4e7def, 7f81ab4f077a, 7f81ab4f20cf
[1:1:0713/024232.964771:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 24d6dec9
[1:1:0713/024232.965297:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 24d6dec9
[1:1:0713/024232.966241:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 24d6dec9
[1:1:0713/024232.968752:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.968986:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.969238:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.969472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24d6dec9
[1:1:0713/024232.971069:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 24d6dec9
[1:1:0713/024232.971299:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f81ab4f07ba
[1:1:0713/024232.971381:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f81ab4e7def, 7f81ab4f077a, 7f81ab4f20cf
[1:1:0713/024232.973662:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/024232.973929:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/024232.974024:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdc9d27ae8, 0x7ffdc9d27a68)
[1:1:0713/024232.983768:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/024232.989578:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[44296:44296:0713/024233.496825:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[44296:44296:0713/024233.497332:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[44296:44307:0713/024233.522451:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[44296:44307:0713/024233.522571:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[44296:44296:0713/024233.522712:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[44296:44296:0713/024233.522814:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[44296:44296:0713/024233.522995:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,44348, 4
[1:7:0713/024233.524859:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[44296:44320:0713/024233.596018:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/024233.642935:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3f7d71055220
[1:1:0713/024233.643209:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/024234.012400:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/024235.658088:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024235.662189:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[44296:44296:0713/024235.901767:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[44296:44296:0713/024235.901923:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/024236.710846:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024237.026467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d141ea01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/024237.026763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024237.045131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d141ea01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/024237.045471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024237.163119:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024237.163407:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024237.508048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024237.516479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d141ea01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/024237.516723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024237.568736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024237.579554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d141ea01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/024237.579820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024237.591716:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/024237.596475:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f7d71053e20
[1:1:0713/024237.596742:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[44296:44296:0713/024237.604756:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[44296:44296:0713/024237.616664:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[44296:44296:0713/024237.638008:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[44296:44296:0713/024237.638102:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/024237.715227:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024238.543037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f81951542e0 0x3f7d712f95e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024238.544459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d141ea01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/024238.544722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024238.546189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[44296:44296:0713/024238.606763:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/024238.608943:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3f7d71054820
[1:1:0713/024238.609177:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[44296:44296:0713/024238.613834:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/024238.628459:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/024238.628722:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[44296:44296:0713/024238.629849:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[44296:44296:0713/024238.642056:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[44296:44296:0713/024238.643074:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[44296:44307:0713/024238.649155:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[44296:44307:0713/024238.649247:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[44296:44296:0713/024238.649451:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[44296:44296:0713/024238.649553:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[44296:44296:0713/024238.649697:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,44348, 4
[1:7:0713/024238.653436:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/024239.127161:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/024239.546604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f81951542e0 0x3f7d71423660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024239.547662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d141ea01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/024239.547898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024239.548660:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[44296:44296:0713/024239.788583:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[44296:44296:0713/024239.788704:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/024239.810046:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[44296:44296:0713/024240.215792:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[44296:44325:0713/024240.216338:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/024240.216559:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/024240.216872:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/024240.217348:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/024240.217516:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/024240.221137:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x17df22fd, 1
[1:1:0713/024240.221499:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3b3e2708, 0
[1:1:0713/024240.221651:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2ba067d7, 3
[1:1:0713/024240.221785:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xc72b60e, 2
[1:1:0713/024240.221957:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 08273e3b fffffffd22ffffffdf17 0effffffb6720c ffffffd767ffffffa02b , 10104, 5
[1:1:0713/024240.223336:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[44296:44325:0713/024240.223596:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING'>;�"��r�g�+~F
[44296:44325:0713/024240.223678:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is '>;�"��r�g�+�q~F
[1:1:0713/024240.223815:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f81a972b0a0, 3
[44296:44325:0713/024240.223966:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 44393, 5, 08273e3b fd22df17 0eb6720c d767a02b 
[1:1:0713/024240.224063:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f81a98b6080, 2
[1:1:0713/024240.224280:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8193579d20, -2
[1:1:0713/024240.248755:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/024240.249053:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c72b60e
[1:1:0713/024240.249243:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c72b60e
[1:1:0713/024240.249504:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c72b60e
[1:1:0713/024240.250032:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.250135:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.250225:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.250343:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.250571:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c72b60e
[1:1:0713/024240.250697:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f81ab4f07ba
[1:1:0713/024240.250804:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f81ab4e7def, 7f81ab4f077a, 7f81ab4f20cf
[1:1:0713/024240.252374:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c72b60e
[1:1:0713/024240.252530:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c72b60e
[1:1:0713/024240.252783:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c72b60e
[1:1:0713/024240.253452:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.253566:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.253668:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.253762:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c72b60e
[1:1:0713/024240.253767:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024240.254229:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c72b60e
[1:1:0713/024240.254386:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f81ab4f07ba
[1:1:0713/024240.254457:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f81ab4e7def, 7f81ab4f077a, 7f81ab4f20cf
[1:1:0713/024240.256656:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/024240.257002:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/024240.257094:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdc9d27ae8, 0x7ffdc9d27a68)
[1:1:0713/024240.269387:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/024240.273638:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/024240.429676:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f7d71024220
[1:1:0713/024240.429948:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/024240.795822:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024240.796145:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/024241.217305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/024241.222015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d141eb2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/024241.222354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/024241.230434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[44296:44296:0713/024241.336916:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[44296:44296:0713/024241.346148:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[44296:44307:0713/024241.391699:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[44296:44307:0713/024241.391799:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[44296:44296:0713/024241.392360:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://info.umeng.com/
[44296:44296:0713/024241.392474:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://info.umeng.com/, https://info.umeng.com/detail/201941/1554082726948, 1
[44296:44296:0713/024241.392641:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://info.umeng.com/, HTTP/1.1 200 status:200 date:Sat, 13 Jul 2019 09:42:41 GMT content-type:text/html; charset=utf-8 vary:Accept-Encoding vary:Ali-Detector-Type cache-control:max-age=60, s-maxage=90 eagleeye-traceid:0b150b7915630109612671454ee6de eagleeye-traceid:0b150b7915630109612671454ee6de strict-transport-security:max-age=31536000 strict-transport-security:max-age=31536000 timing-allow-origin:*, * timing-allow-origin:* content-md5:qP3VL0vNau4VPkT2g5UNwQ== via:cache18.l2cm9-2[24,304-0,H], cache8.l2cm9-2[25,0], bcache3.cn1570[38,200-0,H], bcache6.cn1570[40,0] ali-swift-global-savetime:1562689768 age:0 x-cache:HIT TCP_REFRESH_HIT dirn:37:315249012 x-swift-savetime:Sat, 13 Jul 2019 09:42:41 GMT x-swift-cachetime:90 eagleid:0b150b7915630109612671454ee6de content-encoding:gzip server:Tengine/Aserver  ,44393, 5
[1:7:0713/024241.401967:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/024241.431194:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://info.umeng.com/
[44296:44296:0713/024241.530141:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://info.umeng.com/, https://info.umeng.com/, 1
[44296:44296:0713/024241.530243:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://info.umeng.com/, https://info.umeng.com
[1:1:0713/024241.591241:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/024241.619180:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024241.619966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d141ea01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/024241.620185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024241.722110:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024241.858701:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024241.858891:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024242.313332:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f819322c070 0x3f7d7126c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024242.315676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , "function"!=typeof Object.assign&&(Object.assign=function(t,n){"use strict";if(null==t)throw new Typ
[1:1:0713/024242.315864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024242.413586:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024242.425134:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f81a98b6080 0x3f7d711c1b00 1 0 0x3f7d711c1b18 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024242.426986:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024242.435873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , /*!
Copyright 2015, KISSY v6.2.4
MIT Licensed
*/
!function e(t,n,r){function i(a,u){if(!n[a]){if(!t[
[1:1:0713/024242.436076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/024242.994915:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024242.997686:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024242.998082:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024242.998510:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024242.998879:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[44296:44296:0713/024322.060568:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/024322.069193:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/024322.151803:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f81a98b6080 0x3f7d711c1b00 1 0 0x3f7d711c1b18 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024322.164503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f81a98b6080 0x3f7d711c1b00 1 0 0x3f7d711c1b18 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024322.165719:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f81a98b6080 0x3f7d711c1b00 1 0 0x3f7d711c1b18 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024322.167522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f81a98b6080 0x3f7d711c1b00 1 0 0x3f7d711c1b18 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024322.342575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/024322.342742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024322.755007:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7f819322c070 0x3f7d713a51e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024322.755714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , 
with(document)with(body)with(insertBefore(createElement("script"),firstChild))setAttribute("exparam
[1:1:0713/024322.755830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024322.759327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7f819322c070 0x3f7d713a51e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024322.774715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7f819322c070 0x3f7d713a51e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024322.789433:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0305722, 243, 1
[1:1:0713/024322.789614:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024323.150513:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024323.150736:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024323.153265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298 0x7f819322c070 0x3f7d7147f8e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024323.155046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , !function(e){function t(o){if(n[o])return n[o].exports;var r=n[o]={"exports":{},"id":o,"loaded":!1};
[1:1:0713/024323.155202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024323.184177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 50
[1:1:0713/024323.184413:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.umeng.com/, 326
[1:1:0713/024323.184670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7f819322c070 0x3f7d7143e460 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 298 0x7f819322c070 0x3f7d7147f8e0 
[1:1:0713/024323.187256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298 0x7f819322c070 0x3f7d7147f8e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024323.206343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298 0x7f819322c070 0x3f7d7147f8e0 , "https://info.umeng.com/detail/201941/1554082726948"
[44296:44296:0713/024323.208052:INFO:CONSOLE(339)] "Mixed Content: The page at 'https://info.umeng.com/detail/201941/1554082726948' was loaded over HTTPS, but requested an insecure image 'http://img.alicdn.com/tfs/TB1HXRmXuuSBuNjy1XcXXcYjFXa-190-190.gif'. This content should also be served over HTTPS.", source: https://info.umeng.com/detail/201941/1554082726948 (339)
[1:1:0713/024323.224545:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0737882, 58, 1
[1:1:0713/024323.224782:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024323.380357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 308 0x7f81951542e0 0x3f7d7117ad60 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024323.382109:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024323.389127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , !function(a){function b(){b.done||(b.done=!0,S=!0,N=!1,P.each(ca,function(a){a._dom_loaded()}))}func
[1:1:0713/024323.389311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024323.816011:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xb687a9a29c8, 0x3f7d709e0198
[1:1:0713/024323.816227:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 3000
[1:1:0713/024323.816622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 377
[1:1:0713/024323.816831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 377 0x7f819322c070 0x3f7d71631ce0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 308 0x7f81951542e0 0x3f7d7117ad60 
[1:1:0713/024323.913609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f81951542e0 0x3f7d713eb5e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024323.916977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , !function e(t,n,r){function a(i,u){if(!n[i]){if(!t[i]){var s="function"==typeof require&&require;if(
[1:1:0713/024323.917234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024324.687845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024324.688739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024324.817906:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 318 0x7f81951542e0 0x3f7d71395de0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024324.819579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , !function e(t,n,r){function a(i,u){if(!n[i]){if(!t[i]){var s="function"==typeof require&&require;if(
[1:1:0713/024324.819798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024325.246301:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024325.246555:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024325.318013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.umeng.com/, 326, 7f8195b718db
[1:1:0713/024325.337457:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"298 0x7f819322c070 0x3f7d7147f8e0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024325.337785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"298 0x7f819322c070 0x3f7d7147f8e0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024325.338249:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.umeng.com/, 453
[1:1:0713/024325.338477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 453 0x7f819322c070 0x3f7d71945ee0 , 5:3_https://info.umeng.com/, 0, , 326 0x7f819322c070 0x3f7d7143e460 
[1:1:0713/024325.338803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024325.339424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (){R?(clearInterval(a),e.call(this)):n>r&&clearInterval(a),n++}
[1:1:0713/024325.339646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024326.529062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0713/024326.529330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024326.537821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0713/024326.538060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024326.777553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024326.777848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024327.591207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f81951542e0 0x3f7d713a55e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.593159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , /**/window['reqwest_1563011003165244711']({"page":{"deviceType":"pc","charset":"utf-8","backgroundCo
[1:1:0713/024327.593379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024327.597554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.636587:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f81951542e0 0x3f7d718e4060 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.637598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , /**/reqwest_1563011003181065085({"ret":200,"msg":"success","data":{"umplus_uc_loginid":null,"umplus_
[1:1:0713/024327.637831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024327.638874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.726074:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449, "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.726911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , 

(function(){
    if(window.umSiteFontLoaded){return;}
    var domStyle = document.createElement(
[1:1:0713/024327.727139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024327.754992:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.025924, 158, 1
[1:1:0713/024327.755270:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024327.809217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7f81951542e0 0x3f7d71a555e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.812215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , /**/window['reqwest_1563011003172403133']({"page":{"deviceType":"pc","charset":"utf-8","backgroundCo
[1:1:0713/024327.812436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024327.816864:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.846865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7f81951542e0 0x3f7d71a44e60 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024327.848331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0713/024327.848583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024328.394544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024328.395339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , window.(anonymous function).onload, (){try{l=!0,this.onload=null,window[this.umname]=null,!d&&c&&(e.fire_request_handles(b,{_transport:"
[1:1:0713/024328.395554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024328.471070:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024328.471856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/024328.472083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024328.647340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024328.647630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024328.674680:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 377, 7f8195b71881
[1:1:0713/024328.686500:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"308 0x7f81951542e0 0x3f7d7117ad60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024328.686848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"308 0x7f81951542e0 0x3f7d7117ad60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024328.687264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024328.687874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (){l||(d=!0,"function"==typeof c&&(e.fire_request_handles(b,{_transport:"img",_status:1,_result:0}),
[1:1:0713/024328.688124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024329.863728:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024329.863998:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024329.868314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f819322c070 0x3f7d7144c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024329.870752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , !function(e){function t(n){if(r[n])return r[n].exports;var s=r[n]={"exports":{},"id":n,"loaded":!1};
[1:1:0713/024329.870986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024329.878024:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 50
[1:1:0713/024329.878522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.umeng.com/, 570
[1:1:0713/024329.878761:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 570 0x7f819322c070 0x3f7d71f34b60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 525 0x7f819322c070 0x3f7d7144c360 
[1:1:0713/024329.887320:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f819322c070 0x3f7d7144c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024329.890709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f819322c070 0x3f7d7144c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024329.901173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f819322c070 0x3f7d7144c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024329.922780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f819322c070 0x3f7d7144c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024329.944034:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f819322c070 0x3f7d7144c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024329.952915:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb687a9a29c8, 0x3f7d709e01a8
[1:1:0713/024329.953137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 0
[1:1:0713/024329.953576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 588
[1:1:0713/024329.953870:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7f819322c070 0x3f7d70990f60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 525 0x7f819322c070 0x3f7d7144c360 
[1:1:0713/024329.961080:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f819322c070 0x3f7d7144c360 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024330.094857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (e){t(e)}
[1:1:0713/024330.095159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024330.102352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 536 0x7f81a678bbb0 0x3f7d711e4960 0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024330.450935:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0xb687a9a29c8, 0x3f7d709e0588
[1:1:0713/024330.451200:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 1000
[1:1:0713/024330.451667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 603
[1:1:0713/024330.451897:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 603 0x7f819322c070 0x3f7d722f5d60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 536 0x7f81a678bbb0 0x3f7d711e4960 0 
[1:1:0713/024330.544596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xb687a9a29c8, 0x3f7d709e0588
[1:1:0713/024330.544859:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 500
[1:1:0713/024330.545292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 606
[1:1:0713/024330.545519:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f819322c070 0x3f7d723f8f60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 536 0x7f81a678bbb0 0x3f7d711e4960 0 
[1:1:0713/024330.706960:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0xb687a9a29c8, 0x3f7d709e0588
[1:1:0713/024330.707231:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 5000
[1:1:0713/024330.707686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 618
[1:1:0713/024330.707917:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f819322c070 0x3f7d724719e0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 536 0x7f81a678bbb0 0x3f7d711e4960 0 
[1:1:0713/024330.729520:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xb687a9a29c8, 0x3f7d709e0588
[1:1:0713/024330.729777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 10
[1:1:0713/024330.730203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 619
[1:1:0713/024330.730480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f819322c070 0x3f7d724b73e0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 536 0x7f81a678bbb0 0x3f7d711e4960 0 
[1:1:0713/024330.875167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024330.875468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024332.267107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 582, "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024332.268432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , 

(function (ele, event, cb) {
    ele = ele || {};
    if (ele.addEventListener) {
        ele.ad
[1:1:0713/024332.268660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[44296:44296:0713/024332.270311:INFO:CONSOLE(0)] "Access to Script at 'https://s.umeng.com/tracker/clue.js?pid=umsite' from origin 'https://info.umeng.com' has been blocked by CORS policy: The 'Access-Control-Allow-Origin' header has a value 'https://www.umeng.com' that is not equal to the supplied origin. Origin 'https://info.umeng.com' is therefore not allowed access.", source: https://info.umeng.com/detail/201941/1554082726948 (0)
[1:1:0713/024332.273473:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024332.276402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024332.312110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024332.313607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , o.port1.onmessage, (){i=a,o.port1.onmessage=e,e()}
[1:1:0713/024332.313838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024332.314583:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x281323b92c48
[1:1:0713/024333.415353:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.umeng.com/, 570, 7f8195b718db
[1:1:0713/024333.445021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"525 0x7f819322c070 0x3f7d7144c360 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024333.445404:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"525 0x7f819322c070 0x3f7d7144c360 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024333.445866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.umeng.com/, 681
[1:1:0713/024333.446098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f819322c070 0x3f7d72c7cae0 , 5:3_https://info.umeng.com/, 0, , 570 0x7f819322c070 0x3f7d71f34b60 
[1:1:0713/024333.446460:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024333.447057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (){p?(clearInterval(o),e.call(this)):r>s&&clearInterval(o),r++}
[1:1:0713/024333.447282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024333.479787:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 588, 7f8195b71881
[1:1:0713/024333.509452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"525 0x7f819322c070 0x3f7d7144c360 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024333.509785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"525 0x7f819322c070 0x3f7d7144c360 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024333.510211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024333.510812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , e, (){for(var e,n=0;e=t[n++];)e();n>1&&(t=[]),r=0}
[1:1:0713/024333.511030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024334.290144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 619, 7f8195b71881
[1:1:0713/024334.322060:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024334.322459:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024334.322865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024334.323541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0713/024334.323754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024334.492082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024334.492392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024334.561442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 606, 7f8195b71881
[1:1:0713/024334.587164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024334.587558:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024334.588076:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024334.588750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0713/024334.588959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024334.591196:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xb687a9a29c8, 0x3f7d709e0150
[1:1:0713/024334.591446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 500
[1:1:0713/024334.591883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 702
[1:1:0713/024334.592111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f819322c070 0x3f7d71e3cd60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 606 0x7f819322c070 0x3f7d723f8f60 
[1:1:0713/024334.907230:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 603, 7f8195b71881
[1:1:0713/024334.939972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024334.940356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024334.940771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024334.941396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0713/024334.941635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024336.415197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024336.415513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024336.488682:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024336.489549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , n.onload, (){i()}
[1:1:0713/024336.489792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024336.840038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 702, 7f8195b71881
[1:1:0713/024336.876844:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"606 0x7f819322c070 0x3f7d723f8f60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024336.877258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"606 0x7f819322c070 0x3f7d723f8f60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024336.877678:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024336.878349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0713/024336.878612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024336.880504:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xb687a9a29c8, 0x3f7d709e0150
[1:1:0713/024336.880713:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 500
[1:1:0713/024336.881170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 761
[1:1:0713/024336.881446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7f819322c070 0x3f7d72978a60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 702 0x7f819322c070 0x3f7d71e3cd60 
[1:1:0713/024337.144273:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 618, 7f8195b71881
[1:1:0713/024337.181432:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024337.181783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"536 0x7f81a678bbb0 0x3f7d711e4960 0 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024337.182259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024337.182882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0713/024337.183115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/024337.429174:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 737 0x7f81951542e0 0x3f7d72cca060 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024337.430675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0713/024337.430900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024337.517405:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738 0x7f81951542e0 0x3f7d7269d4e0 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024337.518555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="R3KTFa0Quk8CAdrxhyKpAJUj";goldlog.stag=1;
[1:1:0713/024337.518837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024337.519552:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024337.615447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024337.615725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024337.973182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f81951542e0 0x3f7d726c3e60 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024337.978700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , define("promise",[],function(){//! Copyright 2015, promise@6.1.1 MIT Licensed, build time: Thu, 29 O
[1:1:0713/024337.978992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024338.037148:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
		remove user.11_ab5fab7 -> 0
[1:1:0713/024338.615865:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024340.183428:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 761, 7f8195b71881
[1:1:0713/024340.220630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"702 0x7f819322c070 0x3f7d71e3cd60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024340.220950:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"702 0x7f819322c070 0x3f7d71e3cd60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024340.221362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024340.221957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0713/024340.222135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024340.223995:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xb687a9a29c8, 0x3f7d709e0150
[1:1:0713/024340.224160:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 500
[1:1:0713/024340.224551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 857
[1:1:0713/024340.224739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 857 0x7f819322c070 0x3f7d737025e0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 761 0x7f819322c070 0x3f7d72978a60 
[1:1:0713/024340.515964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , document.readyState
[1:1:0713/024340.516288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024341.019459:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024341.020248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , e, (){for(var e,n=0;e=t[n++];)e();n>1&&(t=[]),r=0}
[1:1:0713/024341.020427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[44296:44296:0713/024341.033035:INFO:CONSOLE(1)] "all modules : ", source: https://g.alicdn.com/code/npm/@ali/??straw/1.1.1/index.cmd.js,xctrl/7.2.4/xctrl-kissy.cmd.js,pi-kissy-pc/0.0.32/index.cmd.js,pi-kissy-pc/0.0.32/mod-base.cmd.js,xtemplate/4.5.0/runtime.cmd.js (1)
[44296:44296:0713/024341.127827:INFO:CONSOLE(1)] "首屏加载的模块：4个", source: https://g.alicdn.com/code/npm/@ali/??straw/1.1.1/index.cmd.js,xctrl/7.2.4/xctrl-kissy.cmd.js,pi-kissy-pc/0.0.32/index.cmd.js,pi-kissy-pc/0.0.32/mod-base.cmd.js,xtemplate/4.5.0/runtime.cmd.js (1)
[1:1:0713/024341.298273:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.298509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.298935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 909
[1:1:0713/024341.299153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7f819322c070 0x3f7d737cf9e0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.393227:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.393462:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.393871:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 911
[1:1:0713/024341.394066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 911 0x7f819322c070 0x3f7d73856be0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.487689:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.487921:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.488500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 913
[1:1:0713/024341.488703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 913 0x7f819322c070 0x3f7d738b2ee0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.632482:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.632665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 5000
[1:1:0713/024341.632863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 915
[1:1:0713/024341.632972:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 915 0x7f819322c070 0x3f7d73995060 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.705399:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.705566:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.705755:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 918
[1:1:0713/024341.705864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7f819322c070 0x3f7d73a48b60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.739024:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.739297:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.739786:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 919
[1:1:0713/024341.740021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7f819322c070 0x3f7d739e4de0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.818772:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.819014:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.819347:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 921
[1:1:0713/024341.819482:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f819322c070 0x3f7d73b1cfe0 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.863987:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.864144:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.864347:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 922
[1:1:0713/024341.864457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f819322c070 0x3f7d73b26860 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024341.913477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xb687a9a29c8, 0x3f7d709e0210
[1:1:0713/024341.913645:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 100
[1:1:0713/024341.913833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 925
[1:1:0713/024341.913943:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7f819322c070 0x3f7d73ba4a60 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 823 0x7f81a98b6080 0x3f7d72d67e20 1 0 0x3f7d72d67e38 
[1:1:0713/024342.379987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 866 0x7f81951542e0 0x3f7d7359dd60 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024342.383295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0713/024342.383543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024342.609632:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024342.610610:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024342.612198:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:20:0713/024342.617375:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0713/024342.630228:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0xb687a9a29c8, 0x3f7d709e0190
[1:1:0713/024342.630490:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 5000
[1:1:0713/024342.630896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 956
[1:1:0713/024342.631088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7f819322c070 0x3f7d73b9a260 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 866 0x7f81951542e0 0x3f7d7359dd60 
[1:1:0713/024342.735496:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 867 0x7f81951542e0 0x3f7d73735060 , "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024342.737676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , , /* 2016-05-06 10:57:52 */
!function e(t,n,i){function r(o,a){if(!n[o]){if(!t[o]){var u="function"==t
[1:1:0713/024342.737862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024342.772617:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024343.672408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 857, 7f8195b71881
[1:1:0713/024343.686734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"212777ec2860","ptid":"761 0x7f819322c070 0x3f7d72978a60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024343.686926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.umeng.com/","ptid":"761 0x7f819322c070 0x3f7d72978a60 ","rf":"5:3_https://info.umeng.com/"}
[1:1:0713/024343.687148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.umeng.com/detail/201941/1554082726948"
[1:1:0713/024343.687473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.umeng.com/, 212777ec2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0713/024343.687587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.umeng.com/detail/201941/1554082726948", "info.umeng.com", 3, 1, , , 0
[1:1:0713/024343.688265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xb687a9a29c8, 0x3f7d709e0150
[1:1:0713/024343.688371:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.umeng.com/detail/201941/1554082726948", 500
[1:1:0713/024343.688580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.umeng.com/, 995
[1:1:0713/024343.688723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7f819322c070 0x3f7d73822460 , 5:3_https://info.umeng.com/, 1, -5:3_https://info.umeng.com/, 857 0x7f819322c070 0x3f7d737025e0 
