[0713/040432.349922:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/040432.350399:INFO:switcher_clone.cc(787)] backtrace rip is 7ff30d41c891
[0713/040433.309119:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/040433.309632:INFO:switcher_clone.cc(787)] backtrace rip is 7f73f0694891
[1:1:0713/040433.321776:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/040433.322056:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/040433.327334:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/040434.903582:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/040434.903997:INFO:switcher_clone.cc(787)] backtrace rip is 7fafdf91e891
[53530:53530:0713/040435.016206:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/d7083013-3422-4a90-861e-c56ce68bcc91
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[53563:53563:0713/040435.141379:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=53563
[53574:53574:0713/040435.141925:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=53574
[53530:53530:0713/040435.591401:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[53530:53560:0713/040435.592317:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/040435.592593:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/040435.592859:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/040435.593594:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/040435.593769:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/040435.597200:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xb8e8817, 1
[1:1:0713/040435.597595:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x847b832, 0
[1:1:0713/040435.597807:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3287c5e2, 3
[1:1:0713/040435.598016:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3553d46a, 2
[1:1:0713/040435.598304:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 32ffffffb84708 17ffffff88ffffff8e0b 6affffffd45335 ffffffe2ffffffc5ffffff8732 , 10104, 4
[1:1:0713/040435.599343:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[53530:53560:0713/040435.599597:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING2�G��j�S5�Ň2���
[53530:53560:0713/040435.599661:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 2�G��j�S5�Ň2�͐��
[1:1:0713/040435.599774:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73ee8cf0a0, 3
[53530:53560:0713/040435.599929:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[53530:53560:0713/040435.600010:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 53582, 4, 32b84708 17888e0b 6ad45335 e2c58732 
[1:1:0713/040435.600012:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73eea5a080, 2
[1:1:0713/040435.600159:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73d871dd20, -2
[1:1:0713/040435.614604:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/040435.615545:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3553d46a
[1:1:0713/040435.616508:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3553d46a
[1:1:0713/040435.618090:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3553d46a
[1:1:0713/040435.619607:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.619817:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.619999:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.620197:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.620856:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3553d46a
[1:1:0713/040435.621163:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73f06947ba
[1:1:0713/040435.621297:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73f068bdef, 7f73f069477a, 7f73f06960cf
[1:1:0713/040435.627364:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3553d46a
[1:1:0713/040435.627865:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3553d46a
[1:1:0713/040435.628203:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3553d46a
[1:1:0713/040435.628966:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.629092:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.629193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.629288:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3553d46a
[1:1:0713/040435.630017:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3553d46a
[1:1:0713/040435.630273:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73f06947ba
[1:1:0713/040435.630369:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73f068bdef, 7f73f069477a, 7f73f06960cf
[1:1:0713/040435.632627:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/040435.632921:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/040435.633019:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffe600d158, 0x7fffe600d0d8)
[1:1:0713/040435.644187:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/040435.650985:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[53530:53530:0713/040436.291034:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[53530:53530:0713/040436.292408:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[53530:53541:0713/040436.314794:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[53530:53541:0713/040436.314928:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[53530:53530:0713/040436.315002:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[53530:53530:0713/040436.315102:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[53530:53530:0713/040436.315278:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,53582, 4
[1:7:0713/040436.318712:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[53530:53553:0713/040436.376074:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/040436.444071:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x340e5a16a220
[1:1:0713/040436.444412:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/040436.884009:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/040438.652624:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[53530:53530:0713/040438.653651:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[53530:53530:0713/040438.653768:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/040438.656058:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/040439.660427:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040439.814178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298ed51c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/040439.814510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/040439.845689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298ed51c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/040439.845968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/040440.087827:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040440.088134:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/040440.517065:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/040440.525496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298ed51c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/040440.525845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/040440.561883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/040440.574267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298ed51c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/040440.574643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/040440.587231:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[53530:53530:0713/040440.590757:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/040440.590765:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x340e5a168e20
[1:1:0713/040440.590996:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[53530:53530:0713/040440.599568:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[53530:53530:0713/040440.635494:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[53530:53530:0713/040440.635729:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/040440.689538:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/040441.488345:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f73da2f82e0 0x340e5a383460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/040441.489724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298ed51c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/040441.489990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/040441.491517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/040441.565364:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x340e5a169820
[1:1:0713/040441.565624:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[53530:53530:0713/040441.566690:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[53530:53530:0713/040441.582185:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/040441.584057:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/040441.584287:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[53530:53530:0713/040441.606213:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[53530:53530:0713/040441.622741:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[53530:53530:0713/040441.623761:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[53530:53541:0713/040441.629747:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[53530:53541:0713/040441.629827:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[53530:53530:0713/040441.631060:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[53530:53530:0713/040441.631142:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[53530:53530:0713/040441.631296:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,53582, 4
[1:7:0713/040441.634101:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/040442.250957:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/040442.800992:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7f73da2f82e0 0x340e5a3309e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/040442.802068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298ed51c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/040442.802474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/040442.803293:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[53530:53530:0713/040442.889615:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[53530:53530:0713/040442.889738:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/040442.890052:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[53530:53530:0713/040442.977390:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[53530:53560:0713/040442.977921:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/040442.978170:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/040442.995789:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/040442.997454:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/040442.997626:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/040443.001417:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2bfbf223, 1
[1:1:0713/040443.001972:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3161712a, 0
[1:1:0713/040443.002248:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3b2839fa, 3
[1:1:0713/040443.002586:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2168e894, 2
[1:1:0713/040443.002793:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2a716131 23fffffff2fffffffb2b ffffff94ffffffe86821 fffffffa39283b , 10104, 5
[1:1:0713/040443.004409:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[53530:53560:0713/040443.004834:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING*qa1#��+��h!�9(;t��
[53530:53560:0713/040443.004925:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is *qa1#��+��h!�9(;at��
[1:1:0713/040443.004823:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73ee8cf0a0, 3
[53530:53560:0713/040443.005242:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 53628, 5, 2a716131 23f2fb2b 94e86821 fa39283b 
[1:1:0713/040443.005432:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73eea5a080, 2
[1:1:0713/040443.005742:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73d871dd20, -2
[1:1:0713/040443.030740:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/040443.031205:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2168e894
[1:1:0713/040443.031765:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2168e894
[1:1:0713/040443.032466:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2168e894
[1:1:0713/040443.033879:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.034188:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.034517:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.034811:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.035678:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2168e894
[1:1:0713/040443.036009:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73f06947ba
[1:1:0713/040443.036222:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73f068bdef, 7f73f069477a, 7f73f06960cf
[1:1:0713/040443.041830:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2168e894
[1:1:0713/040443.042262:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2168e894
[1:1:0713/040443.043061:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2168e894
[1:1:0713/040443.045216:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.045566:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.045819:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.046064:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2168e894
[1:1:0713/040443.047518:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2168e894
[1:1:0713/040443.047942:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73f06947ba
[1:1:0713/040443.048156:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73f068bdef, 7f73f069477a, 7f73f06960cf
[1:1:0713/040443.052687:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/040443.053368:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/040443.053571:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffe600d158, 0x7fffe600d0d8)
[1:1:0713/040443.068709:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/040443.074830:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/040443.334973:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x340e5a13e220
[1:1:0713/040443.335305:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/040443.400458:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[53530:53530:0713/040443.868875:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[53530:53530:0713/040443.875409:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[53530:53541:0713/040443.933635:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[53530:53541:0713/040443.933772:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[53530:53530:0713/040443.934272:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://china.99114.com/
[53530:53530:0713/040443.934379:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://china.99114.com/, http://china.99114.com/106/, 1
[53530:53530:0713/040443.934570:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://china.99114.com/, HTTP/1.1 200 Server: Tengine Date: Sat, 13 Jul 2019 11:04:43 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Language: zh-CN Content-Encoding: gzip  ,53628, 5
[1:7:0713/040443.938800:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/040443.991852:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://china.99114.com/
[53530:53530:0713/040444.088564:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://china.99114.com/, http://china.99114.com/, 1
[53530:53530:0713/040444.088697:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://china.99114.com/, http://china.99114.com
[1:1:0713/040444.106148:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/040444.126427:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040444.126664:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/040444.198000:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040444.256058:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/040444.284368:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040444.284660:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040444.436152:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/040444.731049:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040444.801699:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/040445.029513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f73d8738bd0 0x340e5a258dd8 , "http://china.99114.com/106/"
[1:1:0713/040445.053565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , // JavaScript Document
/*! jQuery v@1.8.0 jquery.com | jquery.org/license */
(function(a,b){function
[1:1:0713/040445.053939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040445.056377:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040445.247693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f73d8738bd0 0x340e5a258dd8 , "http://china.99114.com/106/"
[1:1:0713/040445.260818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f73d8738bd0 0x340e5a258dd8 , "http://china.99114.com/106/"
[1:1:0713/040445.272027:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f73d8738bd0 0x340e5a258dd8 , "http://china.99114.com/106/"
[1:1:0713/040445.279487:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/040445.312449:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x340e5a13d820
[1:1:0713/040445.312752:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0713/040445.337216:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/040445.337511:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[1:1:0713/040445.388451:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040445.388943:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040445.391176:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040445.391798:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040445.392291:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040445.513987:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.267809, 557, 1
[1:1:0713/040445.514292:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040446.025893:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040446.026211:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040446.028134:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f73d83d0070 0x340e5a494c60 , "http://china.99114.com/106/"
[1:1:0713/040446.034441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , 
    /**
     * Created by duanz on 2015/12/22.
     */

    (function($){
        /**初始化基�
[1:1:0713/040446.034696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040446.047495:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f73d83d0070 0x340e5a494c60 , "http://china.99114.com/106/"
[1:1:0713/040446.076597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f73d83d0070 0x340e5a494c60 , "http://china.99114.com/106/"
[1:1:0713/040446.099206:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0728769, 117, 1
[1:1:0713/040446.099467:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040446.342881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 239 0x7f73da2f82e0 0x340e59d47660 , "http://china.99114.com/106/"
[1:1:0713/040446.344880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , /////////////工具类/////////////////////////////////////////////////////
/**
 * 判断浏览器�
[1:1:0713/040446.345129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040446.360909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb49d8
[1:1:0713/040446.361198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040446.361576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 264
[1:1:0713/040446.361806:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 264 0x7f73d83d0070 0x340e5a2aa260 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 239 0x7f73da2f82e0 0x340e59d47660 
[1:1:0713/040446.577008:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040446.577283:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040446.584507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f73d83d0070 0x340e5a25a060 , "http://china.99114.com/106/"
[1:1:0713/040446.615051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , var INTERACTIVE_PLUGIN=function(exports){"use strict";function getUID(){function t(t){var e,n=1,i=0;
[1:1:0713/040446.615372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[53530:53530:0713/040527.864387:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[53530:53530:0713/040527.871420:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[53530:53530:0713/040527.883450:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[53530:53530:0713/040527.970155:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/040528.024274:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/040528.041934:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 41.4646, 0, 0
[1:1:0713/040528.042231:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040528.114196:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 264, 7f73dad15881
[1:1:0713/040528.131001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"239 0x7f73da2f82e0 0x340e59d47660 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040528.131362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"239 0x7f73da2f82e0 0x340e59d47660 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040528.131693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040528.132310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0713/040528.132546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040528.133494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040528.133739:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040528.134146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 308
[1:1:0713/040528.134418:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 308 0x7f73d83d0070 0x340e5a2ca0e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 264 0x7f73d83d0070 0x340e5a2aa260 
[53530:53530:0713/040528.179197:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[53530:53530:0713/040528.184664:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/040528.217510:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","http://static.99114.cn/static/portal/imagesv4/logo.png"
[53530:53541:0713/040528.227904:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[53530:53541:0713/040528.227992:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[53530:53530:0713/040528.231075:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://trusted.shuidi.cn/
[53530:53530:0713/040528.231155:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://trusted.shuidi.cn/, http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0, 4
[53530:53530:0713/040528.231286:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://trusted.shuidi.cn/, HTTP/1.1 200 OK Server: nginx/1.9.12 Date: Sat, 13 Jul 2019 11:05:27 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: guid=a8833b8505b357a39e5e61a36b94e7eb; expires=Mon, 19-Jun-2119 11:05:28 GMT; Max-Age=3153600000; path=/; domain=shuidi.cn Access-Control-Allow-Origin: http://cha.shuidi.cn Access-Control-Allow-Methods: POST,GET Access-Control-Allow-Credentials: true Content-Encoding: gzip  ,53628, 5
[1:7:0713/040528.236201:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/040528.244064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/040528.244410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040528.429490:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040528.429831:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040528.431028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298 0x7f73d83d0070 0x340e59d3fd60 , "http://china.99114.com/106/"
[1:1:0713/040528.431989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , 
                INTERACTIVE_PLUGIN.render({
                    showid: 'kRmhRE',
                 
[1:1:0713/040528.432219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040528.459166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29c1971029c8, 0x340e59fb4998
[1:1:0713/040528.459410:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0713/040528.459816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 332
[1:1:0713/040528.460034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 332 0x7f73d83d0070 0x340e5a44eae0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 298 0x7f73d83d0070 0x340e59d3fd60 
[1:1:0713/040528.473910:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.043997, 96, 1
[1:1:0713/040528.474215:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040528.578961:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 308, 7f73dad15881
[1:1:0713/040528.593077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"264 0x7f73d83d0070 0x340e5a2aa260 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040528.593370:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"264 0x7f73d83d0070 0x340e5a2aa260 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040528.593643:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040528.594215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0713/040528.594445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040528.595102:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040528.595284:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040528.595632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 344
[1:1:0713/040528.595845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 344 0x7f73d83d0070 0x340e5a407360 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 308 0x7f73d83d0070 0x340e5a2ca0e0 
[1:1:0713/040528.764981:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://trusted.shuidi.cn/
[1:1:0713/040528.799136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , document.readyState
[1:1:0713/040528.799399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040529.016365:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040529.016611:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040529.017360:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f73d83d0070 0x340e5a2453e0 , "http://china.99114.com/106/"
[1:1:0713/040529.018212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , 
                    var mediav_ad_pub = 'HHqMvu_2335583';
                    var mediav_ad_width =
[1:1:0713/040529.018453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040529.024400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f73d83d0070 0x340e5a2453e0 , "http://china.99114.com/106/"
[1:1:0713/040529.030665:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040529.071743:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x340e59d43a20
[1:1:0713/040529.072013:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0713/040529.090898:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/040529.091117:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[1:1:0713/040529.095878:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 12000, 0x29c1971029c8, 0x340e59fb4ae0
[1:1:0713/040529.096087:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 12000
[1:1:0713/040529.096435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 362
[1:1:0713/040529.096654:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 362 0x7f73d83d0070 0x340e5a5f7c60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 336 0x7f73d83d0070 0x340e5a2453e0 
[1:1:0713/040529.097401:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29c1971029c8, 0x340e59fb4ae0
[1:1:0713/040529.097599:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0713/040529.097969:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 363
[1:1:0713/040529.098207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 363 0x7f73d83d0070 0x340e5a5f72e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 336 0x7f73d83d0070 0x340e5a2453e0 
[53530:53530:0713/040529.164195:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[53530:53530:0713/040529.166160:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: ifr2335583, 5, 5, 
[53530:53530:0713/040529.169437:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[53530:53530:0713/040529.253742:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[53530:53530:0713/040529.258275:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[53530:53541:0713/040529.297247:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[53530:53541:0713/040529.297336:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[53530:53530:0713/040529.297505:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://show.g.mediav.com/
[53530:53530:0713/040529.297585:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://show.g.mediav.com/, http://show.g.mediav.com/s?ver=1.2.8&enifr=1&showid=HHqMvu&type=1&of=2&uid=15630159290517926177300249344706&isifr=0&title=%E3%80%90%E7%BA%B8%E4%B8%9A%E3%80%91%E4%BC%81%E4%B8%9A%E5%90%8D%E5%BD%95_%E4%BC%81%E4%B8%9A%E9%BB%84%E9%A1%B5_%E4%BC%81%E4%B8%9A%E5%A4%A7%E5%85%A8-%E4%B8%AD&refurl=, 5
[53530:53530:0713/040529.297729:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://show.g.mediav.com/, HTTP/1.1 200 OK Server: nginx Date: Sat, 13 Jul 2019 11:05:29 GMT Content-Type: image/gif Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Pragma: no-cache P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Cache-Control: no-cache, must-revalidate Content-Encoding: gzip  ,53628, 5
[1:7:0713/040529.302625:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/040529.317922:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.301223, 2008, 1
[1:1:0713/040529.318196:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040529.409776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 344, 7f73dad15881
[1:1:0713/040529.426878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"308 0x7f73d83d0070 0x340e5a2ca0e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040529.427212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"308 0x7f73d83d0070 0x340e5a2ca0e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040529.427594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040529.428180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0713/040529.428438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040529.429393:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040529.429668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040529.430218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 392
[1:1:0713/040529.430455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 392 0x7f73d83d0070 0x340e5a246060 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 344 0x7f73d83d0070 0x340e5a407360 
[1:1:0713/040529.521056:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[53530:53530:0713/040529.523514:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://trusted.shuidi.cn/, http://trusted.shuidi.cn/, 4
[53530:53530:0713/040529.523610:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://trusted.shuidi.cn/, http://trusted.shuidi.cn
[1:1:0713/040532.734005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , document.readyState
[1:1:0713/040532.734352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040532.819826:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://show.g.mediav.com/
[1:1:0713/040532.850488:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040532.850751:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040532.864465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f73d83d0070 0x340e5a547de0 , "http://china.99114.com/106/"
[1:1:0713/040532.887894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , var BANNER_SLIDER=function(){"use strict";Date.now||(Date.now=function(){return+new Date}),Function.
[1:1:0713/040532.888158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040533.116095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f73d83d0070 0x340e5a547de0 , "http://china.99114.com/106/"
[1:1:0713/040533.222468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29c1971029c8, 0x340e59fb4998
[1:1:0713/040533.222759:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0713/040533.223308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 458
[1:1:0713/040533.223532:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 458 0x7f73d83d0070 0x340e5a21f260 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 384 0x7f73d83d0070 0x340e5a547de0 
[1:1:0713/040533.304538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29c1971029c8, 0x340e59fb4998
[1:1:0713/040533.304783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0713/040533.305171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 466
[1:1:0713/040533.305390:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 466 0x7f73d83d0070 0x340e5b0f1c60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 384 0x7f73d83d0070 0x340e5a547de0 
[1:1:0713/040533.343135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f73d83d0070 0x340e5a547de0 , "http://china.99114.com/106/"
[1:1:0713/040533.347164:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f73d83d0070 0x340e5a547de0 , "http://china.99114.com/106/"
[53530:53530:0713/040533.350870:INFO:CONSOLE(2899)] "Uncaught SyntaxError: Unexpected end of input", source: http://china.99114.com/106/ (2899)
[1:1:0713/040533.351890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f73d83d0070 0x340e5a547de0 , "http://china.99114.com/106/"
[53530:53530:0713/040533.390785:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/040533.392995:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x340e5a21e220
[1:1:0713/040533.393231:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[53530:53530:0713/040533.397615:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: ifr2335584, 6, 6, 
[1:1:0713/040533.402375:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/040533.402599:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[1:1:0713/040533.406755:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29c1971029c8, 0x340e59fb4ad0
[1:1:0713/040533.407081:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0713/040533.407515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 490
[1:1:0713/040533.407813:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7f73d83d0070 0x340e5b0f3c60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 384 0x7f73d83d0070 0x340e5a547de0 
[53530:53530:0713/040533.411041:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[1:1:0713/040533.411013:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.560051, 21, 0
[1:1:0713/040533.411235:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040533.413665:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 363, 7f73dad15881
[1:1:0713/040533.436025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"336 0x7f73d83d0070 0x340e5a2453e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040533.436352:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"336 0x7f73d83d0070 0x340e5a2453e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040533.436743:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040533.437311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){try{j.onclick=function(p){var q=this,p=p||event;mediav[h]();mediav.ad.lisenClick(p,q,d,c,m)}}catc
[1:1:0713/040533.437515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[53530:53530:0713/040533.469289:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[53530:53530:0713/040533.472069:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[53530:53541:0713/040533.484869:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[53530:53530:0713/040533.484904:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://show.g.mediav.com/
[53530:53541:0713/040533.485011:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[53530:53530:0713/040533.485036:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://show.g.mediav.com/, http://show.g.mediav.com/s?ver=1.2.8&enifr=1&showid=sB1ZYl&type=1&of=2&uid=15630159290517926177300249344706&isifr=0&title=%E3%80%90%E7%BA%B8%E4%B8%9A%E3%80%91%E4%BC%81%E4%B8%9A%E5%90%8D%E5%BD%95_%E4%BC%81%E4%B8%9A%E9%BB%84%E9%A1%B5_%E4%BC%81%E4%B8%9A%E5%A4%A7%E5%85%A8-%E4%B8%AD&refurl=, 6
[53530:53530:0713/040533.485176:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_http://show.g.mediav.com/, HTTP/1.1 200 OK Server: nginx Date: Sat, 13 Jul 2019 11:05:33 GMT Content-Type: image/gif Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Pragma: no-cache P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Cache-Control: no-cache, must-revalidate Content-Encoding: gzip  ,53628, 5
[1:7:0713/040533.489928:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/040533.489926:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f73da2f82e0 0x340e5a6307e0 , "http://china.99114.com/106/"
[1:1:0713/040533.491155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (function(){ var json={"ads":[{"clktk":["http://xdssp.mediav.com/s?type=13&r=20&an=__ACT_NUM__&uai=F
[1:1:0713/040533.491609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040533.496462:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4990
[1:1:0713/040533.496675:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040533.497069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 500
[1:1:0713/040533.497297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 500 0x7f73d83d0070 0x340e5a298160 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 390 0x7f73da2f82e0 0x340e5a6307e0 
[1:1:0713/040533.524466:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 392, 7f73dad15881
[1:1:0713/040533.546293:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"344 0x7f73d83d0070 0x340e5a407360 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040533.546851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"344 0x7f73d83d0070 0x340e5a407360 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040533.547331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040533.547882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0713/040533.548123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040533.548888:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040533.549112:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040533.549476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 503
[1:1:0713/040533.549702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 503 0x7f73d83d0070 0x340e5a630de0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 392 0x7f73d83d0070 0x340e5a246060 
[1:1:0713/040533.580291:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040535.394440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , document.readyState
[1:1:0713/040535.394773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[53530:53530:0713/040535.464159:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://show.g.mediav.com/, http://show.g.mediav.com/, 5
[53530:53530:0713/040535.464270:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://show.g.mediav.com/, http://show.g.mediav.com
[1:1:0713/040536.293469:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040536.293747:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040536.316400:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0226061, 98, 1
[1:1:0713/040536.316725:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/040536.454168:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_http://show.g.mediav.com/
[1:1:0713/040536.466359:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 500, 7f73dad15881
[1:1:0713/040536.496714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"390 0x7f73da2f82e0 0x340e5a6307e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040536.497072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"390 0x7f73da2f82e0 0x340e5a6307e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040536.497458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040536.498044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var i;try{i=n(t._value)}catch(o){retur
[1:1:0713/040536.498287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040536.697106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 490, 7f73dad15881
[1:1:0713/040536.706443:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"384 0x7f73d83d0070 0x340e5a547de0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040536.706835:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"384 0x7f73d83d0070 0x340e5a547de0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040536.707241:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040536.707839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){try{j.onclick=function(p){var q=this,p=p||event;mediav[h]();mediav.ad.lisenClick(p,q,d,c,m)}}catc
[1:1:0713/040536.708064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040536.710291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 503, 7f73dad15881
[1:1:0713/040536.719236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"392 0x7f73d83d0070 0x340e5a246060 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040536.719575:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"392 0x7f73d83d0070 0x340e5a246060 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040536.719990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040536.720649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0713/040536.720933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040536.721698:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040536.721935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040536.722303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 567
[1:1:0713/040536.722537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7f73d83d0070 0x340e5b420ce0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 503 0x7f73d83d0070 0x340e5a630de0 
[1:1:0713/040536.740695:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040536.741004:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040536.760609:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.019383, 58, 1
[1:1:0713/040536.760898:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/040539.112609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , document.readyState
[1:1:0713/040539.112910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040539.691986:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040539.692282:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0713/040539.693269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7f73d83d0070 0x340e5ac2aa60 , "http://china.99114.com/106/"
[1:1:0713/040539.694323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (function(){document.getElementById('___szfw_logo___').oncontextmenu = function(){return false;}})()
[1:1:0713/040539.694590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040539.706642:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7f73d83d0070 0x340e5ac2aa60 , "http://china.99114.com/106/"
[1:1:0713/040539.719386:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7f73d83d0070 0x340e5ac2aa60 , "http://china.99114.com/106/"
[1:1:0713/040539.733217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7f73d83d0070 0x340e5ac2aa60 , "http://china.99114.com/106/"
[1:1:0713/040539.881733:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7f73d83d0070 0x340e5ac2aa60 , "http://china.99114.com/106/"
[1:1:0713/040539.949244:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0713/040539.949719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 635
[1:1:0713/040539.949957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f73d83d0070 0x340e5b1feae0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 555 0x7f73d83d0070 0x340e5ac2aa60 
[1:1:0713/040540.028818:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29c1971029c8, 0x340e59fb49a0
[1:1:0713/040540.029161:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0713/040540.029551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 637
[1:1:0713/040540.029944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f73d83d0070 0x340e5a732160 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 555 0x7f73d83d0070 0x340e5ac2aa60 
[1:1:0713/040540.060904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[1:1:0713/040540.638247:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[1:1:0713/040540.658645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29c1971029c8, 0x340e59fb49e0
[1:1:0713/040540.658970:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0713/040540.659359:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 650
[1:1:0713/040540.659586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7f73d83d0070 0x340e5a72b2e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 555 0x7f73d83d0070 0x340e5ac2aa60 
[53530:53530:0713/040540.704425:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/040540.706991:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x340e5ab49820
[1:1:0713/040540.708830:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[53530:53530:0713/040540.712700:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0713/040540.736310:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/040540.736542:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[1:1:0713/040540.740600:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[53530:53530:0713/040540.742008:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[1:1:0713/040540.742093:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[53530:53530:0713/040540.806194:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[53530:53530:0713/040540.812186:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[53530:53541:0713/040540.864750:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[53530:53541:0713/040540.864884:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[53530:53530:0713/040540.865098:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://cjhd.mediav.com/
[53530:53530:0713/040540.865184:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://cjhd.mediav.com/, http://cjhd.mediav.com/games/wheel.html?&si=kRmhRE&containerID=QIHOO__INTERACTIVE_PLUGIN1563015928435&t=1563015940702, 7
[53530:53530:0713/040540.865329:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_http://cjhd.mediav.com/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 11:05:40 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Thu, 15 Nov 2018 03:47:49 GMT Vary: Accept-Encoding Cache-Control: max-age=7200 Content-Encoding: gzip X-QHCDN: HIT Expires: Sat, 13 Jul 2019 13:05:40 GMT KCS-Via: HIT from w-fc06.bjyt  ,53628, 5
[1:7:0713/040540.871487:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/040540.997660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558 0x7f73da2f82e0 0x340e5a987ce0 , "http://china.99114.com/106/"
[1:1:0713/040540.998818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (function(){
var json=	[];
window['QIHOO__WEB__SO__BANNER_SLIDER15630159331282O48T0'](json);
})();
[1:1:0713/040540.999164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040541.134092:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://china.99114.com/106/"
[1:1:0713/040541.134812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , h, (a){return typeof p!="undefined"&&(!a||p.event.triggered!==a.type)?p.event.dispatch.apply(h.elem,arg
[53530:53530:0713/040541.135333:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://show.g.mediav.com/, http://show.g.mediav.com/, 6
[1:1:0713/040541.135057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[53530:53530:0713/040541.135426:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://show.g.mediav.com/, http://show.g.mediav.com
[1:1:0713/040541.545492:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/040541.545747:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040541.560779:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 567, 7f73dad15881
[1:1:0713/040541.593534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"503 0x7f73d83d0070 0x340e5a630de0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040541.593896:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"503 0x7f73d83d0070 0x340e5a630de0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040541.594335:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040541.594897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0713/040541.595145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040541.595927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040541.596136:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040541.596500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 708
[1:1:0713/040541.596729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7f73d83d0070 0x340e5ac566e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 567 0x7f73d83d0070 0x340e5b420ce0 
[1:1:0713/040541.758229:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581, "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040541.759668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://trusted.shuidi.cn/, 24fc3a1d2e08, , , function got_url(url) {
    var script = document.createElement('script');
    script.type = 'text/j
[1:1:0713/040541.759907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0", "trusted.shuidi.cn", 4, 1, http://china.99114.com, china.99114.com, 3
[1:1:0713/040542.017129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 458, 7f73dad15881
[1:1:0713/040542.037854:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"384 0x7f73d83d0070 0x340e5a547de0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040542.038058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"384 0x7f73d83d0070 0x340e5a547de0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040542.038541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040542.039100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){f(),n&&n(new Error("Timeout"))}
[1:1:0713/040542.039296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040542.076532:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040542.076833:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 1000
[1:1:0713/040542.077297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 727
[1:1:0713/040542.077556:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f73d83d0070 0x340e5b437560 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 458 0x7f73d83d0070 0x340e5a21f260 
[1:1:0713/040542.452445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , document.readyState
[1:1:0713/040542.452625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/040544.412927:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_http://cjhd.mediav.com/
[1:1:0713/040544.526004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 635, 7f73dad158db
[1:1:0713/040544.565352:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"555 0x7f73d83d0070 0x340e5ac2aa60 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040544.565756:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"555 0x7f73d83d0070 0x340e5ac2aa60 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040544.566310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 842
[1:1:0713/040544.566561:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7f73d83d0070 0x340e5b2239e0 , 5:3_http://china.99114.com/, 0, , 635 0x7f73d83d0070 0x340e5b1feae0 
[1:1:0713/040544.566931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040544.567598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){s.data&&(o(s.data),window.clearInterval(t))}
[1:1:0713/040544.567867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040544.752595:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 362, 7f73dad15881
[1:1:0713/040544.783138:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"336 0x7f73d83d0070 0x340e5a2453e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040544.783334:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"336 0x7f73d83d0070 0x340e5a2453e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040544.783560:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040544.783938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , f, (){var q=null,o=null,l=curDateStamp=(new Date()).valueOf(),n=60000;if(!e()){var m=b.pub;o=mediav.G(g
[1:1:0713/040544.784071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040544.792386:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 800
[1:1:0713/040544.792809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 850
[1:1:0713/040544.793018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f73d83d0070 0x340e5a715f60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 362 0x7f73d83d0070 0x340e5a5f7c60 
[1:1:0713/040545.379237:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 708, 7f73dad15881
[1:1:0713/040545.391999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24fc3a0a2860","ptid":"567 0x7f73d83d0070 0x340e5b420ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040545.392473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"567 0x7f73d83d0070 0x340e5b420ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0713/040545.392950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0713/040545.393515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0713/040545.393698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040545.394349:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c1971029c8, 0x340e59fb4950
[1:1:0713/040545.394508:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0713/040545.394834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 872
[1:1:0713/040545.395074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 872 0x7f73d83d0070 0x340e5a199660 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 708 0x7f73d83d0070 0x340e5ac566e0 
[1:1:0713/040545.688655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 721 0x7f73eea5a080 0x340e5b29f600 1 0 0x340e5b29f618 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040545.716809:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040545.717336:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/040545.728796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://trusted.shuidi.cn/, 24fc3a1d2e08, , , /*! jQuery v1.7.1 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow
[1:1:0713/040545.729130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0", "trusted.shuidi.cn", 4, 1, http://china.99114.com, china.99114.com, 3
[1:1:0713/040545.940357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 721 0x7f73eea5a080 0x340e5b29f600 1 0 0x340e5b29f618 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040545.958392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 721 0x7f73eea5a080 0x340e5b29f600 1 0 0x340e5b29f618 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040546.105743:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 721 0x7f73eea5a080 0x340e5b29f600 1 0 0x340e5b29f618 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040546.109722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 721 0x7f73eea5a080 0x340e5b29f600 1 0 0x340e5b29f618 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040546.124838:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0713/040546.404640:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738 0x7f73da2f82e0 0x340e5b2301e0 , "http://china.99114.com/106/"
[1:1:0713/040546.408390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , get360mvDormerAd({"\u5bb6\u7535":[{"curl":"http:\/\/redirect.simba.taobao.com\/rd?c=un&w=unionsem&k=
[1:1:0713/040546.408553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0713/040546.461077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 739 0x7f73da2f82e0 0x340e5a88f560 , "http://china.99114.com/106/"
[1:1:0713/040546.462383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 24fc3a0a2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0713/040546.462575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
