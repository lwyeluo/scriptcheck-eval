[0712/155830.509296:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155830.509668:INFO:switcher_clone.cc(787)] backtrace rip is 7fc72af0c891
[0712/155831.637430:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155831.637858:INFO:switcher_clone.cc(787)] backtrace rip is 7f072cb3d891
[1:1:0712/155831.654548:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/155831.655090:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/155831.664461:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/155833.157409:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155833.157735:INFO:switcher_clone.cc(787)] backtrace rip is 7f61ee90b891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[36063:36063:0712/155833.337055:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[36094:36094:0712/155833.384229:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=36094
[36104:36104:0712/155833.384627:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=36104

DevTools listening on ws://127.0.0.1:9222/devtools/browser/63f5a935-9db8-4d3b-97f5-62fce4b9fc85
[36063:36063:0712/155833.953039:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[36063:36092:0712/155833.953841:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/155833.954068:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155833.954288:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155833.954884:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155833.955035:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/155833.958311:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x24ad4c88, 1
[1:1:0712/155833.958851:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xafc2c58, 0
[1:1:0712/155833.959186:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1b558345, 3
[1:1:0712/155833.959504:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3547bda4, 2
[1:1:0712/155833.959920:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 582cfffffffc0a ffffff884cffffffad24 ffffffa4ffffffbd4735 45ffffff83551b , 10104, 4
[1:1:0712/155833.961722:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[36063:36092:0712/155833.962110:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGX,�
�L�$��G5E�U�Ӊ	
[36063:36092:0712/155833.962241:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is X,�
�L�$��G5E�UXV�Ӊ	
[36063:36092:0712/155833.962566:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[36063:36092:0712/155833.962633:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 36114, 4, 582cfc0a 884cad24 a4bd4735 4583551b 
[1:1:0712/155833.962442:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f072ad780a0, 3
[1:1:0712/155833.962830:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f072af03080, 2
[1:1:0712/155833.963127:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0714bc6d20, -2
[1:1:0712/155833.982250:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155833.983133:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3547bda4
[1:1:0712/155833.984154:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3547bda4
[1:1:0712/155833.985870:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3547bda4
[1:1:0712/155833.987473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.987690:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.987891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.988094:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.988879:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3547bda4
[1:1:0712/155833.989280:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f072cb3d7ba
[1:1:0712/155833.989435:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f072cb34def, 7f072cb3d77a, 7f072cb3f0cf
[1:1:0712/155833.990973:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3547bda4
[1:1:0712/155833.991141:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3547bda4
[1:1:0712/155833.991407:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3547bda4
[1:1:0712/155833.992082:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.992192:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.992284:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.992374:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3547bda4
[1:1:0712/155833.992859:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3547bda4
[1:1:0712/155833.993017:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f072cb3d7ba
[1:1:0712/155833.993100:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f072cb34def, 7f072cb3d77a, 7f072cb3f0cf
[1:1:0712/155833.996310:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155833.996726:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155833.996867:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc5b439e88, 0x7ffc5b439e08)
[1:1:0712/155834.011601:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155834.017094:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[36063:36063:0712/155834.633752:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[36063:36063:0712/155834.634923:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[36063:36073:0712/155834.645466:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[36063:36063:0712/155834.645586:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[36063:36073:0712/155834.645562:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[36063:36063:0712/155834.645671:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[36063:36063:0712/155834.645773:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,36114, 4
[1:7:0712/155834.648193:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[36063:36085:0712/155834.657983:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/155834.754593:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x37f1bd6ee220
[1:1:0712/155834.754853:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/155835.129140:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[36063:36063:0712/155836.835782:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[36063:36063:0712/155836.835857:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155836.868069:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155836.871577:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155837.833991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32c1ccd41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155837.834301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155837.850814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32c1ccd41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155837.851115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155837.938407:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155838.283672:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155838.284022:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155838.739865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155838.752054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32c1ccd41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155838.752497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155838.810995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155838.833540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32c1ccd41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155838.833900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155838.848251:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[36063:36063:0712/155838.851396:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155838.851933:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37f1bd6ece20
[1:1:0712/155838.852276:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[36063:36063:0712/155838.878337:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[36063:36063:0712/155838.918822:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[36063:36063:0712/155838.918952:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[36063:36063:0712/155838.929410:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/155838.953763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155839.709150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f07167a12e0 0x37f1bd9704e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155839.710654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32c1ccd41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/155839.710966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155839.712632:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[36063:36063:0712/155839.799220:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155839.803973:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x37f1bd6ed820
[1:1:0712/155839.804455:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[36063:36063:0712/155839.805890:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/155839.817582:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/155839.817831:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[36063:36063:0712/155839.824715:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[36063:36063:0712/155839.838594:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[36063:36063:0712/155839.841213:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[36063:36073:0712/155839.847615:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[36063:36073:0712/155839.847705:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[36063:36063:0712/155839.847887:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[36063:36063:0712/155839.847968:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[36063:36063:0712/155839.848111:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,36114, 4
[1:7:0712/155839.853515:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155840.580815:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[36063:36063:0712/155840.627440:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[36063:36092:0712/155840.627843:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/155840.628073:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155840.628391:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155840.628916:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155840.629157:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/155840.632467:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1af16acd, 1
[1:1:0712/155840.632881:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xe1886e8, 0
[1:1:0712/155840.633047:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x27983562, 3
[1:1:0712/155840.633210:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xc34770e, 2
[1:1:0712/155840.633433:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe8ffffff86180e ffffffcd6afffffff11a 0e77340c 6235ffffff9827 , 10104, 5
[1:1:0712/155840.634496:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[36063:36092:0712/155840.634781:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��j�w4b5�'�։	
[36063:36092:0712/155840.634857:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��j�w4b5�'��։	
[36063:36092:0712/155840.635106:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 36159, 5, e886180e cd6af11a 0e77340c 62359827 
[1:1:0712/155840.635443:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f072ad780a0, 3
[1:1:0712/155840.635679:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f072af03080, 2
[1:1:0712/155840.635867:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0714bc6d20, -2
[1:1:0712/155840.660473:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155840.660989:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c34770e
[1:1:0712/155840.661370:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c34770e
[1:1:0712/155840.662147:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c34770e
[1:1:0712/155840.663891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.664117:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.664335:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.664582:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.665391:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c34770e
[1:1:0712/155840.665767:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f072cb3d7ba
[1:1:0712/155840.665935:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f072cb34def, 7f072cb3d77a, 7f072cb3f0cf
[1:1:0712/155840.672896:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c34770e
[1:1:0712/155840.673330:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c34770e
[1:1:0712/155840.674234:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c34770e
[1:1:0712/155840.676775:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.677038:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.677264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.677500:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c34770e
[1:1:0712/155840.678765:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c34770e
[1:1:0712/155840.679126:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f072cb3d7ba
[1:1:0712/155840.679259:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f072cb34def, 7f072cb3d77a, 7f072cb3f0cf
[1:1:0712/155840.687090:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155840.687647:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155840.687805:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc5b439e88, 0x7ffc5b439e08)
[1:1:0712/155840.701317:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155840.706499:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/155840.867083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 490 0x7f07167a12e0 0x37f1bdad01e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155840.868139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32c1ccd41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/155840.868416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155840.869247:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155840.974342:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37f1bd6a9220
[1:1:0712/155840.974613:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/155841.013350:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[36063:36063:0712/155841.018694:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[36063:36063:0712/155841.018792:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[36063:36063:0712/155841.325014:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[36063:36063:0712/155841.330464:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[36063:36073:0712/155841.348129:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[36063:36073:0712/155841.348220:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[36063:36063:0712/155841.358676:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.opensns.cn/
[36063:36063:0712/155841.358804:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.opensns.cn/, http://www.opensns.cn/, 1
[36063:36063:0712/155841.358949:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.opensns.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 22:58:41 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Thu, 19 Nov 1981 08:52:00 GMT Pragma: no-cache Cache-control: private X-Powered-By: ThinkPHP Content-Encoding: gzip  ,36159, 5
[1:7:0712/155841.364459:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155841.375630:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.opensns.cn/
[1:1:0712/155841.490883:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[36063:36063:0712/155841.536214:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.opensns.cn/, http://www.opensns.cn/, 1
[36063:36063:0712/155841.536343:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.opensns.cn/, http://www.opensns.cn
[1:1:0712/155841.582088:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155841.690775:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155841.818433:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155841.818706:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.opensns.cn/"
[1:1:0712/155842.284162:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155842.284428:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155842.326751:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7f0714879070 0x37f1bd8932e0 , "http://www.opensns.cn/"
[1:1:0712/155842.329145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , 
        (function(){
            var bp = document.createElement('script');
            var curProt
[1:1:0712/155842.329368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155842.331244:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155842.377477:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/155842.907863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f0714be1bd0 0x37f1bd7da8d8 , "http://www.opensns.cn/"
[1:1:0712/155842.915407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , /*! jQuery v2.1.4 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/155842.915652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155843.114064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f0714be1bd0 0x37f1bd7da8d8 , "http://www.opensns.cn/"
[1:1:0712/155843.333838:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f0714be1bd0 0x37f1bd7da8d8 , "http://www.opensns.cn/"
[1:1:0712/155843.398515:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155843.398971:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155843.402612:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155843.403014:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155843.403411:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155843.427177:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f0714be1bd0 0x37f1bd7da8d8 , "http://www.opensns.cn/"
[1:1:0712/155843.565407:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f0714be1bd0 0x37f1bd7da8d8 , "http://www.opensns.cn/"
[1:1:0712/155843.580543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f0714be1bd0 0x37f1bd7da8d8 , "http://www.opensns.cn/"
[1:1:0712/155843.615567:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.505201, 0, 0
[1:1:0712/155843.615849:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155843.933150:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155843.933416:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.opensns.cn/"
[1:1:0712/155843.936754:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0714879070 0x37f1bd8fb560 , "http://www.opensns.cn/"
[1:1:0712/155843.938663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , /**
 * Created by ddj on 2017/8/22.
 */
$(function ($) {
    /**
     * 初始化轮播图比�
[1:1:0712/155843.938898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155843.994046:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0714879070 0x37f1bd8fb560 , "http://www.opensns.cn/"
[1:1:0712/155844.126654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0714879070 0x37f1bd8fb560 , "http://www.opensns.cn/"
[1:1:0712/155844.179488:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/155844.249828:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x37f1bd6a7420
[1:1:0712/155844.250580:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/155844.365884:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.432375, 881, 1
[1:1:0712/155844.366150:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155845.498218:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155845.498516:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.opensns.cn/"
[1:1:0712/155845.500408:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f0714879070 0x37f1bd8fbf60 , "http://www.opensns.cn/"
[1:1:0712/155845.501334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , function getCookie(d) {
    var b = document.cookie.split("; ");
    for (var c = 0; c < b.length;
[1:1:0712/155845.501457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155845.520361:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f0714879070 0x37f1bd8fbf60 , "http://www.opensns.cn/"
[1:1:0712/155846.679801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 366 0x7f07167a12e0 0x37f1bd7d2c60 , "http://www.opensns.cn/"
[1:1:0712/155846.680559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/155846.680678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155846.996862:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f0714be1bd0 0x37f1bd72d1d8 , "http://www.opensns.cn/"
[1:1:0712/155847.001914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , /*!
 * ZUI - v1.4.0 - 2016-01-26
 * http://zui.sexy
 * GitHub: https://github.com/easysoft/zui.gi
[1:1:0712/155847.002109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[36063:36063:0712/155915.920236:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[36063:36063:0712/155915.927675:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[36063:36063:0712/155915.952161:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://www.opensns.cn/, http://www.opensns.cn/, 4
[36063:36063:0712/155915.952344:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://www.opensns.cn/, http://www.opensns.cn
[36063:36063:0712/155916.126130:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/155916.188928:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[36063:36063:0712/155916.245561:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/155916.340275:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155916.487687:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155916.488338:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155916.774655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f0714be1bd0 0x37f1bd72d1d8 , "http://www.opensns.cn/"
[1:1:0712/155916.851253:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f0714be1bd0 0x37f1bd72d1d8 , "http://www.opensns.cn/"
[1:1:0712/155918.070112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.opensns.cn/"
[1:1:0712/155918.072136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , window.(anonymous function).onload.window.(anonymous function).onerror.window.(anonymous function).onabort, () {
        try {
            this.onload = this.onerror = this.onabort = null
        } catch (
[1:1:0712/155918.072387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155919.084144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/155919.084468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155921.441750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155921.442072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155922.039015:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 606 0x7f07167a12e0 0x37f1bd6e23e0 , "http://www.opensns.cn/"
[1:1:0712/155922.050784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , /**
 * [WARNING]
 *   !!! 请勿将本文件保存到您的服务器上自行托管
 *   !!! 否则�
[1:1:0712/155922.051030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[36063:36063:0712/155922.214049:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155922.216493:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x37f1be1c8e20
[1:1:0712/155922.216746:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[36063:36063:0712/155922.223172:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: 215077, 5, 5, 
[1:1:0712/155922.240114:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/155922.240374:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.opensns.cn
[36063:36063:0712/155922.243751:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.opensns.cn/
[36063:36063:0712/155922.264416:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0712/155922.267635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x348b037229c8, 0x37f1bd534990
[1:1:0712/155922.267795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 500
[36063:36063:0712/155922.267927:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/155922.267965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 683
[1:1:0712/155922.268082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7f0714879070 0x37f1bde1b7e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 606 0x7f07167a12e0 0x37f1bd6e23e0 
[36063:36073:0712/155922.289836:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[36063:36063:0712/155922.289872:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://360fenxi.mediav.com/
[36063:36063:0712/155922.289925:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://360fenxi.mediav.com/, http://360fenxi.mediav.com/mv.html, 5
[36063:36073:0712/155922.289929:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[36063:36063:0712/155922.289980:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://360fenxi.mediav.com/, HTTP/1.1 200 OK Server: openresty/1.9.15.1 Date: Fri, 12 Jul 2019 09:05:03 GMT Content-Type: text/html Last-Modified: Mon, 21 Jan 2019 10:22:25 GMT ETag: W/"5c459d61-603" P3P: CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT" Content-Encoding: gzip  ,36159, 5
[1:7:0712/155922.293044:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155922.722531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 622 0x7f0714be1bd0 0x37f1bd8e5fd8 , "http://www.opensns.cn/"
[1:1:0712/155922.725241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , var LR_JCML='c2408e0604deb24408e256f0da5fe802a2d143ff823eb4b3c160792190f281d66896b1b39537d4847b28cb4
[1:1:0712/155922.725392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
		remove user.11_14b4ac9 -> 0
		remove user.12_d3c9159d -> 0
		remove user.13_6ff40604 -> 0
[1:1:0712/155923.776288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 50
[1:1:0712/155923.776748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 702
[1:1:0712/155923.776982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f0714879070 0x37f1be0705e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155923.830572:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 200
[1:1:0712/155923.830888:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 707
[1:1:0712/155923.831016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f0714879070 0x37f1bd8f29e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155923.840268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 200
[1:1:0712/155923.840799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 708
[1:1:0712/155923.841050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7f0714879070 0x37f1bde74b60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155923.848023:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 200
[1:1:0712/155923.848407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 709
[1:1:0712/155923.848602:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f0714879070 0x37f1bddec260 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155923.856732:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 200
[1:1:0712/155923.857113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 710
[1:1:0712/155923.857308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 710 0x7f0714879070 0x37f1bd6e2ae0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155923.934613:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 100
[1:1:0712/155923.935017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 723
[1:1:0712/155923.935385:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7f0714879070 0x37f1bd6e2d60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155923.957205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 200
[1:1:0712/155923.957590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 725
[1:1:0712/155923.957808:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f0714879070 0x37f1bd3a99e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155923.958396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 200
[1:1:0712/155923.958708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 726
[1:1:0712/155923.958896:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7f0714879070 0x37f1bd8fe160 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 622 0x7f0714be1bd0 0x37f1bd8e5fd8 
[1:1:0712/155924.003839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155924.004148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155925.280156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.opensns.cn/"
[1:1:0712/155925.280822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , q.handle, (b){return"undefined"!=typeof r&&r.event.triggered!==b.type?r.event.dispatch.apply(a,arguments):void
[1:1:0712/155925.281027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155925.591981:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.opensns.cn/"
[1:1:0712/155925.593129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x348b037229c8, 0x37f1bd5349f0
[1:1:0712/155925.593321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 50
[1:1:0712/155925.593649:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 758
[1:1:0712/155925.593843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 758 0x7f0714879070 0x37f1bde060e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 673 0x7f0723b8a960 0x37f1be1764c0 0x37f1be1764d0 
[1:1:0712/155926.175462:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://360fenxi.mediav.com/
[1:1:0712/155927.395329:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 683, 7f07171be881
[1:1:0712/155927.439061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"606 0x7f07167a12e0 0x37f1bd6e23e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.439458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"606 0x7f07167a12e0 0x37f1bd6e23e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.439961:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155927.440597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , v, (){if(!c)return c=!0,u.apply(this,arguments)}
[1:1:0712/155927.440860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.494639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 702, 7f07171be8db
[1:1:0712/155927.529168:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.529472:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.529908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 794
[1:1:0712/155927.530118:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7f0714879070 0x37f1bf631b60 , 5:3_http://www.opensns.cn/, 0, , 702 0x7f0714879070 0x37f1be0705e0 
[1:1:0712/155927.530399:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155927.531210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155927.531391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.684770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155927.685021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.688145:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 707, 7f07171be8db
[1:1:0712/155927.722598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.722936:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.723373:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 803
[1:1:0712/155927.723575:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7f0714879070 0x37f1be763360 , 5:3_http://www.opensns.cn/, 0, , 707 0x7f0714879070 0x37f1bd8f29e0 
[1:1:0712/155927.723889:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155927.724692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155927.724891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.728036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 723, 7f07171be881
[1:1:0712/155927.762665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.762993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.763375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155927.764155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , LR_LS()
[1:1:0712/155927.764337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.765173:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 100
[1:1:0712/155927.765541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 804
[1:1:0712/155927.765732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f0714879070 0x37f1bdda9fe0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 723 0x7f0714879070 0x37f1bd6e2d60 
[1:1:0712/155927.805258:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 708, 7f07171be8db
[1:1:0712/155927.839808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.840140:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.840534:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 805
[1:1:0712/155927.840725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7f0714879070 0x37f1bd6e03e0 , 5:3_http://www.opensns.cn/, 0, , 708 0x7f0714879070 0x37f1bde74b60 
[1:1:0712/155927.841005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155927.841809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155927.841992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.880251:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 709, 7f07171be8db
[1:1:0712/155927.914893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.915202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.915589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 809
[1:1:0712/155927.915780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f0714879070 0x37f1be75fc60 , 5:3_http://www.opensns.cn/, 0, , 709 0x7f0714879070 0x37f1bddec260 
[1:1:0712/155927.916110:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155927.916897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155927.917076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.919292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 710, 7f07171be8db
[1:1:0712/155927.960680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.961118:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155927.961617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 810
[1:1:0712/155927.961888:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 810 0x7f0714879070 0x37f1bdaceee0 , 5:3_http://www.opensns.cn/, 0, , 710 0x7f0714879070 0x37f1bd6e2ae0 
[1:1:0712/155927.962210:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155927.963211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155927.963444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155927.990674:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 725, 7f07171be8db
[1:1:0712/155928.003374:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155928.003657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155928.004013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 811
[1:1:0712/155928.004181:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7f0714879070 0x37f1bf62d9e0 , 5:3_http://www.opensns.cn/, 0, , 725 0x7f0714879070 0x37f1bd3a99e0 
[1:1:0712/155928.004386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155928.004788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155928.004963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155928.021340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 726, 7f07171be8db
[1:1:0712/155928.032884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155928.033084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"622 0x7f0714be1bd0 0x37f1bd8e5fd8 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155928.033331:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 813
[1:1:0712/155928.033450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 813 0x7f0714879070 0x37f1be78b960 , 5:3_http://www.opensns.cn/, 0, , 726 0x7f0714879070 0x37f1bd8fe160 
[1:1:0712/155928.033592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155928.033928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155928.034040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155928.302996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 758, 7f07171be881
[1:1:0712/155928.314724:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"673 0x7f0723b8a960 0x37f1be1764c0 0x37f1be1764d0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155928.314949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"673 0x7f0723b8a960 0x37f1be1764c0 0x37f1be1764d0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155928.315164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155928.315462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , (){n(i.instances,function(t){t.options.responsive&&t.resize(t.render,!0)})}
[1:1:0712/155928.315569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155928.534377:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[36063:36063:0712/155928.538560:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://360fenxi.mediav.com/, http://360fenxi.mediav.com/, 5
[36063:36063:0712/155928.538656:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://360fenxi.mediav.com/, http://360fenxi.mediav.com
[1:1:0712/155928.590537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.opensns.cn/"
[1:1:0712/155928.591224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , onload.i.onerror.i.onabort, (){i.onload=i.onerror=i.onabort=null,i=m[r]=null,n&&n()}
[1:1:0712/155928.591414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155928.666127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 778 0x7f07167a12e0 0x37f1bf615960 , "http://www.opensns.cn/"
[1:1:0712/155928.666943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , 
[1:1:0712/155928.667172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155928.667619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.opensns.cn/"
[1:1:0712/155928.741422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 779 0x7f07167a12e0 0x37f1bf63c9e0 , "http://www.opensns.cn/"
[1:1:0712/155928.742525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , LR_inviteimgJS=1;checkcount=2;LR_sidexists=0;LR_ip="218.241.135.34";var lr_iptemp=LR_getCookie('IP')
[1:1:0712/155928.742731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155928.881740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7f0714879070 0x37f1bf612f60 , "http://www.opensns.cn/"
[1:1:0712/155928.882394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , 
    var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");
    
[1:1:0712/155928.882510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[36063:36063:0712/155928.889716:INFO:CONSOLE(790)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s5.cnzz.com/stat.php?id=5849549&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.opensns.cn/ (790)
[36063:36063:0712/155928.895030:INFO:CONSOLE(790)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s5.cnzz.com/stat.php?id=5849549&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.opensns.cn/ (790)
[1:1:0712/155929.241053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 794, 7f07171be8db
[1:1:0712/155929.258595:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"702 0x7f0714879070 0x37f1be0705e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.258846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"702 0x7f0714879070 0x37f1be0705e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.259141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 848
[1:1:0712/155929.259325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 848 0x7f0714879070 0x37f1bdda5c60 , 5:3_http://www.opensns.cn/, 0, , 794 0x7f0714879070 0x37f1bf631b60 
[1:1:0712/155929.259541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.260059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155929.260233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.323178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155929.323506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.325508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 803, 7f07171be8db
[1:1:0712/155929.337345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"707 0x7f0714879070 0x37f1bd8f29e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.337517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"707 0x7f0714879070 0x37f1bd8f29e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.337753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 851
[1:1:0712/155929.337871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7f0714879070 0x37f1be792de0 , 5:3_http://www.opensns.cn/, 0, , 803 0x7f0714879070 0x37f1be763360 
[1:1:0712/155929.338024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.338371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155929.338489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.351265:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 805, 7f07171be8db
[1:1:0712/155929.373412:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"708 0x7f0714879070 0x37f1bde74b60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.373691:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"708 0x7f0714879070 0x37f1bde74b60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.374071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 852
[1:1:0712/155929.374281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f0714879070 0x37f1be832ee0 , 5:3_http://www.opensns.cn/, 0, , 805 0x7f0714879070 0x37f1bd6e03e0 
[1:1:0712/155929.374537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.375090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155929.375289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.377424:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 804, 7f07171be881
[1:1:0712/155929.414598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"723 0x7f0714879070 0x37f1bd6e2d60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.414917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"723 0x7f0714879070 0x37f1bd6e2d60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.415296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.415888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , LR_LS()
[1:1:0712/155929.416095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.555556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 809, 7f07171be8db
[1:1:0712/155929.570843:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"709 0x7f0714879070 0x37f1bddec260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.571093:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"709 0x7f0714879070 0x37f1bddec260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.571932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 877
[1:1:0712/155929.572101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 877 0x7f0714879070 0x37f1be834960 , 5:3_http://www.opensns.cn/, 0, , 809 0x7f0714879070 0x37f1be75fc60 
[1:1:0712/155929.572339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.572816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155929.572968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.592068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 810, 7f07171be8db
[1:1:0712/155929.606434:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"710 0x7f0714879070 0x37f1bd6e2ae0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.606630:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"710 0x7f0714879070 0x37f1bd6e2ae0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.606872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 878
[1:1:0712/155929.606990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 878 0x7f0714879070 0x37f1bd2cdfe0 , 5:3_http://www.opensns.cn/, 0, , 810 0x7f0714879070 0x37f1bdaceee0 
[1:1:0712/155929.607259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.607890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155929.608073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.610180:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 811, 7f07171be8db
[1:1:0712/155929.634476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"725 0x7f0714879070 0x37f1bd3a99e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.634660:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"725 0x7f0714879070 0x37f1bd3a99e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.634895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 880
[1:1:0712/155929.635015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7f0714879070 0x37f1be782de0 , 5:3_http://www.opensns.cn/, 0, , 811 0x7f0714879070 0x37f1bf62d9e0 
[1:1:0712/155929.635166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.635530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155929.635663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.655579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 813, 7f07171be8db
[1:1:0712/155929.685719:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"726 0x7f0714879070 0x37f1bd8fe160 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.685920:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"726 0x7f0714879070 0x37f1bd8fe160 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155929.686171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 884
[1:1:0712/155929.686326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f0714879070 0x37f1be8342e0 , 5:3_http://www.opensns.cn/, 0, , 813 0x7f0714879070 0x37f1be78b960 
[1:1:0712/155929.686486:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155929.686783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155929.686890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155929.910512:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155930.598089:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 844, "http://www.opensns.cn/"
[1:1:0712/155930.605158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , (function(){function p(){this.c="5849549";this.ca="z";this.Y="pic";this.V="";this.X="";this.D="15629
[1:1:0712/155930.605381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[36063:36063:0712/155930.675236:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=5849549&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s5.cnzz.com/stat.php?id=5849549&show=pic (17)
[36063:36063:0712/155930.684238:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=5849549&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s5.cnzz.com/stat.php?id=5849549&show=pic (17)
[1:1:0712/155930.739758:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.opensns.cn/"
[1:1:0712/155930.740462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , onload.i.onerror.i.onabort, (){i.onload=i.onerror=i.onabort=null,i=m[r]=null,n&&n()}
[1:1:0712/155930.740676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155930.755582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 848, 7f07171be8db
[1:1:0712/155930.769129:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"794 0x7f0714879070 0x37f1bf631b60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155930.769297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"794 0x7f0714879070 0x37f1bf631b60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155930.769582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 923
[1:1:0712/155930.769727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 923 0x7f0714879070 0x37f1be7958e0 , 5:3_http://www.opensns.cn/, 0, , 848 0x7f0714879070 0x37f1bdda5c60 
[1:1:0712/155930.769951:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155930.770360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155930.770476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155930.784451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155930.784703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155931.422499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 851, 7f07171be8db
[1:1:0712/155931.435471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"803 0x7f0714879070 0x37f1be763360 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.435654:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"803 0x7f0714879070 0x37f1be763360 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.435907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 928
[1:1:0712/155931.436026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7f0714879070 0x37f1be86e6e0 , 5:3_http://www.opensns.cn/, 0, , 851 0x7f0714879070 0x37f1be792de0 
[1:1:0712/155931.436178:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155931.436517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155931.436636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155931.437433:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 852, 7f07171be8db
[1:1:0712/155931.449987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"805 0x7f0714879070 0x37f1bd6e03e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.450131:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"805 0x7f0714879070 0x37f1bd6e03e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.450357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 929
[1:1:0712/155931.450479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f0714879070 0x37f1be886060 , 5:3_http://www.opensns.cn/, 0, , 852 0x7f0714879070 0x37f1be832ee0 
[1:1:0712/155931.450608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155931.450932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155931.451043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155931.592050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 877, 7f07171be8db
[1:1:0712/155931.635427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"809 0x7f0714879070 0x37f1be75fc60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.635720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"809 0x7f0714879070 0x37f1be75fc60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.636154:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 934
[1:1:0712/155931.636352:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 934 0x7f0714879070 0x37f1be874f60 , 5:3_http://www.opensns.cn/, 0, , 877 0x7f0714879070 0x37f1be834960 
[1:1:0712/155931.636608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155931.637193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155931.637385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155931.759418:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 878, 7f07171be8db
[1:1:0712/155931.799149:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"810 0x7f0714879070 0x37f1bdaceee0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.799427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"810 0x7f0714879070 0x37f1bdaceee0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.799808:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 940
[1:1:0712/155931.800076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 940 0x7f0714879070 0x37f1be832a60 , 5:3_http://www.opensns.cn/, 0, , 878 0x7f0714879070 0x37f1bd2cdfe0 
[1:1:0712/155931.800365:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155931.800935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155931.801119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155931.803602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 880, 7f07171be8db
[1:1:0712/155931.841557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"811 0x7f0714879070 0x37f1bf62d9e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.841824:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"811 0x7f0714879070 0x37f1bf62d9e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.842225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 941
[1:1:0712/155931.842412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 941 0x7f0714879070 0x37f1bf619860 , 5:3_http://www.opensns.cn/, 0, , 880 0x7f0714879070 0x37f1be782de0 
[1:1:0712/155931.842682:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155931.843192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155931.843365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155931.844998:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 884, 7f07171be8db
[1:1:0712/155931.863444:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"813 0x7f0714879070 0x37f1be78b960 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.863642:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"813 0x7f0714879070 0x37f1be78b960 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155931.863868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 942
[1:1:0712/155931.864032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 942 0x7f0714879070 0x37f1bd8f7ce0 , 5:3_http://www.opensns.cn/, 0, , 884 0x7f0714879070 0x37f1be8342e0 
[1:1:0712/155931.864177:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155931.864472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155931.864578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155931.878129:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155931.878257:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://360fenxi.mediav.com/mv.html"
[1:1:0712/155931.879797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f0714879070 0x37f1be871fe0 , "http://360fenxi.mediav.com/mv.html"
[1:1:0712/155931.891299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://360fenxi.mediav.com/, 39cfc3c5a280, , , var mid=getMid();if(""!==mid&&sendMsg("mid|"+mid),"0"!==window.name){var data=getInfo();data.v?sendM
[1:1:0712/155931.891466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://360fenxi.mediav.com/mv.html", "360fenxi.mediav.com", 5, 1, http://www.opensns.cn, www.opensns.cn, 3
[1:1:0712/155932.995217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921, "http://www.opensns.cn/"
[1:1:0712/155932.998353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/155932.998556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.023862:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921, "http://www.opensns.cn/"
[1:1:0712/155933.052210:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.opensns.cn/"
[1:1:0712/155933.068603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.opensns.cn/"
[1:1:0712/155933.074676:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.074862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.075191:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 993
[1:1:0712/155933.075410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f0714879070 0x37f1be76b1e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.076195:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.076445:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.076751:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 994
[1:1:0712/155933.076935:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7f0714879070 0x37f1be83aa60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.077626:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.077788:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.078088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 995
[1:1:0712/155933.078302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7f0714879070 0x37f1be8fdee0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.079005:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.079162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.079481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 996
[1:1:0712/155933.079672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 996 0x7f0714879070 0x37f1be837760 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.080370:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.080534:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.080833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 997
[1:1:0712/155933.081022:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 997 0x7f0714879070 0x37f1be86eb60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.081771:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.081934:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.082235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 998
[1:1:0712/155933.082446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 998 0x7f0714879070 0x37f1be8e74e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.083155:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.083340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.083651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 999
[1:1:0712/155933.083836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 999 0x7f0714879070 0x37f1be8327e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.084553:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.084717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.085182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1000
[1:1:0712/155933.085407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7f0714879070 0x37f1be8d15e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.086148:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.086333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.086662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1001
[1:1:0712/155933.086857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7f0714879070 0x37f1be834460 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.087606:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.087777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.088086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1002
[1:1:0712/155933.088303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1002 0x7f0714879070 0x37f1bf6125e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.089099:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.089279:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.089590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1003
[1:1:0712/155933.089778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f0714879070 0x37f1bf648260 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.090539:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd5349e0
[1:1:0712/155933.090700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155933.091019:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1004
[1:1:0712/155933.091220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1004 0x7f0714879070 0x37f1be877260 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 921
[1:1:0712/155933.206912:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 923, 7f07171be8db
[1:1:0712/155933.220795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"848 0x7f0714879070 0x37f1bdda5c60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.220990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"848 0x7f0714879070 0x37f1bdda5c60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.221226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1025
[1:1:0712/155933.221371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1025 0x7f0714879070 0x37f1be7ac960 , 5:3_http://www.opensns.cn/, 0, , 923 0x7f0714879070 0x37f1be7958e0 
[1:1:0712/155933.221569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155933.221912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155933.222027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.236387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155933.236648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.390441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 931 0x7f07167a12e0 0x37f1bda1c1e0 , "http://www.opensns.cn/"
[1:1:0712/155933.391302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , LR_inviteimgJS=1;checkcount=2;LR_sidexists=1;
[1:1:0712/155933.391508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.436267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 928, 7f07171be8db
[1:1:0712/155933.478200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"851 0x7f0714879070 0x37f1be792de0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.478508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"851 0x7f0714879070 0x37f1be792de0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.478925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1030
[1:1:0712/155933.479122:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f0714879070 0x37f1be78bd60 , 5:3_http://www.opensns.cn/, 0, , 928 0x7f0714879070 0x37f1be86e6e0 
[1:1:0712/155933.479483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155933.480039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155933.480214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.572739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 929, 7f07171be8db
[1:1:0712/155933.614828:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"852 0x7f0714879070 0x37f1be832ee0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.615193:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"852 0x7f0714879070 0x37f1be832ee0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.615624:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1031
[1:1:0712/155933.615824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1031 0x7f0714879070 0x37f1be83ab60 , 5:3_http://www.opensns.cn/, 0, , 929 0x7f0714879070 0x37f1be886060 
[1:1:0712/155933.616129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155933.616725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155933.616918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.619321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 934, 7f07171be8db
[1:1:0712/155933.661544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"877 0x7f0714879070 0x37f1be834960 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.661830:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"877 0x7f0714879070 0x37f1be834960 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.662266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1032
[1:1:0712/155933.662485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1032 0x7f0714879070 0x37f1be8e7060 , 5:3_http://www.opensns.cn/, 0, , 934 0x7f0714879070 0x37f1be874f60 
[1:1:0712/155933.662802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155933.663386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155933.663613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.711877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 940, 7f07171be8db
[1:1:0712/155933.754490:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"878 0x7f0714879070 0x37f1bd2cdfe0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.754778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"878 0x7f0714879070 0x37f1bd2cdfe0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155933.755196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1036
[1:1:0712/155933.755395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1036 0x7f0714879070 0x37f1be9587e0 , 5:3_http://www.opensns.cn/, 0, , 940 0x7f0714879070 0x37f1be832a60 
[1:1:0712/155933.755738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155933.756330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155933.756576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.935774:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://www.opensns.cn/"
[1:1:0712/155933.937168:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://www.opensns.cn/, 5:5_http://360fenxi.mediav.com/
[1:1:0712/155933.937348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , i, (t){t=function(t){if(t||(t=m.event),!t)throw new Error("`event` is not an object");t.target||(t.targ
[1:1:0712/155933.937559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155933.983945:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://www.opensns.cn/"
[1:1:0712/155933.989327:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 941, 7f07171be8db
[1:1:0712/155934.034579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"880 0x7f0714879070 0x37f1be782de0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155934.034928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"880 0x7f0714879070 0x37f1be782de0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155934.035427:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1044
[1:1:0712/155934.035702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7f0714879070 0x37f1be96b760 , 5:3_http://www.opensns.cn/, 0, , 941 0x7f0714879070 0x37f1bf619860 
[1:1:0712/155934.036243:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155934.036931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155934.037160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155934.092896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 942, 7f07171be8db
[1:1:0712/155934.143923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"884 0x7f0714879070 0x37f1be8342e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155934.144279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"884 0x7f0714879070 0x37f1be8342e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155934.144809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1046
[1:1:0712/155934.145059:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f0714879070 0x37f1be7fa860 , 5:3_http://www.opensns.cn/, 0, , 942 0x7f0714879070 0x37f1bd8f7ce0 
[1:1:0712/155934.145455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155934.146183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155934.146412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/155935.246701:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 993, 7f07171be881
[1:1:0712/155935.283675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.283959:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.284237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155935.284557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155935.284664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.287815:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155935.288060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155935.288247:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1079
[1:1:0712/155935.288362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7f0714879070 0x37f1bd421f60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 993 0x7f0714879070 0x37f1be76b1e0 
[1:1:0712/155935.339546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 994, 7f07171be881
[1:1:0712/155935.378847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.379245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.379670:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155935.380222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155935.380402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.413278:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155935.413586:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155935.414035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1082
[1:1:0712/155935.414291:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1082 0x7f0714879070 0x37f1be998b60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 994 0x7f0714879070 0x37f1be83aa60 
[1:1:0712/155935.474830:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 995, 7f07171be881
[1:1:0712/155935.525901:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.526140:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.526347:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155935.526650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155935.526771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.677300:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155935.677542:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155935.677872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1088
[1:1:0712/155935.678097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7f0714879070 0x37f1be6178e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 995 0x7f0714879070 0x37f1be8fdee0 
[1:1:0712/155935.680903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 996, 7f07171be881
[1:1:0712/155935.737090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.737488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.737938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155935.738591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155935.738818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.749979:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155935.750300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155935.750708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1093
[1:1:0712/155935.750957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1093 0x7f0714879070 0x37f1bde824e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 996 0x7f0714879070 0x37f1be837760 
[1:1:0712/155935.814245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 997, 7f07171be881
[1:1:0712/155935.847143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.847410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.847692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155935.848132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155935.848302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.851549:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155935.851723:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155935.851967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1097
[1:1:0712/155935.852166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7f0714879070 0x37f1be83a0e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 997 0x7f0714879070 0x37f1be86eb60 
[1:1:0712/155935.875635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.opensns.cn/"
[1:1:0712/155935.876314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/155935.876494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.877683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 998, 7f07171be881
[1:1:0712/155935.899835:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.900078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.900336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155935.900643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155935.900763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.904382:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155935.904513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155935.904697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1099
[1:1:0712/155935.904812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7f0714879070 0x37f1be8fbe60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 998 0x7f0714879070 0x37f1be8e74e0 
[1:1:0712/155935.905377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 999, 7f07171be881
[1:1:0712/155935.947983:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.948345:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155935.948743:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155935.949274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155935.949457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155935.961033:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155935.961310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155935.961658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1100
[1:1:0712/155935.961855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7f0714879070 0x37f1bf3dc160 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 999 0x7f0714879070 0x37f1be8327e0 
[1:1:0712/155936.015670:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1000, 7f07171be881
[1:1:0712/155936.061975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.062305:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.062660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155936.063179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155936.063363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155936.074180:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155936.074405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155936.074730:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1104
[1:1:0712/155936.074925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1104 0x7f0714879070 0x37f1bf628360 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1000 0x7f0714879070 0x37f1be8d15e0 
[1:1:0712/155936.122445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155936.122693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155936.125821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1001, 7f07171be881
[1:1:0712/155936.171182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.171503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.171885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155936.172411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155936.172594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155936.183254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155936.183469:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155936.183797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1108
[1:1:0712/155936.183990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1108 0x7f0714879070 0x37f1be8fbfe0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1001 0x7f0714879070 0x37f1be834460 
[1:1:0712/155936.185779:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1002, 7f07171be881
[1:1:0712/155936.224565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.224954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.225470:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155936.226111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155936.226392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155936.277511:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155936.277744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155936.278074:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1111
[1:1:0712/155936.278308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1111 0x7f0714879070 0x37f1be832a60 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1002 0x7f0714879070 0x37f1bf6125e0 
[1:1:0712/155936.325769:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1003, 7f07171be881
[1:1:0712/155936.373157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.373487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.373871:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155936.374414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155936.374595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155936.385483:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155936.385717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155936.386046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1114
[1:1:0712/155936.386269:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1114 0x7f0714879070 0x37f1bf643ce0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1003 0x7f0714879070 0x37f1bf648260 
[1:1:0712/155936.434897:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1004, 7f07171be881
[1:1:0712/155936.481018:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.481360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"921","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.481741:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155936.482273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155936.482457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155936.577539:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155936.577791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 0
[1:1:0712/155936.578136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1117
[1:1:0712/155936.578349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1117 0x7f0714879070 0x37f1bde19160 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1004 0x7f0714879070 0x37f1be877260 
[1:1:0712/155936.675441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1025, 7f07171be8db
[1:1:0712/155936.730696:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"923 0x7f0714879070 0x37f1be7958e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.731050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"923 0x7f0714879070 0x37f1be7958e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.731585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1120
[1:1:0712/155936.731835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7f0714879070 0x37f1bd6dfa60 , 5:3_http://www.opensns.cn/, 0, , 1025 0x7f0714879070 0x37f1be7ac960 
[1:1:0712/155936.732346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155936.733129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155936.733362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155936.923428:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1030, 7f07171be8db
[1:1:0712/155936.968486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"928 0x7f0714879070 0x37f1be86e6e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.968771:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"928 0x7f0714879070 0x37f1be86e6e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155936.969183:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1123
[1:1:0712/155936.969403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7f0714879070 0x37f1be874f60 , 5:3_http://www.opensns.cn/, 0, , 1030 0x7f0714879070 0x37f1be78bd60 
[1:1:0712/155936.969750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155936.970360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155936.970550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155937.027383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1031, 7f07171be8db
[1:1:0712/155937.072790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"929 0x7f0714879070 0x37f1be886060 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.073070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"929 0x7f0714879070 0x37f1be886060 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.073535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1127
[1:1:0712/155937.073735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1127 0x7f0714879070 0x37f1bd8e7a60 , 5:3_http://www.opensns.cn/, 0, , 1031 0x7f0714879070 0x37f1be83ab60 
[1:1:0712/155937.074045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155937.074666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155937.074848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155937.077120:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1032, 7f07171be8db
[1:1:0712/155937.122271:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"934 0x7f0714879070 0x37f1be874f60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.122601:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"934 0x7f0714879070 0x37f1be874f60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.123022:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1129
[1:1:0712/155937.123222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1129 0x7f0714879070 0x37f1be617c60 , 5:3_http://www.opensns.cn/, 0, , 1032 0x7f0714879070 0x37f1be8e7060 
[1:1:0712/155937.123561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155937.124127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155937.124303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155937.173258:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1036, 7f07171be8db
[1:1:0712/155937.218470:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"940 0x7f0714879070 0x37f1be832a60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.218816:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"940 0x7f0714879070 0x37f1be832a60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.219348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1130
[1:1:0712/155937.219641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1130 0x7f0714879070 0x37f1be79ae60 , 5:3_http://www.opensns.cn/, 0, , 1036 0x7f0714879070 0x37f1be9587e0 
[1:1:0712/155937.220040:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155937.220723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155937.220920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155937.314793:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1044, 7f07171be8db
[1:1:0712/155937.362950:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"941 0x7f0714879070 0x37f1bf619860 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.363246:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"941 0x7f0714879070 0x37f1bf619860 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.363722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1138
[1:1:0712/155937.363936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1138 0x7f0714879070 0x37f1be75f6e0 , 5:3_http://www.opensns.cn/, 0, , 1044 0x7f0714879070 0x37f1be96b760 
[1:1:0712/155937.364294:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155937.364895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155937.365128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155937.465327:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1046, 7f07171be8db
[1:1:0712/155937.500052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"942 0x7f0714879070 0x37f1bd8f7ce0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.500260:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"942 0x7f0714879070 0x37f1bd8f7ce0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155937.500546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1140
[1:1:0712/155937.500678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1140 0x7f0714879070 0x37f1be8797e0 , 5:3_http://www.opensns.cn/, 0, , 1046 0x7f0714879070 0x37f1be7fa860 
[1:1:0712/155937.500867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155937.501175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155937.501290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[36063:36063:0712/155938.099377:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/155938.225126:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1079, 7f07171be881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/155938.280252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"993 0x7f0714879070 0x37f1be76b1e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.280655:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"993 0x7f0714879070 0x37f1be76b1e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.281437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.282623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.283207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.337208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1082, 7f07171be881
[1:1:0712/155938.382877:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"994 0x7f0714879070 0x37f1be83aa60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.383083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"994 0x7f0714879070 0x37f1be83aa60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.383327:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.383643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.383815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.440964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1088, 7f07171be881
[1:1:0712/155938.487559:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"995 0x7f0714879070 0x37f1be8fdee0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.487917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"995 0x7f0714879070 0x37f1be8fdee0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.488288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.488826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.489028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.585308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1093, 7f07171be881
[1:1:0712/155938.632279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"996 0x7f0714879070 0x37f1be837760 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.632593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"996 0x7f0714879070 0x37f1be837760 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.632974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.633494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.633672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.637936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1097, 7f07171be881
[1:1:0712/155938.686128:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"997 0x7f0714879070 0x37f1be86eb60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.686451:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"997 0x7f0714879070 0x37f1be86eb60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.686847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.687351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.687530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.692026:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1099, 7f07171be881
[1:1:0712/155938.738863:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"998 0x7f0714879070 0x37f1be8e74e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.739178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"998 0x7f0714879070 0x37f1be8e74e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.739532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.740056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.740240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.793524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155938.793828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.849010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1100, 7f07171be881
[1:1:0712/155938.897307:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"999 0x7f0714879070 0x37f1be8327e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.897624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"999 0x7f0714879070 0x37f1be8327e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.898001:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.898536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.898716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.903063:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1104, 7f07171be881
[1:1:0712/155938.957171:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"1000 0x7f0714879070 0x37f1be8d15e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.957591:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"1000 0x7f0714879070 0x37f1be8d15e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.958064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.958697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.958946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155938.964439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1108, 7f07171be881
[1:1:0712/155938.990828:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"1001 0x7f0714879070 0x37f1be834460 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.991064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"1001 0x7f0714879070 0x37f1be834460 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155938.991280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155938.991636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155938.991750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.035793:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1111, 7f07171be881
[1:1:0712/155939.067580:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"1002 0x7f0714879070 0x37f1bf6125e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.067904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"1002 0x7f0714879070 0x37f1bf6125e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.068284:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.068768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155939.068958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.072804:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1114, 7f07171be881
[1:1:0712/155939.115305:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"1003 0x7f0714879070 0x37f1bf648260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.115503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"1003 0x7f0714879070 0x37f1bf648260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.115707:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.116073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155939.116278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.117932:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1117, 7f07171be881
[1:1:0712/155939.178774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"1004 0x7f0714879070 0x37f1be877260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.179204:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"1004 0x7f0714879070 0x37f1be877260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.179663:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.180335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/155939.180566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.214139:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.opensns.cn/"
[1:1:0712/155939.214573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , onload.i.onerror.i.onabort, (){i.onload=i.onerror=i.onabort=null,i=m[r]=null,n&&n()}
[1:1:0712/155939.214687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.240606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1120, 7f07171be8db
[1:1:0712/155939.256251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1025 0x7f0714879070 0x37f1be7ac960 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.256447:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1025 0x7f0714879070 0x37f1be7ac960 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.256687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1183
[1:1:0712/155939.256812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1183 0x7f0714879070 0x37f1be7955e0 , 5:3_http://www.opensns.cn/, 0, , 1120 0x7f0714879070 0x37f1bd6dfa60 
[1:1:0712/155939.257038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.257397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155939.257508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.258038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1123, 7f07171be8db
[1:1:0712/155939.274099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1030 0x7f0714879070 0x37f1be78bd60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.274289:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1030 0x7f0714879070 0x37f1be78bd60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.274734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1184
[1:1:0712/155939.274937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7f0714879070 0x37f1bea46460 , 5:3_http://www.opensns.cn/, 0, , 1123 0x7f0714879070 0x37f1be874f60 
[1:1:0712/155939.275280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.275878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155939.276098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.427871:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1127, 7f07171be8db
[1:1:0712/155939.480012:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1031 0x7f0714879070 0x37f1be83ab60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.480422:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1031 0x7f0714879070 0x37f1be83ab60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.480926:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1191
[1:1:0712/155939.481188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1191 0x7f0714879070 0x37f1be874760 , 5:3_http://www.opensns.cn/, 0, , 1127 0x7f0714879070 0x37f1bd8e7a60 
[1:1:0712/155939.481592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.482333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155939.482559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.485940:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1129, 7f07171be8db
[1:1:0712/155939.538990:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1032 0x7f0714879070 0x37f1be8e7060 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.539314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1032 0x7f0714879070 0x37f1be8e7060 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.539712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1194
[1:1:0712/155939.539906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1194 0x7f0714879070 0x37f1be795260 , 5:3_http://www.opensns.cn/, 0, , 1129 0x7f0714879070 0x37f1be617c60 
[1:1:0712/155939.540251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.540821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155939.540998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.543449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1130, 7f07171be8db
[1:1:0712/155939.591501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1036 0x7f0714879070 0x37f1be9587e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.591801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1036 0x7f0714879070 0x37f1be9587e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.592244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1196
[1:1:0712/155939.592455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1196 0x7f0714879070 0x37f1bda6a2e0 , 5:3_http://www.opensns.cn/, 0, , 1130 0x7f0714879070 0x37f1be79ae60 
[1:1:0712/155939.592791:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.593380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155939.593573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.691578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1138, 7f07171be8db
[1:1:0712/155939.706977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1044 0x7f0714879070 0x37f1be96b760 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.707182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1044 0x7f0714879070 0x37f1be96b760 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.707407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1203
[1:1:0712/155939.707518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1203 0x7f0714879070 0x37f1be792be0 , 5:3_http://www.opensns.cn/, 0, , 1138 0x7f0714879070 0x37f1be75f6e0 
[1:1:0712/155939.707710:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.708015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155939.708160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155939.708760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1140, 7f07171be8db
[1:1:0712/155939.739889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1046 0x7f0714879070 0x37f1be7fa860 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.740204:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1046 0x7f0714879070 0x37f1be7fa860 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155939.740610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1204
[1:1:0712/155939.740803:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1204 0x7f0714879070 0x37f1bde016e0 , 5:3_http://www.opensns.cn/, 0, , 1140 0x7f0714879070 0x37f1be8797e0 
[1:1:0712/155939.741138:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155939.741711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155939.741907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155940.529349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , document.readyState
[1:1:0712/155940.529543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155940.597963:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1183, 7f07171be8db
[1:1:0712/155940.661249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1120 0x7f0714879070 0x37f1bd6dfa60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155940.661556:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1120 0x7f0714879070 0x37f1bd6dfa60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155940.661996:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1228
[1:1:0712/155940.662197:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1228 0x7f0714879070 0x37f1bdace260 , 5:3_http://www.opensns.cn/, 0, , 1183 0x7f0714879070 0x37f1be7955e0 
[1:1:0712/155940.662579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155940.663150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155940.663331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.177308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1184, 7f07171be8db
[1:1:0712/155941.227730:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1123 0x7f0714879070 0x37f1be874f60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.228019:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1123 0x7f0714879070 0x37f1be874f60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.228438:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1250
[1:1:0712/155941.228668:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1250 0x7f0714879070 0x37f1be76b2e0 , 5:3_http://www.opensns.cn/, 0, , 1184 0x7f0714879070 0x37f1bea46460 
[1:1:0712/155941.229027:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155941.229602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155941.229784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.326624:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1191, 7f07171be8db
[1:1:0712/155941.343062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1127 0x7f0714879070 0x37f1bd8e7a60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.343249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1127 0x7f0714879070 0x37f1bd8e7a60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.343490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1259
[1:1:0712/155941.343641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1259 0x7f0714879070 0x37f1be7690e0 , 5:3_http://www.opensns.cn/, 0, , 1191 0x7f0714879070 0x37f1be874760 
[1:1:0712/155941.343840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155941.344186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155941.344295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.345156:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1194, 7f07171be8db
[1:1:0712/155941.362431:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1129 0x7f0714879070 0x37f1be617c60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.362643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1129 0x7f0714879070 0x37f1be617c60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.362900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1260
[1:1:0712/155941.363018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1260 0x7f0714879070 0x37f1be998ae0 , 5:3_http://www.opensns.cn/, 0, , 1194 0x7f0714879070 0x37f1be795260 
[1:1:0712/155941.363208:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155941.363551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155941.363682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.364518:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1196, 7f07171be8db
[1:1:0712/155941.381193:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1130 0x7f0714879070 0x37f1be79ae60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.381396:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1130 0x7f0714879070 0x37f1be79ae60 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.381676:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1262
[1:1:0712/155941.381796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1262 0x7f0714879070 0x37f1be754b60 , 5:3_http://www.opensns.cn/, 0, , 1196 0x7f0714879070 0x37f1bda6a2e0 
[1:1:0712/155941.381990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155941.382338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155941.382446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.465649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1203, 7f07171be8db
[1:1:0712/155941.507732:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1138 0x7f0714879070 0x37f1be75f6e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.507928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1138 0x7f0714879070 0x37f1be75f6e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.508169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1273
[1:1:0712/155941.508362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1273 0x7f0714879070 0x37f1be880f60 , 5:3_http://www.opensns.cn/, 0, , 1203 0x7f0714879070 0x37f1be792be0 
[1:1:0712/155941.508552:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155941.508907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155941.509044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.509643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1204, 7f07171be8db
[1:1:0712/155941.527442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1140 0x7f0714879070 0x37f1be8797e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.527659:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1140 0x7f0714879070 0x37f1be8797e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.527920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1277
[1:1:0712/155941.528036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1277 0x7f0714879070 0x37f1be837be0 , 5:3_http://www.opensns.cn/, 0, , 1204 0x7f0714879070 0x37f1bde016e0 
[1:1:0712/155941.528212:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155941.528505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155941.528611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.565364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1226 0x7f07167a12e0 0x37f1be99a5e0 , "http://www.opensns.cn/"
[1:1:0712/155941.568575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , (function(){var h={},mt={},c={id:"68a197002e2e8d9866ca100e66d51217",dm:["opensns.cn","zhiguo-opensns
[1:1:0712/155941.568764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.599294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x348b037229c8, 0x37f1bd534948
[1:1:0712/155941.599667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 100
[1:1:0712/155941.600104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1283
[1:1:0712/155941.600365:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1283 0x7f0714879070 0x37f1be7a80e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1226 0x7f07167a12e0 0x37f1be99a5e0 
[1:1:0712/155941.680251:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 600000
[1:1:0712/155941.680702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1297
[1:1:0712/155941.680913:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1297 0x7f0714879070 0x37f1be7585e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1226 0x7f07167a12e0 0x37f1be99a5e0 
[1:1:0712/155941.681807:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 5000
[1:1:0712/155941.682127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1298
[1:1:0712/155941.682317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1298 0x7f0714879070 0x37f1be95cbe0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1226 0x7f07167a12e0 0x37f1be99a5e0 
[1:1:0712/155941.821376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1228, 7f07171be8db
[1:1:0712/155941.838796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1183 0x7f0714879070 0x37f1be7955e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.838986:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1183 0x7f0714879070 0x37f1be7955e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155941.839241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1315
[1:1:0712/155941.839376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1315 0x7f0714879070 0x37f1be795260 , 5:3_http://www.opensns.cn/, 0, , 1228 0x7f0714879070 0x37f1bdace260 
[1:1:0712/155941.839562:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155941.839932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155941.840046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155941.997906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1250, 7f07171be8db
[1:1:0712/155942.050041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1184 0x7f0714879070 0x37f1bea46460 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.050322:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1184 0x7f0714879070 0x37f1bea46460 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.050812:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1320
[1:1:0712/155942.051005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7f0714879070 0x37f1bd3309e0 , 5:3_http://www.opensns.cn/, 0, , 1250 0x7f0714879070 0x37f1be76b2e0 
[1:1:0712/155942.051340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155942.051929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0712/155942.052128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155942.348394:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1259, 7f07171be8db
[1:1:0712/155942.401155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1191 0x7f0714879070 0x37f1be874760 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.401445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1191 0x7f0714879070 0x37f1be874760 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.401938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1329
[1:1:0712/155942.402138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f0714879070 0x37f1be8724e0 , 5:3_http://www.opensns.cn/, 0, , 1259 0x7f0714879070 0x37f1be7690e0 
[1:1:0712/155942.402500:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155942.403106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon1.autoScroll()
[1:1:0712/155942.403287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155942.405675:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1260, 7f07171be8db
[1:1:0712/155942.458302:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1194 0x7f0714879070 0x37f1be795260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.458591:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1194 0x7f0714879070 0x37f1be795260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.459030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1331
[1:1:0712/155942.459233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1331 0x7f0714879070 0x37f1be761160 , 5:3_http://www.opensns.cn/, 0, , 1260 0x7f0714879070 0x37f1be998ae0 
[1:1:0712/155942.459560:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155942.460167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon2.autoScroll()
[1:1:0712/155942.460350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155942.517756:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1262, 7f07171be8db
[1:1:0712/155942.572515:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1196 0x7f0714879070 0x37f1bda6a2e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.572807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1196 0x7f0714879070 0x37f1bda6a2e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155942.573297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1337
[1:1:0712/155942.573498:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1337 0x7f0714879070 0x37f1be919d60 , 5:3_http://www.opensns.cn/, 0, , 1262 0x7f0714879070 0x37f1be754b60 
[1:1:0712/155942.573810:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155942.574395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon3.autoScroll()
[1:1:0712/155942.574575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155944.189753:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1273, 7f07171be8db
[1:1:0712/155944.223054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1203 0x7f0714879070 0x37f1be792be0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.223265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1203 0x7f0714879070 0x37f1be792be0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.223521:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1384
[1:1:0712/155944.223643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1384 0x7f0714879070 0x37f1bf635a60 , 5:3_http://www.opensns.cn/, 0, , 1273 0x7f0714879070 0x37f1be880f60 
[1:1:0712/155944.223840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155944.224130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if (LR_GetObj('LRfloater2') && (!isMiniFullScreen)) {
        if (LR_GetObj("LRMINIWIN").
[1:1:0712/155944.224236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155944.224830:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1277, 7f07171be8db
[1:1:0712/155944.242517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1204 0x7f0714879070 0x37f1bde016e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.242731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1204 0x7f0714879070 0x37f1bde016e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.242959:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1385
[1:1:0712/155944.243072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1385 0x7f0714879070 0x37f1be9192e0 , 5:3_http://www.opensns.cn/, 0, , 1277 0x7f0714879070 0x37f1be837be0 
[1:1:0712/155944.243256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155944.243565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , () {
    if ((!LR_minifocus) && LR_GetObj('LRfloater2')) {

        if (isMiniFullScreen && LR_Ge
[1:1:0712/155944.243676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155944.244224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1283, 7f07171be881
[1:1:0712/155944.261901:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"39cfc3b82860","ptid":"1226 0x7f07167a12e0 0x37f1be99a5e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.262103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.opensns.cn/","ptid":"1226 0x7f07167a12e0 0x37f1be99a5e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.262311:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155944.262642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/155944.262754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155944.263113:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x348b037229c8, 0x37f1bd534950
[1:1:0712/155944.263234:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.opensns.cn/", 100
[1:1:0712/155944.263442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.opensns.cn/, 1386
[1:1:0712/155944.263560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1386 0x7f0714879070 0x37f1be9698e0 , 5:3_http://www.opensns.cn/, 1, -5:3_http://www.opensns.cn/, 1283 0x7f0714879070 0x37f1be7a80e0 
[1:1:0712/155944.319481:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1315, 7f07171be8db
[1:1:0712/155944.337257:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1228 0x7f0714879070 0x37f1bdace260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.337485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1228 0x7f0714879070 0x37f1bdace260 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0712/155944.337721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1389
[1:1:0712/155944.337834:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1389 0x7f0714879070 0x37f1be7d2560 , 5:3_http://www.opensns.cn/, 0, , 1315 0x7f0714879070 0x37f1be795260 
[1:1:0712/155944.338026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0712/155944.338372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , if(typeof(LR_nextshowmini_s)!='undefined')LR_nextshowmini_s='lr';
[1:1:0712/155944.338573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0712/155944.425370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1320, 7f07171be8db
[1:1:0100/000000.445910:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1250 0x7f0714879070 0x37f1be76b2e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0100/000000.471974:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1250 0x7f0714879070 0x37f1be76b2e0 ","rf":"5:3_http://www.opensns.cn/"}
[1:1:0100/000000.472433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1413
[1:1:0100/000000.472646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7f0714879070 0x37f1bdacf5e0 , 5:3_http://www.opensns.cn/, 0, , 1320 0x7f0714879070 0x37f1bd3309e0 
[1:1:0100/000000.473001:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.opensns.cn/"
[1:1:0100/000000.473686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.opensns.cn/, 39cfc3b82860, , , onlinerIcon0.autoScroll()
[1:1:0100/000000.473868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.opensns.cn/", "www.opensns.cn", 3, 1, , , 0
[1:1:0100/000000.476790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.opensns.cn/, 1329, 7f07171be8db
