[0712/223520.989969:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/223520.990239:INFO:switcher_clone.cc(787)] backtrace rip is 7f8804d1d891
[0712/223522.012336:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/223522.012723:INFO:switcher_clone.cc(787)] backtrace rip is 7fbe3a8af891
[1:1:0712/223522.024417:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/223522.024666:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/223522.029202:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/223523.459438:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/223523.459694:INFO:switcher_clone.cc(787)] backtrace rip is 7f7e60ba3891
[13212:13212:0712/223523.548083:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[13244:13244:0712/223523.614996:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13244
[13255:13255:0712/223523.615394:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13255

DevTools listening on ws://127.0.0.1:9222/devtools/browser/798091f6-2418-47ab-8f16-a46f4cad3d0b
[13212:13212:0712/223524.000058:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[13212:13241:0712/223524.000878:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/223524.001108:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/223524.001318:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/223524.001908:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/223524.002062:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/223524.004895:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xca74e7b, 1
[1:1:0712/223524.005220:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x37d94db0, 0
[1:1:0712/223524.005412:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x5934f7b, 3
[1:1:0712/223524.005621:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x30c4160, 2
[1:1:0712/223524.005840:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb04dffffffd937 7b4effffffa70c 60410c03 7b4fffffff9305 , 10104, 4
[1:1:0712/223524.006877:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[13212:13241:0712/223524.007164:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�M�7{N�`A{O��)�
[13212:13241:0712/223524.007246:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �M�7{N�`A{O�H�)�
[1:1:0712/223524.007149:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbe38aea0a0, 3
[1:1:0712/223524.007386:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbe38c75080, 2
[13212:13241:0712/223524.007530:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/223524.007540:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbe22938d20, -2
[13212:13241:0712/223524.007611:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13265, 4, b04dd937 7b4ea70c 60410c03 7b4f9305 
[1:1:0712/223524.021694:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/223524.022254:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30c4160
[1:1:0712/223524.022898:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30c4160
[1:1:0712/223524.023885:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30c4160
[1:1:0712/223524.024398:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.024500:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.024617:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.024713:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.024928:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30c4160
[1:1:0712/223524.025057:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbe3a8af7ba
[1:1:0712/223524.025129:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbe3a8a6def, 7fbe3a8af77a, 7fbe3a8b10cf
[1:1:0712/223524.026493:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30c4160
[1:1:0712/223524.026708:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30c4160
[1:1:0712/223524.026977:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30c4160
[1:1:0712/223524.028049:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.028249:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.028432:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.028634:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30c4160
[1:1:0712/223524.029890:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30c4160
[1:1:0712/223524.030247:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbe3a8af7ba
[1:1:0712/223524.030378:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbe3a8a6def, 7fbe3a8af77a, 7fbe3a8b10cf
[1:1:0712/223524.038099:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/223524.038541:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/223524.038699:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff611c38d8, 0x7fff611c3858)
[1:1:0712/223524.054877:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/223524.060706:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[13212:13212:0712/223524.709531:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13212:13212:0712/223524.710642:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13212:13224:0712/223524.728937:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[13212:13224:0712/223524.729032:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[13212:13212:0712/223524.729183:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[13212:13212:0712/223524.729262:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[13212:13212:0712/223524.729405:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,13265, 4
[1:7:0712/223524.731086:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[13212:13236:0712/223524.781484:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/223524.791005:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3b578ccb2220
[1:1:0712/223524.791226:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/223525.090601:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/223526.364670:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223526.368795:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[13212:13212:0712/223526.728524:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[13212:13212:0712/223526.728591:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/223527.110331:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/223527.367866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35d1f4781f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/223527.368164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/223527.386220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35d1f4781f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/223527.386518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/223527.491866:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223527.492085:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/223527.931699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/223527.939825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35d1f4781f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/223527.940079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/223527.975558:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/223527.979082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35d1f4781f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/223527.979320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/223527.991401:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[13212:13212:0712/223527.993772:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/223527.994574:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3b578ccb0e20
[1:1:0712/223527.994822:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[13212:13212:0712/223528.001265:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[13212:13212:0712/223528.034873:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[13212:13212:0712/223528.034963:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/223528.049268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/223529.038932:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7fbe245132e0 0x3b578ce817e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/223529.040270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35d1f4781f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/223529.040515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/223529.041982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[13212:13212:0712/223529.114441:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/223529.116871:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3b578ccb1820
[1:1:0712/223529.117082:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[13212:13212:0712/223529.121392:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/223529.136979:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/223529.137190:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[13212:13212:0712/223529.140305:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[13212:13212:0712/223529.151108:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13212:13212:0712/223529.152139:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13212:13224:0712/223529.158318:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[13212:13224:0712/223529.158408:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[13212:13212:0712/223529.158571:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[13212:13212:0712/223529.158649:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[13212:13212:0712/223529.158785:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,13265, 4
[1:7:0712/223529.162120:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/223529.684747:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/223530.298519:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7fbe245132e0 0x3b578ce80360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/223530.299739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35d1f4781f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/223530.300018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/223530.300957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[13212:13212:0712/223530.456031:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[13212:13212:0712/223530.456158:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/223530.468110:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/223530.969341:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[13212:13212:0712/223531.173416:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[13212:13241:0712/223531.173870:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/223531.174099:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/223531.174358:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/223531.174765:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/223531.174915:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/223531.177992:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2b72f40a, 1
[1:1:0712/223531.178384:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1e2bc68c, 0
[1:1:0712/223531.178596:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x30871e4c, 3
[1:1:0712/223531.178783:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2ed41349, 2
[1:1:0712/223531.178970:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8cffffffc62b1e 0afffffff4722b 4913ffffffd42e 4c1effffff8730 , 10104, 5
[1:1:0712/223531.179978:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[13212:13241:0712/223531.180257:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��+
�r+I�.L�0�)�
[13212:13241:0712/223531.180329:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��+
�r+I�.L�0Q�)�
[13212:13241:0712/223531.180597:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13308, 5, 8cc62b1e 0af4722b 4913d42e 4c1e8730 
[1:1:0712/223531.180249:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbe38aea0a0, 3
[1:1:0712/223531.181099:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbe38c75080, 2
[1:1:0712/223531.181319:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbe22938d20, -2
[1:1:0712/223531.207394:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/223531.207813:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ed41349
[1:1:0712/223531.208191:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ed41349
[1:1:0712/223531.208904:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ed41349
[1:1:0712/223531.210411:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.210695:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.210920:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.211142:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.211878:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ed41349
[1:1:0712/223531.212227:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbe3a8af7ba
[1:1:0712/223531.212403:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbe3a8a6def, 7fbe3a8af77a, 7fbe3a8b10cf
[1:1:0712/223531.218503:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ed41349
[1:1:0712/223531.218916:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ed41349
[1:1:0712/223531.219721:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ed41349
[1:1:0712/223531.221987:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.222295:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.222564:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.222827:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ed41349
[1:1:0712/223531.224188:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ed41349
[1:1:0712/223531.224636:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbe3a8af7ba
[1:1:0712/223531.224814:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbe3a8a6def, 7fbe3a8af77a, 7fbe3a8b10cf
[1:1:0712/223531.233627:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/223531.234158:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/223531.234351:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff611c38d8, 0x7fff611c3858)
[1:1:0712/223531.245292:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/223531.249746:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/223531.342921:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223531.343154:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/223531.522920:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3b578cc88220
[1:1:0712/223531.523170:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[13212:13212:0712/223531.791397:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13212:13212:0712/223531.797715:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13212:13224:0712/223531.832468:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[13212:13224:0712/223531.832565:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[13212:13212:0712/223531.833024:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://sale.vmall.com/
[13212:13212:0712/223531.833115:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://sale.vmall.com/, https://sale.vmall.com/pseries.html?cid=78164, 1
[13212:13212:0712/223531.833279:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://sale.vmall.com/, HTTP/1.1 200 OK Server: openresty Date: Sat, 13 Jul 2019 05:35:31 GMT Content-Type: text/html Content-Length: 10845 Connection: keep-alive Last-Modified: Fri, 12 Jul 2019 16:02:07 GMT Vary: Accept-Encoding Content-Encoding: gzip Accept-Ranges: bytes  ,13308, 5
[1:7:0712/223531.839338:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/223531.843565:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/223531.848127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 35d1f48ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/223531.848434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/223531.858207:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/223531.859077:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://sale.vmall.com/
[13212:13212:0712/223532.003301:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://sale.vmall.com/, https://sale.vmall.com/, 1
[13212:13212:0712/223532.003397:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://sale.vmall.com/, https://sale.vmall.com
[1:1:0712/223532.009686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/223532.010423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 35d1f4781f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/223532.010671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/223532.017933:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/223532.109126:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/223532.165385:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/223532.200873:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223532.201117:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223532.263433:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 131 0x7fbe225eb070 0x3b578cd6bde0 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223532.265720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , 
    (function(window) {
        var document = window.document;
        // 下线跳转
        var
[1:1:0712/223532.265949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223532.306125:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.104867, 198, 1
[1:1:0712/223532.306368:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/223532.783923:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223532.784160:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sale.vmall.com/pseries.html?cid=78164"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/223533.237816:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fbe225eb070 0x3b578ce2f460 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223533.238768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , 
    var couponList = window.couponList || {};
        
[1:1:0712/223533.238981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223533.270543:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0300879, 132, 1
[1:1:0712/223533.270858:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/223533.458504:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223533.458739:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223533.459504:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7fbe225eb070 0x3b578ce821e0 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223533.460393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , 
    var couponList = window.couponList || {};
        
[1:1:0712/223533.460610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223533.604781:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.14589, 513, 1
[1:1:0712/223533.605038:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/223533.694345:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223533.694894:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223533.698444:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223533.698962:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223533.699354:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223533.816883:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223533.949793:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223533.950020:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223533.950905:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7fbe225eb070 0x3b578cf708e0 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223533.952214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , 
        var couponList = window.couponList || {};
                    if(typeof couponList['570896'
[1:1:0712/223533.952431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223533.969098:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0188971, 67, 1
[1:1:0712/223533.969338:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/223534.120992:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223534.371940:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223534.372157:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223534.380342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 316 0x7fbe225eb070 0x3b578ce2f160 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223534.419676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , /*! jQuery v1.11.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){
[1:1:0712/223534.419919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223534.443617:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_dbc8aaa1 -> 0
		remove user.11_7e3ba52e -> 0
		remove user.12_c2ec0c28 -> 0
		remove user.13_be4ac3ac -> 0
		remove user.14_e6589c41 -> 0
[1:1:0712/223535.167317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223535.168674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , // 主站配置
var domainYY = '//yy.vmall.com';
var domainRush = '//buy.vmall.com';
var domainEd
[1:1:0712/223535.168789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223535.346861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223535.351014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , window.locale = window.locale || {};

// 公共
locale.common = {
    "currencySymbol": "&#165;"
[1:1:0712/223535.351200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223535.484042:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/223535.770189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7fbe22953bd0 0x3b578d0e9e58 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223535.771579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , /*! utils-pc | Date:2019-05-21 10:39:29 */
!function(t){function e(i){if(o[i])return o[i].exports;va
[1:1:0712/223535.771733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223535.843498:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:7:0712/223535.851248:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 7
[1:7:0712/223536.346154:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 8
[1:7:0712/223536.349699:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 9
[1:7:0712/223536.359265:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 10
[1:1:0712/223536.411695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7fbe22953bd0 0x3b578d0e9e58 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223536.597130:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429, "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223536.598762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , /**
 * PC页面分发
 * 转测{"version":"1.3.4","time":"2018.02.07 14:41:58","author":"Ben"}
 *
[1:1:0712/223536.598971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223537.472228:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fbe22953bd0 0x3b578d393658 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223537.478982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , /* jquery.nicescroll v3.7.6 InuYaksa - MIT - https://nicescroll.areaaperta.com */
!function(e){"func
[1:1:0712/223537.479235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223537.506657:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fbe22953bd0 0x3b578d393658 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223537.604676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fbe22953bd0 0x3b578d393658 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223538.432609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7fbe22953bd0 0x3b578d2db1d8 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223538.434621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , /* swiper 3.4.0 */
!function(){"use strict";function e(e){e.fn.swiper=function(a){var s;return e(th
[1:1:0712/223538.434732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223538.442821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7fbe22953bd0 0x3b578d2db1d8 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223540.979496:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.53803, 0, 0
[1:1:0712/223540.979743:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/223543.081046:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/223543.081311:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223543.087444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 639 0x7fbe225eb070 0x3b578d8eac60 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223543.097774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , /**
 * PC端：数据上报
 * 优化：支持?和#{"version":"1.2.20","time":"2017.12.14 10:04:26
[1:1:0712/223543.098006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223543.196468:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223543.866790:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223543.867530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , n, (){i&&i()}
[1:1:0712/223543.867766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:15:0712/223544.367406:ERROR:render_media_log.cc(30)] MediaEvent: MEDIA_ERROR_LOG_ENTRY {"error":"FFmpegDemuxer: no supported streams"}
[1:1:0712/223544.376819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223545.858313:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223545.859026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , n, (){i&&i()}
[1:1:0712/223545.859262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223545.949457:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223545.950112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , n, (){i&&i()}
[1:1:0712/223545.950374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223546.038454:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223546.039067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , n, (){i&&i()}
[1:1:0712/223546.039276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223546.131381:ERROR:render_media_log.cc(30)] MediaEvent: PIPELINE_ERROR DEMUXER_ERROR_NO_SUPPORTED_STREAMS
[1:1:0712/223546.189249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223546.189913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , n, (){i&&i()}
[1:1:0712/223546.190159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223546.430229:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 791 0x7fbe245132e0 0x3b578cddf9e0 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223546.432147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (function(b,e,d,a,c){e[a]=e[a]||function(){(e[a].q=e[a].q||[]).push(arguments)};setTimeout(function(
[1:1:0712/223546.432369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223546.433444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1e4523de29c8, 0x3b578cafb1a0
[1:1:0712/223546.433641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 0
[1:1:0712/223546.434057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 825
[1:1:0712/223546.434316:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 825 0x7fbe225eb070 0x3b578ddc3fe0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 791 0x7fbe245132e0 0x3b578cddf9e0 
[1:1:0712/223546.453514:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 792 0x7fbe245132e0 0x3b578d6044e0 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223546.464123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , if(!this.JSON2){this.JSON2={}}(function(){function d(f){return f<10?"0"+f:f}function l(n,m){var f=Ob
[1:1:0712/223546.464350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223546.472173:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 10
[1:1:0712/223546.472618:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 829
[1:1:0712/223546.472845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7fbe225eb070 0x3b578ca5b9e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 792 0x7fbe245132e0 0x3b578d6044e0 
[1:1:0712/223546.653182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 794 0x7fbe245132e0 0x3b578d5f9fe0 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223546.662229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (function(){var h={},mt={},c={id:"82d2186024cf7459f80be3ff94bea77f",dm:["sale.vmall.com"],js:"tongji
[1:1:0712/223546.698604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223546.740983:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb148
[1:1:0712/223546.741209:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223546.741630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 849
[1:1:0712/223546.741857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7fbe225eb070 0x3b578d7897e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 794 0x7fbe245132e0 0x3b578d5f9fe0 
[13212:13212:0712/223606.037825:INFO:CONSOLE(4)] "Synchronous XMLHttpRequest on the main thread is deprecated because of its detrimental effects to the end user's experience. For more help, check https://xhr.spec.whatwg.org/.", source: https://res9.vmallres.com/shopdc/cdn/modules/common/pc/js/jquery-1.11.1.min.js (4)
[13212:13212:0712/223606.239147:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/223606.298379:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/223607.397493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 825, 7fbe24f30881
[1:1:0712/223607.421143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"791 0x7fbe245132e0 0x3b578cddf9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223607.421491:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"791 0x7fbe245132e0 0x3b578cddf9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223607.421930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223607.422569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (){var g=document.createElement("iframe");(g.frameElement||g).style.cssText="display:none";g.src="ja
[1:1:0712/223607.422781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[13212:13212:0712/223607.427038:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/223607.429083:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x3b578c891a20
[1:1:0712/223607.429289:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[13212:13212:0712/223607.433677:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 4, 
[1:1:0712/223607.453148:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[13212:13212:0712/223607.464492:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://sale.vmall.com/, https://sale.vmall.com/, 4
[13212:13212:0712/223607.464671:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 5, https://sale.vmall.com/, https://sale.vmall.com
[1:1:0712/223607.473427:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 3efe443ed8d8, 5:3_https://sale.vmall.com/, 5:5_https://sale.vmall.com/, about:blank
[1:1:0712/223607.473736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/, 3efe443ed8d8, 3efe44362860, , false
[1:1:0712/223607.474024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "sale.vmall.com", 5, 2, https://sale.vmall.com, sale.vmall.com, 3
[1:1:0712/223607.474468:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://nebula-collector.huawei.com/api/2.0/vmallcn-min.js:1:1

[1:1:0712/223607.478428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/-5:3_https://sale.vmall.com/, 3efe44362860, 3efe443ed8d8, Date, 
[1:1:0712/223607.478746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 3, , , 0
[1:1:0712/223607.479275:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://nebula-collector.huawei.com/api/2.0/vmallcn-min.js:1:1

[1:1:0712/223607.479732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/-5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/, 3efe443ed8d8, 3efe44362860, write, 
[1:1:0712/223607.480048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 5, 4, https://sale.vmall.com, sale.vmall.com, 3
[1:1:0712/223607.480550:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://nebula-collector.huawei.com/api/2.0/vmallcn-min.js:1:1

[1:1:0712/223607.485616:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223607.722899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 829, 7fbe24f308db
[1:1:0712/223607.762299:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"792 0x7fbe245132e0 0x3b578d6044e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223607.762649:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"792 0x7fbe245132e0 0x3b578d6044e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223607.763151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 945
[1:1:0712/223607.763383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 945 0x7fbe225eb070 0x3b578cda3060 , 5:3_https://sale.vmall.com/, 0, , 829 0x7fbe225eb070 0x3b578ca5b9e0 
[1:1:0712/223607.763700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223607.764329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (){if(h||/loaded|complete/.test(d.readyState)){clearInterval(K);k()}}
[1:1:0712/223607.764572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223608.151749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/223608.152054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223609.182794:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223609.184312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (d){if(a.K(d.origin)===k.Ma){var e=d.data||{};d=e.sd||"";var e=e.jn||"",f=/^customevent$/.test(e);Re
[1:1:0712/223609.184548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223609.573315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 849, 7fbe24f30881
[1:1:0712/223609.594876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"794 0x7fbe245132e0 0x3b578d5f9fe0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223609.595088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"794 0x7fbe245132e0 0x3b578d5f9fe0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223609.595291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223609.595636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/223609.595751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223609.596116:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb150
[1:1:0712/223609.596218:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223609.596399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 967
[1:1:0712/223609.596522:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7fbe225eb070 0x3b578df1f7e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 849 0x7fbe225eb070 0x3b578d7897e0 
[1:1:0712/223610.788487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 945, 7fbe24f308db
[1:1:0712/223610.802911:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"829 0x7fbe225eb070 0x3b578ca5b9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223610.803106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"829 0x7fbe225eb070 0x3b578ca5b9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223610.803318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 983
[1:1:0712/223610.803424:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7fbe225eb070 0x3b578d7789e0 , 5:3_https://sale.vmall.com/, 0, , 945 0x7fbe225eb070 0x3b578cda3060 
[1:1:0712/223610.803569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223610.803881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (){if(h||/loaded|complete/.test(d.readyState)){clearInterval(K);k()}}
[1:1:0712/223610.803986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223610.979687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , document.readyState
[1:1:0712/223610.979950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223611.647124:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223611.647878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/223611.648111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223611.685129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 967, 7fbe24f30881
[1:1:0712/223611.729342:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"849 0x7fbe225eb070 0x3b578d7897e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223611.729643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"849 0x7fbe225eb070 0x3b578d7897e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223611.730044:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223611.730608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/223611.730785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223611.731495:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb150
[1:1:0712/223611.731650:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223611.732039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1025
[1:1:0712/223611.732230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1025 0x7fbe225eb070 0x3b578e1b01e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 967 0x7fbe225eb070 0x3b578df1f7e0 
[1:1:0712/223611.819709:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223611.820163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , k, (){var K;if(!h){h=true;g("load");for(K=0;K<C.length;K++){C[K]()}}return true}
[1:1:0712/223611.820276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223611.820705:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223611.821690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223611.822312:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223611.822736:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb1f0
[1:1:0712/223611.822836:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223611.823037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1027
[1:1:0712/223611.823152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1027 0x7fbe225eb070 0x3b578e38d760 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 973 0x7fbe225eb070 0x3b578d5fb5e0 
[1:1:0712/223611.961765:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 979 0x7fbe245132e0 0x3b578e256460 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223611.962784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://sale.vmall.com/, 3efe443ed8d8, , , var win=parent?parent.window:window;(function(b,a){(function(h,k,j){var c,e=0,f=a.getElementById("dm
[1:1:0712/223611.962926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 5, 1, https://sale.vmall.com, sale.vmall.com, 3
[1:1:0712/223611.963429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_https://sale.vmall.com/-5:3_https://sale.vmall.com/, 3efe44362860, 3efe443ed8d8, getElementById, 
[1:1:0712/223611.963538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 2, , , 0
[1:1:0712/223611.963787:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1
	https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1
	https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1

[1:1:0712/223611.966612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_https://sale.vmall.com/-5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/, 3efe443ed8d8, 3efe44362860, indexOf, 
[1:1:0712/223611.966873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 5, 3, https://sale.vmall.com, sale.vmall.com, 3
[1:1:0712/223611.967541:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1
	https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1
	https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1

[1:1:0712/223611.971863:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1e4523ef8260, 0x3b578cafb190
[1:1:0712/223611.972122:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 0
[1:1:0712/223611.972710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1035
[1:1:0712/223611.972962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7fbe225eb070 0x3b578e3797e0 , 5:3_https://sale.vmall.com/, 3, -5:5_https://sale.vmall.com/-5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/, 979 0x7fbe245132e0 0x3b578e256460 
[1:1:0712/223612.101760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 983, 7fbe24f308db
[1:1:0712/223612.135769:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"945 0x7fbe225eb070 0x3b578cda3060 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223612.136053:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"945 0x7fbe225eb070 0x3b578cda3060 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223612.136510:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 1039
[1:1:0712/223612.136727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1039 0x7fbe225eb070 0x3b578e1aefe0 , 5:3_https://sale.vmall.com/, 0, , 983 0x7fbe225eb070 0x3b578d7789e0 
[1:1:0712/223612.137107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223612.137652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (){if(h||/loaded|complete/.test(d.readyState)){clearInterval(K);k()}}
[1:1:0712/223612.137824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223612.186248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , document.readyState
[1:1:0712/223612.186496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223613.083081:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223613.083920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , r.handle, (a){return typeof m===K||a&&m.event.triggered===a.type?void 0:m.event.dispatch.apply(k.elem,argument
[1:1:0712/223613.084141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223613.104191:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223613.222209:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223614.532673:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1027, 7fbe24f30881
[1:1:0712/223614.577263:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"973 0x7fbe225eb070 0x3b578d5fb5e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223614.577647:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"973 0x7fbe225eb070 0x3b578d5fb5e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223614.578067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223614.578736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/223614.578947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223614.579644:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb150
[1:1:0712/223614.579831:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223614.580225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1068
[1:1:0712/223614.580425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1068 0x7fbe225eb070 0x3b578e6968e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1027 0x7fbe225eb070 0x3b578e38d760 
[1:1:0712/223614.662860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1035, 7fbe24f30881
[1:1:0712/223614.697047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe443ed8d83efe443628603efe443ed8d8","ptid":"979 0x7fbe245132e0 0x3b578e256460 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223614.697400:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:5_https://sale.vmall.com/-5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/","ptid":"979 0x7fbe245132e0 0x3b578e256460 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223614.697802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223614.698360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://sale.vmall.com/, 3efe443ed8d8, , , (){loaderJs(i+g,"dmpa")}
[1:1:0712/223614.698578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 5, 1, https://sale.vmall.com, sale.vmall.com, 3
[1:1:0712/223614.700050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_https://sale.vmall.com/-5:3_https://sale.vmall.com/, 3efe44362860, 3efe443ed8d8, getElementById, 
[1:1:0712/223614.700241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 2, , , 0
[1:1:0712/223614.700816:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	loaderJs (https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1)
	https://nebula-collector.huawei.com/api/2.0/dmpa_f-min.js?hr=1562996167480:1:1

[1:1:0712/223615.329469:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "animationend", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223615.782842:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1068, 7fbe24f30881
[1:1:0712/223615.828155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"1027 0x7fbe225eb070 0x3b578e38d760 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223615.828525:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"1027 0x7fbe225eb070 0x3b578e38d760 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223615.829599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223615.830278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/223615.830463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223615.831174:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb150
[1:1:0712/223615.831335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223615.831715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1083
[1:1:0712/223615.831904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7fbe225eb070 0x3b578e4d6560 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1068 0x7fbe225eb070 0x3b578e6968e0 
[1:1:0712/223616.084328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1083, 7fbe24f30881
[1:1:0712/223616.101435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"1068 0x7fbe225eb070 0x3b578e6968e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223616.101620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"1068 0x7fbe225eb070 0x3b578e6968e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223616.101812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223616.102286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/223616.102394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223616.102702:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb150
[1:1:0712/223616.102797:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223616.102972:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1097
[1:1:0712/223616.103074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7fbe225eb070 0x3b578e6bffe0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1083 0x7fbe225eb070 0x3b578e4d6560 
[1:1:0712/223616.387628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7fbe245132e0 0x3b578d94d9e0 , "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223616.396071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , /*!
 * Web Analytics(hwa-js-api-1.1.7_20160506_1,builded by ming t1)
 *
 * JavaScript tracking clien
[1:1:0712/223616.396327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223616.411590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 10
[1:1:0712/223616.411998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 1106
[1:1:0712/223616.412210:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7fbe225eb070 0x3b578d5dd8e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1098 0x7fbe245132e0 0x3b578d94d9e0 
[1:1:0712/223616.603685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1e4523de29c8, 0x3b578cafb148
[1:1:0712/223616.603940:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 10
[1:1:0712/223616.604369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1107
[1:1:0712/223616.604563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1107 0x7fbe225eb070 0x3b578e268560 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1098 0x7fbe245132e0 0x3b578d94d9e0 
[1:1:0712/223616.606186:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 300
[1:1:0712/223616.606608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 1108
[1:1:0712/223616.606798:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1108 0x7fbe225eb070 0x3b578e379c60 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1098 0x7fbe245132e0 0x3b578d94d9e0 
[1:1:0712/223616.607418:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x1e4523de29c8, 0x3b578cafb148
[1:1:0712/223616.607575:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 10000
[1:1:0712/223616.607944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1109
[1:1:0712/223616.608129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7fbe225eb070 0x3b578e4a4360 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1098 0x7fbe245132e0 0x3b578d94d9e0 
[1:1:0712/223616.609088:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1e4523de29c8, 0x3b578cafb148
[1:1:0712/223616.609267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 0
[1:1:0712/223616.609633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1110
[1:1:0712/223616.609818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1110 0x7fbe225eb070 0x3b578e4ab4e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1098 0x7fbe245132e0 0x3b578d94d9e0 
[1:1:0712/223616.612527:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223616.613141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://sale.vmall.com/-5:5_https://sale.vmall.com/, 3efe443ed8d8, 3efe44362860, c.onload.c.onreadystatechange, (){if(!this.readyState||"loaded"===this.readyState||"complete"===this.readyState){o();this.onload=th
[1:1:0712/223616.613415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 5, 2, https://sale.vmall.com, sale.vmall.com, 3
[1:1:0712/223616.613806:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/223616.759690:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1097, 7fbe24f30881
[1:1:0712/223616.776899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"1083 0x7fbe225eb070 0x3b578e4d6560 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223616.777099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"1083 0x7fbe225eb070 0x3b578e4d6560 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223616.777311:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223616.777632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/223616.777734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223616.778050:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1e4523de29c8, 0x3b578cafb150
[1:1:0712/223616.778145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sale.vmall.com/pseries.html?cid=78164", 100
[1:1:0712/223616.778364:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1120
[1:1:0712/223616.778474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7fbe225eb070 0x3b578d68d2e0 , 5:3_https://sale.vmall.com/, 1, -5:3_https://sale.vmall.com/, 1097 0x7fbe225eb070 0x3b578e6bffe0 
[1:1:0712/223616.904114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 1106, 7fbe24f308db
[1:1:0712/223616.950177:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"1098 0x7fbe245132e0 0x3b578d94d9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223616.950549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"1098 0x7fbe245132e0 0x3b578d94d9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223616.950947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sale.vmall.com/, 1124
[1:1:0712/223616.951138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1124 0x7fbe225eb070 0x3b578e6b2ce0 , 5:3_https://sale.vmall.com/, 0, , 1106 0x7fbe225eb070 0x3b578d5dd8e0 
[1:1:0712/223616.951467:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223616.952018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (){if(hasLoaded||/loaded|complete/.test(documentAlias.readyState)){clearInterval(_timer);loadHandler
[1:1:0712/223616.952203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223617.003416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1110, 7fbe24f30881
[1:1:0712/223617.049681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"1098 0x7fbe245132e0 0x3b578d94d9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223617.050016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"1098 0x7fbe245132e0 0x3b578d94d9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223617.050446:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223617.051022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (){if(autoSendPV){asyncTracker.trackPageView();asyncTracker.trackPerformance(null,null)}}
[1:1:0712/223617.051197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
[1:1:0712/223617.099493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sale.vmall.com/, 1107, 7fbe24f30881
[1:1:0712/223617.145980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3efe44362860","ptid":"1098 0x7fbe245132e0 0x3b578d94d9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223617.146313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sale.vmall.com/","ptid":"1098 0x7fbe245132e0 0x3b578d94d9e0 ","rf":"5:3_https://sale.vmall.com/"}
[1:1:0712/223617.146717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sale.vmall.com/pseries.html?cid=78164"
[1:1:0712/223617.147342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sale.vmall.com/, 3efe44362860, , , (){var request=getRequest(mixin({action:"pv"},mapData(data)),null,"log");sendRequest(request,configT
[1:1:0712/223617.147535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sale.vmall.com/pseries.html?cid=78164", "sale.vmall.com", 3, 1, , , 0
