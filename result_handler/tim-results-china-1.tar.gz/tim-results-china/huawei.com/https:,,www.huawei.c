[0712/222029.850262:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/222029.850633:INFO:switcher_clone.cc(787)] backtrace rip is 7f192ab44891
[0712/222030.786574:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/222030.786955:INFO:switcher_clone.cc(787)] backtrace rip is 7f058ce3a891
[1:1:0712/222030.798812:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/222030.799074:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/222030.804257:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/222032.073237:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/222032.073525:INFO:switcher_clone.cc(787)] backtrace rip is 7ff69f6d6891
[11348:11348:0712/222032.210949:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[11381:11381:0712/222032.300716:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11381
[11391:11391:0712/222032.301153:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11391

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dfc8a450-ed75-4173-8f28-43914170b2b9
[11348:11348:0712/222032.751606:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[11348:11379:0712/222032.752306:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/222032.752649:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/222032.753722:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/222032.754342:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/222032.754490:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/222032.757770:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3077f2b9, 1
[1:1:0712/222032.758384:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x385918ee, 0
[1:1:0712/222032.758693:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf1fce05, 3
[1:1:0712/222032.759098:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1f540e53, 2
[1:1:0712/222032.759543:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffee185938 ffffffb9fffffff27730 530e541f 05ffffffce1f0f , 10104, 4
[1:1:0712/222032.761498:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11348:11379:0712/222032.762007:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Y8��w0ST���z
[11348:11379:0712/222032.762073:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Y8��w0ST�����z
[1:1:0712/222032.762018:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f058b0750a0, 3
[11348:11379:0712/222032.762424:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[11348:11379:0712/222032.762515:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 11401, 4, ee185938 b9f27730 530e541f 05ce1f0f 
[1:1:0712/222032.762458:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f058b200080, 2
[1:1:0712/222032.762831:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0574ec3d20, -2
[1:1:0712/222032.792448:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/222032.793039:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f540e53
[1:1:0712/222032.793671:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f540e53
[1:1:0712/222032.794655:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f540e53
[1:1:0712/222032.795217:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.795330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.795423:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.795525:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.795754:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f540e53
[1:1:0712/222032.795926:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f058ce3a7ba
[1:1:0712/222032.796006:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f058ce31def, 7f058ce3a77a, 7f058ce3c0cf
[1:1:0712/222032.797481:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f540e53
[1:1:0712/222032.797649:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f540e53
[1:1:0712/222032.797945:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f540e53
[1:1:0712/222032.798616:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.798722:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.798868:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.798971:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f540e53
[1:1:0712/222032.799414:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f540e53
[1:1:0712/222032.799573:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f058ce3a7ba
[1:1:0712/222032.799654:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f058ce31def, 7f058ce3a77a, 7f058ce3c0cf
[1:1:0712/222032.801884:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/222032.802157:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/222032.802262:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc47cd82e8, 0x7ffc47cd8268)
[1:1:0712/222032.821063:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/222032.829027:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[11348:11348:0712/222033.430877:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11348:11348:0712/222033.432212:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11348:11360:0712/222033.451332:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[11348:11360:0712/222033.451432:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[11348:11348:0712/222033.451579:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[11348:11348:0712/222033.451664:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[11348:11348:0712/222033.451841:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,11401, 4
[1:7:0712/222033.458466:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[11348:11373:0712/222033.521541:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/222033.590226:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x992555eb220
[1:1:0712/222033.590464:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/222033.848690:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/222035.100459:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222035.104947:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[11348:11348:0712/222035.502719:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[11348:11348:0712/222035.502781:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/222035.959678:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/222036.166384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144f890c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/222036.166721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/222036.183232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144f890c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/222036.183575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/222036.311361:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/222036.311620:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/222036.756455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/222036.764572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144f890c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/222036.764861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/222036.803423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/222036.813255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144f890c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/222036.813492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/222036.825071:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[11348:11348:0712/222036.828667:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/222036.829377:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x992555e9e20
[1:1:0712/222036.829664:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[11348:11348:0712/222036.848928:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[11348:11348:0712/222036.883485:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[11348:11348:0712/222036.883639:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[11348:11348:0712/222036.903989:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/222036.908872:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/222037.888454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f0576a9e2e0 0x99255794ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/222037.889819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144f890c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/222037.890059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/222037.891608:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[11348:11348:0712/222037.964516:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/222037.966812:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x992555ea820
[1:1:0712/222037.967031:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[11348:11348:0712/222037.971488:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/222037.987071:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/222037.987341:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[11348:11348:0712/222037.988430:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[11348:11348:0712/222037.999731:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11348:11348:0712/222038.000729:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11348:11360:0712/222038.006716:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[11348:11360:0712/222038.006806:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[11348:11348:0712/222038.007117:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[11348:11348:0712/222038.007223:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[11348:11348:0712/222038.007411:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,11401, 4
[1:7:0712/222038.012682:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/222038.595692:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/222039.063964:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f0576a9e2e0 0x99255836b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/222039.065024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144f890c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/222039.065242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/222039.066007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[11348:11348:0712/222039.195319:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[11348:11348:0712/222039.195448:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/222039.238078:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/222039.515442:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[11348:11348:0712/222039.627228:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[11348:11379:0712/222039.627742:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/222039.627977:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/222039.628216:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/222039.628618:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/222039.628755:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/222039.631806:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2448921e, 1
[1:1:0712/222039.632164:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1a55746d, 0
[1:1:0712/222039.632314:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2a7019e5, 3
[1:1:0712/222039.632456:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x100e33ed, 2
[1:1:0712/222039.632621:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6d74551a 1effffff924824 ffffffed330e10 ffffffe519702a , 10104, 5
[1:1:0712/222039.633581:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11348:11379:0712/222039.633796:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGmtU�H$�3�p*��z
[11348:11379:0712/222039.633866:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is mtU�H$�3�p*����z
[1:1:0712/222039.633972:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f058b0750a0, 3
[11348:11379:0712/222039.634110:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 11446, 5, 6d74551a 1e924824 ed330e10 e519702a 
[1:1:0712/222039.634150:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f058b200080, 2
[1:1:0712/222039.634349:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0574ec3d20, -2
[1:1:0712/222039.659136:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/222039.659499:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 100e33ed
[1:1:0712/222039.659818:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 100e33ed
[1:1:0712/222039.660083:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 100e33ed
[1:1:0712/222039.660538:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.660639:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.660733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.660834:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.661070:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 100e33ed
[1:1:0712/222039.661200:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f058ce3a7ba
[1:1:0712/222039.661276:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f058ce31def, 7f058ce3a77a, 7f058ce3c0cf
[1:1:0712/222039.662860:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 100e33ed
[1:1:0712/222039.663024:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 100e33ed
[1:1:0712/222039.663297:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 100e33ed
[1:1:0712/222039.663994:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.664112:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.664208:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.664305:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 100e33ed
[1:1:0712/222039.664770:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 100e33ed
[1:1:0712/222039.664929:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f058ce3a7ba
[1:1:0712/222039.665012:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f058ce31def, 7f058ce3a77a, 7f058ce3c0cf
[1:1:0712/222039.667238:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/222039.667576:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/222039.667672:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc47cd82e8, 0x7ffc47cd8268)
[1:1:0712/222039.679239:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/222039.684059:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/222039.804969:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/222039.805125:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/222039.883004:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x992555c7220
[1:1:0712/222039.883155:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/222040.254177:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/222040.255906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144f891ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/222040.256052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/222040.258266:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/222040.424499:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/222040.425214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144f890c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/222040.425394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[11348:11348:0712/222040.565537:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11348:11348:0712/222040.572565:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11348:11360:0712/222040.601232:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[11348:11360:0712/222040.601324:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[11348:11348:0712/222040.601859:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.huawei.com/
[11348:11348:0712/222040.601952:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.huawei.com/, https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei, 1
[11348:11348:0712/222040.602112:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.huawei.com/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 05:20:40 GMT Server: nginx Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Cache-Control: no-cache, no-store Pragma: no-cache Expires: -1 X-Frame-Options: SAMEORIGIN X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block X-Download-Options: noopen Strict-Transport-Security: max-age=31536000 X-Powered-By: ASP.NET Access-Control-Allow-Origin: * Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS Access-Control-Allow-Headers: Content-Type processtime: 0.056 Content-Encoding: gzip X-Via: 1.1 chk157:7 (Cdn Cache Server V2.0) Connection: keep-alive Ws-S2h-Acc-Level: 1  ,11446, 5
[1:7:0712/222040.610273:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/222040.653306:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.huawei.com/
[11348:11348:0712/222040.771556:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.huawei.com/, https://www.huawei.com/, 1
[11348:11348:0712/222040.771704:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.huawei.com/, https://www.huawei.com
[1:1:0712/222040.776180:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/222040.858105:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/222040.859696:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/222040.859889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144f891ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/222040.860113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/222040.890446:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/222040.975737:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/222040.975997:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222041.016284:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/222041.016834:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/222041.017032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144f891ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/222041.017211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/222041.797970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7f0574b76070 0x9925579e7e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222041.800016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , 
        var startup = [];
    
[1:1:0712/222041.800211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222041.822338:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.020592, 118, 1
[1:1:0712/222041.822520:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/222041.860752:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/222041.860875:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222041.863199:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 191 0x7f0574b76070 0x9925579c4e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222041.875411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , /*! jQuery v3.3.1 | (c) JS Foundation and other contributors | jquery.org/license */
!function(e,t){
[1:1:0712/222041.875618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222041.896874:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222042.141020:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 191 0x7f0574b76070 0x9925579c4e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/222042.730708:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222042.732668:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222042.747901:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222042.761500:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222042.761844:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222043.767387:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.90653, 0, 0
[1:1:0712/222043.767619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/222043.856367:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/222043.856518:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222043.857047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f0574b76070 0x99255bfaf60 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222043.857594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , 
$(function () {
    $("#hw1_global_nav .nav-contact > ul > li > a").each(function (i) {
        var
[1:1:0712/222043.857705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222043.951750:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222044.098190:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0574edebd0 0x99255f49958 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.120257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , /*! jQuery Validation Plugin - v1.13.1 - 10/14/2014
 * http://jqueryvalidation.org/
 * Copyright (c)
[1:1:0712/222044.120494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222044.726957:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0574edebd0 0x99255f49958 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.728749:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b9a0
[1:1:0712/222044.728893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.729107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 234
[1:1:0712/222044.729214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 234 0x7f0574b76070 0x992560e6e60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.730283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0574edebd0 0x99255f49958 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.731499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0574edebd0 0x99255f49958 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
		remove user.10_22c6804f -> 0
[1:1:0712/222044.735430:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0574edebd0 0x99255f49958 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.736438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f0574edebd0 0x99255f49958 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.796724:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.805227:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.805405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.805956:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 246
[1:1:0712/222044.806162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 246 0x7f0574b76070 0x992561271e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.807057:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.807215:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.807714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 247
[1:1:0712/222044.807930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 247 0x7f0574b76070 0x9925615f160 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.808618:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.808769:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.809303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 248
[1:1:0712/222044.809494:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 248 0x7f0574b76070 0x99255bfaf60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.810269:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.810424:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.810976:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 249
[1:1:0712/222044.811163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 249 0x7f0574b76070 0x99256213c60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.811918:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.812074:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.812571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 250
[1:1:0712/222044.812751:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 250 0x7f0574b76070 0x9925615f260 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.813489:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.813642:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.814254:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 251
[1:1:0712/222044.814439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 251 0x7f0574b76070 0x9925620b360 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.815265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.815466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.816146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 252
[1:1:0712/222044.816389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 252 0x7f0574b76070 0x99255f4bae0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.817404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.817598:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.818262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 253
[1:1:0712/222044.818497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 253 0x7f0574b76070 0x99256293360 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.819469:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.819681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.820352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 254
[1:1:0712/222044.820603:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 254 0x7f0574b76070 0x992562930e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.821542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.821737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.822414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 255
[1:1:0712/222044.822654:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 255 0x7f0574b76070 0x992561f82e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.823577:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.823771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.824340:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 256
[1:1:0712/222044.824528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 256 0x7f0574b76070 0x992562cb2e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.825299:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.825455:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.825978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 257
[1:1:0712/222044.826164:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 257 0x7f0574b76070 0x99255754360 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.826914:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.827077:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.827582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 258
[1:1:0712/222044.827771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 258 0x7f0574b76070 0x992562da660 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.828520:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515bc40
[1:1:0712/222044.828673:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222044.829189:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 259
[1:1:0712/222044.829380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 259 0x7f0574b76070 0x992562da9e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 230 0x7f0574edebd0 0x99255f49958 
[1:1:0712/222044.930780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 234, 7f05774bb881
[1:1:0712/222044.934070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222044.934208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222044.934377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.934722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
                var iframe = document.createElement('iframe');
                (iframe.frameEle
[1:1:0712/222044.934825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222044.939508:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x992563c1a20
[1:1:0712/222044.939680:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/222044.977308:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 3aeb0ff195b8, 5:3_https://www.huawei.com/, 5:4_https://www.huawei.com/, about:blank
[1:1:0712/222044.977475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.huawei.com/-5:4_https://www.huawei.com/, 3aeb0ff195b8, 3aeb0fe02860, , false
[1:1:0712/222044.977601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.huawei.com", 4, 2, https://www.huawei.com, www.huawei.com, 3
[1:1:0712/222044.977775:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei:179:32

[1:1:0712/222044.978800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.huawei.com/-5:4_https://www.huawei.com/-5:3_https://www.huawei.com/, 3aeb0fe02860, 3aeb0ff195b8, Date, 
[1:1:0712/222044.978971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 3, , , 0
[1:1:0712/222044.979185:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei:179:32

[1:1:0712/222044.979668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://www.huawei.com/-5:4_https://www.huawei.com/-5:3_https://www.huawei.com/-5:4_https://www.huawei.com/, 3aeb0ff195b8, 3aeb0fe02860, write, 
[1:1:0712/222044.979817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 4, 4, https://www.huawei.com, www.huawei.com, 3
[1:1:0712/222044.980067:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei:179:32

[1:1:0712/222044.981849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.992384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 246, 7f05774bb881
[1:1:0712/222044.996571:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222044.996713:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222044.996939:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222044.997243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222044.997344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.001897:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.002018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.002232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 298
[1:1:0712/222045.002343:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 298 0x7f0574b76070 0x992563fcde0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 246 0x7f0574b76070 0x992561271e0 
[1:1:0712/222045.002852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 247, 7f05774bb881
[1:1:0712/222045.007034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.007161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.007318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.007592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.007692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.009950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.010054:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.010251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 299
[1:1:0712/222045.010354:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 299 0x7f0574b76070 0x99255f4c960 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 247 0x7f0574b76070 0x9925615f160 
[1:1:0712/222045.010829:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 248, 7f05774bb881
[1:1:0712/222045.014370:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.014492:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.014646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.014947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.015051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.088229:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.088501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.089171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 302
[1:1:0712/222045.089406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 302 0x7f0574b76070 0x9925643d5e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 248 0x7f0574b76070 0x99255bfaf60 
[1:1:0712/222045.102005:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 249, 7f05774bb881
[1:1:0712/222045.105554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.105688:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.105852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.106253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.106364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.132332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.132577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.133244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 308
[1:1:0712/222045.133480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 308 0x7f0574b76070 0x9925644e160 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 249 0x7f0574b76070 0x99256213c60 
[1:1:0712/222045.135505:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 250, 7f05774bb881
[1:1:0712/222045.151743:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.152100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.152499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.153364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.153576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.239682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.239852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 800
[1:1:0712/222045.240097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 311
[1:1:0712/222045.240207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 311 0x7f0574b76070 0x99255719460 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 250 0x7f0574b76070 0x9925615f260 
[1:1:0712/222045.246216:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.246324:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.246531:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 312
[1:1:0712/222045.246638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 312 0x7f0574b76070 0x992564fc2e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 250 0x7f0574b76070 0x9925615f260 
[1:1:0712/222045.248317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 251, 7f05774bb881
[1:1:0712/222045.261209:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.261522:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.261843:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.262522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.262700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.320630:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.320789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.321070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 319
[1:1:0712/222045.321181:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 319 0x7f0574b76070 0x992561b8fe0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 251 0x7f0574b76070 0x9925620b360 
[1:1:0712/222045.333394:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.333507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1000
[1:1:0712/222045.333715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 320
[1:1:0712/222045.333819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 320 0x7f0574b76070 0x9925662d760 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 251 0x7f0574b76070 0x9925620b360 
[1:1:0712/222045.496027:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.496246:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 50
[1:1:0712/222045.496779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 321
[1:1:0712/222045.496967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 321 0x7f0574b76070 0x9925669a260 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 251 0x7f0574b76070 0x9925620b360 
[1:1:0712/222045.525886:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.526249:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.526953:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 322
[1:1:0712/222045.527235:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 322 0x7f0574b76070 0x992565394e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 251 0x7f0574b76070 0x9925620b360 
[1:1:0712/222045.536260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 252, 7f05774bb881
[1:1:0712/222045.539904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.540074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.540240:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.540535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.540636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.543691:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.543798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.544039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 326
[1:1:0712/222045.544150:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7f0574b76070 0x992565ff8e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 252 0x7f0574b76070 0x99255f4bae0 
[1:1:0712/222045.544591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 253, 7f05774bb881
[1:1:0712/222045.548368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.548495:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.548650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.548917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.549084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.556623:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.556734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 200
[1:1:0712/222045.556951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 327
[1:1:0712/222045.557088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 327 0x7f0574b76070 0x9925669a3e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 253 0x7f0574b76070 0x99256293360 
[1:1:0712/222045.564081:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.564196:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.564398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 328
[1:1:0712/222045.564502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 328 0x7f0574b76070 0x992561f8760 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 253 0x7f0574b76070 0x99256293360 
[1:1:0712/222045.564985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 254, 7f05774bb881
[1:1:0712/222045.569260:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.569385:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.569544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.569813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.569915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.571584:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.571685:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.571881:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 331
[1:1:0712/222045.571982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 331 0x7f0574b76070 0x99256425160 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 254 0x7f0574b76070 0x992562930e0 
[1:1:0712/222045.581328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 255, 7f05774bb881
[1:1:0712/222045.584950:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.585108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.585265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.585536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.585641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.812596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.812818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.813412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 341
[1:1:0712/222045.813601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 341 0x7f0574b76070 0x99256813560 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 255 0x7f0574b76070 0x992561f82e0 
[1:1:0712/222045.815997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 256, 7f05774bb881
[1:1:0712/222045.830198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.830441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.830755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.831420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.831592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.835925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.836109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.836610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 345
[1:1:0712/222045.836793:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 345 0x7f0574b76070 0x9925620be60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 256 0x7f0574b76070 0x992562cb2e0 
[1:1:0712/222045.838461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 257, 7f05774bb881
[1:1:0712/222045.851656:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.851898:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.852223:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.852857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.853027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222045.860876:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222045.861039:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222045.861558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 348
[1:1:0712/222045.861741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 348 0x7f0574b76070 0x99256770ce0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 257 0x7f0574b76070 0x99255754360 
[1:1:0712/222045.890906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 258, 7f05774bb881
[1:1:0712/222045.904170:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.904417:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222045.904717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222045.905373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222045.905545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.033674:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222046.033903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222046.034477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 350
[1:1:0712/222046.034669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 350 0x7f0574b76070 0x9925688f0e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 258 0x7f0574b76070 0x992562da660 
[1:1:0712/222046.036595:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 259, 7f05774bb881
[1:1:0712/222046.050969:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.051226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"230 0x7f0574edebd0 0x99255f49958 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.051551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.052211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.052384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.057751:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222046.057915:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222046.058448:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 354
[1:1:0712/222046.058633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 354 0x7f0574b76070 0x992567c10e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 259 0x7f0574b76070 0x992562da9e0 
[1:1:0712/222046.116640:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 298, 7f05774bb881
[1:1:0712/222046.130010:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"246 0x7f0574b76070 0x992561271e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.130307:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"246 0x7f0574b76070 0x992561271e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.130615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.131268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.131441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.164546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 299, 7f05774bb881
[1:1:0712/222046.177972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"247 0x7f0574b76070 0x9925615f160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.178243:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"247 0x7f0574b76070 0x9925615f160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.178551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.179204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.179383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.210090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 302, 7f05774bb881
[1:1:0712/222046.223939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"248 0x7f0574b76070 0x99255bfaf60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.224201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"248 0x7f0574b76070 0x99255bfaf60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.224510:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.225155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.225345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.288137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 308, 7f05774bb881
[1:1:0712/222046.301795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"249 0x7f0574b76070 0x99256213c60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.302036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"249 0x7f0574b76070 0x99256213c60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.302382:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.303041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.303233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.365993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 312, 7f05774bb881
[1:1:0712/222046.379798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"250 0x7f0574b76070 0x9925615f260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.380040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"250 0x7f0574b76070 0x9925615f260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.380360:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.381015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.381191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.386093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 319, 7f05774bb881
[1:1:0712/222046.399895:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.400136:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.400455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.401083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.401272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.407205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222046.407396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222046.407904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 364
[1:1:0712/222046.408087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7f0574b76070 0x9925669ad60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 319 0x7f0574b76070 0x992561b8fe0 
[1:1:0712/222046.423628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 322, 7f05774bb881
[1:1:0712/222046.437427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.437667:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.437973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.438646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.438817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.458341:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 326, 7f05774bb881
[1:1:0712/222046.472182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"252 0x7f0574b76070 0x99255f4bae0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.472461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"252 0x7f0574b76070 0x99255f4bae0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.472768:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.473428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.473601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.478511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 321, 7f05774bb881
[1:1:0712/222046.492329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.492574:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.492872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.493518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){
		if($(window).width()<768){
			$('.vertical-card .card-img img.lazy').parent().setWidthHeight
[1:1:0712/222046.493690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.533892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 328, 7f05774bb881
[1:1:0712/222046.543805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"253 0x7f0574b76070 0x99256293360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.543941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"253 0x7f0574b76070 0x99256293360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.544109:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.544438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.544539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.550082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 331, 7f05774bb881
[1:1:0712/222046.553877:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"254 0x7f0574b76070 0x992562930e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.554002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"254 0x7f0574b76070 0x992562930e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.554150:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.554435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.554535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.589154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 327, 7f05774bb881
[1:1:0712/222046.593603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"253 0x7f0574b76070 0x99256293360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.593728:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"253 0x7f0574b76070 0x99256293360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.593927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.594257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){
    huawei.text_dot();
  // if($('.vertical-card').data('info')=='speaker-2'){
    if(window.scr
[1:1:0712/222046.594393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.644593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 341, 7f05774bb881
[1:1:0712/222046.662440:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"255 0x7f0574b76070 0x992561f82e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.662754:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"255 0x7f0574b76070 0x992561f82e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.663144:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.663962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.664174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.706471:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 345, 7f05774bb881
[1:1:0712/222046.723817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"256 0x7f0574b76070 0x992562cb2e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.724109:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"256 0x7f0574b76070 0x992562cb2e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.724494:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.725281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.725506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.750784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 348, 7f05774bb881
[1:1:0712/222046.768101:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"257 0x7f0574b76070 0x99255754360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.768410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"257 0x7f0574b76070 0x99255754360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.768777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.769643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.769853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.811794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 350, 7f05774bb881
[1:1:0712/222046.829175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"258 0x7f0574b76070 0x992562da660 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.829492:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"258 0x7f0574b76070 0x992562da660 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.829872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.830683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.830892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.854585:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358 0x7f0576a9e2e0 0x99256539160 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.856420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.huawei.com/, 3aeb0ff195b8, , , var win=parent?parent.window:window;(function(d,c){var b,a=function(e){if(!c.getElementById("ha")){b
[1:1:0712/222046.856690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 4, 1, https://www.huawei.com, www.huawei.com, 3
[1:1:0712/222046.858003:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b99710, 0x9925515b990
[1:1:0712/222046.858192:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222046.858916:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 375
[1:1:0712/222046.859142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 375 0x7f0574b76070 0x99256923c60 , 5:3_https://www.huawei.com/, 1, -5:4_https://www.huawei.com/, 358 0x7f0576a9e2e0 0x99256539160 
[1:1:0712/222046.861337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 311, 7f05774bb881
[1:1:0712/222046.878961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"250 0x7f0574b76070 0x9925615f260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.879253:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"250 0x7f0574b76070 0x9925615f260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.879635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.880438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , fn, () {
		if (!(location.hash == "#worldwide"))
			return;
		if ($(window).width() < 992) {
			$(".js-m
[1:1:0712/222046.880648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.883322:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 354, 7f05774bb881
[1:1:0712/222046.900844:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"259 0x7f0574b76070 0x992562da9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.901135:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"259 0x7f0574b76070 0x992562da9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.901515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.902399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222046.902618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222046.945214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 320, 7f05774bb881
[1:1:0712/222046.962722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.963009:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"251 0x7f0574b76070 0x9925620b360 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222046.963388:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222046.964155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
		huawei.lazyload(".slick-cloned .lazy");
		$(".slick-cloned .lazy").trigger("appear");
	}
[1:1:0712/222046.964376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222047.018266:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222047.018491:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222047.019129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 379
[1:1:0712/222047.019354:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 379 0x7f0574b76070 0x9925579db60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 320 0x7f0574b76070 0x9925662d760 
[1:1:0712/222047.066044:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 364, 7f05774bb881
[1:1:0712/222047.084472:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"319 0x7f0574b76070 0x992561b8fe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222047.084722:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"319 0x7f0574b76070 0x992561b8fe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222047.085037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222047.085710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222047.085888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222047.138039:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7f0576a9e2e0 0x992562a05e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222047.145547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.loader ut4.0.201907030949, Copyright 2019 Tealium.com Inc. All Rights
[1:1:0712/222047.145730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[11348:11348:0712/222119.932138:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei (0)
[11348:11348:0712/222119.932688:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[11348:11348:0712/222119.934636:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[11348:11348:0712/222119.939880:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.huawei.com/, https://www.huawei.com/, 4
[11348:11348:0712/222119.939982:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.huawei.com/, https://www.huawei.com
[11348:11348:0712/222120.007725:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/222120.019955:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[11348:11348:0712/222120.044580:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/222120.152841:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222120.378851:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 375, 7f05774bb881
[1:1:0712/222120.399259:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0ff195b8","ptid":"358 0x7f0576a9e2e0 0x99256539160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222120.399546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.huawei.com/","ptid":"358 0x7f0576a9e2e0 0x99256539160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222120.399892:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222120.400344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.huawei.com/, 3aeb0ff195b8, , , (){var e=c.getElementById("hwa");if(typeof d.ha_js_init_time=="number"){console.log("already loaded 
[1:1:0712/222120.400488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 4, 1, https://www.huawei.com, www.huawei.com, 3
[1:1:0712/222120.400979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.huawei.com/-5:3_https://www.huawei.com/, 3aeb0fe02860, 3aeb0ff195b8, getElementById, 
[1:1:0712/222120.401104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 2, , , 0
[1:1:0712/222120.401329:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://app.huawei.com/hwa-c/configresource/js/general/ha_f.js?hr=1562995244979:1:1

[1:1:0712/222120.406677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.huawei.com/-5:3_https://www.huawei.com/-5:4_https://www.huawei.com/, 3aeb0ff195b8, 3aeb0fe02860, a, (e){if(!c.getElementById("ha")){b=c.createElement("script");b.src=e;b.async=true;b.defer=true;b.id="
[1:1:0712/222120.407039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 4, 3, https://www.huawei.com, www.huawei.com, 3
[1:1:0712/222120.407849:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://app.huawei.com/hwa-c/configresource/js/general/ha_f.js?hr=1562995244979:1:1

[1:1:0712/222120.408784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.huawei.com/-5:3_https://www.huawei.com/-5:4_https://www.huawei.com/-5:3_https://www.huawei.com/, 3aeb0fe02860, 3aeb0ff195b8, getElementById, 
[1:1:0712/222120.409066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 4, , , 0
[1:1:0712/222120.409792:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	a (https://app.huawei.com/hwa-c/configresource/js/general/ha_f.js?hr=1562995244979:1:1)
	https://app.huawei.com/hwa-c/configresource/js/general/ha_f.js?hr=1562995244979:1:1

[1:1:0712/222120.488774:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 379, 7f05774bb881
[1:1:0712/222120.503594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"320 0x7f0574b76070 0x9925662d760 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222120.503943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"320 0x7f0574b76070 0x9925662d760 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222120.504409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222120.505177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222120.505381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222120.511550:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222120.511760:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222120.512348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 450
[1:1:0712/222120.512579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7f0574b76070 0x99256923d60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 379 0x7f0574b76070 0x9925579db60 
[1:1:0712/222120.728602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/222120.728908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222121.643555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 450, 7f05774bb881
[1:1:0712/222121.662904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"379 0x7f0574b76070 0x9925579db60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222121.663270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"379 0x7f0574b76070 0x9925579db60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222121.663717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222121.664523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , c, (){try{l()}catch(e){w.Deferred.exceptionHook&&w.Deferred.exceptionHook(e,c.stackTrace),t+1>=o&&(r!==
[1:1:0712/222121.664762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222121.806028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222121.806473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222121.978079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7f0576a9e2e0 0x99256b43060 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222121.985058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.19 ut4.0.201812201028, Copyright 2018 Tealium.com Inc. All Rights Res
[1:1:0712/222121.985311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222122.482069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222122.482381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222122.892887:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222122.893824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , y.handle, (t){return"undefined"!=typeof w&&w.event.triggered!==t.type?w.event.dispatch.apply(e,arguments):void
[1:1:0712/222122.894026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222123.043358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 508 0x7f0576a9e2e0 0x99256ecb0e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222123.046376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , /*!
 * Web Analytics(hwa-js-api-1.5.0_2019-1-29,builded by f00333362 t33)
 */
var ha_js_init_time
[1:1:0712/222123.046512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222123.052960:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 500
[1:1:0712/222123.053225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 532
[1:1:0712/222123.053339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f0574b76070 0x992563fcae0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 508 0x7f0576a9e2e0 0x99256ecb0e0 
[1:1:0712/222123.188077:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x12ac85b829c8, 0x9925515b948
[1:1:0712/222123.188359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 0
[1:1:0712/222123.189046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 533
[1:1:0712/222123.189293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 533 0x7f0574b76070 0x992553c8f60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 508 0x7f0576a9e2e0 0x99256ecb0e0 
[1:1:0712/222123.226299:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7f0576a9e2e0 0x99255f4a2e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222123.234450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0712/222123.234782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
		remove user.11_88df3228 -> 0
[1:1:0712/222123.850537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222123.850703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222124.102100:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 533, 7f05774bb881
[1:1:0712/222124.124510:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"508 0x7f0576a9e2e0 0x99256ecb0e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.124860:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"508 0x7f0576a9e2e0 0x99256ecb0e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.125266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222124.126017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){if(autoSendPV){asyncTracker.trackPageView();asyncTracker.trackPerformance(null,null)}}
[1:1:0712/222124.126255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222124.132628:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222124.132861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 10
[1:1:0712/222124.133444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 567
[1:1:0712/222124.133671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7f0574b76070 0x99256ee2e60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 533 0x7f0574b76070 0x992553c8f60 
[1:1:0712/222124.138573:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222124.138863:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222124.139519:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 568
[1:1:0712/222124.139756:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7f0574b76070 0x992565356e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 533 0x7f0574b76070 0x992553c8f60 
[1:1:0712/222124.673053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222124.673373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222124.701129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 532, 7f05774bb8db
[1:1:0712/222124.724032:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"508 0x7f0576a9e2e0 0x99256ecb0e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.724409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"508 0x7f0576a9e2e0 0x99256ecb0e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.724853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 585
[1:1:0712/222124.725196:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 585 0x7f0574b76070 0x99256a78e60 , 5:3_https://www.huawei.com/, 0, , 532 0x7f0574b76070 0x992563fcae0 
[1:1:0712/222124.725526:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222124.726401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){if(hasLoaded||/loaded|complete/.test(documentAlias.readyState)){clearInterval(_timer);loadHandler
[1:1:0712/222124.726637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222124.789013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 567, 7f05774bb881
[1:1:0712/222124.812505:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"533 0x7f0574b76070 0x992553c8f60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.812889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"533 0x7f0574b76070 0x992553c8f60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.813306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222124.814212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){var request=getRequest(mixin({"action":"pv"},mapData(data)),null,"log");sendRequest(request,confi
[1:1:0712/222124.814427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222124.936309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 568, 7f05774bb881
[1:1:0712/222124.951109:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"533 0x7f0574b76070 0x992553c8f60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.951510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"533 0x7f0574b76070 0x992553c8f60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222124.951973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222124.952789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){logPerformance(customTitle,customData,dryrun)}
[1:1:0712/222124.953007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222124.954243:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222124.954451:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222124.955012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 603
[1:1:0712/222124.955257:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 603 0x7f0574b76070 0x99256ee2de0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 568 0x7f0574b76070 0x992565356e0 
[1:1:0712/222124.982892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222124.983210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.024044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.024957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0712/222125.025207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.340114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222125.340421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.380407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 585, 7f05774bb8db
[1:1:0712/222125.406654:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"532 0x7f0574b76070 0x992563fcae0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.406973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"532 0x7f0574b76070 0x992563fcae0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.407413:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 624
[1:1:0712/222125.407653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 624 0x7f0574b76070 0x992562ef0e0 , 5:3_https://www.huawei.com/, 0, , 585 0x7f0574b76070 0x99256a78e60 
[1:1:0712/222125.407976:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.408728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){if(hasLoaded||/loaded|complete/.test(documentAlias.readyState)){clearInterval(_timer);loadHandler
[1:1:0712/222125.408950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.411403:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 603, 7f05774bb881
[1:1:0712/222125.429988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"568 0x7f0574b76070 0x992565356e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.430413:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"568 0x7f0574b76070 0x992565356e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.430808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.431575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){logPerformance(customTitle,customData,dryrun)}
[1:1:0712/222125.431787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.432706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222125.432898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222125.433552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 626
[1:1:0712/222125.433799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7f0574b76070 0x992552b95e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 603 0x7f0574b76070 0x99256ee2de0 
[1:1:0712/222125.460578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222125.460850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.491378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.492238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , image.onload, (){}
[1:1:0712/222125.492475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.495927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.510607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 500
[1:1:0712/222125.511200:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 630
[1:1:0712/222125.511428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 630 0x7f0574b76070 0x99256ecbbe0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 622 0x7f0574b76070 0x992560e6be0 
[1:1:0712/222125.511849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.524329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 250
[1:1:0712/222125.524865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 631
[1:1:0712/222125.525054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f0574b76070 0x992561f8de0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 622 0x7f0574b76070 0x992560e6be0 
[1:1:0712/222125.578061:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.642649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , document.readyState
[1:1:0712/222125.642804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.832559:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 626, 7f05774bb881
[1:1:0712/222125.845615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"603 0x7f0574b76070 0x99256ee2de0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.845915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"603 0x7f0574b76070 0x99256ee2de0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.846116:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.846493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){logPerformance(customTitle,customData,dryrun)}
[1:1:0712/222125.846602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222125.923655:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 624, 7f05774bb8db
[1:1:0712/222125.951840:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"585 0x7f0574b76070 0x99256a78e60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.952118:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"585 0x7f0574b76070 0x99256a78e60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222125.952520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 669
[1:1:0712/222125.952727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f0574b76070 0x992569348e0 , 5:3_https://www.huawei.com/, 0, , 624 0x7f0574b76070 0x992562ef0e0 
[1:1:0712/222125.952978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222125.953687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){if(hasLoaded||/loaded|complete/.test(documentAlias.readyState)){clearInterval(_timer);loadHandler
[1:1:0712/222125.953861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222126.199078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 631, 7f05774bb8db
[1:1:0712/222126.225728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"622 0x7f0574b76070 0x992560e6be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222126.226051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"622 0x7f0574b76070 0x992560e6be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222126.226453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 685
[1:1:0712/222126.226687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7f0574b76070 0x99256ecb460 , 5:3_https://www.huawei.com/, 0, , 631 0x7f0574b76070 0x992561f8de0 
[1:1:0712/222126.226970:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222126.227702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , utag.jdh, (h,i,j,k){h=utag.jdhc.length;if(h==0)window.clearInterval(utag.jdhi);else{for(i=0;i<h;i++){j=utag.jd
[1:1:0712/222126.227878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222126.284185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 656 0x7f0576a9e2e0 0x99255dcfee0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222126.285998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.5 ut4.0.201805230324, Copyright 2018 Tealium.com Inc. All Rights Rese
[1:1:0712/222126.286180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222126.341550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 657 0x7f0576a9e2e0 0x9925643d4e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222126.346317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.31 ut4.0.201805230324, Copyright 2018 Tealium.com Inc. All Rights Res
[1:1:0712/222126.346558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222126.814959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 671 0x7f0576a9e2e0 0x99256ee2560 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222126.816978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.73 ut4.0.201812201028, Copyright 2018 Tealium.com Inc. All Rights Res
[1:1:0712/222126.817184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222126.891535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 672 0x7f0576a9e2e0 0x992573dd2e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222126.894746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.78 ut4.0.201812201028, Copyright 2018 Tealium.com Inc. All Rights Res
[1:1:0712/222126.894941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222127.066918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 675 0x7f0576a9e2e0 0x992562daee0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222127.069085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.74 ut4.0.201812201028, Copyright 2018 Tealium.com Inc. All Rights Res
[1:1:0712/222127.069278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222127.136330:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 630, 7f05774bb8db
[1:1:0712/222127.164336:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"622 0x7f0574b76070 0x992560e6be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222127.164638:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"622 0x7f0574b76070 0x992560e6be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222127.165132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 714
[1:1:0712/222127.165367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7f0574b76070 0x992558ec9e0 , 5:3_https://www.huawei.com/, 0, , 630 0x7f0574b76070 0x99256ecbbe0 
[1:1:0712/222127.165663:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222127.166415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
			if (i > 3)
				clearInterval(t);
			i++;
			$("html,body").trigger("scroll");
		}
[1:1:0712/222127.166589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222127.190499:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222127.190807:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222127.191483:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 715
[1:1:0712/222127.191747:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f0574b76070 0x99256f16b60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 630 0x7f0574b76070 0x99256ecbbe0 
[1:1:0712/222127.229053:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222127.229276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222127.229865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 716
[1:1:0712/222127.230060:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 716 0x7f0574b76070 0x99257455fe0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 630 0x7f0574b76070 0x99256ecbbe0 
[1:1:0712/222127.234343:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222127.234510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222127.235100:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 718
[1:1:0712/222127.235294:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 718 0x7f0574b76070 0x992573f7de0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 630 0x7f0574b76070 0x99256ecbbe0 
[1:1:0712/222127.667158:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222127.668040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , image.onload, (){}
[1:1:0712/222127.668229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222127.818537:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 718, 7f05774bb881
[1:1:0712/222127.853670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"630 0x7f0574b76070 0x99256ecbbe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222127.854087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"630 0x7f0574b76070 0x99256ecbbe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222127.854524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222127.855450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
				clearTimeout(timer);
				timer = null;
				_self.apply(_me, args);
			}
[1:1:0712/222127.855673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222127.866626:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 714, 7f05774bb8db
[1:1:0712/222127.888168:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"630 0x7f0574b76070 0x99256ecbbe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222127.888443:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"630 0x7f0574b76070 0x99256ecbbe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222127.888831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 745
[1:1:0712/222127.889044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f0574b76070 0x99256b3e3e0 , 5:3_https://www.huawei.com/, 0, , 714 0x7f0574b76070 0x992558ec9e0 
[1:1:0712/222127.889323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222127.890020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
			if (i > 3)
				clearInterval(t);
			i++;
			$("html,body").trigger("scroll");
		}
[1:1:0712/222127.890196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222127.903642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222127.903841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222127.904382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 746
[1:1:0712/222127.904572:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 746 0x7f0574b76070 0x99257504160 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 714 0x7f0574b76070 0x992558ec9e0 
[1:1:0712/222127.908788:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222127.908974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222127.909491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 747
[1:1:0712/222127.909676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 747 0x7f0574b76070 0x992567c1c60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 714 0x7f0574b76070 0x992558ec9e0 
[1:1:0712/222127.923965:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222127.924152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222127.924667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 748
[1:1:0712/222127.924867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f0574b76070 0x99255c9fee0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 714 0x7f0574b76070 0x992558ec9e0 
[1:1:0712/222128.085925:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 737 0x7f0576a9e2e0 0x992574e1460 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222128.109530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (function(){var h={},mt={},c={id:"48e5a2ca327922f1ee2bb5ea69bdd0a6",dm:["huawei.com"],js:"tongji.bai
[1:1:0712/222128.109777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222128.138435:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b990
[1:1:0712/222128.138663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222128.139228:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 762
[1:1:0712/222128.139420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 762 0x7f0574b76070 0x9925757e0e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 737 0x7f0576a9e2e0 0x992574e1460 
[1:1:0712/222128.198846:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222128.199551:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/222128.354970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738 0x7f0576a9e2e0 0x99256ee2c60 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222128.367285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (function(){var aa="function"==typeof Object.defineProperties?Object.defineProperty:function(a,b,d){
[1:1:0712/222128.367484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222128.383212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222128.608378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 742 0x7f0576a9e2e0 0x99255c3a3e0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222128.618362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (function(){var TagSettings;
TagSettings=function(){function d(a){this.context=a;this.data={};this._
[1:1:0712/222128.618634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222128.913462:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 747, 7f05774bb881
[1:1:0712/222128.943019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"714 0x7f0574b76070 0x992558ec9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222128.943342:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"714 0x7f0574b76070 0x992558ec9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222128.943693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222128.944412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
				clearTimeout(timer);
				timer = null;
				_self.apply(_me, args);
			}
[1:1:0712/222128.944586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222128.955512:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 745, 7f05774bb8db
[1:1:0712/222128.985541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"714 0x7f0574b76070 0x992558ec9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222128.985904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"714 0x7f0574b76070 0x992558ec9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222128.986449:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 808
[1:1:0712/222128.986655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7f0574b76070 0x99257683260 , 5:3_https://www.huawei.com/, 0, , 745 0x7f0574b76070 0x99256b3e3e0 
[1:1:0712/222128.986933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222128.987633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
			if (i > 3)
				clearInterval(t);
			i++;
			$("html,body").trigger("scroll");
		}
[1:1:0712/222128.987806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222129.000532:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222129.000702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222129.001233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 809
[1:1:0712/222129.001428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f0574b76070 0x99257674c60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 745 0x7f0574b76070 0x99256b3e3e0 
[1:1:0712/222129.005555:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222129.005714:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222129.006310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 810
[1:1:0712/222129.006500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 810 0x7f0574b76070 0x99256541660 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 745 0x7f0574b76070 0x99256b3e3e0 
[1:1:0712/222129.019361:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222129.019523:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222129.020020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 811
[1:1:0712/222129.020220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7f0574b76070 0x99256f16060 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 745 0x7f0574b76070 0x99256b3e3e0 
[1:1:0712/222129.840502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 762, 7f05774bb881
[1:1:0712/222129.870682:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"737 0x7f0576a9e2e0 0x992574e1460 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222129.870995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"737 0x7f0576a9e2e0 0x992574e1460 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222129.871356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222129.872084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222129.872257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222129.873188:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222129.873352:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222129.873910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 831
[1:1:0712/222129.874098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7f0574b76070 0x992558ec2e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 762 0x7f0574b76070 0x9925757e0e0 
[1:1:0712/222130.243859:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 808, 7f05774bb8db
[1:1:0712/222130.253674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"745 0x7f0574b76070 0x99256b3e3e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222130.253818:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"745 0x7f0574b76070 0x99256b3e3e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222130.254013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 853
[1:1:0712/222130.254120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 853 0x7f0574b76070 0x99256edbfe0 , 5:3_https://www.huawei.com/, 0, , 808 0x7f0574b76070 0x99257683260 
[1:1:0712/222130.254265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.254635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
			if (i > 3)
				clearInterval(t);
			i++;
			$("html,body").trigger("scroll");
		}
[1:1:0712/222130.254745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222130.266233:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222130.266406:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222130.266961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 854
[1:1:0712/222130.267154:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 854 0x7f0574b76070 0x99256a7cee0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 808 0x7f0574b76070 0x99257683260 
[1:1:0712/222130.283123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222130.283295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222130.283829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 855
[1:1:0712/222130.284018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 855 0x7f0574b76070 0x992556fd2e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 808 0x7f0574b76070 0x99257683260 
[1:1:0712/222130.293245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 810, 7f05774bb881
[1:1:0712/222130.321177:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"745 0x7f0574b76070 0x99256b3e3e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222130.321349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"745 0x7f0574b76070 0x99256b3e3e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222130.321614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.322049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
				clearTimeout(timer);
				timer = null;
				_self.apply(_me, args);
			}
[1:1:0712/222130.322156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222130.433013:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.433889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/222130.434068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222130.441876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 831, 7f05774bb881
[1:1:0712/222130.472719:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"762 0x7f0574b76070 0x9925757e0e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222130.472993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"762 0x7f0574b76070 0x9925757e0e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222130.473353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.474095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222130.474282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222130.475140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222130.475298:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222130.475829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 860
[1:1:0712/222130.476026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 860 0x7f0574b76070 0x992574e1ce0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 831 0x7f0574b76070 0x992558ec2e0 
[1:1:0712/222130.604065:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 842 0x7f0576a9e2e0 0x99255f4c760 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.613755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.35 ut4.0.201907030949, Copyright 2019 Tealium.com Inc. All Rights Res
[1:1:0712/222130.613969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222130.791495:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.793239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.858306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 843 0x7f0576a9e2e0 0x99257674960 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222130.865916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //tealium universal tag - utag.9 ut4.0.201904250817, Copyright 2019 Tealium.com Inc. All Rights Rese
[1:1:0712/222130.866114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222131.278597:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x12ac85b829c8, 0x9925515b948
[1:1:0712/222131.278798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 5000
[1:1:0712/222131.279032:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 884
[1:1:0712/222131.279144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f0574b76070 0x99255bfd760 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 843 0x7f0576a9e2e0 0x99257674960 
[1:1:0712/222131.472009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 844 0x7f0576a9e2e0 0x992573f7e60 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222131.473088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , window['google_noFurtherRedirects'] = true;
[1:1:0712/222131.473268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222131.474144:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222131.729274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 853, 7f05774bb8db
[1:1:0712/222131.755323:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"808 0x7f0574b76070 0x99257683260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222131.755581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"808 0x7f0574b76070 0x99257683260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222131.755975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.huawei.com/, 895
[1:1:0712/222131.756168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7f0574b76070 0x992562938e0 , 5:3_https://www.huawei.com/, 0, , 853 0x7f0574b76070 0x99256edbfe0 
[1:1:0712/222131.756412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222131.757122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
			if (i > 3)
				clearInterval(t);
			i++;
			$("html,body").trigger("scroll");
		}
[1:1:0712/222131.757318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222131.770363:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222131.770529:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222131.771082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 896
[1:1:0712/222131.771217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7f0574b76070 0x99256edb4e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 853 0x7f0574b76070 0x99256edbfe0 
[1:1:0712/222131.772990:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222131.773096:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222131.773293:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 897
[1:1:0712/222131.773416:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 897 0x7f0574b76070 0x99256924fe0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 853 0x7f0574b76070 0x99256edbfe0 
[1:1:0712/222131.783332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222131.783538:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1500
[1:1:0712/222131.784232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 898
[1:1:0712/222131.784478:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 898 0x7f0574b76070 0x992573f7a60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 853 0x7f0574b76070 0x99256edbfe0 
[1:1:0712/222132.006429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 860, 7f05774bb881
[1:1:0712/222132.038267:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"831 0x7f0574b76070 0x992558ec2e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222132.038543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"831 0x7f0574b76070 0x992558ec2e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222132.038900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.039666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222132.039841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222132.040675:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222132.040831:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222132.041371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 909
[1:1:0712/222132.041560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7f0574b76070 0x99256b43160 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 860 0x7f0574b76070 0x992574e1ce0 
[1:1:0712/222132.623914:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.624366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){if(xhr.readyState===3){try{u.region=xhr.getResponseHeader("X-Region")||u.region||"";}catch(res_er
[1:1:0712/222132.624479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222132.624798:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.625500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.660342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.663526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.665259:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x12ac85b829c8, 0x9925515ba10
[1:1:0712/222132.665421:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1
[1:1:0712/222132.665924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 938
[1:1:0712/222132.666161:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7f0574b76070 0x99256ecb860 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 899
[1:1:0712/222132.666635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1001, 0x12ac85b829c8, 0x9925515ba10
[1:1:0712/222132.666787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 1001
[1:1:0712/222132.667304:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 939
[1:1:0712/222132.667488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 939 0x7f0574b76070 0x99256f16360 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 899
[1:1:0712/222132.667828:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.669179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadend", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.671600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x12ac85b829c8, 0x9925515bb00
[1:1:0712/222132.671766:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 4000
[1:1:0712/222132.672312:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 940
[1:1:0712/222132.672500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 940 0x7f0574b76070 0x99257504060 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 899
[1:1:0712/222132.746623:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 897, 7f05774bb881
[1:1:0712/222132.779344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"853 0x7f0574b76070 0x99256edbfe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222132.779615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"853 0x7f0574b76070 0x99256edbfe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222132.779966:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.780663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , () {
				clearTimeout(timer);
				timer = null;
				_self.apply(_me, args);
			}
[1:1:0712/222132.780845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222132.911334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 909, 7f05774bb881
[1:1:0712/222132.944629:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"860 0x7f0574b76070 0x992574e1ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222132.944912:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"860 0x7f0574b76070 0x992574e1ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222132.945264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222132.946014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222132.946251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222132.947068:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222132.947242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222132.947759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 951
[1:1:0712/222132.947945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f0574b76070 0x9925776af60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 909 0x7f0574b76070 0x99256b43160 
[1:1:0712/222133.087776:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 931 0x7f0576a9e2e0 0x9925638a360 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.088762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , //
[1:1:0712/222133.088939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.157052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 932 0x7f0576a9e2e0 0x992551cd860 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.158026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , 
[1:1:0712/222133.158209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.398391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 938, 7f05774bb881
[1:1:0712/222133.431556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"899","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.431805:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"899","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.432124:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.432826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){u.visitor_service_request((new Date).getTime(),server)}
[1:1:0712/222133.433000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.582953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 951, 7f05774bb881
[1:1:0712/222133.594007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"909 0x7f0574b76070 0x99256b43160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.594172:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"909 0x7f0574b76070 0x99256b43160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.594399:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.595141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222133.595252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.595628:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222133.595727:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222133.595935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 970
[1:1:0712/222133.596043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 970 0x7f0574b76070 0x99257686c60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 951 0x7f0574b76070 0x9925776af60 
[1:1:0712/222133.611315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 898, 7f05774bb881
[1:1:0712/222133.621106:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"853 0x7f0574b76070 0x99256edbfe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.621238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"853 0x7f0574b76070 0x99256edbfe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.621419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.621720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){c=0,O()}
[1:1:0712/222133.621819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.660007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.660433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , b.onload.b.wa, (){b.Sa&&(a.na=Date.now()-b.Sa);a.gb(c);b.Fa();a.Bb();a.ha();a.q=0;a.X();if(b.Da){b.Da=!1;try{a.doPo
[1:1:0712/222133.660540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.690660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 939, 7f05774bb881
[1:1:0712/222133.716233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"899","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.716509:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"899","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.716825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.717531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , (){u.visitor_service_request((new Date).getTime(),server)}
[1:1:0712/222133.717699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.727171:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 970, 7f05774bb881
[1:1:0712/222133.754243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"951 0x7f0574b76070 0x9925776af60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.754482:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"951 0x7f0574b76070 0x9925776af60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.754706:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.755053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222133.755157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.755541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222133.755649:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222133.755865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 983
[1:1:0712/222133.755971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f0574b76070 0x992576745e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 970 0x7f0574b76070 0x99257686c60 
[1:1:0712/222133.859021:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 983, 7f05774bb881
[1:1:0712/222133.893599:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"970 0x7f0574b76070 0x99257686c60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.893891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"970 0x7f0574b76070 0x99257686c60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222133.894230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222133.894984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222133.895158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222133.896000:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222133.896156:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222133.896726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 990
[1:1:0712/222133.896916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 990 0x7f0574b76070 0x99257683260 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 983 0x7f0574b76070 0x992576745e0 
[1:1:0712/222134.080510:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 997 0x7f0576a9e2e0 0x99256ee2be0 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.081367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , utag.ut["writevamain"]({});
[1:1:0712/222134.081576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.099794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7f0576a9e2e0 0x9925744e860 , "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.100819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , , utag.ut["writevamain"]({});
[1:1:0712/222134.101023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.113425:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 990, 7f05774bb881
[1:1:0712/222134.124082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"983 0x7f0574b76070 0x992576745e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.124247:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"983 0x7f0574b76070 0x992576745e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.124442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.124813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222134.124918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.125262:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222134.125358:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222134.125606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1006
[1:1:0712/222134.125721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1006 0x7f0574b76070 0x992573dda60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 990 0x7f0574b76070 0x99257683260 
[1:1:0712/222134.227437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1006, 7f05774bb881
[1:1:0712/222134.264851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"990 0x7f0574b76070 0x99257683260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.265167:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"990 0x7f0574b76070 0x99257683260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.265547:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.266265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222134.266438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.267312:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222134.267476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222134.268013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1010
[1:1:0712/222134.268203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7f0574b76070 0x992557161e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1006 0x7f0574b76070 0x992573dda60 
[1:1:0712/222134.422808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1010, 7f05774bb881
[1:1:0712/222134.447307:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1006 0x7f0574b76070 0x992573dda60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.447600:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1006 0x7f0574b76070 0x992573dda60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.447933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.448659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222134.448834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.449681:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222134.449838:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222134.450352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1018
[1:1:0712/222134.450537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1018 0x7f0574b76070 0x99256ee2a60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1010 0x7f0574b76070 0x992557161e0 
[1:1:0712/222134.555152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1018, 7f05774bb881
[1:1:0712/222134.590991:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1010 0x7f0574b76070 0x992557161e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.591319:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1010 0x7f0574b76070 0x992557161e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.591686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.592407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222134.592594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.597742:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222134.597907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222134.598434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1023
[1:1:0712/222134.598648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f0574b76070 0x9925669a9e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1018 0x7f0574b76070 0x99256ee2a60 
[1:1:0712/222134.707334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1023, 7f05774bb881
[1:1:0712/222134.742933:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1018 0x7f0574b76070 0x99256ee2a60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.743242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1018 0x7f0574b76070 0x99256ee2a60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.743589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.744312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222134.744484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.745323:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222134.745479:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222134.746026:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1029
[1:1:0712/222134.746217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f0574b76070 0x9925643d160 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1023 0x7f0574b76070 0x9925669a9e0 
[1:1:0712/222134.859072:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1029, 7f05774bb881
[1:1:0712/222134.894737:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1023 0x7f0574b76070 0x9925669a9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.895046:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1023 0x7f0574b76070 0x9925669a9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222134.895394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222134.896120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222134.896305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222134.897147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222134.897305:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222134.897846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1035
[1:1:0712/222134.898035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7f0574b76070 0x99256ee2c60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1029 0x7f0574b76070 0x9925643d160 
[1:1:0712/222135.101649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1035, 7f05774bb881
[1:1:0712/222135.138558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1029 0x7f0574b76070 0x9925643d160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.138881:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1029 0x7f0574b76070 0x9925643d160 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.139227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222135.139957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222135.140130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222135.141009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222135.141168:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222135.141686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1046
[1:1:0712/222135.141908:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f0574b76070 0x992553c8f60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1035 0x7f0574b76070 0x99256ee2c60 
[1:1:0712/222135.286039:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1046, 7f05774bb881
[1:1:0712/222135.324209:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1035 0x7f0574b76070 0x99256ee2c60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.324540:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1035 0x7f0574b76070 0x99256ee2c60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.324920:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222135.325628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222135.325818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222135.326641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222135.326841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222135.327365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1054
[1:1:0712/222135.327552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1054 0x7f0574b76070 0x99257683ce0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1046 0x7f0574b76070 0x992553c8f60 
[1:1:0712/222135.435019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1054, 7f05774bb881
[1:1:0712/222135.446363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1046 0x7f0574b76070 0x992553c8f60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.446530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1046 0x7f0574b76070 0x992553c8f60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.446723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222135.447117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222135.447230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222135.447575:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222135.447684:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222135.447961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1061
[1:1:0712/222135.448073:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1061 0x7f0574b76070 0x992552f6ce0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1054 0x7f0574b76070 0x99257683ce0 
[1:1:0712/222135.578704:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1061, 7f05774bb881
[1:1:0712/222135.590096:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1054 0x7f0574b76070 0x99257683ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.590261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1054 0x7f0574b76070 0x99257683ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.590451:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222135.590801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222135.590947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222135.591301:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222135.591402:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222135.591617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1065
[1:1:0712/222135.591725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1065 0x7f0574b76070 0x99256ecb5e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1061 0x7f0574b76070 0x992552f6ce0 
[1:1:0712/222135.729899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1065, 7f05774bb881
[1:1:0712/222135.764590:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1061 0x7f0574b76070 0x992552f6ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.764776:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1061 0x7f0574b76070 0x992552f6ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.765012:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222135.765373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222135.765478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222135.765855:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222135.765984:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222135.766201:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1067
[1:1:0712/222135.766315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1067 0x7f0574b76070 0x99257683e60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1065 0x7f0574b76070 0x99256ecb5e0 
[1:1:0712/222135.895883:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1067, 7f05774bb881
[1:1:0712/222135.908377:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1065 0x7f0574b76070 0x99256ecb5e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.908546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1065 0x7f0574b76070 0x99256ecb5e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222135.908739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222135.909118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222135.909227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222135.909573:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222135.909670:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222135.909884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1069
[1:1:0712/222135.910021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1069 0x7f0574b76070 0x99256a7c8e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1067 0x7f0574b76070 0x99257683e60 
[1:1:0712/222136.048386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1069, 7f05774bb881
[1:1:0712/222136.060100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1067 0x7f0574b76070 0x99257683e60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.060271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1067 0x7f0574b76070 0x99257683e60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.060464:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222136.060815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222136.060932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222136.061305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222136.061399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222136.061614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1071
[1:1:0712/222136.061728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1071 0x7f0574b76070 0x99256d20460 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1069 0x7f0574b76070 0x99256a7c8e0 
[1:1:0712/222136.247362:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1071, 7f05774bb881
[11348:11348:0712/222136.262961:INFO:CONSOLE(88)] "Error, missing Report Suite ID in AppMeasurement initialization", source: https://tags.tiqcdn.com/utag/huawei/main/prod/utag.9.js?utv=ut4.46.201904250817 (88)
[1:1:0712/222136.272205:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1069 0x7f0574b76070 0x99256a7c8e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.272586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1069 0x7f0574b76070 0x99256a7c8e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.273032:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222136.273921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222136.274137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222136.274526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222136.274631:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222136.274860:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1078
[1:1:0712/222136.274976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1078 0x7f0574b76070 0x99257674ae0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1071 0x7f0574b76070 0x99256d20460 
[1:1:0712/222136.654135:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1078, 7f05774bb881
[1:1:0712/222136.704253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1071 0x7f0574b76070 0x99256d20460 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.704664:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1071 0x7f0574b76070 0x99256d20460 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.705136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222136.706053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222136.706339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222136.707445:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222136.707660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222136.708352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1088
[1:1:0712/222136.708608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7f0574b76070 0x9925744e6e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1078 0x7f0574b76070 0x99257674ae0 
[1:1:0712/222136.854046:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 940, 7f05774bb881
[1:1:0712/222136.865516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"899","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.865705:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"899","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.865897:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222136.866477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , sendPerfQueue, (isContinue){try{perf_send_status="sending";var _qlen=perf_event_q.length;for(var i=0;i<_qlen;i++){_
[1:1:0712/222136.866673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222136.891013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1088, 7f05774bb881
[1:1:0712/222136.929526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1078 0x7f0574b76070 0x99257674ae0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.929881:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1078 0x7f0574b76070 0x99257674ae0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222136.930320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222136.931073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222136.931312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222136.932229:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222136.932443:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222136.933034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1094
[1:1:0712/222136.933336:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1094 0x7f0574b76070 0x99255655ce0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1088 0x7f0574b76070 0x9925744e6e0 
[1:1:0712/222137.072662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1094, 7f05774bb881
[1:1:0712/222137.111725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1088 0x7f0574b76070 0x9925744e6e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.112087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1088 0x7f0574b76070 0x9925744e6e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.112497:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222137.113263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222137.113471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222137.114380:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222137.114576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222137.115136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1096
[1:1:0712/222137.115361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7f0574b76070 0x99255795d60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1094 0x7f0574b76070 0x99255655ce0 
[1:1:0712/222137.254758:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1096, 7f05774bb881
[1:1:0712/222137.298884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1094 0x7f0574b76070 0x99255655ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.299280:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1094 0x7f0574b76070 0x99255655ce0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.299686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222137.300430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222137.300640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222137.301495:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222137.301703:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222137.302239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1099
[1:1:0712/222137.302502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7f0574b76070 0x992556f6ee0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1096 0x7f0574b76070 0x99255795d60 
[1:1:0712/222137.441415:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1099, 7f05774bb881
[1:1:0712/222137.482078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1096 0x7f0574b76070 0x99255795d60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.482518:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1096 0x7f0574b76070 0x99255795d60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.482947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222137.483760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222137.483984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222137.484892:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222137.485094:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222137.485679:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1101
[1:1:0712/222137.485918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7f0574b76070 0x9925744e7e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1099 0x7f0574b76070 0x992556f6ee0 
[1:1:0712/222137.625429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1101, 7f05774bb881
[1:1:0712/222137.673350:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1099 0x7f0574b76070 0x992556f6ee0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.673823:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1099 0x7f0574b76070 0x992556f6ee0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.674248:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222137.675099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222137.675494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222137.676587:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222137.676825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222137.677436:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1103
[1:1:0712/222137.677673:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7f0574b76070 0x9925757e8e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1101 0x7f0574b76070 0x9925744e7e0 
[1:1:0712/222137.827004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1103, 7f05774bb881
[1:1:0712/222137.866425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1101 0x7f0574b76070 0x9925744e7e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.866834:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1101 0x7f0574b76070 0x9925744e7e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222137.867242:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222137.868025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222137.868279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222137.869482:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222137.869714:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222137.870556:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1106
[1:1:0712/222137.870819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f0574b76070 0x992556182e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1103 0x7f0574b76070 0x9925757e8e0 
[1:1:0712/222138.012676:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1106, 7f05774bb881
[1:1:0712/222138.053932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1103 0x7f0574b76070 0x9925757e8e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.054373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1103 0x7f0574b76070 0x9925757e8e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.054802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222138.055625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222138.055879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222138.056829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222138.057048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222138.057658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1109
[1:1:0712/222138.057908:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7f0574b76070 0x99256ee2be0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1106 0x7f0574b76070 0x992556182e0 
[1:1:0712/222138.185657:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1109, 7f05774bb881
[1:1:0712/222138.227746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1106 0x7f0574b76070 0x992556182e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.228125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1106 0x7f0574b76070 0x992556182e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.228644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222138.229429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222138.229691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222138.230623:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222138.230839:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222138.231409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1111
[1:1:0712/222138.231660:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1111 0x7f0574b76070 0x99255618b60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1109 0x7f0574b76070 0x99256ee2be0 
[1:1:0712/222138.379947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1111, 7f05774bb881
[1:1:0712/222138.401994:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1109 0x7f0574b76070 0x99256ee2be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.402361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1109 0x7f0574b76070 0x99256ee2be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.402797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222138.403572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222138.403790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222138.404720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222138.404932:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222138.405501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1113
[1:1:0712/222138.405764:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1113 0x7f0574b76070 0x99256770760 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1111 0x7f0574b76070 0x99255618b60 
[1:1:0712/222138.544004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1113, 7f05774bb881
[1:1:0712/222138.590134:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1111 0x7f0574b76070 0x99255618b60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.590552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1111 0x7f0574b76070 0x99255618b60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.590987:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222138.591958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222138.592184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222138.593088:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222138.593304:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222138.593890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1115
[1:1:0712/222138.594174:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1115 0x7f0574b76070 0x992569345e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1113 0x7f0574b76070 0x99256770760 
[1:1:0712/222138.721962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1115, 7f05774bb881
[1:1:0712/222138.762776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1113 0x7f0574b76070 0x99256770760 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.763182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1113 0x7f0574b76070 0x99256770760 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.763608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222138.764567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222138.764852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222138.765778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222138.766018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222138.766819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1119
[1:1:0712/222138.767071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1119 0x7f0574b76070 0x99255700a60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1115 0x7f0574b76070 0x992569345e0 
[1:1:0712/222138.887724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1119, 7f05774bb881
[1:1:0712/222138.925171:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1115 0x7f0574b76070 0x992569345e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.925510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1115 0x7f0574b76070 0x992569345e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222138.925844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222138.926579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222138.926890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222138.927748:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222138.927953:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222138.928500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1121
[1:1:0712/222138.928744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1121 0x7f0574b76070 0x99255673a60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1119 0x7f0574b76070 0x99255700a60 
[1:1:0712/222139.067705:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1121, 7f05774bb881
[1:1:0712/222139.114633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1119 0x7f0574b76070 0x99255700a60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.114995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1119 0x7f0574b76070 0x99255700a60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.115371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222139.116107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222139.116314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222139.117168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222139.117358:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222139.117912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1123
[1:1:0712/222139.118200:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7f0574b76070 0x99255655be0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1121 0x7f0574b76070 0x99255673a60 
[1:1:0712/222139.263837:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1123, 7f05774bb881
[1:1:0712/222139.302996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1121 0x7f0574b76070 0x99255673a60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.303371:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1121 0x7f0574b76070 0x99255673a60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.303765:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222139.304570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222139.304822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222139.305682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222139.305902:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222139.306633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1126
[1:1:0712/222139.306884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1126 0x7f0574b76070 0x9925568f260 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1123 0x7f0574b76070 0x99255655be0 
[1:1:0712/222139.447631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1126, 7f05774bb881
[1:1:0712/222139.497031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1123 0x7f0574b76070 0x99255655be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.497435:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1123 0x7f0574b76070 0x99255655be0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.497856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222139.498607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222139.498898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222139.499764:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222139.500004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222139.500590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1128
[1:1:0712/222139.500819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1128 0x7f0574b76070 0x99255bdb9e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1126 0x7f0574b76070 0x9925568f260 
[1:1:0712/222139.640643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1128, 7f05774bb881
[1:1:0712/222139.677017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1126 0x7f0574b76070 0x9925568f260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.677388:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1126 0x7f0574b76070 0x9925568f260 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.677816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222139.678597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222139.678848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222139.679721:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222139.679940:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222139.680501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1131
[1:1:0712/222139.680724:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1131 0x7f0574b76070 0x99256ecbfe0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1128 0x7f0574b76070 0x99255bdb9e0 
[1:1:0712/222139.823061:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1131, 7f05774bb881
[1:1:0712/222139.864105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1128 0x7f0574b76070 0x99255bdb9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.864479:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1128 0x7f0574b76070 0x99255bdb9e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222139.864875:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222139.865664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222139.865877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222139.866803:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222139.867013:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222139.867592:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1133
[1:1:0712/222139.867830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1133 0x7f0574b76070 0x992558ecee0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1131 0x7f0574b76070 0x99256ecbfe0 
[1:1:0712/222140.019404:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1133, 7f05774bb881
[1:1:0712/222140.058649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1131 0x7f0574b76070 0x99256ecbfe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.059041:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1131 0x7f0574b76070 0x99256ecbfe0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.059439:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222140.060220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222140.060436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222140.061335:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222140.061529:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222140.062106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1135
[1:1:0712/222140.062374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1135 0x7f0574b76070 0x99255655e60 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1133 0x7f0574b76070 0x992558ecee0 
[1:1:0712/222140.203217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1135, 7f05774bb881
[1:1:0712/222140.241746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1133 0x7f0574b76070 0x992558ecee0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.242165:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1133 0x7f0574b76070 0x992558ecee0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.242571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222140.243340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222140.243554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222140.244433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222140.244626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222140.245202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1137
[1:1:0712/222140.245428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1137 0x7f0574b76070 0x9925776a4e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1135 0x7f0574b76070 0x99255655e60 
[1:1:0712/222140.403385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1137, 7f05774bb881
[1:1:0712/222140.461567:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1135 0x7f0574b76070 0x99255655e60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.461974:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1135 0x7f0574b76070 0x99255655e60 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.462533:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222140.463365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222140.463637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222140.464574:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222140.464829:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222140.465468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1139
[1:1:0712/222140.465705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1139 0x7f0574b76070 0x992556231e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1137 0x7f0574b76070 0x9925776a4e0 
[1:1:0712/222140.607942:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1139, 7f05774bb881
[1:1:0712/222140.645260:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1137 0x7f0574b76070 0x9925776a4e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.645716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1137 0x7f0574b76070 0x9925776a4e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.646308:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222140.647144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222140.647379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222140.648295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222140.648513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222140.649090:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1142
[1:1:0712/222140.649360:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1142 0x7f0574b76070 0x992576782e0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1139 0x7f0574b76070 0x992556231e0 
[1:1:0712/222140.788850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1142, 7f05774bb881
[1:1:0712/222140.832153:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1139 0x7f0574b76070 0x992556231e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.832673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1139 0x7f0574b76070 0x992556231e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222140.833234:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222140.834337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222140.834623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222140.835840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222140.836098:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222140.836896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1144
[1:1:0712/222140.837219:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1144 0x7f0574b76070 0x99255716de0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1142 0x7f0574b76070 0x992576782e0 
[1:1:0712/222140.983990:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1144, 7f05774bb881
[1:1:0712/222141.030288:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1142 0x7f0574b76070 0x992576782e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222141.030641:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1142 0x7f0574b76070 0x992576782e0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0712/222141.031029:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0712/222141.031802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/222141.032093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0712/222141.033428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0712/222141.033700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0712/222141.034600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1146
[1:1:0712/222141.034904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1146 0x7f0574b76070 0x992558e4be0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1144 0x7f0574b76070 0x99255716de0 
[1:1:0712/222141.175953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1146, 7f05774bb881
[1:1:0100/000000.223906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3aeb0fe02860","ptid":"1144 0x7f0574b76070 0x99255716de0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0100/000000.226815:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.huawei.com/","ptid":"1144 0x7f0574b76070 0x99255716de0 ","rf":"5:3_https://www.huawei.com/"}
[1:1:0100/000000.227155:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei"
[1:1:0100/000000.227903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.huawei.com/, 3aeb0fe02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0100/000000.228054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", "www.huawei.com", 3, 1, , , 0
[1:1:0100/000000.228862:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x12ac85b829c8, 0x9925515b950
[1:1:0100/000000.228964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.huawei.com/cn/my-huawei/login?redirect=https%3a%2f%2fwww.huawei.com%2fcn%2fmy-huawei", 100
[1:1:0100/000000.229456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.huawei.com/, 1175
[1:1:0100/000000.229597:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7f0574b76070 0x99255673de0 , 5:3_https://www.huawei.com/, 1, -5:3_https://www.huawei.com/, 1146 0x7f0574b76070 0x992558e4be0 
