[0712/043755.584474:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043755.584890:INFO:switcher_clone.cc(787)] backtrace rip is 7f02d51ec891
[0712/043756.593494:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043756.593819:INFO:switcher_clone.cc(787)] backtrace rip is 7fbaae827891
[1:1:0712/043756.597956:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/043756.598134:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/043756.603784:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/043757.869672:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043757.869930:INFO:switcher_clone.cc(787)] backtrace rip is 7fe4fa191891
[78129:78129:0712/043757.912098:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/3008fdd5-5074-4afe-b8aa-feb2d4003f18
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[78161:78161:0712/043758.104726:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=78161
[78173:78173:0712/043758.105150:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=78173
[78129:78129:0712/043758.384634:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[78129:78159:0712/043758.385443:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/043758.385654:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043758.385866:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043758.386581:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043758.386774:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/043758.390232:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1554de0b, 1
[1:1:0712/043758.390639:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xc63643e, 0
[1:1:0712/043758.390863:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1633e61e, 3
[1:1:0712/043758.391090:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2129b023, 2
[1:1:0712/043758.391405:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3e64630c 0bffffffde5415 23ffffffb02921 1effffffe63316 , 10104, 4
[1:1:0712/043758.392711:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[78129:78159:0712/043758.392992:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING>dc�T#�)!�3�B�?
[78129:78159:0712/043758.393073:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is >dc�T#�)!�3h��B�?
[1:1:0712/043758.392988:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbaaca620a0, 3
[1:1:0712/043758.393244:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbaacbed080, 2
[78129:78159:0712/043758.393407:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/043758.393398:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fba968b0d20, -2
[78129:78159:0712/043758.393488:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 78181, 4, 3e64630c 0bde5415 23b02921 1ee63316 
[1:1:0712/043758.412481:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043758.413383:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2129b023
[1:1:0712/043758.414357:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2129b023
[1:1:0712/043758.415948:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2129b023
[1:1:0712/043758.417520:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.417713:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.417892:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.418077:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.418728:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2129b023
[1:1:0712/043758.419048:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbaae8277ba
[1:1:0712/043758.419200:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbaae81edef, 7fbaae82777a, 7fbaae8290cf
[1:1:0712/043758.424864:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2129b023
[1:1:0712/043758.425234:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2129b023
[1:1:0712/043758.425976:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2129b023
[1:1:0712/043758.428023:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.428279:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.428517:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.428747:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2129b023
[1:1:0712/043758.430218:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2129b023
[1:1:0712/043758.430582:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbaae8277ba
[1:1:0712/043758.430713:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbaae81edef, 7fbaae82777a, 7fbaae8290cf
[1:1:0712/043758.438155:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043758.438599:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043758.438744:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff604b288, 0x7ffff604b208)
[1:1:0712/043758.453758:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043758.459341:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[78129:78129:0712/043759.089310:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[78129:78129:0712/043759.090710:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[78129:78140:0712/043759.103595:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[78129:78140:0712/043759.103700:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[78129:78129:0712/043759.103839:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[78129:78129:0712/043759.103917:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[78129:78129:0712/043759.104055:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,78181, 4
[1:7:0712/043759.105831:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[78129:78151:0712/043759.150826:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/043759.161911:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x147892118220
[1:1:0712/043759.162160:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/043759.526683:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[78129:78129:0712/043801.627309:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[78129:78129:0712/043801.627428:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043801.674463:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043801.683332:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043802.581173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2878bd7e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043802.581603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043802.611373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2878bd7e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043802.611917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043802.714250:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043803.053231:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043803.053459:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043803.481490:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043803.484782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2878bd7e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043803.484984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043803.500831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043803.504728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2878bd7e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043803.504877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043803.509400:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[78129:78129:0712/043803.511045:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043803.514850:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x147892116e20
[1:1:0712/043803.515093:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[78129:78129:0712/043803.528713:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[78129:78129:0712/043803.571781:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[78129:78129:0712/043803.571883:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043803.585656:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043804.441148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7fba9848b2e0 0x147891f3ce60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043804.442591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2878bd7e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/043804.444278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043804.446091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043804.527940:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x147892117820
[78129:78129:0712/043804.528178:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043804.528154:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[78129:78129:0712/043804.533918:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/043804.553544:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043804.553805:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[78129:78129:0712/043804.555035:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[78129:78129:0712/043804.568281:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[78129:78129:0712/043804.569816:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[78129:78140:0712/043804.577036:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[78129:78140:0712/043804.577133:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[78129:78129:0712/043804.577276:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[78129:78129:0712/043804.577357:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[78129:78129:0712/043804.577501:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,78181, 4
[1:7:0712/043804.586529:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043805.265899:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/043805.863996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7fba9848b2e0 0x14789241fbe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043805.865057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2878bd7e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/043805.865321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043805.866115:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[78129:78129:0712/043806.093119:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[78129:78129:0712/043806.093238:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/043806.130214:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[78129:78129:0712/043806.308679:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[78129:78159:0712/043806.309121:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/043806.309383:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043806.309707:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043806.310212:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043806.310448:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/043806.314093:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3884aa40, 1
[1:1:0712/043806.314503:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x170bbfb3, 0
[1:1:0712/043806.314700:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3c649d4f, 3
[1:1:0712/043806.314891:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ceaabe0, 2
[1:1:0712/043806.315068:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb3ffffffbf0b17 40ffffffaaffffff8438 ffffffe0ffffffabffffffea1c 4fffffff9d643c , 10104, 5
[1:1:0712/043806.315997:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[78129:78159:0712/043806.316159:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��@��8��O�d<=C�?
[78129:78159:0712/043806.316200:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��@��8��O�d<hi=C�?
[1:1:0712/043806.316281:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbaaca620a0, 3
[78129:78159:0712/043806.316476:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 78226, 5, b3bf0b17 40aa8438 e0abea1c 4f9d643c 
[1:1:0712/043806.316431:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbaacbed080, 2
[1:1:0712/043806.316581:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fba968b0d20, -2
[1:1:0712/043806.327163:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043806.327355:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ceaabe0
[1:1:0712/043806.327569:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ceaabe0
[1:1:0712/043806.327856:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ceaabe0
[1:1:0712/043806.328319:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.328476:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.328575:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.328668:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.328899:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ceaabe0
[1:1:0712/043806.329026:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbaae8277ba
[1:1:0712/043806.329110:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbaae81edef, 7fbaae82777a, 7fbaae8290cf
[1:1:0712/043806.330682:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ceaabe0
[1:1:0712/043806.330853:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ceaabe0
[1:1:0712/043806.331130:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ceaabe0
[1:1:0712/043806.331858:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.331978:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.332085:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.332179:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ceaabe0
[1:1:0712/043806.332746:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ceaabe0
[1:1:0712/043806.332915:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbaae8277ba
[1:1:0712/043806.332992:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbaae81edef, 7fbaae82777a, 7fbaae8290cf
[1:1:0712/043806.335319:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043806.335692:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043806.335787:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff604b288, 0x7ffff604b208)
[1:1:0712/043806.348518:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043806.353436:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/043806.556405:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1478920d3220
[1:1:0712/043806.556763:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/043806.601623:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043807.230266:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043807.230538:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[78129:78129:0712/043807.425186:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[78129:78129:0712/043807.463267:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[78129:78159:0712/043807.463794:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/043807.464044:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043807.464279:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043807.464768:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043807.464947:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/043807.468406:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2804b404, 1
[1:1:0712/043807.468873:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3ed090d2, 0
[1:1:0712/043807.469187:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xec160, 3
[1:1:0712/043807.469431:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x14859762, 2
[1:1:0712/043807.469658:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd2ffffff90ffffffd03e 04ffffffb40428 62ffffff97ffffff8514 60ffffffc10e00 , 10104, 6
[1:1:0712/043807.471070:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[78129:78159:0712/043807.471394:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGҐ�>�(b��`�
[78129:78159:0712/043807.471486:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ґ�>�(b��`�
[1:1:0712/043807.471624:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbaaca620a0, 3
[78129:78159:0712/043807.471855:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 78244, 6, d290d03e 04b40428 62978514 60c10e00 
[1:1:0712/043807.471945:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbaacbed080, 2
[1:1:0712/043807.472145:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fba968b0d20, -2
[1:1:0712/043807.490141:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043807.490452:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14859762
[1:1:0712/043807.490717:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14859762
[1:1:0712/043807.491298:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14859762
[1:1:0712/043807.492738:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.492958:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.493155:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.493332:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.494008:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14859762
[1:1:0712/043807.494298:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbaae8277ba
[1:1:0712/043807.494431:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbaae81edef, 7fbaae82777a, 7fbaae8290cf
[78129:78129:0712/043807.494535:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043807.499979:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14859762
[1:1:0712/043807.500199:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14859762
[1:1:0712/043807.500487:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14859762
[1:1:0712/043807.501235:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.501358:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.501455:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.501549:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14859762
[1:1:0712/043807.502652:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14859762
[1:1:0712/043807.503057:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbaae8277ba
[1:1:0712/043807.503192:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbaae81edef, 7fbaae82777a, 7fbaae8290cf
[78129:78140:0712/043807.506473:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[78129:78129:0712/043807.506647:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.bubukua.com/
[78129:78129:0712/043807.506685:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.bubukua.com/, https://www.bubukua.com/, 1
[78129:78129:0712/043807.506781:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.bubukua.com/, HTTP/1.1 200 OK Server: nginx-upupw/1.8.0 Date: Fri, 12 Jul 2019 11:38:08 GMT Content-Type: text/html Last-Modified: Fri, 12 Jul 2019 02:40:23 GMT Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding ETag: W/"5d27f317-a861" Content-Encoding: gzip  ,0, 6
[78129:78140:0712/043807.506562:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[3:3:0712/043807.509336:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043807.510985:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043807.511504:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043807.511662:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff604b288, 0x7ffff604b208)
[1:1:0712/043807.524411:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043807.528690:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/043807.598179:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043807.639917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 566, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043807.644507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2878bd9109f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/043807.644836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043807.653415:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043807.784395:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1478920f0220
[1:1:0712/043807.784721:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/043807.888490:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.bubukua.com/
[78129:78129:0712/043808.200084:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.bubukua.com/, https://www.bubukua.com/, 1
[78129:78129:0712/043808.200220:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.bubukua.com/, https://www.bubukua.com
[1:1:0712/043808.248994:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043808.403520:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043808.408422:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043808.409181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2878bd7e1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/043808.409441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043808.582479:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043808.582818:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bubukua.com/"
[1:1:0712/043808.742019:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.159018, 73, 1
[1:1:0712/043808.742304:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043809.520526:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043809.520782:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bubukua.com/"
[1:1:0712/043810.583401:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7fba96563070 0x1478923291e0 , "https://www.bubukua.com/"
[1:1:0712/043810.585452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.writeln("<script type=\'text/javascript\' src=\'//h11.xinkuaiyu.com/common/resource/drd5r.j
[1:1:0712/043810.585681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043811.427700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 330, "https://www.bubukua.com/"
[1:1:0712/043811.429086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0712/043811.429210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043811.430938:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043815.920437:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043815.920925:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043815.921393:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043815.921816:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043815.922234:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[78129:78129:0712/043827.638890:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://h11.xinkuaiyu.com/common/resource/drd5r.js?e=zriavfyw, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.bubukua.com/css/hj300250.js (1)
[78129:78129:0712/043827.642757:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://h11.xinkuaiyu.com/common/resource/drd5r.js?e=zriavfyw, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.bubukua.com/css/hj300250.js (1)
[78129:78129:0712/043827.708789:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/043827.724986:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043828.053130:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043828.126473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/043828.126779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043828.570616:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043828.823061:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 383 0x7fba9848b2e0 0x1478921e6b60 , "https://www.bubukua.com/"
[1:1:0712/043828.833840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , try{!function(t){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_ds_||(win
[1:1:0712/043828.834003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
		remove user.10_b8164c3a -> 0
[1:1:0712/043829.835994:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[78129:78129:0712/043829.837873:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043829.839785:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x147892891a20
[1:1:0712/043829.840089:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[78129:78129:0712/043829.842470:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/043829.868505:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043829.868765:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.bubukua.com
[78129:78129:0712/043829.870392:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://www.bubukua.com/
[1:1:0712/043829.893101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7fba9848b2e0 0x1478922dd9e0 , "https://www.bubukua.com/"
[1:1:0712/043829.894123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , window.__baidu_dup_jobruner = {};
try {
    var storage = window.localStorage;
    if (storage &&
[1:1:0712/043829.894342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043829.895802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bubukua.com/"
[1:1:0712/043829.998088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043829.998436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043830.016053:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043830.016207:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bubukua.com/"
[78129:78129:0712/043830.098767:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[78129:78129:0712/043830.107397:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[78129:78140:0712/043830.146834:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[78129:78140:0712/043830.146933:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[78129:78129:0712/043830.147232:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[78129:78129:0712/043830.147334:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://pos.baidu.com/, https://pos.baidu.com/s?hei=250&wid=300&di=u3174065&ltu=https%3A%2F%2Fwww.bubukua.com%2F&psi=bfdb9113221382fad0eadfa6ec6922e2&tpr=1562931509552&dis=0&dai=1&exps=111000,117008,110011&ant=0&tlm=1562899223&cmi=2&ps=76x790&pss=1090x409&ti=%E9%83%A8%E9%83%A8%E5%A4%B8%20-%20%E9%9F%A9%E5%89%A7%E8%B5%84%E8%AE%AF%E7%BD%91%E7%AB%99&col=en-US&prot=2&cfv=0&cja=false&cpl=2&tcn=1562931510&dri=0&chi=2&par=1211x623&cdo=-1&psr=1276x647&ccd=24&cec=UTF-8&ari=2&dc=3&drs=1&pcs=1040x409&cce=true&pis=-1x-1&dtm=HTML_POST, 4
[78129:78129:0712/043830.147534:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 2568 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 11:38:30 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 19:38:30 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,78244, 6
[1:7:0712/043830.152232:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043830.156363:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.140205, 1078, 1
[1:1:0712/043830.156588:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043832.293719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043832.293908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043833.502326:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://pos.baidu.com/
[1:1:0712/043833.531959:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043833.532112:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bubukua.com/"
[1:1:0712/043833.533401:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 490 0x7fba96563070 0x147892c162e0 , "https://www.bubukua.com/"
[1:1:0712/043833.534217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.w
[1:1:0712/043833.534366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[78129:78129:0712/043833.542771:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s19.cnzz.com/stat.php?id=5928337, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.bubukua.com/css/tongji.js (1)
[78129:78129:0712/043833.549372:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s19.cnzz.com/stat.php?id=5928337, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.bubukua.com/css/tongji.js (1)
[1:1:0712/043833.793575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043833.793777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043834.119284:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[78129:78129:0712/043834.129618:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://pos.baidu.com/, https://pos.baidu.com/, 4
[78129:78129:0712/043834.129707:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0712/043834.403488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531, "https://www.bubukua.com/"
[1:1:0712/043834.411677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , (function(){function p(){this.c="5928337";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629303
[1:1:0712/043834.411937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[78129:78129:0712/043834.553413:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=5928337&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s19.cnzz.com/stat.php?id=5928337 (17)
[78129:78129:0712/043834.561678:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=5928337&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s19.cnzz.com/stat.php?id=5928337 (17)
[1:1:0712/043834.597714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043834.597884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043834.638003:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043835.396946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7fba9848b2e0 0x147892cefce0 , "https://www.bubukua.com/"
[1:1:0712/043835.406120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , (function(){var h={},mt={},c={id:"2357c95cc40d89dcbb7a92c6de659197",dm:["bubukua.com"],js:"tongji.ba
[1:1:0712/043835.406349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043835.431515:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e940
[1:1:0712/043835.431677:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043835.431857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 600
[1:1:0712/043835.431967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7fba96563070 0x1478921f26e0 , 6:3_https://www.bubukua.com/, 1, -6:3_https://www.bubukua.com/, 577 0x7fba9848b2e0 0x147892cefce0 
[1:1:0712/043835.637300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043835.637619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043835.668261:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043835.668553:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/s?hei=250&wid=300&di=u3174065&ltu=https%3A%2F%2Fwww.bubukua.com%2F&psi=bfdb9113221382fad0eadfa6ec6922e2&tpr=1562931509552&dis=0&dai=1&exps=111000,117008,110011&ant=0&tlm=1562899223&cmi=2&ps=76x790&pss=1090x409&ti=%E9%83%A8%E9%83%A8%E5%A4%B8%20-%20%E9%9F%A9%E5%89%A7%E8%B5%84%E8%AE%AF%E7%BD%91%E7%AB%99&col=en-US&prot=2&cfv=0&cja=false&cpl=2&tcn=1562931510&dri=0&chi=2&par=1211x623&cdo=-1&psr=1276x647&ccd=24&cec=UTF-8&ari=2&dc=3&drs=1&pcs=1040x409&cce=true&pis=-1x-1&dtm=HTML_POST"
[1:1:0712/043835.680265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 580 0x7fba96563070 0x147892c81c60 , "https://pos.baidu.com/s?hei=250&wid=300&di=u3174065&ltu=https%3A%2F%2Fwww.bubukua.com%2F&psi=bfdb9113221382fad0eadfa6ec6922e2&tpr=1562931509552&dis=0&dai=1&exps=111000,117008,110011&ant=0&tlm=1562899223&cmi=2&ps=76x790&pss=1090x409&ti=%E9%83%A8%E9%83%A8%E5%A4%B8%20-%20%E9%9F%A9%E5%89%A7%E8%B5%84%E8%AE%AF%E7%BD%91%E7%AB%99&col=en-US&prot=2&cfv=0&cja=false&cpl=2&tcn=1562931510&dri=0&chi=2&par=1211x623&cdo=-1&psr=1276x647&ccd=24&cec=UTF-8&ari=2&dc=3&drs=1&pcs=1040x409&cce=true&pis=-1x-1&dtm=HTML_POST"
[1:1:0712/043835.719394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://pos.baidu.com/, 334ebebcc1e0, , ,  
try{window.postMessage && window.parent && window.parent.postMessage(
{
"queryid" : "0b6af3b09f8d8
[1:1:0712/043835.719767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/s?hei=250&wid=300&di=u3174065&ltu=https%3A%2F%2Fwww.bubukua.com%2F&psi=bfdb9113221382fad0eadfa6ec6922e2&tpr=1562931509552&dis=0&dai=1&exps=111000,117008,110011&ant=0&tlm=1562899223&cmi=2&ps=76x790&pss=1090x409&ti=%E9%83%A8%E9%83%A8%E5%A4%B8%20-%20%E9%9F%A9%E5%89%A7%E8%B5%84%E8%AE%AF%E7%BD%91%E7%AB%99&col=en-US&prot=2&cfv=0&cja=false&cpl=2&tcn=1562931510&dri=0&chi=2&par=1211x623&cdo=-1&psr=1276x647&ccd=24&cec=UTF-8&ari=2&dc=3&drs=1&pcs=1040x409&cce=true&pis=-1x-1&dtm=HTML_POST", "pos.baidu.com", 4, 1, https://www.bubukua.com, www.bubukua.com, 3
[1:1:0712/043835.734036:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[78129:78129:0712/043835.758291:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043835.762512:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x147892d7fe20
[1:1:0712/043835.762769:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[78129:78129:0712/043835.764988:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/043835.788321:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043835.788604:INFO:render_frame_impl.cc(7019)] 	 [url] = https://pos.baidu.com
[1:1:0712/043835.791933:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[78129:78129:0712/043835.793672:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:4_https://pos.baidu.com/
[1:1:0712/043835.796750:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x1478920ef820
[1:1:0712/043835.796947:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0712/043835.804422:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043835.804584:INFO:render_frame_impl.cc(7019)] 	 [url] = https://pos.baidu.com
[1:1:0712/043835.805308:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[78129:78129:0712/043835.809313:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043835.815250:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x147891e02820
[1:1:0712/043835.815416:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[78129:78129:0712/043835.815960:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/043835.832922:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043835.833171:INFO:render_frame_impl.cc(7019)] 	 [url] = https://pos.baidu.com
[78129:78129:0712/043835.833609:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:4_https://pos.baidu.com/
[78129:78129:0712/043835.848970:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[78129:78129:0712/043835.855609:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[78129:78129:0712/043835.859940:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:4_https://pos.baidu.com/
[1:1:0712/043835.861062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581, "https://www.bubukua.com/"
[1:1:0712/043835.861937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043835.862081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043835.866301:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.bubukua.com/"
[1:1:0712/043835.869834:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.bubukua.com/"
[78129:78129:0712/043835.958505:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[78129:78129:0712/043835.965326:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[78129:78140:0712/043835.996105:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 5
[78129:78140:0712/043835.996200:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 5, HandleIncomingMessage, HandleIncomingMessage
[78129:78129:0712/043835.996365:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://vt.ipinyou.com/
[78129:78129:0712/043835.996443:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://vt.ipinyou.com/, https://vt.ipinyou.com/Ii6LtP66QNTYXOBVZVld.Pt_sY_.IkdTZAzxPekyGVCztDLhvaF-ulxU-HvmYhBd-JR5Y8xv7Q9Qy_T82RdR6ol9ttsa7Qa4r_XAQ6Fo3o2fJhLzQDxygNFyYIssvOxi4AjqIqxTrmbq4gnJID9ehy2cOQKG6g1FZ5puGq2IXoC9lgjnUruR-eFIJoRLUO834rmn0vft7dmV8SfX6Ds3ZqKQOoCS6gFwZ5lSOia620NTNJcbM3Qll3nQqYLUIH-eFtEbBXmFo0E66fr4Y--eyL3QI16Ahb6DeyTvQQ5YwmB8aFKYUpazg6kZJZRdg3agNjrJjnIWzY9M6r8U9FmUPxmgDsMUl19rTudEMkgBjOqsvDlHqKd4mojiEYqAxAKCWSqnsqlsezA6Jdu1Tvp3d9Tl1sMBkmyhTx1uM5K9JmdbaKq9cKdX17pYyDaqbFxvrwp084FISG7UYdxOfSewicDZfIuMDE9SQumjQqNNpU7mQKbversxo21Trsp8r1KKM_VAU8blrZ5dAjNq66zYzNpldYKMk1CICsujGNK4Ms5SaFsSupFIY9N87MmsSDmP4xu5s993ioBaHSpJ6Aa.k3RyY_LSaYuLwH7NOJdBC_?eup=http%3A%2F%2Fclick%2Ebes%2Ebaidu%2Ecom%2Fadx%2Ephp%3Fc%3Dcz0zZjg1OGQ5ZmIwZjM2YTBiAHQ9MTU2MjkzMTUwOQBzZT0xAGJ1PTY0MTgwNDEAdHU9dTMxNzQwNjUAYWQ9MTU1ODYxMDQ2ODA4MQBzaXRlPWh0dHBzOi8vd3d3LmJ1YnVrdWEuY29tLwB2PTEAaT1iNzA5YWMwMg%26k%3Ddz0zMDAAaD0yNTAAY3NpZD0xMDczNzQxODI0MzAwAHRtPTI3NTAzODA3NwB0ZD0zMTc0MDY1AHdpPTY0MTgwNDEAZm49NjkwMzkwMTlfY3ByAGZhbj0AdWlkPTIyODE0NzU5AGNoPTAAb3M9NwBicj0xMgBpcD0yMTguMjQxLjEzNS4zNABzc3A9MQBhcHBfaWQ9AGFwcF9zaWQ9AHNka192ZXJzaW9uPQB0dHA9MQBjb21wbGU9MABzdHlwZT0wAGNobWQ9MABzY2htZD0wAHhpcD0AZHRwPTEAY21hdGNoPTIwMABmaXJzdF9yZWdpb249MQBzZWNvbmRfcmVnaW9uPTM4NQBiYnQ9MQBhYnQ9MQBudHRwPTEAYm1sPTAAYWRjbGFzcz0w%26url%3D, 5
[78129:78129:0712/043835.996641:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:5_https://vt.ipinyou.com/, HTTP/1.1 200 OK Server: nginx/1.10.2 Date: Fri, 12 Jul 2019 11:38:35 GMT Content-Type: text/html;charset=utf-8 Content-Length: 1922 Connection: keep-alive Cache-Control: no-store Pragma: no-cache Expires: Thu, 01 Jan 1970 00:00:00 GMT P3P: CP="NON DSP COR CURa ADMa DEVa TAIa PSAa PSDa IVAa IVDa CONa HISa TELa OTPa OUR UNRa IND UNI COM NAV INT DEM CNT PRE LOC" Set-Cookie: sessionId=J7CJbZEO0003Yf; Domain=.ipinyou.com; Path=/  ,78244, 6
[1:7:0712/043836.000960:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[78129:78129:0712/043836.365656:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[78129:78129:0712/043836.371484:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[78129:78140:0712/043836.387155:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 7
[78129:78140:0712/043836.387208:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 7, HandleIncomingMessage, HandleIncomingMessage
[78129:78129:0712/043836.388251:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://ad.doubleclick.net/
[78129:78129:0712/043836.388333:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:7_https://ad.doubleclick.net/, https://ad.doubleclick.net/ddm/trackimp/N5983.3004866IPINYOU/B22613829.247579518;dc_pre=CIzD0s6lr-MCFRiKwgodf_oGrw;dc_trk_aid=443681922;dc_trk_cid=115523332;ord=15629315099683593;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;tfua=?, 7
[78129:78129:0712/043836.388473:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:7_https://ad.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* date:Fri, 12 Jul 2019 11:38:36 GMT pragma:no-cache expires:Fri, 01 Jan 1990 00:00:00 GMT cache-control:no-cache, must-revalidate content-type:image/gif x-content-type-options:nosniff server:cafe content-length:42 x-xss-protection:0 alt-svc:quic=":443"; ma=2592000; v="46,43,39"  ,78244, 6
[1:7:0712/043836.398160:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043836.430270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 600, 7fba98ea8881
[1:1:0712/043836.459815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"577 0x7fba9848b2e0 0x147892cefce0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043836.460123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"577 0x7fba9848b2e0 0x147892cefce0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043836.460497:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043836.461077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043836.461280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043836.462040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043836.462199:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043836.462514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 707
[1:1:0712/043836.462699:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7fba96563070 0x147892c6c2e0 , 6:3_https://www.bubukua.com/, 1, -6:3_https://www.bubukua.com/, 600 0x7fba96563070 0x1478921f26e0 
[1:1:0712/043836.611410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043836.611579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043836.678185:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.bubukua.com/"
[1:1:0712/043836.678889:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 6:3_https://www.bubukua.com/, 6:4_https://pos.baidu.com/
[1:1:0712/043836.679000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/043836.679097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[78129:78129:0712/043837.255060:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[78129:78129:0712/043837.259997:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[78129:78140:0712/043837.275026:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 6
[78129:78129:0712/043837.275082:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://cm.cn.miaozhen.com/
[78129:78129:0712/043837.275125:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:6_https://cm.cn.miaozhen.com/, https://cm.cn.miaozhen.com/ipinyou.gif?ipinyou_uid=J7BBrL1W003R~, 6
[78129:78140:0712/043837.275124:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 6, HandleIncomingMessage, HandleIncomingMessage
[78129:78129:0712/043837.275186:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:6_https://cm.cn.miaozhen.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:38:37 GMT Content-Type: image/gif Content-Length: 35 Connection: keep-alive Set-Cookie: a=ZjDeh0UNoUfq; path=/; domain=.miaozhen.com; expires=Sun, 11-Jul-2021 11:38:37 GMT; P3P: CP='CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR' Server: Apache4Miaozhen 2.2.4  ,78244, 6
[1:7:0712/043837.280778:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043837.744776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.bubukua.com/"
[1:1:0712/043837.745215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043837.745339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043837.792466:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:5_https://vt.ipinyou.com/
[1:1:0712/043838.046500:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:7_https://ad.doubleclick.net/
[1:1:0712/043838.093000:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bubukua.com/"
[1:1:0712/043838.093439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , f.onload, (){f.onload=v;f=window[d]=v;a&&a(b)}
[1:1:0712/043838.093550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043838.096906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 707, 7fba98ea8881
[1:1:0712/043838.107234:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"600 0x7fba96563070 0x1478921f26e0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043838.107412:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"600 0x7fba96563070 0x1478921f26e0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043838.107645:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043838.107931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043838.108035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043838.108367:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043838.108469:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043838.108638:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 764
[1:1:0712/043838.108752:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7fba96563070 0x147892c6c860 , 6:3_https://www.bubukua.com/, 1, -6:3_https://www.bubukua.com/, 707 0x7fba96563070 0x147892c6c2e0 
[1:1:0712/043838.128460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043838.128614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043838.651776:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:6_https://cm.cn.miaozhen.com/
[1:1:0712/043838.881985:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[78129:78129:0712/043838.908867:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://vt.ipinyou.com/, https://vt.ipinyou.com/, 5
[78129:78129:0712/043838.908978:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://vt.ipinyou.com/, https://vt.ipinyou.com
[1:1:0712/043839.018263:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 756 0x7fba9848b2e0 0x14789327d160 , "https://www.bubukua.com/"
[1:1:0712/043839.018832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , ___baidu_union_callback_("auto","bfdb9113221382fad0eadfa6ec6922e2",[])
[1:1:0712/043839.018946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[78129:78129:0712/043839.099392:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:7_https://ad.doubleclick.net/, https://ad.doubleclick.net/, 7
[78129:78129:0712/043839.099526:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://ad.doubleclick.net/, https://ad.doubleclick.net
[1:1:0712/043839.247571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043839.247741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043839.248988:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 764, 7fba98ea8881
[1:1:0712/043839.259525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"707 0x7fba96563070 0x147892c6c2e0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043839.259679:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"707 0x7fba96563070 0x147892c6c2e0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043839.259859:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043839.260140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043839.260241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043839.260564:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043839.260676:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043839.260840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 830
[1:1:0712/043839.260947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7fba96563070 0x14789326f960 , 6:3_https://www.bubukua.com/, 1, -6:3_https://www.bubukua.com/, 764 0x7fba96563070 0x147892c6c860 
[78129:78129:0712/043839.609508:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:6_https://cm.cn.miaozhen.com/, https://cm.cn.miaozhen.com/, 6
[78129:78129:0712/043839.609673:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://cm.cn.miaozhen.com/, https://cm.cn.miaozhen.com
[1:1:0712/043840.035363:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043840.732083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043840.732327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043840.899299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 830, 7fba98ea8881
[1:1:0712/043840.935209:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"764 0x7fba96563070 0x147892c6c860 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043840.935518:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"764 0x7fba96563070 0x147892c6c860 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043840.935858:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043840.936415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043840.936591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043840.937245:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043840.937406:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043840.937817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 887
[1:1:0712/043840.938028:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 887 0x7fba96563070 0x147892c62de0 , 6:3_https://www.bubukua.com/, 1, -6:3_https://www.bubukua.com/, 830 0x7fba96563070 0x14789326f960 
[1:1:0712/043841.746550:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043841.746709:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://vt.ipinyou.com/Ii6LtP66QNTYXOBVZVld.Pt_sY_.IkdTZAzxPekyGVCztDLhvaF-ulxU-HvmYhBd-JR5Y8xv7Q9Qy_T82RdR6ol9ttsa7Qa4r_XAQ6Fo3o2fJhLzQDxygNFyYIssvOxi4AjqIqxTrmbq4gnJID9ehy2cOQKG6g1FZ5puGq2IXoC9lgjnUruR-eFIJoRLUO834rmn0vft7dmV8SfX6Ds3ZqKQOoCS6gFwZ5lSOia620NTNJcbM3Qll3nQqYLUIH-eFtEbBXmFo0E66fr4Y--eyL3QI16Ahb6DeyTvQQ5YwmB8aFKYUpazg6kZJZRdg3agNjrJjnIWzY9M6r8U9FmUPxmgDsMUl19rTudEMkgBjOqsvDlHqKd4mojiEYqAxAKCWSqnsqlsezA6Jdu1Tvp3d9Tl1sMBkmyhTx1uM5K9JmdbaKq9cKdX17pYyDaqbFxvrwp084FISG7UYdxOfSewicDZfIuMDE9SQumjQqNNpU7mQKbversxo21Trsp8r1KKM_VAU8blrZ5dAjNq66zYzNpldYKMk1CICsujGNK4Ms5SaFsSupFIY9N87MmsSDmP4xu5s993ioBaHSpJ6Aa.k3RyY_LSaYuLwH7NOJdBC_?eup=http%3A%2F%2Fclick%2Ebes%2Ebaidu%2Ecom%2Fadx%2Ephp%3Fc%3Dcz0zZjg1OGQ5ZmIwZjM2YTBiAHQ9MTU2MjkzMTUwOQBzZT0xAGJ1PTY0MTgwNDEAdHU9dTMxNzQwNjUAYWQ9MTU1ODYxMDQ2ODA4MQBzaXRlPWh0dHBzOi8vd3d3LmJ1YnVrdWEuY29tLwB2PTEAaT1iNzA5YWMwMg%26k%3Ddz0zMDAAaD0yNTAAY3NpZD0xMDczNzQxODI0MzAwAHRtPTI3NTAzODA3NwB0ZD0zMTc0MDY1AHdpPTY0MTgwNDEAZm49NjkwMzkwMTlfY3ByAGZhbj0AdWlkPTIyODE0NzU5AGNoPTAAb3M9NwBicj0xMgBpcD0yMTguMjQxLjEzNS4zNABzc3A9MQBhcHBfaWQ9AGFwcF9zaWQ9AHNka192ZXJzaW9uPQB0dHA9MQBjb21wbGU9MABzdHlwZT0wAGNobWQ9MABzY2htZD0wAHhpcD0AZHRwPTEAY21hdGNoPTIwMABmaXJzdF9yZWdpb249MQBzZWNvbmRfcmVnaW9uPTM4NQBiYnQ9MQBhYnQ9MQBudHRwPTEAYm1sPTAAYWRjbGFzcz0w%26url%3D"
[1:1:0712/043841.764872:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043841.807530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043841.807728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043842.014668:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 887, 7fba98ea8881
[1:1:0712/043842.051851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"830 0x7fba96563070 0x14789326f960 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043842.052156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"830 0x7fba96563070 0x14789326f960 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043842.052592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043842.053108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043842.053301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043842.053933:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043842.054091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043842.054442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 925
[1:1:0712/043842.054641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7fba96563070 0x147893429460 , 6:3_https://www.bubukua.com/, 1, -6:3_https://www.bubukua.com/, 887 0x7fba96563070 0x147892c62de0 
[1:1:0712/043842.942341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043842.942663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043842.995564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 920, "https://vt.ipinyou.com/Ii6LtP66QNTYXOBVZVld.Pt_sY_.IkdTZAzxPekyGVCztDLhvaF-ulxU-HvmYhBd-JR5Y8xv7Q9Qy_T82RdR6ol9ttsa7Qa4r_XAQ6Fo3o2fJhLzQDxygNFyYIssvOxi4AjqIqxTrmbq4gnJID9ehy2cOQKG6g1FZ5puGq2IXoC9lgjnUruR-eFIJoRLUO834rmn0vft7dmV8SfX6Ds3ZqKQOoCS6gFwZ5lSOia620NTNJcbM3Qll3nQqYLUIH-eFtEbBXmFo0E66fr4Y--eyL3QI16Ahb6DeyTvQQ5YwmB8aFKYUpazg6kZJZRdg3agNjrJjnIWzY9M6r8U9FmUPxmgDsMUl19rTudEMkgBjOqsvDlHqKd4mojiEYqAxAKCWSqnsqlsezA6Jdu1Tvp3d9Tl1sMBkmyhTx1uM5K9JmdbaKq9cKdX17pYyDaqbFxvrwp084FISG7UYdxOfSewicDZfIuMDE9SQumjQqNNpU7mQKbversxo21Trsp8r1KKM_VAU8blrZ5dAjNq66zYzNpldYKMk1CICsujGNK4Ms5SaFsSupFIY9N87MmsSDmP4xu5s993ioBaHSpJ6Aa.k3RyY_LSaYuLwH7NOJdBC_?eup=http%3A%2F%2Fclick%2Ebes%2Ebaidu%2Ecom%2Fadx%2Ephp%3Fc%3Dcz0zZjg1OGQ5ZmIwZjM2YTBiAHQ9MTU2MjkzMTUwOQBzZT0xAGJ1PTY0MTgwNDEAdHU9dTMxNzQwNjUAYWQ9MTU1ODYxMDQ2ODA4MQBzaXRlPWh0dHBzOi8vd3d3LmJ1YnVrdWEuY29tLwB2PTEAaT1iNzA5YWMwMg%26k%3Ddz0zMDAAaD0yNTAAY3NpZD0xMDczNzQxODI0MzAwAHRtPTI3NTAzODA3NwB0ZD0zMTc0MDY1AHdpPTY0MTgwNDEAZm49NjkwMzkwMTlfY3ByAGZhbj0AdWlkPTIyODE0NzU5AGNoPTAAb3M9NwBicj0xMgBpcD0yMTguMjQxLjEzNS4zNABzc3A9MQBhcHBfaWQ9AGFwcF9zaWQ9AHNka192ZXJzaW9uPQB0dHA9MQBjb21wbGU9MABzdHlwZT0wAGNobWQ9MABzY2htZD0wAHhpcD0AZHRwPTEAY21hdGNoPTIwMABmaXJzdF9yZWdpb249MQBzZWNvbmRfcmVnaW9uPTM4NQBiYnQ9MQBhYnQ9MQBudHRwPTEAYm1sPTAAYWRjbGFzcz0w%26url%3D"
[1:1:0712/043843.000590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:5_https://vt.ipinyou.com/, 334ebebacd98, , , function setLogo(e){var a,g;switch(e.position){case"BottomLeft":a="bottom: 0; left: 0;";g="bottom: 0
[1:1:0712/043843.000855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://vt.ipinyou.com/Ii6LtP66QNTYXOBVZVld.Pt_sY_.IkdTZAzxPekyGVCztDLhvaF-ulxU-HvmYhBd-JR5Y8xv7Q9Qy_T82RdR6ol9ttsa7Qa4r_XAQ6Fo3o2fJhLzQDxygNFyYIssvOxi4AjqIqxTrmbq4gnJID9ehy2cOQKG6g1FZ5puGq2IXoC9lgjnUruR-eFIJoRLUO834rmn0vft7dmV8SfX6Ds3ZqKQOoCS6gFwZ5lSOia620NTNJcbM3Qll3nQqYLUIH-eFtEbBXmFo0E66fr4Y--eyL3QI16Ahb6DeyTvQQ5YwmB8aFKYUpazg6kZJZRdg3agNjrJjnIWzY9M6r8U9FmUPxmgDsMUl19rTudEMkgBjOqsvDlHqKd4mojiEYqAxAKCWSqnsqlsezA6Jdu1Tvp3d9Tl1sMBkmyhTx1uM5K9JmdbaKq9cKdX17pYyDaqbFxvrwp084FISG7UYdxOfSewicDZfIuMDE9SQumjQqNNpU7mQKbversxo21Trsp8r1KKM_VAU8blrZ5dAjNq66zYzNpldYKMk1CICsujGNK4Ms5SaFsSupFIY9N87MmsSDmP4xu5s993ioBaHSpJ6Aa.k3RyY_LSaYuLwH7NOJdBC_?eup=http%3A%2F%2Fclick%2Ebes%2Ebaidu%2Ecom%2Fadx%2Ephp%3Fc%3Dcz0zZjg1OGQ5ZmIwZjM2YTBiAHQ9MTU2MjkzMTUwOQBzZT0xAGJ1PTY0MTgwNDEAdHU9dTMxNzQwNjUAYWQ9MTU1ODYxMDQ2ODA4MQBzaXRlPWh0dHBzOi8vd3d3LmJ1YnVrdWEuY29tLwB2PTEAaT1iNzA5YWMwMg%26k%3Ddz0zMDAAaD0yNTAAY3NpZD0xMDczNzQxODI0MzAwAHRtPTI3NTAzODA3NwB0ZD0zMTc0MDY1AHdpPTY0MTgwNDEAZm49NjkwMzkwMTlfY3ByAGZhbj0AdWlkPTIyODE0NzU5AGNoPTAAb3M9NwBicj0xMgBpcD0yMTguMjQxLjEzNS4zNABzc3A9MQBhcHBfaWQ9AGFwcF9zaWQ9AHNka192ZXJzaW9uPQB0dHA9MQBjb21wbGU9MABzdHlwZT0wAGNobWQ9MABzY2htZD0wAHhpcD0AZHRwPTEAY21hdGNoPTIwMABmaXJzdF9yZWdpb249MQBzZWNvbmRfcmVnaW9uPTM4NQBiYnQ9MQBhYnQ9MQBudHRwPTEAYm1sPTAAYWRjbGFzcz0w%26url%3D", "vt.ipinyou.com", 5, 1, https://pos.baidu.com, pos.baidu.com, 4
[1:1:0712/043843.062083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 923, "https://vt.ipinyou.com/Ii6LtP66QNTYXOBVZVld.Pt_sY_.IkdTZAzxPekyGVCztDLhvaF-ulxU-HvmYhBd-JR5Y8xv7Q9Qy_T82RdR6ol9ttsa7Qa4r_XAQ6Fo3o2fJhLzQDxygNFyYIssvOxi4AjqIqxTrmbq4gnJID9ehy2cOQKG6g1FZ5puGq2IXoC9lgjnUruR-eFIJoRLUO834rmn0vft7dmV8SfX6Ds3ZqKQOoCS6gFwZ5lSOia620NTNJcbM3Qll3nQqYLUIH-eFtEbBXmFo0E66fr4Y--eyL3QI16Ahb6DeyTvQQ5YwmB8aFKYUpazg6kZJZRdg3agNjrJjnIWzY9M6r8U9FmUPxmgDsMUl19rTudEMkgBjOqsvDlHqKd4mojiEYqAxAKCWSqnsqlsezA6Jdu1Tvp3d9Tl1sMBkmyhTx1uM5K9JmdbaKq9cKdX17pYyDaqbFxvrwp084FISG7UYdxOfSewicDZfIuMDE9SQumjQqNNpU7mQKbversxo21Trsp8r1KKM_VAU8blrZ5dAjNq66zYzNpldYKMk1CICsujGNK4Ms5SaFsSupFIY9N87MmsSDmP4xu5s993ioBaHSpJ6Aa.k3RyY_LSaYuLwH7NOJdBC_?eup=http%3A%2F%2Fclick%2Ebes%2Ebaidu%2Ecom%2Fadx%2Ephp%3Fc%3Dcz0zZjg1OGQ5ZmIwZjM2YTBiAHQ9MTU2MjkzMTUwOQBzZT0xAGJ1PTY0MTgwNDEAdHU9dTMxNzQwNjUAYWQ9MTU1ODYxMDQ2ODA4MQBzaXRlPWh0dHBzOi8vd3d3LmJ1YnVrdWEuY29tLwB2PTEAaT1iNzA5YWMwMg%26k%3Ddz0zMDAAaD0yNTAAY3NpZD0xMDczNzQxODI0MzAwAHRtPTI3NTAzODA3NwB0ZD0zMTc0MDY1AHdpPTY0MTgwNDEAZm49NjkwMzkwMTlfY3ByAGZhbj0AdWlkPTIyODE0NzU5AGNoPTAAb3M9NwBicj0xMgBpcD0yMTguMjQxLjEzNS4zNABzc3A9MQBhcHBfaWQ9AGFwcF9zaWQ9AHNka192ZXJzaW9uPQB0dHA9MQBjb21wbGU9MABzdHlwZT0wAGNobWQ9MABzY2htZD0wAHhpcD0AZHRwPTEAY21hdGNoPTIwMABmaXJzdF9yZWdpb249MQBzZWNvbmRfcmVnaW9uPTM4NQBiYnQ9MQBhYnQ9MQBudHRwPTEAYm1sPTAAYWRjbGFzcz0w%26url%3D"
[1:1:0712/043843.067796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:5_https://vt.ipinyou.com/, 334ebebacd98, , , setLogo( {"height":250,"hoverLogo":{"clickUrl":"https://h5.ipinyou.com","height":18,"url":"https://f
[1:1:0712/043843.068136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://vt.ipinyou.com/Ii6LtP66QNTYXOBVZVld.Pt_sY_.IkdTZAzxPekyGVCztDLhvaF-ulxU-HvmYhBd-JR5Y8xv7Q9Qy_T82RdR6ol9ttsa7Qa4r_XAQ6Fo3o2fJhLzQDxygNFyYIssvOxi4AjqIqxTrmbq4gnJID9ehy2cOQKG6g1FZ5puGq2IXoC9lgjnUruR-eFIJoRLUO834rmn0vft7dmV8SfX6Ds3ZqKQOoCS6gFwZ5lSOia620NTNJcbM3Qll3nQqYLUIH-eFtEbBXmFo0E66fr4Y--eyL3QI16Ahb6DeyTvQQ5YwmB8aFKYUpazg6kZJZRdg3agNjrJjnIWzY9M6r8U9FmUPxmgDsMUl19rTudEMkgBjOqsvDlHqKd4mojiEYqAxAKCWSqnsqlsezA6Jdu1Tvp3d9Tl1sMBkmyhTx1uM5K9JmdbaKq9cKdX17pYyDaqbFxvrwp084FISG7UYdxOfSewicDZfIuMDE9SQumjQqNNpU7mQKbversxo21Trsp8r1KKM_VAU8blrZ5dAjNq66zYzNpldYKMk1CICsujGNK4Ms5SaFsSupFIY9N87MmsSDmP4xu5s993ioBaHSpJ6Aa.k3RyY_LSaYuLwH7NOJdBC_?eup=http%3A%2F%2Fclick%2Ebes%2Ebaidu%2Ecom%2Fadx%2Ephp%3Fc%3Dcz0zZjg1OGQ5ZmIwZjM2YTBiAHQ9MTU2MjkzMTUwOQBzZT0xAGJ1PTY0MTgwNDEAdHU9dTMxNzQwNjUAYWQ9MTU1ODYxMDQ2ODA4MQBzaXRlPWh0dHBzOi8vd3d3LmJ1YnVrdWEuY29tLwB2PTEAaT1iNzA5YWMwMg%26k%3Ddz0zMDAAaD0yNTAAY3NpZD0xMDczNzQxODI0MzAwAHRtPTI3NTAzODA3NwB0ZD0zMTc0MDY1AHdpPTY0MTgwNDEAZm49NjkwMzkwMTlfY3ByAGZhbj0AdWlkPTIyODE0NzU5AGNoPTAAb3M9NwBicj0xMgBpcD0yMTguMjQxLjEzNS4zNABzc3A9MQBhcHBfaWQ9AGFwcF9zaWQ9AHNka192ZXJzaW9uPQB0dHA9MQBjb21wbGU9MABzdHlwZT0wAGNobWQ9MABzY2htZD0wAHhpcD0AZHRwPTEAY21hdGNoPTIwMABmaXJzdF9yZWdpb249MQBzZWNvbmRfcmVnaW9uPTM4NQBiYnQ9MQBhYnQ9MQBudHRwPTEAYm1sPTAAYWRjbGFzcz0w%26url%3D", "vt.ipinyou.com", 5, 1, https://pos.baidu.com, pos.baidu.com, 4
[1:1:0712/043843.273798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 925, 7fba98ea8881
[1:1:0712/043843.314493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"887 0x7fba96563070 0x147892c62de0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043843.314843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"887 0x7fba96563070 0x147892c62de0 ","rf":"6:3_https://www.bubukua.com/"}
[1:1:0712/043843.315105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043843.315432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043843.315537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043843.315859:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043843.315959:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043843.316125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bubukua.com/, 972
[1:1:0712/043843.316250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7fba96563070 0x147892bfb760 , 6:3_https://www.bubukua.com/, 1, -6:3_https://www.bubukua.com/, 925 0x7fba96563070 0x147893429460 
[1:1:0712/043843.518809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043843.519049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043844.030513:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.bubukua.com/"
[1:1:0712/043844.031243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/043844.031439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043844.034057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bubukua.com/"
[1:1:0712/043844.037251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://www.bubukua.com/"
[1:1:0712/043844.039005:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8eaf0
[1:1:0712/043844.039213:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043844.039601:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1005
[1:1:0712/043844.039955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7fba96563070 0x147893501b60 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 969 0x7fba96563070 0x147891c727e0 
[1:1:0712/043844.187466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , , document.readyState
[1:1:0712/043844.187797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043845.203407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1005, 7fba98ea8881
[1:1:0712/043845.244428:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"969 0x7fba96563070 0x147891c727e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043845.244767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"969 0x7fba96563070 0x147891c727e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043845.245162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043845.245684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043845.245940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043845.246604:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043845.246763:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043845.247086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1029
[1:1:0712/043845.247297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7fba96563070 0x1478936ae960 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1005 0x7fba96563070 0x147893501b60 
[1:1:0712/043846.162302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1029, 7fba98ea8881
[1:1:0712/043846.203861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1005 0x7fba96563070 0x147893501b60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043846.204212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1005 0x7fba96563070 0x147893501b60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043846.204642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043846.205240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043846.205433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043846.206068:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043846.206246:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043846.206600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1046
[1:1:0712/043846.206790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7fba96563070 0x1478936a5c60 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1029 0x7fba96563070 0x1478936ae960 
[1:1:0712/043846.632245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1046, 7fba98ea8881
[1:1:0712/043846.673577:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1029 0x7fba96563070 0x1478936ae960 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043846.673879:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1029 0x7fba96563070 0x1478936ae960 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043846.674244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043846.674790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043846.674968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043846.675630:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043846.675789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043846.676108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1061
[1:1:0712/043846.676295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1061 0x7fba96563070 0x14789325bf60 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1046 0x7fba96563070 0x1478936a5c60 
[1:1:0712/043846.887114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1061, 7fba98ea8881
[1:1:0712/043846.927762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1046 0x7fba96563070 0x1478936a5c60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043846.928062:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1046 0x7fba96563070 0x1478936a5c60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043846.928436:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043846.928986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043846.929164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043846.929821:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043846.929981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043846.930387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1067
[1:1:0712/043846.930573:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1067 0x7fba96563070 0x147893685b60 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1061 0x7fba96563070 0x14789325bf60 
[1:1:0712/043847.058123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1067, 7fba98ea8881
[1:1:0712/043847.098899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1061 0x7fba96563070 0x14789325bf60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.099214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1061 0x7fba96563070 0x14789325bf60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.099597:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043847.100126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043847.100304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043847.106581:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043847.106770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043847.107097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1073
[1:1:0712/043847.107283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1073 0x7fba96563070 0x147891e220e0 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1067 0x7fba96563070 0x147893685b60 
[1:1:0712/043847.228744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1073, 7fba98ea8881
[1:1:0712/043847.281768:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1067 0x7fba96563070 0x147893685b60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.282160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1067 0x7fba96563070 0x147893685b60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.282644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043847.283306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043847.283528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043847.284365:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043847.284566:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043847.284989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1079
[1:1:0712/043847.285230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7fba96563070 0x147892c5fd60 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1073 0x7fba96563070 0x147891e220e0 
[1:1:0712/043847.386168:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1079, 7fba98ea8881
[1:1:0712/043847.398700:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1073 0x7fba96563070 0x147891e220e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.398917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1073 0x7fba96563070 0x147891e220e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.399119:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043847.399427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043847.399531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043847.399920:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043847.400038:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043847.400210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1085
[1:1:0712/043847.400320:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7fba96563070 0x147892bd1260 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1079 0x7fba96563070 0x147892c5fd60 
[1:1:0712/043847.566008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1085, 7fba98ea8881
[1:1:0712/043847.605563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1079 0x7fba96563070 0x147892c5fd60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.605883:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1079 0x7fba96563070 0x147892c5fd60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.606260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043847.606751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043847.606937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043847.607536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043847.607687:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043847.608043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1090
[1:1:0712/043847.608227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1090 0x7fba96563070 0x147891f612e0 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1085 0x7fba96563070 0x147892bd1260 
[1:1:0712/043847.771584:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1090, 7fba98ea8881
[1:1:0712/043847.816166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1085 0x7fba96563070 0x147892bd1260 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.816509:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1085 0x7fba96563070 0x147892bd1260 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043847.816921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043847.817466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043847.817648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043847.818335:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043847.818518:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043847.818879:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1092
[1:1:0712/043847.819083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1092 0x7fba96563070 0x1478936984e0 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1090 0x7fba96563070 0x147891f612e0 
[1:1:0712/043847.980530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1092, 7fba98ea8881
[1:1:0712/043848.022213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1090 0x7fba96563070 0x147891f612e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.022504:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1090 0x7fba96563070 0x147891f612e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.022873:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043848.023418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043848.023593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043848.024264:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043848.024428:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043848.024751:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1095
[1:1:0712/043848.024984:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7fba96563070 0x14789353cb60 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1092 0x7fba96563070 0x1478936984e0 
[1:1:0712/043848.179578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1095, 7fba98ea8881
[1:1:0712/043848.209230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1092 0x7fba96563070 0x1478936984e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.209401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1092 0x7fba96563070 0x1478936984e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.209605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043848.209911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043848.210036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043848.210348:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043848.210448:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043848.210631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1097
[1:1:0712/043848.210741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7fba96563070 0x1478920c9a60 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1095 0x7fba96563070 0x14789353cb60 
[1:1:0712/043848.356781:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1097, 7fba98ea8881
[1:1:0712/043848.397407:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1095 0x7fba96563070 0x14789353cb60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.397618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1095 0x7fba96563070 0x14789353cb60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.397832:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043848.398167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043848.398275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043848.398573:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043848.398672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043848.398846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1099
[1:1:0712/043848.398960:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7fba96563070 0x147892be26e0 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1097 0x7fba96563070 0x1478920c9a60 
[1:1:0712/043848.540288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1099, 7fba98ea8881
[1:1:0712/043848.554376:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1097 0x7fba96563070 0x1478920c9a60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.554535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1097 0x7fba96563070 0x1478920c9a60 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.554733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043848.555042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043848.555176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043848.555484:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043848.555585:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043848.555771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1101
[1:1:0712/043848.555895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7fba96563070 0x147892bce5e0 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1099 0x7fba96563070 0x147892be26e0 
[1:1:0712/043848.730700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1101, 7fba98ea8881
[1:1:0712/043848.773244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1099 0x7fba96563070 0x147892be26e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.773587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1099 0x7fba96563070 0x147892be26e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.774011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043848.774561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043848.774751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043848.775476:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043848.775674:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043848.776103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1104
[1:1:0712/043848.776401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1104 0x7fba96563070 0x1478936a5860 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1101 0x7fba96563070 0x147892bce5e0 
[1:1:0712/043848.919644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1104, 7fba98ea8881
[1:1:0712/043848.961540:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1101 0x7fba96563070 0x147892bce5e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.961825:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1101 0x7fba96563070 0x147892bce5e0 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043848.962211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043848.962725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043848.962900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043848.963553:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043848.963712:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043848.964031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1108
[1:1:0712/043848.964271:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1108 0x7fba96563070 0x1478936aa0e0 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1104 0x7fba96563070 0x1478936a5860 
[1:1:0712/043849.117939:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1108, 7fba98ea8881
[1:1:0712/043849.159978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"334ebeac2860","ptid":"1104 0x7fba96563070 0x1478936a5860 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043849.160313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bubukua.com/","ptid":"1104 0x7fba96563070 0x1478936a5860 ","rf":"6:5_https://vt.ipinyou.com/"}
[1:1:0712/043849.160690:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bubukua.com/"
[1:1:0712/043849.161196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bubukua.com/, 334ebeac2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/043849.161403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bubukua.com/", "www.bubukua.com", 3, 1, , , 0
[1:1:0712/043849.162028:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2474467829c8, 0x147891a8e950
[1:1:0712/043849.162185:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bubukua.com/", 100
[1:1:0712/043849.162530:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:5_https://vt.ipinyou.com/, 1111
[1:1:0712/043849.162717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1111 0x7fba96563070 0x14789338b960 , 6:5_https://vt.ipinyou.com/, 1, -6:3_https://www.bubukua.com/, 1108 0x7fba96563070 0x1478936aa0e0 
