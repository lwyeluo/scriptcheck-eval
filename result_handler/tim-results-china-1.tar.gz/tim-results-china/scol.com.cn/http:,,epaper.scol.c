[0712/034208.643317:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034208.643884:INFO:switcher_clone.cc(787)] backtrace rip is 7fcc0cbc3891
[0712/034209.572551:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034209.572969:INFO:switcher_clone.cc(787)] backtrace rip is 7f71fa0d7891
[1:1:0712/034209.586214:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/034209.586485:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/034209.591742:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/034210.988834:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034210.989101:INFO:switcher_clone.cc(787)] backtrace rip is 7f312a9a7891
[71221:71221:0712/034211.078001:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/a2974803-1ff5-4275-9d90-973d56fbf284
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[71251:71251:0712/034211.232938:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=71251
[71264:71264:0712/034211.233333:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=71264
[71221:71221:0712/034211.495546:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[71221:71249:0712/034211.496245:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/034211.496492:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034211.496752:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034211.497351:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034211.497542:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/034211.500568:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x16aaf2f7, 1
[1:1:0712/034211.500916:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3b81cae4, 0
[1:1:0712/034211.501123:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x860b9a0, 3
[1:1:0712/034211.501310:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2a1bb2b7, 2
[1:1:0712/034211.501546:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe4ffffffcaffffff813b fffffff7fffffff2ffffffaa16 ffffffb7ffffffb21b2a ffffffa0ffffffb96008 , 10104, 4
[1:1:0712/034211.502622:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[71221:71249:0712/034211.502870:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�ʁ;����*��`�M
[71221:71249:0712/034211.502947:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �ʁ;����*��`ع�M
[1:1:0712/034211.503069:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71f83120a0, 3
[71221:71249:0712/034211.503216:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[71221:71249:0712/034211.503280:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 71272, 4, e4ca813b f7f2aa16 b7b21b2a a0b96008 
[1:1:0712/034211.503278:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71f849d080, 2
[1:1:0712/034211.503426:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71e2160d20, -2
[1:1:0712/034211.511802:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034211.512369:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1bb2b7
[1:1:0712/034211.513040:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1bb2b7
[1:1:0712/034211.514082:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1bb2b7
[1:1:0712/034211.514582:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.514685:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.514778:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.514882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.515102:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1bb2b7
[1:1:0712/034211.515237:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71fa0d77ba
[1:1:0712/034211.515315:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71fa0cedef, 7f71fa0d777a, 7f71fa0d90cf
[1:1:0712/034211.516924:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1bb2b7
[1:1:0712/034211.517084:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1bb2b7
[1:1:0712/034211.517355:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1bb2b7
[1:1:0712/034211.518059:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.518171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.518265:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.518357:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1bb2b7
[1:1:0712/034211.518832:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1bb2b7
[1:1:0712/034211.518992:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71fa0d77ba
[1:1:0712/034211.519069:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71fa0cedef, 7f71fa0d777a, 7f71fa0d90cf
[1:1:0712/034211.521249:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034211.521512:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034211.521604:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc7ccaa2d8, 0x7ffc7ccaa258)
[1:1:0712/034211.537073:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034211.545132:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[71221:71221:0712/034212.199943:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71221:71221:0712/034212.201422:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71221:71231:0712/034212.214911:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[71221:71231:0712/034212.215033:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[71221:71221:0712/034212.215171:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[71221:71221:0712/034212.215261:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[71221:71221:0712/034212.215434:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,71272, 4
[1:7:0712/034212.218228:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[71221:71242:0712/034212.260947:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/034212.348237:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2835ac2b9220
[1:1:0712/034212.348527:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/034212.732870:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/034214.420008:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034214.423328:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[71221:71221:0712/034214.443150:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[71221:71221:0712/034214.443268:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/034215.540124:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034215.686120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c008ef81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034215.686699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034215.712882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c008ef81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034215.713311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034215.911067:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034215.911647:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034216.231263:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034216.239857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c008ef81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034216.240234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034216.276351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034216.287417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c008ef81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034216.287785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034216.300061:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/034216.305192:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2835ac2b7e20
[1:1:0712/034216.305494:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[71221:71221:0712/034216.307435:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[71221:71221:0712/034216.331669:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[71221:71221:0712/034216.369670:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[71221:71221:0712/034216.369858:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[71221:71221:0712/034216.393447:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/034216.411835:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034217.161595:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f71e3d3b2e0 0x2835ac5725e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034217.163562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c008ef81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/034217.163785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034217.165735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[71221:71221:0712/034217.253706:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/034217.254524:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2835ac2b8820
[1:1:0712/034217.254759:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[71221:71221:0712/034217.270200:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/034217.274936:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/034217.275235:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[71221:71221:0712/034217.306713:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[71221:71221:0712/034217.323045:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71221:71221:0712/034217.324221:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71221:71231:0712/034217.330656:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[71221:71231:0712/034217.330761:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[71221:71221:0712/034217.330902:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[71221:71221:0712/034217.331014:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[71221:71221:0712/034217.331158:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,71272, 4
[1:7:0712/034217.335288:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034217.972325:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/034218.545530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f71e3d3b2e0 0x2835ac6558e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034218.547393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c008ef81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/034218.547820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034218.549405:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034218.718647:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[71221:71221:0712/034218.719821:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[71221:71221:0712/034218.719896:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/034219.093668:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[71221:71221:0712/034219.097144:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[71221:71249:0712/034219.097638:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/034219.097834:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034219.098061:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034219.098522:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034219.098714:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/034219.102323:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c0c0fd9, 1
[1:1:0712/034219.102716:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x8f170a3, 0
[1:1:0712/034219.102872:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2e38512b, 3
[1:1:0712/034219.103032:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x136f3e26, 2
[1:1:0712/034219.103181:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa370fffffff108 ffffffd90f0c3c 263e6f13 2b51382e , 10104, 5
[1:1:0712/034219.105566:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[71221:71249:0712/034219.106125:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�p��<&>o+Q8.6�M
[71221:71249:0712/034219.106297:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �p��<&>o+Q8.��6�M
[71221:71249:0712/034219.106706:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 71318, 5, a370f108 d90f0c3c 263e6f13 2b51382e 
[1:1:0712/034219.106615:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71f83120a0, 3
[1:1:0712/034219.107065:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71f849d080, 2
[1:1:0712/034219.107607:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71e2160d20, -2
[1:1:0712/034219.127672:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034219.127887:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 136f3e26
[1:1:0712/034219.128102:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 136f3e26
[1:1:0712/034219.128454:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 136f3e26
[1:1:0712/034219.128984:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.129101:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.129211:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.129326:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.129634:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 136f3e26
[1:1:0712/034219.129788:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71fa0d77ba
[1:1:0712/034219.129877:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71fa0cedef, 7f71fa0d777a, 7f71fa0d90cf
[1:1:0712/034219.132426:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 136f3e26
[1:1:0712/034219.132705:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 136f3e26
[1:1:0712/034219.133205:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 136f3e26
[1:1:0712/034219.134090:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.134229:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.134344:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.134488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 136f3e26
[1:1:0712/034219.135021:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 136f3e26
[1:1:0712/034219.135208:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f71fa0d77ba
[1:1:0712/034219.135302:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f71fa0cedef, 7f71fa0d777a, 7f71fa0d90cf
[1:1:0712/034219.138076:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034219.138487:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034219.138595:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc7ccaa2d8, 0x7ffc7ccaa258)
[1:1:0712/034219.152887:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034219.157323:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/034219.414091:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2835ac2b0220
[1:1:0712/034219.414302:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/034219.772914:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034219.773272:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034220.323134:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034220.327939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c008f0b09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/034220.328824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034220.337577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[71221:71221:0712/034220.391825:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71221:71221:0712/034220.397668:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/034220.411527:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034220.412505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c008ef81f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/034220.412767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[71221:71231:0712/034220.441213:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[71221:71231:0712/034220.441320:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[71221:71221:0712/034220.442968:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://epaper.scol.com.cn/
[71221:71221:0712/034220.443076:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://epaper.scol.com.cn/, http://epaper.scol.com.cn/rlzyb/20190708/, 1
[71221:71221:0712/034220.443255:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://epaper.scol.com.cn/, HTTP/1.1 200 OK Content-Length: 1797 Content-Type: text/html Content-Location: http://epaper.scol.com.cn/rlzyb/20190708/index.htm Last-Modified: Sun, 07 Jul 2019 15:13:32 GMT Accept-Ranges: bytes ETag: "5c681f8ad634d51:7ca6" Server: Microsoft-IIS/6.0 X-Powered-By: ASP.NET Date: Fri, 12 Jul 2019 10:41:04 GMT  ,71318, 5
[1:7:0712/034220.448789:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034220.477467:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://epaper.scol.com.cn/
[1:1:0712/034220.575706:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034220.577584:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/034220.577834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c008f0b09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/034220.578205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[71221:71221:0712/034220.617413:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://epaper.scol.com.cn/, http://epaper.scol.com.cn/, 1
[71221:71221:0712/034220.617553:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://epaper.scol.com.cn/, http://epaper.scol.com.cn
[1:1:0712/034220.681500:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034220.751781:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034220.775356:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034220.775506:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://epaper.scol.com.cn/rlzyb/20190708/"
[1:1:0712/034220.807799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034220.808743:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/034220.808969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c008f0b09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/034220.809231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034220.963995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 129, "http://epaper.scol.com.cn/rlzyb/20190708/"
[1:1:0712/034220.965108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://epaper.scol.com.cn/, 0cfb86442860, , , 
[1:1:0712/034220.965338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://epaper.scol.com.cn/rlzyb/20190708/", "epaper.scol.com.cn", 3, 1, , , 0
[1:1:0712/034220.973618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 129, "http://epaper.scol.com.cn/rlzyb/20190708/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/034229.486171:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034229.486743:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034229.491459:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034229.492154:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034229.492658:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[71221:71221:0712/034239.397556:INFO:CONSOLE(26)] "Uncaught SyntaxError: Unexpected token .", source: http://epaper.scol.com.cn/rlzyb/20190708/ (26)
[71221:71221:0712/034239.479059:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/034239.487247:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/034239.519602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://epaper.scol.com.cn/, 0cfb86442860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/034239.519958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://epaper.scol.com.cn/rlzyb/20190708/", "epaper.scol.com.cn", 3, 1, , , 0
[1:1:0712/034239.521103:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034239.638682:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034239.639135:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034239.639450:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034239.639725:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034239.640072:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034239.852407:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034240.149404:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034240.149650:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/034240.151200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f71e1e13070 0x2835ac3d8260 , "data:text/html,pluginplaceholderdata"
[1:1:0712/034240.152243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 0cfb86561f78, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/034240.152484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/034240.176280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f71e1e13070 0x2835ac3d8260 , "data:text/html,pluginplaceholderdata"
[1:1:0712/034240.182098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f71e1e13070 0x2835ac3d8260 , "data:text/html,pluginplaceholderdata"
[1:1:0712/034240.184611:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f71e1e13070 0x2835ac3d8260 , "data:text/html,pluginplaceholderdata"
		remove user.f_6842b6e8 -> 0
[1:1:0712/034240.323443:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://epaper.scol.com.cn/favicon.ico"
[1:1:0712/034240.463174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/034240.465103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 0cfb86561f78, , onload, notifyDidFinishLoading();
[1:1:0712/034240.465315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
