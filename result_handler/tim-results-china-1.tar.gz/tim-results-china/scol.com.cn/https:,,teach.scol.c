[0712/033402.668297:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033402.668617:INFO:switcher_clone.cc(787)] backtrace rip is 7f7b55c7d891
[0712/033403.663747:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033403.664109:INFO:switcher_clone.cc(787)] backtrace rip is 7f4c6f4ee891
[1:1:0712/033403.668357:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/033403.668561:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/033403.674063:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[70011:70011:0712/033404.775098:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/b9f107ac-b12e-40a3-91f6-396fdfff8091
[0712/033405.132830:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033405.133218:INFO:switcher_clone.cc(787)] backtrace rip is 7f74593ff891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[70011:70011:0712/033405.357549:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[70011:70041:0712/033405.358316:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/033405.358574:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/033405.358789:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/033405.359382:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/033405.359549:INFO:zygote_linux.cc(633)] 		cid is 4
[70043:70043:0712/033405.360753:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=70043
[70056:70056:0712/033405.361138:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=70056
[1:1:0712/033405.362270:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x24672ff2, 1
[1:1:0712/033405.362688:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x271a95b6, 0
[1:1:0712/033405.362908:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x18a7c37a, 3
[1:1:0712/033405.363121:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x33a2f435, 2
[1:1:0712/033405.363429:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb6ffffff951a27 fffffff22f6724 35fffffff4ffffffa233 7affffffc3ffffffa718 , 10104, 4
[1:1:0712/033405.364675:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[70011:70041:0712/033405.364929:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��'�/g$5��3zç9|�
[70011:70041:0712/033405.365023:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��'�/g$5��3zç�9|�
[1:1:0712/033405.365164:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4c6d7290a0, 3
[70011:70041:0712/033405.365343:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[70011:70041:0712/033405.365422:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 70057, 4, b6951a27 f22f6724 35f4a233 7ac3a718 
[1:1:0712/033405.365432:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4c6d8b4080, 2
[1:1:0712/033405.365627:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4c57577d20, -2
[1:1:0712/033405.389164:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/033405.390229:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33a2f435
[1:1:0712/033405.391469:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33a2f435
[1:1:0712/033405.393456:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33a2f435
[1:1:0712/033405.395251:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.395506:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.395731:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.395963:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.396758:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33a2f435
[1:1:0712/033405.397176:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4c6f4ee7ba
[1:1:0712/033405.397357:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4c6f4e5def, 7f4c6f4ee77a, 7f4c6f4f00cf
[1:1:0712/033405.404311:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33a2f435
[1:1:0712/033405.404786:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33a2f435
[1:1:0712/033405.405712:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33a2f435
[1:1:0712/033405.408227:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.408512:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.408741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.408987:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33a2f435
[1:1:0712/033405.410547:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33a2f435
[1:1:0712/033405.410996:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4c6f4ee7ba
[1:1:0712/033405.411182:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4c6f4e5def, 7f4c6f4ee77a, 7f4c6f4f00cf
[1:1:0712/033405.419195:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/033405.419727:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/033405.419879:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc69bd3d98, 0x7ffc69bd3d18)
[1:1:0712/033405.434858:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/033405.440898:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[70011:70034:0712/033406.057353:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[70011:70011:0712/033406.074819:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[70011:70011:0712/033406.076390:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[70011:70022:0712/033406.089631:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[70011:70022:0712/033406.089790:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[70011:70011:0712/033406.089850:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[70011:70011:0712/033406.089952:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[70011:70011:0712/033406.090084:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,70057, 4
[1:7:0712/033406.097073:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033406.123844:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1ecb88ffe220
[1:1:0712/033406.124151:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/033406.558047:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/033407.651676:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033407.656103:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[70011:70011:0712/033407.783533:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[70011:70011:0712/033407.783587:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/033408.955701:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033409.182824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19345da41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/033409.183116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033409.200175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19345da41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/033409.200499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033409.358498:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033409.358779:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033409.659606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033409.667886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19345da41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/033409.668205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033409.704231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033409.714691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19345da41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/033409.714992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033409.727021:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/033409.730631:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1ecb88ffce20
[1:1:0712/033409.730843:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[70011:70011:0712/033409.731511:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[70011:70011:0712/033409.746086:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[70011:70011:0712/033409.797754:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[70011:70011:0712/033409.799768:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/033409.829706:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033410.983486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f4c591522e0 0x1ecb891fa960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033410.984963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19345da41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/033410.985176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033410.986641:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[70011:70011:0712/033411.054238:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/033411.056093:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1ecb88ffd820
[1:1:0712/033411.056338:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[70011:70011:0712/033411.056517:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/033411.075052:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/033411.075282:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[70011:70011:0712/033411.076324:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[70011:70011:0712/033411.087610:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[70011:70011:0712/033411.088125:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[70011:70022:0712/033411.089774:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[70011:70011:0712/033411.089839:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[70011:70011:0712/033411.089879:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[70011:70022:0712/033411.089894:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[70011:70011:0712/033411.089944:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,70057, 4
[1:7:0712/033411.099191:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033411.663572:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/033411.871925:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4c591522e0 0x1ecb894630e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033411.872961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19345da41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/033411.873232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033411.874045:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[70011:70011:0712/033412.092032:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[70011:70011:0712/033412.092185:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/033412.099021:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033412.403319:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[70011:70011:0712/033412.807694:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[70011:70041:0712/033412.808219:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/033412.808455:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/033412.808706:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/033412.809107:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/033412.809304:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/033412.812068:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x31f24353, 1
[1:1:0712/033412.812503:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3fe39a1d, 0
[1:1:0712/033412.812703:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3f1882af, 3
[1:1:0712/033412.812885:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2f834369, 2
[1:1:0712/033412.813063:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1dffffff9affffffe33f 5343fffffff231 6943ffffff832f ffffffafffffff82183f , 10104, 5
[1:1:0712/033412.814059:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[70011:70041:0712/033412.814344:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��?SC�1iC�/��?�~�
[70011:70041:0712/033412.814429:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��?SC�1iC�/��?�G�~�
[1:1:0712/033412.814569:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4c6d7290a0, 3
[70011:70041:0712/033412.814726:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 70107, 5, 1d9ae33f 5343f231 6943832f af82183f 
[1:1:0712/033412.814817:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4c6d8b4080, 2
[1:1:0712/033412.815045:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4c57577d20, -2
[1:1:0712/033412.839689:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/033412.840045:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f834369
[1:1:0712/033412.840436:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f834369
[1:1:0712/033412.840717:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f834369
[1:1:0712/033412.841157:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.841275:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.841377:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.841466:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.841699:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f834369
[1:1:0712/033412.841839:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4c6f4ee7ba
[1:1:0712/033412.841913:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4c6f4e5def, 7f4c6f4ee77a, 7f4c6f4f00cf
[1:1:0712/033412.843390:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f834369
[1:1:0712/033412.843555:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f834369
[1:1:0712/033412.843819:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f834369
[1:1:0712/033412.844526:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.844650:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.844749:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.844844:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f834369
[1:1:0712/033412.845300:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f834369
[1:1:0712/033412.845462:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4c6f4ee7ba
[1:1:0712/033412.845535:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4c6f4e5def, 7f4c6f4ee77a, 7f4c6f4f00cf
[1:1:0712/033412.847757:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/033412.848089:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/033412.848183:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc69bd3d98, 0x7ffc69bd3d18)
[1:1:0712/033412.853428:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033412.853628:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033412.861107:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/033412.865364:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/033413.027353:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1ecb88fe4220
[1:1:0712/033413.027624:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/033413.150499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033413.155183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19345db70640, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/033413.155544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/033413.163591:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033413.324178:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033413.324982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19345da41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/033413.325221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033413.526717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033413.528732:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/033413.528952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19345db70640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/033413.529216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[70011:70011:0712/033413.555278:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[70011:70011:0712/033413.561532:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[70011:70011:0712/033413.591078:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://teach.scol.com.cn/
[70011:70022:0712/033413.591061:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[70011:70011:0712/033413.591187:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://teach.scol.com.cn/, https://teach.scol.com.cn/, 1
[70011:70022:0712/033413.591221:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[70011:70011:0712/033413.591258:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://teach.scol.com.cn/, HTTP/1.1 200 OK Content-Type: text/html Content-Encoding: gzip Last-Modified: Fri, 12 Jul 2019 06:24:49 GMT ETag: "7c5e19827a38d51:0" Vary: Accept-Encoding Server: Microsoft-IIS/8.0 Date: Fri, 12 Jul 2019 10:34:40 GMT Content-Length: 9231  ,70107, 5
[1:7:0712/033413.594971:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033413.629011:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://teach.scol.com.cn/
[1:1:0712/033413.677515:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033413.678382:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/033413.678644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19345db70640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/033413.678923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/033413.747345:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[70011:70011:0712/033413.798652:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://teach.scol.com.cn/, https://teach.scol.com.cn/, 1
[70011:70011:0712/033413.798771:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://teach.scol.com.cn/, https://teach.scol.com.cn
[1:1:0712/033413.832853:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033413.906944:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033413.907250:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://teach.scol.com.cn/"
[1:1:0712/033414.049514:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033414.205557:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f4c6d8b4080 0x1ecb88f52ba0 1 0 0x1ecb88f52bb8 , "https://teach.scol.com.cn/"
[1:1:0712/033414.213273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , /*! jQuery v1.12.4 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0712/033414.213549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033414.224525:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033414.420214:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f4c6d8b4080 0x1ecb88f52ba0 1 0 0x1ecb88f52bb8 , "https://teach.scol.com.cn/"
[1:1:0712/033414.518792:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/033414.660610:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/033414.675011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 176, "https://teach.scol.com.cn/"
[1:1:0712/033414.678518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , /*! myFocus v2.0.4 | http://cosmissy.com/ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?''
[1:1:0712/033414.678803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033414.858565:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/033414.929197:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://smallpdf.com/"
[1:1:0712/033415.046100:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://expedia.com/"
[1:1:0712/033415.183773:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 176, "https://teach.scol.com.cn/"
[1:1:0712/033415.196585:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://91jm.com/"
[1:1:0712/033415.244634:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 176, "https://teach.scol.com.cn/"
[1:1:0712/033415.331513:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://cimaclub.com/"
[1:1:0712/033415.411853:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yadi.sk/"
[1:1:0712/033415.460987:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.298997, 672, 1
[1:1:0712/033415.461280:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033416.022596:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033416.022911:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://teach.scol.com.cn/"
[1:1:0712/033416.026368:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f4c5722a070 0x1ecb8963ac60 , "https://teach.scol.com.cn/"
[1:1:0712/033416.027674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , document.writeln("<style>");
document.writeln("#copylink{width:100%; margin:0 auto; overflow:hidden
[1:1:0712/033416.027965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033416.041946:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/033416.045619:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1ecb88fe2420
[1:1:0712/033416.045841:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/033416.061385:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/033416.061647:INFO:render_frame_impl.cc(7019)] 	 [url] = https://teach.scol.com.cn
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/033416.712725:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289, "https://teach.scol.com.cn/"
[1:1:0712/033416.713831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , $(function () {
    var errLine, errMsg, errUrl, cssStyle = '';

    //错误处理
    window.o
[1:1:0712/033416.714069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033416.796509:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033416.798484:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033416.798857:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033416.799275:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033416.799662:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033417.278986:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033417.821662:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358 0x7f4c591522e0 0x1ecb896f7460 , "https://teach.scol.com.cn/"
[1:1:0712/033417.827381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (function(){var h={},mt={},c={id:"3655798ef3e7d6f0b0ffacdc386fa14d",dm:["scol.com.cn"],js:"tongji.ba
[1:1:0712/033417.827652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033417.851316:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c190
[1:1:0712/033417.851592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033417.851998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 387
[1:1:0712/033417.852225:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 387 0x7f4c5722a070 0x1ecb896f7b60 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 358 0x7f4c591522e0 0x1ecb896f7460 
[70011:70011:0712/033432.803553:INFO:CONSOLE(101)] "Mixed Content: The page at 'https://teach.scol.com.cn/' was loaded over HTTPS, but requested an insecure image 'http://teach.scol.com.cn/images/whf.jpg'. This content should also be served over HTTPS.", source: https://teach.scol.com.cn/ (101)
[70011:70011:0712/033432.812476:INFO:CONSOLE(106)] "Mixed Content: The page at 'https://teach.scol.com.cn/' was loaded over HTTPS, but requested an insecure image 'http://teach.scol.com.cn/images/whf.jpg'. This content should also be served over HTTPS.", source: https://teach.scol.com.cn/ (106)
[70011:70011:0712/033432.821486:INFO:CONSOLE(111)] "Mixed Content: The page at 'https://teach.scol.com.cn/' was loaded over HTTPS, but requested an insecure image 'http://teach.scol.com.cn/images/whf.jpg'. This content should also be served over HTTPS.", source: https://teach.scol.com.cn/ (111)
[70011:70011:0712/033432.829559:INFO:CONSOLE(116)] "Mixed Content: The page at 'https://teach.scol.com.cn/' was loaded over HTTPS, but requested an insecure image 'http://teach.scol.com.cn/images/yhf.jpg'. This content should also be served over HTTPS.", source: https://teach.scol.com.cn/ (116)
[70011:70011:0712/033432.869154:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[70011:70011:0712/033432.876781:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[70011:70011:0712/033432.890480:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://teach.scol.com.cn/
[70011:70011:0712/033433.032725:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/033433.047521:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[70011:70011:0712/033433.123007:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[70011:70011:0712/033433.129242:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[70011:70022:0712/033433.160620:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[70011:70022:0712/033433.160722:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[70011:70011:0712/033433.160968:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://special.scol.com.cn/
[70011:70011:0712/033433.161066:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://special.scol.com.cn/, https://special.scol.com.cn/siteinfo/sitestat1.asp, 4
[70011:70011:0712/033433.161238:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://special.scol.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 10:35:17 GMT Server: Microsoft-IIS/6.0 X-Powered-By: ASP.NET Content-Length: 0 Content-Type: text/html; Charset=GB2312 Cache-control: private  ,70107, 5
[1:7:0712/033433.165795:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033434.851984:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033434.852246:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://teach.scol.com.cn/"
[1:1:0712/033434.853594:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7f4c5722a070 0x1ecb891702e0 , "https://teach.scol.com.cn/"
[1:1:0712/033434.854664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , 
        myFocus.set({
            id: 'myFocus',
            pattern: 'mF_taobao2010'
        });
 
[1:1:0712/033434.855377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033434.883159:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x3cbbfd2a29c8, 0x1ecb88e6c1a0
[1:1:0712/033434.883474:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 10000
[1:1:0712/033434.883895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 489
[1:1:0712/033434.884192:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 489 0x7f4c5722a070 0x1ecb89896f60 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 368 0x7f4c5722a070 0x1ecb891702e0 
[1:1:0712/033434.907227:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7f4c5722a070 0x1ecb891702e0 , "https://teach.scol.com.cn/"
[1:1:0712/033434.923968:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7f4c5722a070 0x1ecb891702e0 , "https://teach.scol.com.cn/"
[1:1:0712/033434.931483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7f4c5722a070 0x1ecb891702e0 , "https://teach.scol.com.cn/"
[1:1:0712/033435.783207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/033435.783465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033436.270728:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://special.scol.com.cn/
[1:1:0712/033436.722398:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 387, 7f4c59b6f881
[1:1:0712/033436.745484:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"358 0x7f4c591522e0 0x1ecb896f7460 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033436.745837:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"358 0x7f4c591522e0 0x1ecb896f7460 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033436.746265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033436.746870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033436.747109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033436.747945:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033436.748175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033436.748580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 543
[1:1:0712/033436.748807:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 543 0x7f4c5722a070 0x1ecb8987b9e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 387 0x7f4c5722a070 0x1ecb896f7b60 
[1:1:0712/033437.367517:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514, "https://teach.scol.com.cn/"
[1:1:0712/033437.368424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , 
[1:1:0712/033437.368675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033437.371014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://teach.scol.com.cn/"
[1:1:0712/033437.413857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://teach.scol.com.cn/"
[1:1:0712/033437.430855:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 1000
[1:1:0712/033437.431308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 561
[1:1:0712/033437.431553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f4c5722a070 0x1ecb89e1cce0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 514
[1:1:0712/033437.433273:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c1e0
[1:1:0712/033437.433484:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033437.433900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 562
[1:1:0712/033437.434130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 562 0x7f4c5722a070 0x1ecb8963af60 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 514
[1:1:0712/033437.441880:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://teach.scol.com.cn/"
[1:1:0712/033437.649369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , document.readyState
[1:1:0712/033437.649706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[70011:70011:0712/033438.291964:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://special.scol.com.cn/, https://special.scol.com.cn/, 4
[70011:70011:0712/033438.292079:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://special.scol.com.cn/, https://special.scol.com.cn
[1:1:0712/033438.525608:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033438.526373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/033438.526595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033438.561815:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 543, 7f4c59b6f881
[1:1:0712/033438.584286:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"387 0x7f4c5722a070 0x1ecb896f7b60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033438.584650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"387 0x7f4c5722a070 0x1ecb896f7b60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033438.585096:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033438.585660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033438.585911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033438.586591:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033438.586783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033438.587156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 635
[1:1:0712/033438.587379:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f4c5722a070 0x1ecb89580360 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 543 0x7f4c5722a070 0x1ecb8987b9e0 
[1:1:0712/033438.714999:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7f4c591522e0 0x1ecb88ffce60 , "https://teach.scol.com.cn/"
[1:1:0712/033438.716617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , myFocus.pattern.extend({//*********************淘宝2010主页风格******************
	'mF_taobao
[1:1:0712/033438.716850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033438.718535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033438.821757:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 562, 7f4c59b6f881
[1:1:0712/033438.849118:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"514","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033438.849463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"514","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033438.849885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033438.850545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , ajaxpost, () {
        //收集客户端信息
        var fWidth = screen.width;
        var fHeight = scr
[1:1:0712/033438.850758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033439.241105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , document.readyState
[1:1:0712/033439.241409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033440.054536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 561, 7f4c59b6f8db
[1:1:0712/033440.063825:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"514","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033440.064013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"514","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033440.064224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 687
[1:1:0712/033440.064379:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f4c5722a070 0x1ecb89550a60 , 5:3_https://teach.scol.com.cn/, 0, , 561 0x7f4c5722a070 0x1ecb89e1cce0 
[1:1:0712/033440.064532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033440.064819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033440.064930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033440.288578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033440.289258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , d.onload, (){count+=1;arrSize[this.i]={w:this.width,h:this.height};if(count==len&&!done){done=true,a(arrSize)}
[1:1:0712/033440.289460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033440.311833:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033440.312249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , d.onload, (){count+=1;arrSize[this.i]={w:this.width,h:this.height};if(count==len&&!done){done=true,a(arrSize)}
[1:1:0712/033440.312382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033440.321745:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033440.322065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , d.onload, (){count+=1;arrSize[this.i]={w:this.width,h:this.height};if(count==len&&!done){done=true,a(arrSize)}
[1:1:0712/033440.322174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033440.340843:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033440.341292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , d.onload, (){count+=1;arrSize[this.i]={w:this.width,h:this.height};if(count==len&&!done){done=true,a(arrSize)}
[1:1:0712/033440.341457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033440.341965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 635, 7f4c59b6f881
[1:1:0712/033440.354231:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"543 0x7f4c5722a070 0x1ecb8987b9e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033440.354565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"543 0x7f4c5722a070 0x1ecb8987b9e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033440.354916:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033440.355493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033440.355670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033440.356307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033440.356495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033440.356825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 695
[1:1:0712/033440.357014:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f4c5722a070 0x1ecb89e1c2e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 635 0x7f4c5722a070 0x1ecb89580360 
[1:1:0712/033440.479059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , document.readyState
[1:1:0712/033440.479238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/033441.067656:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033441.068544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , d.onload, (){count+=1;arrSize[this.i]={w:this.width,h:this.height};if(count==len&&!done){done=true,a(arrSize)}
[1:1:0712/033441.068776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033441.250333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 13
[1:1:0712/033441.250782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 735
[1:1:0712/033441.251016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f4c5722a070 0x1ecb89544860 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 692 0x7f4c5722a070 0x1ecb89885160 
[1:1:0712/033441.252049:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 4000
[1:1:0712/033441.252486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 736
[1:1:0712/033441.252743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 736 0x7f4c5722a070 0x1ecb8a3b08e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 692 0x7f4c5722a070 0x1ecb89885160 
[1:1:0712/033441.415203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 687, 7f4c59b6f8db
[1:1:0712/033441.432075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"561 0x7f4c5722a070 0x1ecb89e1cce0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033441.432404:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"561 0x7f4c5722a070 0x1ecb89e1cce0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033441.432861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 741
[1:1:0712/033441.433100:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7f4c5722a070 0x1ecb8a39cd60 , 5:3_https://teach.scol.com.cn/, 0, , 687 0x7f4c5722a070 0x1ecb89550a60 
[1:1:0712/033441.433405:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033441.433981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033441.434195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033441.494544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 695, 7f4c59b6f881
[1:1:0712/033441.528017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"635 0x7f4c5722a070 0x1ecb89580360 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033441.528367:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"635 0x7f4c5722a070 0x1ecb89580360 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033441.528794:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033441.529376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033441.529588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033441.530292:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033441.530489:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033441.530864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 742
[1:1:0712/033441.531101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f4c5722a070 0x1ecb8954f5e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 695 0x7f4c5722a070 0x1ecb89e1c2e0 
[1:1:0712/033441.549965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , document.readyState
[1:1:0712/033441.550272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033441.647709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 705 0x7f4c591522e0 0x1ecb88fb82e0 , "https://teach.scol.com.cn/"
[1:1:0712/033441.648620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , jQuery11240399633122463372_1562927655341([])
[1:1:0712/033441.648880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033441.649757:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033442.526158:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033442.526907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/033442.527129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033442.527577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://teach.scol.com.cn/"
[1:1:0712/033442.531285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://teach.scol.com.cn/"
[1:1:0712/033442.532381:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c2f0
[1:1:0712/033442.532608:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033442.533053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 757
[1:1:0712/033442.533364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7f4c5722a070 0x1ecb8956d460 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 732 0x7f4c5722a070 0x1ecb895661e0 
[1:1:0712/033442.554281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 735, 7f4c59b6f8db
[1:1:0712/033442.585775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"692 0x7f4c5722a070 0x1ecb89885160 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033442.586174:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"692 0x7f4c5722a070 0x1ecb89885160 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033442.586606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 761
[1:1:0712/033442.586848:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7f4c5722a070 0x1ecb88bae060 , 5:3_https://teach.scol.com.cn/, 0, , 735 0x7f4c5722a070 0x1ecb89544860 
[1:1:0712/033442.587175:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033442.587713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0712/033442.587976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033442.688255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , document.readyState
[1:1:0712/033442.688549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033442.858829:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 741, 7f4c59b6f8db
[1:1:0712/033442.892616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"687 0x7f4c5722a070 0x1ecb89550a60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033442.892954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"687 0x7f4c5722a070 0x1ecb89550a60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033442.893461:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 775
[1:1:0712/033442.893692:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7f4c5722a070 0x1ecb89577ae0 , 5:3_https://teach.scol.com.cn/, 0, , 741 0x7f4c5722a070 0x1ecb8a39cd60 
[1:1:0712/033442.894018:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033442.894570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033442.894785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033443.069454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 757, 7f4c59b6f881
[1:1:0712/033443.101818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"732 0x7f4c5722a070 0x1ecb895661e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.102212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"732 0x7f4c5722a070 0x1ecb895661e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.102608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033443.103188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033443.103418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033443.104192:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033443.104394:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033443.104764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 780
[1:1:0712/033443.104990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f4c5722a070 0x1ecb89893560 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 757 0x7f4c5722a070 0x1ecb8956d460 
[1:1:0712/033443.475045:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 780, 7f4c59b6f881
[1:1:0712/033443.507685:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"757 0x7f4c5722a070 0x1ecb8956d460 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.508049:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"757 0x7f4c5722a070 0x1ecb8956d460 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.508494:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033443.509062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033443.509300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033443.509983:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033443.510222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033443.510607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 791
[1:1:0712/033443.510835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7f4c5722a070 0x1ecb898b6660 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 780 0x7f4c5722a070 0x1ecb89893560 
[1:1:0712/033443.547665:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 775, 7f4c59b6f8db
[1:1:0712/033443.580513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"741 0x7f4c5722a070 0x1ecb8a39cd60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.580870:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"741 0x7f4c5722a070 0x1ecb8a39cd60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.581375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 794
[1:1:0712/033443.581607:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7f4c5722a070 0x1ecb89e13160 , 5:3_https://teach.scol.com.cn/, 0, , 775 0x7f4c5722a070 0x1ecb89577ae0 
[1:1:0712/033443.581895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033443.582455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033443.582667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033443.776809:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","https://teach.scol.com.cn/favicon.ico"
[1:1:0712/033443.812493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 791, 7f4c59b6f881
[1:1:0712/033443.845527:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"780 0x7f4c5722a070 0x1ecb89893560 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.845949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"780 0x7f4c5722a070 0x1ecb89893560 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033443.846538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033443.847132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033443.847377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033443.848062:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033443.848303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033443.848823:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 805
[1:1:0712/033443.849049:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7f4c5722a070 0x1ecb89870360 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 791 0x7f4c5722a070 0x1ecb898b6660 
[1:1:0712/033444.021439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 805, 7f4c59b6f881
[1:1:0712/033444.054412:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"791 0x7f4c5722a070 0x1ecb898b6660 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.054793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"791 0x7f4c5722a070 0x1ecb898b6660 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.055182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033444.055769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033444.056024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033444.056725:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033444.056932:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033444.057328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 812
[1:1:0712/033444.057557:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7f4c5722a070 0x1ecb89550a60 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 805 0x7f4c5722a070 0x1ecb89870360 
[1:1:0712/033444.241115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 812, 7f4c59b6f881
[1:1:0712/033444.275273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"805 0x7f4c5722a070 0x1ecb89870360 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.275682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"805 0x7f4c5722a070 0x1ecb89870360 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.276099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033444.276679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033444.276895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033444.283020:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033444.283247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033444.283663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 821
[1:1:0712/033444.283929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f4c5722a070 0x1ecb89029760 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 812 0x7f4c5722a070 0x1ecb89550a60 
[1:1:0712/033444.404020:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 821, 7f4c59b6f881
[1:1:0712/033444.437898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"812 0x7f4c5722a070 0x1ecb89550a60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.438285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"812 0x7f4c5722a070 0x1ecb89550a60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.438657:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033444.439217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033444.439444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033444.440127:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033444.440382:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033444.440767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 825
[1:1:0712/033444.440998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 825 0x7f4c5722a070 0x1ecb8a3e9960 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 821 0x7f4c5722a070 0x1ecb89029760 
[1:1:0712/033444.442658:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 794, 7f4c59b6f8db
[1:1:0712/033444.477077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"775 0x7f4c5722a070 0x1ecb89577ae0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.477442:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"775 0x7f4c5722a070 0x1ecb89577ae0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.477810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 828
[1:1:0712/033444.478038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7f4c5722a070 0x1ecb8a628960 , 5:3_https://teach.scol.com.cn/, 0, , 794 0x7f4c5722a070 0x1ecb89e13160 
[1:1:0712/033444.478328:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033444.478881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033444.479094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033444.643540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 825, 7f4c59b6f881
[1:1:0712/033444.655061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"821 0x7f4c5722a070 0x1ecb89029760 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.655377:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"821 0x7f4c5722a070 0x1ecb89029760 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.655736:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033444.656352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033444.656605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033444.657368:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033444.657603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033444.657980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 836
[1:1:0712/033444.658207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 836 0x7f4c5722a070 0x1ecb8896d5e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 825 0x7f4c5722a070 0x1ecb8a3e9960 
[1:1:0712/033444.790510:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 836, 7f4c59b6f881
[1:1:0712/033444.824691:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"825 0x7f4c5722a070 0x1ecb8a3e9960 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.825090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"825 0x7f4c5722a070 0x1ecb8a3e9960 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.825429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033444.826009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033444.826227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033444.826942:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033444.827145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033444.827535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 843
[1:1:0712/033444.827765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 843 0x7f4c5722a070 0x1ecb891005e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 836 0x7f4c5722a070 0x1ecb8896d5e0 
[1:1:0712/033444.919748:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 489, 7f4c59b6f881
[1:1:0712/033444.954182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"368 0x7f4c5722a070 0x1ecb891702e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.954603:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"368 0x7f4c5722a070 0x1ecb891702e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033444.954983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033444.955563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){if(!isSuccess)q(p.id).innerHTML='加载失败: '+src}
[1:1:0712/033444.955793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.061922:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 843, 7f4c59b6f881
[1:1:0712/033445.096013:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"836 0x7f4c5722a070 0x1ecb8896d5e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.096384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"836 0x7f4c5722a070 0x1ecb8896d5e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.096724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.097343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033445.097571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.098254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033445.098448:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033445.098848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 855
[1:1:0712/033445.099074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 855 0x7f4c5722a070 0x1ecb8987fde0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 843 0x7f4c5722a070 0x1ecb891005e0 
[1:1:0712/033445.204812:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 855, 7f4c59b6f881
[1:1:0712/033445.239414:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"843 0x7f4c5722a070 0x1ecb891005e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.239867:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"843 0x7f4c5722a070 0x1ecb891005e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.240242:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.240839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033445.241055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.241769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033445.241967:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033445.242340:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 862
[1:1:0712/033445.242601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f4c5722a070 0x1ecb895639e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 855 0x7f4c5722a070 0x1ecb8987fde0 
[1:1:0712/033445.278668:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 736, 7f4c59b6f8db
[1:1:0712/033445.313213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"692 0x7f4c5722a070 0x1ecb89885160 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.313579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"692 0x7f4c5722a070 0x1ecb89885160 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.314056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 866
[1:1:0712/033445.314304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 866 0x7f4c5722a070 0x1ecb89117d60 , 5:3_https://teach.scol.com.cn/, 0, , 736 0x7f4c5722a070 0x1ecb8a3b08e0 
[1:1:0712/033445.314637:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.315157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){f.run('+=1')}
[1:1:0712/033445.315369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.318917:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 13
[1:1:0712/033445.319286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 868
[1:1:0712/033445.319509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f4c5722a070 0x1ecb8a624d60 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 736 0x7f4c5722a070 0x1ecb8a3b08e0 
[1:1:0712/033445.424786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 868, 7f4c59b6f8db
[1:1:0712/033445.446746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"736 0x7f4c5722a070 0x1ecb8a3b08e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.447088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"736 0x7f4c5722a070 0x1ecb8a3b08e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.447482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 881
[1:1:0712/033445.447788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 881 0x7f4c5722a070 0x1ecb8905eee0 , 5:3_https://teach.scol.com.cn/, 0, , 868 0x7f4c5722a070 0x1ecb8a624d60 
[1:1:0712/033445.448117:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.448722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0712/033445.448986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.451855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 862, 7f4c59b6f881
[1:1:0712/033445.489155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"855 0x7f4c5722a070 0x1ecb8987fde0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.489546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"855 0x7f4c5722a070 0x1ecb8987fde0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.489968:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.490557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033445.490800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.491488:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033445.491715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033445.492131:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 884
[1:1:0712/033445.492370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f4c5722a070 0x1ecb8a68a5e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 862 0x7f4c5722a070 0x1ecb895639e0 
[1:1:0712/033445.775643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 828, 7f4c59b6f8db
[1:1:0712/033445.790167:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"794 0x7f4c5722a070 0x1ecb89e13160 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.790480:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"794 0x7f4c5722a070 0x1ecb89e13160 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.790856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 889
[1:1:0712/033445.791090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 889 0x7f4c5722a070 0x1ecb88baef60 , 5:3_https://teach.scol.com.cn/, 0, , 828 0x7f4c5722a070 0x1ecb8a628960 
[1:1:0712/033445.791395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.791986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033445.792203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.803564:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 881, 7f4c59b6f8db
[1:1:0712/033445.847877:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"868 0x7f4c5722a070 0x1ecb8a624d60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.848265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"868 0x7f4c5722a070 0x1ecb8a624d60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.848635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 891
[1:1:0712/033445.848887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 891 0x7f4c5722a070 0x1ecb8a5261e0 , 5:3_https://teach.scol.com.cn/, 0, , 881 0x7f4c5722a070 0x1ecb8905eee0 
[1:1:0712/033445.849228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.849800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0712/033445.850021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.852440:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 884, 7f4c59b6f881
[1:1:0712/033445.887837:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"862 0x7f4c5722a070 0x1ecb895639e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.888217:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"862 0x7f4c5722a070 0x1ecb895639e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033445.888538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033445.889118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033445.889343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033445.890056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033445.890259:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033445.890634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 892
[1:1:0712/033445.890872:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f4c5722a070 0x1ecb89e506e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 884 0x7f4c5722a070 0x1ecb8a68a5e0 
[1:1:0712/033446.001121:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 891, 7f4c59b6f8db
[1:1:0712/033446.025288:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"881 0x7f4c5722a070 0x1ecb8905eee0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.025618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"881 0x7f4c5722a070 0x1ecb8905eee0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.026034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 895
[1:1:0712/033446.026290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7f4c5722a070 0x1ecb89f95e60 , 5:3_https://teach.scol.com.cn/, 0, , 891 0x7f4c5722a070 0x1ecb8a5261e0 
[1:1:0712/033446.026611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.027170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){var t=(new Date)-origTime;if(t<=d){setProperty.call(k,e(t,b,c,d),a,m)}else{setProperty.call(k,b+c
[1:1:0712/033446.027384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.029722:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 892, 7f4c59b6f881
[1:1:0712/033446.064794:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"884 0x7f4c5722a070 0x1ecb8a68a5e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.065175:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"884 0x7f4c5722a070 0x1ecb8a68a5e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.065498:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.066123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033446.066338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.067046:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033446.067244:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033446.067613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 896
[1:1:0712/033446.067901:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7f4c5722a070 0x1ecb8a624ee0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 892 0x7f4c5722a070 0x1ecb89e506e0 
[1:1:0712/033446.187980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 896, 7f4c59b6f881
[1:1:0712/033446.223247:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"892 0x7f4c5722a070 0x1ecb89e506e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.223684:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"892 0x7f4c5722a070 0x1ecb89e506e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.224168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.224788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033446.225123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.225929:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033446.226194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033446.226626:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 898
[1:1:0712/033446.226930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 898 0x7f4c5722a070 0x1ecb898b74e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 896 0x7f4c5722a070 0x1ecb8a624ee0 
[1:1:0712/033446.363320:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 898, 7f4c59b6f881
[1:1:0712/033446.408905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"896 0x7f4c5722a070 0x1ecb8a624ee0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.409293:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"896 0x7f4c5722a070 0x1ecb8a624ee0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.409614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.410241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033446.410459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.411167:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033446.411365:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033446.411736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 900
[1:1:0712/033446.412067:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7f4c5722a070 0x1ecb890901e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 898 0x7f4c5722a070 0x1ecb898b74e0 
[1:1:0712/033446.498535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 889, 7f4c59b6f8db
[1:1:0712/033446.534245:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"828 0x7f4c5722a070 0x1ecb8a628960 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.534573:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"828 0x7f4c5722a070 0x1ecb8a628960 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.534950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 904
[1:1:0712/033446.535190:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 904 0x7f4c5722a070 0x1ecb8905eee0 , 5:3_https://teach.scol.com.cn/, 0, , 889 0x7f4c5722a070 0x1ecb88baef60 
[1:1:0712/033446.535476:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.536066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033446.536289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.562569:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 900, 7f4c59b6f881
[1:1:0712/033446.596965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"898 0x7f4c5722a070 0x1ecb898b74e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.597355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"898 0x7f4c5722a070 0x1ecb898b74e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.597711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.598193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033446.598415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.599106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033446.599303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033446.599804:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 907
[1:1:0712/033446.600188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7f4c5722a070 0x1ecb88bb0a60 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 900 0x7f4c5722a070 0x1ecb890901e0 
[1:1:0712/033446.738431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 907, 7f4c59b6f881
[1:1:0712/033446.773070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"900 0x7f4c5722a070 0x1ecb890901e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.773441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"900 0x7f4c5722a070 0x1ecb890901e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.773787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.774389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033446.774600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.775298:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033446.775488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033446.775844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 909
[1:1:0712/033446.776152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7f4c5722a070 0x1ecb8a5648e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 907 0x7f4c5722a070 0x1ecb88bb0a60 
[1:1:0712/033446.892803:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 909, 7f4c59b6f881
[1:1:0712/033446.930881:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"907 0x7f4c5722a070 0x1ecb88bb0a60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.931266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"907 0x7f4c5722a070 0x1ecb88bb0a60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033446.931592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033446.932204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033446.932413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033446.933142:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033446.933350:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033446.933707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 911
[1:1:0712/033446.933925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 911 0x7f4c5722a070 0x1ecb8a626860 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 909 0x7f4c5722a070 0x1ecb8a5648e0 
[1:1:0712/033447.053361:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 911, 7f4c59b6f881
[1:1:0712/033447.072462:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"909 0x7f4c5722a070 0x1ecb8a5648e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.072828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"909 0x7f4c5722a070 0x1ecb8a5648e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.073176:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033447.073785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033447.073996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033447.074699:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033447.074894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033447.075282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 913
[1:1:0712/033447.075524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 913 0x7f4c5722a070 0x1ecb897b1960 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 911 0x7f4c5722a070 0x1ecb8a626860 
[1:1:0712/033447.222926:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 913, 7f4c59b6f881
[1:1:0712/033447.263583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"911 0x7f4c5722a070 0x1ecb8a626860 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.264008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"911 0x7f4c5722a070 0x1ecb8a626860 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.264386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033447.264929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033447.265151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033447.265808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033447.265997:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033447.266463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 915
[1:1:0712/033447.266696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 915 0x7f4c5722a070 0x1ecb8a68a5e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 913 0x7f4c5722a070 0x1ecb897b1960 
[1:1:0712/033447.407402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 915, 7f4c59b6f881
[1:1:0712/033447.431564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"913 0x7f4c5722a070 0x1ecb897b1960 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.431909:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"913 0x7f4c5722a070 0x1ecb897b1960 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.432236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033447.432815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033447.433019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033447.433685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033447.433875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033447.434248:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 917
[1:1:0712/033447.434483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7f4c5722a070 0x1ecb89e1cce0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 915 0x7f4c5722a070 0x1ecb8a68a5e0 
[1:1:0712/033447.435720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 904, 7f4c59b6f8db
[1:1:0712/033447.470387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"889 0x7f4c5722a070 0x1ecb88baef60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.470718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"889 0x7f4c5722a070 0x1ecb88baef60 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.471066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://teach.scol.com.cn/, 919
[1:1:0712/033447.471338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7f4c5722a070 0x1ecb88d424e0 , 5:3_https://teach.scol.com.cn/, 0, , 904 0x7f4c5722a070 0x1ecb8905eee0 
[1:1:0712/033447.471638:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033447.472211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , , (){
		$(".yxtposter").css({"margin-bottom":"2px"});
	}
[1:1:0712/033447.472424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033447.593001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 917, 7f4c59b6f881
[1:1:0712/033447.627351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d1f5fce2860","ptid":"915 0x7f4c5722a070 0x1ecb8a68a5e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.627740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://teach.scol.com.cn/","ptid":"915 0x7f4c5722a070 0x1ecb8a68a5e0 ","rf":"5:3_https://teach.scol.com.cn/"}
[1:1:0712/033447.628105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://teach.scol.com.cn/"
[1:1:0712/033447.628695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://teach.scol.com.cn/, 0d1f5fce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033447.628910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://teach.scol.com.cn/", "teach.scol.com.cn", 3, 1, , , 0
[1:1:0712/033447.629614:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3cbbfd2a29c8, 0x1ecb88e6c150
[1:1:0712/033447.629812:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://teach.scol.com.cn/", 100
[1:1:0712/033447.630218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://teach.scol.com.cn/, 925
[1:1:0712/033447.630456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7f4c5722a070 0x1ecb89f955e0 , 5:3_https://teach.scol.com.cn/, 1, -5:3_https://teach.scol.com.cn/, 917 0x7f4c5722a070 0x1ecb89e1cce0 
