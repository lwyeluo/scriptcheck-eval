[0712/033603.805325:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033603.807237:INFO:switcher_clone.cc(787)] backtrace rip is 7f5b5d224891
[0712/033604.914051:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033604.914406:INFO:switcher_clone.cc(787)] backtrace rip is 7fce4c4f0891
[1:1:0712/033604.926061:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/033604.926318:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/033604.932430:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[70274:70274:0712/033606.094298:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/827cada8-922d-4269-b2d8-c893a5c6b9e5
[0712/033606.353430:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033606.353694:INFO:switcher_clone.cc(787)] backtrace rip is 7fa4d88f5891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[70274:70274:0712/033606.487014:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[70274:70303:0712/033606.487970:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/033606.488252:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/033606.488509:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/033606.489239:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/033606.489444:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/033606.492805:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26f841de, 1
[1:1:0712/033606.493220:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x365e55a0, 0
[1:1:0712/033606.493421:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x11585d37, 3
[1:1:0712/033606.493617:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x280fbfb1, 2
[1:1:0712/033606.493882:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa0555e36 ffffffde41fffffff826 ffffffb1ffffffbf0f28 375d5811 , 10104, 4
[1:1:0712/033606.495097:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[70274:70303:0712/033606.495362:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�U^6�A�&��(7]X�X>
[70274:70303:0712/033606.495431:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �U^6�A�&��(7]X8g�X>
[1:1:0712/033606.495357:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce4a72b0a0, 3
[1:1:0712/033606.495603:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce4a8b6080, 2
[70274:70303:0712/033606.495718:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[70274:70303:0712/033606.495799:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 70320, 4, a0555e36 de41f826 b1bf0f28 375d5811 
[1:1:0712/033606.495789:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce34579d20, -2
[1:1:0712/033606.517978:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/033606.519023:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 280fbfb1
[1:1:0712/033606.520188:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 280fbfb1
[1:1:0712/033606.522083:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 280fbfb1
[1:1:0712/033606.523897:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.524197:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.524442:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.524691:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.525498:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 280fbfb1
[1:1:0712/033606.525892:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce4c4f07ba
[1:1:0712/033606.526090:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce4c4e7def, 7fce4c4f077a, 7fce4c4f20cf
[1:1:0712/033606.533032:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 280fbfb1
[1:1:0712/033606.533486:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 280fbfb1
[1:1:0712/033606.534380:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 280fbfb1
[1:1:0712/033606.536851:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.537110:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.537380:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.537592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280fbfb1
[1:1:0712/033606.538842:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 280fbfb1
[1:1:0712/033606.539226:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce4c4f07ba
[1:1:0712/033606.539365:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce4c4e7def, 7fce4c4f077a, 7fce4c4f20cf
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/033606.547114:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/033606.547604:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/033606.547748:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe31c8bea8, 0x7ffe31c8be28)
[70305:70305:0712/033606.561453:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=70305
[70327:70327:0712/033606.562191:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=70327
[1:1:0712/033606.563611:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/033606.569459:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[70274:70274:0712/033607.090114:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[70274:70274:0712/033607.091522:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[70274:70285:0712/033607.104298:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[70274:70285:0712/033607.104402:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[70274:70274:0712/033607.104546:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[70274:70274:0712/033607.104625:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[70274:70274:0712/033607.104768:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,70320, 4
[1:7:0712/033607.106463:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[70274:70296:0712/033607.170526:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/033607.263220:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x18b093299220
[1:1:0712/033607.263484:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/033607.505072:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[70274:70274:0712/033609.034759:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[70274:70274:0712/033609.034908:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/033609.080258:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033609.083931:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033609.938629:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3436d5d61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/033609.938816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033609.947469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3436d5d61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/033609.947595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033609.971135:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033610.284486:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033610.284707:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033610.706405:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033610.711578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3436d5d61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/033610.711788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033610.746851:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033610.757423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3436d5d61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/033610.757656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033610.769425:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[70274:70274:0712/033610.772109:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/033610.772782:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x18b093297e20
[1:1:0712/033610.772944:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[70274:70274:0712/033610.779372:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[70274:70274:0712/033610.811742:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[70274:70274:0712/033610.811950:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/033610.866847:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033611.765269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7fce361542e0 0x18b0934f76e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033611.766607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3436d5d61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/033611.766802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033611.768263:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[70274:70274:0712/033611.838665:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/033611.840913:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x18b093298820
[1:1:0712/033611.841125:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/033611.851063:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/033611.851235:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[70274:70274:0712/033611.852726:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[70274:70274:0712/033611.872582:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[70274:70274:0712/033611.885179:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[70274:70274:0712/033611.886239:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[70274:70285:0712/033611.892272:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[70274:70285:0712/033611.892385:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[70274:70274:0712/033611.892622:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[70274:70274:0712/033611.892715:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[70274:70274:0712/033611.892884:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,70320, 4
[1:7:0712/033611.901762:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033612.314898:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/033612.646030:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7fce361542e0 0x18b0933234e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033612.647083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3436d5d61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/033612.647328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033612.648117:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[70274:70274:0712/033612.852059:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[70274:70274:0712/033612.852213:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/033612.884171:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033613.223485:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033613.695262:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033613.695531:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[70274:70274:0712/033613.781578:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[70274:70303:0712/033613.782118:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/033613.782309:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/033613.782577:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/033613.783086:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/033613.783259:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/033613.786688:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x5575f1, 1
[1:1:0712/033613.787119:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x323ce015, 0
[1:1:0712/033613.787323:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1db90a92, 3
[1:1:0712/033613.787528:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x19ffb2b1, 2
[1:1:0712/033613.787718:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 15ffffffe03c32 fffffff1755500 ffffffb1ffffffb2ffffffff19 ffffff920affffffb91d , 10104, 5
[1:1:0712/033613.788790:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[70274:70303:0712/033613.789064:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�<2�uU
[70274:70303:0712/033613.789131:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �<2�uU
[1:1:0712/033613.789254:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce4a72b0a0, 3
[70274:70303:0712/033613.789425:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 70372, 5, 15e03c32 f1755500 b1b2ff19 920ab91d 
[1:1:0712/033613.789463:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce4a8b6080, 2
[1:1:0712/033613.789705:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce34579d20, -2
[1:1:0712/033613.812674:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/033613.813105:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19ffb2b1
[1:1:0712/033613.813488:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19ffb2b1
[1:1:0712/033613.814281:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19ffb2b1
[1:1:0712/033613.816041:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.816273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.816503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.816722:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.817527:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19ffb2b1
[1:1:0712/033613.817877:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce4c4f07ba
[1:1:0712/033613.818064:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce4c4e7def, 7fce4c4f077a, 7fce4c4f20cf
[1:1:0712/033613.825037:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19ffb2b1
[1:1:0712/033613.825508:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19ffb2b1
[1:1:0712/033613.826416:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19ffb2b1
[1:1:0712/033613.828954:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.829222:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.829456:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.829651:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ffb2b1
[1:1:0712/033613.830888:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19ffb2b1
[1:1:0712/033613.831361:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce4c4f07ba
[1:1:0712/033613.831532:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce4c4e7def, 7fce4c4f077a, 7fce4c4f20cf
[1:1:0712/033613.841291:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/033613.841856:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/033613.842147:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe31c8bea8, 0x7ffe31c8be28)
[1:1:0712/033613.856441:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/033613.856619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033613.860997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3436d5e909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/033613.861295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/033613.862370:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/033613.868792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033614.113706:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x18b093271220
[1:1:0712/033614.113963:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[70274:70274:0712/033614.268664:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[70274:70274:0712/033614.273619:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[70274:70285:0712/033614.307551:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[70274:70285:0712/033614.307675:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[70274:70274:0712/033614.308002:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://digest.scol.com.cn/
[70274:70274:0712/033614.308123:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://digest.scol.com.cn/, http://digest.scol.com.cn/, 1
[70274:70274:0712/033614.308256:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://digest.scol.com.cn/, HTTP/1.1 200 OK Content-Type: text/html Last-Modified: Sun, 15 Aug 2010 16:40:31 GMT Accept-Ranges: bytes ETag: "f6d91d93983ccb1:0" Server: Microsoft-IIS/7.5 X-Powered-By: ASP.NET Date: Fri, 12 Jul 2019 10:35:17 GMT Content-Length: 421  ,70372, 5
[1:7:0712/033614.319147:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033614.363154:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://digest.scol.com.cn/
[1:1:0712/033614.443459:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[70274:70274:0712/033614.462833:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://digest.scol.com.cn/, http://digest.scol.com.cn/, 1
[70274:70274:0712/033614.462942:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://digest.scol.com.cn/, http://digest.scol.com.cn
[1:1:0712/033614.501024:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033614.583061:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033614.583281:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://digest.scol.com.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/033616.134235:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033616.134732:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033616.135093:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033616.141096:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033616.141455:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033634.245221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://digest.scol.com.cn/, 0fc772862860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/033634.245578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://digest.scol.com.cn/", "digest.scol.com.cn", 3, 1, , , 0
[1:1:0712/033634.249863:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[70274:70274:0712/033634.691076:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/033635.853177:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/033636.647563:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://digest.scol.com.cn/favicon.ico"
