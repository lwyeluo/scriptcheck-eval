[0712/032509.904328:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/032509.904775:INFO:switcher_clone.cc(787)] backtrace rip is 7f20c389f891
[0712/032511.014283:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/032511.014673:INFO:switcher_clone.cc(787)] backtrace rip is 7f87ef365891
[1:1:0712/032511.026431:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/032511.026686:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/032511.031969:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/032512.395816:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/032512.396082:INFO:switcher_clone.cc(787)] backtrace rip is 7f5976dda891
[68861:68861:0712/032512.477493:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/790e0656-e308-4a57-80d4-a33554ca0553
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[68893:68893:0712/032512.645101:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68893
[68904:68904:0712/032512.645527:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68904
[68861:68861:0712/032513.037353:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[68861:68890:0712/032513.038073:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/032513.038291:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/032513.038527:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/032513.039102:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/032513.039241:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/032513.042047:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2478f599, 1
[1:1:0712/032513.042349:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x10fac835, 0
[1:1:0712/032513.042529:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x18245a2a, 3
[1:1:0712/032513.042681:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e3d6842, 2
[1:1:0712/032513.042877:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 35ffffffc8fffffffa10 ffffff99fffffff57824 42683d2e 2a5a2418 , 10104, 4
[1:1:0712/032513.043789:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68861:68890:0712/032513.044009:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING5����x$Bh=.*Z$��P>
[68861:68890:0712/032513.044081:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 5����x$Bh=.*Z$����P>
[1:1:0712/032513.044019:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f87ed5a00a0, 3
[1:1:0712/032513.044221:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f87ed72b080, 2
[68861:68890:0712/032513.044437:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/032513.044385:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f87d73eed20, -2
[68861:68890:0712/032513.044514:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 68912, 4, 35c8fa10 99f57824 42683d2e 2a5a2418 
[1:1:0712/032513.062176:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/032513.062992:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e3d6842
[1:1:0712/032513.063919:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e3d6842
[1:1:0712/032513.065461:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e3d6842
[1:1:0712/032513.066880:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.067057:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.067231:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.067430:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.068030:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e3d6842
[1:1:0712/032513.068328:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f87ef3657ba
[1:1:0712/032513.068556:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f87ef35cdef, 7f87ef36577a, 7f87ef3670cf
[1:1:0712/032513.073984:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e3d6842
[1:1:0712/032513.074310:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e3d6842
[1:1:0712/032513.075000:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e3d6842
[1:1:0712/032513.076921:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.077130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.077306:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.077512:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e3d6842
[1:1:0712/032513.078702:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e3d6842
[1:1:0712/032513.079043:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f87ef3657ba
[1:1:0712/032513.079168:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f87ef35cdef, 7f87ef36577a, 7f87ef3670cf
[1:1:0712/032513.086492:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/032513.086914:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/032513.087068:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe8342d058, 0x7ffe8342cfd8)
[1:1:0712/032513.102452:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/032513.107961:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[68861:68861:0712/032513.740732:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68861:68861:0712/032513.742103:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68861:68871:0712/032513.754754:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[68861:68871:0712/032513.754855:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[68861:68861:0712/032513.755002:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[68861:68861:0712/032513.755080:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[68861:68861:0712/032513.755219:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,68912, 4
[1:7:0712/032513.757552:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[68861:68884:0712/032513.787854:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/032513.829833:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3616f0bf8220
[1:1:0712/032513.830065:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/032514.257416:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[68861:68861:0712/032515.531272:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[68861:68861:0712/032515.531346:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/032515.578606:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032515.582035:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032516.522745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ac21dce1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/032516.523031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032516.552835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ac21dce1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/032516.553105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032516.615499:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032516.758270:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032516.758446:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032517.010226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032517.018216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ac21dce1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/032517.018415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032517.043802:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032517.054200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ac21dce1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/032517.054395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032517.066058:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[68861:68861:0712/032517.068127:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/032517.069755:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3616f0bf6e20
[1:1:0712/032517.069963:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[68861:68861:0712/032517.071677:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[68861:68861:0712/032517.116567:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[68861:68861:0712/032517.116776:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/032517.124839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032518.005822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f87d8fc92e0 0x3616f0ec1660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032518.006552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ac21dce1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/032518.006712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032518.007290:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68861:68861:0712/032518.041050:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/032518.043394:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3616f0bf7820
[1:1:0712/032518.043601:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[68861:68861:0712/032518.049763:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/032518.063393:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/032518.063657:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[68861:68861:0712/032518.075612:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[68861:68861:0712/032518.087002:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68861:68861:0712/032518.088301:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68861:68871:0712/032518.095815:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[68861:68871:0712/032518.095950:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[68861:68861:0712/032518.096049:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[68861:68861:0712/032518.096148:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[68861:68861:0712/032518.096319:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,68912, 4
[1:7:0712/032518.100978:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/032518.765387:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/032519.405178:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f87d8fc92e0 0x3616f0d1ed60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032519.406260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ac21dce1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/032519.406488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032519.407259:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68861:68861:0712/032519.601114:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[68861:68861:0712/032519.601249:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/032519.640172:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032520.139430:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[68861:68861:0712/032520.421143:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[68861:68890:0712/032520.421636:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/032520.421831:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/032520.422077:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/032520.422538:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/032520.422734:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/032520.425920:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2b61b41e, 1
[1:1:0712/032520.426318:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x246c1562, 0
[1:1:0712/032520.426629:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2a558a50, 3
[1:1:0712/032520.426907:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xdaa3026, 2
[1:1:0712/032520.427091:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 62156c24 1effffffb4612b 2630ffffffaa0d 50ffffff8a552a , 10104, 5
[1:1:0712/032520.428089:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68861:68890:0712/032520.428326:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGbl$�a+&0�P�U*��P>
[68861:68890:0712/032520.428420:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is bl$�a+&0�P�U*HC��P>
[68861:68890:0712/032520.428715:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 68957, 5, 62156c24 1eb4612b 2630aa0d 508a552a 
[1:1:0712/032520.428543:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f87ed5a00a0, 3
[1:1:0712/032520.429110:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f87ed72b080, 2
[1:1:0712/032520.429381:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f87d73eed20, -2
[1:1:0712/032520.450735:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/032520.451116:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal daa3026
[1:1:0712/032520.451510:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal daa3026
[1:1:0712/032520.452177:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal daa3026
[1:1:0712/032520.453859:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.454086:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.454299:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.454522:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.455205:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal daa3026
[1:1:0712/032520.455552:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f87ef3657ba
[1:1:0712/032520.455723:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f87ef35cdef, 7f87ef36577a, 7f87ef3670cf
[1:1:0712/032520.461627:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal daa3026
[1:1:0712/032520.462042:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal daa3026
[1:1:0712/032520.462816:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal daa3026
[1:1:0712/032520.464896:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.465153:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.465391:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.465626:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal daa3026
[1:1:0712/032520.466897:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal daa3026
[1:1:0712/032520.467292:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f87ef3657ba
[1:1:0712/032520.467481:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f87ef35cdef, 7f87ef36577a, 7f87ef3670cf
[1:1:0712/032520.475232:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/032520.475811:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/032520.476052:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe8342d058, 0x7ffe8342cfd8)
[1:1:0712/032520.490110:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/032520.494423:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/032520.675286:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3616f0bd1220
[1:1:0712/032520.675587:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/032520.817919:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032520.818229:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[68861:68861:0712/032521.111432:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68861:68861:0712/032521.116398:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68861:68871:0712/032521.151754:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[68861:68871:0712/032521.151862:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[68861:68861:0712/032521.152386:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.nmgnews.com.cn/
[68861:68861:0712/032521.152486:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.nmgnews.com.cn/, http://www.nmgnews.com.cn/, 1
[68861:68861:0712/032521.152676:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.nmgnews.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 10:25:19 GMT Server: Apache X-Frame-Options: SAMEORIGIN, DENY Last-Modified: Fri, 12 Jul 2019 10:22:20 GMT ETag: "1a0038-123e4-58d794919ced9" Accept-Ranges: bytes Vary: Accept-Encoding Content-Encoding: gzip Content-Length: 16865 Content-Type: text/html; charset=UTF-8 Set-Cookie: yunsuo_session_verify=9d32bc3d0b19a2f7828f5f2e64c09258; expires=Mon, 15-Jul-19 18:25:19 GMT; path=/; HttpOnly Set-Cookie: yunsuo_session_verify=9d32bc3d0b19a2f7828f5f2e64c09258; expires=Mon, 15-Jul-19 18:25:19 GMT; path=/; HttpOnly  ,68957, 5
[1:7:0712/032521.159209:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/032521.194994:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.nmgnews.com.cn/
[1:1:0712/032521.260348:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/032521.264942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3ac21de109f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/032521.265273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/032521.273128:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[68861:68861:0712/032521.341835:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.nmgnews.com.cn/, http://www.nmgnews.com.cn/, 1
[68861:68861:0712/032521.341944:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.nmgnews.com.cn/, http://www.nmgnews.com.cn
[1:1:0712/032521.400215:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032521.519925:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032521.554668:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/032521.564450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/032521.565249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ac21dce1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/032521.565476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/032521.579991:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032521.580301:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.nmgnews.com.cn/"
[1:1:0712/032522.031279:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://www.nmgnews.com.cn/DWConfiguration/ActiveContent/IncludeFiles/AC_RunActiveContent.js"
[1:1:0712/032522.110646:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032522.288673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f87d7409bd0 0x3616f0cf94d8 , "http://www.nmgnews.com.cn/"
[1:1:0712/032522.309013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/032522.309351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032522.311862:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_b24f0f1c -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/032522.533402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f87d7409bd0 0x3616f0cf94d8 , "http://www.nmgnews.com.cn/"
[1:1:0712/032522.777063:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032522.777552:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032522.777932:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032522.778339:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032522.778819:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032524.078176:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.54724, 0, 0
[1:1:0712/032524.078505:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032524.202020:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032524.202270:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.nmgnews.com.cn/"
[1:1:0712/032524.215900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7f87d70a1070 0x3616f0a4b8e0 , "http://www.nmgnews.com.cn/"
[1:1:0712/032524.217084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , 
$(function(){

	//affect:1
	$(".af1").slide({
		affect:1,
		time:3000,
		speed:400,
		dot_text:fals
[1:1:0712/032524.217316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032524.527688:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://www.nmgnews.com.cn/DWConfiguration/ActiveContent/IncludeFiles/AC_RunActiveContent.js"
[1:1:0712/032524.533264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210, "http://www.nmgnews.com.cn/"
[1:1:0712/032524.534433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https
[1:1:0712/032524.534666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032524.539552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210, "http://www.nmgnews.com.cn/"
[1:1:0712/032524.608997:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210, "http://www.nmgnews.com.cn/"
[1:1:0712/032526.582669:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032526.583181:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032527.013887:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.48173, 2, 0
[1:1:0712/032527.014188:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032528.927471:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032528.927700:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.nmgnews.com.cn/"
[1:1:0712/032528.930854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7f87d70a1070 0x3616f0d39de0 , "http://www.nmgnews.com.cn/"
[1:1:0712/032528.932585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , /**
 * @L_slide picutre scroll
 * @version 1.0
 * @author DQ Lee
 **/

(function($){
	$.fn.sl
[1:1:0712/032528.932821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032528.973483:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0456729, 367, 1
[1:1:0712/032528.973695:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032529.861429:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7f87d8fc92e0 0x3616f232d9e0 , "http://www.nmgnews.com.cn/"
[1:1:0712/032529.870281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , (function(){var h={},mt={},c={id:"c66c0a42a9e87bd763bd8372588368a8",dm:["nmgnews.com.cn"],js:"tongji
[1:1:0712/032529.870509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032529.901241:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b9c604429c8, 0x3616f0760148
[1:1:0712/032529.901484:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 100
[1:1:0712/032529.901823:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 449
[1:1:0712/032529.902035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 449 0x7f87d70a1070 0x3616f161fd60 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 368 0x7f87d8fc92e0 0x3616f232d9e0 
[68861:68861:0712/032539.876759:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/032539.914987:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/032542.012689:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032542.013030:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.nmgnews.com.cn/"
[1:1:0712/032542.013985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f87d70a1070 0x3616f0cf65e0 , "http://www.nmgnews.com.cn/"
[1:1:0712/032542.015080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , 
	Qfast.add('widgets', { path: "http://inews.nmgnews.com.cn/zt/sgqfgpd/js/terminator2.2.min.js", typ
[1:1:0712/032542.015304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032542.128104:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.11496, 1244, 1
[1:1:0712/032542.128422:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/032542.664707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/032542.665045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032544.026314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 449, 7f87d99e6881
[1:1:0712/032544.057979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"368 0x7f87d8fc92e0 0x3616f232d9e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032544.058332:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"368 0x7f87d8fc92e0 0x3616f232d9e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032544.058781:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032544.059354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/032544.059565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032544.060057:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b9c604429c8, 0x3616f0760150
[1:1:0712/032544.060258:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 100
[1:1:0712/032544.060620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 604
[1:1:0712/032544.060866:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f87d70a1070 0x3616f27cf1e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 449 0x7f87d70a1070 0x3616f161fd60 
[1:1:0712/032545.649972:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/032545.650267:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.nmgnews.com.cn/"
[1:1:0712/032545.651113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 571 0x7f87d70a1070 0x3616f0cf0f60 , "http://www.nmgnews.com.cn/"
[1:1:0712/032545.652535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , 
function scrollDoor(){}
scrollDoor.prototype = {
	sd : function(menus,divs,openClass,closeClass){
	
[1:1:0712/032545.652879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032545.659494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 571 0x7f87d70a1070 0x3616f0cf0f60 , "http://www.nmgnews.com.cn/"
[68861:68861:0712/032545.666374:INFO:CONSOLE(833)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://dcs.conac.cn/js/07/000/0000/60430517/CA070000000604305170001.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.nmgnews.com.cn/ (833)
[68861:68861:0712/032545.676849:INFO:CONSOLE(833)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://dcs.conac.cn/js/07/000/0000/60430517/CA070000000604305170001.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.nmgnews.com.cn/ (833)
[1:1:0712/032547.166069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , document.readyState
[1:1:0712/032547.166372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032548.040053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 604, 7f87d99e6881
[1:1:0712/032548.069704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"449 0x7f87d70a1070 0x3616f161fd60 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032548.070069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"449 0x7f87d70a1070 0x3616f161fd60 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032548.070452:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032548.071027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/032548.071252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032548.071994:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b9c604429c8, 0x3616f0760150
[1:1:0712/032548.072193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 100
[1:1:0712/032548.072560:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 655
[1:1:0712/032548.072876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7f87d70a1070 0x3616f1599260 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 604 0x7f87d70a1070 0x3616f27cf1e0 
[1:1:0712/032548.134419:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.nmgnews.com.cn/"
[1:1:0712/032548.136448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/032548.136684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032548.238661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 612 0x7f87d8fc92e0 0x3616f1d9e6e0 , "http://www.nmgnews.com.cn/"
[1:1:0712/032548.241724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , /*
Highlight:QQ.com�Ż�Ч��ϼ��������5Koala
@�汾:1.
@����:boqi
[1:1:0712/032548.241995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032549.320786:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.nmgnews.com.cn/"
		remove user.11_87d6a33e -> 0
		remove user.12_3f6e86a -> 0
[1:1:0712/032549.417651:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1b9c604429c8, 0x3616f0760218
[1:1:0712/032549.417823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032549.418011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 662
[1:1:0712/032549.418156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7f87d70a1070 0x3616f1d9d5e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 612 0x7f87d8fc92e0 0x3616f1d9e6e0 
[1:1:0712/032549.497192:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x1b9c604429c8, 0x3616f0760218
[1:1:0712/032549.497410:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 50
[1:1:0712/032549.497812:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 663
[1:1:0712/032549.497994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f87d70a1070 0x3616f34e40e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 612 0x7f87d8fc92e0 0x3616f1d9e6e0 
[1:1:0712/032549.663760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 623, "http://www.nmgnews.com.cn/"
[1:1:0712/032549.664793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , document.write(unescape("%3Cspan id='_ideConac' %3E%3C/span%3E"));var span_msg=document.getElementBy
[1:1:0712/032549.664974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032549.682430:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 623, "http://www.nmgnews.com.cn/"
[1:1:0712/032549.900814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , document.readyState
[1:1:0712/032549.901051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032550.762197:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 655, 7f87d99e6881
[1:1:0712/032550.795476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"604 0x7f87d70a1070 0x3616f27cf1e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032550.795837:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"604 0x7f87d70a1070 0x3616f27cf1e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032550.796339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032550.797008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/032550.797268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032550.798008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b9c604429c8, 0x3616f0760150
[1:1:0712/032550.798237:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 100
[1:1:0712/032550.798758:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 707
[1:1:0712/032550.799000:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f87d70a1070 0x3616f284f7e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 655 0x7f87d70a1070 0x3616f1599260 
[1:1:0712/032550.800337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 663, 7f87d99e6881
[1:1:0712/032550.833215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"612 0x7f87d8fc92e0 0x3616f1d9e6e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032550.833654:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"612 0x7f87d8fc92e0 0x3616f1d9e6e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032550.834098:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032550.834749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , (){h.runffId&&clearTimeout(h.runffId);if(g<100){g+=Math.ceil((100-g)/10);c(f,g);h.runffId=setTimeout
[1:1:0712/032550.834984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032550.836290:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x1b9c604429c8, 0x3616f0760158
[1:1:0712/032550.836535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 50
[1:1:0712/032550.836929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 709
[1:1:0712/032550.837167:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f87d70a1070 0x3616f168abe0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 663 0x7f87d70a1070 0x3616f34e40e0 
[1:1:0712/032551.239499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 676, "http://www.nmgnews.com.cn/"
[1:1:0712/032551.242842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , var has_runed = has_runed;//当前脚本是否已经执行过
if(!has_runed){
	has_runed = true;

[1:1:0712/032551.243095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032551.312243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , document.readyState
[1:1:0712/032551.312562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032552.263677:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 709, 7f87d99e6881
[1:1:0712/032552.302234:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"663 0x7f87d70a1070 0x3616f34e40e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032552.302620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"663 0x7f87d70a1070 0x3616f34e40e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032552.303061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032552.303659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , (){h.runffId&&clearTimeout(h.runffId);if(g<100){g+=Math.ceil((100-g)/10);c(f,g);h.runffId=setTimeout
[1:1:0712/032552.304041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032552.305460:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x1b9c604429c8, 0x3616f0760158
[1:1:0712/032552.305686:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 50
[1:1:0712/032552.306092:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 824
[1:1:0712/032552.306331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 824 0x7f87d70a1070 0x3616f27da760 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 709 0x7f87d70a1070 0x3616f168abe0 
[1:1:0712/032552.307645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 707, 7f87d99e6881
[1:1:0712/032552.320574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"655 0x7f87d70a1070 0x3616f1599260 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032552.320931:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"655 0x7f87d70a1070 0x3616f1599260 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032552.321363:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032552.321962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/032552.322196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032552.322918:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b9c604429c8, 0x3616f0760150
[1:1:0712/032552.323137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 100
[1:1:0712/032552.323503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 827
[1:1:0712/032552.323746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 827 0x7f87d70a1070 0x3616f383e8e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 707 0x7f87d70a1070 0x3616f284f7e0 
[1:1:0712/032553.043470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , document.readyState
[1:1:0712/032553.043772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032553.121539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738, "http://www.nmgnews.com.cn/"
[1:1:0712/032553.122428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , 
[1:1:0712/032553.122685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032553.124998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738, "http://www.nmgnews.com.cn/"
[1:1:0712/032553.132988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738, "http://www.nmgnews.com.cn/"
[68861:68861:0712/032553.133670:INFO:CONSOLE(1)] "Uncaught SyntaxError: Unexpected token u in JSON at position 0", source: http://www.nmgnews.com.cn/ (1)
[1:1:0712/032553.191746:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 738, "http://www.nmgnews.com.cn/"
[1:1:0712/032553.201242:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.nmgnews.com.cn/"
[1:1:0712/032553.552878:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032553.553349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 894
[1:1:0712/032553.553580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 894 0x7f87d70a1070 0x3616f3875ce0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032553.835348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032553.835831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 907
[1:1:0712/032553.836144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7f87d70a1070 0x3616f384e8e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032554.053739:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032554.054182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 917
[1:1:0712/032554.054433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7f87d70a1070 0x3616f2e2a360 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032554.308835:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032554.309284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 928
[1:1:0712/032554.309540:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7f87d70a1070 0x3616f0d5cfe0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032554.497985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032554.498468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 937
[1:1:0712/032554.498726:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7f87d70a1070 0x3616f2844a60 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032554.707844:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032554.708361:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 948
[1:1:0712/032554.708743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 948 0x7f87d70a1070 0x3616f27da560 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032554.962365:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032554.962827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 959
[1:1:0712/032554.963088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7f87d70a1070 0x3616f1629160 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032555.216290:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032555.216582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 972
[1:1:0712/032555.216822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7f87d70a1070 0x3616f1da0ae0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032555.314715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032555.315123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 978
[1:1:0712/032555.315321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 978 0x7f87d70a1070 0x3616f0dafce0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032555.421848:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032555.422248:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 985
[1:1:0712/032555.422444:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f87d70a1070 0x3616f1da3a60 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032555.578207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032555.578620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 993
[1:1:0712/032555.578859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f87d70a1070 0x3616f08e5960 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032555.794426:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032555.794682:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1003
[1:1:0712/032555.794812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f87d70a1070 0x3616f05b4360 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
[1:1:0712/032555.806220:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.nmgnews.com.cn/"
[1:1:0712/032555.807667:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.nmgnews.com.cn/"
[1:1:0712/032555.809004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.nmgnews.com.cn/"
[1:1:0712/032555.854870:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b9c604429c8, 0x3616f07601e0
[1:1:0712/032555.855039:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 1000
[1:1:0712/032555.855209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 1008
[1:1:0712/032555.855327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1008 0x7f87d70a1070 0x3616f162f2e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 738
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/032600.044619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 824, 7f87d99e6881
[1:1:0712/032600.086085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"709 0x7f87d70a1070 0x3616f168abe0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032600.086290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"709 0x7f87d70a1070 0x3616f168abe0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032600.086526:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032600.086869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , (){h.runffId&&clearTimeout(h.runffId);if(g<100){g+=Math.ceil((100-g)/10);c(f,g);h.runffId=setTimeout
[1:1:0712/032600.087020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032600.087605:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x1b9c604429c8, 0x3616f0760158
[1:1:0712/032600.087709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 50
[1:1:0712/032600.087877:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 1224
[1:1:0712/032600.088042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1224 0x7f87d70a1070 0x3616f37e83e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 824 0x7f87d70a1070 0x3616f27da760 
[1:1:0712/032600.178543:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 662, 7f87d99e6881
[1:1:0712/032600.231267:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"612 0x7f87d8fc92e0 0x3616f1d9e6e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032600.231476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"612 0x7f87d8fc92e0 0x3616f1d9e6e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032600.231731:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032600.232133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , (){g.next()}
[1:1:0712/032600.232260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032600.233055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1b9c604429c8, 0x3616f0760158
[1:1:0712/032600.233162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 3000
[1:1:0712/032600.233332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 1233
[1:1:0712/032600.233445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1233 0x7f87d70a1070 0x3616f08dc8e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 662 0x7f87d70a1070 0x3616f1d9d5e0 
[1:1:0712/032600.311021:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x1b9c604429c8, 0x3616f0760158
[1:1:0712/032600.311254:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 50
[1:1:0712/032600.311585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 1236
[1:1:0712/032600.311780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1236 0x7f87d70a1070 0x3616f38907e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 662 0x7f87d70a1070 0x3616f1d9d5e0 
[1:1:0712/032600.313587:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 827, 7f87d99e6881
[1:1:0712/032600.363961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"707 0x7f87d70a1070 0x3616f284f7e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032600.364186:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"707 0x7f87d70a1070 0x3616f284f7e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032600.364444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032600.364794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/032600.364908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032600.365273:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b9c604429c8, 0x3616f0760150
[1:1:0712/032600.365375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 100
[1:1:0712/032600.365544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 1240
[1:1:0712/032600.365655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1240 0x7f87d70a1070 0x3616f45a9ce0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 827 0x7f87d70a1070 0x3616f383e8e0 
[1:1:0712/032601.684046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , document.readyState
[1:1:0712/032601.684351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[68861:68861:0712/032601.932573:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/032611.054102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 894, 7f87d99e68db
[1:1:0712/032611.117978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032611.118285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032611.118706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1700
[1:1:0712/032611.118931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1700 0x7f87d70a1070 0x3616f497a9e0 , 5:3_http://www.nmgnews.com.cn/, 0, , 894 0x7f87d70a1070 0x3616f3875ce0 
[1:1:0712/032611.119270:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032611.119802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032611.120042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032611.196362:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 13
[1:1:0712/032611.197088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1705
[1:1:0712/032611.197350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1705 0x7f87d70a1070 0x3616f4a76060 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 894 0x7f87d70a1070 0x3616f3875ce0 
[1:1:0712/032611.835512:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 907, 7f87d99e68db
[1:1:0712/032611.861549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032611.861749:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032611.861958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1740
[1:1:0712/032611.862078:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1740 0x7f87d70a1070 0x3616f49664e0 , 5:3_http://www.nmgnews.com.cn/, 0, , 907 0x7f87d70a1070 0x3616f384e8e0 
[1:1:0712/032611.862262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032611.862561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032611.862688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032611.996549:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 1008, 7f87d99e6881
[1:1:0712/032612.021742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032612.022097:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032612.022558:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032612.023239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , (){r.requesting=!1,n&&n(new Error("etag request time out"))}
[1:1:0712/032612.023486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032612.543387:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 917, 7f87d99e68db
[1:1:0712/032612.567526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032612.567715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032612.567948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1778
[1:1:0712/032612.568063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1778 0x7f87d70a1070 0x3616f48c3660 , 5:3_http://www.nmgnews.com.cn/, 0, , 917 0x7f87d70a1070 0x3616f2e2a360 
[1:1:0712/032612.568234:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032612.568546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032612.568652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032613.384314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 928, 7f87d99e68db
[1:1:0712/032613.409338:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032613.409547:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032613.409784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1818
[1:1:0712/032613.409902:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1818 0x7f87d70a1070 0x3616f49d1a60 , 5:3_http://www.nmgnews.com.cn/, 0, , 928 0x7f87d70a1070 0x3616f0d5cfe0 
[1:1:0712/032613.410080:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032613.410395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032613.410556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032613.892852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 937, 7f87d99e68db
[1:1:0712/032613.966201:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032613.966403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032613.966712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1844
[1:1:0712/032613.966911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1844 0x7f87d70a1070 0x3616f49e3e60 , 5:3_http://www.nmgnews.com.cn/, 0, , 937 0x7f87d70a1070 0x3616f2844a60 
[1:1:0712/032613.967099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032613.967419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032613.967551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032614.612897:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 948, 7f87d99e68db
[1:1:0712/032614.694341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032614.694544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032614.694989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1870
[1:1:0712/032614.695111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1870 0x7f87d70a1070 0x3616f48da2e0 , 5:3_http://www.nmgnews.com.cn/, 0, , 948 0x7f87d70a1070 0x3616f27da560 
[1:1:0712/032614.695292:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032614.695602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032614.695730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032615.270519:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 959, 7f87d99e68db
[1:1:0712/032615.347222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032615.347548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032615.347993:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1901
[1:1:0712/032615.348216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1901 0x7f87d70a1070 0x3616f4d48ce0 , 5:3_http://www.nmgnews.com.cn/, 0, , 959 0x7f87d70a1070 0x3616f1629160 
[1:1:0712/032615.348515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032615.349062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032615.349265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032615.374267:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032615.374736:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032615.377859:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/032616.050015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 972, 7f87d99e68db
[1:1:0712/032616.097084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032616.097480:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032616.097983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1939
[1:1:0712/032616.098255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1939 0x7f87d70a1070 0x3616f4a65ae0 , 5:3_http://www.nmgnews.com.cn/, 0, , 972 0x7f87d70a1070 0x3616f1da0ae0 
[1:1:0712/032616.098676:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032616.099351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032616.099575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032616.586058:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 978, 7f87d99e68db
[1:1:0712/032616.653929:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032616.654145:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032616.654417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1965
[1:1:0712/032616.654538:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1965 0x7f87d70a1070 0x3616f4e3a3e0 , 5:3_http://www.nmgnews.com.cn/, 0, , 978 0x7f87d70a1070 0x3616f0dafce0 
[1:1:0712/032616.654722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032616.655058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032616.655217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032616.938524:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 985, 7f87d99e68db
[1:1:0712/032616.969294:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032616.969486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032616.969724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1979
[1:1:0712/032616.969841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1979 0x7f87d70a1070 0x3616f49ee260 , 5:3_http://www.nmgnews.com.cn/, 0, , 985 0x7f87d70a1070 0x3616f1da3a60 
[1:1:0712/032616.970013:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032616.970320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032616.970424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032617.491494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 993, 7f87d99e68db
[1:1:0712/032617.579875:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032617.580071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032617.580528:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 2002
[1:1:0712/032617.580780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2002 0x7f87d70a1070 0x3616f4dda3e0 , 5:3_http://www.nmgnews.com.cn/, 0, , 993 0x7f87d70a1070 0x3616f08e5960 
[1:1:0712/032617.581150:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032617.581771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032617.582023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032618.268520:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 1003, 7f87d99e68db
[1:1:0712/032618.299156:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032618.299385:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"738","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032618.299627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.nmgnews.com.cn/, 2031
[1:1:0712/032618.299743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2031 0x7f87d70a1070 0x3616f4dc8660 , 5:3_http://www.nmgnews.com.cn/, 0, , 1003 0x7f87d70a1070 0x3616f05b4360 
[1:1:0712/032618.299914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032618.300227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , auto, (){
				num<$box.find("li").length-1?num++:num=0;
				run();
			}
[1:1:0712/032618.300338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032623.757404:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 1236, 7f87d99e6881
[1:1:0712/032623.868585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1a86a18e2860","ptid":"662 0x7f87d70a1070 0x3616f1d9d5e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032623.868963:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.nmgnews.com.cn/","ptid":"662 0x7f87d70a1070 0x3616f1d9d5e0 ","rf":"5:3_http://www.nmgnews.com.cn/"}
[1:1:0712/032623.869435:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.nmgnews.com.cn/"
[1:1:0712/032623.870043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.nmgnews.com.cn/, 1a86a18e2860, , , (){h.runffId&&clearTimeout(h.runffId);if(g<100){g+=Math.ceil((100-g)/10);c(f,g);h.runffId=setTimeout
[1:1:0712/032623.870286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.nmgnews.com.cn/", "www.nmgnews.com.cn", 3, 1, , , 0
[1:1:0712/032623.871433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x1b9c604429c8, 0x3616f0760158
[1:1:0712/032623.871800:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.nmgnews.com.cn/", 50
[1:1:0712/032623.872287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.nmgnews.com.cn/, 2290
[1:1:0712/032623.872589:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2290 0x7f87d70a1070 0x3616f49a94e0 , 5:3_http://www.nmgnews.com.cn/, 1, -5:3_http://www.nmgnews.com.cn/, 1236 0x7f87d70a1070 0x3616f38907e0 
