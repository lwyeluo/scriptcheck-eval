[0712/034245.586898:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034245.587283:INFO:switcher_clone.cc(787)] backtrace rip is 7f2a01171891
[0712/034246.669615:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034246.669950:INFO:switcher_clone.cc(787)] backtrace rip is 7f43d25d7891
[1:1:0712/034246.681550:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/034246.681798:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/034246.689647:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[71344:71344:0712/034247.978958:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/fd7ffd4a-dbe8-4d3e-9936-a62cdf7597ff
[0712/034248.334304:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034248.334840:INFO:switcher_clone.cc(787)] backtrace rip is 7f9a20798891
[71344:71344:0712/034248.473162:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[71344:71373:0712/034248.474066:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/034248.474349:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034248.474571:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034248.475191:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034248.475339:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/034248.478280:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xdb6e475, 1
[1:1:0712/034248.478599:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24bc5ecc, 0
[1:1:0712/034248.478776:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c20a949, 3
[1:1:0712/034248.479043:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xa22a5b1, 2
[1:1:0712/034248.479314:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcc5effffffbc24 75ffffffe4ffffffb60d ffffffb1ffffffa5220a 49ffffffa9201c , 10104, 4
[1:1:0712/034248.480619:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[71344:71373:0712/034248.480933:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�^�$u���"
I� ��
[71344:71373:0712/034248.481015:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �^�$u���"
I� ���
[1:1:0712/034248.480932:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43d08120a0, 3
[71344:71373:0712/034248.481381:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/034248.481421:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43d099d080, 2
[71344:71373:0712/034248.481475:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 71388, 4, cc5ebc24 75e4b60d b1a5220a 49a9201c 
[1:1:0712/034248.481639:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43ba660d20, -2
[1:1:0712/034248.496102:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034248.496705:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a22a5b1
[1:1:0712/034248.497375:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a22a5b1
[1:1:0712/034248.498626:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a22a5b1
[1:1:0712/034248.499214:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.499321:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.499418:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.499508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.499728:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a22a5b1
[1:1:0712/034248.500091:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f43d25d77ba
[1:1:0712/034248.500231:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f43d25cedef, 7f43d25d777a, 7f43d25d90cf
[1:1:0712/034248.505934:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a22a5b1
[1:1:0712/034248.506291:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a22a5b1
[1:1:0712/034248.507033:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a22a5b1
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/034248.509090:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.509285:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.509483:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.509665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a22a5b1
[1:1:0712/034248.510951:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a22a5b1
[1:1:0712/034248.511311:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f43d25d77ba
[1:1:0712/034248.511441:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f43d25cedef, 7f43d25d777a, 7f43d25d90cf
[1:1:0712/034248.520281:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034248.520939:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034248.521151:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff54aff658, 0x7fff54aff5d8)
[1:1:0712/034248.540494:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034248.547958:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[71375:71375:0712/034248.595064:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=71375
[71396:71396:0712/034248.595480:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=71396
[71344:71344:0712/034248.983354:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71344:71344:0712/034248.984986:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71344:71354:0712/034248.999346:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[71344:71354:0712/034248.999448:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[71344:71344:0712/034248.999691:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[71344:71344:0712/034248.999788:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[71344:71344:0712/034249.000019:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,71388, 4
[1:7:0712/034249.004652:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[71344:71365:0712/034249.073300:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/034249.087206:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3c1d27566220
[1:1:0712/034249.087393:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/034249.284141:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/034250.633476:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034250.636941:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[71344:71344:0712/034250.746880:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[71344:71344:0712/034250.746961:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/034251.977475:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034252.179570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 282593961f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034252.179966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034252.196530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 282593961f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034252.196828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034252.531519:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034252.680815:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034253.225053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034253.233191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 282593961f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034253.233425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034253.287929:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034253.298889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 282593961f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034253.299152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034253.311756:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[71344:71344:0712/034253.313563:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[71344:71344:0712/034253.317367:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0712/034253.320088:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c1d27564e20
[1:1:0712/034253.321625:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[71344:71344:0712/034253.353748:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[71344:71344:0712/034253.353905:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/034253.361250:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034253.974638:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f43bc23b2e0 0x3c1d277df260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034253.976070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 282593961f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/034253.976439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034253.977962:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[71344:71344:0712/034254.049050:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/034254.052363:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c1d27565820
[1:1:0712/034254.052601:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[71344:71344:0712/034254.055772:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/034254.073739:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/034254.074030:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[71344:71344:0712/034254.076324:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[71344:71344:0712/034254.086285:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71344:71344:0712/034254.087298:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71344:71354:0712/034254.093110:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[71344:71354:0712/034254.093194:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[71344:71344:0712/034254.093380:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[71344:71344:0712/034254.093456:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[71344:71344:0712/034254.093591:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,71388, 4
[1:7:0712/034254.099032:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034254.740185:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/034255.370623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f43bc23b2e0 0x3c1d277e3060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034255.371665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 282593961f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/034255.371971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034255.372740:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[71344:71344:0712/034255.493707:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[71344:71344:0712/034255.493830:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/034255.528653:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034256.028250:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[71344:71344:0712/034256.391879:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[71344:71373:0712/034256.392373:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/034256.392599:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034256.392882:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034256.393267:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034256.393417:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/034256.396446:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xa11cf12, 1
[1:1:0712/034256.396774:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xaba8d3e, 0
[1:1:0712/034256.396917:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1925f250, 3
[1:1:0712/034256.396996:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e94c794, 2
[1:1:0712/034256.397085:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3effffff8dffffffba0a 12ffffffcf110a ffffff94ffffffc7ffffff941e 50fffffff22519 , 10104, 5
[1:1:0712/034256.397743:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[71344:71373:0712/034256.397953:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING>��
�
�ǔP�%��
[71344:71373:0712/034256.398040:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is >��
�
�ǔP�%����
[1:1:0712/034256.398173:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43d08120a0, 3
[71344:71373:0712/034256.398332:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 71440, 5, 3e8dba0a 12cf110a 94c7941e 50f22519 
[1:1:0712/034256.398377:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43d099d080, 2
[1:1:0712/034256.398607:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43ba660d20, -2
[1:1:0712/034256.408517:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034256.408711:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e94c794
[1:1:0712/034256.408903:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e94c794
[1:1:0712/034256.409156:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e94c794
[1:1:0712/034256.409570:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.409669:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.409754:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.409861:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.410103:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e94c794
[1:1:0712/034256.410239:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f43d25d77ba
[1:1:0712/034256.410312:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f43d25cedef, 7f43d25d777a, 7f43d25d90cf
[1:1:0712/034256.411681:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e94c794
[1:1:0712/034256.411870:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e94c794
[1:1:0712/034256.412127:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e94c794
[1:1:0712/034256.412758:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.412902:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.413008:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.413097:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e94c794
[1:1:0712/034256.413514:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e94c794
[1:1:0712/034256.413662:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f43d25d77ba
[1:1:0712/034256.413732:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f43d25cedef, 7f43d25d777a, 7f43d25d90cf
[1:1:0712/034256.415785:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034256.416202:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034256.416296:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff54aff658, 0x7fff54aff5d8)
[1:1:0712/034256.428174:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034256.432600:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/034256.592641:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c1d2754f220
[1:1:0712/034256.592798:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/034256.645613:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034256.645862:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[71344:71344:0712/034257.109039:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[71344:71344:0712/034257.109184:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0712/034257.148852:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.149130:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.149301:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.149468:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.149635:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.149790:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.149947:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.150136:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.150320:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.150484:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.150638:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.150790:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.150944:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.151114:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.151280:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.151442:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.151613:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.151767:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.151921:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.152115:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.152283:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.152437:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.152617:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.152774:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.152935:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.153118:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.153278:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.153441:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.153610:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.153775:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.153942:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.154114:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.154282:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.154439:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.154588:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.154745:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.154894:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.155099:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.155258:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.155407:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.155730:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.155888:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034257.173233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034257.178116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 282593a909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/034257.178429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034257.186500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034257.324430:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034257.335815:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034257.443043:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034257.443794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 282593961f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/034257.444000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034257.651690:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034257.651901:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/034257.696878:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179 0x7f43ba313070 0x3c1d276031e0 , "chrome-error://chromewebdata/"
[1:1:0712/034257.699000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179 0x7f43ba313070 0x3c1d276031e0 , "chrome-error://chromewebdata/"
[1:1:0712/034257.700571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179 0x7f43ba313070 0x3c1d276031e0 , "chrome-error://chromewebdata/"
[1:1:0712/034257.704704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179 0x7f43ba313070 0x3c1d276031e0 , "chrome-error://chromewebdata/"
[1:1:0712/034257.723560:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0714982, 81, 1
[1:1:0712/034257.723733:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[3:3:0712/034258.177453:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/034258.348301:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034258.348584:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/034258.350077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f43ba313070 0x3c1d275f4e60 , "chrome-error://chromewebdata/"
[1:1:0712/034258.358097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f43ba313070 0x3c1d275f4e60 , "chrome-error://chromewebdata/"
[1:1:0712/034258.363787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f43ba313070 0x3c1d275f4e60 , "chrome-error://chromewebdata/"
[1:1:0712/034258.394385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f43ba313070 0x3c1d275f4e60 , "chrome-error://chromewebdata/"
[1:1:0712/034258.402091:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f43ba313070 0x3c1d275f4e60 , "chrome-error://chromewebdata/"
[1:1:0712/034258.505962:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/034258.511336:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/034259.302550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/034259.316676:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/034259.343882:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/034259.358814:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
[1:1:0712/034259.451224:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/034259.451505:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[71344:71344:0712/034259.452655:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
