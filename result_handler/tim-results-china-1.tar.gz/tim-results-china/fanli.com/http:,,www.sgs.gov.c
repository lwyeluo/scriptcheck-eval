[0711/230241.733929:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/230241.734474:INFO:switcher_clone.cc(787)] backtrace rip is 7fcfc6efe891
[0711/230242.823901:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/230242.824317:INFO:switcher_clone.cc(787)] backtrace rip is 7f10fb657891
[1:1:0711/230242.836083:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/230242.836375:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/230242.841753:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[32105:32105:0711/230243.955680:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/91fdd0c0-5ce0-4f83-a5ec-9a95ccc3604f
[0711/230244.291314:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/230244.291633:INFO:switcher_clone.cc(787)] backtrace rip is 7f565bf59891
[32105:32105:0711/230244.370246:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[32105:32134:0711/230244.371097:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/230244.371335:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/230244.371578:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/230244.372360:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/230244.372562:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/230244.375406:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1985dafd, 1
[1:1:0711/230244.375799:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x19fc7cec, 0
[1:1:0711/230244.376046:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x103ddb98, 3
[1:1:0711/230244.376269:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b5e524b, 2
[1:1:0711/230244.376504:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffec7cfffffffc19 fffffffdffffffdaffffff8519 4b525e1b ffffff98ffffffdb3d10 , 10104, 4
[1:1:0711/230244.377537:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[32105:32134:0711/230244.377859:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�|��څKR^��=84�;
[32105:32134:0711/230244.378068:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �|��څKR^��=�Y84�;
[1:1:0711/230244.377862:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10f98920a0, 3
[32105:32134:0711/230244.378404:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[32105:32134:0711/230244.378472:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 32149, 4, ec7cfc19 fdda8519 4b525e1b 98db3d10 
[1:1:0711/230244.378414:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10f9a1d080, 2
[1:1:0711/230244.378680:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10e36e0d20, -2
[1:1:0711/230244.397559:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/230244.398482:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b5e524b
[1:1:0711/230244.399497:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b5e524b
[1:1:0711/230244.401231:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b5e524b
[1:1:0711/230244.402907:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.403125:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.403336:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.403544:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.404200:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b5e524b
[1:1:0711/230244.404547:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f10fb6577ba
[1:1:0711/230244.404736:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f10fb64edef, 7f10fb65777a, 7f10fb6590cf
[1:1:0711/230244.411194:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b5e524b
[1:1:0711/230244.411607:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b5e524b
[1:1:0711/230244.412407:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b5e524b
[1:1:0711/230244.414481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.414748:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.415012:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.415259:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b5e524b
[1:1:0711/230244.416581:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b5e524b
[1:1:0711/230244.417023:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f10fb6577ba
[1:1:0711/230244.417219:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f10fb64edef, 7f10fb65777a, 7f10fb6590cf
[1:1:0711/230244.425273:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/230244.425866:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/230244.426054:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff50055858, 0x7fff500557d8)
[1:1:0711/230244.441763:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/230244.448086:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[32136:32136:0711/230244.527383:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=32136
[32163:32163:0711/230244.527879:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=32163
[32105:32105:0711/230244.917613:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32105:32105:0711/230244.919519:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32105:32115:0711/230244.932054:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[32105:32115:0711/230244.932151:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[32105:32105:0711/230244.932296:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[32105:32105:0711/230244.932372:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[32105:32105:0711/230244.932508:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,32149, 4
[1:7:0711/230244.941217:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[32105:32126:0711/230244.961950:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/230245.052388:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2e49bd7be220
[1:1:0711/230245.052644:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/230245.370949:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[32105:32105:0711/230246.829611:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[32105:32105:0711/230246.829730:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/230246.835539:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230246.839141:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/230248.212453:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230248.304043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 231cc9ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/230248.304371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230248.315432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 231cc9ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/230248.315730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230248.651247:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230248.651533:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230249.007559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230249.016541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 231cc9ae1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/230249.016829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230249.053178:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230249.063941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 231cc9ae1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/230249.064225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230249.076163:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[32105:32105:0711/230249.078591:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/230249.079792:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2e49bd7bce20
[1:1:0711/230249.080031:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[32105:32105:0711/230249.085464:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[32105:32105:0711/230249.115669:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[32105:32105:0711/230249.115856:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/230249.160691:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230249.923323:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f10e52bb2e0 0x2e49bda6e460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230249.924743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 231cc9ae1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/230249.925037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230249.926570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[32105:32105:0711/230249.996298:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/230249.998607:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2e49bd7bd820
[1:1:0711/230249.998876:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[32105:32105:0711/230250.000731:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/230250.009189:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/230250.009431:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[32105:32105:0711/230250.015576:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[32105:32105:0711/230250.028293:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32105:32105:0711/230250.029331:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[32105:32115:0711/230250.035698:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[32105:32115:0711/230250.035787:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[32105:32105:0711/230250.035937:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[32105:32105:0711/230250.036064:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[32105:32105:0711/230250.036233:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,32149, 4
[1:7:0711/230250.039523:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/230250.508427:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/230250.879310:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f10e52bb2e0 0x2e49bdb68360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230250.880329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 231cc9ae1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/230250.880575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230250.881378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[32105:32105:0711/230250.958194:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[32105:32105:0711/230250.958265:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/230250.970790:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/230251.231062:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230251.752298:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230251.752568:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[32105:32105:0711/230251.803178:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[32105:32134:0711/230251.803658:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/230251.803845:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/230251.804074:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/230251.804456:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/230251.804592:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/230251.808106:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2ca7be32, 1
[1:1:0711/230251.808585:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x38cd7b7a, 0
[1:1:0711/230251.808786:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2403d767, 3
[1:1:0711/230251.808956:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1d2f7507, 2
[1:1:0711/230251.809123:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7a7bffffffcd38 32ffffffbeffffffa72c 07752f1d 67ffffffd70324 , 10104, 5
[1:1:0711/230251.810375:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[32105:32134:0711/230251.810688:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGz{�82��,u/g�$^5�;
[32105:32134:0711/230251.810775:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is z{�82��,u/g�$�.^5�;
[1:1:0711/230251.810666:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10f98920a0, 3
[1:1:0711/230251.810867:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10f9a1d080, 2
[32105:32134:0711/230251.811073:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 32200, 5, 7a7bcd38 32bea72c 07752f1d 67d70324 
[1:1:0711/230251.811097:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10e36e0d20, -2
[1:1:0711/230251.836233:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/230251.836629:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d2f7507
[1:1:0711/230251.837024:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d2f7507
[1:1:0711/230251.837781:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d2f7507
[1:1:0711/230251.839536:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.839756:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.839983:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.840195:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.841035:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d2f7507
[1:1:0711/230251.841409:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f10fb6577ba
[1:1:0711/230251.841573:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f10fb64edef, 7f10fb65777a, 7f10fb6590cf
[1:1:0711/230251.848511:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d2f7507
[1:1:0711/230251.848990:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d2f7507
[1:1:0711/230251.849882:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d2f7507
[1:1:0711/230251.852419:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.852674:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.852896:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.853125:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d2f7507
[1:1:0711/230251.854654:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d2f7507
[1:1:0711/230251.855092:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f10fb6577ba
[1:1:0711/230251.855252:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f10fb64edef, 7f10fb65777a, 7f10fb6590cf
[1:1:0711/230251.864816:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/230251.865477:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/230251.865659:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff50055858, 0x7fff500557d8)
[1:1:0711/230251.879583:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/230251.883922:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/230252.081959:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2e49bd799220
[1:1:0711/230252.082221:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/230252.095376:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230252.099939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 231cc9c109f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/230252.100254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230252.108016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[32105:32105:0711/230252.871181:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[32105:32105:0711/230252.904009:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[32105:32134:0711/230252.904490:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0711/230252.904743:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/230252.905359:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/230252.905766:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/230252.905932:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0711/230252.908989:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2436f24b, 1
[1:1:0711/230252.909307:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2641a67, 0
[1:1:0711/230252.909500:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x31134cdb, 3
[1:1:0711/230252.909690:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x18b2e1f8, 2
[1:1:0711/230252.909841:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 671a6402 4bfffffff23624 fffffff8ffffffe1ffffffb218 ffffffdb4c1331 , 10104, 6
[1:1:0711/230252.910816:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[32105:32134:0711/230252.911092:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGgdK�6$���L1a5�;
[32105:32134:0711/230252.911165:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is gdK�6$���L1X�a5�;
[1:1:0711/230252.911274:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10f98920a0, 3
[32105:32134:0711/230252.911431:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 32215, 6, 671a6402 4bf23624 f8e1b218 db4c1331 
[1:1:0711/230252.911450:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10f9a1d080, 2
[1:1:0711/230252.911662:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10e36e0d20, -2
[1:1:0711/230252.925436:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/230252.925667:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18b2e1f8
[1:1:0711/230252.925794:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18b2e1f8
[1:1:0711/230252.926025:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18b2e1f8
[1:1:0711/230252.926452:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.926547:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.926704:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.926890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.927114:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18b2e1f8
[1:1:0711/230252.927230:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f10fb6577ba
[1:1:0711/230252.927300:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f10fb64edef, 7f10fb65777a, 7f10fb6590cf
[1:1:0711/230252.928726:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18b2e1f8
[1:1:0711/230252.928880:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18b2e1f8
[1:1:0711/230252.929131:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18b2e1f8
[1:1:0711/230252.930277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.930545:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.930802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.931024:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18b2e1f8
[1:1:0711/230252.932531:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18b2e1f8
[1:1:0711/230252.933005:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f10fb6577ba
[1:1:0711/230252.933180:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f10fb64edef, 7f10fb65777a, 7f10fb6590cf
[1:1:0711/230252.938330:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/230252.938700:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/230252.938801:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff50055858, 0x7fff500557d8)
[32105:32105:0711/230252.941959:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/230252.953122:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/230252.958431:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[32105:32115:0711/230252.959488:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[32105:32115:0711/230252.959593:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[32105:32105:0711/230252.961753:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://scjgj.sh.gov.cn/
[32105:32105:0711/230252.961846:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=2015012315401525, 1
[32105:32105:0711/230252.961986:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_http://scjgj.sh.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:02:53 GMT Content-Type: text/html;charset=UTF-8 Content-Length: 13733 Connection: keep-alive Expires: Fri, 12 Jul 2019 06:02:53 GMT Pragma: no-cache Cache-Control: no-cache Set-Cookie: JSESSIONIDlz=0000-7ZoUMyPq1Q-rIqWjegSefm:16f9u5cfo; Path=/ Content-Language: zh-CN X-Ser: BC14_dx-lt-yd-jiangsu-zhenjiang-3-cache-9, BC76_cl-shanghai-shanghai-1-cache-2, BC148_ck-shanghai-shanghai-3-cache-2, BC158_ck-beijing-beijing-2-cache-2  ,0, 6
[3:3:0711/230252.995351:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0711/230253.052681:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/230253.161312:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2e49bd7c7220
[1:1:0711/230253.162477:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/230253.234327:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_http://scjgj.sh.gov.cn/
[32105:32105:0711/230253.448606:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn/, 1
[32105:32105:0711/230253.448757:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn
[1:1:0711/230253.482120:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/230253.580410:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230253.673896:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230253.674139:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=2015012315401525"
[1:1:0711/230253.737151:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0626709, 266, 1
[1:1:0711/230253.737387:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230253.809638:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230253.809897:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=2015012315401525"
[1:1:0711/230253.920012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157 0x7f10e3393070 0x2e49bd8b5260 , "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=2015012315401525"
[1:1:0711/230253.922361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_http://scjgj.sh.gov.cn/, 09b00b3a2860, , , 
//changediv();
function changediv(){
	var tab = document.getElementById("resultTb");
	var d = docum
[1:1:0711/230253.922591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=2015012315401525", "scjgj.sh.gov.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230301.415691:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230301.416188:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230301.416532:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230301.416943:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230301.417265:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230305.922575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_http://scjgj.sh.gov.cn/, 09b00b3a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/230305.922908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=2015012315401525", "scjgj.sh.gov.cn", 3, 1, , , 0
[1:1:0711/230305.927340:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[32105:32105:0711/230306.352952:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/230307.131349:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
