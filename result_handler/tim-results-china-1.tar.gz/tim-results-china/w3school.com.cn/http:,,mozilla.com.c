[0711/193802.353281:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193802.353692:INFO:switcher_clone.cc(787)] backtrace rip is 7f9dfa5c0891
[0711/193803.392326:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193803.392713:INFO:switcher_clone.cc(787)] backtrace rip is 7f870d8ae891
[1:1:0711/193803.404575:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/193803.404828:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/193803.410599:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[2914:2914:0711/193804.490842:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f89b5ddb-e367-4831-87d4-aaed51e49212
[0711/193804.630298:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193804.630622:INFO:switcher_clone.cc(787)] backtrace rip is 7f168a046891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[2946:2946:0711/193804.851778:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2946
[2958:2958:0711/193804.852173:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2958
[2914:2914:0711/193804.928798:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[2914:2944:0711/193804.929497:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/193804.929730:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/193804.929972:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/193804.930570:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/193804.930756:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/193804.933856:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1609eb, 1
[1:1:0711/193804.934257:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1212b9c0, 0
[1:1:0711/193804.934520:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x22a2cd83, 3
[1:1:0711/193804.934800:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x28aac1ef, 2
[1:1:0711/193804.935053:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc0ffffffb91212 ffffffeb091600 ffffffefffffffc1ffffffaa28 ffffff83ffffffcdffffffa222 , 10104, 4
[1:1:0711/193804.936143:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2914:2944:0711/193804.936456:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���	
[2914:2944:0711/193804.936625:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���	
[1:1:0711/193804.936406:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f870bae90a0, 3
[1:1:0711/193804.936789:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f870bc74080, 2
[2914:2944:0711/193804.937003:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[2914:2944:0711/193804.937077:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2966, 4, c0b91212 eb091600 efc1aa28 83cda222 
[1:1:0711/193804.937007:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f86f5937d20, -2
[1:1:0711/193804.981279:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/193804.982250:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 28aac1ef
[1:1:0711/193804.983175:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 28aac1ef
[1:1:0711/193804.984751:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 28aac1ef
[1:1:0711/193804.986199:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.986419:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.986652:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.986867:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.987549:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 28aac1ef
[1:1:0711/193804.987913:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f870d8ae7ba
[1:1:0711/193804.988120:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f870d8a5def, 7f870d8ae77a, 7f870d8b00cf
[1:1:0711/193804.993811:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 28aac1ef
[1:1:0711/193804.994189:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 28aac1ef
[1:1:0711/193804.994954:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 28aac1ef
[1:1:0711/193804.997013:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.997244:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.997470:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.997766:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28aac1ef
[1:1:0711/193804.999076:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 28aac1ef
[1:1:0711/193804.999475:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f870d8ae7ba
[1:1:0711/193804.999659:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f870d8a5def, 7f870d8ae77a, 7f870d8b00cf
[1:1:0711/193805.007448:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/193805.008036:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/193805.008181:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcd22a6f18, 0x7ffcd22a6e98)
[1:1:0711/193805.024656:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/193805.030461:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[2914:2914:0711/193805.650854:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2914:2914:0711/193805.652078:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2914:2925:0711/193805.663136:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[2914:2925:0711/193805.663362:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[2914:2914:0711/193805.663508:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[2914:2914:0711/193805.663594:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[2914:2914:0711/193805.663802:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,2966, 4
[1:7:0711/193805.665580:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[2914:2936:0711/193805.702973:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/193805.805522:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2872bfd6d220
[1:1:0711/193805.805778:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/193806.248131:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[2914:2914:0711/193807.897462:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[2914:2914:0711/193807.897598:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/193807.904472:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193807.907876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/193809.265907:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193809.407590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2345434e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/193809.407868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193809.424249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2345434e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/193809.424476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193809.671456:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193809.671674:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193809.937219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193809.939736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2345434e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/193809.939860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193809.966755:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193809.977367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2345434e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/193809.977595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193809.989167:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[2914:2914:0711/193809.991795:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/193809.992681:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2872bfd6be20
[1:1:0711/193809.992879:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[2914:2914:0711/193809.999937:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[2914:2914:0711/193810.056119:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[2914:2914:0711/193810.056342:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/193810.074463:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193810.742994:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f86f75122e0 0x2872bff8e960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193810.743974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2345434e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/193810.744454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193810.745944:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2914:2914:0711/193810.791855:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/193810.793678:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2872bfd6c820
[1:1:0711/193810.793867:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[2914:2914:0711/193810.798741:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/193810.806800:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/193810.806936:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[2914:2914:0711/193810.814409:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[2914:2914:0711/193810.824356:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2914:2914:0711/193810.825366:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2914:2925:0711/193810.831323:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[2914:2925:0711/193810.831414:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[2914:2914:0711/193810.831584:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[2914:2914:0711/193810.831663:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[2914:2914:0711/193810.831800:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,2966, 4
[1:7:0711/193810.835184:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193811.572229:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/193811.802853:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f86f75122e0 0x2872c0085660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193811.803935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2345434e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/193811.804173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193811.804930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2914:2914:0711/193811.933859:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[2914:2914:0711/193811.933946:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/193811.972884:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[2914:2914:0711/193812.230681:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[2914:2944:0711/193812.231205:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/193812.231390:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/193812.231616:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/193812.232036:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/193812.232249:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/193812.235466:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x38c59dd6, 1
[1:1:0711/193812.235820:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x10d50a77, 0
[1:1:0711/193812.235965:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3f00da37, 3
[1:1:0711/193812.236160:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2ba0d831, 2
[1:1:0711/193812.236297:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 770affffffd510 ffffffd6ffffff9dffffffc538 31ffffffd8ffffffa02b 37ffffffda003f , 10104, 5
[1:1:0711/193812.237290:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2914:2944:0711/193812.237501:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGw
�֝�81ؠ+7�
[2914:2944:0711/193812.237568:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is w
�֝�81ؠ+7�
[1:1:0711/193812.237677:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f870bae90a0, 3
[2914:2944:0711/193812.237835:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3010, 5, 770ad510 d69dc538 31d8a02b 37da003f 
[1:1:0711/193812.237844:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f870bc74080, 2
[1:1:0711/193812.238079:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f86f5937d20, -2
[1:1:0711/193812.261296:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/193812.261588:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ba0d831
[1:1:0711/193812.261901:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ba0d831
[1:1:0711/193812.262540:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ba0d831
[1:1:0711/193812.263868:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.264086:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.264313:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.264482:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.265102:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ba0d831
[1:1:0711/193812.265374:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f870d8ae7ba
[1:1:0711/193812.265498:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f870d8a5def, 7f870d8ae77a, 7f870d8b00cf
[1:1:0711/193812.271265:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ba0d831
[1:1:0711/193812.271825:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ba0d831
[1:1:0711/193812.272585:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ba0d831
[1:1:0711/193812.274616:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.274827:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.275028:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.275243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba0d831
[1:1:0711/193812.276482:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ba0d831
[1:1:0711/193812.276858:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f870d8ae7ba
[1:1:0711/193812.277059:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f870d8a5def, 7f870d8ae77a, 7f870d8b00cf
[1:1:0711/193812.280206:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193812.285063:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/193812.285549:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/193812.285699:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcd22a6f18, 0x7ffcd22a6e98)
[1:1:0711/193812.298673:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/193812.303108:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/193812.560193:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2872bfcea220
[1:1:0711/193812.560565:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/193812.952298:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193812.952553:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[2914:2914:0711/193813.160294:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2914:2914:0711/193813.166331:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2914:2925:0711/193813.191167:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[2914:2925:0711/193813.191226:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[2914:2914:0711/193813.199115:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://mozilla.com.cn/
[2914:2914:0711/193813.199199:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://mozilla.com.cn/, http://mozilla.com.cn/moz-portal.html, 1
[2914:2914:0711/193813.199352:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://mozilla.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 02:38:13 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Server: nginx Set-Cookie: 0kLe_2132_saltkey=dtxx1Utj; expires=Sun, 11-Aug-2019 02:38:13 GMT; Max-Age=2592000; path=/; httponly Set-Cookie: 0kLe_2132_lastvisit=1562895493; expires=Sun, 11-Aug-2019 02:38:13 GMT; Max-Age=2592000; path=/ Set-Cookie: 0kLe_2132_sid=Bmu2ST; expires=Sat, 13-Jul-2019 02:38:13 GMT; Max-Age=86400; path=/ Set-Cookie: 0kLe_2132_lastact=1562899093%09plugin.php%09; expires=Sat, 13-Jul-2019 02:38:13 GMT; Max-Age=86400; path=/ Content-Encoding: gzip Vary: Accept-Encoding  ,3010, 5
[1:7:0711/193813.202544:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193813.235122:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://mozilla.com.cn/
[1:1:0711/193813.274295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/193813.278976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 23454360e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/193813.279379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/193813.287274:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[2914:2914:0711/193813.375084:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://mozilla.com.cn/, http://mozilla.com.cn/, 1
[2914:2914:0711/193813.375177:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://mozilla.com.cn/, http://mozilla.com.cn
[1:1:0711/193813.388771:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/193813.476108:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193813.567355:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193813.567565:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193813.635718:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193813.636552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2345434e1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/193813.636793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/193814.355529:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.360065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , /* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy
[1:1:0711/193814.360313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193814.362334:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193814.383935:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.395979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.452702:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.468127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.626965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.635342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.681378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169 0x7f86f55ea070 0x2872bfe60c60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193814.729255:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.346298, 61, 1
[1:1:0711/193814.729538:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193814.783026:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193814.784090:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193814.784526:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193814.784992:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193814.786442:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193815.672160:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193815.672402:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193815.675382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f86f55ea070 0x2872c00a8be0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193815.676587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , /*
	[Discuz!] (C)2001-2099 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$
[1:1:0711/193815.676804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193815.683905:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0113919, 62, 1
[1:1:0711/193815.684148:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193816.538687:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193816.538953:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193816.541897:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7f86f55ea070 0x2872bfdbdde0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193816.543563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , !function(d){var b='[data-toggle="dropdown"]',a=function(f){var e=d(f).on("click.dropdown.data-api",
[1:1:0711/193816.543784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193816.551433:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7f86f55ea070 0x2872bfdbdde0 , "http://mozilla.com.cn/moz-portal.html"
[3:3:0711/193823.664731:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/193823.788574:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 7.24955, 0, 0
[1:1:0711/193823.788872:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193824.299940:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193824.502399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/193824.502682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193824.930467:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193824.930626:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193824.932104:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354 0x7f86f55ea070 0x2872c00b0260 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193824.932916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , function doSearch() {
	searchFocus(jQuery('#scbar_txt'));
	var engineDisplayElement = jQuery('#engin
[1:1:0711/193824.933069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193824.938088:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00741196, 59, 1
[1:1:0711/193824.938201:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193825.292184:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f86f75122e0 0x2872c00b02e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193825.302501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , (function(){var h={},mt={},c={id:"d78cc3d5d410149533738ffc6006a9c6",dm:["mozilla.com.cn"],js:"tongji
[1:1:0711/193825.302869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193825.356213:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823948
[1:1:0711/193825.356517:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193825.357034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 402
[1:1:0711/193825.357290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 402 0x7f86f55ea070 0x2872c00a2460 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 375 0x7f86f75122e0 0x2872c00b02e0 
[1:1:0711/193825.973978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 600000
[1:1:0711/193825.974484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 426
[1:1:0711/193825.974754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 426 0x7f86f55ea070 0x2872c022a860 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 375 0x7f86f75122e0 0x2872c00b02e0 
[1:1:0711/193825.975636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 5000
[1:1:0711/193825.976193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 427
[1:1:0711/193825.976453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 427 0x7f86f55ea070 0x2872bf8d2ee0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 375 0x7f86f75122e0 0x2872c00b02e0 
[1:1:0711/193826.109561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193826.110386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193826.272516:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193826.272760:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193826.273729:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389 0x7f86f55ea070 0x2872c00b43e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193826.274639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , 
initSearchmenu('scbar', '');

[1:1:0711/193826.274895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193826.284034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193826.291913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389 0x7f86f55ea070 0x2872c00b43e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193826.305735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389 0x7f86f55ea070 0x2872c00b43e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193826.382115:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[2914:2914:0711/193826.402371:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/193826.402698:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2872c0480420
[1:1:0711/193826.402981:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[2914:2914:0711/193826.409273:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0711/193826.444850:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/193826.445121:INFO:render_frame_impl.cc(7019)] 	 [url] = http://mozilla.com.cn
[2914:2914:0711/193826.447939:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://mozilla.com.cn/
[1:1:0711/193826.459213:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.186315, 778, 1
[1:1:0711/193826.459486:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[2914:2914:0711/193826.722300:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/193827.071744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 402, 7f86f7f2f881
[1:1:0711/193827.094935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"375 0x7f86f75122e0 0x2872c00b02e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193827.095328:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"375 0x7f86f75122e0 0x2872c00b02e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193827.095751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193827.096428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193827.096669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193827.097504:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193827.097696:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193827.098081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 523
[1:1:0711/193827.098321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7f86f55ea070 0x2872c00b2260 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 402 0x7f86f55ea070 0x2872c00a2460 
[2914:2914:0711/193827.230531:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2914:2914:0711/193827.236882:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2914:2925:0711/193827.251028:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[2914:2914:0711/193827.251085:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://widget.weibo.com/
[2914:2914:0711/193827.251130:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1, 4
[2914:2925:0711/193827.251133:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[2914:2914:0711/193827.251223:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://widget.weibo.com/, HTTP/1.1 200 OK Server: WeiBo/LB Date: Fri, 12 Jul 2019 02:38:26 GMT Content-Type: text/html Content-Length: 7003 Connection: keep-alive Vary: Host,Accept-Encoding Set-Cookie: U_TRS1=00000022.dc3e7015.5d27f2a2.e1524e72; path=/; expires=Mon, 09-Jul-29 02:38:26 GMT; domain=.sina.com.cn Set-Cookie: U_TRS2=00000022.dc4c7015.5d27f2a2.5a648924; path=/; domain=.sina.com.cn Content-Security-Policy: upgrade-insecure-requests xPlugins-Type: 1 Cache-Control: max-age=60, must-revalidate Pragma:  Expires: Fri, 12 Jul 2019 02:43:26 GMT Last-Modified: Fri, 12 Jul 2019 02:38:26 GMT DPOOL_HEADER: qubele35 Content-Encoding: gzip Set-Cookie: YF-Widget-G0=4a4609df0e4ef6187a7b4717d4e6cf12;Path=/ LB_HEADER: venus243 Strict-Transport-Security: max-age=31536000; preload  ,3010, 5
[1:7:0711/193827.253878:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193828.934919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193828.935264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193830.515803:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193830.515960:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193830.517701:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515 0x7f86f55ea070 0x2872c05d08e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193830.518147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , 
[1:1:0711/193830.518274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193830.519081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515 0x7f86f55ea070 0x2872c05d08e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193830.521900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515 0x7f86f55ea070 0x2872c05d08e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193830.567729:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515 0x7f86f55ea070 0x2872c05d08e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193830.571468:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0554669, 64, 1
[1:1:0711/193830.571619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193830.691921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 523, 7f86f7f2f881
[1:1:0711/193830.701272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"402 0x7f86f55ea070 0x2872c00a2460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193830.701485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"402 0x7f86f55ea070 0x2872c00a2460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193830.701689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193830.702013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193830.702113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193830.702433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193830.702533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193830.702736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 580
[1:1:0711/193830.702853:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7f86f55ea070 0x2872c0a594e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 523 0x7f86f55ea070 0x2872c00b2260 
[1:1:0711/193830.789148:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://widget.weibo.com/
[1:1:0711/193831.338756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193831.338970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193832.452059:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193832.452311:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.455222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f86f55ea070 0x2872c019bce0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.456044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , 
[1:1:0711/193832.456869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193832.460116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f86f55ea070 0x2872c019bce0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.472923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.647104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 3000
[1:1:0711/193832.647573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 619
[1:1:0711/193832.647801:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f86f55ea070 0x2872c089c560 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 577 0x7f86f55ea070 0x2872c019bce0 
[1:1:0711/193832.667869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.769342:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/193832.788094:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 580, 7f86f7f2f881
[1:1:0711/193832.815648:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"523 0x7f86f55ea070 0x2872c00b2260 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193832.816027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"523 0x7f86f55ea070 0x2872c00b2260 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193832.816456:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.817066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193832.817368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193832.818095:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193832.818363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193832.818813:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 636
[1:1:0711/193832.819079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7f86f55ea070 0x2872c0782960 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 580 0x7f86f55ea070 0x2872c0a594e0 
[2914:2914:0711/193832.837525:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/, 4
[2914:2914:0711/193832.837702:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://widget.weibo.com/, https://widget.weibo.com
[1:1:0711/193832.877330:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.878084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0711/193832.878464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193832.930621:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 427, 7f86f7f2f8db
[1:1:0711/193832.961648:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"375 0x7f86f75122e0 0x2872c00b02e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193832.961998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"375 0x7f86f75122e0 0x2872c00b02e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193832.962438:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 643
[1:1:0711/193832.962668:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7f86f55ea070 0x2872c08dea60 , 5:3_http://mozilla.com.cn/, 0, , 427 0x7f86f55ea070 0x2872bf8d2ee0 
[1:1:0711/193832.962958:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193832.963534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/193832.963753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193833.151035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193833.151336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/193833.767351:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193834.068480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 636, 7f86f7f2f881
[1:1:0711/193834.098003:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"580 0x7f86f55ea070 0x2872c0a594e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193834.098349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"580 0x7f86f55ea070 0x2872c0a594e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193834.098749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193834.099342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193834.099552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193834.100317:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193834.100514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193834.100912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 666
[1:1:0711/193834.101133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7f86f55ea070 0x2872c08ca8e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 636 0x7f86f55ea070 0x2872c0782960 
[1:1:0711/193834.136168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193834.136452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193834.623190:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193834.623450:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193834.664621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 663 0x7f86f55ea070 0x2872c07508e0 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193834.748196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , , 
            var $CONFIG = {
                $lang: "zh",
                $oid: "",
                
[1:1:0711/193834.748577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193835.649227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193835.649505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193835.673357:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 666, 7f86f7f2f881
[1:1:0711/193835.704972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"636 0x7f86f55ea070 0x2872c0782960 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193835.705336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"636 0x7f86f55ea070 0x2872c0782960 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193835.705740:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193835.706373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193835.706588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193835.707307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193835.707505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193835.707903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 693
[1:1:0711/193835.708162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f86f55ea070 0x2872c09d4560 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 666 0x7f86f55ea070 0x2872c08ca8e0 
[1:1:0711/193836.579048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 619, 7f86f7f2f8db
[1:1:0711/193836.611124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"577 0x7f86f55ea070 0x2872c019bce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193836.611589:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"577 0x7f86f55ea070 0x2872c019bce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193836.612193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 724
[1:1:0711/193836.612484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7f86f55ea070 0x2872c0023f60 , 5:3_http://mozilla.com.cn/, 0, , 619 0x7f86f55ea070 0x2872c089c560 
[1:1:0711/193836.612843:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193836.613424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0711/193836.613679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193836.705653:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193836.705987:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193836.706467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 727
[1:1:0711/193836.706736:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f86f55ea070 0x2872c04be9e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 619 0x7f86f55ea070 0x2872c089c560 
[1:1:0711/193836.713680:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0711/193836.714215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 728
[1:1:0711/193836.714458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f86f55ea070 0x2872c022e660 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 619 0x7f86f55ea070 0x2872c089c560 
[1:1:0711/193836.751015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193836.751317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193836.932235:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","https://addons.cdn.mozilla.net/user-media/addon_icons/0/748-64.png?modified=1531822767"
[1:1:0711/193836.935861:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 693, 7f86f7f2f881
[1:1:0711/193836.973393:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"666 0x7f86f55ea070 0x2872c08ca8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193836.973583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"666 0x7f86f55ea070 0x2872c08ca8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193836.973972:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193836.974537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193836.974771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193836.975575:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193836.975792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193836.976149:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 742
[1:1:0711/193836.976335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f86f55ea070 0x2872c0025160 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 693 0x7f86f55ea070 0x2872c09d4560 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/193837.017804:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","https://addons.cdn.mozilla.net/user-media/addon_icons/8/8542-64.png?modified=mcrushed"
[1:1:0711/193837.021316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 643, 7f86f7f2f8db
[1:1:0711/193837.056748:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"427 0x7f86f55ea070 0x2872bf8d2ee0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193837.057084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"427 0x7f86f55ea070 0x2872bf8d2ee0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193837.057604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 747
[1:1:0711/193837.057871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 747 0x7f86f55ea070 0x2872c00b1c60 , 5:3_http://mozilla.com.cn/, 0, , 643 0x7f86f55ea070 0x2872c08dea60 
[1:1:0711/193837.058184:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193837.058849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/193837.059071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193837.796609:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 727, 7f86f7f2f881
[1:1:0711/193837.833152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"619 0x7f86f55ea070 0x2872c089c560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193837.833532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"619 0x7f86f55ea070 0x2872c089c560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193837.834019:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193837.834675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193837.834893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193837.878483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 728, 7f86f7f2f8db
[1:1:0711/193837.919683:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"619 0x7f86f55ea070 0x2872c089c560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193837.920084:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"619 0x7f86f55ea070 0x2872c089c560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193837.920584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 775
[1:1:0711/193837.920821:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7f86f55ea070 0x2872c00b4e60 , 5:3_http://mozilla.com.cn/, 0, , 728 0x7f86f55ea070 0x2872c022e660 
[1:1:0711/193837.921181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193837.921822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0711/193837.922052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193837.923788:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193837.924022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193837.924458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 776
[1:1:0711/193837.924688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 776 0x7f86f55ea070 0x2872c0738d60 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 728 0x7f86f55ea070 0x2872c022e660 
[1:1:0711/193837.996208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193837.996369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193838.174553:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 742, 7f86f7f2f881
[1:1:0711/193838.185610:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"693 0x7f86f55ea070 0x2872c09d4560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193838.185796:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"693 0x7f86f55ea070 0x2872c09d4560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193838.186010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193838.186545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193838.186697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193838.187126:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193838.187276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193838.187457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 781
[1:1:0711/193838.187562:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7f86f55ea070 0x2872c094f560 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 742 0x7f86f55ea070 0x2872c0025160 
[1:1:0711/193838.830438:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 776, 7f86f7f2f881
[1:1:0711/193838.849517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"728 0x7f86f55ea070 0x2872c022e660 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193838.849889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"728 0x7f86f55ea070 0x2872c022e660 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193838.850356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193838.850948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193838.851185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193838.890238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193838.890542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193839.050842:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 784 0x7f86f5952bd0 0x2872bfe224d8 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193839.059473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , , var STK=function(){var a={};var b=[];a.inc=function(a,b){return true};a.register=function(c,d){var e
[1:1:0711/193839.059825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193839.166092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x2e1c0b282548, 0x2872bf823960
[1:1:0711/193839.166359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0711/193839.167242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 808
[1:1:0711/193839.167486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7f86f55ea070 0x2872c0a5a4e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 784 0x7f86f5952bd0 0x2872bfe224d8 
[1:1:0711/193839.382344:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.128466, 671, 1
[1:1:0711/193839.382568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193839.435776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 781, 7f86f7f2f881
[1:1:0711/193839.475346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"742 0x7f86f55ea070 0x2872c0025160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193839.475663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"742 0x7f86f55ea070 0x2872c0025160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193839.476090:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193839.476810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193839.477334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193839.478047:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193839.478209:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193839.478576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 847
[1:1:0711/193839.478765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7f86f55ea070 0x2872c08dec60 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 781 0x7f86f55ea070 0x2872c094f560 
[1:1:0711/193839.810102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 724, 7f86f7f2f8db
[1:1:0711/193839.848809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"619 0x7f86f55ea070 0x2872c089c560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193839.849126:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"619 0x7f86f55ea070 0x2872c089c560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193839.849592:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 857
[1:1:0711/193839.849865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 857 0x7f86f55ea070 0x2872c05d2160 , 5:3_http://mozilla.com.cn/, 0, , 724 0x7f86f55ea070 0x2872c0023f60 
[1:1:0711/193839.850170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193839.850779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0711/193839.850993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193839.908536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193839.908819:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193839.909227:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 858
[1:1:0711/193839.909479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f86f55ea070 0x2872bfdb8ee0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 724 0x7f86f55ea070 0x2872c0023f60 
[1:1:0711/193839.912319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0711/193839.912774:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 859
[1:1:0711/193839.913023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 859 0x7f86f55ea070 0x2872c0ad6460 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 724 0x7f86f55ea070 0x2872c0023f60 
[1:1:0711/193840.189544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193840.189708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193841.151251:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193841.151398:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193841.181965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 808, 7f86f7f2f881
[1:1:0711/193841.215468:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cca21f8","ptid":"784 0x7f86f5952bd0 0x2872bfe224d8 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193841.215774:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"784 0x7f86f5952bd0 0x2872bfe224d8 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193841.216086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193841.217076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0711/193841.217320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193841.218461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x2e1c0b282548, 0x2872bf823950
[1:1:0711/193841.218619:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0711/193841.219416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 890
[1:1:0711/193841.219620:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7f86f55ea070 0x2872c10a6b60 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 808 0x7f86f55ea070 0x2872c0a5a4e0 
[1:1:0711/193841.996581:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 847, 7f86f7f2f881
[1:1:0711/193842.035257:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"781 0x7f86f55ea070 0x2872c094f560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.035581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"781 0x7f86f55ea070 0x2872c094f560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.035923:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193842.036492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193842.036681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193842.037330:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193842.037509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193842.037870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 924
[1:1:0711/193842.038057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 924 0x7f86f55ea070 0x2872c10959e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 847 0x7f86f55ea070 0x2872c08dec60 
[1:1:0711/193842.119134:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 858, 7f86f7f2f881
[1:1:0711/193842.158391:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"724 0x7f86f55ea070 0x2872c0023f60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.158728:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"724 0x7f86f55ea070 0x2872c0023f60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.159072:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193842.159675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193842.159858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193842.180085:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 859, 7f86f7f2f8db
[1:1:0711/193842.192959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"724 0x7f86f55ea070 0x2872c0023f60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.193274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"724 0x7f86f55ea070 0x2872c0023f60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.193491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 926
[1:1:0711/193842.193631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7f86f55ea070 0x2872c0195860 , 5:3_http://mozilla.com.cn/, 0, , 859 0x7f86f55ea070 0x2872c0ad6460 
[1:1:0711/193842.193780:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193842.194065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0711/193842.194163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193842.194584:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193842.194678:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193842.194840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 927
[1:1:0711/193842.194938:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 927 0x7f86f55ea070 0x2872c0a5bb60 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 859 0x7f86f55ea070 0x2872c0ad6460 
[1:1:0711/193842.238684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193842.238971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193842.592885:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 747, 7f86f7f2f8db
[1:1:0711/193842.634483:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"643 0x7f86f55ea070 0x2872c08dea60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.634818:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"643 0x7f86f55ea070 0x2872c08dea60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193842.635209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 936
[1:1:0711/193842.635396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 936 0x7f86f55ea070 0x2872c094fbe0 , 5:3_http://mozilla.com.cn/, 0, , 747 0x7f86f55ea070 0x2872c00b1c60 
[1:1:0711/193842.635649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193842.636196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/193842.636363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193844.179747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 890, 7f86f7f2f881
[1:1:0711/193844.220493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cca21f8","ptid":"808 0x7f86f55ea070 0x2872c0a5a4e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193844.220877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"808 0x7f86f55ea070 0x2872c0a5a4e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193844.221283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193844.222320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0711/193844.222593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193844.224154:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x2e1c0b282548, 0x2872bf823950
[1:1:0711/193844.224483:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0711/193844.225633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 958
[1:1:0711/193844.225892:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7f86f55ea070 0x2872c11545e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 890 0x7f86f55ea070 0x2872c10a6b60 
[1:1:0711/193844.796423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 857, 7f86f7f2f8db
[1:1:0711/193844.837369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"724 0x7f86f55ea070 0x2872c0023f60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193844.837710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"724 0x7f86f55ea070 0x2872c0023f60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193844.838107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 972
[1:1:0711/193844.838327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7f86f55ea070 0x2872c0023160 , 5:3_http://mozilla.com.cn/, 0, , 857 0x7f86f55ea070 0x2872c05d2160 
[1:1:0711/193844.838667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193844.839204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0711/193844.839405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193844.899638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0711/193844.900115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 973
[1:1:0711/193844.900348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7f86f55ea070 0x2872c046c4e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 857 0x7f86f55ea070 0x2872c05d2160 
[1:1:0711/193844.995395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f86f5952bd0 0x2872c0473258 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193844.996575:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193845.004183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , , STK.register("kit.extra.language", function($) {
    window.$LANG || (window.$LANG = {});
    return
[1:1:0711/193845.004476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193845.316551:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x2e1c0b282548, 0x2872bf823960
[1:1:0711/193845.316863:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0711/193845.317710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 983
[1:1:0711/193845.317957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f86f55ea070 0x2872c00a5a60 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 912 0x7f86f5952bd0 0x2872c0473258 
[1:1:0711/193845.323922:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f86f5952bd0 0x2872c0473258 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193845.402604:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b282548, 0x2872bf8239a8
[1:1:0711/193845.402873:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 0
[1:1:0711/193845.403797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 996
[1:1:0711/193845.404049:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 996 0x7f86f55ea070 0x2872c1015360 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 912 0x7f86f5952bd0 0x2872c0473258 
[1:1:0711/193845.406767:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193845.871232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 924, 7f86f7f2f881
[1:1:0711/193845.913784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"847 0x7f86f55ea070 0x2872c08dec60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193845.914163:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"847 0x7f86f55ea070 0x2872c08dec60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193845.914575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193845.915172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193845.915383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193845.916133:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193845.916327:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193845.916720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1012
[1:1:0711/193845.916964:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7f86f55ea070 0x2872c05d0860 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 924 0x7f86f55ea070 0x2872c10959e0 
[1:1:0711/193845.918492:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 927, 7f86f7f2f881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/193845.962346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"859 0x7f86f55ea070 0x2872c0ad6460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193845.962693:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"859 0x7f86f55ea070 0x2872c0ad6460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193845.963225:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193845.963996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193845.964219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193846.195416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193846.195737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193846.816370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 958, 7f86f7f2f881
[1:1:0711/193846.847603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cca21f8","ptid":"890 0x7f86f55ea070 0x2872c10a6b60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193846.847979:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"890 0x7f86f55ea070 0x2872c10a6b60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193846.848418:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193846.849416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0711/193846.849674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193846.852656:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 973, 7f86f7f2f8db
[1:1:0711/193846.880660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"857 0x7f86f55ea070 0x2872c05d2160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193846.880999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"857 0x7f86f55ea070 0x2872c05d2160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193846.881472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1040
[1:1:0711/193846.881713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7f86f55ea070 0x2872c12815e0 , 5:3_http://mozilla.com.cn/, 0, , 973 0x7f86f55ea070 0x2872c046c4e0 
[1:1:0711/193846.882092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193846.882652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0711/193846.882867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193846.883848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193846.884075:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193846.884582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1041
[1:1:0711/193846.884823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7f86f55ea070 0x2872c11545e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 973 0x7f86f55ea070 0x2872c046c4e0 
[1:1:0711/193847.081340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193847.082574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , h, (){if(c==true){return}c=true;for(var a=0,e=b.length;a<e;a++){if(d(b[a])==="function"){try{b[a].call(
[1:1:0711/193847.082856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193847.098206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193847.098960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://widget.weibo.com/-5:3_http://mozilla.com.cn/, 2f9f4cbc2860, 2f9f4cca21f8, cardInit, () {
	var cardShow = function (obj) {
		if(BROWSER.ie && BROWSER.ie < 7 && obj.href.indexOf('usernam
[1:1:0711/193847.099196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 2, , , 0
[1:1:0711/193847.099631:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0711/193847.128380:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193847.129108:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193847.129721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193847.133075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193847.134330:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193847.135221:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf8239f0
[1:1:0711/193847.135501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193847.135927:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1049
[1:1:0711/193847.136212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1049 0x7f86f55ea070 0x2872c05d7d60 , 5:4_https://widget.weibo.com/, 2, -5:4_https://widget.weibo.com/-5:3_http://mozilla.com.cn/, 982
[1:1:0711/193847.774001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 983, 7f86f7f2f881
[1:1:0711/193847.795154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cca21f8","ptid":"912 0x7f86f5952bd0 0x2872c0473258 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193847.795543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"912 0x7f86f5952bd0 0x2872c0473258 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193847.796021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193847.797073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , h, (){var a=+(new Date);do{f.process.call(f.context,e.shift())}while(e.length>0&&+(new Date)-a<f.execTi
[1:1:0711/193847.797333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193848.101359:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 996, 7f86f7f2f881
[1:1:0711/193848.142365:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cca21f8","ptid":"912 0x7f86f5952bd0 0x2872c0473258 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193848.142709:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"912 0x7f86f5952bd0 0x2872c0473258 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193848.143108:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193848.144085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , q, (){if(ax||x){return}if(t<3&&typeof __GLOBAL_STATS_PAGESTART_TIME__!="undefined"){t++;if(typeof __GLO
[1:1:0711/193848.144399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193848.234217:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2e1c0b282548, 0x2872bf823950
[1:1:0711/193848.234493:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 2000
[1:1:0711/193848.235326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1081
[1:1:0711/193848.235558:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1081 0x7f86f55ea070 0x2872c03126e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 996 0x7f86f55ea070 0x2872c1015360 
[1:1:0711/193848.357169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 936, 7f86f7f2f8db
[1:1:0711/193848.398615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"747 0x7f86f55ea070 0x2872c00b1c60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193848.398940:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"747 0x7f86f55ea070 0x2872c00b1c60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193848.399397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1086
[1:1:0711/193848.399643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7f86f55ea070 0x2872c10ebfe0 , 5:3_http://mozilla.com.cn/, 0, , 936 0x7f86f55ea070 0x2872c094fbe0 
[1:1:0711/193848.400044:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193848.400598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/193848.400844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[2914:2914:0711/193848.657201:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/193848.692332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , document.readyState
[1:1:0711/193848.692613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193849.108234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1041, 7f86f7f2f881
[1:1:0711/193849.151881:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"973 0x7f86f55ea070 0x2872c046c4e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193849.152282:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"973 0x7f86f55ea070 0x2872c046c4e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193849.152730:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193849.153337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193849.153545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193849.499093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1049, 7f86f7f2f881
[1:1:0711/193849.541769:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cca21f82f9f4cbc2860","ptid":"982","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193849.542122:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/-5:3_http://mozilla.com.cn/","ptid":"982","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193849.542537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193849.543131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193849.543373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193849.544109:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193849.544380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193849.544923:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1105
[1:1:0711/193849.545163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7f86f55ea070 0x2872c1015360 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1049 0x7f86f55ea070 0x2872c05d7d60 
[1:1:0711/193849.638061:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 972, 7f86f7f2f8db
[1:1:0711/193849.676364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"857 0x7f86f55ea070 0x2872c05d2160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193849.676658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"857 0x7f86f55ea070 0x2872c05d2160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193849.677107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1106
[1:1:0711/193849.677338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f86f55ea070 0x2872bfcff6e0 , 5:3_http://mozilla.com.cn/, 0, , 972 0x7f86f55ea070 0x2872c0023160 
[1:1:0711/193849.677676:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193849.678271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0711/193849.678480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193849.729375:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193849.729609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193849.729997:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1108
[1:1:0711/193849.730238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1108 0x7f86f55ea070 0x2872c10959e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 972 0x7f86f55ea070 0x2872c0023160 
[1:1:0711/193849.732102:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0711/193849.732527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1109
[1:1:0711/193849.732747:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7f86f55ea070 0x2872c07733e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 972 0x7f86f55ea070 0x2872c0023160 
[1:1:0711/193851.591543:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1105, 7f86f7f2f881
[1:1:0711/193851.615072:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"1049 0x7f86f55ea070 0x2872c05d7d60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193851.615420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1049 0x7f86f55ea070 0x2872c05d7d60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193851.615852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193851.616531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193851.616743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193851.617451:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193851.617672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193851.618159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1150
[1:1:0711/193851.618408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1150 0x7f86f55ea070 0x2872c091f0e0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1105 0x7f86f55ea070 0x2872c1015360 
[1:1:0711/193851.635048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1108, 7f86f7f2f881
[1:1:0711/193851.679964:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"972 0x7f86f55ea070 0x2872c0023160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193851.680375:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"972 0x7f86f55ea070 0x2872c0023160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193851.680800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193851.681289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193851.681514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193851.682899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1109, 7f86f7f2f8db
[1:1:0711/193851.708683:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"972 0x7f86f55ea070 0x2872c0023160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193851.709026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"972 0x7f86f55ea070 0x2872c0023160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193851.709492:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1151
[1:1:0711/193851.709719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1151 0x7f86f55ea070 0x2872c0920fe0 , 5:3_http://mozilla.com.cn/, 0, , 1109 0x7f86f55ea070 0x2872c07733e0 
[1:1:0711/193851.710075:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193851.710631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0711/193851.710849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193851.711805:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193851.712088:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193851.712485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1152
[1:1:0711/193851.712721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1152 0x7f86f55ea070 0x2872c0914860 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1109 0x7f86f55ea070 0x2872c07733e0 
[1:1:0711/193851.768442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1081, 7f86f7f2f881
[1:1:0711/193851.814243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cca21f8","ptid":"996 0x7f86f55ea070 0x2872c1015360 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193851.814619:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"996 0x7f86f55ea070 0x2872c1015360 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193851.815193:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0711/193851.816286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2f9f4cca21f8, , , (){if(D&&D.callback&&typeof D.callback=="function"){D.callback(false);e.onload=null}}
[1:1:0711/193851.816557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0711/193851.915438:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1106, 7f86f7f2f8db
[1:1:0711/193851.960366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"972 0x7f86f55ea070 0x2872c0023160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193851.960691:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"972 0x7f86f55ea070 0x2872c0023160 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193851.961216:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1156
[1:1:0711/193851.961452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1156 0x7f86f55ea070 0x2872c11674e0 , 5:3_http://mozilla.com.cn/, 0, , 1106 0x7f86f55ea070 0x2872bfcff6e0 
[1:1:0711/193851.961812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193851.962410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0711/193851.962630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193851.990225:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0711/193851.990690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1157
[1:1:0711/193851.990929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1157 0x7f86f55ea070 0x2872c091f460 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1106 0x7f86f55ea070 0x2872bfcff6e0 
[1:1:0711/193852.207021:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1086, 7f86f7f2f8db
[1:1:0711/193852.263864:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"936 0x7f86f55ea070 0x2872c094fbe0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193852.264263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"936 0x7f86f55ea070 0x2872c094fbe0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193852.264729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1162
[1:1:0711/193852.264956:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1162 0x7f86f55ea070 0x2872c095f1e0 , 5:3_http://mozilla.com.cn/, 0, , 1086 0x7f86f55ea070 0x2872c10ebfe0 
[1:1:0711/193852.265330:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193852.265881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/193852.266087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193852.952840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1152, 7f86f7f2f881
[1:1:0711/193853.009809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"1109 0x7f86f55ea070 0x2872c07733e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193853.010168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1109 0x7f86f55ea070 0x2872c07733e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193853.010573:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193853.011195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193853.011422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193853.013119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1150, 7f86f7f2f881
[1:1:0711/193853.057886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"1105 0x7f86f55ea070 0x2872c1015360 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193853.058205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1105 0x7f86f55ea070 0x2872c1015360 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193853.058614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193853.059156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193853.059363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193853.060097:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193853.060323:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193853.060746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1175
[1:1:0711/193853.060978:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7f86f55ea070 0x2872c04ad5e0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1150 0x7f86f55ea070 0x2872c091f0e0 
[1:1:0711/193853.062353:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1157, 7f86f7f2f8db
[1:1:0711/193853.116080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"1106 0x7f86f55ea070 0x2872bfcff6e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193853.116406:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1106 0x7f86f55ea070 0x2872bfcff6e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193853.116845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1176
[1:1:0711/193853.117096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7f86f55ea070 0x2872c0db4d60 , 5:3_http://mozilla.com.cn/, 0, , 1157 0x7f86f55ea070 0x2872c091f460 
[1:1:0711/193853.117492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193853.118024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0711/193853.118230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193853.119211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193853.119402:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0711/193853.119790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1177
[1:1:0711/193853.120041:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7f86f55ea070 0x2872c0ba1d60 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1157 0x7f86f55ea070 0x2872c091f460 
[1:1:0711/193853.300413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1177, 7f86f7f2f881
[1:1:0711/193853.315761:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"1157 0x7f86f55ea070 0x2872c091f460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193853.316062:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1157 0x7f86f55ea070 0x2872c091f460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0711/193853.316451:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193853.317010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , ct, (){cr=b}
[1:1:0711/193853.317215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193853.363364:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1175, 7f86f7f2f881
[1:1:0711/193853.406651:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"1150 0x7f86f55ea070 0x2872c091f0e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193853.406974:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1150 0x7f86f55ea070 0x2872c091f0e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193853.407381:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193853.407956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193853.408198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193853.408910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193853.409101:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193853.409491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1183
[1:1:0711/193853.409789:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1183 0x7f86f55ea070 0x2872bfe25a60 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1175 0x7f86f55ea070 0x2872c04ad5e0 
[1:1:0711/193853.529402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1183, 7f86f7f2f881
[1:1:0711/193853.545717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2f9f4cbc2860","ptid":"1175 0x7f86f55ea070 0x2872c04ad5e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193853.546017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1175 0x7f86f55ea070 0x2872c04ad5e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0711/193853.546414:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0711/193853.547000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2f9f4cbc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/193853.547222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0711/193853.547938:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2e1c0b1829c8, 0x2872bf823950
[1:1:0711/193853.548152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0711/193853.548541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1186
[1:1:0711/193853.548777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1186 0x7f86f55ea070 0x2872bf8f4960 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1183 0x7f86f55ea070 0x2872bfe25a60 
[1:1:0711/193853.700860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1156, 7f86f7f2f8db
