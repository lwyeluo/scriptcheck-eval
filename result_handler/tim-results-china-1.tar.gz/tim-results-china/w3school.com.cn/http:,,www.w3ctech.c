[0711/193921.621079:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193921.621513:INFO:switcher_clone.cc(787)] backtrace rip is 7f5a25ef3891
[0711/193922.718609:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193922.719005:INFO:switcher_clone.cc(787)] backtrace rip is 7f453a3dd891
[1:1:0711/193922.730597:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/193922.730854:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/193922.736353:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[3215:3215:0711/193923.968833:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0637832f-3cce-4187-b27b-0ce7877c9c1c
[0711/193924.240015:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193924.240453:INFO:switcher_clone.cc(787)] backtrace rip is 7f2123ae5891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[3215:3215:0711/193924.407263:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[3215:3244:0711/193924.408220:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/193924.408452:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/193924.408661:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/193924.409250:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/193924.409424:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/193924.413529:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x34e84385, 1
[1:1:0711/193924.414928:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x130b1e26, 0
[1:1:0711/193924.415607:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1f1438c3, 3
[1:1:0711/193924.416230:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2be777bc, 2
[1:1:0711/193924.416909:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 261e0b13 ffffff8543ffffffe834 ffffffbc77ffffffe72b ffffffc338141f , 10104, 4
[1:1:0711/193924.418100:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3215:3244:0711/193924.418361:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING&�C�4�w�+�8�%
[1:1:0711/193924.418339:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f45386180a0, 3
[3215:3244:0711/193924.418450:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is &�C�4�w�+�8���%
[3215:3244:0711/193924.418760:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/193924.418539:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f45387a3080, 2
[3215:3244:0711/193924.418837:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3259, 4, 261e0b13 8543e834 bc77e72b c338141f 
[1:1:0711/193924.418895:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4522466d20, -2
[1:1:0711/193924.441390:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/193924.442399:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2be777bc
[1:1:0711/193924.443504:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2be777bc
[1:1:0711/193924.445386:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2be777bc
[1:1:0711/193924.447235:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.447455:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.447687:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.447907:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.448703:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2be777bc
[1:1:0711/193924.449802:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f453a3dd7ba
[1:1:0711/193924.449982:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f453a3d4def, 7f453a3dd77a, 7f453a3df0cf
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/193924.457979:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2be777bc
[1:1:0711/193924.458443:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2be777bc
[1:1:0711/193924.459369:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2be777bc
[1:1:0711/193924.461876:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.462112:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.462372:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.462595:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2be777bc
[1:1:0711/193924.464125:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2be777bc
[1:1:0711/193924.464605:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f453a3dd7ba
[1:1:0711/193924.464791:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f453a3d4def, 7f453a3dd77a, 7f453a3df0cf
[3246:3246:0711/193924.472582:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3246
[3260:3260:0711/193924.473087:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3260
[1:1:0711/193924.474369:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/193924.474944:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/193924.475113:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffef2598508, 0x7ffef2598488)
[1:1:0711/193924.494089:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/193924.501458:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3215:3236:0711/193925.067716:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[3215:3215:0711/193925.089985:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3215:3215:0711/193925.091242:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3215:3225:0711/193925.114521:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[3215:3225:0711/193925.114642:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[3215:3215:0711/193925.114761:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[3215:3215:0711/193925.114843:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[3215:3215:0711/193925.114981:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,3259, 4
[1:7:0711/193925.116876:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193925.133576:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1d2e95f1f220
[1:1:0711/193925.133812:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/193925.499003:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0711/193926.632475:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193926.636946:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3215:3215:0711/193926.669227:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[3215:3215:0711/193926.669312:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/193927.831286:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193928.035144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20b67d461f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/193928.035627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193928.071471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20b67d461f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/193928.071915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193928.182528:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193928.182923:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193928.454484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193928.462979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20b67d461f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/193928.463272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193928.492553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193928.503110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20b67d461f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/193928.503529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193928.523854:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[3215:3215:0711/193928.527764:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/193928.528011:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1d2e95f1de20
[1:1:0711/193928.528225:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[3215:3215:0711/193928.532868:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[3215:3215:0711/193928.571289:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[3215:3215:0711/193928.571440:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/193928.644906:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193929.559478:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f45240412e0 0x1d2e961e7e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193929.562886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20b67d461f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/193929.563533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193929.567911:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[3215:3215:0711/193929.665105:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[3215:3215:0711/193929.668702:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/193929.670903:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1d2e95f1e820
[1:1:0711/193929.671325:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/193929.690992:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/193929.691331:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[3215:3215:0711/193929.702299:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[3215:3215:0711/193929.714032:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3215:3215:0711/193929.715025:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3215:3225:0711/193929.720862:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[3215:3225:0711/193929.720948:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[3215:3215:0711/193929.721092:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[3215:3215:0711/193929.721187:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[3215:3215:0711/193929.721322:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,3259, 4
[1:7:0711/193929.730324:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193930.378021:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/193930.654857:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f45240412e0 0x1d2e95fd4260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193930.656018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20b67d461f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/193930.656294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193930.657120:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193930.756072:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3215:3215:0711/193930.762305:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[3215:3215:0711/193930.762399:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/193931.206430:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193931.669150:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193931.669435:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[3215:3215:0711/193931.802686:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[3215:3244:0711/193931.803069:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/193931.803265:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/193931.803487:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/193931.803892:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/193931.804035:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/193931.806774:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x27f21b55, 1
[1:1:0711/193931.807018:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x287d00f, 0
[1:1:0711/193931.807113:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x16a28c2d, 3
[1:1:0711/193931.807197:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3faaa8e0, 2
[1:1:0711/193931.807273:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 0fffffffd0ffffff8702 551bfffffff227 ffffffe0ffffffa8ffffffaa3f 2dffffff8cffffffa216 , 10104, 5
[1:1:0711/193931.808045:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3215:3244:0711/193931.808274:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGЇU�'ਪ?-���%
[1:1:0711/193931.808255:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f45386180a0, 3
[3215:3244:0711/193931.808349:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ЇU�'ਪ?-��X��%
[1:1:0711/193931.808368:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f45387a3080, 2
[1:1:0711/193931.808471:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4522466d20, -2
[3215:3244:0711/193931.808629:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3310, 5, 0fd08702 551bf227 e0a8aa3f 2d8ca216 
[1:1:0711/193931.830172:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/193931.830569:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3faaa8e0
[1:1:0711/193931.830977:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3faaa8e0
[1:1:0711/193931.831734:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3faaa8e0
[1:1:0711/193931.833477:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.833727:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.833952:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.834162:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.834968:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3faaa8e0
[1:1:0711/193931.835308:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f453a3dd7ba
[1:1:0711/193931.835466:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f453a3d4def, 7f453a3dd77a, 7f453a3df0cf
[1:1:0711/193931.842266:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3faaa8e0
[1:1:0711/193931.842722:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3faaa8e0
[1:1:0711/193931.843634:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3faaa8e0
[1:1:0711/193931.846123:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.846385:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.846640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.846864:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3faaa8e0
[1:1:0711/193931.848383:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3faaa8e0
[1:1:0711/193931.848865:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f453a3dd7ba
[1:1:0711/193931.849026:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f453a3d4def, 7f453a3dd77a, 7f453a3df0cf
[1:1:0711/193931.858430:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/193931.858998:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/193931.859167:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffef2598508, 0x7ffef2598488)
[1:1:0711/193931.875335:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/193931.880236:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/193931.983518:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/193931.986441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20b67d58e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/193931.986735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/193931.989554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/193932.113797:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1d2e95ef8220
[1:1:0711/193932.114041:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[3215:3215:0711/193932.486694:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3215:3215:0711/193932.527886:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[3215:3244:0711/193932.528385:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0711/193932.528586:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/193932.528796:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/193932.529175:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/193932.529323:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0711/193932.531891:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3acfaab4, 1
[1:1:0711/193932.532190:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3d29581b, 0
[1:1:0711/193932.532375:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x28647052, 3
[1:1:0711/193932.532533:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x38c9a313, 2
[1:1:0711/193932.532760:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1b58293d ffffffb4ffffffaaffffffcf3a 13ffffffa3ffffffc938 52706428 , 10104, 6
[1:1:0711/193932.533695:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3215:3244:0711/193932.533963:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGX)=���:��8Rpd(�%
[3215:3244:0711/193932.534041:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is X)=���:��8Rpd(8�%
[3215:3244:0711/193932.534292:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3326, 6, 1b58293d b4aacf3a 13a3c938 52706428 
[1:1:0711/193932.534146:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f45386180a0, 3
[1:1:0711/193932.534625:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f45387a3080, 2
[1:1:0711/193932.534843:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4522466d20, -2
[3215:3215:0711/193932.561410:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/193932.561426:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/193932.561840:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38c9a313
[1:1:0711/193932.562093:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38c9a313
[1:1:0711/193932.562693:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38c9a313
[1:1:0711/193932.564113:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.564301:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.564485:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.564706:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.565509:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38c9a313
[1:1:0711/193932.565867:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f453a3dd7ba
[1:1:0711/193932.566028:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f453a3d4def, 7f453a3dd77a, 7f453a3df0cf
[1:1:0711/193932.572935:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38c9a313
[1:1:0711/193932.573357:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38c9a313
[1:1:0711/193932.574253:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38c9a313
[1:1:0711/193932.576758:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.577022:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.577253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.577471:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38c9a313
[1:1:0711/193932.579001:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38c9a313
[1:1:0711/193932.579442:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f453a3dd7ba
[1:1:0711/193932.579599:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f453a3d4def, 7f453a3dd77a, 7f453a3df0cf
[1:1:0711/193932.589002:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/193932.589550:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/193932.589736:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffef2598508, 0x7ffef2598488)
[3215:3225:0711/193932.593240:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[3215:3225:0711/193932.593354:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[3215:3215:0711/193932.597533:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.w3ctech.com/
[3215:3215:0711/193932.597626:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.w3ctech.com/, https://www.w3ctech.com/, 1
[3215:3215:0711/193932.597843:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.w3ctech.com/, HTTP/1.1 200 status:200 server:nginx/1.12.1 date:Fri, 12 Jul 2019 02:39:32 GMT content-type:text/html; charset=utf-8 x-powered-by:thinkjs-1.2.11 set-cookie:thinkjs=6nhmbu0cNZkOEGzgcEfSBN1jAwQMd0A3; Domain=w3ctech.com; Path=/; Expires=Sun, 11 Aug 2019 02:39:32 GMT strict-transport-security:max-age=31536000; includeSubDomains  ,0, 6
[3:3:0711/193932.601018:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/193932.604980:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/193932.609281:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0711/193932.672909:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193932.818470:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1d2e95efb220
[1:1:0711/193932.818784:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/193932.905516:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.w3ctech.com/
[1:1:0711/193933.187385:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3215:3215:0711/193933.194618:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.w3ctech.com/, https://www.w3ctech.com/, 1
[3215:3215:0711/193933.194743:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.w3ctech.com/, https://www.w3ctech.com
[1:1:0711/193933.239621:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193933.326553:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/193933.363873:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193933.364109:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.w3ctech.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/193933.822071:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193933.983815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f4522481bd0 0x1d2e95d458d8 , "https://www.w3ctech.com/"
[1:1:0711/193933.993100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , /*! jQuery v1.11.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0711/193933.993334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193934.013199:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193934.175433:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193934.176056:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193934.178706:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193934.179580:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193934.180013:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193934.356778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f4522481bd0 0x1d2e95d458d8 , "https://www.w3ctech.com/"
[1:1:0711/193934.824322:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.468363, 2590, 1
[1:1:0711/193934.824568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193935.313099:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193935.313390:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.w3ctech.com/"
[1:1:0711/193935.320138:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f4522119070 0x1d2e960ad360 , "https://www.w3ctech.com/"
[1:1:0711/193935.330680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , var q=null;window.PR_SHOULD_USE_CONTINUATION=!0;
(function(){function L(a){function m(a){var f=a.cha
[1:1:0711/193935.330963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[3215:3225:0711/193936.294663:WARNING:spdy_session.cc(2744)] Received RST for invalid stream9
[3215:3225:0711/193936.294774:WARNING:spdy_session.cc(2744)] Received RST for invalid stream15
[3215:3225:0711/193936.294854:WARNING:spdy_session.cc(2744)] Received RST for invalid stream25
[3215:3225:0711/193936.294932:WARNING:spdy_session.cc(2744)] Received RST for invalid stream13
[1:1:0711/193937.871772:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.55829, 0, 0
[1:1:0711/193937.872029:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193938.111168:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f45240412e0 0x1d2e9607f960 , "https://www.w3ctech.com/"
[1:1:0711/193938.120115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , (function(){var h={},mt={},c={id:"d464a182f8055b18e3b7d861436bb35b",dm:["w3ctech.com"],js:"tongji.ba
[1:1:0711/193938.120307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193938.155069:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f948
[1:1:0711/193938.155310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193938.155653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 261
[1:1:0711/193938.155842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 261 0x7f4522119070 0x1d2e961873e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 218 0x7f45240412e0 0x1d2e9607f960 
[3:3:0711/193943.790191:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[3215:3215:0711/193946.083962:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/193946.707704:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193946.707989:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.w3ctech.com/"
[1:1:0711/193946.712368:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f4522119070 0x1d2e961877e0 , "https://www.w3ctech.com/"
[1:1:0711/193946.720388:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , (function(){function t(t){this.tokens=[],this.tokens.links={},this.options=t||c.defaults,this.rules=
[1:1:0711/193946.720635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193946.796704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f4522119070 0x1d2e961877e0 , "https://www.w3ctech.com/"
[1:1:0711/193946.819622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f4522119070 0x1d2e961877e0 , "https://www.w3ctech.com/"
[1:1:0711/193946.822776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.w3ctech.com/"
[1:1:0711/193947.320212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.w3ctech.com/"
[1:1:0711/193947.685042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/193947.685315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193948.442023:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 261, 7f4524a5e881
[1:1:0711/193948.462893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"218 0x7f45240412e0 0x1d2e9607f960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193948.463255:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"218 0x7f45240412e0 0x1d2e9607f960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193948.463608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/193948.464198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/193948.464412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193948.465208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/193948.465405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193948.465776:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 388
[1:1:0711/193948.465998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7f4522119070 0x1d2e96182ce0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 261 0x7f4522119070 0x1d2e961873e0 
[1:1:0711/193949.259898:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.w3ctech.com/"
[1:1:0711/193949.260612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xc[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0711/193949.260828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193949.261965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.w3ctech.com/"
[1:1:0711/193949.264533:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.w3ctech.com/"
[1:1:0711/193949.265235:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x35b8a15e9a48
[1:1:0711/193949.465779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/193949.466070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193952.055639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 388, 7f4524a5e881
[1:1:0711/193952.068003:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"261 0x7f4522119070 0x1d2e961873e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193952.068425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"261 0x7f4522119070 0x1d2e961873e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193952.068796:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/193952.069553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/193952.069798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193952.070487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/193952.070651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193952.070975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 469
[1:1:0711/193952.071232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f4522119070 0x1d2e96081860 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 388 0x7f4522119070 0x1d2e96182ce0 
[1:1:0711/193952.163614:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.w3ctech.com/"
[1:1:0711/193952.164465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/193952.164787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193952.522048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7f45240412e0 0x1d2e96d63b60 , "https://www.w3ctech.com/"
[1:1:0711/193952.523051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , jQuery111109902290140073533_1562899174300({"signPackage":{"appId":"wxb19448506406b15e","nonceStr":"H
[1:1:0711/193952.523313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193952.524321:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.w3ctech.com/"
[1:1:0711/193952.606256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/193952.606578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193956.128315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 469, 7f4524a5e881
[1:1:0711/193956.152818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"388 0x7f4522119070 0x1d2e96182ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193956.153755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"388 0x7f4522119070 0x1d2e96182ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193956.155117:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/193956.155863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/193956.156143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193956.156787:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/193956.156982:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193956.157439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 506
[1:1:0711/193956.157705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 506 0x7f4522119070 0x1d2e97787960 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 469 0x7f4522119070 0x1d2e96081860 
[1:1:0711/193956.490714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/193956.491050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193957.301524:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 506, 7f4524a5e881
[1:1:0711/193957.326359:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"469 0x7f4522119070 0x1d2e96081860 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193957.326752:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"469 0x7f4522119070 0x1d2e96081860 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193957.327037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/193957.327768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/193957.327943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193957.328634:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/193957.328790:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193957.329223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 546
[1:1:0711/193957.329470:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 546 0x7f4522119070 0x1d2e96079ee0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 506 0x7f4522119070 0x1d2e97787960 
[1:1:0711/193957.527355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/193957.527603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193958.327578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 546, 7f4524a5e881
[1:1:0711/193958.354814:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"506 0x7f4522119070 0x1d2e97787960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193958.355017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"506 0x7f4522119070 0x1d2e97787960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193958.355241:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/193958.355639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/193958.355877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193958.356859:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/193958.357068:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193958.357494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 565
[1:1:0711/193958.357732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f4522119070 0x1d2e961f5960 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 546 0x7f4522119070 0x1d2e96079ee0 
[1:1:0711/193958.391322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/193958.391656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193958.842290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/193958.842698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193958.847277:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 565, 7f4524a5e881
[1:1:0711/193958.862088:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"546 0x7f4522119070 0x1d2e96079ee0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193958.862520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"546 0x7f4522119070 0x1d2e96079ee0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193958.862823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/193958.863335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/193958.863549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193958.864320:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/193958.864535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193958.864865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 605
[1:1:0711/193958.865055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 605 0x7f4522119070 0x1d2e9617e6e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 565 0x7f4522119070 0x1d2e961f5960 
[1:1:0711/193959.886926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/193959.887223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193959.891283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 605, 7f4524a5e881
[1:1:0711/193959.921963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"565 0x7f4522119070 0x1d2e961f5960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193959.922325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"565 0x7f4522119070 0x1d2e961f5960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/193959.922661:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/193959.923278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/193959.923489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/193959.924256:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/193959.924446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/193959.935963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 652
[1:1:0711/193959.936212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 652 0x7f4522119070 0x1d2e96d56260 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 605 0x7f4522119070 0x1d2e9617e6e0 
[1:1:0711/194001.190895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194001.191156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194001.202539:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 652, 7f4524a5e881
[1:1:0711/194001.215817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"605 0x7f4522119070 0x1d2e9617e6e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194001.216182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"605 0x7f4522119070 0x1d2e9617e6e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194001.216579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194001.217294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194001.217535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194001.218261:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194001.218462:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194001.218837:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 668
[1:1:0711/194001.219088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f4522119070 0x1d2e978e4860 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 652 0x7f4522119070 0x1d2e96d56260 
[1:1:0711/194001.651753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194001.652030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194001.726218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 668, 7f4524a5e881
[1:1:0711/194001.748690:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"652 0x7f4522119070 0x1d2e96d56260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194001.749081:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"652 0x7f4522119070 0x1d2e96d56260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194001.749398:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194001.750041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194001.750252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194001.751040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194001.751238:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194001.751642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 682
[1:1:0711/194001.751880:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7f4522119070 0x1d2e95d7a6e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 668 0x7f4522119070 0x1d2e978e4860 
[1:1:0711/194001.956855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194001.957023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.058961:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 682, 7f4524a5e881
[1:1:0711/194002.093706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"668 0x7f4522119070 0x1d2e978e4860 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194002.093926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"668 0x7f4522119070 0x1d2e978e4860 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194002.094150:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194002.094458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194002.094563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.094861:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194002.094955:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194002.095148:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 691
[1:1:0711/194002.095263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f4522119070 0x1d2e991886e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 682 0x7f4522119070 0x1d2e95d7a6e0 
[1:1:0711/194002.125368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194002.125663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.361716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194002.361902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.386494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 691, 7f4524a5e881
[1:1:0711/194002.418562:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"682 0x7f4522119070 0x1d2e95d7a6e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194002.418999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"682 0x7f4522119070 0x1d2e95d7a6e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194002.419412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194002.420103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194002.420370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.420974:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194002.421124:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194002.421453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 703
[1:1:0711/194002.421641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7f4522119070 0x1d2e97547760 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 691 0x7f4522119070 0x1d2e991886e0 
[1:1:0711/194002.603782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194002.604099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.755534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 703, 7f4524a5e881
[1:1:0711/194002.787181:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"691 0x7f4522119070 0x1d2e991886e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194002.787512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"691 0x7f4522119070 0x1d2e991886e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194002.787812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194002.788349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194002.788526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.789165:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194002.789343:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194002.789667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 715
[1:1:0711/194002.789854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f4522119070 0x1d2e9918bde0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 703 0x7f4522119070 0x1d2e97547760 
[1:1:0711/194002.812853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194002.813028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194002.908608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194002.908918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.080603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194003.080858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.124762:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 715, 7f4524a5e881
[1:1:0711/194003.136681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"703 0x7f4522119070 0x1d2e97547760 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.136978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"703 0x7f4522119070 0x1d2e97547760 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.137233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194003.137737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194003.137911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.138444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194003.138549:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194003.138750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 735
[1:1:0711/194003.138858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f4522119070 0x1d2e97a948e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 715 0x7f4522119070 0x1d2e9918bde0 
[1:1:0711/194003.204748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194003.204939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.294249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194003.294576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.488402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 735, 7f4524a5e881
[1:1:0711/194003.498781:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"715 0x7f4522119070 0x1d2e9918bde0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.498951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"715 0x7f4522119070 0x1d2e9918bde0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.499126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194003.499441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194003.499547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.499847:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194003.499942:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194003.500104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 755
[1:1:0711/194003.500209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f4522119070 0x1d2e99188e60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 735 0x7f4522119070 0x1d2e97a948e0 
[1:1:0711/194003.525875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194003.526056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.711141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194003.711481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.735132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 755, 7f4524a5e881
[1:1:0711/194003.745698:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"735 0x7f4522119070 0x1d2e97a948e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.745891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"735 0x7f4522119070 0x1d2e97a948e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.746046:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194003.746339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194003.746472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.746781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194003.746875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194003.747039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 761
[1:1:0711/194003.747144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7f4522119070 0x1d2e97a9fb60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 755 0x7f4522119070 0x1d2e99188e60 
[1:1:0711/194003.773283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194003.773472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.865344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194003.865608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.946292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 761, 7f4524a5e881
[1:1:0711/194003.980387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"755 0x7f4522119070 0x1d2e99188e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.980826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"755 0x7f4522119070 0x1d2e99188e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194003.981166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194003.981822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194003.982042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194003.982850:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194003.983049:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194003.983466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 773
[1:1:0711/194003.983706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 773 0x7f4522119070 0x1d2e9918a6e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 761 0x7f4522119070 0x1d2e97a9fb60 
[1:1:0711/194004.028256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194004.028533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.100761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194004.101112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.151328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 773, 7f4524a5e881
[1:1:0711/194004.169025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"761 0x7f4522119070 0x1d2e97a9fb60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194004.169454:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"761 0x7f4522119070 0x1d2e97a9fb60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194004.169883:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194004.170401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194004.170595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.171224:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194004.171379:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194004.171726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 783
[1:1:0711/194004.171915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7f4522119070 0x1d2e97ab68e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 773 0x7f4522119070 0x1d2e9918a6e0 
[1:1:0711/194004.210673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194004.210912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.343931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194004.344206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.427796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 783, 7f4524a5e881
[1:1:0711/194004.462962:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"773 0x7f4522119070 0x1d2e9918a6e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194004.463272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"773 0x7f4522119070 0x1d2e9918a6e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194004.463591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194004.464119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194004.464292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.464969:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194004.465301:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194004.465649:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 802
[1:1:0711/194004.465841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7f4522119070 0x1d2e98d76260 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 783 0x7f4522119070 0x1d2e97ab68e0 
[1:1:0711/194004.529760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194004.529928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.688006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194004.688314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.718651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 802, 7f4524a5e881
[1:1:0711/194004.751333:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"783 0x7f4522119070 0x1d2e97ab68e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194004.751554:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"783 0x7f4522119070 0x1d2e97ab68e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194004.751744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194004.752056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194004.752177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194004.752486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194004.752584:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194004.752816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 814
[1:1:0711/194004.752931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7f4522119070 0x1d2e96078ee0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 802 0x7f4522119070 0x1d2e98d76260 
[1:1:0711/194004.926300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194004.926536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.008379:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 814, 7f4524a5e881
[1:1:0711/194005.047553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"802 0x7f4522119070 0x1d2e98d76260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.047968:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"802 0x7f4522119070 0x1d2e98d76260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.048299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194005.048957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194005.049178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.049993:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194005.050192:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194005.050597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 821
[1:1:0711/194005.050854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f4522119070 0x1d2e9607e460 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 814 0x7f4522119070 0x1d2e96078ee0 
[1:1:0711/194005.087389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194005.087689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.146518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194005.146809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.230881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194005.231129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.234550:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 821, 7f4524a5e881
[1:1:0711/194005.273148:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"814 0x7f4522119070 0x1d2e96078ee0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.273348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"814 0x7f4522119070 0x1d2e96078ee0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.273514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194005.273934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194005.274113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.274755:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194005.274921:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194005.275247:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 831
[1:1:0711/194005.275434:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7f4522119070 0x1d2e97b411e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 821 0x7f4522119070 0x1d2e9607e460 
[1:1:0711/194005.353368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194005.353664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.441961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194005.442230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.554544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 831, 7f4524a5e881
[1:1:0711/194005.590412:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"821 0x7f4522119070 0x1d2e9607e460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.590748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"821 0x7f4522119070 0x1d2e9607e460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.591054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194005.591571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194005.591744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.592410:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194005.592567:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194005.592931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 845
[1:1:0711/194005.593125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 845 0x7f4522119070 0x1d2e961f7e60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 831 0x7f4522119070 0x1d2e97b411e0 
[1:1:0711/194005.668213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194005.668445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.921368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194005.921534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.922796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 845, 7f4524a5e881
[1:1:0711/194005.953053:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"831 0x7f4522119070 0x1d2e97b411e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.953471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"831 0x7f4522119070 0x1d2e97b411e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194005.953830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194005.954385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194005.954570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194005.955282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194005.955442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194005.955764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 858
[1:1:0711/194005.956043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f4522119070 0x1d2e97c95360 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 845 0x7f4522119070 0x1d2e961f7e60 
[1:1:0711/194006.091000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194006.091242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.125870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 858, 7f4524a5e881
[1:1:0711/194006.168605:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"845 0x7f4522119070 0x1d2e961f7e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194006.168999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"845 0x7f4522119070 0x1d2e961f7e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194006.169374:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194006.170407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194006.170614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.171390:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194006.171579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194006.171992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 865
[1:1:0711/194006.172229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7f4522119070 0x1d2e978e6ae0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 858 0x7f4522119070 0x1d2e97c95360 
[1:1:0711/194006.211815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194006.212077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.320562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194006.320878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.437088:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 865, 7f4524a5e881
[1:1:0711/194006.475773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"858 0x7f4522119070 0x1d2e97c95360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194006.476202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"858 0x7f4522119070 0x1d2e97c95360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194006.476549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194006.477212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194006.477433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.478251:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194006.478459:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194006.478868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 875
[1:1:0711/194006.479128:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7f4522119070 0x1d2e96e81b60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 865 0x7f4522119070 0x1d2e978e6ae0 
[1:1:0711/194006.501086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194006.501262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.537618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194006.537848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/194006.734101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194006.734356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.824719:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 875, 7f4524a5e881
[1:1:0711/194006.868733:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"865 0x7f4522119070 0x1d2e978e6ae0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194006.869053:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"865 0x7f4522119070 0x1d2e978e6ae0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194006.869402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194006.870049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194006.870293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194006.871088:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194006.871292:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194006.871832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 891
[1:1:0711/194006.872056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 891 0x7f4522119070 0x1d2e97acede0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 875 0x7f4522119070 0x1d2e96e81b60 
[1:1:0711/194006.958974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194006.959254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.287962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194007.288304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.292382:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 891, 7f4524a5e881
[1:1:0711/194007.338670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"875 0x7f4522119070 0x1d2e96e81b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194007.339046:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"875 0x7f4522119070 0x1d2e96e81b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194007.339427:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194007.340062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194007.340314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.341121:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194007.341343:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194007.341755:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 904
[1:1:0711/194007.342002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 904 0x7f4522119070 0x1d2e97c95560 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 891 0x7f4522119070 0x1d2e97acede0 
[1:1:0711/194007.591305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194007.591609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.635702:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 904, 7f4524a5e881
[1:1:0711/194007.676165:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"891 0x7f4522119070 0x1d2e97acede0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194007.676527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"891 0x7f4522119070 0x1d2e97acede0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194007.676790:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194007.677319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194007.677495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.678118:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194007.678288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194007.678614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 912
[1:1:0711/194007.678800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7f4522119070 0x1d2e97a9f8e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 904 0x7f4522119070 0x1d2e97c95560 
[1:1:0711/194007.720438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194007.720672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.813519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194007.813778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.864056:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 912, 7f4524a5e881
[1:1:0711/194007.894587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"904 0x7f4522119070 0x1d2e97c95560 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194007.894920:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"904 0x7f4522119070 0x1d2e97c95560 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194007.895187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194007.895727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194007.895906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194007.896618:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194007.896787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194007.897120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 922
[1:1:0711/194007.897342:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f4522119070 0x1d2e97b41d60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 912 0x7f4522119070 0x1d2e97a9f8e0 
[1:1:0711/194007.933861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194007.934032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[3215:3215:0711/194008.059960:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/194008.080796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194008.081094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194008.129959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 922, 7f4524a5e881
[1:1:0711/194008.165803:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"912 0x7f4522119070 0x1d2e97a9f8e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194008.165991:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"912 0x7f4522119070 0x1d2e97a9f8e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194008.166193:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194008.166517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194008.166636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194008.166933:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194008.167030:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194008.167195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 938
[1:1:0711/194008.167301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7f4522119070 0x1d2e975e6be0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 922 0x7f4522119070 0x1d2e97b41d60 
[1:1:0711/194008.448211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194008.448559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194008.500267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 938, 7f4524a5e881
[1:1:0711/194008.540876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"922 0x7f4522119070 0x1d2e97b41d60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194008.541179:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"922 0x7f4522119070 0x1d2e97b41d60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194008.541487:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194008.541985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194008.542151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194008.542769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194008.542920:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194008.543231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 947
[1:1:0711/194008.543411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7f4522119070 0x1d2e98d70460 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 938 0x7f4522119070 0x1d2e975e6be0 
[1:1:0711/194008.685382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194008.685629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194008.803583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194008.803899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194008.808272:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 947, 7f4524a5e881
[1:1:0711/194008.852461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"938 0x7f4522119070 0x1d2e975e6be0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194008.852801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"938 0x7f4522119070 0x1d2e975e6be0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194008.853105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194008.853644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194008.853819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194008.854461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194008.854637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194008.854959:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 957
[1:1:0711/194008.855148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7f4522119070 0x1d2e97e031e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 947 0x7f4522119070 0x1d2e98d70460 
[1:1:0711/194008.984223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194008.984458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194009.125365:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 957, 7f4524a5e881
[1:1:0711/194009.137816:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"947 0x7f4522119070 0x1d2e98d70460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194009.138000:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"947 0x7f4522119070 0x1d2e98d70460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194009.138157:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194009.138451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194009.138569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194009.138872:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194009.138979:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194009.139147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 969
[1:1:0711/194009.139252:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7f4522119070 0x1d2e97c9b0e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 957 0x7f4522119070 0x1d2e97e031e0 
[1:1:0711/194009.162449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194009.162665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194009.314963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194009.315200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194009.410368:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 969, 7f4524a5e881
[1:1:0711/194009.428064:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"957 0x7f4522119070 0x1d2e97e031e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194009.428442:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"957 0x7f4522119070 0x1d2e97e031e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194009.428886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194009.429527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194009.429765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194009.430559:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194009.430778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194009.431205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 981
[1:1:0711/194009.431459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7f4522119070 0x1d2e96e4ce60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 969 0x7f4522119070 0x1d2e97c9b0e0 
[1:1:0711/194009.729893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194009.730151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194009.873447:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 981, 7f4524a5e881
[1:1:0711/194009.903261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"969 0x7f4522119070 0x1d2e97c9b0e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194009.903467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"969 0x7f4522119070 0x1d2e97c9b0e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194009.903632:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194009.903963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194009.904069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194009.904367:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194009.904464:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194009.904644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 992
[1:1:0711/194009.904784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 992 0x7f4522119070 0x1d2e97ca5360 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 981 0x7f4522119070 0x1d2e96e4ce60 
[1:1:0711/194010.017565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194010.017809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.108062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 992, 7f4524a5e881
[1:1:0711/194010.142616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"981 0x7f4522119070 0x1d2e96e4ce60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194010.143025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"981 0x7f4522119070 0x1d2e96e4ce60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194010.143397:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194010.144114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194010.144341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.145123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194010.145289:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194010.145637:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1000
[1:1:0711/194010.145849:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7f4522119070 0x1d2e978e67e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 992 0x7f4522119070 0x1d2e97ca5360 
[1:1:0711/194010.189433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194010.189669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.277216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194010.277407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.378897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194010.379123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.382536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1000, 7f4524a5e881
[1:1:0711/194010.404778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"992 0x7f4522119070 0x1d2e97ca5360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194010.404993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"992 0x7f4522119070 0x1d2e97ca5360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194010.405200:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194010.405507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194010.405613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.405947:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194010.406058:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194010.406224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1014
[1:1:0711/194010.406332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7f4522119070 0x1d2e97c91460 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1000 0x7f4522119070 0x1d2e978e67e0 
[1:1:0711/194010.545206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194010.545512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.851894:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1014, 7f4524a5e881
[1:1:0711/194010.886617:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1000 0x7f4522119070 0x1d2e978e67e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194010.886918:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1000 0x7f4522119070 0x1d2e978e67e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194010.887235:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194010.887715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194010.887884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194010.888653:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194010.888822:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194010.889203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1029
[1:1:0711/194010.889403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f4522119070 0x1d2e96192e60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1014 0x7f4522119070 0x1d2e97c91460 
[1:1:0711/194010.934027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194010.934272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.226425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194011.226691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.229292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1029, 7f4524a5e881
[1:1:0711/194011.254873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1014 0x7f4522119070 0x1d2e97c91460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194011.255271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1014 0x7f4522119070 0x1d2e97c91460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194011.255679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194011.256331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194011.256506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.257213:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194011.257454:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194011.257904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1036
[1:1:0711/194011.258188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1036 0x7f4522119070 0x1d2e97b41e60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1029 0x7f4522119070 0x1d2e96192e60 
[1:1:0711/194011.348067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194011.348372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.473697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194011.473958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.475427:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1036, 7f4524a5e881
[1:1:0711/194011.514729:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1029 0x7f4522119070 0x1d2e96192e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194011.514932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1029 0x7f4522119070 0x1d2e96192e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194011.515143:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194011.515448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194011.515552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.515849:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194011.515946:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194011.516157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1046
[1:1:0711/194011.516274:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f4522119070 0x1d2e97ab6060 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1036 0x7f4522119070 0x1d2e97b41e60 
[1:1:0711/194011.641374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194011.641553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.785661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1046, 7f4524a5e881
[1:1:0711/194011.804140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1036 0x7f4522119070 0x1d2e97b41e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194011.804354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1036 0x7f4522119070 0x1d2e97b41e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194011.804533:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194011.804862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194011.804967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194011.805278:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194011.805374:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194011.805542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1059
[1:1:0711/194011.805647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1059 0x7f4522119070 0x1d2e97e0ad60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1046 0x7f4522119070 0x1d2e97ab6060 
[1:1:0711/194012.039035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194012.039365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194012.106423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1059, 7f4524a5e881
[1:1:0711/194012.153715:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1046 0x7f4522119070 0x1d2e97ab6060 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194012.154025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1046 0x7f4522119070 0x1d2e97ab6060 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194012.154354:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194012.154873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194012.155045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194012.155700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194012.155860:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194012.156185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1067
[1:1:0711/194012.156485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1067 0x7f4522119070 0x1d2e96186760 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1059 0x7f4522119070 0x1d2e97e0ad60 
[1:1:0711/194012.359788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194012.360033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194012.414792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1067, 7f4524a5e881
[1:1:0711/194012.455341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1059 0x7f4522119070 0x1d2e97e0ad60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194012.455537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1059 0x7f4522119070 0x1d2e97e0ad60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194012.455747:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194012.456063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194012.456167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194012.456782:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194012.456954:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194012.457320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1076
[1:1:0711/194012.457451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1076 0x7f4522119070 0x1d2e97841060 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1067 0x7f4522119070 0x1d2e96186760 
[1:1:0711/194012.536881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194012.537117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194012.638080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194012.638342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194012.757447:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1076, 7f4524a5e881
[1:1:0711/194012.796768:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1067 0x7f4522119070 0x1d2e96186760 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194012.797175:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1067 0x7f4522119070 0x1d2e96186760 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194012.797551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194012.798086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194012.798264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194012.798898:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194012.799049:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194012.799514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1090
[1:1:0711/194012.799697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1090 0x7f4522119070 0x1d2e97ac64e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1076 0x7f4522119070 0x1d2e97841060 
[1:1:0711/194012.888787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194012.889148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.162867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194013.163118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.164802:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1090, 7f4524a5e881
[1:1:0711/194013.187973:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1076 0x7f4522119070 0x1d2e97841060 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194013.188171:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1076 0x7f4522119070 0x1d2e97841060 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194013.188379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194013.189049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194013.189276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.189905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194013.190064:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194013.190374:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1103
[1:1:0711/194013.190592:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7f4522119070 0x1d2e97ec0160 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1090 0x7f4522119070 0x1d2e97ac64e0 
[1:1:0711/194013.474299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194013.474559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.524665:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1103, 7f4524a5e881
[1:1:0711/194013.545229:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1090 0x7f4522119070 0x1d2e97ac64e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194013.545427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1090 0x7f4522119070 0x1d2e97ac64e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194013.545711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194013.546020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194013.546127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.546427:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194013.546547:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194013.546722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1111
[1:1:0711/194013.546831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1111 0x7f4522119070 0x1d2e97ec9e60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1103 0x7f4522119070 0x1d2e97ec0160 
[1:1:0711/194013.578771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194013.578948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.701698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194013.702032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.842921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1111, 7f4524a5e881
[1:1:0711/194013.857633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1103 0x7f4522119070 0x1d2e97ec0160 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194013.857979:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1103 0x7f4522119070 0x1d2e97ec0160 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194013.858151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194013.858474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194013.858595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194013.858905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194013.859003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194013.859206:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1123
[1:1:0711/194013.859316:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7f4522119070 0x1d2e97eb4960 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1111 0x7f4522119070 0x1d2e97ec9e60 
[1:1:0711/194013.886068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194013.886241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.134344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194014.134672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.200311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1123, 7f4524a5e881
[1:1:0711/194014.224068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1111 0x7f4522119070 0x1d2e97ec9e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194014.224261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1111 0x7f4522119070 0x1d2e97ec9e60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194014.224419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194014.224832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194014.225048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.225822:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194014.225993:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194014.226172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1139
[1:1:0711/194014.226292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1139 0x7f4522119070 0x1d2e97d74d60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1123 0x7f4522119070 0x1d2e97eb4960 
[1:1:0711/194014.430573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194014.430846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.511986:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1139, 7f4524a5e881
[1:1:0711/194014.559552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1123 0x7f4522119070 0x1d2e97eb4960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194014.559845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1123 0x7f4522119070 0x1d2e97eb4960 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194014.560132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194014.560440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194014.560546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.560865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194014.560964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194014.561130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1148
[1:1:0711/194014.561236:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1148 0x7f4522119070 0x1d2e98d8d860 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1139 0x7f4522119070 0x1d2e97d74d60 
[1:1:0711/194014.803195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194014.803367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.838598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1148, 7f4524a5e881
[1:1:0711/194014.877420:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1139 0x7f4522119070 0x1d2e97d74d60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194014.877629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1139 0x7f4522119070 0x1d2e97d74d60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194014.877831:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194014.878148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194014.878267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.878576:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194014.878674:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194014.878897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1157
[1:1:0711/194014.879014:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1157 0x7f4522119070 0x1d2e97d669e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1148 0x7f4522119070 0x1d2e98d8d860 
[1:1:0711/194014.940095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194014.940286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194014.989384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194014.989707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194015.128078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1157, 7f4524a5e881
[1:1:0711/194015.170274:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1148 0x7f4522119070 0x1d2e98d8d860 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194015.170476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1148 0x7f4522119070 0x1d2e98d8d860 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194015.170644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194015.170978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194015.171089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194015.171395:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194015.171493:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194015.171664:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1169
[1:1:0711/194015.171772:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7f4522119070 0x1d2e96187b60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1157 0x7f4522119070 0x1d2e97d669e0 
[1:1:0711/194015.205845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194015.206111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194015.425021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194015.425269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194015.513040:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1169, 7f4524a5e881
[1:1:0711/194015.527756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1157 0x7f4522119070 0x1d2e97d669e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194015.527976:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1157 0x7f4522119070 0x1d2e97d669e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194015.528183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194015.528495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194015.528602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194015.528904:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194015.529100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194015.529407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1186
[1:1:0711/194015.529520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1186 0x7f4522119070 0x1d2e97be0b60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1169 0x7f4522119070 0x1d2e96187b60 
[1:1:0711/194015.717561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194015.717860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194015.796115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1186, 7f4524a5e881
[1:1:0711/194015.854105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1169 0x7f4522119070 0x1d2e96187b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194015.854492:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1169 0x7f4522119070 0x1d2e96187b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194015.854819:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194015.855477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194015.855712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194015.856559:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194015.856758:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194015.857185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1195
[1:1:0711/194015.857428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7f4522119070 0x1d2e97ec9c60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1186 0x7f4522119070 0x1d2e97be0b60 
[1:1:0711/194016.092993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194016.093321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194016.130487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1195, 7f4524a5e881
[1:1:0711/194016.150581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1186 0x7f4522119070 0x1d2e97be0b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194016.150774:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1186 0x7f4522119070 0x1d2e97be0b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194016.150936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194016.151255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194016.151361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194016.151658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194016.151753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194016.151919:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1204
[1:1:0711/194016.152026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1204 0x7f4522119070 0x1d2e96079360 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1195 0x7f4522119070 0x1d2e97ec9c60 
[1:1:0711/194016.241584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194016.241887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194016.356676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194016.356925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194016.495305:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1204, 7f4524a5e881
[1:1:0711/194016.546781:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1195 0x7f4522119070 0x1d2e97ec9c60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194016.547091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1195 0x7f4522119070 0x1d2e97ec9c60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194016.547374:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194016.547891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194016.548076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194016.548739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194016.548895:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194016.549244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1222
[1:1:0711/194016.549440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1222 0x7f4522119070 0x1d2e97f361e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1204 0x7f4522119070 0x1d2e96079360 
[1:1:0711/194016.677644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194016.677935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.038397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194017.038568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.039717:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1222, 7f4524a5e881
[1:1:0711/194017.067885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1204 0x7f4522119070 0x1d2e96079360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194017.068200:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1204 0x7f4522119070 0x1d2e96079360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194017.068509:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194017.069034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194017.069211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.069855:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194017.070012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194017.070356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1241
[1:1:0711/194017.070549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1241 0x7f4522119070 0x1d2e97fae460 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1222 0x7f4522119070 0x1d2e97f361e0 
[1:1:0711/194017.254663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194017.254847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.363017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1241, 7f4524a5e881
[1:1:0711/194017.413361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1222 0x7f4522119070 0x1d2e97f361e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194017.413679:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1222 0x7f4522119070 0x1d2e97f361e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194017.413941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194017.414481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194017.414657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.415294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194017.415504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194017.415827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1249
[1:1:0711/194017.416022:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1249 0x7f4522119070 0x1d2e98052ce0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1241 0x7f4522119070 0x1d2e97fae460 
[1:1:0711/194017.467741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194017.467982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.521922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194017.522094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.690802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194017.690996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.791923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1249, 7f4524a5e881
[1:1:0711/194017.816024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1241 0x7f4522119070 0x1d2e97fae460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194017.816300:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1241 0x7f4522119070 0x1d2e97fae460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194017.816563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194017.816968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194017.817115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194017.817590:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194017.817790:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194017.818195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1268
[1:1:0711/194017.818433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1268 0x7f4522119070 0x1d2e97a944e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1249 0x7f4522119070 0x1d2e98052ce0 
[1:1:0711/194017.907337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194017.907711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194018.252975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194018.253167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194018.254478:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1268, 7f4524a5e881
[1:1:0711/194018.273024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1249 0x7f4522119070 0x1d2e98052ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194018.273297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1249 0x7f4522119070 0x1d2e98052ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194018.273595:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194018.274023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194018.274171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194018.274637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194018.274778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194018.275027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1284
[1:1:0711/194018.275197:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1284 0x7f4522119070 0x1d2e97841f60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1268 0x7f4522119070 0x1d2e97a944e0 
[1:1:0711/194018.548792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194018.549032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194018.682092:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.w3ctech.com/"
[1:1:0711/194018.682503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0711/194018.682618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194018.683308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://www.w3ctech.com/"
[1:1:0711/194018.683995:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8faf0
[1:1:0711/194018.684100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194018.684264:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1303
[1:1:0711/194018.684370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7f4522119070 0x1d2e978e9460 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1288 0x7f4522119070 0x1d2e982758e0 
[1:1:0711/194018.861308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , , document.readyState
[1:1:0711/194018.861549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194018.904859:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1303, 7f4524a5e881
[1:1:0711/194018.919674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1288 0x7f4522119070 0x1d2e982758e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194018.919915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1288 0x7f4522119070 0x1d2e982758e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194018.920066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194018.920353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194018.920452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194018.920769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194018.920876:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194018.921038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1310
[1:1:0711/194018.921140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1310 0x7f4522119070 0x1d2e97d668e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1303 0x7f4522119070 0x1d2e978e9460 
[1:1:0711/194019.067507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1310, 7f4524a5e881
[1:1:0711/194019.100767:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1303 0x7f4522119070 0x1d2e978e9460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.100972:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1303 0x7f4522119070 0x1d2e978e9460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.101134:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194019.101432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194019.101537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194019.101861:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194019.101960:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194019.102129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1312
[1:1:0711/194019.102235:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1312 0x7f4522119070 0x1d2e96e6cd60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1310 0x7f4522119070 0x1d2e97d668e0 
[1:1:0711/194019.235010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1312, 7f4524a5e881
[1:1:0711/194019.280669:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1310 0x7f4522119070 0x1d2e97d668e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.281013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1310 0x7f4522119070 0x1d2e97d668e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.281281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194019.281814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194019.281991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194019.282615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194019.282801:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194019.283252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1314
[1:1:0711/194019.283440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7f4522119070 0x1d2e98165d60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1312 0x7f4522119070 0x1d2e96e6cd60 
[1:1:0711/194019.429316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1314, 7f4524a5e881
[1:1:0711/194019.476493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1312 0x7f4522119070 0x1d2e96e6cd60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.476894:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1312 0x7f4522119070 0x1d2e96e6cd60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.477217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194019.477861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194019.478039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194019.478640:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194019.478791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194019.479127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1316
[1:1:0711/194019.479308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1316 0x7f4522119070 0x1d2e98d91ce0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1314 0x7f4522119070 0x1d2e98165d60 
[1:1:0711/194019.631192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1316, 7f4524a5e881
[1:1:0711/194019.655692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1314 0x7f4522119070 0x1d2e98165d60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.655954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1314 0x7f4522119070 0x1d2e98165d60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.656128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194019.656434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194019.656538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194019.656836:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194019.656961:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194019.657148:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1319
[1:1:0711/194019.657257:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1319 0x7f4522119070 0x1d2e981dfde0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1316 0x7f4522119070 0x1d2e98d91ce0 
[1:1:0711/194019.789805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1319, 7f4524a5e881
[1:1:0711/194019.826238:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1316 0x7f4522119070 0x1d2e98d91ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.826633:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1316 0x7f4522119070 0x1d2e98d91ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194019.826973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194019.827638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194019.827856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194019.828711:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194019.828927:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194019.829336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1322
[1:1:0711/194019.829576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1322 0x7f4522119070 0x1d2e97eb41e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1319 0x7f4522119070 0x1d2e981dfde0 
[1:1:0711/194019.979979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1322, 7f4524a5e881
[1:1:0711/194020.045288:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1319 0x7f4522119070 0x1d2e981dfde0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.045676:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1319 0x7f4522119070 0x1d2e981dfde0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.046060:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194020.046701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194020.046914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194020.047720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194020.047911:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194020.048372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1324
[1:1:0711/194020.048617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1324 0x7f4522119070 0x1d2e97faebe0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1322 0x7f4522119070 0x1d2e97eb41e0 
[1:1:0711/194020.209003:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1324, 7f4524a5e881
[1:1:0711/194020.258187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1322 0x7f4522119070 0x1d2e97eb41e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.258508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1322 0x7f4522119070 0x1d2e97eb41e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.258771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194020.259300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194020.259473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194020.260140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194020.260300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194020.260624:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1327
[1:1:0711/194020.260810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7f4522119070 0x1d2e97eb44e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1324 0x7f4522119070 0x1d2e97faebe0 
[1:1:0711/194020.385947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1327, 7f4524a5e881
[1:1:0711/194020.407261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1324 0x7f4522119070 0x1d2e97faebe0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.407478:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1324 0x7f4522119070 0x1d2e97faebe0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.407642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194020.407941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194020.408080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194020.408383:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194020.408480:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194020.408650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1331
[1:1:0711/194020.408770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1331 0x7f4522119070 0x1d2e9617d560 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1327 0x7f4522119070 0x1d2e97eb44e0 
[1:1:0711/194020.556862:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1331, 7f4524a5e881
[1:1:0711/194020.582600:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1327 0x7f4522119070 0x1d2e97eb44e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.582916:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1327 0x7f4522119070 0x1d2e97eb44e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.583202:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194020.583712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194020.583886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194020.584573:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194020.584728:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194020.585074:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1333
[1:1:0711/194020.585270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1333 0x7f4522119070 0x1d2e981fc1e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1331 0x7f4522119070 0x1d2e9617d560 
[1:1:0711/194020.738613:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1333, 7f4524a5e881
[1:1:0711/194020.785728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1331 0x7f4522119070 0x1d2e9617d560 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.786044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1331 0x7f4522119070 0x1d2e9617d560 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.786318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194020.786810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194020.786975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194020.787594:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194020.787744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194020.788055:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1335
[1:1:0711/194020.788297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1335 0x7f4522119070 0x1d2e97eb6b60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1333 0x7f4522119070 0x1d2e981fc1e0 
[1:1:0711/194020.921569:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1335, 7f4524a5e881
[1:1:0711/194020.942452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1333 0x7f4522119070 0x1d2e981fc1e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.942650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1333 0x7f4522119070 0x1d2e981fc1e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194020.942807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194020.943113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194020.943237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194020.943536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194020.943632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194020.943799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1338
[1:1:0711/194020.943906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7f4522119070 0x1d2e97d66fe0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1335 0x7f4522119070 0x1d2e97eb6b60 
[1:1:0711/194021.095431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1338, 7f4524a5e881
[1:1:0711/194021.148203:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1335 0x7f4522119070 0x1d2e97eb6b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.148614:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1335 0x7f4522119070 0x1d2e97eb6b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.148931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194021.149573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194021.149786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194021.150572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194021.150763:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194021.151160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1340
[1:1:0711/194021.151406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1340 0x7f4522119070 0x1d2e981e7360 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1338 0x7f4522119070 0x1d2e97d66fe0 
[1:1:0711/194021.276924:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1340, 7f4524a5e881
[1:1:0711/194021.297463:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1338 0x7f4522119070 0x1d2e97d66fe0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.297661:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1338 0x7f4522119070 0x1d2e97d66fe0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.297824:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194021.298122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194021.298262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194021.298569:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194021.298663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194021.298835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1343
[1:1:0711/194021.298942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1343 0x7f4522119070 0x1d2e97a944e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1340 0x7f4522119070 0x1d2e981e7360 
[1:1:0711/194021.563032:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1343, 7f4524a5e881
[1:1:0711/194021.605725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1340 0x7f4522119070 0x1d2e981e7360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.605923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1340 0x7f4522119070 0x1d2e981e7360 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.606099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194021.606425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194021.606532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194021.606833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194021.606929:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194021.607098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1355
[1:1:0711/194021.607206:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1355 0x7f4522119070 0x1d2e981e7b60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1343 0x7f4522119070 0x1d2e97a944e0 
[1:1:0711/194021.880552:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1355, 7f4524a5e881
[1:1:0711/194021.899237:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1343 0x7f4522119070 0x1d2e97a944e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.899552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1343 0x7f4522119070 0x1d2e97a944e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194021.899855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194021.900407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194021.900606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194021.901235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194021.901411:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194021.901729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1364
[1:1:0711/194021.901916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1364 0x7f4522119070 0x1d2e95d749e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1355 0x7f4522119070 0x1d2e981e7b60 
[1:1:0711/194022.208728:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1364, 7f4524a5e881
[1:1:0711/194022.224769:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1355 0x7f4522119070 0x1d2e981e7b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.224964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1355 0x7f4522119070 0x1d2e981e7b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.225133:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194022.225443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194022.225552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194022.225848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194022.225942:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194022.226108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1376
[1:1:0711/194022.226215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1376 0x7f4522119070 0x1d2e97c9bfe0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1364 0x7f4522119070 0x1d2e95d749e0 
[1:1:0711/194022.455953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1376, 7f4524a5e881
[1:1:0711/194022.505073:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1364 0x7f4522119070 0x1d2e95d749e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.505392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1364 0x7f4522119070 0x1d2e95d749e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.505664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194022.506157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194022.506324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194022.506949:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194022.507100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194022.507414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1391
[1:1:0711/194022.507664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1391 0x7f4522119070 0x1d2e97bc1760 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1376 0x7f4522119070 0x1d2e97c9bfe0 
[1:1:0711/194022.755645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1391, 7f4524a5e881
[1:1:0711/194022.797236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1376 0x7f4522119070 0x1d2e97c9bfe0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.797451:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1376 0x7f4522119070 0x1d2e97c9bfe0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.797623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194022.798045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194022.798147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194022.798434:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194022.798526:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194022.799525:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1402
[1:1:0711/194022.799822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1402 0x7f4522119070 0x1d2e97eb8ce0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1391 0x7f4522119070 0x1d2e97bc1760 
[1:1:0711/194022.846258:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194022.848344:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194022.848851:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194022.910485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1402, 7f4524a5e881
[1:1:0711/194022.935318:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1391 0x7f4522119070 0x1d2e97bc1760 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.935520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1391 0x7f4522119070 0x1d2e97bc1760 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194022.935763:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194022.936080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194022.936186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194022.936488:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194022.936618:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194022.936799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1405
[1:1:0711/194022.936907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1405 0x7f4522119070 0x1d2e97eae9e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1402 0x7f4522119070 0x1d2e97eb8ce0 
[1:1:0711/194023.242258:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1405, 7f4524a5e881
[1:1:0711/194023.294116:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1402 0x7f4522119070 0x1d2e97eb8ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194023.294439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1402 0x7f4522119070 0x1d2e97eb8ce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194023.294828:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194023.295340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194023.295511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194023.296212:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194023.296368:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194023.296715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1421
[1:1:0711/194023.296906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1421 0x7f4522119070 0x1d2e96398b60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1405 0x7f4522119070 0x1d2e97eae9e0 
[1:1:0711/194023.585484:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1421, 7f4524a5e881
[1:1:0711/194023.638098:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1405 0x7f4522119070 0x1d2e97eae9e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194023.638398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1405 0x7f4522119070 0x1d2e97eae9e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194023.638807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194023.639344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194023.639515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194023.640189:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194023.640345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194023.640666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1437
[1:1:0711/194023.640874:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1437 0x7f4522119070 0x1d2e95f203e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1421 0x7f4522119070 0x1d2e96398b60 
[1:1:0711/194023.938652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1437, 7f4524a5e881
[1:1:0711/194023.991624:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1421 0x7f4522119070 0x1d2e96398b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194023.991999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1421 0x7f4522119070 0x1d2e96398b60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194023.992453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194023.992986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194023.993161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194023.993783:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194023.993959:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194023.994282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1447
[1:1:0711/194023.994468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1447 0x7f4522119070 0x1d2e97fb1460 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1437 0x7f4522119070 0x1d2e95f203e0 
[1:1:0711/194024.142478:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1447, 7f4524a5e881
[1:1:0711/194024.158675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1437 0x7f4522119070 0x1d2e95f203e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.158840:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1437 0x7f4522119070 0x1d2e95f203e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.159058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194024.159375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194024.159483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194024.159793:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194024.159945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194024.160125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1453
[1:1:0711/194024.160235:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7f4522119070 0x1d2e95ed9260 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1447 0x7f4522119070 0x1d2e97fb1460 
[1:1:0711/194024.296311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1453, 7f4524a5e881
[1:1:0711/194024.317394:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1447 0x7f4522119070 0x1d2e97fb1460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.317785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1447 0x7f4522119070 0x1d2e97fb1460 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.318246:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194024.318958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194024.319192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194024.320068:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194024.320282:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194024.320689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1455
[1:1:0711/194024.320987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1455 0x7f4522119070 0x1d2e95fecc60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1453 0x7f4522119070 0x1d2e95ed9260 
[1:1:0711/194024.448462:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1455, 7f4524a5e881
[1:1:0711/194024.465255:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1453 0x7f4522119070 0x1d2e95ed9260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.465428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1453 0x7f4522119070 0x1d2e95ed9260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.465623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194024.465924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194024.466064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194024.466372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194024.466481:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194024.466651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1457
[1:1:0711/194024.466762:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1457 0x7f4522119070 0x1d2e98275be0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1455 0x7f4522119070 0x1d2e95fecc60 
[1:1:0711/194024.634197:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1457, 7f4524a5e881
[1:1:0711/194024.686655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1455 0x7f4522119070 0x1d2e95fecc60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.686975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1455 0x7f4522119070 0x1d2e95fecc60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.687352:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194024.687869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194024.688096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194024.688728:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194024.688884:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194024.689232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1459
[1:1:0711/194024.689421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1459 0x7f4522119070 0x1d2e981f58e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1457 0x7f4522119070 0x1d2e98275be0 
[1:1:0711/194024.830545:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1459, 7f4524a5e881
[1:1:0711/194024.847587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1457 0x7f4522119070 0x1d2e98275be0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.847790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1457 0x7f4522119070 0x1d2e98275be0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194024.847996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194024.848366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194024.848474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194024.848783:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194024.848883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194024.849078:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1462
[1:1:0711/194024.849196:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1462 0x7f4522119070 0x1d2e982758e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1459 0x7f4522119070 0x1d2e981f58e0 
[1:1:0711/194025.030799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1462, 7f4524a5e881
[1:1:0711/194025.116208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1459 0x7f4522119070 0x1d2e981f58e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.116530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1459 0x7f4522119070 0x1d2e981f58e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.116899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194025.117452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194025.117647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194025.118353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194025.118517:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194025.118852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1464
[1:1:0711/194025.119045:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1464 0x7f4522119070 0x1d2e97ec06e0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1462 0x7f4522119070 0x1d2e982758e0 
[1:1:0711/194025.294263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1464, 7f4524a5e881
[1:1:0711/194025.350383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1462 0x7f4522119070 0x1d2e982758e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.350695:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1462 0x7f4522119070 0x1d2e982758e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.351065:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194025.351716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194025.352345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194025.353166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194025.353365:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194025.353713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1468
[1:1:0711/194025.353909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1468 0x7f4522119070 0x1d2e9918bce0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1464 0x7f4522119070 0x1d2e97ec06e0 
[1:1:0711/194025.520752:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1468, 7f4524a5e881
[1:1:0711/194025.542787:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1464 0x7f4522119070 0x1d2e97ec06e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.543145:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1464 0x7f4522119070 0x1d2e97ec06e0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.543612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194025.544351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194025.544595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194025.545489:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194025.545694:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194025.546108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1472
[1:1:0711/194025.546378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1472 0x7f4522119070 0x1d2e95f2ed60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1468 0x7f4522119070 0x1d2e9918bce0 
[1:1:0711/194025.684953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1472, 7f4524a5e881
[1:1:0711/194025.750733:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1468 0x7f4522119070 0x1d2e9918bce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.751072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1468 0x7f4522119070 0x1d2e9918bce0 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.751465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194025.751994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194025.752199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194025.752910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194025.753070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194025.753430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1474
[1:1:0711/194025.753628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1474 0x7f4522119070 0x1d2e97b4da60 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1472 0x7f4522119070 0x1d2e95f2ed60 
[1:1:0711/194025.915563:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1474, 7f4524a5e881
[1:1:0711/194025.965535:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1472 0x7f4522119070 0x1d2e95f2ed60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.965841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1472 0x7f4522119070 0x1d2e95f2ed60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194025.966190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194025.966712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194025.966896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194025.967549:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194025.967706:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194025.968024:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1477
[1:1:0711/194025.968209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1477 0x7f4522119070 0x1d2e97bcf260 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1474 0x7f4522119070 0x1d2e97b4da60 
[1:1:0711/194026.154119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1477, 7f4524a5e881
[1:1:0711/194026.211114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1474 0x7f4522119070 0x1d2e97b4da60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194026.211535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1474 0x7f4522119070 0x1d2e97b4da60 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0711/194026.211906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0711/194026.212478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/194026.212664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0711/194026.213320:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0711/194026.213498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0711/194026.213836:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1480
[1:1:0711/194026.214031:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1480 0x7f4522119070 0x1d2e980d0160 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1477 0x7f4522119070 0x1d2e97bcf260 
[1:1:0711/194026.397602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1480, 7f4524a5e881
[1:1:0100/000000.456119:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05118fa82860","ptid":"1477 0x7f4522119070 0x1d2e97bcf260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0100/000000.474173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.w3ctech.com/","ptid":"1477 0x7f4522119070 0x1d2e97bcf260 ","rf":"6:3_https://www.w3ctech.com/"}
[1:1:0100/000000.474611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.w3ctech.com/"
[1:1:0100/000000.475231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.w3ctech.com/, 05118fa82860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0100/000000.475402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.w3ctech.com/", "www.w3ctech.com", 3, 1, , , 0
[1:1:0100/000000.476230:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15814d6629c8, 0x1d2e95d8f950
[1:1:0100/000000.476468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.w3ctech.com/", 100
[1:1:0100/000000.477047:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.w3ctech.com/, 1483
[1:1:0100/000000.477356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1483 0x7f4522119070 0x1d2e97ec0fe0 , 6:3_https://www.w3ctech.com/, 1, -6:3_https://www.w3ctech.com/, 1480 0x7f4522119070 0x1d2e980d0160 
