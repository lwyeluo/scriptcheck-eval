[0712/014817.935026:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/014817.935360:INFO:switcher_clone.cc(787)] backtrace rip is 7fd86d852891
[0712/014818.817585:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/014818.818035:INFO:switcher_clone.cc(787)] backtrace rip is 7f4aa4b41891
[1:1:0712/014818.830167:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/014818.830458:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/014818.836670:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[55254:55254:0712/014820.137574:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ee837d9b-0ec3-4a1a-9430-c1fed8197337
[0712/014820.469701:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/014820.470130:INFO:switcher_clone.cc(787)] backtrace rip is 7f6f83544891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[55254:55254:0712/014820.701297:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[55254:55284:0712/014820.702242:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/014820.702489:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/014820.702702:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/014820.703324:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/014820.703478:INFO:zygote_linux.cc(633)] 		cid is 4
[55286:55286:0712/014820.704308:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=55286
[55301:55301:0712/014820.704767:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=55301
[1:1:0712/014820.706553:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe82a9af, 1
[1:1:0712/014820.707054:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1bb2a9f1, 0
[1:1:0712/014820.707297:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1dabd64f, 3
[1:1:0712/014820.707544:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x565c63a, 2
[1:1:0712/014820.707838:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff1ffffffa9ffffffb21b ffffffafffffffa9ffffff820e 3affffffc66505 4fffffffd6ffffffab1d , 10104, 4
[1:1:0712/014820.709080:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[55254:55284:0712/014820.709380:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����:�eO֫�ƺ&
[55254:55284:0712/014820.709449:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����:�eO֫�H�ƺ&
[1:1:0712/014820.709379:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4aa2d7c0a0, 3
[1:1:0712/014820.709745:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4aa2f07080, 2
[55254:55284:0712/014820.709969:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[55254:55284:0712/014820.710035:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 55302, 4, f1a9b21b afa9820e 3ac66505 4fd6ab1d 
[1:1:0712/014820.710046:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a8cbcad20, -2
[1:1:0712/014820.730896:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/014820.732005:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 565c63a
[1:1:0712/014820.733169:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 565c63a
[1:1:0712/014820.735077:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 565c63a
[1:1:0712/014820.736943:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.737227:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.738480:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.738734:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.739488:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 565c63a
[1:1:0712/014820.739850:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4aa4b417ba
[1:1:0712/014820.740090:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4aa4b38def, 7f4aa4b4177a, 7f4aa4b430cf
[1:1:0712/014820.745842:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 565c63a
[1:1:0712/014820.746247:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 565c63a
[1:1:0712/014820.747197:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 565c63a
[1:1:0712/014820.749429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.749677:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.749929:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.750157:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 565c63a
[1:1:0712/014820.751451:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 565c63a
[1:1:0712/014820.751849:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4aa4b417ba
[1:1:0712/014820.752091:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4aa4b38def, 7f4aa4b4177a, 7f4aa4b430cf
[1:1:0712/014820.759881:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/014820.760365:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/014820.760550:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd395ac8f8, 0x7ffd395ac878)
[1:1:0712/014820.777726:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/014820.781844:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[55254:55276:0712/014821.346729:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[55254:55254:0712/014821.412605:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[55254:55254:0712/014821.414422:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[55254:55265:0712/014821.430827:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[55254:55265:0712/014821.430929:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[55254:55254:0712/014821.431147:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[55254:55254:0712/014821.431249:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[55254:55254:0712/014821.431425:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,55302, 4
[1:7:0712/014821.433562:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/014821.444134:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2d716c618220
[1:1:0712/014821.444441:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/014821.977335:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[55254:55254:0712/014823.328397:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[55254:55254:0712/014823.328515:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/014823.366138:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014823.370546:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/014824.471318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298fb0241f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/014824.471660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/014824.488430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298fb0241f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/014824.488729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/014824.531619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014824.831141:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014824.831417:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/014825.164453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/014825.172559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298fb0241f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/014825.172840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/014825.224716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/014825.235215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298fb0241f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/014825.235526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/014825.247542:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/014825.251035:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2d716c616e20
[1:1:0712/014825.251294:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[55254:55254:0712/014825.251444:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[55254:55254:0712/014825.266896:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[55254:55254:0712/014825.316427:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[55254:55254:0712/014825.316635:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/014825.345189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/014826.168870:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f4a8e7a52e0 0x2d716c8973e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/014826.170252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298fb0241f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/014826.170527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/014826.172003:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[55254:55254:0712/014826.238240:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/014826.240443:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2d716c617820
[1:1:0712/014826.240650:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[55254:55254:0712/014826.245104:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/014826.256796:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/014826.256940:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[55254:55254:0712/014826.262905:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[55254:55254:0712/014826.273830:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[55254:55254:0712/014826.274853:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[55254:55265:0712/014826.280845:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[55254:55265:0712/014826.280933:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[55254:55254:0712/014826.281184:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[55254:55254:0712/014826.281283:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[55254:55254:0712/014826.281480:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,55302, 4
[1:7:0712/014826.293788:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/014826.690798:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/014827.264883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7f4a8e7a52e0 0x2d716c9c63e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/014827.265939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298fb0241f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/014827.266181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/014827.267086:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[55254:55254:0712/014827.357421:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[55254:55254:0712/014827.357580:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/014827.383541:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/014827.823608:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[55254:55254:0712/014828.326452:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[55254:55284:0712/014828.326689:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/014828.326813:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/014828.327051:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/014828.327317:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/014828.327450:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/014828.330011:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd1eadd6, 1
[1:1:0712/014828.330354:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xb43ea74, 0
[1:1:0712/014828.330538:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x13208b2, 3
[1:1:0712/014828.330717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3179f18f, 2
[1:1:0712/014828.330919:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 74ffffffea430b ffffffd6ffffffad1e0d ffffff8ffffffff17931 ffffffb2083201 , 10104, 5
[1:1:0712/014828.331981:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[55254:55284:0712/014828.332230:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGt�C֭��y1�2�Ⱥ&
[55254:55284:0712/014828.332302:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is t�C֭��y1�2��Ⱥ&
[1:1:0712/014828.332413:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4aa2d7c0a0, 3
[55254:55284:0712/014828.332573:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 55355, 5, 74ea430b d6ad1e0d 8ff17931 b2083201 
[1:1:0712/014828.332645:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4aa2f07080, 2
[1:1:0712/014828.332923:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a8cbcad20, -2
[1:1:0712/014828.355485:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/014828.355958:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3179f18f
[1:1:0712/014828.356305:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3179f18f
[1:1:0712/014828.356999:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3179f18f
[1:1:0712/014828.358432:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.358682:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.358971:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.359248:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.360235:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3179f18f
[1:1:0712/014828.360582:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4aa4b417ba
[1:1:0712/014828.360756:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4aa4b38def, 7f4aa4b4177a, 7f4aa4b430cf
[1:1:0712/014828.366539:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3179f18f
[1:1:0712/014828.367041:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3179f18f
[1:1:0712/014828.367814:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3179f18f
[1:1:0712/014828.369933:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.370481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.370712:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.370993:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3179f18f
[1:1:0712/014828.372416:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3179f18f
[1:1:0712/014828.372933:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4aa4b417ba
[1:1:0712/014828.373164:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4aa4b38def, 7f4aa4b4177a, 7f4aa4b430cf
[1:1:0712/014828.382737:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/014828.383501:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/014828.383765:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd395ac8f8, 0x7ffd395ac878)
[1:1:0712/014828.398381:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/014828.402737:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/014828.417803:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014828.418097:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/014828.563949:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2d716c5d3220
[1:1:0712/014828.564305:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/014828.909645:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/014828.914408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 298fb0370640, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/014828.914736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/014828.923173:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/014829.113726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/014829.114694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 298fb0241f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/014829.115055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[55254:55254:0712/014829.163134:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[55254:55254:0712/014829.170386:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[55254:55265:0712/014829.188108:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[55254:55265:0712/014829.188214:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[55254:55254:0712/014829.189164:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://mozilla.com.cn/
[55254:55254:0712/014829.189273:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://mozilla.com.cn/, http://mozilla.com.cn/moz-portal.html, 1
[55254:55254:0712/014829.189438:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://mozilla.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 08:48:29 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Server: nginx Set-Cookie: 0kLe_2132_sid=naM4eQ; expires=Sat, 13-Jul-2019 08:48:29 GMT; Max-Age=86400; path=/ Set-Cookie: 0kLe_2132_lastact=1562921309%09plugin.php%09; expires=Sat, 13-Jul-2019 08:48:29 GMT; Max-Age=86400; path=/ Content-Encoding: gzip Vary: Accept-Encoding  ,55355, 5
[1:7:0712/014829.193045:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/014829.211050:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://mozilla.com.cn/
[1:1:0712/014829.316260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/014829.316659:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/014829.318059:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/014829.318306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 298fb0370640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/014829.318610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[55254:55254:0712/014829.331928:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://mozilla.com.cn/, http://mozilla.com.cn/, 1
[55254:55254:0712/014829.332043:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://mozilla.com.cn/, http://mozilla.com.cn
[1:1:0712/014829.407924:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014829.452046:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/014829.453018:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/014829.453285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 298fb0370640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/014829.453598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/014829.544029:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014829.544424:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.263649:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.267853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , /* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy
[1:1:0712/014830.268192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014830.271017:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014830.283047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.292812:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.355502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.367886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.634007:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.642506:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014830.730006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f4a8c87d070 0x2d716c343760 , "http://mozilla.com.cn/moz-portal.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/014830.780332:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.498134, 61, 1
[1:1:0712/014830.780664:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014831.166749:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014831.167298:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014831.167689:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014831.168186:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014831.170863:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014831.232059:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014831.232334:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014831.235822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 214 0x7f4a8c87d070 0x2d716c9d2b60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014831.237183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , /*
	[Discuz!] (C)2001-2099 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$
[1:1:0712/014831.237464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014831.256368:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.023905, 62, 1
[1:1:0712/014831.256738:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014832.405064:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014832.405394:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014832.408566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f4a8c87d070 0x2d716c6ed1e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014832.410550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , !function(d){var b='[data-toggle="dropdown"]',a=function(f){var e=d(f).on("click.dropdown.data-api",
[1:1:0712/014832.410800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014832.419279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f4a8c87d070 0x2d716c6ed1e0 , "http://mozilla.com.cn/moz-portal.html"
[55254:55254:0712/014844.370521:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/014844.374472:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/014844.470215:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 12.0648, 0, 0
[1:1:0712/014844.470588:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014844.962611:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014845.132770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/014845.133088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014845.562850:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014845.563125:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014845.566794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356 0x7f4a8c87d070 0x2d716c6ecf60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014845.568373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , function doSearch() {
	searchFocus(jQuery('#scbar_txt'));
	var engineDisplayElement = jQuery('#engin
[1:1:0712/014845.568608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014845.582794:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0195282, 59, 1
[1:1:0712/014845.583048:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014845.730169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f4a8e7a52e0 0x2d716c5de8e0 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014845.740593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , (function(){var h={},mt={},c={id:"d78cc3d5d410149533738ffc6006a9c6",dm:["mozilla.com.cn"],js:"tongji
[1:1:0712/014845.740880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014845.777275:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a948
[1:1:0712/014845.777581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014845.777991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 398
[1:1:0712/014845.778220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 398 0x7f4a8c87d070 0x2d716c74b2e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 372 0x7f4a8e7a52e0 0x2d716c5de8e0 
[1:1:0712/014846.320260:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 600000
[1:1:0712/014846.320779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 421
[1:1:0712/014846.321040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 421 0x7f4a8c87d070 0x2d716c2dd460 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 372 0x7f4a8e7a52e0 0x2d716c5de8e0 
[1:1:0712/014846.321974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 5000
[1:1:0712/014846.322378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 422
[1:1:0712/014846.322631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 422 0x7f4a8c87d070 0x2d716cab79e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 372 0x7f4a8e7a52e0 0x2d716c5de8e0 
[1:1:0712/014846.390539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014846.390829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014846.818365:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014846.818674:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014846.819715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 391 0x7f4a8c87d070 0x2d716c87ee60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014846.820762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , 
initSearchmenu('scbar', '');

[1:1:0712/014846.821006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014846.830260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014846.837743:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 391 0x7f4a8c87d070 0x2d716c87ee60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014846.850327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 391 0x7f4a8c87d070 0x2d716c87ee60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014847.016029:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[55254:55254:0712/014847.017852:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/014847.020438:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2d716c5d2820
[1:1:0712/014847.020729:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[55254:55254:0712/014847.034009:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/014847.040022:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/014847.040302:INFO:render_frame_impl.cc(7019)] 	 [url] = http://mozilla.com.cn
[55254:55254:0712/014847.044229:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://mozilla.com.cn/
[1:1:0712/014847.049380:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.230539, 778, 1
[1:1:0712/014847.049614:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[55254:55254:0712/014847.185350:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[55254:55254:0712/014847.194641:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[55254:55265:0712/014847.223582:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[55254:55265:0712/014847.223709:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[55254:55254:0712/014847.223870:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://widget.weibo.com/
[55254:55254:0712/014847.223948:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1, 4
[55254:55254:0712/014847.224080:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://widget.weibo.com/, HTTP/1.1 200 OK Server: WeiBo/LB Date: Fri, 12 Jul 2019 08:48:47 GMT Content-Type: text/html Content-Length: 7000 Connection: keep-alive Vary: Host,Accept-Encoding Set-Cookie: U_TRS1=00000022.148f8f2.5d28496f.b6c51e3e; path=/; expires=Mon, 09-Jul-29 08:48:47 GMT; domain=.sina.com.cn Set-Cookie: U_TRS2=00000022.149e8f2.5d28496f.fa982a59; path=/; domain=.sina.com.cn Content-Security-Policy: upgrade-insecure-requests xPlugins-Type: 1 Cache-Control: max-age=60, must-revalidate Pragma:  Expires: Fri, 12 Jul 2019 08:53:47 GMT Last-Modified: Fri, 12 Jul 2019 08:48:47 GMT DPOOL_HEADER: qubele35 Content-Encoding: gzip LB_HEADER: venus241 Strict-Transport-Security: max-age=31536000; preload  ,55355, 5
[1:7:0712/014847.227134:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/014847.775321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 398, 7f4a8f1c2881
[1:1:0712/014847.798128:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"372 0x7f4a8e7a52e0 0x2d716c5de8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014847.798482:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"372 0x7f4a8e7a52e0 0x2d716c5de8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014847.798948:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014847.799582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014847.799850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014847.800642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014847.800857:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014847.801286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 523
[1:1:0712/014847.801534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7f4a8c87d070 0x2d716cab7560 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 398 0x7f4a8c87d070 0x2d716c74b2e0 
[1:1:0712/014847.828928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014847.829217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014850.864950:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014850.865273:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014850.869860:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 513 0x7f4a8c87d070 0x2d716ca5da60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014850.870881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , 
[1:1:0712/014850.871169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014850.874060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 513 0x7f4a8c87d070 0x2d716ca5da60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014850.883687:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 513 0x7f4a8c87d070 0x2d716ca5da60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014850.944853:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 513 0x7f4a8c87d070 0x2d716ca5da60 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014850.953947:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.088532, 64, 1
[1:1:0712/014850.954214:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014851.089920:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://widget.weibo.com/
[1:1:0712/014851.151099:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","https://hm.baidu.com/hm.gif?cc=1&ck=1&cl=24-bit&ds=1276x647&vl=424&et=0&ja=0&ln=en-us&lo=0&lt=1562899105&rnd=275160338&si=d78cc3d5d410149533738ffc6006a9c6&v=1.2.51&lv=2&sn=42646&ct=!!&tt=%E9%A6%96%E9%A1%B5%20-%20%E7%81%AB%E7%8B%90%E7%A4%BE%E5%8C%BA"
[1:1:0712/014851.193695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014851.194026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014851.272103:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 523, 7f4a8f1c2881
[1:1:0712/014851.300219:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"398 0x7f4a8c87d070 0x2d716c74b2e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014851.300618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"398 0x7f4a8c87d070 0x2d716c74b2e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014851.301136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014851.301818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014851.302047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014851.302782:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014851.302985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014851.303475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 586
[1:1:0712/014851.303776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 586 0x7f4a8c87d070 0x2d716d0d4de0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 523 0x7f4a8c87d070 0x2d716cab7560 
[1:1:0712/014852.719994:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014852.720281:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014852.723178:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f4a8c87d070 0x2d716d08c960 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014852.723959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , 
[1:1:0712/014852.724172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014852.731954:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f4a8c87d070 0x2d716d08c960 , "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014852.741452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014852.829523:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 3000
[1:1:0712/014852.829787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 635
[1:1:0712/014852.829909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f4a8c87d070 0x2d716c94cce0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 577 0x7f4a8c87d070 0x2d716d08c960 
[1:1:0712/014852.844094:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014852.899484:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[55254:55254:0712/014852.906946:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/, 4
[55254:55254:0712/014852.907053:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://widget.weibo.com/, https://widget.weibo.com
[1:1:0712/014852.935955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014852.936209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014852.946399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 422, 7f4a8f1c28db
[1:1:0712/014852.956087:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"372 0x7f4a8e7a52e0 0x2d716c5de8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014852.956303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"372 0x7f4a8e7a52e0 0x2d716c5de8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014852.956512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 654
[1:1:0712/014852.956621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f4a8c87d070 0x2d716c943be0 , 5:3_http://mozilla.com.cn/, 0, , 422 0x7f4a8c87d070 0x2d716cab79e0 
[1:1:0712/014852.956771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014852.957053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/014852.957185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014852.974870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 586, 7f4a8f1c2881
[1:1:0712/014853.007549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"523 0x7f4a8c87d070 0x2d716cab7560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014853.007852:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"523 0x7f4a8c87d070 0x2d716cab7560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014853.008232:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014853.008782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014853.008984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014853.009653:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014853.009813:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014853.010187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 656
[1:1:0712/014853.010378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f4a8c87d070 0x2d716ca5d860 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 586 0x7f4a8c87d070 0x2d716d0d4de0 
[1:1:0712/014853.184614:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","https://addons.cdn.mozilla.net/user-media/addon_icons/0/748-64.png?modified=1531822767"
[1:1:0712/014853.195945:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","https://addons.cdn.mozilla.net/user-media/addon_icons/8/8542-64.png?modified=mcrushed"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/014853.915079:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014854.120206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014854.120376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014854.149918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 656, 7f4a8f1c2881
[1:1:0712/014854.159163:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"586 0x7f4a8c87d070 0x2d716d0d4de0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014854.159334:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"586 0x7f4a8c87d070 0x2d716d0d4de0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014854.159537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014854.159854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014854.159972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014854.160269:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014854.160367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014854.160569:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 691
[1:1:0712/014854.160679:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f4a8c87d070 0x2d716c789260 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 656 0x7f4a8c87d070 0x2d716ca5d860 
[1:1:0712/014854.842157:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014854.842316:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014854.857092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 688 0x7f4a8c87d070 0x2d716ce00160 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014854.871332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , , 
            var $CONFIG = {
                $lang: "zh",
                $oid: "",
                
[1:1:0712/014854.871519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014854.901924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014854.902087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014854.903285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 691, 7f4a8f1c2881
[1:1:0712/014854.925358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"656 0x7f4a8c87d070 0x2d716ca5d860 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014854.925552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"656 0x7f4a8c87d070 0x2d716ca5d860 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014854.925772:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014854.926087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014854.926191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014854.926507:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014854.926603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014854.926802:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 712
[1:1:0712/014854.926909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7f4a8c87d070 0x2d716c8286e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 691 0x7f4a8c87d070 0x2d716c789260 
[1:1:0712/014855.494385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014855.494635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014855.641851:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 712, 7f4a8f1c2881
[1:1:0712/014855.666269:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"691 0x7f4a8c87d070 0x2d716c789260 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014855.666461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"691 0x7f4a8c87d070 0x2d716c789260 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014855.666660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014855.667013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014855.667123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014855.667426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014855.667524:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014855.667706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 741
[1:1:0712/014855.667814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7f4a8c87d070 0x2d716c828d60 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 712 0x7f4a8c87d070 0x2d716c8286e0 
[1:1:0712/014855.806946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014855.807197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014856.005015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 741, 7f4a8f1c2881
[1:1:0712/014856.018836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"712 0x7f4a8c87d070 0x2d716c8286e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014856.019226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"712 0x7f4a8c87d070 0x2d716c8286e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014856.019621:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014856.020275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014856.020459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014856.021140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014856.021302:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014856.021653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 763
[1:1:0712/014856.021841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 763 0x7f4a8c87d070 0x2d716d07c8e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 741 0x7f4a8c87d070 0x2d716c828d60 
[1:1:0712/014856.039423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014856.039668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014856.041031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 635, 7f4a8f1c28db
[1:1:0712/014856.051237:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"577 0x7f4a8c87d070 0x2d716d08c960 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014856.051401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"577 0x7f4a8c87d070 0x2d716d08c960 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014856.051593:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 767
[1:1:0712/014856.051697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 767 0x7f4a8c87d070 0x2d716d2fe7e0 , 5:3_http://mozilla.com.cn/, 0, , 635 0x7f4a8c87d070 0x2d716c94cce0 
[1:1:0712/014856.051828:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014856.052119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0712/014856.052220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014856.080000:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014856.080163:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014856.080361:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 769
[1:1:0712/014856.080468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7f4a8c87d070 0x2d716c87dbe0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 635 0x7f4a8c87d070 0x2d716c94cce0 
[1:1:0712/014856.082701:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0712/014856.082891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 770
[1:1:0712/014856.083017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7f4a8c87d070 0x2d716c889060 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 635 0x7f4a8c87d070 0x2d716c94cce0 
[1:1:0712/014856.456816:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 761 0x7f4a8cbe5bd0 0x2d716c87d958 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014856.467888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , , var STK=function(){var a={};var b=[];a.inc=function(a,b){return true};a.register=function(c,d){var e
[1:1:0712/014856.468188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014856.589769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x1d4324482a10, 0x2d716c45a960
[1:1:0712/014856.589994:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0712/014856.590831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 788
[1:1:0712/014856.591022:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7f4a8c87d070 0x2d716d252b60 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 761 0x7f4a8cbe5bd0 0x2d716c87d958 
[1:1:0712/014856.835310:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.118609, 671, 1
[1:1:0712/014856.835527:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/014856.986751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014856.986925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014857.031927:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 769, 7f4a8f1c2881
[1:1:0712/014857.054423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"635 0x7f4a8c87d070 0x2d716c94cce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.054748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"635 0x7f4a8c87d070 0x2d716c94cce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.055121:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014857.055737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , ct, (){cr=b}
[1:1:0712/014857.055940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014857.057686:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 770, 7f4a8f1c28db
[1:1:0712/014857.092954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"635 0x7f4a8c87d070 0x2d716c94cce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.093279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"635 0x7f4a8c87d070 0x2d716c94cce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.093678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 840
[1:1:0712/014857.093867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7f4a8c87d070 0x2d716d05afe0 , 5:3_http://mozilla.com.cn/, 0, , 770 0x7f4a8c87d070 0x2d716c889060 
[1:1:0712/014857.094152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014857.094691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/014857.094864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014857.096312:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014857.096475:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014857.096826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 841
[1:1:0712/014857.097014:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7f4a8c87d070 0x2d716cabb6e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 770 0x7f4a8c87d070 0x2d716c889060 
[1:1:0712/014857.192486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 763, 7f4a8f1c2881
[1:1:0712/014857.236376:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"741 0x7f4a8c87d070 0x2d716c828d60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.236765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"741 0x7f4a8c87d070 0x2d716c828d60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.237228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014857.237909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014857.238122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014857.238936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014857.239128:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014857.239582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 844
[1:1:0712/014857.239828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 844 0x7f4a8c87d070 0x2d716d0753e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 763 0x7f4a8c87d070 0x2d716d07c8e0 
[1:1:0712/014857.326611:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 654, 7f4a8f1c28db
[1:1:0712/014857.337216:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"422 0x7f4a8c87d070 0x2d716cab79e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.337399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"422 0x7f4a8c87d070 0x2d716cab79e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014857.337630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 847
[1:1:0712/014857.337740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7f4a8c87d070 0x2d716d07e460 , 5:3_http://mozilla.com.cn/, 0, , 654 0x7f4a8c87d070 0x2d716c943be0 
[1:1:0712/014857.337872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014857.338141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/014857.338256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014859.252638:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/014859.252919:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014859.355241:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 788, 7f4a8f1c2881
[1:1:0712/014859.390423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c80430c0","ptid":"761 0x7f4a8cbe5bd0 0x2d716c87d958 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014859.390780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"761 0x7f4a8cbe5bd0 0x2d716c87d958 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014859.391122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014859.392195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0712/014859.392465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014859.393586:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x1d4324482a10, 0x2d716c45a950
[1:1:0712/014859.393806:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0712/014859.394686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 889
[1:1:0712/014859.394936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 889 0x7f4a8c87d070 0x2d716d9cd3e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 788 0x7f4a8c87d070 0x2d716d252b60 
[1:1:0712/014859.838745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014859.839041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014900.030296:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 841, 7f4a8f1c2881
[1:1:0712/014900.058672:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"770 0x7f4a8c87d070 0x2d716c889060 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014900.059033:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"770 0x7f4a8c87d070 0x2d716c889060 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014900.059589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014900.060222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , ct, (){cr=b}
[1:1:0712/014900.060446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/014900.379772:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 844, 7f4a8f1c2881
[1:1:0712/014900.394147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"763 0x7f4a8c87d070 0x2d716d07c8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014900.394413:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"763 0x7f4a8c87d070 0x2d716d07c8e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014900.394641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014900.394945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014900.395069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014900.395367:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014900.395461:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014900.395633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 921
[1:1:0712/014900.395743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f4a8c87d070 0x2d716ce00b60 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 844 0x7f4a8c87d070 0x2d716d0753e0 
[1:1:0712/014900.691462:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 767, 7f4a8f1c28db
[1:1:0712/014900.703912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"635 0x7f4a8c87d070 0x2d716c94cce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014900.704304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"635 0x7f4a8c87d070 0x2d716c94cce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014900.704761:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 924
[1:1:0712/014900.704999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 924 0x7f4a8c87d070 0x2d716d9c0560 , 5:3_http://mozilla.com.cn/, 0, , 767 0x7f4a8c87d070 0x2d716d2fe7e0 
[1:1:0712/014900.705317:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014900.705683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0712/014900.705788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014900.736069:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014900.736501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014900.736968:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 925
[1:1:0712/014900.737270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7f4a8c87d070 0x2d716d08a160 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 767 0x7f4a8c87d070 0x2d716d2fe7e0 
[1:1:0712/014900.740613:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0712/014900.741076:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 926
[1:1:0712/014900.741340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7f4a8c87d070 0x2d716d5ef5e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 767 0x7f4a8c87d070 0x2d716d2fe7e0 
[1:1:0712/014901.402381:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 889, 7f4a8f1c2881
[1:1:0712/014901.415139:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c80430c0","ptid":"788 0x7f4a8c87d070 0x2d716d252b60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014901.415401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"788 0x7f4a8c87d070 0x2d716d252b60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014901.415672:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014901.416252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0712/014901.416488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014901.417079:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x1d4324482a10, 0x2d716c45a950
[1:1:0712/014901.417213:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0712/014901.417625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 931
[1:1:0712/014901.417776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7f4a8c87d070 0x2d716da7cc60 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 889 0x7f4a8c87d070 0x2d716d9cd3e0 
[1:1:0712/014901.753444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 903 0x7f4a8cbe5bd0 0x2d716da83658 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014901.761162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , , STK.register("kit.extra.language", function($) {
    window.$LANG || (window.$LANG = {});
    return
[1:1:0712/014901.761428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014901.919983:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x1d4324482a10, 0x2d716c45a960
[1:1:0712/014901.920152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 25
[1:1:0712/014901.920465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 943
[1:1:0712/014901.920582:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 943 0x7f4a8c87d070 0x2d716d5ee8e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 903 0x7f4a8cbe5bd0 0x2d716da83658 
[1:1:0712/014901.923658:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 903 0x7f4a8cbe5bd0 0x2d716da83658 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014901.956731:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d4324482a10, 0x2d716c45a9a8
[1:1:0712/014901.956977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 0
[1:1:0712/014901.957720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 956
[1:1:0712/014901.957906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7f4a8c87d070 0x2d716d9bc2e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 903 0x7f4a8cbe5bd0 0x2d716da83658 
[1:1:0712/014901.961864:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014902.009496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014902.009665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014902.370355:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 921, 7f4a8f1c2881
[1:1:0712/014902.413844:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"844 0x7f4a8c87d070 0x2d716d0753e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.414153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"844 0x7f4a8c87d070 0x2d716d0753e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.414502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.415072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014902.415258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014902.415950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014902.416110:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014902.416472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 978
[1:1:0712/014902.416735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 978 0x7f4a8c87d070 0x2d716d05c0e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 921 0x7f4a8c87d070 0x2d716ce00b60 
[1:1:0712/014902.418146:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 925, 7f4a8f1c2881
[1:1:0712/014902.458081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"767 0x7f4a8c87d070 0x2d716d2fe7e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.458393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"767 0x7f4a8c87d070 0x2d716d2fe7e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.458762:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.459336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , ct, (){cr=b}
[1:1:0712/014902.459502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014902.460306:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 926, 7f4a8f1c28db
[1:1:0712/014902.473084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"767 0x7f4a8c87d070 0x2d716d2fe7e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.473247:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"767 0x7f4a8c87d070 0x2d716d2fe7e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.473458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 979
[1:1:0712/014902.473587:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7f4a8c87d070 0x2d716d8875e0 , 5:3_http://mozilla.com.cn/, 0, , 926 0x7f4a8c87d070 0x2d716d5ef5e0 
[1:1:0712/014902.473745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.474029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/014902.474131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014902.474532:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014902.474677:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014902.474869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 980
[1:1:0712/014902.474973:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 980 0x7f4a8c87d070 0x2d716db2cee0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 926 0x7f4a8c87d070 0x2d716d5ef5e0 
[1:1:0712/014902.503330:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 847, 7f4a8f1c28db
[1:1:0712/014902.515977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"654 0x7f4a8c87d070 0x2d716c943be0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.516150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"654 0x7f4a8c87d070 0x2d716c943be0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014902.516380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 983
[1:1:0712/014902.516493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f4a8c87d070 0x2d716d2d87e0 , 5:3_http://mozilla.com.cn/, 0, , 847 0x7f4a8c87d070 0x2d716d07e460 
[1:1:0712/014902.516662:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.516956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/014902.517059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014902.521141:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 931, 7f4a8f1c2881
[1:1:0712/014902.534044:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c80430c0","ptid":"889 0x7f4a8c87d070 0x2d716d9cd3e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014902.534208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"889 0x7f4a8c87d070 0x2d716d9cd3e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014902.534413:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014902.534816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0712/014902.534960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014902.869870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014902.871272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , h, (){if(c==true){return}c=true;for(var a=0,e=b.length;a<e;a++){if(d(b[a])==="function"){try{b[a].call(
[1:1:0712/014902.871574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014902.887546:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.888052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://widget.weibo.com/-5:3_http://mozilla.com.cn/, 2236c7f62860, 2236c80430c0, cardInit, () {
	var cardShow = function (obj) {
		if(BROWSER.ie && BROWSER.ie < 7 && obj.href.indexOf('usernam
[1:1:0712/014902.888187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 2, , , 0
[1:1:0712/014902.888345:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/014902.906357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.907134:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.907850:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.911894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.913276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014902.914145:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a9f0
[1:1:0712/014902.914307:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014902.914673:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1000
[1:1:0712/014902.914871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7f4a8c87d070 0x2d716cab8260 , 5:4_https://widget.weibo.com/, 2, -5:4_https://widget.weibo.com/-5:3_http://mozilla.com.cn/, 941
[1:1:0712/014903.419767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 943, 7f4a8f1c2881
[1:1:0712/014903.460259:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c80430c0","ptid":"903 0x7f4a8cbe5bd0 0x2d716da83658 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014903.460551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"903 0x7f4a8cbe5bd0 0x2d716da83658 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014903.460890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014903.461867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , h, (){var a=+(new Date);do{f.process.call(f.context,e.shift())}while(e.length>0&&+(new Date)-a<f.execTi
[1:1:0712/014903.462106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014903.907128:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 956, 7f4a8f1c2881
[1:1:0712/014903.944760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c80430c0","ptid":"903 0x7f4a8cbe5bd0 0x2d716da83658 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014903.945329:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"903 0x7f4a8cbe5bd0 0x2d716da83658 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014903.946006:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014903.947306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , q, (){if(ax||x){return}if(t<3&&typeof __GLOBAL_STATS_PAGESTART_TIME__!="undefined"){t++;if(typeof __GLO
[1:1:0712/014903.947608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014903.970673:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/014904.039489:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x1d4324482a10, 0x2d716c45a950
[1:1:0712/014904.039791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", 2000
[1:1:0712/014904.040877:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1027
[1:1:0712/014904.041159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1027 0x7f4a8c87d070 0x2d716dbae8e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 956 0x7f4a8c87d070 0x2d716d9bc2e0 
[1:1:0712/014904.046429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 924, 7f4a8f1c28db
[1:1:0712/014904.085931:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"767 0x7f4a8c87d070 0x2d716d2fe7e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014904.086227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"767 0x7f4a8c87d070 0x2d716d2fe7e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014904.086663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1031
[1:1:0712/014904.086860:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1031 0x7f4a8c87d070 0x2d716cb30a60 , 5:3_http://mozilla.com.cn/, 0, , 924 0x7f4a8c87d070 0x2d716d9c0560 
[1:1:0712/014904.087217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014904.087735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0712/014904.087908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014904.139883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0712/014904.140354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1033
[1:1:0712/014904.140547:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1033 0x7f4a8c87d070 0x2d716dc29260 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 924 0x7f4a8c87d070 0x2d716d9c0560 
[1:1:0712/014904.184861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , document.readyState
[1:1:0712/014904.185110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014904.816327:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 980, 7f4a8f1c2881
[1:1:0712/014904.862130:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"926 0x7f4a8c87d070 0x2d716d5ef5e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014904.862458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"926 0x7f4a8c87d070 0x2d716d5ef5e0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014904.862876:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014904.863505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , ct, (){cr=b}
[1:1:0712/014904.863688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014905.322373:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1000, 7f4a8f1c2881
[1:1:0712/014905.364078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c80430c02236c7f62860","ptid":"941","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014905.364408:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/-5:3_http://mozilla.com.cn/","ptid":"941","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014905.364772:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014905.365325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014905.365503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014905.366172:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014905.366347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014905.366701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1058
[1:1:0712/014905.366885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7f4a8c87d070 0x2d716c862060 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1000 0x7f4a8c87d070 0x2d716cab8260 
[1:1:0712/014906.073469:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1033, 7f4a8f1c28db
[1:1:0712/014906.086272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"924 0x7f4a8c87d070 0x2d716d9c0560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014906.086449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"924 0x7f4a8c87d070 0x2d716d9c0560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014906.086691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1072
[1:1:0712/014906.086797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1072 0x7f4a8c87d070 0x2d716d9dd6e0 , 5:3_http://mozilla.com.cn/, 0, , 1033 0x7f4a8c87d070 0x2d716dc29260 
[1:1:0712/014906.086981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014906.087263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/014906.087366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014906.088179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014906.088338:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014906.088713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1073
[1:1:0712/014906.088900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1073 0x7f4a8c87d070 0x2d716dadf6e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1033 0x7f4a8c87d070 0x2d716dc29260 
[55254:55254:0712/014906.256489:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/014906.724542:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1031, 7f4a8f1c28db
[1:1:0712/014906.767203:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"924 0x7f4a8c87d070 0x2d716d9c0560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014906.767449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"924 0x7f4a8c87d070 0x2d716d9c0560 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014906.767907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1082
[1:1:0712/014906.768113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1082 0x7f4a8c87d070 0x2d716dc2fce0 , 5:3_http://mozilla.com.cn/, 0, , 1031 0x7f4a8c87d070 0x2d716cb30a60 
[1:1:0712/014906.768448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014906.768997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0712/014906.769173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014906.826722:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0712/014906.827115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1084
[1:1:0712/014906.827301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7f4a8c87d070 0x2d716dd1bfe0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1031 0x7f4a8c87d070 0x2d716cb30a60 
[1:1:0712/014907.011560:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1058, 7f4a8f1c2881
[1:1:0712/014907.055301:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1000 0x7f4a8c87d070 0x2d716cab8260 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014907.055590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1000 0x7f4a8c87d070 0x2d716cab8260 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014907.055996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014907.056536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014907.056710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014907.057391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014907.057550:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014907.058060:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1094
[1:1:0712/014907.058249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1094 0x7f4a8c87d070 0x2d716dd45760 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1058 0x7f4a8c87d070 0x2d716c862060 
[1:1:0712/014907.229264:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1027, 7f4a8f1c2881
[1:1:0712/014907.242587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c80430c0","ptid":"956 0x7f4a8c87d070 0x2d716d9bc2e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014907.242754:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"956 0x7f4a8c87d070 0x2d716d9bc2e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014907.243021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1"
[1:1:0712/014907.243434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2236c80430c0, , , (){if(D&&D.callback&&typeof D.callback=="function"){D.callback(false);e.onload=null}}
[1:1:0712/014907.243566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=1&ptype=1&speed=0&skin=2&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1663337394&verifier=b218d70f&dpc=1", "widget.weibo.com", 4, 1, http://mozilla.com.cn, mozilla.com.cn, 3
[1:1:0712/014907.380569:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1073, 7f4a8f1c2881
[1:1:0712/014907.434086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1033 0x7f4a8c87d070 0x2d716dc29260 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014907.434426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1033 0x7f4a8c87d070 0x2d716dc29260 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014907.434887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014907.435734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , ct, (){cr=b}
[1:1:0712/014907.436005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014907.487038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 983, 7f4a8f1c28db
[1:1:0712/014907.533011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"847 0x7f4a8c87d070 0x2d716d07e460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014907.533281:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"847 0x7f4a8c87d070 0x2d716d07e460 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014907.533701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1109
[1:1:0712/014907.533922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7f4a8c87d070 0x2d716dcfb560 , 5:3_http://mozilla.com.cn/, 0, , 983 0x7f4a8c87d070 0x2d716d2d87e0 
[1:1:0712/014907.534247:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014907.534780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/014907.534991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014907.732042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1084, 7f4a8f1c28db
[1:1:0712/014907.775469:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1031 0x7f4a8c87d070 0x2d716cb30a60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014907.775743:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1031 0x7f4a8c87d070 0x2d716cb30a60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014907.776172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1112
[1:1:0712/014907.776366:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7f4a8c87d070 0x2d716dd4c0e0 , 5:3_http://mozilla.com.cn/, 0, , 1084 0x7f4a8c87d070 0x2d716dd1bfe0 
[1:1:0712/014907.776698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014907.777234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/014907.777410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014907.778376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014907.778537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014907.778881:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1113
[1:1:0712/014907.779091:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1113 0x7f4a8c87d070 0x2d716dd162e0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1084 0x7f4a8c87d070 0x2d716dd1bfe0 
[1:1:0712/014907.925072:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1094, 7f4a8f1c2881
[1:1:0712/014907.969131:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1058 0x7f4a8c87d070 0x2d716c862060 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014907.969417:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1058 0x7f4a8c87d070 0x2d716c862060 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014907.969778:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014907.970338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014907.970512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014907.971192:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014907.971350:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014907.971701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1121
[1:1:0712/014907.971899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1121 0x7f4a8c87d070 0x2d716dcb38e0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1094 0x7f4a8c87d070 0x2d716dd45760 
[1:1:0712/014908.499202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1113, 7f4a8f1c2881
[1:1:0712/014908.550672:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1084 0x7f4a8c87d070 0x2d716dd1bfe0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014908.551019:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1084 0x7f4a8c87d070 0x2d716dd1bfe0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014908.551463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014908.551988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , ct, (){cr=b}
[1:1:0712/014908.552205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014908.553729:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1082, 7f4a8f1c28db
[1:1:0712/014908.597551:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1031 0x7f4a8c87d070 0x2d716cb30a60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014908.597720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1031 0x7f4a8c87d070 0x2d716cb30a60 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014908.597932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1129
[1:1:0712/014908.598038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1129 0x7f4a8c87d070 0x2d716d5ef960 , 5:3_http://mozilla.com.cn/, 0, , 1082 0x7f4a8c87d070 0x2d716dc2fce0 
[1:1:0712/014908.598408:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014908.599066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , , (){
++index;
if (index > 2) { index = 0; }
scrollFeatures(index);
}
[1:1:0712/014908.599316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014908.663246:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014908.663486:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014908.663938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1130
[1:1:0712/014908.664210:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1130 0x7f4a8c87d070 0x2d716d9c7ee0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1082 0x7f4a8c87d070 0x2d716dc2fce0 
[1:1:0712/014908.666681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 13
[1:1:0712/014908.667136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1131
[1:1:0712/014908.667394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1131 0x7f4a8c87d070 0x2d716c2c0fe0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1082 0x7f4a8c87d070 0x2d716dc2fce0 
[1:1:0712/014908.816475:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1121, 7f4a8f1c2881
[1:1:0712/014908.860489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1094 0x7f4a8c87d070 0x2d716dd45760 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014908.860767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1094 0x7f4a8c87d070 0x2d716dd45760 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014908.861126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014908.861678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014908.861863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014908.862539:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014908.862696:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014908.863050:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1136
[1:1:0712/014908.863257:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1136 0x7f4a8c87d070 0x2d716db2c160 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1121 0x7f4a8c87d070 0x2d716dcb38e0 
[1:1:0712/014908.954690:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1130, 7f4a8f1c2881
[1:1:0712/014908.998835:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1082 0x7f4a8c87d070 0x2d716dc2fce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014908.999114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1082 0x7f4a8c87d070 0x2d716dc2fce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014908.999498:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014909.000009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , ct, (){cr=b}
[1:1:0712/014909.000181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014909.001553:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1131, 7f4a8f1c28db
[1:1:0712/014909.045796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1082 0x7f4a8c87d070 0x2d716dc2fce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014909.046059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1082 0x7f4a8c87d070 0x2d716dc2fce0 ","rf":"5:3_http://mozilla.com.cn/"}
[1:1:0712/014909.046500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://mozilla.com.cn/, 1138
[1:1:0712/014909.046691:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1138 0x7f4a8c87d070 0x2d716dcbd760 , 5:3_http://mozilla.com.cn/, 0, , 1131 0x7f4a8c87d070 0x2d716c2c0fe0 
[1:1:0712/014909.047024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014909.047537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/014909.047711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014909.048691:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014909.048853:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 0
[1:1:0712/014909.049207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1139
[1:1:0712/014909.049414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1139 0x7f4a8c87d070 0x2d716c947be0 , 5:3_http://mozilla.com.cn/, 1, -5:3_http://mozilla.com.cn/, 1131 0x7f4a8c87d070 0x2d716c2c0fe0 
[1:1:0712/014909.103007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1136, 7f4a8f1c2881
[1:1:0712/014909.147721:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2236c7f62860","ptid":"1121 0x7f4a8c87d070 0x2d716dcb38e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014909.148007:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://mozilla.com.cn/","ptid":"1121 0x7f4a8c87d070 0x2d716dcb38e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/014909.148421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://mozilla.com.cn/moz-portal.html"
[1:1:0712/014909.148963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://mozilla.com.cn/, 2236c7f62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/014909.149137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://mozilla.com.cn/moz-portal.html", "mozilla.com.cn", 3, 1, , , 0
[1:1:0712/014909.149813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d43243829c8, 0x2d716c45a950
[1:1:0712/014909.149971:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://mozilla.com.cn/moz-portal.html", 100
[1:1:0712/014909.150349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1143
[1:1:0712/014909.150540:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1143 0x7f4a8c87d070 0x2d716dcd5560 , 5:4_https://widget.weibo.com/, 1, -5:3_http://mozilla.com.cn/, 1136 0x7f4a8c87d070 0x2d716db2c160 
[1:1:0712/014909.197014:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://mozilla.com.cn/, 1139, 7f4a8f1c2881
