[0713/032628.285659:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/032628.286148:INFO:switcher_clone.cc(787)] backtrace rip is 7f2e6e05f891
[0713/032629.389943:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/032629.390268:INFO:switcher_clone.cc(787)] backtrace rip is 7fc41c071891
[1:1:0713/032629.394338:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/032629.394517:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/032629.399454:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/032630.789916:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/032630.790149:INFO:switcher_clone.cc(787)] backtrace rip is 7fa4408af891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[49294:49294:0713/032630.981116:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=49294
[49304:49304:0713/032630.981555:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=49304
[49261:49261:0713/032631.057626:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ef84d99f-7bf0-427f-8d60-6012e2d2ca8f
[49261:49261:0713/032631.456865:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[49261:49292:0713/032631.458373:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/032631.458921:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/032631.459382:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/032631.460685:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/032631.461048:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/032631.466348:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xabbe0ef, 1
[1:1:0713/032631.467108:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15459adf, 0
[1:1:0713/032631.467462:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c37d0f7, 3
[1:1:0713/032631.467904:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2a78ffb8, 2
[1:1:0713/032631.468315:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdfffffff9a4515 ffffffefffffffe0ffffffbb0a ffffffb8ffffffff782a fffffff7ffffffd0371c , 10104, 4
[1:1:0713/032631.470330:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[49261:49292:0713/032631.470848:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGߚE��
��x*��7��
[49261:49292:0713/032631.471026:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ߚE��
��x*��7X͹�
[1:1:0713/032631.470840:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc41a2ac0a0, 3
[49261:49292:0713/032631.471663:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/032631.471706:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc41a437080, 2
[49261:49292:0713/032631.471840:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 49314, 4, df9a4515 efe0bb0a b8ff782a f7d0371c 
[1:1:0713/032631.472034:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc4040fad20, -2
[1:1:0713/032631.504223:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/032631.505506:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a78ffb8
[1:1:0713/032631.507037:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a78ffb8
[1:1:0713/032631.509316:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a78ffb8
[1:1:0713/032631.510847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.511054:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.511238:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.511424:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.512262:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a78ffb8
[1:1:0713/032631.512704:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc41c0717ba
[1:1:0713/032631.512842:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc41c068def, 7fc41c07177a, 7fc41c0730cf
[1:1:0713/032631.519501:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a78ffb8
[1:1:0713/032631.519892:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a78ffb8
[1:1:0713/032631.520639:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a78ffb8
[1:1:0713/032631.522664:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.522894:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.523084:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.523267:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a78ffb8
[1:1:0713/032631.524521:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a78ffb8
[1:1:0713/032631.524892:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc41c0717ba
[1:1:0713/032631.525034:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc41c068def, 7fc41c07177a, 7fc41c0730cf
[1:1:0713/032631.533051:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/032631.533477:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/032631.533647:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe9472d638, 0x7ffe9472d5b8)
[1:1:0713/032631.548985:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/032631.555564:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[49261:49261:0713/032632.168911:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032632.170298:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49273:0713/032632.191766:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[49261:49273:0713/032632.191870:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[49261:49261:0713/032632.192107:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[49261:49261:0713/032632.192204:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[49261:49261:0713/032632.192378:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,49314, 4
[1:7:0713/032632.197045:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[49261:49286:0713/032632.225132:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/032632.264995:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x35a449f61220
[1:1:0713/032632.265626:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/032632.554675:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/032634.141548:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032634.145340:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49261:49261:0713/032634.381799:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[49261:49261:0713/032634.381915:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/032635.354571:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032635.558935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cd2d9d21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/032635.559242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032635.566565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cd2d9d21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/032635.566826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032635.667615:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032635.667794:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032636.073018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032636.081140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cd2d9d21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/032636.081349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032636.115563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032636.125972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cd2d9d21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/032636.126180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032636.138192:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[49261:49261:0713/032636.140204:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032636.142322:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x35a449f5fe20
[1:1:0713/032636.142506:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[49261:49261:0713/032636.147048:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[49261:49261:0713/032636.181370:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[49261:49261:0713/032636.181575:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/032636.241200:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032636.958989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fc405cd52e0 0x35a44a140360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032636.959688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cd2d9d21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/032636.959836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032636.960384:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[49261:49261:0713/032637.023136:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032637.025492:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x35a449f60820
[1:1:0713/032637.025738:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[49261:49261:0713/032637.030647:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/032637.048165:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032637.048415:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[49261:49261:0713/032637.049767:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[49261:49261:0713/032637.062870:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032637.064116:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49273:0713/032637.071332:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[49261:49273:0713/032637.071421:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[49261:49261:0713/032637.071661:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[49261:49261:0713/032637.071754:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[49261:49261:0713/032637.071953:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,49314, 4
[1:7:0713/032637.075771:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032637.640701:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/032638.044779:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7fc405cd52e0 0x35a44a0ce7e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032638.045839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cd2d9d21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/032638.046134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032638.046888:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[49261:49261:0713/032638.288997:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[49261:49261:0713/032638.289069:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/032638.315596:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49261:49261:0713/032638.710326:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[49261:49292:0713/032638.710548:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/032638.710722:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/032638.710949:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/032638.711358:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/032638.711499:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/032638.714556:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x142b62bc, 1
[1:1:0713/032638.714905:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x212be7cc, 0
[1:1:0713/032638.715055:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x942d2b0, 3
[1:1:0713/032638.715217:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x696e0b1, 2
[1:1:0713/032638.715370:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffccffffffe72b21 ffffffbc622b14 ffffffb1ffffffe0ffffff9606 ffffffb0ffffffd24209 , 10104, 5
[1:1:0713/032638.716355:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[49261:49292:0713/032638.716568:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��+!�b+�����B	R�
[49261:49292:0713/032638.716637:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��+!�b+�����B	��R�
[1:1:0713/032638.716754:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc41a2ac0a0, 3
[49261:49292:0713/032638.716921:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 49358, 5, cce72b21 bc622b14 b1e09606 b0d24209 
[1:1:0713/032638.717036:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc41a437080, 2
[1:1:0713/032638.717272:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc4040fad20, -2
[1:1:0713/032638.738283:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/032638.738602:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 696e0b1
[1:1:0713/032638.738941:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 696e0b1
[1:1:0713/032638.739581:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 696e0b1
[1:1:0713/032638.740974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.741184:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.741386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.741562:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.742279:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 696e0b1
[1:1:0713/032638.742651:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc41c0717ba
[1:1:0713/032638.742844:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc41c068def, 7fc41c07177a, 7fc41c0730cf
[1:1:0713/032638.744467:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 696e0b1
[1:1:0713/032638.744632:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 696e0b1
[1:1:0713/032638.744904:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 696e0b1
[1:1:0713/032638.745586:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.745702:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.745809:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.745904:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 696e0b1
[1:1:0713/032638.746386:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 696e0b1
[1:1:0713/032638.746548:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc41c0717ba
[1:1:0713/032638.746625:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc41c068def, 7fc41c07177a, 7fc41c0730cf
[1:1:0713/032638.748784:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/032638.749133:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/032638.749236:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe9472d638, 0x7ffe9472d5b8)
[1:1:0713/032638.764612:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/032638.768846:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/032638.774892:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032638.947153:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x35a449f40220
[1:1:0713/032638.947364:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/032639.425024:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032639.425307:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/032639.835375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/032639.840070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3cd2d9e4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/032639.840401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/032639.849265:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[49261:49261:0713/032639.959750:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032639.968251:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49273:0713/032640.018986:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[49261:49273:0713/032640.019089:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[49261:49261:0713/032640.019671:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://hq.gucheng.com/
[49261:49261:0713/032640.019773:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://hq.gucheng.com/, https://hq.gucheng.com/SH600199/, 1
[49261:49261:0713/032640.019944:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://hq.gucheng.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=utf-8 content-length:14220 date:Sat, 13 Jul 2019 10:26:39 GMT vary:Accept-Encoding x-powered-by:PHP/7.1.17 set-cookie:stockhistory=1543%2C785%2C2225%2C531; path=/ expires:Thu, 19 Nov 1981 08:52:00 GMT cache-control:no-store, no-cache, must-revalidate pragma:no-cache content-encoding:gzip ali-swift-global-savetime:1563013599 via:cache24.l2eu6-1[184,200-0,M], cache3.l2eu6-1[184,0], cache5.cn143[246,200-0,M], cache5.cn143[248,0] x-cache:MISS TCP_MISS dirn:-2:-2 x-swift-savetime:Sat, 13 Jul 2019 10:26:39 GMT x-swift-cachetime:0 timing-allow-origin:* eagleid:7cc1e29915630135997163386e  ,49358, 5
[1:7:0713/032640.024083:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032640.066303:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://hq.gucheng.com/
[1:1:0713/032640.103888:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032640.104694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cd2d9d21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/032640.104925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[49261:49261:0713/032640.206604:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://hq.gucheng.com/, https://hq.gucheng.com/, 1
[49261:49261:0713/032640.206708:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://hq.gucheng.com/, https://hq.gucheng.com
[1:1:0713/032640.229611:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/032640.338306:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032640.433333:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032640.433492:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.551006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/032640.552698:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/032640.552929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3cd2d9e4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/032640.553193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/032640.574976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 158, "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.577277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , //pc to wap

var isMobile = false;



var pingbi = false;



var u = navigator.userAgent;







if 
[1:1:0713/032640.577503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032640.581302:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032640.601452:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 158, "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.617392:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.016701, 57, 1
[1:1:0713/032640.617672:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032640.636750:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/032640.637603:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/032640.637880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3cd2d9e4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/032640.638145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/032640.701550:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032640.701842:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.702617:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7fc403dad070 0x35a44a073d60 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.703482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , hq_top_ad();
[1:1:0713/032640.703718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032640.716569:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7fc403dad070 0x35a44a073d60 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.735134:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0331719, 176, 1
[1:1:0713/032640.735373:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032640.942426:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032640.942696:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.943466:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 186 0x7fc403dad070 0x35a44a07d160 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032640.944278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , right_toptitle();
[1:1:0713/032640.944505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032641.013236:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032641.097086:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200, "https://hq.gucheng.com/SH600199/"
[1:1:0713/032641.098546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0713/032641.098834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/032641.657818:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032641.658314:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032641.660763:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032641.661181:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032641.661531:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[49261:49261:0713/032721.361057:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/032721.368105:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/032721.519810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7fc405cd52e0 0x35a44a0784e0 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032721.529057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , (function(){var h={},mt={},c={id:"9636c8f382a28ba02485f6d78a23de71",dm:["gucheng.com"],js:"tongji.ba
[1:1:0713/032721.529342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032721.546141:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032721.564913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70948
[1:1:0713/032721.565210:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032721.565670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 252
[1:1:0713/032721.565919:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 252 0x7fc403dad070 0x35a44a0dcfe0 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 213 0x7fc405cd52e0 0x35a44a0784e0 
[1:1:0713/032722.780578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/032722.780871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032723.053850:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032723.445609:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 252, 7fc4066f2881
[1:1:0713/032723.455641:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"213 0x7fc405cd52e0 0x35a44a0784e0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032723.456010:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"213 0x7fc405cd52e0 0x35a44a0784e0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032723.456448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032723.457079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032723.457296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032723.458080:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032723.458417:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032723.458907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 299
[1:1:0713/032723.459170:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 299 0x7fc403dad070 0x35a44a25fce0 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 252 0x7fc403dad070 0x35a44a0dcfe0 
[1:1:0713/032723.513034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032723.513358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032723.537058:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7fc405cd52e0 0x35a44a252760 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032723.542461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , try{!function(t){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_ds_||(win
[1:1:0713/032723.542706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
		remove user.11_440f053b -> 0
[1:1:0713/032724.098932:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[49261:49261:0713/032724.101209:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032724.103534:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x35a449f3f820
[1:1:0713/032724.103784:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[49261:49261:0713/032724.107817:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0713/032724.132395:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032724.132820:INFO:render_frame_impl.cc(7019)] 	 [url] = https://hq.gucheng.com
[49261:49261:0713/032724.134497:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://hq.gucheng.com/
[1:1:0713/032724.180961:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7fc405cd52e0 0x35a44a05f0e0 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032724.182138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , window.__baidu_dup_jobruner = {};
try {
    var storage = window.localStorage;
    if (storage &&
[1:1:0713/032724.182442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032724.184019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://hq.gucheng.com/SH600199/"
[49261:49261:0713/032724.375996:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032724.383597:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49273:0713/032724.419919:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[49261:49273:0713/032724.420062:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[49261:49261:0713/032724.420269:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[49261:49261:0713/032724.420370:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184, 4
[49261:49261:0713/032724.420583:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 7503 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 10:27:24 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 18:27:24 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,49358, 5
[1:7:0713/032724.423597:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032724.469658:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032724.469928:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032724.471921:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/032724.475689:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x35a449f3e420
[1:1:0713/032724.475917:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[49261:49261:0713/032724.476534:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[49261:49261:0713/032724.484483:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0713/032724.486852:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032724.487084:INFO:render_frame_impl.cc(7019)] 	 [url] = https://hq.gucheng.com
[1:1:0713/032724.489738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 290 0x7fc403dad070 0x35a44a0d7460 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032724.490674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , right_chart_gg();
[1:1:0713/032724.490915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[49261:49261:0713/032724.498722:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://hq.gucheng.com/
[1:1:0713/032724.627330:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://hq.gucheng.com/SH600199/"
[1:1:0713/032724.628053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/032724.628264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032724.643912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032724.644194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[49261:49261:0713/032724.752862:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032724.758449:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/032724.780683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 299, 7fc4066f2881
[49261:49273:0713/032724.781722:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[49261:49273:0713/032724.781808:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[49261:49261:0713/032724.782064:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://hq.gucheng.com/
[49261:49261:0713/032724.782158:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://hq.gucheng.com/, https://hq.gucheng.com/chart.php?code=SH600199, 5
[49261:49261:0713/032724.782295:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://hq.gucheng.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=UTF-8 content-length:3539 date:Sat, 13 Jul 2019 10:27:24 GMT vary:Accept-Encoding x-powered-by:PHP/7.1.17 content-encoding:gzip ali-swift-global-savetime:1563013644 via:cache5.l2st4-2[51,200-0,M], cache2.l2st4-2[52,0], cache6.cn143[222,200-0,M], cache5.cn143[224,0] x-cache:MISS TCP_MISS dirn:-2:-2 x-swift-savetime:Sat, 13 Jul 2019 10:27:24 GMT x-swift-cachetime:0 timing-allow-origin:* eagleid:7cc1e29915630136445448441e  ,49358, 5
[1:7:0713/032724.787539:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032724.793025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"252 0x7fc403dad070 0x35a44a0dcfe0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032724.793340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"252 0x7fc403dad070 0x35a44a0dcfe0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032724.793745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032724.794409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032724.794651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032724.795371:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032724.795599:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032724.795989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 370
[1:1:0713/032724.796367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7fc403dad070 0x35a44a0687e0 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 299 0x7fc403dad070 0x35a44a25fce0 
[1:1:0713/032725.252811:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://pos.baidu.com/
[1:1:0713/032725.717351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "https://hq.gucheng.com/SH600199/"
[1:1:0713/032725.718602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0713/032725.718880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032726.095741:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[49261:49261:0713/032726.097048:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032726.099895:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x35a449f3da20
[1:1:0713/032726.100125:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[49261:49261:0713/032726.103812:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0713/032726.118190:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032726.118355:INFO:render_frame_impl.cc(7019)] 	 [url] = https://hq.gucheng.com
[49261:49261:0713/032726.130114:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://hq.gucheng.com/
[1:1:0713/032726.174155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032726.174457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032726.275028:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://hq.gucheng.com/
[1:1:0713/032726.297591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 370, 7fc4066f2881
[49261:49261:0713/032726.301710:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032726.304587:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49273:0713/032726.317671:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[49261:49273:0713/032726.317792:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[49261:49261:0713/032726.318028:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[49261:49261:0713/032726.318118:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://pos.baidu.com/, https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2, 6
[49261:49261:0713/032726.318310:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 7493 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 10:27:26 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 18:27:26 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,49358, 5
[1:1:0713/032726.318744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"299 0x7fc403dad070 0x35a44a25fce0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032726.319125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"299 0x7fc403dad070 0x35a44a25fce0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032726.319549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032726.320197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032726.320447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:7:0713/032726.321061:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032726.321407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032726.321609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032726.322080:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 414
[1:1:0713/032726.322324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 414 0x7fc403dad070 0x35a44a8245e0 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 370 0x7fc403dad070 0x35a44a0687e0 
[49261:49261:0713/032726.393189:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/, 4
[49261:49261:0713/032726.393319:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0713/032726.394262:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/032726.770803:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032726.821432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032726.821641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032726.896497:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49261:49261:0713/032726.909237:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://hq.gucheng.com/, https://hq.gucheng.com/, 5
[49261:49261:0713/032726.909297:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://hq.gucheng.com/, https://hq.gucheng.com
[1:1:0713/032726.960050:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://pos.baidu.com/
[1:1:0713/032726.995887:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032727.067688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 414, 7fc4066f2881
[1:1:0713/032727.081075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"370 0x7fc403dad070 0x35a44a0687e0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032727.081357:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"370 0x7fc403dad070 0x35a44a0687e0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032727.081676:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032727.082160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032727.082319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032727.082784:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032727.082930:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032727.083213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 458
[1:1:0713/032727.083385:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 458 0x7fc403dad070 0x35a44acfa460 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 414 0x7fc403dad070 0x35a44a8245e0 
[1:1:0713/032727.298241:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032727.298407:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032727.322659:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.024246, 393, 1
[1:1:0713/032727.322844:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032727.353657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032727.353987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032727.420473:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/032727.946508:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49261:49261:0713/032727.958545:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://pos.baidu.com/, https://pos.baidu.com/, 6
[49261:49261:0713/032727.958604:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0713/032727.984500:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032727.984754:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032728.093712:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 458, 7fc4066f2881
[1:1:0713/032728.121945:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"414 0x7fc403dad070 0x35a44a8245e0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032728.122653:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"414 0x7fc403dad070 0x35a44a8245e0 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032728.123259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032728.124022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032728.124309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032728.125040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032728.125263:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032728.125755:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 513
[1:1:0713/032728.126006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7fc403dad070 0x35a44afde660 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 458 0x7fc403dad070 0x35a44acfa460 
[1:1:0713/032728.276286:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032728.276599:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032728.277555:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fc403dad070 0x35a44a27d060 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032728.278518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , right_hqbqy();
[1:1:0713/032728.278746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032728.330589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032728.330939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032728.389009:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032728.389326:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/chart.php?code=SH600199"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/032728.696877:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032729.032005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504, "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032729.034808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 112ac883e348, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0713/032729.035093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184", "pos.baidu.com", 4, 1, https://hq.gucheng.com, hq.gucheng.com, 3
[1:1:0713/032729.041062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504, "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032729.056414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504, "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032729.063956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504, "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032729.247257:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504, "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032729.255977:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504, "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032729.386724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 513, 7fc4066f2881
[1:1:0713/032729.417037:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"458 0x7fc403dad070 0x35a44acfa460 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032729.417405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"458 0x7fc403dad070 0x35a44acfa460 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032729.417844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032729.418461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032729.418803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032729.419797:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032729.420045:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032729.420563:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 580
[1:1:0713/032729.420814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7fc403dad070 0x35a44afd3c60 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 513 0x7fc403dad070 0x35a44afde660 
[1:1:0713/032729.510349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519, "https://hq.gucheng.com/SH600199/"
[1:1:0713/032729.511753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0713/032729.512011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032729.967507:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[49261:49261:0713/032729.971524:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032729.971813:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x35a44aa1ae20
[1:1:0713/032729.972061:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[49261:49261:0713/032729.979101:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0713/032729.986616:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032729.986911:INFO:render_frame_impl.cc(7019)] 	 [url] = https://hq.gucheng.com
[49261:49261:0713/032729.996982:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://hq.gucheng.com/
[1:1:0713/032730.085502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032730.085843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[49261:49261:0713/032730.258519:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032730.265433:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49261:0713/032730.304732:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[49261:49261:0713/032730.304791:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://pos.baidu.com/, https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0, 7
[49261:49261:0713/032730.304857:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 8538 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 10:27:30 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 18:27:30 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,49358, 5
[49261:49273:0713/032730.305491:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[49261:49273:0713/032730.305573:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/032730.306670:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032730.455902:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032730.456148:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032730.485126:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fc403dad070 0x35a44b0a31e0 , "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032730.504775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://pos.baidu.com/, 112ac880e900, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0713/032730.505091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2", "pos.baidu.com", 6, 1, https://hq.gucheng.com, hq.gucheng.com, 3
[1:1:0713/032730.511273:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fc403dad070 0x35a44b0a31e0 , "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032730.531244:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fc403dad070 0x35a44b0a31e0 , "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032730.541393:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fc403dad070 0x35a44b0a31e0 , "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032730.627101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fc403dad070 0x35a44b0a31e0 , "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032730.634470:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fc403dad070 0x35a44b0a31e0 , "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032730.843599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://hq.gucheng.com/SH600199/"
[1:1:0713/032730.845153:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://hq.gucheng.com/, 5:4_https://pos.baidu.com/
[1:1:0713/032730.845400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/032730.845629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032731.575480:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032731.631249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 580, 7fc4066f2881
[1:1:0713/032731.661134:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"513 0x7fc403dad070 0x35a44afde660 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032731.661549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"513 0x7fc403dad070 0x35a44afde660 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032731.662133:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032731.662858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032731.663127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032731.663809:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032731.664042:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032731.664429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 676
[1:1:0713/032731.664651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7fc403dad070 0x35a44b486860 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 580 0x7fc403dad070 0x35a44afd3c60 
[1:1:0713/032731.685774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032731.686171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032732.029814:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_https://pos.baidu.com/
[1:1:0713/032732.258135:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://hq.gucheng.com/SH600199/"
[1:1:0713/032732.258842:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://hq.gucheng.com/, 5:6_https://pos.baidu.com/
[1:1:0713/032732.259009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0713/032732.259205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032732.634024:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184"
[1:1:0713/032732.638150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 112ac883e348, , window.onload, (){logo.init({containerId:"container",closeDirect:true,feedbackParentId:"container",deviceType:1})}
[1:1:0713/032732.638558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&exps=111000,110011&ant=0&dtm=HTML_POST&pis=-1x-1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&prot=2&tpr=1563013643811&psr=1276x647&par=1211x623&chi=2&ari=2&cmi=2&drs=1&col=en-US&tlm=1563013644&cec=UTF-8&ccd=24&tcn=1563013644&cce=true&dai=1&cpl=2&pcs=1025x409&dc=3&cdo=-1&cja=false&dis=0&dri=0&pss=1220x513&cfv=0&ps=473x1184", "pos.baidu.com", 4, 1, https://hq.gucheng.com, hq.gucheng.com, 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/032732.936358:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032732.936529:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032732.937454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 675 0x7fc403dad070 0x35a44afcf0e0 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032732.937951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , right_toptitle();
[1:1:0713/032732.938076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032732.940108:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 675 0x7fc403dad070 0x35a44afcf0e0 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032733.584783:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[49261:49261:0713/032733.586962:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032733.589186:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x35a44afeda20
[1:1:0713/032733.589361:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[49261:49261:0713/032733.594887:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[1:1:0713/032733.607820:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032733.607984:INFO:render_frame_impl.cc(7019)] 	 [url] = https://hq.gucheng.com
[49261:49261:0713/032733.610017:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://hq.gucheng.com/
[1:1:0713/032733.655084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032733.655273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[49261:49261:0713/032733.709760:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032733.717150:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49273:0713/032733.761158:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[49261:49273:0713/032733.761266:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[49261:49261:0713/032733.761587:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[49261:49261:0713/032733.761666:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://pos.baidu.com/, https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&cdo=-1&par=1211x623&dc=3&pis=-1x-1&dri=1&pss=1220x1181&prot=2&dtm=HTML_POST&col=en-US&pcs=1025x456&ps=1141x1184&psr=1276x647&cec=UTF-8&dis=0&tpr=1563013643811&cce=true&chi=2&cja=false&drs=1&ccd=24&cfv=0&tlm=1563013653&cmi=2&exps=111000,115008,110011&ari=2&ant=0&tcn=1563013653&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&dai=4, 8
[49261:49261:0713/032733.761831:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 7762 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 10:27:33 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 18:27:33 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,49358, 5
[1:7:0713/032733.769436:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032733.831865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fc403dad070 0x35a44b4fc860 , "https://hq.gucheng.com/chart.php?code=SH600199"
[1:1:0713/032733.859956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://hq.gucheng.com/, 112ac88063b8, , , 
	 var gucheng_watermark='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAAoCAYAAAB5LPGYAAAAGXRF
[1:1:0713/032733.860202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/chart.php?code=SH600199", "hq.gucheng.com", 5, 1, https://hq.gucheng.com, hq.gucheng.com, 3
[1:1:0713/032733.870654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fc403dad070 0x35a44b4fc860 , "https://hq.gucheng.com/chart.php?code=SH600199"
[1:1:0713/032733.985189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fc403dad070 0x35a44b4fc860 , "https://hq.gucheng.com/chart.php?code=SH600199"
[1:1:0713/032734.031596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 676, 7fc4066f2881
[1:1:0713/032734.069711:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"580 0x7fc403dad070 0x35a44afd3c60 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032734.070331:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"580 0x7fc403dad070 0x35a44afd3c60 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032734.070886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032734.071495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032734.071731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032734.072415:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032734.072630:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032734.073015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 780
[1:1:0713/032734.073254:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7fc403dad070 0x35a44afd3460 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 676 0x7fc403dad070 0x35a44b486860 
[1:1:0713/032734.371349:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49261:49261:0713/032734.392821:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://pos.baidu.com/, https://pos.baidu.com/, 7
[49261:49261:0713/032734.392940:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0713/032734.443898:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2"
[1:1:0713/032734.447544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://pos.baidu.com/, 112ac880e900, , window.onload, (){logo.init({containerId:"container",closeDirect:true,feedbackParentId:"container",deviceType:1})}
[1:1:0713/032734.447978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/s?hei=22&wid=520&di=u3559948&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&col=en-US&drs=1&dtm=HTML_POST&tlm=1563013645&dis=0&cfv=0&pss=1220x913&cmi=2&dc=3&pcs=1025x456&cja=false&ant=0&chi=2&psr=1276x647&cdo=-1&tcn=1563013646&ccd=24&ps=847x310&dai=2&cpl=2&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cce=true&dri=0&cec=UTF-8&par=1211x623&exps=111000,110011&prot=2&pis=-1x-1&tpr=1563013643811&ari=2", "pos.baidu.com", 6, 1, https://hq.gucheng.com, hq.gucheng.com, 3
[1:1:0713/032735.700991:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032735.950113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032735.950422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032736.135893:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:8_https://pos.baidu.com/
[1:1:0713/032736.197314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 746 0x7fc41a437080 0x35a44ad8d600 1 0 0x35a44ad8d618 , "https://hq.gucheng.com/chart.php?code=SH600199"
[1:1:0713/032736.203400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://hq.gucheng.com/, 112ac88063b8, , , var IO = IO || {}; !
function() {
    function escapeRegExp(e) {
        return e.replace(/([.*+?
[1:1:0713/032736.203699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/chart.php?code=SH600199", "hq.gucheng.com", 5, 1, https://hq.gucheng.com, hq.gucheng.com, 3
[1:1:0713/032736.212932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23ad935577b8, 0x35a449b709a8
[1:1:0713/032736.213237:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/chart.php?code=SH600199", 0
[1:1:0713/032736.213662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_https://hq.gucheng.com/, 850
[1:1:0713/032736.213910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7fc403dad070 0x35a44afe19e0 , 5:5_https://hq.gucheng.com/, 1, -5:5_https://hq.gucheng.com/, 746 0x7fc41a437080 0x35a44ad8d600 1 0 0x35a44ad8d618 
[1:1:0713/032737.492275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 780, 7fc4066f2881
[1:1:0713/032737.524258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"676 0x7fc403dad070 0x35a44b486860 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032737.524670:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"676 0x7fc403dad070 0x35a44b486860 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032737.525117:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032737.525749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032737.525985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032737.526776:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032737.526986:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032737.527416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 873
[1:1:0713/032737.527628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7fc403dad070 0x35a44b547960 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 780 0x7fc403dad070 0x35a44afd3460 
[1:1:0713/032737.755655:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032738.849123:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032738.849283:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032738.851830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 839 0x7fc403dad070 0x35a44af279e0 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032738.852386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , 
							 if(isMobile){
							var div=document.getElementById("chengjiaoe");/*w和h都要用这部�
[1:1:0713/032738.852497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032738.861587:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.012301, 289, 1
[1:1:0713/032738.861763:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032738.953016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , document.readyState
[1:1:0713/032738.953191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032739.025691:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[49261:49261:0713/032739.037525:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://pos.baidu.com/, https://pos.baidu.com/, 8
[49261:49261:0713/032739.037612:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, https://pos.baidu.com/, https://pos.baidu.com
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/032739.591470:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_https://hq.gucheng.com/, 850, 7fc4066f2881
[1:1:0713/032739.614099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac88063b8","ptid":"746 0x7fc41a437080 0x35a44ad8d600 1 0 0x35a44ad8d618 ","rf":"5:5_https://hq.gucheng.com/"}
[1:1:0713/032739.614449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:5_https://hq.gucheng.com/","ptid":"746 0x7fc41a437080 0x35a44ad8d600 1 0 0x35a44ad8d618 ","rf":"5:5_https://hq.gucheng.com/"}
[1:1:0713/032739.614856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/chart.php?code=SH600199"
[1:1:0713/032739.615460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://hq.gucheng.com/, 112ac88063b8, , , () {
                return P ? void 0 : /loaded|complete/.test(j.readyState) ? void e() : void set
[1:1:0713/032739.615734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/chart.php?code=SH600199", "hq.gucheng.com", 5, 1, https://hq.gucheng.com, hq.gucheng.com, 3
[1:1:0713/032739.616600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23ad935577b8, 0x35a449b70950
[1:1:0713/032739.616832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/chart.php?code=SH600199", 0
[1:1:0713/032739.617268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_https://hq.gucheng.com/, 927
[1:1:0713/032739.617494:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 927 0x7fc403dad070 0x35a44ac965e0 , 5:5_https://hq.gucheng.com/, 1, -5:5_https://hq.gucheng.com/, 850 0x7fc403dad070 0x35a44afe19e0 
[1:1:0713/032740.323521:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 873, 7fc4066f2881
[1:1:0713/032740.362531:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"112ac8702860","ptid":"780 0x7fc403dad070 0x35a44afd3460 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032740.362892:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hq.gucheng.com/","ptid":"780 0x7fc403dad070 0x35a44afd3460 ","rf":"5:3_https://hq.gucheng.com/"}
[1:1:0713/032740.363306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hq.gucheng.com/SH600199/"
[1:1:0713/032740.363879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032740.364115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032740.364805:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23ad935429c8, 0x35a449b70950
[1:1:0713/032740.364991:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hq.gucheng.com/SH600199/", 100
[1:1:0713/032740.365350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hq.gucheng.com/, 935
[1:1:0713/032740.365541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7fc403dad070 0x35a44b571e60 , 5:3_https://hq.gucheng.com/, 1, -5:3_https://hq.gucheng.com/, 873 0x7fc403dad070 0x35a44b547960 
[1:1:0713/032740.379520:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032740.379677:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0"
[1:1:0713/032740.388755:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7fc403dad070 0x35a44acbe6e0 , "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0"
[1:1:0713/032740.409658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_https://pos.baidu.com/, 112ac87fa458, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0713/032740.409952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0", "pos.baidu.com", 7, 1, https://hq.gucheng.com, hq.gucheng.com, 3
[1:1:0713/032740.415305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7fc403dad070 0x35a44acbe6e0 , "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0"
[1:1:0713/032740.426377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7fc403dad070 0x35a44acbe6e0 , "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0"
[1:1:0713/032740.435331:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7fc403dad070 0x35a44acbe6e0 , "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0"
[1:1:0713/032740.538314:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0", 2000
[1:1:0713/032740.540333:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:7_https://pos.baidu.com/, 961
[1:1:0713/032740.540551:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7fc403dad070 0x35a44afdd460 , 5:7_https://pos.baidu.com/, 1, -5:7_https://pos.baidu.com/, 876 0x7fc403dad070 0x35a44acbe6e0 
[1:1:0713/032740.542827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7fc403dad070 0x35a44acbe6e0 , "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0"
[1:1:0713/032740.548544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7fc403dad070 0x35a44acbe6e0 , "https://pos.baidu.com/s?hei=90&wid=892&di=u2995271&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&drs=1&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&cja=false&cdo=-1&exps=111000,110011&ant=0&ari=2&ps=1020x290&cpl=2&cmi=2&cce=true&pcs=1025x456&prot=2&tpr=1563013643811&chi=2&col=en-US&dai=3&cec=UTF-8&dis=0&psr=1276x647&dtm=HTML_POST&pis=-1x-1&tlm=1563013649&ccd=24&cfv=0&pss=1220x1130&par=1211x623&dc=3&tcn=1563013650&dri=0"
[1:1:0713/032741.208750:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032741.208927:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hq.gucheng.com/SH600199/"
[1:1:0713/032741.209466:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 898 0x7fc403dad070 0x35a44b8706e0 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032741.209953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hq.gucheng.com/, 112ac8702860, , , right_toptitle();
[1:1:0713/032741.210065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hq.gucheng.com/SH600199/", "hq.gucheng.com", 3, 1, , , 0
[1:1:0713/032741.212026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 898 0x7fc403dad070 0x35a44b8706e0 , "https://hq.gucheng.com/SH600199/"
[1:1:0713/032741.910070:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[49261:49261:0713/032741.912154:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032741.915096:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x35a44bc5d820
[1:1:0713/032741.915442:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[49261:49261:0713/032741.919170:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[1:1:0713/032741.935248:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032741.935493:INFO:render_frame_impl.cc(7019)] 	 [url] = https://hq.gucheng.com
[49261:49261:0713/032741.979996:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://hq.gucheng.com/
[1:1:0713/032742.047940:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[49261:49261:0713/032742.121311:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[49261:49261:0713/032742.122777:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[49261:49261:0713/032742.166652:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[49261:49261:0713/032742.166748:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://pos.baidu.com/, https://pos.baidu.com/s?hei=22&wid=600&di=u2995312&ltu=https%3A%2F%2Fhq.gucheng.com%2FSH600199%2F&psi=bcea699833e918808a587a827a86db99&ti=%E9%87%91%E7%A7%8D%E5%AD%90%E9%85%92(600199)%E8%82%A1%E7%A5%A8%E4%BB%B7%E6%A0%BC%E8%B5%B0%E5%8A%BF-%E8%82%A1%E7%A5%A8%E8%A1%8C%E6%83%85-%E8%82%A1%E5%9F%8E%E7%BD%91&dai=5&cja=false&pis=-1x-1&psr=1276x647&cdo=-1&exps=111000,115008,110011&dtm=HTML_POST&prot=2&cmi=2&cce=true&cfv=0&cec=UTF-8&tlm=1563013661&ps=2416x1184&dis=0&pss=1260x2456&ant=0&col=en-US&pcs=1025x456&drs=1&ccd=24&dc=3&ari=2&dri=2&cpl=2&par=1211x623&tpr=1563013643811&tcn=1563013662&chi=2, 9
[49261:49261:0713/032742.166894:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 7504 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 10:27:42 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 18:27:42 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,49358, 5
[49261:49273:0713/032742.195372:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[49261:49273:0713/032742.195546:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/032742.197988:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
