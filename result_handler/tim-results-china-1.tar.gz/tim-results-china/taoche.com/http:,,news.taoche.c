[0712/141608.889420:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141608.889820:INFO:switcher_clone.cc(787)] backtrace rip is 7f9ed746b891
[0712/141609.845626:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141609.846059:INFO:switcher_clone.cc(787)] backtrace rip is 7fe9fc69e891
[1:1:0712/141609.860251:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/141609.860615:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/141609.866326:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[22862:22862:0712/141611.299603:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/389fd7c9-a493-4b5c-87b3-d9c103f9967d
[0712/141611.429211:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141611.429725:INFO:switcher_clone.cc(787)] backtrace rip is 7f6410f9c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[22896:22896:0712/141611.644659:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=22896
[22907:22907:0712/141611.645106:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=22907
[22862:22862:0712/141611.735183:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[22862:22893:0712/141611.736053:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/141611.736358:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/141611.736584:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/141611.737167:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/141611.737349:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/141611.740284:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x157972fd, 1
[1:1:0712/141611.740660:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1b01b07d, 0
[1:1:0712/141611.740858:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10d83497, 3
[1:1:0712/141611.741073:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x13dd4ac3, 2
[1:1:0712/141611.741321:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7dffffffb0011b fffffffd727915 ffffffc34affffffdd13 ffffff9734ffffffd810 , 10104, 4
[1:1:0712/141611.742280:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[22862:22893:0712/141611.742583:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING}��ry�J��4����
[22862:22893:0712/141611.742656:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is }��ry�J��4�H㋙�
[1:1:0712/141611.742562:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe9fa8d90a0, 3
[1:1:0712/141611.742806:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe9faa64080, 2
[22862:22893:0712/141611.742953:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[22862:22893:0712/141611.743028:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 22915, 4, 7db0011b fd727915 c34add13 9734d810 
[1:1:0712/141611.742971:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe9e4727d20, -2
[1:1:0712/141611.762165:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/141611.763059:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13dd4ac3
[1:1:0712/141611.764030:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13dd4ac3
[1:1:0712/141611.765709:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13dd4ac3
[1:1:0712/141611.767172:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.767390:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.767569:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.767755:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.768445:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13dd4ac3
[1:1:0712/141611.768809:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe9fc69e7ba
[1:1:0712/141611.768978:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe9fc695def, 7fe9fc69e77a, 7fe9fc6a00cf
[1:1:0712/141611.772194:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13dd4ac3
[1:1:0712/141611.772387:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13dd4ac3
[1:1:0712/141611.772662:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13dd4ac3
[1:1:0712/141611.773321:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.773427:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.773517:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.773609:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13dd4ac3
[1:1:0712/141611.774031:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13dd4ac3
[1:1:0712/141611.774181:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe9fc69e7ba
[1:1:0712/141611.774258:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe9fc695def, 7fe9fc69e77a, 7fe9fc6a00cf
[1:1:0712/141611.776423:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/141611.776678:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/141611.776768:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffddae68248, 0x7ffddae681c8)
[1:1:0712/141611.788123:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/141611.790837:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[22862:22862:0712/141612.367374:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22862:22862:0712/141612.368827:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22862:22862:0712/141612.381994:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[22862:22874:0712/141612.381995:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[22862:22862:0712/141612.382055:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[22862:22862:0712/141612.382134:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,22915, 4
[22862:22874:0712/141612.382118:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/141612.384144:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[22862:22887:0712/141612.440990:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/141612.443913:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2c162a1a7220
[1:1:0712/141612.444169:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/141612.853255:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/141614.658335:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141614.662174:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[22862:22862:0712/141614.690440:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[22862:22862:0712/141614.690532:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/141615.492330:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141615.595153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144eabe81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/141615.595495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141615.612093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144eabe81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/141615.612427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141615.851783:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141615.852076:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141616.313959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141616.321747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144eabe81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/141616.322019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141616.362019:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141616.374824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144eabe81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/141616.375129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141616.380129:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/141616.383829:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c162a1a5e20
[1:1:0712/141616.384078:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[22862:22862:0712/141616.384439:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[22862:22862:0712/141616.392192:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[22862:22862:0712/141616.419979:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[22862:22862:0712/141616.420131:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/141616.489211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141616.889359:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7fe9e63022e0 0x2c162a4504e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141616.890780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144eabe81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/141616.891052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141616.892016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[22862:22862:0712/141616.961980:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/141616.962290:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2c162a1a6820
[1:1:0712/141616.962523:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[22862:22862:0712/141616.967865:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/141616.975010:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/141616.975275:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[22862:22862:0712/141616.984578:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[22862:22862:0712/141616.995851:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22862:22862:0712/141616.996878:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22862:22874:0712/141617.002991:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[22862:22874:0712/141617.003080:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[22862:22862:0712/141617.003238:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[22862:22862:0712/141617.003315:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[22862:22862:0712/141617.003450:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,22915, 4
[1:7:0712/141617.006686:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/141617.452710:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/141617.793790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fe9e63022e0 0x2c162a4550e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141617.794883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144eabe81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/141617.795168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141617.796032:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[22862:22862:0712/141618.015168:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[22862:22862:0712/141618.015322:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/141618.045333:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141618.392077:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141618.803032:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141618.803333:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[22862:22862:0712/141618.907928:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[22862:22893:0712/141618.908417:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/141618.908608:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/141618.908889:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/141618.909293:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/141618.909437:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/141618.912684:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2a8164c2, 1
[1:1:0712/141618.913110:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x31d557cd, 0
[1:1:0712/141618.913348:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10c6618a, 3
[1:1:0712/141618.913528:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1227fe4e, 2
[1:1:0712/141618.913733:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcd57ffffffd531 ffffffc264ffffff812a 4efffffffe2712 ffffff8a61ffffffc610 , 10104, 5
[1:1:0712/141618.915019:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[22862:22893:0712/141618.915331:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�W�1�d�*N�'�a���
[22862:22893:0712/141618.915416:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �W�1�d�*N�'�a�hr��
[1:1:0712/141618.915553:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe9fa8d90a0, 3
[22862:22893:0712/141618.915687:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 22962, 5, cd57d531 c264812a 4efe2712 8a61c610 
[1:1:0712/141618.915779:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe9faa64080, 2
[1:1:0712/141618.916050:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe9e4727d20, -2
[1:1:0712/141618.927793:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/141618.928009:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1227fe4e
[1:1:0712/141618.928225:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1227fe4e
[1:1:0712/141618.928497:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1227fe4e
[1:1:0712/141618.928943:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.929055:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.929165:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.929278:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.929514:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1227fe4e
[1:1:0712/141618.929646:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe9fc69e7ba
[1:1:0712/141618.929723:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe9fc695def, 7fe9fc69e77a, 7fe9fc6a00cf
[1:1:0712/141618.931191:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1227fe4e
[1:1:0712/141618.931360:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1227fe4e
[1:1:0712/141618.931626:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1227fe4e
[1:1:0712/141618.932375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.932496:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.932591:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.932687:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1227fe4e
[1:1:0712/141618.933127:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1227fe4e
[1:1:0712/141618.933321:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe9fc69e7ba
[1:1:0712/141618.933406:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe9fc695def, 7fe9fc69e77a, 7fe9fc6a00cf
[1:1:0712/141618.935594:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/141618.935950:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/141618.936051:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffddae68248, 0x7ffddae681c8)
[1:1:0712/141618.952239:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/141618.959362:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/141619.170777:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c162a177220
[1:1:0712/141619.171033:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/141619.291954:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/141619.296693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144eabfae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/141619.297017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/141619.304878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[22862:22862:0712/141619.789572:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22862:22862:0712/141619.794807:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22862:22874:0712/141619.827004:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[22862:22874:0712/141619.827106:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[22862:22862:0712/141619.827667:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://news.taoche.com/
[22862:22862:0712/141619.827775:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://news.taoche.com/, http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml, 1
[22862:22862:0712/141619.827941:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://news.taoche.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 21:16:19 GMT Content-Type: text/html Content-Length: 27447 Server: Tengine Cache-Control: max-age=600 Content-Encoding: gzip swebs: 3.31 X-Via: 1.1 sx56:6 (Cdn Cache Server V2.0), 1.1 PSjsycsx3ke161:2 (Cdn Cache Server V2.0), 1.1 idong213:8 (Cdn Cache Server V2.0) Connection: keep-alive  ,22962, 5
[1:7:0712/141619.831440:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/141619.862080:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://news.taoche.com/
[22862:22862:0712/141619.962151:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://news.taoche.com/, http://news.taoche.com/, 1
[22862:22862:0712/141619.962213:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://news.taoche.com/, http://news.taoche.com
[1:1:0712/141620.026773:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141620.128325:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141620.152587:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141620.172442:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141620.172659:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/141621.401126:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141621.401806:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141621.402181:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141621.402588:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141621.403015:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141624.769625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 402 0x7fe9e43da070 0x2c162a4421e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141624.771815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , 
        var nid = "5cb45b5c0aa4335bac9298e8";
        var newsid = "142415";
        var NcEnglishA
[1:1:0712/141624.772014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141624.889948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 402 0x7fe9e43da070 0x2c162a4421e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141624.892803:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141625.056464:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.282791, 160, 1
[1:1:0712/141625.056747:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141625.342295:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141625.342578:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141625.346416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fe9e43da070 0x2c162a6933e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141625.348159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , !function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==t
[1:1:0712/141625.348419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141625.359633:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fe9e43da070 0x2c162a6933e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141625.463942:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2b852cb829c8, 0x2c1629fe1218
[1:1:0712/141625.464221:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", 5000
[1:1:0712/141625.464733:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.taoche.com/, 427
[1:1:0712/141625.464999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 427 0x7fe9e43da070 0x2c1629ad9d60 , 5:3_http://news.taoche.com/, 1, -5:3_http://news.taoche.com/, 416 0x7fe9e43da070 0x2c162a6933e0 
[1:1:0712/141625.657655:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.31489, 1393, 1
[1:1:0712/141625.657968:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141626.061982:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141626.062199:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141626.062703:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7fe9e43da070 0x2c162a7884e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141626.063423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , 
        $(function () {
            /*返回顶部*/
            $("#gotoTop").click(function () {

[1:1:0712/141626.063540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141626.067010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7fe9e43da070 0x2c162a7884e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141626.069098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7fe9e43da070 0x2c162a7884e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141626.099552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7fe9e43da070 0x2c162a7884e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141626.627391:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", 1000
[1:1:0712/141626.627939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 463
[1:1:0712/141626.628177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 463 0x7fe9e43da070 0x2c162aae40e0 , 5:3_http://news.taoche.com/, 1, -5:3_http://news.taoche.com/, 444 0x7fe9e43da070 0x2c162a7884e0 
[1:1:0712/141626.860079:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.797972, 4, 0
[1:1:0712/141626.860405:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141627.167322:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.168214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete 
[1:1:0712/141627.168408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141627.169082:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.171981:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.172915:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1da01d2358b0
[1:1:0712/141627.355034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.356066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete 
[1:1:0712/141627.356294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141627.356928:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.357845:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1da01d2358b0
[1:1:0712/141627.406427:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141627.406702:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.410468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7fe9e43da070 0x2c162abd1360 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.411507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , 
$('.carlife-recommend').hide();
$.selectul = function (options) { var opt = { cid: 0, timeout: 10
[1:1:0712/141627.411753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141627.768041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7fe9e43da070 0x2c162abd1360 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.887943:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.481058, 1030, 1
[1:1:0712/141627.888274:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141627.940530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.941425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete 
[1:1:0712/141627.941662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141627.942418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.945291:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141627.946044:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1da01d2358b0
[1:1:0712/141628.048485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7fe9e63022e0 0x2c162ab38ee0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.049693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , Taoche.DynamicFunc.CB__A0({"Islogin":false,"UserName":"","LoanUserID":"","Telphone":"","HashTelphone
[1:1:0712/141628.049923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141628.053800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.138560:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.139424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete 
[1:1:0712/141628.139655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141628.140461:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.143153:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.143896:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1da01d2358b0
[1:1:0712/141628.250789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.251694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete 
[1:1:0712/141628.251953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141628.252666:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.255389:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141628.256153:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1da01d2358b0
[1:1:0712/141629.019499:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141629.019859:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141629.020876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 513 0x7fe9e43da070 0x2c162ad28560 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141629.022218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , 
        $(function () {
            //品牌大写字符
            $('#seoFirstLetter a').click(f
[1:1:0712/141629.022444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141629.044350:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141631.673085:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x2b852cb829c8, 0x2c1629fe1210
[1:1:0712/141631.673364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", 300
[1:1:0712/141631.673925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.taoche.com/, 565
[1:1:0712/141631.674168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7fe9e43da070 0x2c162a2809e0 , 5:3_http://news.taoche.com/, 1, -5:3_http://news.taoche.com/, 513 0x7fe9e43da070 0x2c162ad28560 
[1:1:0712/141631.675172:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2b852cb829c8, 0x2c1629fe1210
[1:1:0712/141631.675380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", 0
[1:1:0712/141631.675830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.taoche.com/, 566
[1:1:0712/141631.676160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7fe9e43da070 0x2c162ae1a260 , 5:3_http://news.taoche.com/, 1, -5:3_http://news.taoche.com/, 513 0x7fe9e43da070 0x2c162ad28560 
		remove user.f_a3314290 -> 0
[1:1:0712/141640.158462:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[22862:22862:0712/141648.964283:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/141648.975661:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/141651.143618:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141651.144044:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141651.144416:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141651.144772:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[22862:22862:0712/141707.741060:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml (0)
[1:1:0712/141707.757663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 463, 7fe9e6d1f8db
[1:1:0712/141707.782160:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2629c4f22860","ptid":"444 0x7fe9e43da070 0x2c162a7884e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141707.782490:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.taoche.com/","ptid":"444 0x7fe9e43da070 0x2c162a7884e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141707.782985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 616
[1:1:0712/141707.783213:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7fe9e43da070 0x2c162ac81fe0 , 5:3_http://news.taoche.com/, 0, , 463 0x7fe9e43da070 0x2c162aae40e0 
[1:1:0712/141707.783510:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141707.784465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , replaceHref()
[1:1:0712/141707.784683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141709.727186:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553 0x7fe9e63022e0 0x2c162ad98ae0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141709.729263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , !function(){function Beacon(){this.initOption=util.extend({clk:!0,pv:!0,exp:!1,scrollTarget:document
[1:1:0712/141709.729496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141709.880747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554 0x7fe9e63022e0 0x2c162acc44e0 , "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141709.882929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , $(function () {
 
});
function dowork()
{
    vipcarview(this.document.body);
   // recarview(this.d
[1:1:0712/141709.883164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141709.886842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141710.121860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/141710.122154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[22862:22862:0712/141710.838577:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/141711.308586:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.taoche.com/, 427, 7fe9e6d1f881
[1:1:0712/141711.338888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2629c4f22860","ptid":"416 0x7fe9e43da070 0x2c162a6933e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.339198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.taoche.com/","ptid":"416 0x7fe9e43da070 0x2c162a6933e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.339587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141711.340245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , (){n.User.isInit||(n.User.isInit=!0,n.User.trigCbs())}
[1:1:0712/141711.340427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141711.373554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.taoche.com/, 566, 7fe9e6d1f881
[1:1:0712/141711.403581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2629c4f22860","ptid":"513 0x7fe9e43da070 0x2c162ad28560 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.403938:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.taoche.com/","ptid":"513 0x7fe9e43da070 0x2c162ad28560 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.404342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141711.405047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , (){var t="placeholder"in document.createElement("input");e.SearchBox.render({inputEle:"#tc_search_tx
[1:1:0712/141711.405260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141711.468179:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://news.taoche.com/, 565, 7fe9e6d1f881
[1:1:0712/141711.498916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2629c4f22860","ptid":"513 0x7fe9e43da070 0x2c162ad28560 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.499233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://news.taoche.com/","ptid":"513 0x7fe9e43da070 0x2c162ad28560 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.499644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141711.500308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , (){t.initCitySelect(),t.initYixinSearchBox(),t.initMenu(),$(".search").find(".sel-car-wrapper").hide
[1:1:0712/141711.500488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141711.757487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 616, 7fe9e6d1f8db
[1:1:0712/141711.766547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"463 0x7fe9e43da070 0x2c162aae40e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.766680:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"463 0x7fe9e43da070 0x2c162aae40e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141711.766917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 691
[1:1:0712/141711.767031:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7fe9e43da070 0x2c163865afe0 , 5:3_http://news.taoche.com/, 0, , 616 0x7fe9e43da070 0x2c162ac81fe0 
[1:1:0712/141711.767170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141711.767523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , replaceHref()
[1:1:0712/141711.767629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
		remove user.11_7bcf829b -> 0
		remove user.12_46c0224b -> 0
		remove user.13_59bb2894 -> 0
		remove user.14_1c1dfedf -> 0
[22862:22862:0712/141713.638121:INFO:CONSOLE(0)] "This page includes a password or credit card input in a non-secure context. A warning has been added to the URL bar. For more information, see https://goo.gl/zmWq3m.", source: http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml (0)
[1:1:0712/141713.642459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , document.readyState
[1:1:0712/141713.642634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141714.779448:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 691, 7fe9e6d1f8db
[1:1:0712/141714.810867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"616 0x7fe9e43da070 0x2c162ac81fe0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141714.811156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"616 0x7fe9e43da070 0x2c162ac81fe0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141714.811569:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 742
[1:1:0712/141714.811774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7fe9e43da070 0x2c162ac8cb60 , 5:3_http://news.taoche.com/, 0, , 691 0x7fe9e43da070 0x2c163865afe0 
[1:1:0712/141714.812038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141714.812724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , replaceHref()
[1:1:0712/141714.812908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141716.763166:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141716.763962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , ready, (a){if(a===!0?--p.readyWait:p.isReady)return;if(!e.body)return setTimeout(p.ready,1);p.isReady=!0;if
[1:1:0712/141716.764188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141717.026800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , document.readyState
[1:1:0712/141717.027148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141718.101996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 742, 7fe9e6d1f8db
[1:1:0712/141718.111533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"691 0x7fe9e43da070 0x2c163865afe0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141718.111670:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"691 0x7fe9e43da070 0x2c163865afe0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141718.111893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 767
[1:1:0712/141718.112008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 767 0x7fe9e43da070 0x2c163199a8e0 , 5:3_http://news.taoche.com/, 0, , 742 0x7fe9e43da070 0x2c162ac8cb60 
[1:1:0712/141718.112146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141718.112550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , replaceHref()
[1:1:0712/141718.112659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141719.986789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 767, 7fe9e6d1f8db
[1:1:0712/141720.020176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"742 0x7fe9e43da070 0x2c162ac8cb60 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141720.020450:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"742 0x7fe9e43da070 0x2c162ac8cb60 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141720.020836:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 788
[1:1:0712/141720.021044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7fe9e43da070 0x2c1639933c60 , 5:3_http://news.taoche.com/, 0, , 767 0x7fe9e43da070 0x2c163199a8e0 
[1:1:0712/141720.021332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141720.022010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , replaceHref()
[1:1:0712/141720.022196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
[1:1:0712/141721.192814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 788, 7fe9e6d1f8db
[1:1:0712/141721.202522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"767 0x7fe9e43da070 0x2c163199a8e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141721.202654:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"767 0x7fe9e43da070 0x2c163199a8e0 ","rf":"5:3_http://news.taoche.com/"}
[1:1:0712/141721.202842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://news.taoche.com/, 795
[1:1:0712/141721.202947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7fe9e43da070 0x2c163a479060 , 5:3_http://news.taoche.com/, 0, , 788 0x7fe9e43da070 0x2c1639933c60 
[1:1:0712/141721.203088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml"
[1:1:0712/141721.203458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://news.taoche.com/, 2629c4f22860, , , replaceHref()
[1:1:0712/141721.203573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.taoche.com/newscate/imgtext/2019-04/142415.shtml", "news.taoche.com", 3, 1, , , 0
