[0712/112906.392179:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112906.392436:INFO:switcher_clone.cc(787)] backtrace rip is 7fdc4703f891
[0712/112907.394075:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112907.394465:INFO:switcher_clone.cc(787)] backtrace rip is 7f6e51052891
[1:1:0712/112907.406252:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/112907.406522:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/112907.411968:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[2741:2741:0712/112908.988690:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/112909.037937:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112909.038446:INFO:switcher_clone.cc(787)] backtrace rip is 7fe02a5b5891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4c94cf36-7608-47ad-bd95-3465d534f29f
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[2773:2773:0712/112909.260742:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2773
[2785:2785:0712/112909.261235:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2785
[2741:2741:0712/112909.633758:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[2741:2770:0712/112909.635210:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/112909.635594:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/112909.635904:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/112909.636509:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/112909.636662:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/112909.639595:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x12775ded, 1
[1:1:0712/112909.639913:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3f966158, 0
[1:1:0712/112909.640089:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3907b747, 3
[1:1:0712/112909.640321:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e3ddc11, 2
[1:1:0712/112909.640516:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5861ffffff963f ffffffed5d7712 11ffffffdc3d1e 47ffffffb70739 , 10104, 4
[1:1:0712/112909.641476:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2741:2770:0712/112909.641739:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGXa�?�]w�=G�9p&{0
[1:1:0712/112909.641696:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e4f28d0a0, 3
[2741:2770:0712/112909.641862:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Xa�?�]w�=G�9h�p&{0
[1:1:0712/112909.641917:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e4f418080, 2
[1:1:0712/112909.642070:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e390dbd20, -2
[2741:2770:0712/112909.642230:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[2741:2770:0712/112909.642299:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2793, 4, 5861963f ed5d7712 11dc3d1e 47b70739 
[1:1:0712/112909.663022:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/112909.664144:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e3ddc11
[1:1:0712/112909.665330:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e3ddc11
[1:1:0712/112909.667335:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e3ddc11
[1:1:0712/112909.668924:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.669154:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.669350:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.669532:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.670243:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e3ddc11
[1:1:0712/112909.670556:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e510527ba
[1:1:0712/112909.670688:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e51049def, 7f6e5105277a, 7f6e510540cf
[1:1:0712/112909.676439:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e3ddc11
[1:1:0712/112909.676779:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e3ddc11
[1:1:0712/112909.677515:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e3ddc11
[1:1:0712/112909.679526:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.679734:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.679919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.680105:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e3ddc11
[1:1:0712/112909.681392:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e3ddc11
[1:1:0712/112909.681749:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e510527ba
[1:1:0712/112909.681900:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e51049def, 7f6e5105277a, 7f6e510540cf
[1:1:0712/112909.687871:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/112909.688145:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/112909.688236:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffffb6981d8, 0x7ffffb698158)
[1:1:0712/112909.703283:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/112909.709196:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[2741:2741:0712/112910.256525:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2741:2741:0712/112910.257039:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2741:2752:0712/112910.269581:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[2741:2752:0712/112910.269686:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[2741:2741:0712/112910.269929:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[2741:2741:0712/112910.270025:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[2741:2741:0712/112910.270197:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,2793, 4
[1:7:0712/112910.275296:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112910.336099:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x220bac427220
[1:1:0712/112910.336375:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[2741:2765:0712/112910.352948:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/112910.687293:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[2741:2741:0712/112912.451818:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[2741:2741:0712/112912.451894:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/112912.521077:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112912.526044:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112913.298777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e518761f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/112913.299094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112913.329265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e518761f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/112913.329543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112913.409677:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112913.783729:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112913.784057:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112914.246848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112914.254544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e518761f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/112914.254782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112914.287666:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112914.297644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e518761f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/112914.297875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112914.309067:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[2741:2741:0712/112914.310203:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/112914.312301:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x220bac425e20
[1:1:0712/112914.312889:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[2741:2741:0712/112914.322071:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[2741:2741:0712/112914.341094:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[2741:2741:0712/112914.341240:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/112914.374087:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112915.298489:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f6e3acb62e0 0x220bac647760 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112915.299906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e518761f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/112915.300217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112915.301820:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2741:2741:0712/112915.339306:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/112915.340851:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x220bac426820
[1:1:0712/112915.341090:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[2741:2741:0712/112915.350657:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/112915.353740:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/112915.353979:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[2741:2741:0712/112915.367606:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[2741:2741:0712/112915.378239:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2741:2741:0712/112915.379228:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2741:2752:0712/112915.385831:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[2741:2752:0712/112915.385918:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[2741:2741:0712/112915.386157:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[2741:2741:0712/112915.386267:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[2741:2741:0712/112915.386443:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,2793, 4
[1:7:0712/112915.398877:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112915.995076:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/112916.529564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f6e3acb62e0 0x220bac63ca60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112916.530535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e518761f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/112916.530778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112916.531528:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2741:2741:0712/112916.704280:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[2741:2741:0712/112916.704341:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/112916.719258:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[2741:2741:0712/112916.829980:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[2741:2770:0712/112916.830364:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/112916.830567:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/112916.830820:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/112916.831090:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/112916.831226:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/112916.834198:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x281f30f0, 1
[1:1:0712/112916.834627:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x229fee16, 0
[1:1:0712/112916.834870:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xe8fb38e, 3
[1:1:0712/112916.835081:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x25850d47, 2
[1:1:0712/112916.835270:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 16ffffffeeffffff9f22 fffffff0301f28 470dffffff8525 ffffff8effffffb3ffffff8f0e , 10104, 5
[1:1:0712/112916.836347:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2741:2770:0712/112916.836628:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�"�0(G�%���	){0
[2741:2770:0712/112916.836704:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �"�0(G�%����	){0
[1:1:0712/112916.836819:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e4f28d0a0, 3
[2741:2770:0712/112916.836986:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2839, 5, 16ee9f22 f0301f28 470d8525 8eb38f0e 
[1:1:0712/112916.837045:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e4f418080, 2
[1:1:0712/112916.837289:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e390dbd20, -2
[1:1:0712/112916.859958:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/112916.860394:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 25850d47
[1:1:0712/112916.860785:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 25850d47
[1:1:0712/112916.861449:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 25850d47
[1:1:0712/112916.862890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.863135:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.863365:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.863620:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.864355:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 25850d47
[1:1:0712/112916.864697:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e510527ba
[1:1:0712/112916.864881:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e51049def, 7f6e5105277a, 7f6e510540cf
[1:1:0712/112916.867612:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 25850d47
[1:1:0712/112916.868018:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 25850d47
[1:1:0712/112916.868791:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 25850d47
[1:1:0712/112916.870845:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.871094:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.871321:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.871624:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25850d47
[1:1:0712/112916.873143:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 25850d47
[1:1:0712/112916.873604:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e510527ba
[1:1:0712/112916.873801:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e51049def, 7f6e5105277a, 7f6e510540cf
[1:1:0712/112916.881150:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/112916.881667:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/112916.881858:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffffb6981d8, 0x7ffffb698158)
[1:1:0712/112916.895930:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/112916.900159:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/112917.157575:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112917.190070:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x220bac3f7220
[1:1:0712/112917.190343:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/112917.830185:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112917.830512:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[2741:2741:0712/112917.940256:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2741:2741:0712/112917.970705:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[2741:2770:0712/112917.971118:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/112917.971336:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/112917.971580:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/112917.972110:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/112917.972301:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/112917.975719:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3303a58b, 1
[1:1:0712/112917.976096:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2beed35c, 0
[1:1:0712/112917.976333:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d83b6a1, 3
[1:1:0712/112917.976518:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3bfa638, 2
[1:1:0712/112917.976701:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5cffffffd3ffffffee2b ffffff8bffffffa50333 38ffffffa6ffffffbf03 ffffffa1ffffffb6ffffff832d , 10104, 6
[1:1:0712/112917.977713:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2741:2770:0712/112917.978037:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING\��+��38�����-d'{0
[2741:2770:0712/112917.978106:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is \��+��38�����-|d'{0
[1:1:0712/112917.978219:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e4f28d0a0, 3
[1:1:0712/112917.978458:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e4f418080, 2
[2741:2770:0712/112917.978519:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2854, 6, 5cd3ee2b 8ba50333 38a6bf03 a1b6832d 
[1:1:0712/112917.978629:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e390dbd20, -2
[1:1:0712/112918.002489:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/112918.002830:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3bfa638
[1:1:0712/112918.003101:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3bfa638
[1:1:0712/112918.003679:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3bfa638
[1:1:0712/112918.005236:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[1:1:0712/112918.005471:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[1:1:0712/112918.005712:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[1:1:0712/112918.005953:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[1:1:0712/112918.006744:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3bfa638
[1:1:0712/112918.007107:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e510527ba
[1:1:0712/112918.007270:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e51049def, 7f6e5105277a, 7f6e510540cf
[1:1:0712/112918.014256:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3bfa638
[1:1:0712/112918.014745:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3bfa638
[1:1:0712/112918.015654:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3bfa638
[1:1:0712/112918.018229:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[2741:2741:0712/112918.018443:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/112918.018498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[1:1:0712/112918.018725:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[1:1:0712/112918.018983:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bfa638
[1:1:0712/112918.020514:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3bfa638
[1:1:0712/112918.020986:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e510527ba
[1:1:0712/112918.021178:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e51049def, 7f6e5105277a, 7f6e510540cf
[1:1:0712/112918.030597:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/112918.031164:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/112918.031376:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffffb6981d8, 0x7ffffb698158)
[1:1:0712/112918.047558:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/112918.052898:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[2741:2752:0712/112918.055110:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[2741:2752:0712/112918.055196:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[2741:2741:0712/112918.055295:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://passport2.eastmoney.com/
[2741:2741:0712/112918.055345:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://passport2.eastmoney.com/, https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F, 1
[2741:2741:0712/112918.055413:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://passport2.eastmoney.com/, HTTP/1.1 200 OK Server: Microsoft-IIS/9.0 Date: Fri, 12 Jul 2019 18:29:17 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Cache-Control: private X-AspNetMvc-Version: 5.2 X-AspNet-Version: 4.0.30319 X-Powered-By: ASP.NET Content-Encoding: gzip  ,0, 6
[3:3:0712/112918.057331:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/112918.133918:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112918.274873:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112918.279805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 38e51888e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/112918.280167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112918.284369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112918.289828:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x220bac441220
[1:1:0712/112918.290043:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/112918.361441:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://passport2.eastmoney.com/
[2741:2741:0712/112918.589600:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://passport2.eastmoney.com/, https://passport2.eastmoney.com/, 1
[2741:2741:0712/112918.589658:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://passport2.eastmoney.com/, https://passport2.eastmoney.com
[1:1:0712/112918.639020:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112918.803423:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112918.821653:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112918.822444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e518761f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/112918.822676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112918.952334:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112918.952602:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112919.012058:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/112919.028938:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x220bac526820
[1:1:0712/112919.029182:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/112919.086483:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.133522, 242, 1
[1:1:0712/112919.086752:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112919.260203:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112919.260457:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112919.508658:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168, "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112919.513868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , /*
 RequireJS 2.1.15 Copyright (c) 2010-2014, The Dojo Foundation All Rights Reserved.
 Available vi
[1:1:0712/112919.514067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112919.516452:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112919.528355:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x2578a06a29c8, 0x220bac2ba1a8
[1:1:0712/112919.528541:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", 4
[1:1:0712/112919.528842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 191
[1:1:0712/112919.528993:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 191 0x7f6e38d8e070 0x220bac62b7e0 , 6:3_https://passport2.eastmoney.com/, 1, -6:3_https://passport2.eastmoney.com/, 168
[1:1:0712/112919.538425:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x2578a06a29c8, 0x220bac2ba1a8
[1:1:0712/112919.538597:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", 4
[1:1:0712/112919.538885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 192
[1:1:0712/112919.539034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 192 0x7f6e38d8e070 0x220bac537060 , 6:3_https://passport2.eastmoney.com/, 1, -6:3_https://passport2.eastmoney.com/, 168
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112919.687985:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112919.735395:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 191, 7f6e3b6d3881
[1:1:0712/112919.742588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a117c2860","ptid":"168","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112919.742832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport2.eastmoney.com/","ptid":"168","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112919.743095:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112919.743755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , (){J();q=s(p(null,a));q.skipMap=e.skipMap;q.init(c,d,m,{enabled:!0});D()}
[1:1:0712/112919.744091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112919.760393:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 192, 7f6e3b6d3881
[1:1:0712/112919.763211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a117c2860","ptid":"168","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112919.763336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport2.eastmoney.com/","ptid":"168","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112919.763468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112919.763730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , (){J();q=s(p(null,a));q.skipMap=e.skipMap;q.init(c,d,m,{enabled:!0});D()}
[1:1:0712/112919.763839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112919.868999:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f6e390f6bd0 0x220bac65a758 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112919.873753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/112919.873896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112919.997005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f6e390f6bd0 0x220bac65a758 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.000465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f6e390f6bd0 0x220bac65a758 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.019416:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x2578a06a29c8, 0x220bac2ba1a0
[1:1:0712/112920.019631:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", 4
[1:1:0712/112920.020115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 212
[1:1:0712/112920.020384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 212 0x7f6e38d8e070 0x220bac5f1260 , 6:3_https://passport2.eastmoney.com/, 1, -6:3_https://passport2.eastmoney.com/, 206 0x7f6e390f6bd0 0x220bac65a758 
[1:1:0712/112920.022871:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f6e390f6bd0 0x220bac65a758 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.030670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f6e390f6bd0 0x220bac65a758 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.033939:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x2578a06a29c8, 0x220bac2ba1b8
[1:1:0712/112920.034119:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", 4
[1:1:0712/112920.034635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 218
[1:1:0712/112920.034825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 218 0x7f6e38d8e070 0x220bac542760 , 6:3_https://passport2.eastmoney.com/, 1, -6:3_https://passport2.eastmoney.com/, 206 0x7f6e390f6bd0 0x220bac65a758 
[1:1:0712/112920.039618:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.574548:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/112920.574813:INFO:render_frame_impl.cc(7019)] 	 [url] = https://passport2.eastmoney.com
[1:1:0712/112920.733116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 212, 7f6e3b6d3881
[1:1:0712/112920.745192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a117c2860","ptid":"206 0x7f6e390f6bd0 0x220bac65a758 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112920.745442:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport2.eastmoney.com/","ptid":"206 0x7f6e390f6bd0 0x220bac65a758 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112920.745719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.746420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , (){J();q=s(p(null,a));q.skipMap=e.skipMap;q.init(c,d,m,{enabled:!0});D()}
[1:1:0712/112920.746635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112920.757799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 218, 7f6e3b6d3881
[1:1:0712/112920.768189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a117c2860","ptid":"206 0x7f6e390f6bd0 0x220bac65a758 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112920.768511:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport2.eastmoney.com/","ptid":"206 0x7f6e390f6bd0 0x220bac65a758 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112920.768790:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.769462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , (){J();q=s(p(null,a));q.skipMap=e.skipMap;q.init(c,d,m,{enabled:!0});D()}
[1:1:0712/112920.769676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112920.800722:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x2578a06a29c8, 0x220bac2ba150
[1:1:0712/112920.800989:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", 50
[1:1:0712/112920.801535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 253
[1:1:0712/112920.801809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 253 0x7f6e38d8e070 0x220bac7541e0 , 6:3_https://passport2.eastmoney.com/, 1, -6:3_https://passport2.eastmoney.com/, 218 0x7f6e38d8e070 0x220bac542760 
[1:1:0712/112920.960782:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 253, 7f6e3b6d3881
[1:1:0712/112920.966638:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a117c2860","ptid":"218 0x7f6e38d8e070 0x220bac542760 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112920.966946:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport2.eastmoney.com/","ptid":"218 0x7f6e38d8e070 0x220bac542760 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112920.967227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112920.967889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , (){X=0;D()}
[1:1:0712/112920.968106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112920.971937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x2578a06a29c8, 0x220bac2ba150
[1:1:0712/112920.972164:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", 50
[1:1:0712/112920.972671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 270
[1:1:0712/112920.972898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 270 0x7f6e38d8e070 0x220bac537060 , 6:3_https://passport2.eastmoney.com/, 1, -6:3_https://passport2.eastmoney.com/, 253 0x7f6e38d8e070 0x220bac7541e0 
[1:1:0712/112921.038128:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 264 0x7f6e3acb62e0 0x220bac5aba60 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112921.039758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , define('comCookie', function () {


    /***
    ** 功能：  cookie操作对象
    ** Author
[1:1:0712/112921.040014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112921.042363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112921.084893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7f6e3acb62e0 0x220bac5ddd60 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112921.086767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , define('common', function() {
	window.xConfig = {};

	window.xConfig.isDebug = function(){
	    
[1:1:0712/112921.086994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112921.089261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112921.120677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 268 0x7f6e3acb62e0 0x220bac746360 , "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112921.123824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , define('comFormChecker', function () {

    //验证手机
    function isPhoneNumber(_keyword) {
[1:1:0712/112921.124079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112921.126470:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112921.242963:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport2.eastmoney.com/, 270, 7f6e3b6d3881
[1:1:0712/112921.250035:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a117c2860","ptid":"253 0x7f6e38d8e070 0x220bac7541e0 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112921.250338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport2.eastmoney.com/","ptid":"253 0x7f6e38d8e070 0x220bac7541e0 ","rf":"6:3_https://passport2.eastmoney.com/"}
[1:1:0712/112921.250636:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112921.251284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , (){X=0;D()}
[1:1:0712/112921.251524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112927.252211:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112927.252921:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112927.253372:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112927.253903:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112927.254361:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112947.379942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/112947.380133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[2741:2741:0712/112947.583043:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[2741:2741:0712/112947.585312:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[2741:2741:0712/112947.593098:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://passport2.eastmoney.com/, https://passport2.eastmoney.com/, 4
[2741:2741:0712/112947.593183:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://passport2.eastmoney.com/, https://passport2.eastmoney.com
[2741:2741:0712/112947.725909:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://passport2.eastmoney.com/
[2741:2741:0712/112947.788514:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/112947.798747:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[2741:2741:0712/112947.852500:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/112948.168399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112948.168711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[2741:2741:0712/112948.779052:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2741:2741:0712/112948.786351:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2741:2752:0712/112948.824903:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[2741:2752:0712/112948.825042:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[2741:2741:0712/112948.825178:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://exaccount2.eastmoney.com/
[2741:2741:0712/112948.825260:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://exaccount2.eastmoney.com/, https://exaccount2.eastmoney.com/home/Login?rc=1659254347, 4
[2741:2741:0712/112948.825395:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://exaccount2.eastmoney.com/, HTTP/1.1 200 OK Server: Microsoft-IIS/9.0 Date: Fri, 12 Jul 2019 18:29:48 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Cache-Control: public, no-cache="Set-Cookie", max-age=3600 Expires: Fri, 12 Jul 2019 19:29:49 GMT Last-Modified: Fri, 12 Jul 2019 18:29:49 GMT Vary: * X-AspNetMvc-Version: 5.2 X-AspNet-Version: 4.0.30319 Set-Cookie: RequestData={"agentPageUrl":"https://passport2.eastmoney.com/pub/LoginAgent","redirectUrl":"http://i.eastmoney.com/","callBack":"LoginCallBack","redirectFunc":"PageRedirect","data":{"domainName":"passport.eastmoney.com","deviceType":"Web","productType":"UserPassport","version":"0.0.1"}}; domain=exaccount2.eastmoney.com; path=/ Set-Cookie: __RequestVerificationToken=2ZfTC86WTqc_gPN1A4eQrSRpz1tFKCsrjSj0SuCS66ync5HtQ6OBDXuOiRE-Axf2brTR4_trTfLlsQk02guRK6dFwXA1; path=/; HttpOnly X-Powered-By: ASP.NET Content-Encoding: gzip  ,2854, 6
[1:7:0712/112948.828611:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112948.894254:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://exaccount2.eastmoney.com/
[1:1:0712/112948.916309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112948.916584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112949.005656:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[2741:2741:0712/112949.026950:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://exaccount2.eastmoney.com/, https://exaccount2.eastmoney.com/, 4
[2741:2741:0712/112949.027076:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://exaccount2.eastmoney.com/, https://exaccount2.eastmoney.com
[1:1:0712/112949.031503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112949.031803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112949.079513:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112949.232262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112949.232582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112949.274091:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112949.274372:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112949.371001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112949.371319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112949.448790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112949.450066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112949.493002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112949.493340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112949.559471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f6e390f6bd0 0x220bac33b758 , "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112949.581416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://exaccount2.eastmoney.com/, 1f1a118e5ed8, , , /* NUGET: BEGIN LICENSE TEXT
 *
 * Microsoft grants you the right to use these script files for the 
[1:1:0712/112949.581764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", "exaccount2.eastmoney.com", 4, 1, https://passport2.eastmoney.com, passport2.eastmoney.com, 3
[1:1:0712/112949.603630:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112949.825719:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f6e390f6bd0 0x220bac33b758 , "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112949.894125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112949.894516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112950.105014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 432 0x7f6e38d8e070 0x220bac8d2960 , "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112950.106127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://exaccount2.eastmoney.com/, 1f1a118e5ed8, , , 
        var XCodeUrl = 'https://xcode2.eastmoney.com/V2/verifycode2.ashx';
        var EnableVCode 
[1:1:0712/112950.106418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", "exaccount2.eastmoney.com", 4, 1, https://passport2.eastmoney.com, passport2.eastmoney.com, 3
[1:1:0712/112950.241511:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[2741:2741:0712/112950.368705:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/112950.370759:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x220bac43e020
[1:1:0712/112950.370996:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[2741:2741:0712/112950.376036:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/112950.437612:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.329692, 623, 1
[1:1:0712/112950.437891:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[2741:2741:0712/112950.445487:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://exaccount2.eastmoney.com/, https://exaccount2.eastmoney.com/, 5
[2741:2741:0712/112950.445671:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://exaccount2.eastmoney.com/, https://exaccount2.eastmoney.com
[1:1:0712/112950.569913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112950.570229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112951.764084:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112951.764363:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112951.947152:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483, "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112951.949351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://exaccount2.eastmoney.com/, 1f1a118e5ed8, , , !function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};ret
[1:1:0712/112951.949682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", "exaccount2.eastmoney.com", 4, 1, https://passport2.eastmoney.com, passport2.eastmoney.com, 3
[1:1:0712/112952.235526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112952.235926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112953.320495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112953.320783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112953.751281:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7f6e390f6bd0 0x220bac8cc6d8 , "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112953.757436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://exaccount2.eastmoney.com/, 1f1a118e5ed8, , , !function(n){var e={};function t(r){if(e[r])return e[r].exports;var i=e[r]={i:r,l:!1,exports:{}};ret
[1:1:0712/112953.757730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", "exaccount2.eastmoney.com", 4, 1, https://passport2.eastmoney.com, passport2.eastmoney.com, 3
[1:1:0712/112953.849790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7f6e390f6bd0 0x220bac8cc6d8 , "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112953.861791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7f6e390f6bd0 0x220bac8cc6d8 , "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112953.897102:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7f6e390f6bd0 0x220bac8cc6d8 , "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112954.186748:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112954.187308:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112954.521430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2578a06b4ef8, 0x220bac2ba1f0
[1:1:0712/112954.521731:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", 1
[1:1:0712/112954.522252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://exaccount2.eastmoney.com/, 599
[1:1:0712/112954.522520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 599 0x7f6e38d8e070 0x220bad7175e0 , 6:4_https://exaccount2.eastmoney.com/, 1, -6:4_https://exaccount2.eastmoney.com/, 575 0x7f6e390f6bd0 0x220bac8cc6d8 
[1:1:0712/112954.524851:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.678671, 0, 0
[1:1:0712/112954.525124:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112954.575246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/112954.575598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/112955.253928:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112955.254197:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112955.258888:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112955.260665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://exaccount2.eastmoney.com/, 1f1a118e5ed8, , q, (e){(a.addEventListener||"load"===e.type||"complete"===a.readyState)&&(_(),x.ready())}
[1:1:0712/112955.260942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", "exaccount2.eastmoney.com", 4, 1, https://passport2.eastmoney.com, passport2.eastmoney.com, 3
[2741:2741:0712/112956.127468:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://exaccount2.eastmoney.com/home/Login?rc=1659254347 (0)
[2741:2741:0712/112956.132109:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "new-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://exaccount2.eastmoney.com/home/Login?rc=1659254347 (0)
[2741:2741:0712/112956.133924:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "new-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://exaccount2.eastmoney.com/home/Login?rc=1659254347 (0)
[1:1:0712/112956.177583:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F"
[1:1:0712/112956.178451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -6:4_https://exaccount2.eastmoney.com/-6:3_https://passport2.eastmoney.com/, 1f1a117c2860, 1f1a118e5ed8, ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0712/112956.178693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 2, , , 0
[1:1:0712/112956.179174:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/112956.215029:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://exaccount2.eastmoney.com/, 599, 7f6e3b6d3881
[1:1:0712/112956.227758:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a118e5ed8","ptid":"575 0x7f6e390f6bd0 0x220bac8cc6d8 ","rf":"6:4_https://exaccount2.eastmoney.com/"}
[1:1:0712/112956.228141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:4_https://exaccount2.eastmoney.com/","ptid":"575 0x7f6e390f6bd0 0x220bac8cc6d8 ","rf":"6:4_https://exaccount2.eastmoney.com/"}
[1:1:0712/112956.229101:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/112956.230132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://exaccount2.eastmoney.com/, 1f1a118e5ed8, , , (){var r=["monospace","sans-serif","serif"],i=["Andale Mono","Arial","Arial Black","Arial Hebrew","A
[1:1:0712/112956.230367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", "exaccount2.eastmoney.com", 4, 1, https://passport2.eastmoney.com, passport2.eastmoney.com, 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
		remove user.11_42e7986d -> 0
		remove user.12_b4af3f19 -> 0
		remove user.13_ceb5b828 -> 0
[1:1:0712/112957.879875:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113002.366439:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113002.367030:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113006.658516:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2578a06b4ef8, 0x220bac2ba150
[1:1:0712/113006.658827:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", 2000
[1:1:0712/113006.659285:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://exaccount2.eastmoney.com/, 640
[1:1:0712/113006.659516:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7f6e38d8e070 0x220bb152a8e0 , 6:4_https://exaccount2.eastmoney.com/, 1, -6:4_https://exaccount2.eastmoney.com/, 599 0x7f6e38d8e070 0x220bad7175e0 
[1:1:0712/113006.737981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport2.eastmoney.com/, 1f1a117c2860, , , document.readyState
[1:1:0712/113006.738293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport2.eastmoney.com/pub/login?backurl=http%3A%2F%2Fi.eastmoney.com%2F", "passport2.eastmoney.com", 3, 1, , , 0
[1:1:0712/113007.427065:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","https://passport2.eastmoney.com/favicon.ico"
[1:1:0712/113008.690751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://exaccount2.eastmoney.com/, 640, 7f6e3b6d3881
[1:1:0712/113008.709136:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f1a118e5ed8","ptid":"599 0x7f6e38d8e070 0x220bad7175e0 ","rf":"6:4_https://exaccount2.eastmoney.com/"}
[1:1:0712/113008.709517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:4_https://exaccount2.eastmoney.com/","ptid":"599 0x7f6e38d8e070 0x220bad7175e0 ","rf":"6:4_https://exaccount2.eastmoney.com/"}
[1:1:0712/113008.709941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://exaccount2.eastmoney.com/home/Login?rc=1659254347"
[1:1:0712/113008.710632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://exaccount2.eastmoney.com/, 1f1a118e5ed8, , , (){document.body.removeChild(t)}
[1:1:0712/113008.710923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://exaccount2.eastmoney.com/home/Login?rc=1659254347", "exaccount2.eastmoney.com", 4, 1, https://passport2.eastmoney.com, passport2.eastmoney.com, 3
[2741:2741:0712/113013.225254:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
