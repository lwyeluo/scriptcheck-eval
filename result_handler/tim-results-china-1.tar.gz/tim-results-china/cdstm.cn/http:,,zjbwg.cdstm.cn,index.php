[0711/102506.325833:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/102506.326101:INFO:switcher_clone.cc(787)] backtrace rip is 7f7ffc6bf891
[0711/102507.320530:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/102507.320936:INFO:switcher_clone.cc(787)] backtrace rip is 7feafd02b891
[1:1:0711/102507.325243:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/102507.325437:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/102507.330376:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[39580:39580:0711/102508.359777:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/b35ec17a-08d7-44a6-ba87-e831b05aef5b
[0711/102508.629740:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/102508.630106:INFO:switcher_clone.cc(787)] backtrace rip is 7efc7f396891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[39580:39580:0711/102508.763059:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[39580:39610:0711/102508.763781:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/102508.764011:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/102508.764253:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/102508.764855:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/102508.765025:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/102508.767887:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xc1b11dd, 1
[1:1:0711/102508.768262:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x105b87da, 0
[1:1:0711/102508.768444:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x216df74b, 3
[1:1:0711/102508.768601:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x17377c77, 2
[1:1:0711/102508.768794:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdaffffff875b10 ffffffdd111b0c 777c3717 4bfffffff76d21 , 10104, 4
[1:1:0711/102508.769736:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[39580:39610:0711/102508.770054:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGڇ[�w|7K�m!<�)+
[39580:39610:0711/102508.770133:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ڇ[�w|7K�m!�0<�)+
[1:1:0711/102508.770026:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feafb2660a0, 3
[1:1:0711/102508.770314:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feafb3f1080, 2
[1:1:0711/102508.770495:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feae50b4d20, -2
[39580:39610:0711/102508.770887:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[39580:39610:0711/102508.771168:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 39625, 4, da875b10 dd111b0c 777c3717 4bf76d21 
[1:1:0711/102508.792522:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/102508.793400:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 17377c77
[1:1:0711/102508.794345:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 17377c77
[1:1:0711/102508.795945:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 17377c77
[1:1:0711/102508.797852:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.798091:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.798341:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.798568:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.799408:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 17377c77
[1:1:0711/102508.799802:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feafd02b7ba
[1:1:0711/102508.800006:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feafd022def, 7feafd02b77a, 7feafd02d0cf
[1:1:0711/102508.807152:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 17377c77
[1:1:0711/102508.807582:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 17377c77
[1:1:0711/102508.808503:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 17377c77
[1:1:0711/102508.811049:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.811243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.811433:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.811614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17377c77
[1:1:0711/102508.812876:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 17377c77
[1:1:0711/102508.813231:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feafd02b7ba
[1:1:0711/102508.813365:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feafd022def, 7feafd02b77a, 7feafd02d0cf
[1:1:0711/102508.821575:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/102508.821988:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/102508.822142:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc30121c88, 0x7ffc30121c08)
[1:1:0711/102508.836777:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/102508.843044:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[39612:39612:0711/102508.847687:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=39612
[39633:39633:0711/102508.851428:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=39633
[39580:39580:0711/102509.223253:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39580:39580:0711/102509.223675:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[39580:39591:0711/102509.237666:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[39580:39591:0711/102509.237763:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[39580:39580:0711/102509.237803:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[39580:39580:0711/102509.237906:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[39580:39580:0711/102509.238110:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,39625, 4
[1:7:0711/102509.241161:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[39580:39603:0711/102509.302704:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/102509.364591:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x4764a780220
[1:1:0711/102509.364822:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/102509.627087:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[39580:39580:0711/102511.105304:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[39580:39580:0711/102511.105408:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/102511.117355:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/102511.120853:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/102512.080292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a519ba61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/102512.080736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/102512.097266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a519ba61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/102512.097627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/102512.143596:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/102512.311294:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/102512.311586:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[39580:39580:0711/102512.439452:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[39580:39610:0711/102512.439781:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/102512.439934:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/102512.440161:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/102512.440533:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/102512.440666:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/102512.446621:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3327c35c, 1
[1:1:0711/102512.447032:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1d82b010, 0
[1:1:0711/102512.447187:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26d07294, 3
[1:1:0711/102512.447338:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2daf9217, 2
[1:1:0711/102512.447497:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 10ffffffb0ffffff821d 5cffffffc32733 17ffffff92ffffffaf2d ffffff9472ffffffd026 , 10104, 5
[1:1:0711/102512.448488:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[39580:39610:0711/102512.448726:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��\�'3��-�r�&��)+
[39580:39610:0711/102512.448790:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��\�'3��-�r�&����)+
[39580:39610:0711/102512.449018:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 39675, 5, 10b0821d 5cc32733 1792af2d 9472d026 
[1:1:0711/102512.449309:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feafb2660a0, 3
[1:1:0711/102512.449483:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feafb3f1080, 2
[1:1:0711/102512.449753:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feae50b4d20, -2
[1:1:0711/102512.476394:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/102512.476802:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2daf9217
[1:1:0711/102512.477168:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2daf9217
[1:1:0711/102512.477824:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2daf9217
[1:1:0711/102512.479327:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.479524:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.479731:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.479937:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.480610:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2daf9217
[1:1:0711/102512.480919:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feafd02b7ba
[1:1:0711/102512.481070:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feafd022def, 7feafd02b77a, 7feafd02d0cf
[1:1:0711/102512.484549:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2daf9217
[1:1:0711/102512.484890:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2daf9217
[1:1:0711/102512.485866:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2daf9217
[1:1:0711/102512.488438:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.488755:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.488972:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.489175:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2daf9217
[1:1:0711/102512.490477:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2daf9217
[1:1:0711/102512.490902:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feafd02b7ba
[1:1:0711/102512.491050:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feafd022def, 7feafd02b77a, 7feafd02d0cf
[1:1:0711/102512.493772:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/102512.494036:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/102512.494129:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc30121c88, 0x7ffc30121c08)
[1:1:0711/102512.507871:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/102512.510892:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/102512.572383:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 366, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/102512.577851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a519ba61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/102512.578100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/102512.633496:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/102512.644352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0a519ba61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/102512.644596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/102512.653707:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/102512.657184:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x4764a77ee20
[1:1:0711/102512.657384:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[39580:39580:0711/102512.665376:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[39580:39580:0711/102512.668255:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0711/102512.705430:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x4764a76c220
[1:1:0711/102512.706023:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[39580:39580:0711/102512.706648:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[39580:39580:0711/102512.706856:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/102512.761712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[39580:39580:0711/102513.030222:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39580:39580:0711/102513.040985:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[39580:39591:0711/102513.074947:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[39580:39591:0711/102513.075073:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[39580:39580:0711/102513.084845:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://zjbwg.cdstm.cn/
[39580:39580:0711/102513.084932:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zjbwg.cdstm.cn/, http://zjbwg.cdstm.cn/index.php, 1
[39580:39580:0711/102513.085061:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://zjbwg.cdstm.cn/, HTTP/1.1 200 OK Server: JSP3/2.0.14 Date: Thu, 11 Jul 2019 17:25:12 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip Age: 119475 Accept-Ranges: bytes Vary: Accept-Encoding X-Frame-Options: SAMEORIGIN X-Via-JSL: 67b4671,- X-Cache: bypass Ohc-File-Size: -1 Timing-Allow-Origin: * Ohc-Cache-HIT: bj2pbs75 [3]  ,39675, 5
[1:7:0711/102513.093454:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/102513.134717:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://zjbwg.cdstm.cn/
[39580:39580:0711/102513.247319:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zjbwg.cdstm.cn/, http://zjbwg.cdstm.cn/, 1
[39580:39580:0711/102513.247822:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://zjbwg.cdstm.cn/, http://zjbwg.cdstm.cn
[1:1:0711/102513.280358:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/102513.340039:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/102513.397641:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/102513.397924:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102513.417574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7feae4d67070 0x4764a7aa660 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102513.419889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , 
_atrk_opts = { atrk_acct:"5BDMm1a4KM+2WR", domain:"cdstm.cn",dynamic: true};
(function() { var as =
[1:1:0711/102513.420124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102513.422315:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/102513.844354:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7feae4d67070 0x4764a873160 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102513.849812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , // JavaScript Document

<!-- dd menu -->

<!--
var timeout         = 500;
var closetimer		= 0;
[1:1:0711/102513.850065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102513.861913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7feae4d67070 0x4764a873160 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102514.131610:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7feae4d67070 0x4764a873160 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102514.136791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7feae4d67070 0x4764a873160 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102514.171265:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.316843, 230, 1
[1:1:0711/102514.171532:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/102514.467280:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/102514.467599:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102514.469450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7feae4d67070 0x4764a9ccf60 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102514.470717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.
[1:1:0711/102514.470999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102514.478327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7feae4d67070 0x4764a9ccf60 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102515.299620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 16
[1:1:0711/102515.300121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 251
[1:1:0711/102515.300373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 251 0x7feae4d67070 0x4764aa30760 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 211 0x7feae4d67070 0x4764a9ccf60 
[1:1:0711/102515.302118:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.833407, 3, 0
[1:1:0711/102515.302377:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/102515.412004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 224 0x7feae6c8f2e0 0x4764a81a460 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102515.413728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , !function(){var t={iu:"https://certify.alexametrics.com/atrk.gif?",ver:"20130128",opts:{atrk_acct:""
[1:1:0711/102515.413956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102515.720230:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/102515.720514:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102515.725270:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102515.726858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , H, (e){(o.addEventListener||"load"===e.type||"complete"===o.readyState)&&(q(),b.ready())}
[1:1:0711/102515.727081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102515.975038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 251, 7feae76ac8db
[1:1:0711/102515.987835:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"211 0x7feae4d67070 0x4764a9ccf60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102515.990766:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"211 0x7feae4d67070 0x4764a9ccf60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102515.991110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 296
[1:1:0711/102515.991334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 296 0x7feae4d67070 0x4764a37f6e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 251 0x7feae4d67070 0x4764aa30760 
[1:1:0711/102515.991808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102515.992821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102515.993027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102516.199915:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/102516.277949:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 296, 7feae76ac8db
[1:1:0711/102516.291324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"251 0x7feae4d67070 0x4764aa30760 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102516.291578:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"251 0x7feae4d67070 0x4764aa30760 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102516.291833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 311
[1:1:0711/102516.291950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 311 0x7feae4d67070 0x4764a35ede0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 296 0x7feae4d67070 0x4764a37f6e0 
[1:1:0711/102516.292103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102516.292424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102516.292537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102516.339842:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7feae6c8f2e0 0x4764a35e9e0 , "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102516.349234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , (function(){var h={},mt={},c={id:"a367cd5964692c7011d746a625fb9bca",dm:["zjbwg.cdstm.cn"],js:"tongji
[1:1:0711/102516.349494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102516.385711:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7148
[1:1:0711/102516.385999:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102516.386426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 316
[1:1:0711/102516.386697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 316 0x7feae4d67070 0x4764a866c60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 306 0x7feae6c8f2e0 0x4764a35e9e0 
[1:1:0711/102517.550976:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0711/102520.129328:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/102520.258002:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 311, 7feae76ac8db
[1:1:0711/102520.274242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"296 0x7feae4d67070 0x4764a37f6e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102520.274599:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"296 0x7feae4d67070 0x4764a37f6e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102520.275027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 377
[1:1:0711/102520.275254:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 377 0x7feae4d67070 0x4764a898460 , 5:3_http://zjbwg.cdstm.cn/, 0, , 311 0x7feae4d67070 0x4764a35ede0 
[1:1:0711/102520.275599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102520.276221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102520.276432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102520.357747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/102520.358043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102520.724632:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 316, 7feae76ac881
[1:1:0711/102520.741775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"306 0x7feae6c8f2e0 0x4764a35e9e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102520.742157:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"306 0x7feae6c8f2e0 0x4764a35e9e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102520.742594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102520.743183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102520.743398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102520.744224:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102520.744426:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102520.744796:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 396
[1:1:0711/102520.745035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 396 0x7feae4d67070 0x4764a9bb960 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 316 0x7feae4d67070 0x4764a866c60 
[1:1:0711/102520.790042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 377, 7feae76ac8db
[1:1:0711/102520.808176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"311 0x7feae4d67070 0x4764a35ede0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102520.808496:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"311 0x7feae4d67070 0x4764a35ede0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102520.808935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 402
[1:1:0711/102520.809165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 402 0x7feae4d67070 0x4764ab1ed60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 377 0x7feae4d67070 0x4764a898460 
[1:1:0711/102520.809493:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102520.810127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102520.810357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102521.132857:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 402, 7feae76ac8db
[1:1:0711/102521.145961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"377 0x7feae4d67070 0x4764a898460 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102521.146288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"377 0x7feae4d67070 0x4764a898460 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102521.146727:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 416
[1:1:0711/102521.146987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 416 0x7feae4d67070 0x4764a9caae0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 402 0x7feae4d67070 0x4764ab1ed60 
[1:1:0711/102521.147310:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102521.147943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102521.148150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102521.167834:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 396, 7feae76ac881
[1:1:0711/102521.187097:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"316 0x7feae4d67070 0x4764a866c60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102521.187445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"316 0x7feae4d67070 0x4764a866c60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102521.187846:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102521.188428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102521.188651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102521.189457:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102521.189655:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102521.190076:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 418
[1:1:0711/102521.190314:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 418 0x7feae4d67070 0x4764a883360 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 396 0x7feae4d67070 0x4764a9bb960 
[1:1:0711/102521.358940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , document.readyState
[1:1:0711/102521.359223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102521.424115:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102521.424868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/102521.425107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102521.434305:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102521.437695:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102521.439295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b72f0
[1:1:0711/102521.439472:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102521.439846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 442
[1:1:0711/102521.440053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 442 0x7feae4d67070 0x4764a86d7e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 413 0x7feae4d67070 0x4764a895360 
[1:1:0711/102521.475047:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 416, 7feae76ac8db
[1:1:0711/102521.495451:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"402 0x7feae4d67070 0x4764ab1ed60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102521.495736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"402 0x7feae4d67070 0x4764ab1ed60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102521.496185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 455
[1:1:0711/102521.496381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 455 0x7feae4d67070 0x4764a9681e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 416 0x7feae4d67070 0x4764a9caae0 
[1:1:0711/102521.496664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102521.497382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102521.497660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102521.665219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , document.readyState
[1:1:0711/102521.665404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102521.983451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 455, 7feae76ac8db
[1:1:0711/102522.003525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"416 0x7feae4d67070 0x4764a9caae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.003803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"416 0x7feae4d67070 0x4764a9caae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.004307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 470
[1:1:0711/102522.004544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7feae4d67070 0x4764a9688e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 455 0x7feae4d67070 0x4764a9681e0 
[1:1:0711/102522.004826:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.005428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.005602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.086454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 442, 7feae76ac881
[1:1:0711/102522.092459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"413 0x7feae4d67070 0x4764a895360 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.092608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"413 0x7feae4d67070 0x4764a895360 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.092783:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.093098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102522.093201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.093487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102522.093602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102522.093856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 476
[1:1:0711/102522.094003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 476 0x7feae4d67070 0x4764b228960 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 442 0x7feae4d67070 0x4764a86d7e0 
[1:1:0711/102522.225638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 470, 7feae76ac8db
[1:1:0711/102522.232035:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"455 0x7feae4d67070 0x4764a9681e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.232199:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"455 0x7feae4d67070 0x4764a9681e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.232402:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 485
[1:1:0711/102522.232527:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7feae4d67070 0x4764b228560 , 5:3_http://zjbwg.cdstm.cn/, 0, , 470 0x7feae4d67070 0x4764a9688e0 
[1:1:0711/102522.232693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.233048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.233154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.305975:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 476, 7feae76ac881
[1:1:0711/102522.311898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"442 0x7feae4d67070 0x4764a86d7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.312100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"442 0x7feae4d67070 0x4764a86d7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.312289:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.312580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102522.312685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.312979:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102522.313100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102522.313273:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 490
[1:1:0711/102522.313379:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7feae4d67070 0x4764a5d6a60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 476 0x7feae4d67070 0x4764b228960 
[1:1:0711/102522.320307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 485, 7feae76ac8db
[1:1:0711/102522.328187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"470 0x7feae4d67070 0x4764a9688e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.328351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"470 0x7feae4d67070 0x4764a9688e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.328552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 491
[1:1:0711/102522.328660:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 491 0x7feae4d67070 0x4764af842e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 485 0x7feae4d67070 0x4764b228560 
[1:1:0711/102522.328808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.329183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.329290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.400161:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 491, 7feae76ac8db
[1:1:0711/102522.407274:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"485 0x7feae4d67070 0x4764b228560 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.407507:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"485 0x7feae4d67070 0x4764b228560 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.407794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 500
[1:1:0711/102522.407946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 500 0x7feae4d67070 0x4764a624860 , 5:3_http://zjbwg.cdstm.cn/, 0, , 491 0x7feae4d67070 0x4764af842e0 
[1:1:0711/102522.408129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.408478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.408584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.417159:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 490, 7feae76ac881
[1:1:0711/102522.424242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"476 0x7feae4d67070 0x4764b228960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.424393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"476 0x7feae4d67070 0x4764b228960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.424581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.424865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102522.424968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.425281:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102522.425383:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102522.425545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 504
[1:1:0711/102522.425650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7feae4d67070 0x4764b228d60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 490 0x7feae4d67070 0x4764a5d6a60 
[1:1:0711/102522.459687:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 500, 7feae76ac8db
[1:1:0711/102522.473137:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"491 0x7feae4d67070 0x4764af842e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.473320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"491 0x7feae4d67070 0x4764af842e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.473538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 511
[1:1:0711/102522.473651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7feae4d67070 0x4764b1fda60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 500 0x7feae4d67070 0x4764a624860 
[1:1:0711/102522.473807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.474177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.474291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.484304:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 511, 7feae76ac8db
[1:1:0711/102522.490839:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"500 0x7feae4d67070 0x4764a624860 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.490971:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"500 0x7feae4d67070 0x4764a624860 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.491246:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 513
[1:1:0711/102522.491376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7feae4d67070 0x4764b225ae0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 511 0x7feae4d67070 0x4764b1fda60 
[1:1:0711/102522.491532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.491868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.491968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.505304:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 513, 7feae76ac8db
[1:1:0711/102522.516475:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"511 0x7feae4d67070 0x4764b1fda60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.516606:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"511 0x7feae4d67070 0x4764b1fda60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.516777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 515
[1:1:0711/102522.516881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 515 0x7feae4d67070 0x4764a7d2de0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 513 0x7feae4d67070 0x4764b225ae0 
[1:1:0711/102522.517009:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.517287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.517391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.530442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 504, 7feae76ac881
[1:1:0711/102522.537602:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"490 0x7feae4d67070 0x4764a5d6a60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.537780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"490 0x7feae4d67070 0x4764a5d6a60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.537978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.538305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102522.538412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.538719:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102522.538833:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102522.539005:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 520
[1:1:0711/102522.539184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 520 0x7feae4d67070 0x4764a776b60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 504 0x7feae4d67070 0x4764b228d60 
[1:1:0711/102522.581541:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 515, 7feae76ac8db
[1:1:0711/102522.605104:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"513 0x7feae4d67070 0x4764b225ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.605471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"513 0x7feae4d67070 0x4764b225ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.605956:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 524
[1:1:0711/102522.606219:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 524 0x7feae4d67070 0x4764a35e560 , 5:3_http://zjbwg.cdstm.cn/, 0, , 515 0x7feae4d67070 0x4764a7d2de0 
[1:1:0711/102522.606584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.607354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.607579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.613400:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 524, 7feae76ac8db
[1:1:0711/102522.637222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"515 0x7feae4d67070 0x4764a7d2de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.637526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"515 0x7feae4d67070 0x4764a7d2de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.637929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 527
[1:1:0711/102522.638143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 527 0x7feae4d67070 0x4764a7ed1e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 524 0x7feae4d67070 0x4764a35e560 
[1:1:0711/102522.638402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.638978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.639203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.666692:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 520, 7feae76ac881
[1:1:0711/102522.691967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"504 0x7feae4d67070 0x4764b228d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.692316:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"504 0x7feae4d67070 0x4764b228d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.692685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.693245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102522.693425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.694067:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102522.694247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102522.694591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 532
[1:1:0711/102522.694792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7feae4d67070 0x4764a3604e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 520 0x7feae4d67070 0x4764a776b60 
[1:1:0711/102522.726928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 527, 7feae76ac8db
[1:1:0711/102522.738730:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"524 0x7feae4d67070 0x4764a35e560 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.738874:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"524 0x7feae4d67070 0x4764a35e560 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.739064:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 536
[1:1:0711/102522.739217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7feae4d67070 0x4764a7ed260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 527 0x7feae4d67070 0x4764a7ed1e0 
[1:1:0711/102522.739391:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.739727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.739830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.766247:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 536, 7feae76ac8db
[1:1:0711/102522.772556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"527 0x7feae4d67070 0x4764a7ed1e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.772683:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"527 0x7feae4d67070 0x4764a7ed1e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.772867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 540
[1:1:0711/102522.772979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 540 0x7feae4d67070 0x4764aa23260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 536 0x7feae4d67070 0x4764a7ed260 
[1:1:0711/102522.773153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.773492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.773596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.830724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 540, 7feae76ac8db
[1:1:0711/102522.837549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"536 0x7feae4d67070 0x4764a7ed260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.837673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"536 0x7feae4d67070 0x4764a7ed260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.837851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 551
[1:1:0711/102522.837952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 551 0x7feae4d67070 0x4764af7f7e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 540 0x7feae4d67070 0x4764aa23260 
[1:1:0711/102522.838099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.838454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.838555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.840001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 532, 7feae76ac881
[1:1:0711/102522.848887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"520 0x7feae4d67070 0x4764a776b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.849069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"520 0x7feae4d67070 0x4764a776b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.849273:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.849542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102522.849640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.849929:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102522.850022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102522.850216:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 552
[1:1:0711/102522.850326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 552 0x7feae4d67070 0x4764a7d18e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 532 0x7feae4d67070 0x4764a3604e0 
[1:1:0711/102522.866090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 551, 7feae76ac8db
[1:1:0711/102522.872279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"540 0x7feae4d67070 0x4764aa23260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.872439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"540 0x7feae4d67070 0x4764aa23260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.872647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 554
[1:1:0711/102522.872759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7feae4d67070 0x4764aa281e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 551 0x7feae4d67070 0x4764af7f7e0 
[1:1:0711/102522.872915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.873272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.873378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.897857:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 554, 7feae76ac8db
[1:1:0711/102522.917774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"551 0x7feae4d67070 0x4764af7f7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.918061:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"551 0x7feae4d67070 0x4764af7f7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.918454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 558
[1:1:0711/102522.918638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7feae4d67070 0x4764a7d24e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 554 0x7feae4d67070 0x4764aa281e0 
[1:1:0711/102522.918906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.919495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.919666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.968939:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 558, 7feae76ac8db
[1:1:0711/102522.976278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"554 0x7feae4d67070 0x4764aa281e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.976455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"554 0x7feae4d67070 0x4764aa281e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.976662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 565
[1:1:0711/102522.976769:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7feae4d67070 0x4764a77cee0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 558 0x7feae4d67070 0x4764a7d24e0 
[1:1:0711/102522.976928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.977313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102522.977456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.979781:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 552, 7feae76ac881
[1:1:0711/102522.990281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"532 0x7feae4d67070 0x4764a3604e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.990467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"532 0x7feae4d67070 0x4764a3604e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102522.990702:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102522.991037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102522.991204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102522.992426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102522.992567:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102522.992808:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 566
[1:1:0711/102522.992959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7feae4d67070 0x4764aa324e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 552 0x7feae4d67070 0x4764a7d18e0 
[1:1:0711/102522.993652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 565, 7feae76ac8db
[1:1:0711/102523.002936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"558 0x7feae4d67070 0x4764a7d24e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.003111:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"558 0x7feae4d67070 0x4764a7d24e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.003358:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 568
[1:1:0711/102523.003475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7feae4d67070 0x4764a790b60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 565 0x7feae4d67070 0x4764a77cee0 
[1:1:0711/102523.003630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.003959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.004062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.023090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 568, 7feae76ac8db
[1:1:0711/102523.030007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"565 0x7feae4d67070 0x4764a77cee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.030211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"565 0x7feae4d67070 0x4764a77cee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.030428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 570
[1:1:0711/102523.030534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 570 0x7feae4d67070 0x4764ae56260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 568 0x7feae4d67070 0x4764a790b60 
[1:1:0711/102523.030684:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.031018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.031118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.045946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 570, 7feae76ac8db
[1:1:0711/102523.068629:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"568 0x7feae4d67070 0x4764a790b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.068922:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"568 0x7feae4d67070 0x4764a790b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.069325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 575
[1:1:0711/102523.069521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7feae4d67070 0x4764b337d60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 570 0x7feae4d67070 0x4764ae56260 
[1:1:0711/102523.069802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.070418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.070595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.117893:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 575, 7feae76ac8db
[1:1:0711/102523.124508:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"570 0x7feae4d67070 0x4764ae56260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.124660:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"570 0x7feae4d67070 0x4764ae56260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.124852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 582
[1:1:0711/102523.124971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7feae4d67070 0x4764b2288e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 575 0x7feae4d67070 0x4764b337d60 
[1:1:0711/102523.125123:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.125483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.125593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.127245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 566, 7feae76ac881
[1:1:0711/102523.134263:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"552 0x7feae4d67070 0x4764a7d18e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.134406:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"552 0x7feae4d67070 0x4764a7d18e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.134575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.134831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102523.134946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.135257:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102523.135360:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102523.135523:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 585
[1:1:0711/102523.135629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 585 0x7feae4d67070 0x4764aa2d260 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 566 0x7feae4d67070 0x4764aa324e0 
[1:1:0711/102523.168666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 582, 7feae76ac8db
[1:1:0711/102523.175413:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"575 0x7feae4d67070 0x4764b337d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.175559:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"575 0x7feae4d67070 0x4764b337d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.175762:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 591
[1:1:0711/102523.175869:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7feae4d67070 0x4764aa2d6e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 582 0x7feae4d67070 0x4764b2288e0 
[1:1:0711/102523.176021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.176370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.176476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.204804:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 591, 7feae76ac8db
[1:1:0711/102523.211435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"582 0x7feae4d67070 0x4764b2288e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.211565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"582 0x7feae4d67070 0x4764b2288e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.211747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 594
[1:1:0711/102523.211918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7feae4d67070 0x4764a86e460 , 5:3_http://zjbwg.cdstm.cn/, 0, , 591 0x7feae4d67070 0x4764aa2d6e0 
[1:1:0711/102523.212073:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.212444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.212552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.231341:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 594, 7feae76ac8db
[1:1:0711/102523.237949:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"591 0x7feae4d67070 0x4764aa2d6e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.238076:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"591 0x7feae4d67070 0x4764aa2d6e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.238331:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 596
[1:1:0711/102523.238591:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7feae4d67070 0x4764a7d2960 , 5:3_http://zjbwg.cdstm.cn/, 0, , 594 0x7feae4d67070 0x4764a86e460 
[1:1:0711/102523.238900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.239608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.239829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.245368:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 585, 7feae76ac881
[1:1:0711/102523.256998:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"566 0x7feae4d67070 0x4764aa324e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.257188:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"566 0x7feae4d67070 0x4764aa324e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.257417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.257702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102523.257807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.258100:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102523.258196:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102523.258431:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 598
[1:1:0711/102523.258543:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7feae4d67070 0x4764a35e0e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 585 0x7feae4d67070 0x4764aa2d260 
[1:1:0711/102523.259006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 596, 7feae76ac8db
[1:1:0711/102523.270387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"594 0x7feae4d67070 0x4764a86e460 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.270767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"594 0x7feae4d67070 0x4764a86e460 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.271281:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 600
[1:1:0711/102523.271532:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7feae4d67070 0x4764af75ee0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 596 0x7feae4d67070 0x4764a7d2960 
[1:1:0711/102523.271895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.272582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.272776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.308651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 600, 7feae76ac8db
[1:1:0711/102523.332476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"596 0x7feae4d67070 0x4764a7d2960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.332789:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"596 0x7feae4d67070 0x4764a7d2960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.333183:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 602
[1:1:0711/102523.333394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7feae4d67070 0x4764b225260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 600 0x7feae4d67070 0x4764af75ee0 
[1:1:0711/102523.333683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.334302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.334499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.372557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 602, 7feae76ac8db
[1:1:0711/102523.383889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"600 0x7feae4d67070 0x4764af75ee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.384067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"600 0x7feae4d67070 0x4764af75ee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.384290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 605
[1:1:0711/102523.384411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 605 0x7feae4d67070 0x4764a858760 , 5:3_http://zjbwg.cdstm.cn/, 0, , 602 0x7feae4d67070 0x4764b225260 
[1:1:0711/102523.384563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.384901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.385006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.386593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 598, 7feae76ac881
[1:1:0711/102523.402907:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"585 0x7feae4d67070 0x4764aa2d260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.403090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"585 0x7feae4d67070 0x4764aa2d260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.403298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.403599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102523.403705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.404002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102523.404105:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102523.404323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 606
[1:1:0711/102523.404531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7feae4d67070 0x4764b228d60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 598 0x7feae4d67070 0x4764a35e0e0 
[1:1:0711/102523.416336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 605, 7feae76ac8db
[1:1:0711/102523.423169:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"602 0x7feae4d67070 0x4764b225260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.423313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"602 0x7feae4d67070 0x4764b225260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.423499:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 610
[1:1:0711/102523.423603:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7feae4d67070 0x4764a7d2a60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 605 0x7feae4d67070 0x4764a858760 
[1:1:0711/102523.423746:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.424064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.424168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.452768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 610, 7feae76ac8db
[1:1:0711/102523.476032:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"605 0x7feae4d67070 0x4764a858760 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.476337:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"605 0x7feae4d67070 0x4764a858760 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.476824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 612
[1:1:0711/102523.477066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7feae4d67070 0x4764aa32fe0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 610 0x7feae4d67070 0x4764a7d2a60 
[1:1:0711/102523.477443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.478172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.478459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.517356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 612, 7feae76ac8db
[1:1:0711/102523.540976:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"610 0x7feae4d67070 0x4764a7d2a60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.541279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"610 0x7feae4d67070 0x4764a7d2a60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.541708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 615
[1:1:0711/102523.541898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7feae4d67070 0x4764aa23d60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 612 0x7feae4d67070 0x4764aa32fe0 
[1:1:0711/102523.542182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.542820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.542994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.548376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 606, 7feae76ac881
[1:1:0711/102523.574395:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"598 0x7feae4d67070 0x4764a35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.574718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"598 0x7feae4d67070 0x4764a35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.575061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.575602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102523.575777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.576434:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102523.576594:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102523.576950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 616
[1:1:0711/102523.577137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7feae4d67070 0x4764aa34d60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 606 0x7feae4d67070 0x4764b228d60 
[1:1:0711/102523.578507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 615, 7feae76ac8db
[1:1:0711/102523.588836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"612 0x7feae4d67070 0x4764aa32fe0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.589016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"612 0x7feae4d67070 0x4764aa32fe0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.589241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 618
[1:1:0711/102523.589367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7feae4d67070 0x4764a7aa9e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 615 0x7feae4d67070 0x4764aa23d60 
[1:1:0711/102523.589535:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.589861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.589965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.618682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 618, 7feae76ac8db
[1:1:0711/102523.629994:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"615 0x7feae4d67070 0x4764aa23d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.630275:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"615 0x7feae4d67070 0x4764aa23d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.630700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 620
[1:1:0711/102523.630891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7feae4d67070 0x4764a7658e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 618 0x7feae4d67070 0x4764a7aa9e0 
[1:1:0711/102523.631172:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.631761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.631937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.663796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 620, 7feae76ac8db
[1:1:0711/102523.670967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"618 0x7feae4d67070 0x4764a7aa9e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.671109:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"618 0x7feae4d67070 0x4764a7aa9e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.671296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 622
[1:1:0711/102523.671486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7feae4d67070 0x4764af7f960 , 5:3_http://zjbwg.cdstm.cn/, 0, , 620 0x7feae4d67070 0x4764a7658e0 
[1:1:0711/102523.671632:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.672011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.672126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.706561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 616, 7feae76ac881
[1:1:0711/102523.732615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"606 0x7feae4d67070 0x4764b228d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.732951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"606 0x7feae4d67070 0x4764b228d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.733296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.733835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102523.734009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.734690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102523.734851:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102523.735193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 625
[1:1:0711/102523.735394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7feae4d67070 0x4764ae563e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 616 0x7feae4d67070 0x4764aa34d60 
[1:1:0711/102523.736694:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 622, 7feae76ac8db
[1:1:0711/102523.764138:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"620 0x7feae4d67070 0x4764a7658e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.764469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"620 0x7feae4d67070 0x4764a7658e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.764860:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 626
[1:1:0711/102523.765050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7feae4d67070 0x4764af7f660 , 5:3_http://zjbwg.cdstm.cn/, 0, , 622 0x7feae4d67070 0x4764af7f960 
[1:1:0711/102523.765334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.765941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.766115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.805218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 626, 7feae76ac8db
[1:1:0711/102523.829476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"622 0x7feae4d67070 0x4764af7f960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.829778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"622 0x7feae4d67070 0x4764af7f960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.830169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 628
[1:1:0711/102523.830360:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7feae4d67070 0x4764a7c41e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 626 0x7feae4d67070 0x4764af7f660 
[1:1:0711/102523.830658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.831232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.831429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.835802:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 625, 7feae76ac881
[1:1:0711/102523.844048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"616 0x7feae4d67070 0x4764aa34d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.844214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"616 0x7feae4d67070 0x4764aa34d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.844415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.844689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102523.844793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.845082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102523.845177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102523.845347:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 630
[1:1:0711/102523.845480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 630 0x7feae4d67070 0x4764af7f660 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 625 0x7feae4d67070 0x4764ae563e0 
[1:1:0711/102523.845906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 628, 7feae76ac8db
[1:1:0711/102523.852943:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"626 0x7feae4d67070 0x4764af7f660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.853061:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"626 0x7feae4d67070 0x4764af7f660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.853228:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 632
[1:1:0711/102523.853340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 632 0x7feae4d67070 0x4764a88fde0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 628 0x7feae4d67070 0x4764a7c41e0 
[1:1:0711/102523.853496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.853764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.853874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.887890:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 632, 7feae76ac8db
[1:1:0711/102523.909195:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"628 0x7feae4d67070 0x4764a7c41e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.909422:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"628 0x7feae4d67070 0x4764a7c41e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.909644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 634
[1:1:0711/102523.909750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7feae4d67070 0x4764a361b60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 632 0x7feae4d67070 0x4764a88fde0 
[1:1:0711/102523.909902:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.910231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.910331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.934643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 634, 7feae76ac8db
[1:1:0711/102523.955445:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"632 0x7feae4d67070 0x4764a88fde0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.955648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"632 0x7feae4d67070 0x4764a88fde0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.955869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 636
[1:1:0711/102523.955979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7feae4d67070 0x4764a968ee0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 634 0x7feae4d67070 0x4764a361b60 
[1:1:0711/102523.956126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.956489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.956599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.958131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 630, 7feae76ac881
[1:1:0711/102523.965974:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"625 0x7feae4d67070 0x4764ae563e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.966137:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"625 0x7feae4d67070 0x4764ae563e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.966321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.966770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102523.966894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102523.967197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102523.967295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102523.967540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 639
[1:1:0711/102523.967734:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7feae4d67070 0x4764a361b60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 630 0x7feae4d67070 0x4764af7f660 
[1:1:0711/102523.969010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 636, 7feae76ac8db
[1:1:0711/102523.993381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"634 0x7feae4d67070 0x4764a361b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.993676:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"634 0x7feae4d67070 0x4764a361b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102523.994057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 640
[1:1:0711/102523.994245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7feae4d67070 0x4764a3613e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 636 0x7feae4d67070 0x4764a968ee0 
[1:1:0711/102523.994562:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102523.995170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102523.995342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.014529:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 640, 7feae76ac8db
[1:1:0711/102524.022849:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"636 0x7feae4d67070 0x4764a968ee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.023082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"636 0x7feae4d67070 0x4764a968ee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.023367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 642
[1:1:0711/102524.023557:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 642 0x7feae4d67070 0x4764af84160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 640 0x7feae4d67070 0x4764a3613e0 
[1:1:0711/102524.023773:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.024228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.024379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.055558:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 642, 7feae76ac8db
[1:1:0711/102524.064503:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"640 0x7feae4d67070 0x4764a3613e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.064656:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"640 0x7feae4d67070 0x4764a3613e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.064851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 644
[1:1:0711/102524.064958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7feae4d67070 0x4764af76ae0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 642 0x7feae4d67070 0x4764af84160 
[1:1:0711/102524.065100:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.065450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.065560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.076892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 639, 7feae76ac881
[1:1:0711/102524.083901:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"630 0x7feae4d67070 0x4764af7f660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.084052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"630 0x7feae4d67070 0x4764af7f660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.084230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.084544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102524.084651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.084945:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102524.085042:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102524.085209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 647
[1:1:0711/102524.085326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7feae4d67070 0x4764a7794e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 639 0x7feae4d67070 0x4764a361b60 
[1:1:0711/102524.085744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 644, 7feae76ac8db
[1:1:0711/102524.105974:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"642 0x7feae4d67070 0x4764af84160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.106249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"642 0x7feae4d67070 0x4764af84160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.106656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 648
[1:1:0711/102524.106851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7feae4d67070 0x4764af303e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 644 0x7feae4d67070 0x4764af76ae0 
[1:1:0711/102524.107128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.107716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.107891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.142767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 648, 7feae76ac8db
[1:1:0711/102524.156173:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"644 0x7feae4d67070 0x4764af76ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.156347:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"644 0x7feae4d67070 0x4764af76ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.156585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 650
[1:1:0711/102524.156700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7feae4d67070 0x4764af84260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 648 0x7feae4d67070 0x4764af303e0 
[1:1:0711/102524.156855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.157185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.157289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.191688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 650, 7feae76ac8db
[1:1:0711/102524.218794:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"648 0x7feae4d67070 0x4764af303e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.219092:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"648 0x7feae4d67070 0x4764af303e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.219516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 653
[1:1:0711/102524.219712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 653 0x7feae4d67070 0x4764b337ae0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 650 0x7feae4d67070 0x4764af84260 
[1:1:0711/102524.220002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.220622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.220858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.225187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 647, 7feae76ac881
[1:1:0711/102524.250156:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"639 0x7feae4d67070 0x4764a361b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.250507:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"639 0x7feae4d67070 0x4764a361b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.250861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.251389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102524.251581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.252224:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102524.252380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102524.252752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 654
[1:1:0711/102524.252943:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7feae4d67070 0x4764af84260 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 647 0x7feae4d67070 0x4764a7794e0 
[1:1:0711/102524.254255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 653, 7feae76ac8db
[1:1:0711/102524.279090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"650 0x7feae4d67070 0x4764af84260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.279378:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"650 0x7feae4d67070 0x4764af84260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.279790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 656
[1:1:0711/102524.279982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7feae4d67070 0x4764a7793e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 653 0x7feae4d67070 0x4764b337ae0 
[1:1:0711/102524.280262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.280869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.281050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.320069:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 656, 7feae76ac8db
[1:1:0711/102524.336429:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"653 0x7feae4d67070 0x4764b337ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.336650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"653 0x7feae4d67070 0x4764b337ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.336867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 658
[1:1:0711/102524.336982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7feae4d67070 0x4764b225760 , 5:3_http://zjbwg.cdstm.cn/, 0, , 656 0x7feae4d67070 0x4764a7793e0 
[1:1:0711/102524.337138:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.337473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.337607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.351349:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 658, 7feae76ac8db
[1:1:0711/102524.358363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"656 0x7feae4d67070 0x4764a7793e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.358552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"656 0x7feae4d67070 0x4764a7793e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.358775:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 660
[1:1:0711/102524.358881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 660 0x7feae4d67070 0x4764b337e60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 658 0x7feae4d67070 0x4764b225760 
[1:1:0711/102524.359018:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.359353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.359457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.360956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 654, 7feae76ac881
[1:1:0711/102524.371813:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"647 0x7feae4d67070 0x4764a7794e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.371990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"647 0x7feae4d67070 0x4764a7794e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.372187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.372467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102524.372602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.372904:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102524.373001:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102524.373171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 662
[1:1:0711/102524.373279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7feae4d67070 0x4764b21dd60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 654 0x7feae4d67070 0x4764af84260 
[1:1:0711/102524.373734:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 660, 7feae76ac8db
[1:1:0711/102524.381222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"658 0x7feae4d67070 0x4764b225760 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.381350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"658 0x7feae4d67070 0x4764b225760 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.381543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 664
[1:1:0711/102524.381653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7feae4d67070 0x4764a803ce0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 660 0x7feae4d67070 0x4764b337e60 
[1:1:0711/102524.381786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.382063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.382165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.421281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 664, 7feae76ac8db
[1:1:0711/102524.444488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"660 0x7feae4d67070 0x4764b337e60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.444709:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"660 0x7feae4d67070 0x4764b337e60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.444932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 667
[1:1:0711/102524.445045:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7feae4d67070 0x4764a7c4260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 664 0x7feae4d67070 0x4764a803ce0 
[1:1:0711/102524.445215:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.445568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.445682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.455239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 667, 7feae76ac8db
[1:1:0711/102524.463092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"664 0x7feae4d67070 0x4764a803ce0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.463279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"664 0x7feae4d67070 0x4764a803ce0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.463494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 669
[1:1:0711/102524.463636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7feae4d67070 0x4764b21d660 , 5:3_http://zjbwg.cdstm.cn/, 0, , 667 0x7feae4d67070 0x4764a7c4260 
[1:1:0711/102524.463795:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.464128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.464235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.496066:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 669, 7feae76ac8db
[1:1:0711/102524.521689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"667 0x7feae4d67070 0x4764a7c4260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.521986:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"667 0x7feae4d67070 0x4764a7c4260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.522379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 672
[1:1:0711/102524.522614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7feae4d67070 0x4764a7c85e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 669 0x7feae4d67070 0x4764b21d660 
[1:1:0711/102524.522912:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.523602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.523781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.528117:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 662, 7feae76ac881
[1:1:0711/102524.554817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"654 0x7feae4d67070 0x4764af84260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.555243:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"654 0x7feae4d67070 0x4764af84260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.555659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.556234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102524.556410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.557082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102524.557244:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102524.557616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 673
[1:1:0711/102524.557811:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7feae4d67070 0x4764b225160 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 662 0x7feae4d67070 0x4764b21dd60 
[1:1:0711/102524.559761:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 672, 7feae76ac8db
[1:1:0711/102524.571114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"669 0x7feae4d67070 0x4764b21d660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.571253:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"669 0x7feae4d67070 0x4764b21d660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.571441:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 675
[1:1:0711/102524.571546:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7feae4d67070 0x4764b22b960 , 5:3_http://zjbwg.cdstm.cn/, 0, , 672 0x7feae4d67070 0x4764a7c85e0 
[1:1:0711/102524.571712:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.572018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.572120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.609340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 675, 7feae76ac8db
[1:1:0711/102524.634921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"672 0x7feae4d67070 0x4764a7c85e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.635218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"672 0x7feae4d67070 0x4764a7c85e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.635626:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 677
[1:1:0711/102524.635824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7feae4d67070 0x4764a7456e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 675 0x7feae4d67070 0x4764b22b960 
[1:1:0711/102524.636128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.636757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.636989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.670872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 677, 7feae76ac8db
[1:1:0711/102524.698649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"675 0x7feae4d67070 0x4764b22b960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.698933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"675 0x7feae4d67070 0x4764b22b960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.699318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 680
[1:1:0711/102524.699507:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7feae4d67070 0x4764a882160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 677 0x7feae4d67070 0x4764a7456e0 
[1:1:0711/102524.699815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.700407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.700580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.702209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 673, 7feae76ac881
[1:1:0711/102524.725694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"662 0x7feae4d67070 0x4764b21dd60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.726061:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"662 0x7feae4d67070 0x4764b21dd60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.726484:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.727167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102524.727388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.727874:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102524.727977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102524.728156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 681
[1:1:0711/102524.728267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7feae4d67070 0x4764a7ed260 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 673 0x7feae4d67070 0x4764b225160 
[1:1:0711/102524.728761:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 680, 7feae76ac8db
[1:1:0711/102524.740081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"677 0x7feae4d67070 0x4764a7456e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.740308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"677 0x7feae4d67070 0x4764a7456e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.740610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 683
[1:1:0711/102524.740778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7feae4d67070 0x4764b22b6e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 680 0x7feae4d67070 0x4764a882160 
[1:1:0711/102524.740994:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.741432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.741576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.777470:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 683, 7feae76ac8db
[1:1:0711/102524.787042:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"680 0x7feae4d67070 0x4764a882160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.787340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"680 0x7feae4d67070 0x4764a882160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.787758:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 685
[1:1:0711/102524.787969:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7feae4d67070 0x4764a37c7e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 683 0x7feae4d67070 0x4764b22b6e0 
[1:1:0711/102524.788257:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.788866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.789043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.793485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 685, 7feae76ac8db
[1:1:0711/102524.819362:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"683 0x7feae4d67070 0x4764b22b6e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.819702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"683 0x7feae4d67070 0x4764b22b6e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.820096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 687
[1:1:0711/102524.820286:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7feae4d67070 0x4764af7f660 , 5:3_http://zjbwg.cdstm.cn/, 0, , 685 0x7feae4d67070 0x4764a37c7e0 
[1:1:0711/102524.820579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.821218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.821397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.825791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 687, 7feae76ac8db
[1:1:0711/102524.851713:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"685 0x7feae4d67070 0x4764a37c7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.851985:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"685 0x7feae4d67070 0x4764a37c7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.852367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 689
[1:1:0711/102524.852556:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7feae4d67070 0x4764a7ed160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 687 0x7feae4d67070 0x4764af7f660 
[1:1:0711/102524.852824:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.853391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.853563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.858084:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 681, 7feae76ac881
[1:1:0711/102524.884053:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"673 0x7feae4d67070 0x4764b225160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.884358:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"673 0x7feae4d67070 0x4764b225160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.884721:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.885261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102524.885442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.886105:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102524.886265:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102524.886607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 691
[1:1:0711/102524.886831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7feae4d67070 0x4764a7793e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 681 0x7feae4d67070 0x4764a7ed260 
[1:1:0711/102524.914322:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 689, 7feae76ac8db
[1:1:0711/102524.931746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"687 0x7feae4d67070 0x4764af7f660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.932113:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"687 0x7feae4d67070 0x4764af7f660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.932610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 693
[1:1:0711/102524.932873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7feae4d67070 0x4764a7c4160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 689 0x7feae4d67070 0x4764a7ed160 
[1:1:0711/102524.933231:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.933972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.934197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102524.963677:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 693, 7feae76ac8db
[1:1:0711/102524.979919:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"689 0x7feae4d67070 0x4764a7ed160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.980201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"689 0x7feae4d67070 0x4764a7ed160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102524.980581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 695
[1:1:0711/102524.980795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7feae4d67070 0x4764b228de0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 693 0x7feae4d67070 0x4764a7c4160 
[1:1:0711/102524.981074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102524.981648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102524.981847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.002721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 691, 7feae76ac881
[1:1:0711/102525.010247:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"681 0x7feae4d67070 0x4764a7ed260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.010400:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"681 0x7feae4d67070 0x4764a7ed260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.010581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.010919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.011037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.011334:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.011437:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.011613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 698
[1:1:0711/102525.011771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7feae4d67070 0x4764aa30b60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 691 0x7feae4d67070 0x4764a7793e0 
[1:1:0711/102525.012200:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 695, 7feae76ac8db
[1:1:0711/102525.020588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"693 0x7feae4d67070 0x4764a7c4160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.020753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"693 0x7feae4d67070 0x4764a7c4160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.020947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 699
[1:1:0711/102525.021054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7feae4d67070 0x4764a7d19e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 695 0x7feae4d67070 0x4764b228de0 
[1:1:0711/102525.021191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.021485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.021588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.042639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 699, 7feae76ac8db
[1:1:0711/102525.056959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"695 0x7feae4d67070 0x4764b228de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.057254:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"695 0x7feae4d67070 0x4764b228de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.057641:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 701
[1:1:0711/102525.057868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7feae4d67070 0x4764aa23be0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 699 0x7feae4d67070 0x4764a7d19e0 
[1:1:0711/102525.058156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.058780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.058958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.063372:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 701, 7feae76ac8db
[1:1:0711/102525.089753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"699 0x7feae4d67070 0x4764a7d19e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.090035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"699 0x7feae4d67070 0x4764a7d19e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.090433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 703
[1:1:0711/102525.090622:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7feae4d67070 0x4764b35e1e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 701 0x7feae4d67070 0x4764aa23be0 
[1:1:0711/102525.091088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.091850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.092073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.094282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 703, 7feae76ac8db
[1:1:0711/102525.102947:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"701 0x7feae4d67070 0x4764aa23be0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.103099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"701 0x7feae4d67070 0x4764aa23be0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.103303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 705
[1:1:0711/102525.103408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7feae4d67070 0x4764a968de0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 703 0x7feae4d67070 0x4764b35e1e0 
[1:1:0711/102525.103554:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.103889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.103996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.125005:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 705, 7feae76ac8db
[1:1:0711/102525.132559:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"703 0x7feae4d67070 0x4764b35e1e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.132712:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"703 0x7feae4d67070 0x4764b35e1e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.132921:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 708
[1:1:0711/102525.133041:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7feae4d67070 0x4764ab1e4e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 705 0x7feae4d67070 0x4764a968de0 
[1:1:0711/102525.133186:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.133496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.133598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.135099:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 698, 7feae76ac881
[1:1:0711/102525.142606:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"691 0x7feae4d67070 0x4764a7793e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.142776:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"691 0x7feae4d67070 0x4764a7793e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.142945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.143187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.143286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.143572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.143665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.143857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 709
[1:1:0711/102525.143963:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7feae4d67070 0x4764b21dd60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 698 0x7feae4d67070 0x4764aa30b60 
[1:1:0711/102525.144378:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 708, 7feae76ac8db
[1:1:0711/102525.152175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"705 0x7feae4d67070 0x4764a968de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.152303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"705 0x7feae4d67070 0x4764a968de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.152482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 711
[1:1:0711/102525.152587:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7feae4d67070 0x4764aa3dee0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 708 0x7feae4d67070 0x4764ab1e4e0 
[1:1:0711/102525.152744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.153122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.153265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.185109:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 711, 7feae76ac8db
[1:1:0711/102525.211775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"708 0x7feae4d67070 0x4764ab1e4e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.212067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"708 0x7feae4d67070 0x4764ab1e4e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.212461:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 713
[1:1:0711/102525.212650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7feae4d67070 0x4764a86e460 , 5:3_http://zjbwg.cdstm.cn/, 0, , 711 0x7feae4d67070 0x4764aa3dee0 
[1:1:0711/102525.213031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.213741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.213951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.246073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 713, 7feae76ac8db
[1:1:0711/102525.255555:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"711 0x7feae4d67070 0x4764aa3dee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.255699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"711 0x7feae4d67070 0x4764aa3dee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.255910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 717
[1:1:0711/102525.256016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7feae4d67070 0x4764a35e0e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 713 0x7feae4d67070 0x4764a86e460 
[1:1:0711/102525.256166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.256495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.256599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.258088:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 709, 7feae76ac881
[1:1:0711/102525.266226:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"698 0x7feae4d67070 0x4764aa30b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.266397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"698 0x7feae4d67070 0x4764aa30b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.266579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.266885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.266992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.267285:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.267387:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.267591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 718
[1:1:0711/102525.267697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 718 0x7feae4d67070 0x4764a7d1b60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 709 0x7feae4d67070 0x4764b21dd60 
[1:1:0711/102525.276426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 717, 7feae76ac8db
[1:1:0711/102525.287431:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"713 0x7feae4d67070 0x4764a86e460 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.287670:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"713 0x7feae4d67070 0x4764a86e460 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.287978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 720
[1:1:0711/102525.288133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 720 0x7feae4d67070 0x4764a9ca160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 717 0x7feae4d67070 0x4764a35e0e0 
[1:1:0711/102525.288342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.288816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.288963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.324650:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 720, 7feae76ac8db
[1:1:0711/102525.333285:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"717 0x7feae4d67070 0x4764a35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.333447:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"717 0x7feae4d67070 0x4764a35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.333648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 722
[1:1:0711/102525.333773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7feae4d67070 0x4764a77c660 , 5:3_http://zjbwg.cdstm.cn/, 0, , 720 0x7feae4d67070 0x4764a9ca160 
[1:1:0711/102525.333932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.334266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.334379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.376257:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 722, 7feae76ac8db
[1:1:0711/102525.398134:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"720 0x7feae4d67070 0x4764a9ca160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.398352:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"720 0x7feae4d67070 0x4764a9ca160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.398574:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 725
[1:1:0711/102525.398685:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7feae4d67070 0x4764b1fd060 , 5:3_http://zjbwg.cdstm.cn/, 0, , 722 0x7feae4d67070 0x4764a77c660 
[1:1:0711/102525.398880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.399223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.399327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.400848:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 718, 7feae76ac881
[1:1:0711/102525.408928:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"709 0x7feae4d67070 0x4764b21dd60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.409057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"709 0x7feae4d67070 0x4764b21dd60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.409211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.409439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.409541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.409864:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.409964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.410124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 726
[1:1:0711/102525.410227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7feae4d67070 0x4764b337d60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 718 0x7feae4d67070 0x4764a7d1b60 
[1:1:0711/102525.423431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 725, 7feae76ac8db
[1:1:0711/102525.431948:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"722 0x7feae4d67070 0x4764a77c660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.432109:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"722 0x7feae4d67070 0x4764a77c660 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.432307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 728
[1:1:0711/102525.432414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7feae4d67070 0x4764a7d18e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 725 0x7feae4d67070 0x4764b1fd060 
[1:1:0711/102525.432575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.433010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.433119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.472465:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 728, 7feae76ac8db
[1:1:0711/102525.495182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"725 0x7feae4d67070 0x4764b1fd060 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.495369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"725 0x7feae4d67070 0x4764b1fd060 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.495581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 730
[1:1:0711/102525.495688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7feae4d67070 0x4764af7f160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 728 0x7feae4d67070 0x4764a7d18e0 
[1:1:0711/102525.495872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.496207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.496309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.525196:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 730, 7feae76ac8db
[1:1:0711/102525.533345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"728 0x7feae4d67070 0x4764a7d18e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.533485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"728 0x7feae4d67070 0x4764a7d18e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.533674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 733
[1:1:0711/102525.533793:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7feae4d67070 0x4764a882160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 730 0x7feae4d67070 0x4764af7f160 
[1:1:0711/102525.534014:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.534355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.534471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.536055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 726, 7feae76ac881
[1:1:0711/102525.544321:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"718 0x7feae4d67070 0x4764a7d1b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.544496:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"718 0x7feae4d67070 0x4764a7d1b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.544687:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.544991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.545096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.545388:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.545485:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.545667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 734
[1:1:0711/102525.545775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7feae4d67070 0x4764b2259e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 726 0x7feae4d67070 0x4764b337d60 
[1:1:0711/102525.546475:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 733, 7feae76ac8db
[1:1:0711/102525.555261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"730 0x7feae4d67070 0x4764af7f160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.555558:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"730 0x7feae4d67070 0x4764af7f160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.555930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 736
[1:1:0711/102525.556115:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 736 0x7feae4d67070 0x4764a835b60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 733 0x7feae4d67070 0x4764a882160 
[1:1:0711/102525.556374:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.556918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.557085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.561227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 736, 7feae76ac8db
[1:1:0711/102525.578958:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"733 0x7feae4d67070 0x4764a882160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.579158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"733 0x7feae4d67070 0x4764a882160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.579373:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 738
[1:1:0711/102525.579484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7feae4d67070 0x4764aa3db60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 736 0x7feae4d67070 0x4764a835b60 
[1:1:0711/102525.579647:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.579993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.580099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.608453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 738, 7feae76ac8db
[1:1:0711/102525.640628:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"736 0x7feae4d67070 0x4764a835b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.640941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"736 0x7feae4d67070 0x4764a835b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.641335:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 740
[1:1:0711/102525.641525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7feae4d67070 0x4764a792160 , 5:3_http://zjbwg.cdstm.cn/, 0, , 738 0x7feae4d67070 0x4764aa3db60 
[1:1:0711/102525.641775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.642410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.642583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.646271:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 734, 7feae76ac881
[1:1:0711/102525.659979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"726 0x7feae4d67070 0x4764b337d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.660128:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"726 0x7feae4d67070 0x4764b337d60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.660303:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.660555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.660658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.661007:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.661120:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.661292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 742
[1:1:0711/102525.661399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7feae4d67070 0x4764ae539e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 734 0x7feae4d67070 0x4764b2259e0 
[1:1:0711/102525.661888:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 740, 7feae76ac8db
[1:1:0711/102525.672273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"738 0x7feae4d67070 0x4764aa3db60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.672463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"738 0x7feae4d67070 0x4764aa3db60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.672675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 744
[1:1:0711/102525.672784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 744 0x7feae4d67070 0x4764a7d2ae0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 740 0x7feae4d67070 0x4764a792160 
[1:1:0711/102525.672975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.673319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.673424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.704472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 744, 7feae76ac8db
[1:1:0711/102525.727272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"740 0x7feae4d67070 0x4764a792160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.727489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"740 0x7feae4d67070 0x4764a792160 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.727714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 746
[1:1:0711/102525.727844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 746 0x7feae4d67070 0x4764a361b60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 744 0x7feae4d67070 0x4764a7d2ae0 
[1:1:0711/102525.728017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.728356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.728458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.743383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 746, 7feae76ac8db
[1:1:0711/102525.751092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"744 0x7feae4d67070 0x4764a7d2ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.751221:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"744 0x7feae4d67070 0x4764a7d2ae0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.751399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 748
[1:1:0711/102525.751510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7feae4d67070 0x4764aa28260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 746 0x7feae4d67070 0x4764a361b60 
[1:1:0711/102525.751649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.751989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.752094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.772370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 742, 7feae76ac881
[1:1:0711/102525.780322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"734 0x7feae4d67070 0x4764b2259e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.780472:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"734 0x7feae4d67070 0x4764b2259e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.780652:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.780966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.781074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.781373:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.781470:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.781640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 751
[1:1:0711/102525.781746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7feae4d67070 0x4764a7d20e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 742 0x7feae4d67070 0x4764ae539e0 
[1:1:0711/102525.782192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 748, 7feae76ac8db
[1:1:0711/102525.802313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"746 0x7feae4d67070 0x4764a361b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.802668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"746 0x7feae4d67070 0x4764a361b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.803184:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 752
[1:1:0711/102525.803449:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7feae4d67070 0x4764a7585e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 748 0x7feae4d67070 0x4764aa28260 
[1:1:0711/102525.803802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.804544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.804771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.834368:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 752, 7feae76ac8db
[1:1:0711/102525.844079:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"748 0x7feae4d67070 0x4764aa28260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.844294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"748 0x7feae4d67070 0x4764aa28260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.844632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 754
[1:1:0711/102525.844809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7feae4d67070 0x4764a35e0e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 752 0x7feae4d67070 0x4764a7585e0 
[1:1:0711/102525.845099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.845641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.845807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.874183:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 754, 7feae76ac8db
[1:1:0711/102525.882620:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"752 0x7feae4d67070 0x4764a7585e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.882792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"752 0x7feae4d67070 0x4764a7585e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.883052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 757
[1:1:0711/102525.883168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7feae4d67070 0x4764a86de60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 754 0x7feae4d67070 0x4764a35e0e0 
[1:1:0711/102525.883311:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.883645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.883748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.894530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 751, 7feae76ac881
[1:1:0711/102525.902573:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"742 0x7feae4d67070 0x4764ae539e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.902718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"742 0x7feae4d67070 0x4764ae539e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.902945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.903243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102525.903346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.903639:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102525.903735:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102525.903925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 760
[1:1:0711/102525.904038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 760 0x7feae4d67070 0x4764b35e0e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 751 0x7feae4d67070 0x4764a7d20e0 
[1:1:0711/102525.904418:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 757, 7feae76ac8db
[1:1:0711/102525.913736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"754 0x7feae4d67070 0x4764a35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.913917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"754 0x7feae4d67070 0x4764a35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.914124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 761
[1:1:0711/102525.914233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7feae4d67070 0x4764b228560 , 5:3_http://zjbwg.cdstm.cn/, 0, , 757 0x7feae4d67070 0x4764a86de60 
[1:1:0711/102525.914373:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.914692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.914796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.950002:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 761, 7feae76ac8db
[1:1:0711/102525.960822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"757 0x7feae4d67070 0x4764a86de60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.961098:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"757 0x7feae4d67070 0x4764a86de60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.961494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 763
[1:1:0711/102525.961684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 763 0x7feae4d67070 0x4764a5d7fe0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 761 0x7feae4d67070 0x4764b228560 
[1:1:0711/102525.961995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.962569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.962748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102525.982505:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 763, 7feae76ac8db
[1:1:0711/102525.996011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"761 0x7feae4d67070 0x4764b228560 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.996259:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"761 0x7feae4d67070 0x4764b228560 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102525.996617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 765
[1:1:0711/102525.996796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 765 0x7feae4d67070 0x4764b22b960 , 5:3_http://zjbwg.cdstm.cn/, 0, , 763 0x7feae4d67070 0x4764a5d7fe0 
[1:1:0711/102525.997057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102525.997606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102525.997779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.032089:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 760, 7feae76ac881
[1:1:0711/102526.059003:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"751 0x7feae4d67070 0x4764a7d20e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.059340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"751 0x7feae4d67070 0x4764a7d20e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.059691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.060244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102526.060421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.061080:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102526.061240:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102526.061598:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 768
[1:1:0711/102526.061786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 768 0x7feae4d67070 0x4764b2282e0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 760 0x7feae4d67070 0x4764b35e0e0 
[1:1:0711/102526.063172:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 765, 7feae76ac8db
[1:1:0711/102526.078155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"763 0x7feae4d67070 0x4764a5d7fe0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.078359:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"763 0x7feae4d67070 0x4764a5d7fe0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.078571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 769
[1:1:0711/102526.078678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7feae4d67070 0x4764a3601e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 765 0x7feae4d67070 0x4764b22b960 
[1:1:0711/102526.078831:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.079224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.079327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.113752:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 769, 7feae76ac8db
[1:1:0711/102526.122086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"765 0x7feae4d67070 0x4764b22b960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.122206:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"765 0x7feae4d67070 0x4764b22b960 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.122383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 771
[1:1:0711/102526.122486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 771 0x7feae4d67070 0x4764a790b60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 769 0x7feae4d67070 0x4764a3601e0 
[1:1:0711/102526.122629:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.122988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.123114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.158605:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 771, 7feae76ac8db
[1:1:0711/102526.175871:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"769 0x7feae4d67070 0x4764a3601e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.176098:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"769 0x7feae4d67070 0x4764a3601e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.176334:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 773
[1:1:0711/102526.176447:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 773 0x7feae4d67070 0x4764af76260 , 5:3_http://zjbwg.cdstm.cn/, 0, , 771 0x7feae4d67070 0x4764a790b60 
[1:1:0711/102526.176594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.176953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.177071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.178577:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 768, 7feae76ac881
[1:1:0711/102526.187417:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"760 0x7feae4d67070 0x4764b35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.187592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"760 0x7feae4d67070 0x4764b35e0e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.187779:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.188084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102526.188190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.188487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102526.188587:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102526.188757:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 775
[1:1:0711/102526.188865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7feae4d67070 0x4764a88fb60 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 768 0x7feae4d67070 0x4764b2282e0 
[1:1:0711/102526.190147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 773, 7feae76ac8db
[1:1:0711/102526.218737:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"771 0x7feae4d67070 0x4764a790b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.219062:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"771 0x7feae4d67070 0x4764a790b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.219457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 777
[1:1:0711/102526.219645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 777 0x7feae4d67070 0x4764af7f7e0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 773 0x7feae4d67070 0x4764af76260 
[1:1:0711/102526.219939:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.220542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.220720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.258157:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 777, 7feae76ac8db
[1:1:0711/102526.287454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"773 0x7feae4d67070 0x4764af76260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.287778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"773 0x7feae4d67070 0x4764af76260 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.288207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 779
[1:1:0711/102526.288406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 779 0x7feae4d67070 0x4764a7f8f60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 777 0x7feae4d67070 0x4764af7f7e0 
[1:1:0711/102526.288659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.289259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.289438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.293866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 775, 7feae76ac881
[1:1:0711/102526.324650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"768 0x7feae4d67070 0x4764b2282e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.325001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"768 0x7feae4d67070 0x4764b2282e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.325361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.325885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102526.326080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.326724:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102526.326881:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102526.327263:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 782
[1:1:0711/102526.327456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 782 0x7feae4d67070 0x4764a968de0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 775 0x7feae4d67070 0x4764a88fb60 
[1:1:0711/102526.328787:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 779, 7feae76ac8db
[1:1:0711/102526.357851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"777 0x7feae4d67070 0x4764af7f7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.358201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"777 0x7feae4d67070 0x4764af7f7e0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.358594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 783
[1:1:0711/102526.358797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7feae4d67070 0x4764a88eee0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 779 0x7feae4d67070 0x4764a7f8f60 
[1:1:0711/102526.359114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.359694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.359878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.386511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 783, 7feae76ac8db
[1:1:0711/102526.404264:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"779 0x7feae4d67070 0x4764a7f8f60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.404427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"779 0x7feae4d67070 0x4764a7f8f60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.404629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 785
[1:1:0711/102526.404738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7feae4d67070 0x4764a7c4de0 , 5:3_http://zjbwg.cdstm.cn/, 0, , 783 0x7feae4d67070 0x4764a88eee0 
[1:1:0711/102526.404889:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.405259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.405365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.434442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 785, 7feae76ac8db
[1:1:0711/102526.442948:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"783 0x7feae4d67070 0x4764a88eee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.443190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"783 0x7feae4d67070 0x4764a88eee0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.443395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 788
[1:1:0711/102526.443508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7feae4d67070 0x4764aa2eb60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 785 0x7feae4d67070 0x4764a7c4de0 
[1:1:0711/102526.443672:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.444034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.444144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.445612:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 782, 7feae76ac881
[1:1:0711/102526.454441:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"775 0x7feae4d67070 0x4764a88fb60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.454594:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"775 0x7feae4d67070 0x4764a88fb60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.454768:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.455051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102526.455158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.455448:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102526.455545:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102526.455709:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 789
[1:1:0711/102526.455824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7feae4d67070 0x4764a88fae0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 782 0x7feae4d67070 0x4764a968de0 
[1:1:0711/102526.456302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 788, 7feae76ac8db
[1:1:0711/102526.470838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"785 0x7feae4d67070 0x4764a7c4de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.471046:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"785 0x7feae4d67070 0x4764a7c4de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.471257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 791
[1:1:0711/102526.471362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7feae4d67070 0x4764aa39b60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 788 0x7feae4d67070 0x4764aa2eb60 
[1:1:0711/102526.471502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.471841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.471941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.548821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 791, 7feae76ac8db
[1:1:0711/102526.569731:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"788 0x7feae4d67070 0x4764aa2eb60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.570009:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"788 0x7feae4d67070 0x4764aa2eb60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.570419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 795
[1:1:0711/102526.570628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7feae4d67070 0x4764aa2fa60 , 5:3_http://zjbwg.cdstm.cn/, 0, , 791 0x7feae4d67070 0x4764aa39b60 
[1:1:0711/102526.570880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.571500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.571677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.575985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 789, 7feae76ac881
[1:1:0711/102526.603977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d6b5ec42860","ptid":"782 0x7feae4d67070 0x4764a968de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.604326:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://zjbwg.cdstm.cn/","ptid":"782 0x7feae4d67070 0x4764a968de0 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.604669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.605225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/102526.605398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
[1:1:0711/102526.606006:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1c4faeba29c8, 0x4764a2b7150
[1:1:0711/102526.606183:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://zjbwg.cdstm.cn/index.php", 100
[1:1:0711/102526.606514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://zjbwg.cdstm.cn/, 797
[1:1:0711/102526.606694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7feae4d67070 0x4764ab1eae0 , 5:3_http://zjbwg.cdstm.cn/, 1, -5:3_http://zjbwg.cdstm.cn/, 789 0x7feae4d67070 0x4764a88fae0 
[1:1:0711/102526.607945:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 795, 7feae76ac8db
[1:1:0711/102526.641697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"791 0x7feae4d67070 0x4764aa39b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.642069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"791 0x7feae4d67070 0x4764aa39b60 ","rf":"5:3_http://zjbwg.cdstm.cn/"}
[1:1:0711/102526.642562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://zjbwg.cdstm.cn/, 799
[1:1:0711/102526.642795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7feae4d67070 0x4764a7c1960 , 5:3_http://zjbwg.cdstm.cn/, 0, , 795 0x7feae4d67070 0x4764aa2fa60 
[1:1:0711/102526.643179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://zjbwg.cdstm.cn/index.php"
[1:1:0711/102526.643903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zjbwg.cdstm.cn/, 1d6b5ec42860, , , slider.s1.run();
[1:1:0711/102526.644139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zjbwg.cdstm.cn/index.php", "zjbwg.cdstm.cn", 3, 1, , , 0
