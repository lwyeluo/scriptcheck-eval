[0712/155146.606164:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155146.606582:INFO:switcher_clone.cc(787)] backtrace rip is 7fa033a2a891
[0712/155147.630387:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155147.630795:INFO:switcher_clone.cc(787)] backtrace rip is 7f16014de891
[1:1:0712/155147.643255:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/155147.643573:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/155147.650898:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/155149.332098:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155149.332390:INFO:switcher_clone.cc(787)] backtrace rip is 7fba7cdd2891
[35158:35158:0712/155149.359029:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6e504589-2360-4b18-a579-66773d4fd4a1
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[35190:35190:0712/155149.604880:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35190
[35203:35203:0712/155149.605425:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35203
[35158:35158:0712/155149.997727:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[35158:35188:0712/155149.998494:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/155149.998697:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155149.998988:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155149.999593:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155149.999749:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/155150.002708:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x25320c06, 1
[1:1:0712/155150.003020:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x4fae5ed, 0
[1:1:0712/155150.003199:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x20aaba9b, 3
[1:1:0712/155150.003378:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3a1a8b3d, 2
[1:1:0712/155150.003561:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffedffffffe5fffffffa04 060c3225 3dffffff8b1a3a ffffff9bffffffbaffffffaa20 , 10104, 4
[1:1:0712/155150.004517:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35158:35188:0712/155150.004750:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���2%=�:��� c��&
[35158:35188:0712/155150.004821:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���2%=�:��� �Uc��&
[1:1:0712/155150.004735:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f15ff7190a0, 3
[1:1:0712/155150.004952:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f15ff8a4080, 2
[35158:35188:0712/155150.005125:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/155150.005104:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f15e9567d20, -2
[35158:35188:0712/155150.005234:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35211, 4, ede5fa04 060c3225 3d8b1a3a 9bbaaa20 
[1:1:0712/155150.023585:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155150.024519:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3a1a8b3d
[1:1:0712/155150.025480:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3a1a8b3d
[1:1:0712/155150.026553:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3a1a8b3d
[1:1:0712/155150.027095:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.027250:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.027361:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.027467:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.027705:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3a1a8b3d
[1:1:0712/155150.027848:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f16014de7ba
[1:1:0712/155150.027926:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f16014d5def, 7f16014de77a, 7f16014e00cf
[1:1:0712/155150.029417:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3a1a8b3d
[1:1:0712/155150.029577:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3a1a8b3d
[1:1:0712/155150.029854:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3a1a8b3d
[1:1:0712/155150.030567:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.030681:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.030779:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.030878:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a1a8b3d
[1:1:0712/155150.031360:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3a1a8b3d
[1:1:0712/155150.031521:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f16014de7ba
[1:1:0712/155150.031598:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f16014d5def, 7f16014de77a, 7f16014e00cf
[1:1:0712/155150.033793:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155150.034080:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155150.034223:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffe73cc218, 0x7fffe73cc198)
[1:1:0712/155150.049613:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155150.054749:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[35158:35158:0712/155150.757955:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35158:35158:0712/155150.759346:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35158:35170:0712/155150.781579:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[35158:35170:0712/155150.781680:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[35158:35158:0712/155150.781818:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[35158:35158:0712/155150.781899:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[35158:35158:0712/155150.782042:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,35211, 4
[1:7:0712/155150.783799:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[35158:35183:0712/155150.834362:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/155150.883583:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xb7a0c741220
[1:1:0712/155150.883853:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/155151.312292:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/155153.223530:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155153.228749:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[35158:35158:0712/155153.273270:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[35158:35158:0712/155153.273354:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155154.676829:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155154.828339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ad1b2ec1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155154.828652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155154.844760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ad1b2ec1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155154.844959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155155.123278:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155155.123502:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155155.605547:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155155.615490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ad1b2ec1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155155.615840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155155.659525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155155.672379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ad1b2ec1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155155.672648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155155.687295:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[35158:35158:0712/155155.689992:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155155.690953:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb7a0c73fe20
[1:1:0712/155155.691131:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[35158:35158:0712/155155.702040:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[35158:35158:0712/155155.741332:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[35158:35158:0712/155155.741529:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155155.760648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155156.351820:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f15eb1422e0 0xb7a0c9b5e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155156.353210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ad1b2ec1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/155156.353506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155156.355058:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[35158:35158:0712/155156.423465:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155156.426562:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xb7a0c740820
[1:1:0712/155156.428109:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[35158:35158:0712/155156.432653:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/155156.448175:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/155156.448434:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[35158:35158:0712/155156.450565:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[35158:35158:0712/155156.472199:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35158:35158:0712/155156.475369:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35158:35170:0712/155156.483236:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[35158:35170:0712/155156.483329:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[35158:35158:0712/155156.483597:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[35158:35158:0712/155156.483693:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[35158:35158:0712/155156.483860:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,35211, 4
[1:7:0712/155156.487145:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[35158:35158:0712/155156.498690:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[35158:35188:0712/155156.499179:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/155156.499424:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155156.499685:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155156.500166:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155156.500330:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/155156.503694:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2dfd03ea, 1
[1:1:0712/155156.504115:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2041777c, 0
[1:1:0712/155156.504275:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3abc5a27, 3
[1:1:0712/155156.504431:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3d8bdf2f, 2
[1:1:0712/155156.504588:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7c774120 ffffffea03fffffffd2d 2fffffffdfffffff8b3d 275affffffbc3a , 10104, 5
[1:1:0712/155156.505576:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35158:35188:0712/155156.505847:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING|wA ��-/ߋ='Z�:��&
[35158:35188:0712/155156.505943:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is |wA ��-/ߋ='Z�:?��&
[1:1:0712/155156.505837:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f15ff7190a0, 3
[1:1:0712/155156.506068:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f15ff8a4080, 2
[35158:35188:0712/155156.506204:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35257, 5, 7c774120 ea03fd2d 2fdf8b3d 275abc3a 
[1:1:0712/155156.506270:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f15e9567d20, -2
[1:1:0712/155156.529683:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155156.530081:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d8bdf2f
[1:1:0712/155156.530409:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d8bdf2f
[1:1:0712/155156.531074:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d8bdf2f
[1:1:0712/155156.532560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.532757:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.532988:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.533181:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.533864:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d8bdf2f
[1:1:0712/155156.534193:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f16014de7ba
[1:1:0712/155156.534342:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f16014d5def, 7f16014de77a, 7f16014e00cf
[1:1:0712/155156.540436:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d8bdf2f
[1:1:0712/155156.540807:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d8bdf2f
[1:1:0712/155156.541574:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d8bdf2f
[1:1:0712/155156.543215:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.543365:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.543477:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.543581:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d8bdf2f
[1:1:0712/155156.544426:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d8bdf2f
[1:1:0712/155156.544886:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f16014de7ba
[1:1:0712/155156.545075:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f16014d5def, 7f16014de77a, 7f16014e00cf
[1:1:0712/155156.554592:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155156.555189:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155156.555377:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffe73cc218, 0x7fffe73cc198)
[1:1:0712/155156.570243:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155156.574454:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/155156.785279:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb7a0c702220
[1:1:0712/155156.785546:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/155157.052542:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[35158:35158:0712/155157.411882:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35158:35158:0712/155157.417585:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/155157.451004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 490 0x7f15eb1422e0 0xb7a0cafd5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155157.451866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ad1b2ec1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/155157.452198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155157.452967:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[35158:35170:0712/155157.455780:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[35158:35170:0712/155157.455875:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[35158:35158:0712/155157.464439:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://country.cnr.cn/
[35158:35158:0712/155157.464496:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://country.cnr.cn/, http://country.cnr.cn/focus/, 1
[35158:35158:0712/155157.464559:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://country.cnr.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 22:51:57 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip Accept-Ranges: bytes X-Via: 1.1 PS-SHA-0152e213:1 (Cdn Cache Server V2.0), 1.1 chk25:3 (Cdn Cache Server V2.0)  ,35257, 5
[1:7:0712/155157.468826:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155157.502570:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://country.cnr.cn/
[35158:35158:0712/155157.581360:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[35158:35158:0712/155157.581467:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/155157.604012:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[35158:35158:0712/155157.650067:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://country.cnr.cn/, http://country.cnr.cn/, 1
[35158:35158:0712/155157.650162:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://country.cnr.cn/, http://country.cnr.cn
[1:1:0712/155157.739577:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155157.873719:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155157.942335:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155157.961016:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155157.961276:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://country.cnr.cn/focus/"
[1:1:0712/155158.478245:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f15e921a070 0xb7a0c831a60 , "http://country.cnr.cn/focus/"
[1:1:0712/155158.479640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://country.cnr.cn/, 2d9ce98c2860, , , /*! Respond.js v1.4.2: min/max-width media query polyfill
 * Copyright 2014 Scott Jehl
 * Licensed u
[1:1:0712/155158.479936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://country.cnr.cn/focus/", "country.cnr.cn", 3, 1, , , 0
[1:1:0712/155158.487551:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155158.612584:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.122109, 413, 1
[1:1:0712/155158.612910:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155158.856340:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155158.856659:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://country.cnr.cn/focus/"
[1:1:0712/155158.859831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f15e921a070 0xb7a0c93e0e0 , "http://country.cnr.cn/focus/"
[1:1:0712/155158.862036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://country.cnr.cn/, 2d9ce98c2860, , , var cnr={"hbo":[{"contentid":351114101136774,"day":"2019-07-12","editorname":"晓杨","index":1,"nod
[1:1:0712/155158.862271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://country.cnr.cn/focus/", "country.cnr.cn", 3, 1, , , 0
[1:1:0712/155158.865460:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f15e921a070 0xb7a0c93e0e0 , "http://country.cnr.cn/focus/"
[1:1:0712/155158.893445:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0367801, 84, 1
[1:1:0712/155158.893814:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155159.087664:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155159.087978:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://country.cnr.cn/focus/"
[1:1:0712/155159.110773:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 239 0x7f15e921a070 0xb7a0c8a51e0 , "http://country.cnr.cn/focus/"
[1:1:0712/155159.173558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://country.cnr.cn/, 2d9ce98c2860, , , /*!
 * jQuery JavaScript Library v1.11.3
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://si
[1:1:0712/155159.173903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://country.cnr.cn/focus/", "country.cnr.cn", 3, 1, , , 0
[1:1:0712/155159.462694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 239 0x7f15e921a070 0xb7a0c8a51e0 , "http://country.cnr.cn/focus/"
[1:1:0712/155159.472655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 239 0x7f15e921a070 0xb7a0c8a51e0 , "http://country.cnr.cn/focus/"
[1:1:0712/155159.651329:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155159.655919:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155159.656426:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155159.656880:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155159.657449:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155159.783046:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 260, "http://country.cnr.cn/focus/"
[1:1:0712/155159.785160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://country.cnr.cn/, 2d9ce98c2860, , , var ROOTDM=[".cnr.cn",".radio.cn",".chipp.cn",".cnpps.org",".gmw.cn",".gmw.com.cn",".zfzz.org.cn",".
[1:1:0712/155159.785393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://country.cnr.cn/focus/", "country.cnr.cn", 3, 1, , , 0
[1:1:0712/155200.126964:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 260, "http://country.cnr.cn/focus/"
[1:1:0712/155200.181022:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://country.cnr.cn/focus/"
[1:1:0712/155203.433117:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://country.cnr.cn/focus/"
[1:1:0712/155203.433915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://country.cnr.cn/, 2d9ce98c2860, , _wdEC, (){}
[1:1:0712/155203.434146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://country.cnr.cn/focus/", "country.cnr.cn", 3, 1, , , 0
[1:1:0712/155231.209079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://country.cnr.cn/, 2d9ce98c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/155231.209399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://country.cnr.cn/focus/", "country.cnr.cn", 3, 1, , , 0
[35158:35158:0712/155231.651566:INFO:CONSOLE(334)] "Uncaught TypeError: Cannot read property 'url' of undefined", source: http://country.cnr.cn/focus/ (334)
[35158:35158:0712/155231.666001:INFO:CONSOLE(510)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cl2.webterren.com/webdig.js?z=7, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://country.cnr.cn/focus/ (510)
[35158:35158:0712/155231.670286:INFO:CONSOLE(510)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cl2.webterren.com/webdig.js?z=7, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://country.cnr.cn/focus/ (510)
[35158:35158:0712/155231.856586:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/155231.862705:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
