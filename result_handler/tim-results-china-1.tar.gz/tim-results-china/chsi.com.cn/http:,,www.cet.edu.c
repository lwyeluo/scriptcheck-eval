[0712/004301.534213:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/004301.534611:INFO:switcher_clone.cc(787)] backtrace rip is 7f732b8d7891
[0712/004302.445440:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/004302.445702:INFO:switcher_clone.cc(787)] backtrace rip is 7f08c7d1a891
[1:1:0712/004302.449864:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/004302.450053:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/004302.455344:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[46851:46851:0712/004303.541735:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/d6bfac1e-7916-419f-8266-e203ad59ca8d
[0712/004303.812244:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/004303.812766:INFO:switcher_clone.cc(787)] backtrace rip is 7f1bb0b7c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[46882:46882:0712/004304.022666:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=46882
[46894:46894:0712/004304.023100:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=46894
[46851:46851:0712/004304.047356:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[46851:46880:0712/004304.048206:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/004304.048462:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/004304.048738:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/004304.049402:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/004304.049616:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/004304.068310:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36a26e6b, 1
[1:1:0712/004304.068729:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x17b2a37b, 0
[1:1:0712/004304.068937:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x158623dd, 3
[1:1:0712/004304.069133:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e73b554, 2
[1:1:0712/004304.069368:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7bffffffa3ffffffb217 6b6effffffa236 54ffffffb5733e ffffffdd23ffffff8615 , 10104, 4
[1:1:0712/004304.070407:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[46851:46880:0712/004304.070698:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING{��kn�6T�s>�#���=
[46851:46880:0712/004304.070773:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is {��kn�6T�s>�#����=
[1:1:0712/004304.070680:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f08c5f550a0, 3
[1:1:0712/004304.070930:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f08c60e0080, 2
[46851:46880:0712/004304.071109:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[46851:46880:0712/004304.071170:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 46902, 4, 7ba3b217 6b6ea236 54b5733e dd238615 
[1:1:0712/004304.071119:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f08afda3d20, -2
[1:1:0712/004304.088450:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/004304.089303:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e73b554
[1:1:0712/004304.090227:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e73b554
[1:1:0712/004304.091517:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e73b554
[1:1:0712/004304.093055:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.093306:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.093525:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.093773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.094441:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e73b554
[1:1:0712/004304.094819:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f08c7d1a7ba
[1:1:0712/004304.095039:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f08c7d11def, 7f08c7d1a77a, 7f08c7d1c0cf
[1:1:0712/004304.100906:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e73b554
[1:1:0712/004304.101288:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e73b554
[1:1:0712/004304.102079:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e73b554
[1:1:0712/004304.104255:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.104594:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.104849:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.105109:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e73b554
[1:1:0712/004304.106428:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e73b554
[1:1:0712/004304.106809:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f08c7d1a7ba
[1:1:0712/004304.107012:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f08c7d11def, 7f08c7d1a77a, 7f08c7d1c0cf
[1:1:0712/004304.116232:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/004304.116741:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/004304.117750:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd25b15a18, 0x7ffd25b15998)
[1:1:0712/004304.135393:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/004304.142774:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[46851:46873:0712/004304.729402:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[46851:46851:0712/004304.764946:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46851:46851:0712/004304.766443:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46851:46861:0712/004304.785251:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[46851:46861:0712/004304.785433:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[46851:46851:0712/004304.785518:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[46851:46851:0712/004304.785622:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[46851:46851:0712/004304.785787:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,46902, 4
[1:7:0712/004304.787813:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/004304.859925:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x26520aee0220
[1:1:0712/004304.860394:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/004305.218941:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[46851:46851:0712/004307.240849:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[46851:46851:0712/004307.240965:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/004307.274342:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004307.277856:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004308.346063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10e0f8381f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/004308.346383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004308.376533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10e0f8381f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/004308.376797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004308.433198:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004308.598624:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004308.598910:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004308.827396:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004308.835588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10e0f8381f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/004308.835897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004308.870522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004308.881690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10e0f8381f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/004308.882125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004308.906617:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[46851:46851:0712/004308.908367:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/004308.912923:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x26520aedee20
[1:1:0712/004308.913371:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[46851:46851:0712/004308.916775:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[46851:46851:0712/004308.956174:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[46851:46851:0712/004308.956343:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/004308.961169:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004309.978773:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7f08b197e2e0 0x26520aeb71e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004309.980192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10e0f8381f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/004309.980470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004309.982018:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[46851:46851:0712/004310.052433:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/004310.052519:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x26520aedf820
[1:1:0712/004310.052834:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[46851:46851:0712/004310.066380:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/004310.071887:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/004310.072132:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[46851:46851:0712/004310.088588:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[46851:46851:0712/004310.094617:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46851:46851:0712/004310.095795:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46851:46861:0712/004310.102143:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[46851:46861:0712/004310.102226:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[46851:46851:0712/004310.102349:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[46851:46851:0712/004310.102428:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[46851:46851:0712/004310.102592:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,46902, 4
[1:7:0712/004310.105893:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/004310.706978:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/004310.997890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 490 0x7f08b197e2e0 0x26520b1908e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004310.999843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10e0f8381f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/004311.000239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004311.001671:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[46851:46851:0712/004311.094237:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[46851:46851:0712/004311.094372:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/004311.126144:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004311.713624:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[46851:46851:0712/004311.889022:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[46851:46880:0712/004311.889510:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/004311.889733:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/004311.890012:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/004311.890416:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/004311.890557:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/004311.893859:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x313568a8, 1
[1:1:0712/004311.894316:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x26a623c, 0
[1:1:0712/004311.894522:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x177605f5, 3
[1:1:0712/004311.894714:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x99f082c, 2
[1:1:0712/004311.894896:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3c626a02 ffffffa8683531 2c08ffffff9f09 fffffff5057617 , 10104, 5
[1:1:0712/004311.896252:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[46851:46880:0712/004311.896554:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING<bj�h51,�	�v��=
[46851:46880:0712/004311.896653:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is <bj�h51,�	�v�ᴱ=
[1:1:0712/004311.896538:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f08c5f550a0, 3
[1:1:0712/004311.897046:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f08c60e0080, 2
[46851:46880:0712/004311.897315:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 46947, 5, 3c626a02 a8683531 2c089f09 f5057617 
[1:1:0712/004311.897293:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f08afda3d20, -2
[1:1:0712/004311.922580:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/004311.922954:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 99f082c
[1:1:0712/004311.923360:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 99f082c
[1:1:0712/004311.924077:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 99f082c
[1:1:0712/004311.925700:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.925945:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.926219:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.926446:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.927176:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 99f082c
[1:1:0712/004311.927572:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f08c7d1a7ba
[1:1:0712/004311.927789:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f08c7d11def, 7f08c7d1a77a, 7f08c7d1c0cf
[1:1:0712/004311.930818:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 99f082c
[1:1:0712/004311.931319:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 99f082c
[1:1:0712/004311.932288:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 99f082c
[1:1:0712/004311.934850:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.935144:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.935385:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.935631:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 99f082c
[1:1:0712/004311.936941:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 99f082c
[1:1:0712/004311.937381:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f08c7d1a7ba
[1:1:0712/004311.937568:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f08c7d11def, 7f08c7d1a77a, 7f08c7d1c0cf
[1:1:0712/004311.946116:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/004311.946794:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/004311.947038:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd25b15a18, 0x7ffd25b15998)
[1:1:0712/004311.962326:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/004311.966303:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/004312.141611:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x26520aeb6220
[1:1:0712/004312.141910:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/004312.242699:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004312.243004:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[46851:46851:0712/004312.865985:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46851:46851:0712/004312.874965:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46851:46861:0712/004312.909531:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[46851:46861:0712/004312.909630:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[46851:46851:0712/004312.911353:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.cet.edu.cn/
[46851:46851:0712/004312.911451:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.cet.edu.cn/, http://www.cet.edu.cn/cet_kw1.htm, 1
[46851:46851:0712/004312.911614:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.cet.edu.cn/, HTTP/1.1 404 Not Found Server: OPTIMUS/1.11.2.4_20 Date: Fri, 12 Jul 2019 07:43:12 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive ETag: W/"55a8979f-55e" Content-Encoding: gzip Dnion-Transfer-Encoding: 1 Age: 0 Via: http/1.1 CMC-CT-CNC-GDFS-P-254-19 (DLC-6.1.26), http/1.1 CCKD-CNC-BJBJ-C-240-203 (DLC-6.1.26) Server-Info: DnionATS HitType: TCP_REFRESH_MISS  ,46947, 5
[1:7:0712/004312.917843:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/004312.932558:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.cet.edu.cn/
[1:1:0712/004312.942607:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://www.cet.edu.cn/cet_kw1.htm"
[1:1:0712/004312.948759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 573, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/004312.953415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 10e0f84b09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/004312.953743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/004312.962483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[46851:46851:0712/004313.093535:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.cet.edu.cn/, http://www.cet.edu.cn/, 1
[46851:46851:0712/004313.093656:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.cet.edu.cn/, http://www.cet.edu.cn
[1:1:0712/004313.121555:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004313.169794:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004313.170625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10e0f8381f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/004313.170874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004313.269217:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004313.363983:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004313.364265:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.cet.edu.cn/cet_kw1.htm"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004313.982128:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004314.008647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7f08afdbebd0 0x26520b0370d8 , "http://www.cet.edu.cn/cet_kw1.htm"
[1:1:0712/004314.014875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.cet.edu.cn/, 138cefb22860, , , function _write(s,b){if(b)b.innerHTML=s;else document.write(s);};

eval(function(p,a,c,k,e,d){e=fu
[1:1:0712/004314.015151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.cet.edu.cn/cet_kw1.htm", "www.cet.edu.cn", 3, 1, , , 0
[1:1:0712/004315.051114:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004315.065100:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/004315.074458:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x26520afba820
[1:1:0712/004315.074729:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/004315.109147:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.cet.edu.cn/cet_kw1.htm"
[1:1:0712/004315.354125:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7f08afa56070 0x26520b5060e0 , "http://www.cet.edu.cn/cet_kw1.htm"
[1:1:0712/004315.355650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.cet.edu.cn/, 138cefb22860, , , 
//>512/////////////////////////////////////////////////////////////////////////////////////////////
[1:1:0712/004315.355943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.cet.edu.cn/cet_kw1.htm", "www.cet.edu.cn", 3, 1, , , 0
[1:1:0712/004315.384809:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x806a03029c8, 0x26520ad3b9a0
[1:1:0712/004315.385091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.cet.edu.cn/cet_kw1.htm", 0
[1:1:0712/004315.385483:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.cet.edu.cn/, 168
[1:1:0712/004315.385706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 168 0x7f08afa56070 0x26520ad23fe0 , 5:3_http://www.cet.edu.cn/, 1, -5:3_http://www.cet.edu.cn/, 162 0x7f08afa56070 0x26520b5060e0 
[1:1:0712/004315.553975:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.cet.edu.cn/, 168, 7f08b239b881
[1:1:0712/004315.561940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"138cefb22860","ptid":"162 0x7f08afa56070 0x26520b5060e0 ","rf":"5:3_http://www.cet.edu.cn/"}
[1:1:0712/004315.562276:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.cet.edu.cn/","ptid":"162 0x7f08afa56070 0x26520b5060e0 ","rf":"5:3_http://www.cet.edu.cn/"}
[1:1:0712/004315.562648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.cet.edu.cn/cet_kw1.htm"
[1:1:0712/004315.563267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.cet.edu.cn/, 138cefb22860, , , (){var arr=new RegExp("html(\\d)/[a-z]+/(\\d+)/(\\d+)-(\\d+).htm").exec(location.pathname);if(arr){f
[1:1:0712/004315.563484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.cet.edu.cn/cet_kw1.htm", "www.cet.edu.cn", 3, 1, , , 0
[1:1:0712/004321.599290:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004321.599928:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004321.600409:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004321.603117:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004321.603532:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[46851:46851:0712/004329.083929:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[46851:46851:0712/004329.091900:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: _ajax, 4, 4, 
[46851:46851:0712/004329.118026:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://www.cet.edu.cn/, http://www.cet.edu.cn/, 4
[46851:46851:0712/004329.118194:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://www.cet.edu.cn/, http://www.cet.edu.cn
[46851:46851:0712/004329.638359:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/004329.644718:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[46851:46851:0712/004329.651780:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[46851:46851:0712/004351.606853:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[46851:46851:0712/004415.339676:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
