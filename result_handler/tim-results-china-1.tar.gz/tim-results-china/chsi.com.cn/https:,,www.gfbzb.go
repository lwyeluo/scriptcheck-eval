[0712/005050.911624:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/005050.912043:INFO:switcher_clone.cc(787)] backtrace rip is 7f76eb54f891
[0712/005051.786429:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/005051.786806:INFO:switcher_clone.cc(787)] backtrace rip is 7f17763b8891
[1:1:0712/005051.798596:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/005051.798896:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/005051.804204:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[48106:48106:0712/005052.966051:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/cb7cf3f0-cda3-4a10-be73-b72f5a9d4918
[0712/005053.179829:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/005053.180249:INFO:switcher_clone.cc(787)] backtrace rip is 7faa23b2c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[48106:48106:0712/005053.387340:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[48106:48136:0712/005053.390711:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/005053.390985:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/005053.391243:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/005053.392023:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/005053.392212:INFO:zygote_linux.cc(633)] 		cid is 4
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/005053.395699:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33d6b91, 1
[1:1:0712/005053.396128:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x320cdd4d, 0
[1:1:0712/005053.396319:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2362ccde, 3
[1:1:0712/005053.396522:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2bfa7bf7, 2
[1:1:0712/005053.396750:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4dffffffdd0c32 ffffff916b3d03 fffffff77bfffffffa2b ffffffdeffffffcc6223 , 10104, 4
[1:1:0712/005053.398006:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[48106:48136:0712/005053.398242:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGM�2�k=�{�+��b#%�J4
[48106:48136:0712/005053.398325:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is M�2�k=�{�+��b#��%�J4
[48106:48136:0712/005053.398719:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[48106:48136:0712/005053.398833:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 48151, 4, 4ddd0c32 916b3d03 f77bfa2b decc6223 
[1:1:0712/005053.399360:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f17745f30a0, 3
[1:1:0712/005053.399615:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f177477e080, 2
[1:1:0712/005053.399856:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f175e441d20, -2
[48138:48138:0712/005053.409608:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=48138
[48152:48152:0712/005053.410085:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=48152
[1:1:0712/005053.422954:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/005053.423999:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2bfa7bf7
[1:1:0712/005053.425174:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2bfa7bf7
[1:1:0712/005053.427177:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2bfa7bf7
[1:1:0712/005053.429040:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.429291:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.429551:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.429810:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.430583:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2bfa7bf7
[1:1:0712/005053.431005:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f17763b87ba
[1:1:0712/005053.431179:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f17763afdef, 7f17763b877a, 7f17763ba0cf
[1:1:0712/005053.437537:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2bfa7bf7
[1:1:0712/005053.437925:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2bfa7bf7
[1:1:0712/005053.438688:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2bfa7bf7
[1:1:0712/005053.440726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.440943:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.441128:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.441338:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2bfa7bf7
[1:1:0712/005053.442574:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2bfa7bf7
[1:1:0712/005053.442947:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f17763b87ba
[1:1:0712/005053.443084:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f17763afdef, 7f17763b877a, 7f17763ba0cf
[1:1:0712/005053.451441:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/005053.451966:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/005053.452114:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe1c2b8e58, 0x7ffe1c2b8dd8)
[1:1:0712/005053.467363:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/005053.474971:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[48106:48130:0712/005054.089730:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[48106:48106:0712/005054.119087:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[48106:48106:0712/005054.119567:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[48106:48106:0712/005054.129577:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[48106:48106:0712/005054.129666:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[48106:48117:0712/005054.129701:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[48106:48106:0712/005054.129732:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,48151, 4
[48106:48117:0712/005054.129834:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/005054.132929:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/005054.158200:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3f5e99ac220
[1:1:0712/005054.158454:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/005054.602033:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[48106:48106:0712/005055.931388:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[48106:48106:0712/005055.931521:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/005055.984071:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005055.988755:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/005056.846600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bce73f01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/005056.846982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/005056.862977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bce73f01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/005056.863400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/005056.935786:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/005057.224078:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/005057.224367:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/005057.406457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/005057.409088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bce73f01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/005057.409212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/005057.425033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/005057.431642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bce73f01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/005057.431845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/005057.443811:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[48106:48106:0712/005057.446052:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/005057.448217:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f5e99aae20
[1:1:0712/005057.448383:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[48106:48106:0712/005057.453216:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[48106:48106:0712/005057.484842:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[48106:48106:0712/005057.485035:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/005057.550791:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/005058.210976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f176001c2e0 0x3f5e9c3fe60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/005058.212542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bce73f01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/005058.212886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/005058.215514:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[48106:48106:0712/005058.290403:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/005058.293542:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3f5e99ab820
[1:1:0712/005058.297303:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[48106:48106:0712/005058.300186:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/005058.319861:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/005058.320063:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[48106:48106:0712/005058.321250:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[48106:48106:0712/005058.332607:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[48106:48106:0712/005058.333659:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[48106:48117:0712/005058.339828:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[48106:48117:0712/005058.339918:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[48106:48106:0712/005058.340070:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[48106:48106:0712/005058.340171:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[48106:48106:0712/005058.340312:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,48151, 4
[1:7:0712/005058.345227:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/005058.904534:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/005059.530961:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f176001c2e0 0x3f5e9c7ae60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/005059.532070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bce73f01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/005059.532282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/005059.533072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[48106:48106:0712/005059.637966:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[48106:48106:0712/005059.638118:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/005059.673458:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/005100.134970:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/005100.572033:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/005100.572326:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/005100.987416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/005100.993068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1bce74030640, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/005100.993400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/005101.003053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[48106:48106:0712/005101.127278:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[48106:48136:0712/005101.127847:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/005101.128181:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/005101.128441:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/005101.128941:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/005101.129119:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/005101.132816:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36c6daae, 1
[1:1:0712/005101.133351:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x140a3bd6, 0
[1:1:0712/005101.133549:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x279103ab, 3
[1:1:0712/005101.133732:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e401268, 2
[1:1:0712/005101.133946:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd63b0a14 ffffffaeffffffdaffffffc636 6812403e ffffffab03ffffff9127 , 10104, 5
[1:1:0712/005101.134642:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[48106:48136:0712/005101.134790:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�;
���6h@>��'�J4
[48106:48136:0712/005101.134833:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �;
���6h@>��'8
[1:1:0712/005101.134947:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f17745f30a0, 3
[48106:48136:0712/005101.135140:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 48203, 5, d63b0a14 aedac636 6812403e ab039127 
[1:1:0712/005101.135197:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f177477e080, 2
[1:1:0712/005101.135406:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f175e441d20, -2
[1:1:0712/005101.154942:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/005101.155442:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e401268
[1:1:0712/005101.155928:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e401268
[1:1:0712/005101.156758:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e401268
[1:1:0712/005101.158598:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.158885:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.159162:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.159413:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.160349:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e401268
[1:1:0712/005101.160712:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f17763b87ba
[1:1:0712/005101.160892:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f17763afdef, 7f17763b877a, 7f17763ba0cf
[1:1:0712/005101.165854:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e401268
[1:1:0712/005101.166152:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e401268
[1:1:0712/005101.166690:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e401268
[1:1:0712/005101.168864:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.169100:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.169284:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.169518:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e401268
[1:1:0712/005101.171104:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e401268
[1:1:0712/005101.171562:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f17763b87ba
[1:1:0712/005101.171793:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f17763afdef, 7f17763b877a, 7f17763ba0cf
[1:1:0712/005101.181755:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/005101.182539:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/005101.182705:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe1c2b8e58, 0x7ffe1c2b8dd8)
[1:1:0712/005101.199661:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/005101.204817:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/005101.213744:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/005101.214502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bce73f01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/005101.214723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/005101.485078:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f5e997e220
[1:1:0712/005101.485344:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/005101.521317:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/005101.522936:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/005101.523179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1bce74030640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/005101.523452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/005101.650633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/005101.651567:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/005101.651786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1bce74030640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/005101.652085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[48106:48106:0712/005102.021182:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[48106:48106:0712/005102.029677:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[48106:48117:0712/005102.064803:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[48106:48117:0712/005102.064905:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[48106:48106:0712/005102.065307:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.gfbzb.gov.cn/
[48106:48106:0712/005102.065409:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.gfbzb.gov.cn/, https://www.gfbzb.gov.cn/zcfg/index.action, 1
[48106:48106:0712/005102.065584:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.gfbzb.gov.cn/, HTTP/1.1 200 Date: Fri, 12 Jul 2019 07:51:01 GMT Content-Type: text/html;charset=utf-8 Connection: keep-alive Set-Cookie: XSRF-CCKTOKEN=db1b6fe2c8c83fb065f1a211e1c6af11; Path=/; Secure; HttpOnly Set-Cookie: JSESSIONID=D1D125286A8F5D86A08FE979B674EE20; Path=/; Secure; HttpOnly Strict-Transport-Security: max-age=31536000 Content-Encoding: gzip Set-Cookie: CHSICC02=!weUq7u01GxnU7BQGGYWrKFjgWJfD//5j0tAWbgxsm9R21yLWcr3QtfMlZ9Yt62+xnZS4gNV1orjRoA==; path=/; Httponly Set-Cookie: TS0184979e=01886fbf6e86d6c643c0fc064ef459ba42cdbc6cdf85873d3b9968063cb7b411c3ff77bbc6de5286ebc21ecc6224d69c6b20b19c1910b63cbc97c9e781cd1dd891088aeb53dee46c160dd32a44bf743c9c8ca3324da8179182729b2db4cca2c5b3d30fb57d; Path=/; Domain=.www.gfbzb.gov.cn Transfer-Encoding: chunked Set-Cookie: CHSICC01=!GXYV8Gy+vKBMk8oGGYWrKFjgWJfD/5dXom2JYqCyGG8xFKtHa6LZ3X+dOyJRhIQfp3CQOp4GiWEUzg==; path=/; Httponly; Secure  ,48203, 5
[1:7:0712/005102.069618:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/005102.106758:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.gfbzb.gov.cn/
[1:1:0712/005102.220786:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[48106:48106:0712/005102.250249:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.gfbzb.gov.cn/, https://www.gfbzb.gov.cn/, 1
[48106:48106:0712/005102.250400:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.gfbzb.gov.cn/, https://www.gfbzb.gov.cn
[1:1:0712/005102.288551:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/005102.329444:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/005102.329647:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005102.475799:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/005102.516475:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/005102.622447:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0712/005102.653041:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0712/005102.765047:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0712/005102.808375:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0712/005102.886164:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005102.901796:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0712/005102.980977:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0712/005103.152705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f175e45cbd0 0x3f5e9b760d8 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005103.155785:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005103.165214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};ret
[1:1:0712/005103.165431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005103.186416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/005103.187311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1bce74030640, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/005103.187599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
		remove user.f_89c8b8c4 -> 0
[1:1:0712/005103.309014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f175e45cbd0 0x3f5e9b760d8 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005103.368234:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f175e45cbd0 0x3f5e9b760d8 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005103.370239:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f175e45cbd0 0x3f5e9b760d8 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005103.373049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f175e45cbd0 0x3f5e9b760d8 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005103.374894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f175e45cbd0 0x3f5e9b760d8 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005103.377716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f175e45cbd0 0x3f5e9b760d8 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005103.496982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.gfbzb.gov.cn/zcfg/index.action"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/005104.733128:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005104.736136:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005104.736503:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005104.736990:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005104.737318:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005105.239606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f176001c2e0 0x3f5e9b786e0 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005105.249823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0712/005105.250083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005105.295763:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4553cae29c8, 0x3f5e97f8960
[1:1:0712/005105.296045:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.gfbzb.gov.cn/zcfg/index.action", 0
[1:1:0712/005105.296453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.gfbzb.gov.cn/, 266
[1:1:0712/005105.296649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 266 0x7f175e0f4070 0x3f5e9b959e0 , 5:3_https://www.gfbzb.gov.cn/, 1, -5:3_https://www.gfbzb.gov.cn/, 262 0x7f176001c2e0 0x3f5e9b786e0 
[1:1:0712/005105.297961:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4553cae29c8, 0x3f5e97f8960
[1:1:0712/005105.298149:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.gfbzb.gov.cn/zcfg/index.action", 0
[1:1:0712/005105.298518:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.gfbzb.gov.cn/, 267
[1:1:0712/005105.298719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 267 0x7f175e0f4070 0x3f5e9c7fa60 , 5:3_https://www.gfbzb.gov.cn/, 1, -5:3_https://www.gfbzb.gov.cn/, 262 0x7f176001c2e0 0x3f5e9b786e0 
[1:1:0712/005105.345269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005105.346039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0712/005105.346276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005105.346772:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005105.347937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4553cae29c8, 0x3f5e97f89f0
[1:1:0712/005105.348176:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.gfbzb.gov.cn/zcfg/index.action", 0
[1:1:0712/005105.348576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.gfbzb.gov.cn/, 274
[1:1:0712/005105.348797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 274 0x7f175e0f4070 0x3f5e9a474e0 , 5:3_https://www.gfbzb.gov.cn/, 1, -5:3_https://www.gfbzb.gov.cn/, 268 0x7f175e0f4070 0x3f5e9c5cc60 
[1:1:0712/005105.390114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.gfbzb.gov.cn/, 266, 7f1760a39881
[1:1:0712/005105.402917:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a6a8e02860","ptid":"262 0x7f176001c2e0 0x3f5e9b786e0 ","rf":"5:3_https://www.gfbzb.gov.cn/"}
[1:1:0712/005105.403263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.gfbzb.gov.cn/","ptid":"262 0x7f176001c2e0 0x3f5e9b786e0 ","rf":"5:3_https://www.gfbzb.gov.cn/"}
[1:1:0712/005105.403625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005105.404249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0712/005105.404462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005105.666892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.gfbzb.gov.cn/, 267, 7f1760a39881
[1:1:0712/005105.681970:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a6a8e02860","ptid":"262 0x7f176001c2e0 0x3f5e9b786e0 ","rf":"5:3_https://www.gfbzb.gov.cn/"}
[1:1:0712/005105.682375:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.gfbzb.gov.cn/","ptid":"262 0x7f176001c2e0 0x3f5e9b786e0 ","rf":"5:3_https://www.gfbzb.gov.cn/"}
[1:1:0712/005105.682789:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005105.683389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0712/005105.683612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005105.783079:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.gfbzb.gov.cn/, 274, 7f1760a39881
[1:1:0712/005105.794789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a6a8e02860","ptid":"268 0x7f175e0f4070 0x3f5e9c5cc60 ","rf":"5:3_https://www.gfbzb.gov.cn/"}
[1:1:0712/005105.795160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.gfbzb.gov.cn/","ptid":"268 0x7f175e0f4070 0x3f5e9c5cc60 ","rf":"5:3_https://www.gfbzb.gov.cn/"}
[1:1:0712/005105.795544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005105.796125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , , (){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))}
[1:1:0712/005105.796423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005105.867512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7f176001c2e0 0x3f5e9a92060 , "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005105.874357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0712/005105.874611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005106.527284:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005106.982272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.gfbzb.gov.cn/zcfg/index.action"
[1:1:0712/005106.982956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0712/005106.983183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[1:1:0712/005117.786440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.gfbzb.gov.cn/, 06a6a8e02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/005117.786601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.gfbzb.gov.cn/zcfg/index.action", "www.gfbzb.gov.cn", 3, 1, , , 0
[48106:48106:0712/005118.279740:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/005118.290404:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/005120.061565:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/005120.062153:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
