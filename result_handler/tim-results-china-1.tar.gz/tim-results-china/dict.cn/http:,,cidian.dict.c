[0712/090323.028191:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/090323.028681:INFO:switcher_clone.cc(787)] backtrace rip is 7f08b1a3c891
[0712/090323.948948:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/090323.949341:INFO:switcher_clone.cc(787)] backtrace rip is 7fc5e3aa0891
[1:1:0712/090323.961177:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/090323.961451:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/090323.966744:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/090325.414992:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/090325.415395:INFO:switcher_clone.cc(787)] backtrace rip is 7f2676f0d891
[112749:112749:0712/090325.529067:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/37d8e047-6a7f-4a64-8857-5e30c4bcbc52
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[112781:112781:0712/090325.629235:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=112781
[112793:112793:0712/090325.629624:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=112793
[112749:112749:0712/090325.974944:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[112749:112779:0712/090325.975756:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/090325.975973:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/090325.976328:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/090325.977100:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/090325.977307:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/090325.979862:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x18688903, 1
[1:1:0712/090325.980118:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x595286, 0
[1:1:0712/090325.980243:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1075e0c6, 3
[1:1:0712/090325.980340:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x10c1acf0, 2
[1:1:0712/090325.980453:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff86525900 03ffffff896818 fffffff0ffffffacffffffc110 ffffffc6ffffffe07510 , 10104, 4
[1:1:0712/090325.981146:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[112749:112779:0712/090325.981288:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�RY
[112749:112779:0712/090325.981326:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �RY
[112749:112779:0712/090325.981487:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[112749:112779:0712/090325.981520:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 112801, 4, 86525900 03896818 f0acc110 c6e07510 
[1:1:0712/090325.981757:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc5e1cdb0a0, 3
[1:1:0712/090325.981890:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc5e1e66080, 2
[1:1:0712/090325.981978:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc5cbb29d20, -2
[1:1:0712/090325.991831:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/090325.992798:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10c1acf0
[1:1:0712/090325.993766:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10c1acf0
[1:1:0712/090325.995463:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10c1acf0
[1:1:0712/090325.997044:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090325.997276:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090325.997460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090325.997653:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090325.998319:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10c1acf0
[1:1:0712/090325.998645:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5e3aa07ba
[1:1:0712/090325.998778:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5e3a97def, 7fc5e3aa077a, 7fc5e3aa20cf
[1:1:0712/090326.002725:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10c1acf0
[1:1:0712/090326.002912:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10c1acf0
[1:1:0712/090326.003204:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10c1acf0
[1:1:0712/090326.003899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090326.004011:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090326.004140:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090326.004243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10c1acf0
[1:1:0712/090326.004697:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10c1acf0
[1:1:0712/090326.004865:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5e3aa07ba
[1:1:0712/090326.004943:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5e3a97def, 7fc5e3aa077a, 7fc5e3aa20cf
[1:1:0712/090326.010693:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/090326.011218:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/090326.011398:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe5f1eed28, 0x7ffe5f1eeca8)
[1:1:0712/090326.029804:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/090326.037021:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[112749:112749:0712/090326.670103:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[112749:112749:0712/090326.671512:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[112749:112760:0712/090326.693814:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[112749:112760:0712/090326.693918:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[112749:112749:0712/090326.694138:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[112749:112749:0712/090326.694236:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[112749:112749:0712/090326.694430:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,112801, 4
[1:7:0712/090326.697092:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[112749:112773:0712/090326.732690:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/090326.849770:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3a1b76bb7220
[1:1:0712/090326.850090:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/090327.208308:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[112749:112749:0712/090328.772152:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[112749:112749:0712/090328.772312:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/090328.815381:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090328.820005:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090329.717264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 316c4ae21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/090329.717579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090329.734614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 316c4ae21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/090329.734913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090329.803757:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090330.169220:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090330.169509:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090330.528269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090330.536562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 316c4ae21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/090330.536851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090330.572570:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090330.585096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 316c4ae21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/090330.585395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090330.597347:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[112749:112749:0712/090330.600983:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/090330.601330:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3a1b76bb5e20
[1:1:0712/090330.601570:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[112749:112749:0712/090330.610087:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[112749:112749:0712/090330.648597:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[112749:112749:0712/090330.648759:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/090330.703255:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090331.504846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7fc5cd7042e0 0x3a1b76e4b0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090331.506207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 316c4ae21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/090331.506463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090331.507945:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[112749:112749:0712/090331.553965:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/090331.555604:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3a1b76bb6820
[1:1:0712/090331.555882:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[112749:112749:0712/090331.567425:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/090331.573127:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/090331.573405:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[112749:112749:0712/090331.582327:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[112749:112749:0712/090331.587273:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[112749:112749:0712/090331.588600:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[112749:112760:0712/090331.594118:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[112749:112760:0712/090331.594213:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[112749:112749:0712/090331.594481:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[112749:112749:0712/090331.594582:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[112749:112749:0712/090331.594762:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,112801, 4
[1:7:0712/090331.598303:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/090332.137406:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/090332.376560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fc5cd7042e0 0x3a1b76c66b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090332.377640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 316c4ae21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/090332.377887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090332.378684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090332.519771:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[112749:112749:0712/090332.533973:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[112749:112749:0712/090332.534077:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/090332.873670:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[112749:112749:0712/090333.016316:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[112749:112779:0712/090333.016827:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/090333.017062:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/090333.017301:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/090333.017778:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/090333.017948:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/090333.021637:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x212612d6, 1
[1:1:0712/090333.022166:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x6e62c22, 0
[1:1:0712/090333.022379:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c4c7d98, 3
[1:1:0712/090333.022618:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x16fdc4e9, 2
[1:1:0712/090333.022877:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 222cffffffe606 ffffffd6122621 ffffffe9ffffffc4fffffffd16 ffffff987d4c1c , 10104, 5
[1:1:0712/090333.023985:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[112749:112779:0712/090333.024335:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING",��&!����}L�
 
[112749:112779:0712/090333.024409:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ",��&!����}Lhy�
 
[1:1:0712/090333.024536:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc5e1cdb0a0, 3
[112749:112779:0712/090333.024759:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 112846, 5, 222ce606 d6122621 e9c4fd16 987d4c1c 
[1:1:0712/090333.024823:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc5e1e66080, 2
[1:1:0712/090333.025128:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc5cbb29d20, -2
[1:1:0712/090333.038644:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/090333.039039:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 16fdc4e9
[1:1:0712/090333.039368:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 16fdc4e9
[1:1:0712/090333.039916:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 16fdc4e9
[1:1:0712/090333.041366:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.041609:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.041848:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.042072:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.042784:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 16fdc4e9
[1:1:0712/090333.043118:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5e3aa07ba
[1:1:0712/090333.043293:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5e3a97def, 7fc5e3aa077a, 7fc5e3aa20cf
[1:1:0712/090333.049097:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 16fdc4e9
[1:1:0712/090333.049485:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 16fdc4e9
[1:1:0712/090333.050250:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 16fdc4e9
[1:1:0712/090333.052353:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.053950:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.054182:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.054423:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16fdc4e9
[1:1:0712/090333.057008:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 16fdc4e9
[1:1:0712/090333.057422:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc5e3aa07ba
[1:1:0712/090333.057604:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc5e3a97def, 7fc5e3aa077a, 7fc5e3aa20cf
[1:1:0712/090333.065558:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/090333.066150:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/090333.066339:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe5f1eed28, 0x7ffe5f1eeca8)
[1:1:0712/090333.120023:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/090333.125983:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/090333.197965:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090333.198692:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[112749:112749:0712/090333.369936:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[112749:112749:0712/090333.376745:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[112749:112760:0712/090333.386126:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[112749:112760:0712/090333.386224:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[112749:112749:0712/090333.386431:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://cidian.dict.cn/
[112749:112749:0712/090333.386471:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://cidian.dict.cn/, http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj, 1
[112749:112749:0712/090333.386523:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://cidian.dict.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:03:33 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Served: 26001. Content-Encoding: gzip  ,112846, 5
[1:7:0712/090333.388158:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/090333.425406:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3a1b76b8a220
[1:1:0712/090333.425710:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/090333.507309:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/090333.512005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 316c4af4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/090333.512315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/090333.520147:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/090333.643092:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://cidian.dict.cn/
[112749:112749:0712/090333.824391:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://cidian.dict.cn/, http://cidian.dict.cn/, 1
[112749:112749:0712/090333.824485:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://cidian.dict.cn/, http://cidian.dict.cn
[1:1:0712/090333.858215:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090333.955306:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090334.007531:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090334.008340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 316c4ae21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/090334.008574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090334.055600:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090334.055889:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090334.441605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 151 0x7fc5cb7dc070 0x3a1b76cb6060 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090334.443806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , var cur_dict = 'lwddgjyycd';var i1_home='http://i1.haidii.com';var xuehai_home='http://xuehai.cn';va
[1:1:0712/090334.444083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "cidian.dict.cn", 3, 1, , , 0
[1:1:0712/090334.471949:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
[1:1:0712/090334.481174:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154 0x7fc5e1e66080 0x3a1b76c22ba0 1 0 0x3a1b76c22bb8 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/090334.483680:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090334.493990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , (function(e,t){var n,r,i=typeof t,o=e.document,a=e.location,s=e.jQuery,u=e.$,l={},c=[],p="1.9.1",f=c
[1:1:0712/090334.494304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "cidian.dict.cn", 3, 1, , , 0
[1:1:0712/090334.712857:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154 0x7fc5e1e66080 0x3a1b76c22ba0 1 0 0x3a1b76c22bb8 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090334.725170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154 0x7fc5e1e66080 0x3a1b76c22ba0 1 0 0x3a1b76c22bb8 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090334.745197:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154 0x7fc5e1e66080 0x3a1b76c22ba0 1 0 0x3a1b76c22bb8 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090334.750310:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154 0x7fc5e1e66080 0x3a1b76c22ba0 1 0 0x3a1b76c22bb8 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090334.810477:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.134338, 208, 1
[1:1:0712/090334.810752:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090335.396117:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090335.396438:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090335.397587:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200 0x7fc5cb7dc070 0x3a1b76e1f660 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090335.398806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , 
	var langt='';
	var cur_dict = 'lwddgjyycd', i1_home='http://i1.haidii.com', xuehai_home='http://xu
[1:1:0712/090335.399035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "cidian.dict.cn", 3, 1, , , 0
[1:1:0712/090335.401629:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200 0x7fc5cb7dc070 0x3a1b76e1f660 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090335.407413:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200 0x7fc5cb7dc070 0x3a1b76e1f660 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090335.440462:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090335.440941:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090335.441547:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090335.441992:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090335.442335:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090335.457971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200 0x7fc5cb7dc070 0x3a1b76e1f660 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090335.487768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200 0x7fc5cb7dc070 0x3a1b76e1f660 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090335.497691:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "cidian.dict.cn", "dict.cn"
[1:1:0712/090335.723749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200 0x7fc5cb7dc070 0x3a1b76e1f660 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090335.734788:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090336.621166:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090336.621766:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://cidian.dict.cn/, 265
[1:1:0712/090336.622026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 265 0x7fc5cb7dc070 0x3a1b76fc3ce0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 200 0x7fc5cb7dc070 0x3a1b76e1f660 
[1:1:0712/090336.944354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090336.972178:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/090336.977807:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3a1b76c36220
[1:1:0712/090336.978083:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/090337.596346:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7fc5cd7042e0 0x3a1b76c6f6e0 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090337.598359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , (function(_win,undefined){var version="3.1";if(_win.dictHc)return;var hc=_win.dictHc={};var _host=""
[1:1:0712/090337.598589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090337.600690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090338.186020:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://cidian.dict.cn/, 265, 7fc5ce1218db
[1:1:0712/090338.199695:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"200 0x7fc5cb7dc070 0x3a1b76e1f660 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090338.200106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"200 0x7fc5cb7dc070 0x3a1b76e1f660 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090338.200458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://cidian.dict.cn/, 334
[1:1:0712/090338.200688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 334 0x7fc5cb7dc070 0x3a1b76d02160 , 5:3_http://cidian.dict.cn/, 0, , 265 0x7fc5cb7dc070 0x3a1b76fc3ce0 
[1:1:0712/090338.201036:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090338.201679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , (){try{if(window.dictHc){dictHc.not(window.document.documentElement);clearInterval(forbidDictHcTimer
[1:1:0712/090338.201929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090338.681722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 318 0x7fc5cd7042e0 0x3a1b76ba11e0 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090338.687604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , (function(){var h={},mt={},c={id:"c02099862d294e963ee04d8f8a6f204f",dm:["dict.cn"],js:"tongji.baidu.
[1:1:0712/090338.687886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090338.713781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18990
[1:1:0712/090338.714043:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090338.714513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 340
[1:1:0712/090338.714741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 340 0x7fc5cb7dc070 0x3a1b76dfbce0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 318 0x7fc5cd7042e0 0x3a1b76ba11e0 
[112749:112749:0712/090356.567038:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[112749:112749:0712/090356.573931:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[112749:112749:0712/090356.597815:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://cidian.dict.cn/, http://cidian.dict.cn/, 4
[112749:112749:0712/090356.597947:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://cidian.dict.cn/, http://cidian.dict.cn
[112749:112749:0712/090356.698820:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/090356.761760:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[112749:112749:0712/090356.831421:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/090357.186118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/090357.186452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090358.122085:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 340, 7fc5ce121881
[1:1:0712/090358.127633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"318 0x7fc5cd7042e0 0x3a1b76ba11e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090358.127800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"318 0x7fc5cd7042e0 0x3a1b76ba11e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090358.127945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090358.128277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090358.128381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090358.128794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090358.128892:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090358.129091:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 443
[1:1:0712/090358.129198:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 443 0x7fc5cb7dc070 0x3a1b772b29e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 340 0x7fc5cb7dc070 0x3a1b76dfbce0 
[1:1:0712/090358.209384:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7fc5cd7042e0 0x3a1b76cebb60 , "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090358.211537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , (function(){var E;var g=window,n=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0712/090358.211692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090358.905843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , document.readyState
[1:1:0712/090358.907047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090359.031088:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090359.031472:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090359.031927:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090359.032282:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090359.032586:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090359.283054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090359.283946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/090359.284169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090359.805981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 443, 7fc5ce121881
[1:1:0712/090359.828964:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"340 0x7fc5cb7dc070 0x3a1b76dfbce0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090359.829312:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"340 0x7fc5cb7dc070 0x3a1b76dfbce0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090359.829644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090359.830349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090359.830578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090359.831365:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090359.831562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090359.832092:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 526
[1:1:0712/090359.832323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 526 0x7fc5cb7dc070 0x3a1b77a65860 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 443 0x7fc5cb7dc070 0x3a1b772b29e0 
[1:1:0712/090400.412113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , document.readyState
[1:1:0712/090400.412416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090400.492297:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090400.833003:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 526, 7fc5ce121881
[1:1:0712/090400.857208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"443 0x7fc5cb7dc070 0x3a1b772b29e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090400.857564:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"443 0x7fc5cb7dc070 0x3a1b772b29e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090400.857867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090400.858540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090400.858757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090400.859523:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090400.859734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090400.860326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 552
[1:1:0712/090400.860555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 552 0x7fc5cb7dc070 0x3a1b77717960 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 526 0x7fc5cb7dc070 0x3a1b77a65860 
[1:1:0712/090401.097254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , document.readyState
[1:1:0712/090401.097548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090401.248143:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090401.250645:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/090401.252261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550 0x7fc5cb7dc070 0x3a1b76fc0660 , "data:text/html,pluginplaceholderdata"
[1:1:0712/090401.253222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 130896562cc0, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/090401.253436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/090401.275708:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550 0x7fc5cb7dc070 0x3a1b76fc0660 , "data:text/html,pluginplaceholderdata"
[1:1:0712/090401.281403:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550 0x7fc5cb7dc070 0x3a1b76fc0660 , "data:text/html,pluginplaceholderdata"
[1:1:0712/090401.284516:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550 0x7fc5cb7dc070 0x3a1b76fc0660 , "data:text/html,pluginplaceholderdata"
[1:1:0712/090401.449567:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090401.450395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/090401.450591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090401.454520:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090401.456129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090401.457398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090401.460700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090401.462116:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18af0
[1:1:0712/090401.462304:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090401.462728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 598
[1:1:0712/090401.462917:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7fc5cb7dc070 0x3a1b77b9e6e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 556 0x7fc5cb7dc070 0x3a1b77ba56e0 
[1:1:0712/090401.548820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , , document.readyState
[1:1:0712/090401.549054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090401.698008:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/090401.699986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 130896562cc0, , onload, notifyDidFinishLoading();
[1:1:0712/090401.700168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/090401.948048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 598, 7fc5ce121881
[1:1:0712/090401.955488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"556 0x7fc5cb7dc070 0x3a1b77ba56e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090401.955625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"556 0x7fc5cb7dc070 0x3a1b77ba56e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090401.955757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090401.956059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090401.956162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090401.956511:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090401.956610:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090401.956792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 617
[1:1:0712/090401.956896:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7fc5cb7dc070 0x3a1b76b8ebe0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 598 0x7fc5cb7dc070 0x3a1b77b9e6e0 
[1:1:0712/090402.067664:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 617, 7fc5ce121881
[1:1:0712/090402.093201:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"598 0x7fc5cb7dc070 0x3a1b77b9e6e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.093482:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"598 0x7fc5cb7dc070 0x3a1b77b9e6e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.093724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090402.094338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090402.094527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090402.099124:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090402.099290:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090402.099754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 623
[1:1:0712/090402.099942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7fc5cb7dc070 0x3a1b77ba56e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 617 0x7fc5cb7dc070 0x3a1b76b8ebe0 
[1:1:0712/090402.205561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 623, 7fc5ce121881
[1:1:0712/090402.230869:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"617 0x7fc5cb7dc070 0x3a1b76b8ebe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.231124:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"617 0x7fc5cb7dc070 0x3a1b76b8ebe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.231375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090402.231972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090402.232146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090402.232893:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090402.233083:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090402.233528:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 629
[1:1:0712/090402.233719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7fc5cb7dc070 0x3a1b77b960e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 623 0x7fc5cb7dc070 0x3a1b77ba56e0 
[1:1:0712/090402.368951:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 629, 7fc5ce121881
[1:1:0712/090402.394632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"623 0x7fc5cb7dc070 0x3a1b77ba56e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.394896:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"623 0x7fc5cb7dc070 0x3a1b77ba56e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.395135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090402.395744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090402.395932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090402.396675:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090402.396837:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090402.397255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 639
[1:1:0712/090402.397462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7fc5cb7dc070 0x3a1b77c16160 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 629 0x7fc5cb7dc070 0x3a1b77b960e0 
[1:1:0712/090402.509748:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 639, 7fc5ce121881
[1:1:0712/090402.535549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"629 0x7fc5cb7dc070 0x3a1b77b960e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.535801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"629 0x7fc5cb7dc070 0x3a1b77b960e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.536043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090402.536701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090402.536881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090402.537624:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090402.537785:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090402.538204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 646
[1:1:0712/090402.538391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 646 0x7fc5cb7dc070 0x3a1b7745f7e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 639 0x7fc5cb7dc070 0x3a1b77c16160 
[1:1:0712/090402.671017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 646, 7fc5ce121881
[1:1:0712/090402.697065:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"639 0x7fc5cb7dc070 0x3a1b77c16160 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.697316:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"639 0x7fc5cb7dc070 0x3a1b77c16160 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.697572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090402.698166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090402.698340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090402.699063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090402.699236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090402.699686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 656
[1:1:0712/090402.699877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7fc5cb7dc070 0x3a1b77c16f60 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 646 0x7fc5cb7dc070 0x3a1b7745f7e0 
[1:1:0712/090402.816985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 656, 7fc5ce121881
[1:1:0712/090402.843201:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"646 0x7fc5cb7dc070 0x3a1b7745f7e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.843459:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"646 0x7fc5cb7dc070 0x3a1b7745f7e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090402.843722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090402.844310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090402.844521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090402.845227:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090402.845390:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090402.845830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 661
[1:1:0712/090402.846032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7fc5cb7dc070 0x3a1b77773660 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 656 0x7fc5cb7dc070 0x3a1b77c16f60 
[1:1:0712/090402.974460:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 661, 7fc5ce121881
[1:1:0712/090403.012938:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"656 0x7fc5cb7dc070 0x3a1b77c16f60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.013231:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"656 0x7fc5cb7dc070 0x3a1b77c16f60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.013505:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090403.014157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090403.014343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090403.015130:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090403.015298:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090403.015767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 664
[1:1:0712/090403.015968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7fc5cb7dc070 0x3a1b77c250e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 661 0x7fc5cb7dc070 0x3a1b77773660 
[1:1:0712/090403.168882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 664, 7fc5ce121881
[1:1:0712/090403.195238:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"661 0x7fc5cb7dc070 0x3a1b77773660 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.195493:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"661 0x7fc5cb7dc070 0x3a1b77773660 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.195752:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090403.196330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090403.196507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090403.197256:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090403.197413:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090403.197853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 668
[1:1:0712/090403.198054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7fc5cb7dc070 0x3a1b76bdd160 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 664 0x7fc5cb7dc070 0x3a1b77c250e0 
[1:1:0712/090403.334459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 668, 7fc5ce121881
[1:1:0712/090403.366289:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"664 0x7fc5cb7dc070 0x3a1b77c250e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.366696:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"664 0x7fc5cb7dc070 0x3a1b77c250e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.367063:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090403.367814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090403.368078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090403.368962:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090403.369207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090403.369724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 672
[1:1:0712/090403.370005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7fc5cb7dc070 0x3a1b76ceefe0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 668 0x7fc5cb7dc070 0x3a1b76bdd160 
[1:1:0712/090403.506862:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 672, 7fc5ce121881
[1:1:0712/090403.533405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"668 0x7fc5cb7dc070 0x3a1b76bdd160 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.533676:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"668 0x7fc5cb7dc070 0x3a1b76bdd160 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.533921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090403.534502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090403.534712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090403.535414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090403.535569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090403.536004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 674
[1:1:0712/090403.536204:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 674 0x7fc5cb7dc070 0x3a1b7746ff60 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 672 0x7fc5cb7dc070 0x3a1b76ceefe0 
[1:1:0712/090403.690925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 674, 7fc5ce121881
[1:1:0712/090403.714801:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"672 0x7fc5cb7dc070 0x3a1b76ceefe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.715198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"672 0x7fc5cb7dc070 0x3a1b76ceefe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.715565:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090403.716350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090403.716611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090403.717461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090403.717742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090403.718218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 676
[1:1:0712/090403.718510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7fc5cb7dc070 0x3a1b76a62660 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 674 0x7fc5cb7dc070 0x3a1b7746ff60 
[1:1:0712/090403.863402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 676, 7fc5ce121881
[1:1:0712/090403.889880:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"674 0x7fc5cb7dc070 0x3a1b7746ff60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.890291:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"674 0x7fc5cb7dc070 0x3a1b7746ff60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090403.890642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090403.891427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090403.891683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090403.892572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090403.892853:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090403.893354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 678
[1:1:0712/090403.893796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7fc5cb7dc070 0x3a1b777634e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 676 0x7fc5cb7dc070 0x3a1b76a62660 
[1:1:0712/090404.042057:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 678, 7fc5ce121881
[1:1:0712/090404.068962:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"676 0x7fc5cb7dc070 0x3a1b76a62660 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.069225:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"676 0x7fc5cb7dc070 0x3a1b76a62660 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.069465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090404.070073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090404.070252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090404.070977:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090404.071137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090404.071654:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 680
[1:1:0712/090404.071888:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7fc5cb7dc070 0x3a1b76d02060 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 678 0x7fc5cb7dc070 0x3a1b777634e0 
[1:1:0712/090404.194441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 680, 7fc5ce121881
[1:1:0712/090404.203113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"678 0x7fc5cb7dc070 0x3a1b777634e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.203251:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"678 0x7fc5cb7dc070 0x3a1b777634e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.203402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090404.203708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090404.203871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090404.204205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090404.204310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090404.204504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 682
[1:1:0712/090404.204609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7fc5cb7dc070 0x3a1b76f4be60 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 680 0x7fc5cb7dc070 0x3a1b76d02060 
[1:1:0712/090404.341011:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 682, 7fc5ce121881
[1:1:0712/090404.357738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"680 0x7fc5cb7dc070 0x3a1b76d02060 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.357906:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"680 0x7fc5cb7dc070 0x3a1b76d02060 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.358062:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090404.358374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090404.358481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090404.358799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090404.358931:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090404.359123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 684
[1:1:0712/090404.359232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7fc5cb7dc070 0x3a1b7776cee0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 682 0x7fc5cb7dc070 0x3a1b76f4be60 
[1:1:0712/090404.497842:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 684, 7fc5ce121881
[1:1:0712/090404.524930:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"682 0x7fc5cb7dc070 0x3a1b76f4be60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.525188:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"682 0x7fc5cb7dc070 0x3a1b76f4be60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.525435:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090404.526064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090404.526243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090404.526992:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090404.527165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090404.527599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 686
[1:1:0712/090404.527786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7fc5cb7dc070 0x3a1b76bdebe0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 684 0x7fc5cb7dc070 0x3a1b7776cee0 
[1:1:0712/090404.679301:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 686, 7fc5ce121881
[1:1:0712/090404.699940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"684 0x7fc5cb7dc070 0x3a1b7776cee0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.700077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"684 0x7fc5cb7dc070 0x3a1b7776cee0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.700214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090404.700512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090404.700626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090404.700954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090404.701056:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090404.701239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 688
[1:1:0712/090404.701344:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7fc5cb7dc070 0x3a1b77bb76e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 686 0x7fc5cb7dc070 0x3a1b76bdebe0 
[1:1:0712/090404.837214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 688, 7fc5ce121881
[1:1:0712/090404.865843:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"686 0x7fc5cb7dc070 0x3a1b76bdebe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.866270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"686 0x7fc5cb7dc070 0x3a1b76bdebe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090404.866628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090404.867356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090404.867621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090404.868524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090404.868765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090404.869343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 690
[1:1:0712/090404.869649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7fc5cb7dc070 0x3a1b76f46a60 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 688 0x7fc5cb7dc070 0x3a1b77bb76e0 
[1:1:0712/090405.019591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 690, 7fc5ce121881
[1:1:0712/090405.048643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"688 0x7fc5cb7dc070 0x3a1b77bb76e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.048921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"688 0x7fc5cb7dc070 0x3a1b77bb76e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.049207:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090405.049831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090405.050033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090405.050773:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090405.050936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090405.051412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 692
[1:1:0712/090405.051609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7fc5cb7dc070 0x3a1b76bd1560 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 690 0x7fc5cb7dc070 0x3a1b76f46a60 
[1:1:0712/090405.154457:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 692, 7fc5ce121881
[1:1:0712/090405.189761:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"690 0x7fc5cb7dc070 0x3a1b76f46a60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.190044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"690 0x7fc5cb7dc070 0x3a1b76f46a60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.190298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090405.190892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090405.191103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090405.191864:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090405.192084:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090405.192650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 694
[1:1:0712/090405.192844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7fc5cb7dc070 0x3a1b76f4be60 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 692 0x7fc5cb7dc070 0x3a1b76bd1560 
[1:1:0712/090405.354821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 694, 7fc5ce121881
[1:1:0712/090405.384031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"692 0x7fc5cb7dc070 0x3a1b76bd1560 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.384336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"692 0x7fc5cb7dc070 0x3a1b76bd1560 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.384600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090405.385252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090405.385448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090405.386212:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090405.386379:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090405.386826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 696
[1:1:0712/090405.387024:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 696 0x7fc5cb7dc070 0x3a1b76ce83e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 694 0x7fc5cb7dc070 0x3a1b76f4be60 
[1:1:0712/090405.517971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 696, 7fc5ce121881
[1:1:0712/090405.547334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"694 0x7fc5cb7dc070 0x3a1b76f4be60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.547615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"694 0x7fc5cb7dc070 0x3a1b76f4be60 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.547878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090405.548566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090405.548752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090405.549538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090405.549717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090405.550203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 698
[1:1:0712/090405.550404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7fc5cb7dc070 0x3a1b776f33e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 696 0x7fc5cb7dc070 0x3a1b76ce83e0 
[1:1:0712/090405.685582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 698, 7fc5ce121881
[1:1:0712/090405.713190:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"696 0x7fc5cb7dc070 0x3a1b76ce83e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.713446:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"696 0x7fc5cb7dc070 0x3a1b76ce83e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.713692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090405.714315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090405.714493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090405.715220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090405.715386:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090405.715809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 700
[1:1:0712/090405.715995:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7fc5cb7dc070 0x3a1b77b70860 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 698 0x7fc5cb7dc070 0x3a1b776f33e0 
[1:1:0712/090405.867246:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 700, 7fc5ce121881
[1:1:0712/090405.895115:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"698 0x7fc5cb7dc070 0x3a1b776f33e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.895436:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"698 0x7fc5cb7dc070 0x3a1b776f33e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090405.895696:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090405.896345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090405.896538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090405.897272:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090405.897435:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090405.897896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 702
[1:1:0712/090405.898096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7fc5cb7dc070 0x3a1b77a65de0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 700 0x7fc5cb7dc070 0x3a1b77b70860 
[1:1:0712/090406.024929:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 702, 7fc5ce121881
[1:1:0712/090406.073857:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"700 0x7fc5cb7dc070 0x3a1b77b70860 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.074122:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"700 0x7fc5cb7dc070 0x3a1b77b70860 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.074389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090406.074972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090406.075147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090406.075862:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090406.076022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090406.076480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 704
[1:1:0712/090406.076672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 704 0x7fc5cb7dc070 0x3a1b76f51fe0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 702 0x7fc5cb7dc070 0x3a1b77a65de0 
[1:1:0712/090406.224482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 704, 7fc5ce121881
[1:1:0712/090406.252364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"702 0x7fc5cb7dc070 0x3a1b77a65de0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.252621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"702 0x7fc5cb7dc070 0x3a1b77a65de0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.252868:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090406.253492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090406.253685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090406.254430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090406.254591:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090406.255018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 708
[1:1:0712/090406.255214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7fc5cb7dc070 0x3a1b776b66e0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 704 0x7fc5cb7dc070 0x3a1b76f51fe0 
[1:1:0712/090406.373472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 708, 7fc5ce121881
[1:1:0712/090406.386106:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"704 0x7fc5cb7dc070 0x3a1b76f51fe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.386322:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"704 0x7fc5cb7dc070 0x3a1b76f51fe0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.386524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090406.386923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090406.387068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090406.387537:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090406.387675:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090406.387933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 710
[1:1:0712/090406.388082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 710 0x7fc5cb7dc070 0x3a1b776cefe0 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 708 0x7fc5cb7dc070 0x3a1b776b66e0 
[1:1:0712/090406.526860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 710, 7fc5ce121881
[1:1:0712/090406.541037:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"130896482860","ptid":"708 0x7fc5cb7dc070 0x3a1b776b66e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.541365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://cidian.dict.cn/","ptid":"708 0x7fc5cb7dc070 0x3a1b776b66e0 ","rf":"5:3_http://cidian.dict.cn/"}
[1:1:0712/090406.541660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj"
[1:1:0712/090406.542245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cidian.dict.cn/, 130896482860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/090406.542533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", "dict.cn", 3, 1, , , 0
[1:1:0712/090406.543171:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21d1a04029c8, 0x3a1b76a18950
[1:1:0712/090406.543396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://cidian.dict.cn/wys/lwddgjyycd.html?iref=cdcenter-index-tj", 100
[1:1:0712/090406.543784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://cidian.dict.cn/, 712
[1:1:0712/090406.544005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7fc5cb7dc070 0x3a1b76bde360 , 5:3_http://cidian.dict.cn/, 1, -5:3_http://cidian.dict.cn/, 710 0x7fc5cb7dc070 0x3a1b776cefe0 
