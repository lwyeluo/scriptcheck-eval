[0712/085533.052601:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/085533.053003:INFO:switcher_clone.cc(787)] backtrace rip is 7f0a5f64e891
[0712/085534.150165:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/085534.150508:INFO:switcher_clone.cc(787)] backtrace rip is 7fd4a6a6a891
[1:1:0712/085534.162196:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/085534.162460:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/085534.172668:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/085535.585880:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/085535.586138:INFO:switcher_clone.cc(787)] backtrace rip is 7f0b022fa891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[111611:111611:0712/085535.754022:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[111643:111643:0712/085535.806584:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=111643
[111653:111653:0712/085535.807006:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=111653

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0c0f1160-5a72-4e89-b7dc-c4f9163d001f
[111611:111611:0712/085536.259595:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[111611:111641:0712/085536.260332:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/085536.260536:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/085536.261056:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/085536.262373:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/085536.262759:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/085536.268184:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1a5012d5, 1
[1:1:0712/085536.268945:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3249c477, 0
[1:1:0712/085536.269331:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xc104681, 3
[1:1:0712/085536.269757:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xa86303e, 2
[1:1:0712/085536.270206:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 77ffffffc44932 ffffffd512501a 3e30ffffff860a ffffff8146100c , 10104, 4
[1:1:0712/085536.272050:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[111611:111641:0712/085536.272550:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGw�I2�P>0�
�F�
[111611:111641:0712/085536.272636:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is w�I2�P>0�
�Fx��
[1:1:0712/085536.272559:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd4a4ca50a0, 3
[1:1:0712/085536.273059:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd4a4e30080, 2
[111611:111641:0712/085536.273275:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[111611:111641:0712/085536.273338:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 111663, 4, 77c44932 d512501a 3e30860a 8146100c 
[1:1:0712/085536.273368:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd48eaf3d20, -2
[1:1:0712/085536.300718:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/085536.301538:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a86303e
[1:1:0712/085536.302506:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a86303e
[1:1:0712/085536.304150:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a86303e
[1:1:0712/085536.305668:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.305878:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.306056:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.306241:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.306917:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a86303e
[1:1:0712/085536.307222:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd4a6a6a7ba
[1:1:0712/085536.307356:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd4a6a61def, 7fd4a6a6a77a, 7fd4a6a6c0cf
[1:1:0712/085536.313039:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a86303e
[1:1:0712/085536.313379:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a86303e
[1:1:0712/085536.314112:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a86303e
[1:1:0712/085536.316104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.316330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.316511:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.316728:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a86303e
[1:1:0712/085536.317959:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a86303e
[1:1:0712/085536.318318:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd4a6a6a7ba
[1:1:0712/085536.318469:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd4a6a61def, 7fd4a6a6a77a, 7fd4a6a6c0cf
[1:1:0712/085536.326128:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/085536.326575:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/085536.326751:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd27441a78, 0x7ffd274419f8)
[1:1:0712/085536.342734:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/085536.348561:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[111611:111611:0712/085536.890486:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[111611:111611:0712/085536.891210:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[111611:111622:0712/085536.896574:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[111611:111611:0712/085536.896627:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[111611:111611:0712/085536.896667:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[111611:111622:0712/085536.896670:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[111611:111611:0712/085536.896732:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,111663, 4
[1:7:0712/085536.899023:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[111611:111635:0712/085536.966481:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/085537.031680:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x19641acc1220
[1:1:0712/085537.031972:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/085537.286876:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/085538.621467:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/085538.624249:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[111611:111611:0712/085538.853131:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[111611:111611:0712/085538.853191:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/085539.682652:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/085540.002931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b97e7221f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/085540.003271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/085540.018461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b97e7221f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/085540.018735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/085540.121212:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/085540.121621:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/085540.507661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/085540.519321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b97e7221f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/085540.519803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/085540.555101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/085540.566480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b97e7221f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/085540.566821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/085540.579308:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/085540.585142:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x19641acbfe20
[1:1:0712/085540.585414:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[111611:111611:0712/085540.591694:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[111611:111611:0712/085540.605267:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[111611:111611:0712/085540.631985:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[111611:111611:0712/085540.632131:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[111611:111611:0712/085540.647093:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/085540.669328:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/085541.641317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fd4906ce2e0 0x19641afafe60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/085541.644304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b97e7221f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/085541.644729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/085541.648224:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[111611:111611:0712/085541.733364:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/085541.745038:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x19641acc0820
[1:1:0712/085541.745453:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[111611:111611:0712/085541.749301:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/085541.772161:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/085541.772450:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[111611:111611:0712/085541.773778:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[111611:111611:0712/085541.797998:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[111611:111611:0712/085541.800118:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[111611:111622:0712/085541.808056:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[111611:111622:0712/085541.808147:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[111611:111611:0712/085541.808289:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[111611:111611:0712/085541.808369:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[111611:111611:0712/085541.808501:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,111663, 4
[1:7:0712/085541.817420:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/085542.402973:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/085543.025096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fd4906ce2e0 0x19641af67be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/085543.026278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b97e7221f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/085543.026588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/085543.028466:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[111611:111611:0712/085543.232318:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[111611:111611:0712/085543.232384:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/085543.266108:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/085543.870668:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[111611:111611:0712/085544.007196:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[111611:111641:0712/085544.007637:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/085544.007838:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/085544.008100:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/085544.008555:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/085544.008750:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/085544.012041:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x16626b59, 1
[1:1:0712/085544.012450:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1cc831e8, 0
[1:1:0712/085544.012607:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3ee61928, 3
[1:1:0712/085544.012751:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1327d6dd, 2
[1:1:0712/085544.012902:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe831ffffffc81c 596b6216 ffffffddffffffd62713 2819ffffffe63e , 10104, 5
[1:1:0712/085544.013843:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[111611:111641:0712/085544.014069:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�1�Ykb��'(�>�
[111611:111641:0712/085544.014136:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �1�Ykb��'(�>�ٯ
[1:1:0712/085544.014246:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd4a4ca50a0, 3
[111611:111641:0712/085544.014435:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 111709, 5, e831c81c 596b6216 ddd62713 2819e63e 
[1:1:0712/085544.014493:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd4a4e30080, 2
[1:1:0712/085544.014727:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd48eaf3d20, -2
[1:1:0712/085544.037222:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/085544.037596:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1327d6dd
[1:1:0712/085544.037916:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1327d6dd
[1:1:0712/085544.038577:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1327d6dd
[1:1:0712/085544.040052:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.040253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.040475:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.040672:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.041345:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1327d6dd
[1:1:0712/085544.041668:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd4a6a6a7ba
[1:1:0712/085544.041811:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd4a6a61def, 7fd4a6a6a77a, 7fd4a6a6c0cf
[1:1:0712/085544.047839:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1327d6dd
[1:1:0712/085544.048206:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1327d6dd
[1:1:0712/085544.048992:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1327d6dd
[1:1:0712/085544.051115:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.051336:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.051548:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.051751:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1327d6dd
[1:1:0712/085544.053058:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1327d6dd
[1:1:0712/085544.053462:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd4a6a6a7ba
[1:1:0712/085544.053630:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd4a6a61def, 7fd4a6a6a77a, 7fd4a6a6c0cf
[1:1:0712/085544.061764:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/085544.062271:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/085544.062455:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd27441a78, 0x7ffd274419f8)
[1:1:0712/085544.076467:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/085544.080647:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/085544.262177:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x19641aca1220
[1:1:0712/085544.262403:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/085544.559154:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/085544.559486:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/085545.139458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/085545.141956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b97e734e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/085545.142259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/085545.150507:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/085545.188350:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/085545.189125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b97e7221f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/085545.189366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[111611:111611:0712/085545.217644:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[111611:111611:0712/085545.256556:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[111611:111641:0712/085545.256945:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/085545.257150:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/085545.257396:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/085545.257916:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/085545.258123:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/085545.261314:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2ec1bb5d, 1
[1:1:0712/085545.261635:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x270637ed, 0
[1:1:0712/085545.261880:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3b964bd7, 3
[1:1:0712/085545.262053:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1287626c, 2
[1:1:0712/085545.262207:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffed370627 5dffffffbbffffffc12e 6c62ffffff8712 ffffffd74bffffff963b , 10104, 6
[1:1:0712/085545.263177:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[111611:111641:0712/085545.263468:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�7']��.lb��K�;g
[111611:111641:0712/085545.263539:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �7']��.lb��K�;زg
[1:1:0712/085545.263659:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd4a4ca50a0, 3
[111611:111641:0712/085545.263896:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 111724, 6, ed370627 5dbbc12e 6c628712 d74b963b 
[1:1:0712/085545.263957:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd4a4e30080, 2
[1:1:0712/085545.264162:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd48eaf3d20, -2
[1:1:0712/085545.285920:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/085545.286238:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1287626c
[1:1:0712/085545.286486:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1287626c
[1:1:0712/085545.287086:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1287626c
[1:1:0712/085545.288539:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[1:1:0712/085545.288751:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[1:1:0712/085545.288944:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[1:1:0712/085545.289120:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[111611:111611:0712/085545.289347:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/085545.289829:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1287626c
[1:1:0712/085545.290116:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd4a6a6a7ba
[1:1:0712/085545.290247:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd4a6a61def, 7fd4a6a6a77a, 7fd4a6a6c0cf
[1:1:0712/085545.295948:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1287626c
[1:1:0712/085545.296290:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1287626c
[1:1:0712/085545.297020:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1287626c
[111611:111622:0712/085545.298015:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[111611:111622:0712/085545.298111:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[111611:111611:0712/085545.298314:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://scjgj.sh.gov.cn/
[111611:111611:0712/085545.298355:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120601170952752, 1
[111611:111611:0712/085545.298419:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_http://scjgj.sh.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 15:55:45 GMT Content-Type: text/html;charset=UTF-8 Content-Length: 13053 Connection: keep-alive Expires: Fri, 12 Jul 2019 15:55:45 GMT Pragma: no-cache Cache-Control: no-cache Set-Cookie: JSESSIONIDlz=0000fxFIJQLemF9xSZT4AYyvysP:16f9u5cfo; Path=/ Content-Language: zh-CN X-Ser: BC29_dx-lt-yd-jiangsu-zhenjiang-3-cache-9, BC76_cl-shanghai-shanghai-1-cache-2, BC147_ck-shanghai-shanghai-3-cache-2, BC150_ck-beijing-beijing-2-cache-2  ,0, 6
[1:1:0712/085545.299016:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[1:1:0712/085545.299241:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[1:1:0712/085545.299431:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[1:1:0712/085545.299613:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1287626c
[1:1:0712/085545.300869:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1287626c
[1:1:0712/085545.301236:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd4a6a6a7ba
[1:1:0712/085545.301398:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd4a6a61def, 7fd4a6a6a77a, 7fd4a6a6c0cf
[3:3:0712/085545.308363:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/085545.309075:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/085545.309589:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/085545.309780:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd27441a78, 0x7ffd274419f8)
[1:1:0712/085545.322995:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/085545.327493:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/085545.355466:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/085545.357261:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/085545.357526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b97e734e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/085545.357871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:7:0712/085545.415643:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/085545.462295:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/085545.463219:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/085545.463444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b97e734e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/085545.463705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/085545.510710:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x19641acc5220
[1:1:0712/085545.535968:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/085545.621474:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_http://scjgj.sh.gov.cn/
[111611:111611:0712/085545.849300:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn/, 1
[111611:111611:0712/085545.849425:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn
[1:1:0712/085545.862567:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/085545.906696:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/085546.024423:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/085546.024679:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120601170952752"
[1:1:0712/085546.088528:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.063539, 260, 1
[1:1:0712/085546.088786:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/085546.211553:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/085546.256007:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.fandom.com/"
[1:1:0712/085546.262749:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/085546.262975:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120601170952752"
[1:1:0712/085546.334518:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/085546.365687:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 152 0x7fd48e7a6070 0x19641adad660 , "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120601170952752"
[1:1:0712/085546.368107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_http://scjgj.sh.gov.cn/, 0e04163c2860, , , 
//changediv();
function changediv(){
	var tab = document.getElementById("resultTb");
	var d = docum
[1:1:0712/085546.368314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120601170952752", "scjgj.sh.gov.cn", 3, 1, , , 0
[1:1:0712/085546.438056:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/085546.518500:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.springer.com/"
[1:1:0712/085546.612462:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0712/085546.677737:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0712/085546.782447:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/085553.724218:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/085553.724749:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/085553.725310:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/085553.725757:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/085553.726169:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/085608.061697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_http://scjgj.sh.gov.cn/, 0e04163c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/085608.062071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120601170952752", "scjgj.sh.gov.cn", 3, 1, , , 0
[1:1:0712/085608.066537:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[111611:111611:0712/085608.606808:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/085608.617613:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
