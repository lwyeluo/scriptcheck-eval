[0712/140149.806654:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140149.806935:INFO:switcher_clone.cc(787)] backtrace rip is 7fb3da4b3891
[0712/140150.783374:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140150.783779:INFO:switcher_clone.cc(787)] backtrace rip is 7fd3fcbd3891
[1:1:0712/140150.795605:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/140150.795855:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/140150.805090:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[21081:21081:0712/140152.063662:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/140152.138284:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140152.138542:INFO:switcher_clone.cc(787)] backtrace rip is 7fb2cab87891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/b01767cb-05ac-418b-9193-13dc9eb3cbe7
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[21114:21114:0712/140152.371169:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=21114
[21125:21125:0712/140152.371563:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=21125
[21081:21081:0712/140152.577205:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[21081:21111:0712/140152.578149:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/140152.578399:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/140152.578697:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/140152.579405:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/140152.579637:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/140152.582992:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1fd3635d, 1
[1:1:0712/140152.583305:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x25c98fcf, 0
[1:1:0712/140152.583492:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1a1662d, 3
[1:1:0712/140152.583669:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2da76851, 2
[1:1:0712/140152.583862:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcfffffff8fffffffc925 5d63ffffffd31f 5168ffffffa72d 2d66ffffffa101 , 10104, 4
[1:1:0712/140152.584829:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[21081:21111:0712/140152.585026:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGϏ�%]c�Qh�--f��B_7
[21081:21111:0712/140152.585106:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ϗ�%]c�Qh�--f����B_7
[1:1:0712/140152.585224:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3fae0e0a0, 3
[21081:21111:0712/140152.585377:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[21081:21111:0712/140152.585473:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 21133, 4, cf8fc925 5d63d31f 5168a72d 2d66a101 
[1:1:0712/140152.585456:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3faf99080, 2
[1:1:0712/140152.585612:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3e4c5cd20, -2
[1:1:0712/140152.609112:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/140152.610158:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2da76851
[1:1:0712/140152.611382:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2da76851
[1:1:0712/140152.613467:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2da76851
[1:1:0712/140152.615349:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.615608:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.615844:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.616086:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.616908:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2da76851
[1:1:0712/140152.617343:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd3fcbd37ba
[1:1:0712/140152.617541:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd3fcbcadef, 7fd3fcbd377a, 7fd3fcbd50cf
[1:1:0712/140152.624612:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2da76851
[1:1:0712/140152.625048:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2da76851
[1:1:0712/140152.625986:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2da76851
[1:1:0712/140152.628559:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.628808:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.629047:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.629279:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2da76851
[1:1:0712/140152.630871:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2da76851
[1:1:0712/140152.631326:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd3fcbd37ba
[1:1:0712/140152.631546:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd3fcbcadef, 7fd3fcbd377a, 7fd3fcbd50cf
[1:1:0712/140152.641243:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/140152.641782:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/140152.642046:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5a7d9658, 0x7ffd5a7d95d8)
[1:1:0712/140152.661307:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/140152.668480:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[21081:21081:0712/140153.148865:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21081:21081:0712/140153.149968:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21081:21092:0712/140153.168482:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[21081:21092:0712/140153.168600:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[21081:21081:0712/140153.168721:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[21081:21081:0712/140153.168820:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[21081:21081:0712/140153.168964:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,21133, 4
[1:7:0712/140153.173873:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[21081:21105:0712/140153.232248:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/140153.244175:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xd0071da220
[1:1:0712/140153.244418:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/140153.531828:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/140155.110637:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140155.114457:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[21081:21081:0712/140155.170381:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[21081:21081:0712/140155.170446:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/140155.896188:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140156.023631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c8c11f21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/140156.023924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140156.033138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c8c11f21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/140156.033393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140156.184985:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140156.185243:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140156.600842:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140156.616573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c8c11f21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/140156.617038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140156.640275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140156.651273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c8c11f21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/140156.651552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140156.658119:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/140156.662640:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd0071d8e20
[1:1:0712/140156.662842:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[21081:21081:0712/140156.667170:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[21081:21081:0712/140156.669412:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[21081:21081:0712/140156.703141:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[21081:21081:0712/140156.703301:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/140156.712214:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140157.522873:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fd3e68372e0 0xd0073cb4e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140157.525422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c8c11f21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/140157.525901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140157.529059:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[21081:21081:0712/140157.618293:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/140157.621356:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xd0071d9820
[1:1:0712/140157.621714:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[21081:21081:0712/140157.632248:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/140157.640224:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/140157.640460:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[21081:21081:0712/140157.650557:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[21081:21081:0712/140157.663318:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21081:21081:0712/140157.665399:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21081:21092:0712/140157.672747:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[21081:21092:0712/140157.672858:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[21081:21081:0712/140157.673103:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[21081:21081:0712/140157.673199:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[21081:21081:0712/140157.673382:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,21133, 4
[1:7:0712/140157.683114:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/140158.252129:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/140158.475258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fd3e68372e0 0xd00746c360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140158.476288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c8c11f21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/140158.476498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140158.477271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[21081:21081:0712/140158.638888:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[21081:21081:0712/140158.638963:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/140158.642932:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140158.972217:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140159.478196:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140159.478418:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140159.869985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140159.875733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c8c1204e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/140159.876115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/140159.885741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[21081:21081:0712/140200.001014:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[21081:21111:0712/140200.001480:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/140200.001720:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/140200.001965:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/140200.002454:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/140200.002630:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/140200.006228:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xeb4b864, 1
[1:1:0712/140200.006644:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x464e495, 0
[1:1:0712/140200.006847:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3cf8da11, 3
[1:1:0712/140200.007035:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x5cb2daf, 2
[1:1:0712/140200.007213:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff95ffffffe46404 64ffffffb8ffffffb40e ffffffaf2dffffffcb05 11ffffffdafffffff83c , 10104, 5
[1:1:0712/140200.008263:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[21081:21111:0712/140200.008570:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��dd���-���<JE_7
[21081:21111:0712/140200.008650:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��dd���-���<oJE_7
[1:1:0712/140200.008563:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3fae0e0a0, 3
[21081:21111:0712/140200.008989:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 21180, 5, 95e46404 64b8b40e af2dcb05 11daf83c 
[1:1:0712/140200.008940:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3faf99080, 2
[1:1:0712/140200.009506:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3e4c5cd20, -2
[1:1:0712/140200.030760:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/140200.031146:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5cb2daf
[1:1:0712/140200.031567:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5cb2daf
[1:1:0712/140200.032224:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5cb2daf
[1:1:0712/140200.033717:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.033955:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.034176:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.034427:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.035126:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5cb2daf
[1:1:0712/140200.035482:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd3fcbd37ba
[1:1:0712/140200.035670:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd3fcbcadef, 7fd3fcbd377a, 7fd3fcbd50cf
[1:1:0712/140200.039975:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5cb2daf
[1:1:0712/140200.040445:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5cb2daf
[1:1:0712/140200.041274:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5cb2daf
[1:1:0712/140200.043653:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.043967:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.044207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.044469:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5cb2daf
[1:1:0712/140200.045782:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5cb2daf
[1:1:0712/140200.046209:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd3fcbd37ba
[1:1:0712/140200.046390:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd3fcbcadef, 7fd3fcbd377a, 7fd3fcbd50cf
[1:1:0712/140200.054281:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/140200.054817:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/140200.054998:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5a7d9658, 0x7ffd5a7d95d8)
[1:1:0712/140200.068787:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/140200.073564:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/140200.141033:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140200.141942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c8c11f21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/140200.142242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140200.308383:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd007195220
[1:1:0712/140200.308687:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/140200.351902:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140200.354007:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/140200.354229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c8c1204e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/140200.354556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/140200.532023:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140200.533097:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/140200.533319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c8c1204e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/140200.533613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[21081:21081:0712/140200.805792:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21081:21081:0712/140200.812008:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/140200.840158:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[21081:21092:0712/140200.842485:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[21081:21092:0712/140200.842573:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[21081:21081:0712/140200.843024:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bj.meituan.com/
[21081:21081:0712/140200.843108:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bj.meituan.com/, https://bj.meituan.com/yanhui/, 1
[21081:21081:0712/140200.843243:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://bj.meituan.com/, HTTP/1.1 200 OK Server: openresty Date: Fri, 12 Jul 2019 21:02:00 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: ci=1; path=/; expires=Tue, 10 Sep 2019 21:02:00 GMT; domain=.meituan.com Set-Cookie: rvct=1%2C56%2C99%2C106; path=/; expires=Tue, 10 Sep 2019 21:02:00 GMT; domain=.meituan.com Content-Encoding: gzip  ,21180, 5
[1:7:0712/140200.852366:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/140200.909754:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://bj.meituan.com/
[21081:21081:0712/140201.027056:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bj.meituan.com/, https://bj.meituan.com/, 1
[21081:21081:0712/140201.027114:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://bj.meituan.com/, https://bj.meituan.com
[1:1:0712/140201.105648:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140201.163669:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140201.233884:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140201.265275:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140201.265549:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bj.meituan.com/yanhui/"
[1:1:0712/140201.322927:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/140201.348574:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140201.566187:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://stackoverflow.com/"
[1:1:0712/140201.637173:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.fandom.com/"
[1:1:0712/140201.673443:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140201.683449:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 152, "https://bj.meituan.com/yanhui/"
[1:1:0712/140201.685458:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140201.690885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , ;!function(t,e){"function"==typeof define&&define.amd?define(e):"object"==typeof exports?module.expo
[1:1:0712/140201.691128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140201.741499:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/140201.813354:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.springer.com/"
[1:1:0712/140201.908137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 152, "https://bj.meituan.com/yanhui/"
[1:1:0712/140201.975145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157, "https://bj.meituan.com/yanhui/"
[1:1:0712/140201.976518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , ;!function(){"use strict";function t(t){if("string"!=typeof t&&(t=t.toString()),/[^a-z0-9\-#$%&'*+.\
[1:1:0712/140201.976746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140201.979666:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157, "https://bj.meituan.com/yanhui/"
[1:1:0712/140201.987763:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157, "https://bj.meituan.com/yanhui/"
[1:1:0712/140202.029775:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.050771, 432, 1
[1:1:0712/140202.030058:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140202.065717:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0712/140202.116824:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0712/140202.343458:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140202.343923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c8c1204e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/140202.344095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/140202.421811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140202.422299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c8c1204e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/140202.422440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/140202.436730:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140202.436947:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bj.meituan.com/yanhui/"
[1:1:0712/140202.437788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fd3e490f070 0xd0074a4be0 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140202.438810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , window.comPtData = window.comPtData || {};
window.comPtData['header'] = {"currentCity":{"id":1,"name
[1:1:0712/140202.439024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140202.645554:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.208503, 3186, 1
[1:1:0712/140202.645845:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140202.907443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 217 0x7fd3e68372e0 0xd0072d4de0 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140202.915201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , !function(){"use strict";var u=!0,n="_MeiTuanALogObject",l=1,r="dianping_nova",h="waimai",m="group",
[1:1:0712/140202.915445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140202.931672:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3dcc53229c8, 0xd006fff9a8
[1:1:0712/140202.931939:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 100
[1:1:0712/140202.932338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 317
[1:1:0712/140202.932564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 317 0x7fd3e490f070 0xd0072c96e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 217 0x7fd3e68372e0 0xd0072d4de0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/140203.834731:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140203.835197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140203.835556:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140203.835994:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140203.836461:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[21081:21081:0712/140230.588958:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.592623:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.600357:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.608185:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.615383:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.623041:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.630945:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.638153:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.645681:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.654075:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.664193:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.674215:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.684104:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.693256:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.702429:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.711434:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.720111:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.727316:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.734503:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.741788:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.748946:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.756112:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.763283:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.770468:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.779011:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.786191:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.793398:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/groupop/348758503e87285267788a5d5b64d777779.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.800648:INFO:CONSOLE(149)] "Mixed Content: The page at 'https://bj.meituan.com/yanhui/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/groupop/af71bbba0c83b6693e9f52645bb1cf3c660.png'. This content should also be served over HTTPS.", source: https://bj.meituan.com/yanhui/ (149)
[21081:21081:0712/140230.835089:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/140230.863105:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/140231.057257:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3dcc53229c8, 0xd006fff9a8
[1:1:0712/140231.057565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 100
[1:1:0712/140231.058007:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 350
[1:1:0712/140231.058253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 350 0x7fd3e490f070 0xd0075fede0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 217 0x7fd3e68372e0 0xd0072d4de0 
[1:1:0712/140231.127212:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x3dcc53229c8, 0xd006fff9a8
[1:1:0712/140231.127408:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 1000
[1:1:0712/140231.127607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 351
[1:1:0712/140231.127773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 351 0x7fd3e490f070 0xd0074f5160 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 217 0x7fd3e68372e0 0xd0072d4de0 
[1:1:0712/140231.212721:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff9a8
[1:1:0712/140231.213004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140231.213414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 366
[1:1:0712/140231.213645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 366 0x7fd3e490f070 0xd0072c06e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 217 0x7fd3e68372e0 0xd0072d4de0 
[1:1:0712/140231.559610:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140231.559902:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bj.meituan.com/yanhui/"
[1:1:0712/140231.564667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7fd3e490f070 0xd007512b60 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140231.591164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , window.AppData = {"poiParam":{"uuid":"34f739686db54d10a2d6.1562964042.1.0.0","userid":-1,"limit":32,
[1:1:0712/140231.591473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140231.613635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7fd3e490f070 0xd007512b60 , "https://bj.meituan.com/yanhui/"
[0712/140231.985731:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140231.986039:INFO:switcher_clone.cc(787)] backtrace rip is 7f8fe69a0891
[1:1:0712/140232.861309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/140232.861630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140233.410539:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 317, 7fd3e7254881
[1:1:0712/140233.417316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140233.417457:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140233.417628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140233.417923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , t, (){clearTimeout(jn);try{Cn()}catch(t){}finally{wn()===at?jn=A(t,On):clearTimeout(jn)}}
[1:1:0712/140233.418036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140233.420526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140233.420697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 5000
[1:1:0712/140233.421037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 401
[1:1:0712/140233.421224:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 401 0x7fd3e490f070 0xd007718860 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 317 0x7fd3e490f070 0xd0072c96e0 
[1:1:0712/140233.422658:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 350, 7fd3e7254881
[1:1:0712/140233.439586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140233.439864:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140233.440141:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140233.440643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){n().then(t)}
[1:1:0712/140233.440826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140233.442333:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140233.442497:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 100
[1:1:0712/140233.442834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 402
[1:1:0712/140233.443036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 402 0x7fd3e490f070 0xd00770e3e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 350 0x7fd3e490f070 0xd0075fede0 
[1:1:0712/140233.463009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 366, 7fd3e7254881
[1:1:0712/140233.480476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140233.480761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140233.481035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140233.481579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140233.481758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140233.488226:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140233.488444:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140233.488788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 403
[1:1:0712/140233.488977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 403 0x7fd3e490f070 0xd00750a4e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 366 0x7fd3e490f070 0xd0072c06e0 
[1:1:0712/140233.607053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fd3faf99080 0xd007167100 1 0 0xd007167118 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140233.608613:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140233.618742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , ;"use strict";function Nb(e){function t(e,t){return null==e||"http://www.w3.org/1999/xhtml"===e?oe(t
[1:1:0712/140233.618961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140233.991913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fd3faf99080 0xd007167100 1 0 0xd007167118 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140234.088682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (t){try{var n=[];(t||[]).forEach(function(t){n.push(t.deviceId)}),cn.did=n.map(function(t){return t.
[1:1:0712/140234.088868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140234.091435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 351, 7fd3e7254881
[1:1:0712/140234.097166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140234.097311:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"217 0x7fd3e68372e0 0xd0072d4de0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140234.097521:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140234.097804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , fu, (){var n,r;Sn(!1),(n=uu,r={none:!0},new Ir(function(e){try{var t=Se(Gi,"4.12.0");!Gi||!te(t)||t<0?e(
[1:1:0712/140234.097995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140234.102211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140234.102621:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140234.103001:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 417
[1:1:0712/140234.103240:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 417 0x7fd3e490f070 0xd0074ee260 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 351 0x7fd3e490f070 0xd0074f5160 
[1:1:0712/140234.175267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , document.readyState
[1:1:0712/140234.175578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140237.050391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "success", "https://bj.meituan.com/yanhui/"
[1:1:0712/140237.052828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , onsuccess, (t){_i=!0,bi=t.target.result,n()}
[1:1:0712/140237.053081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140237.056477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 403, 7fd3e7254881
[1:1:0712/140237.075855:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"366 0x7fd3e490f070 0xd0072c06e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140237.076150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"366 0x7fd3e490f070 0xd0072c06e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140237.076548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140237.077063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140237.077256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140237.079290:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140237.079460:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140237.079795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 455
[1:1:0712/140237.079987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 455 0x7fd3e490f070 0xd00770e260 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 403 0x7fd3e490f070 0xd00750a4e0 
[1:1:0712/140237.082129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 402, 7fd3e7254881
[1:1:0712/140237.104576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"350 0x7fd3e490f070 0xd0075fede0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140237.104952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"350 0x7fd3e490f070 0xd0075fede0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140237.105444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140237.106109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){n().then(t)}
[1:1:0712/140237.106404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140237.107814:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140237.107980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 100
[1:1:0712/140237.108355:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 457
[1:1:0712/140237.108553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 457 0x7fd3e490f070 0xd007b692e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 402 0x7fd3e490f070 0xd00770e3e0 
[1:1:0712/140237.317347:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 417, 7fd3e7254881
[1:1:0712/140237.339146:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"351 0x7fd3e490f070 0xd0074f5160 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140237.339506:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"351 0x7fd3e490f070 0xd0074f5160 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140237.339888:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140237.340455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140237.340667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140237.405415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , document.readyState
[1:1:0712/140237.405661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140239.690413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 455, 7fd3e7254881
[1:1:0712/140239.705586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"403 0x7fd3e490f070 0xd00750a4e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140239.705791:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"403 0x7fd3e490f070 0xd00750a4e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140239.706049:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140239.706494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140239.706648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140239.710288:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140239.710402:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140239.710576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 481
[1:1:0712/140239.710684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7fd3e490f070 0xd007b85260 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 455 0x7fd3e490f070 0xd00770e260 
[1:1:0712/140239.711155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 457, 7fd3e7254881
[1:1:0712/140239.717775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"402 0x7fd3e490f070 0xd00770e3e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140239.717929:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"402 0x7fd3e490f070 0xd00770e3e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140239.718132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140239.718405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){n().then(t)}
[1:1:0712/140239.718536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140239.719099:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140239.719207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 100
[1:1:0712/140239.719369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 482
[1:1:0712/140239.719477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7fd3e490f070 0xd0079d0ce0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 457 0x7fd3e490f070 0xd007b692e0 
[1:1:0712/140239.764395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7fd3e4c77bd0 0xd0074a5d58 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140239.780344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , ;var App=webpackJsonpApp([2],[function(e,t,n){(function(t){function r(e){return(r="function"==typeof
[1:1:0712/140239.780585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140240.004993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7fd3e4c77bd0 0xd0074a5d58 , "https://bj.meituan.com/yanhui/"
		remove user.11_e119c9a6 -> 0
[1:1:0712/140241.551075:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140241.551581:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[21081:21081:0712/140252.867171:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/140253.481724:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 13.4773, 0, 0
[1:1:0712/140253.481905:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140253.570591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , document.readyState
[1:1:0712/140253.570862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140253.716339:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 401, 7fd3e7254881
[1:1:0712/140253.739797:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"317 0x7fd3e490f070 0xd0072c96e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140253.740210:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"317 0x7fd3e490f070 0xd0072c96e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140253.740718:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140253.741450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , t, (){clearTimeout(jn);try{Cn()}catch(t){}finally{wn()===at?jn=A(t,On):clearTimeout(jn)}}
[1:1:0712/140253.741715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140253.743822:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140253.744048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 5000
[1:1:0712/140253.744503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 498
[1:1:0712/140253.744803:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7fd3e490f070 0xd006e87e60 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 401 0x7fd3e490f070 0xd007718860 
[1:1:0712/140253.815814:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://bj.meituan.com/yanhui/"
[1:1:0712/140253.816238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , value, (){var e=window.innerHeight-245,t=document.body.clientWidth-250;e<500&&(e=500),e>1090&&(e=1090),t>10
[1:1:0712/140253.816351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140254.007875:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 481, 7fd3e7254881
[1:1:0712/140254.014552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"455 0x7fd3e490f070 0xd00770e260 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140254.014754:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"455 0x7fd3e490f070 0xd00770e260 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140254.015017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140254.015327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140254.015433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140254.016708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140254.016840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140254.017018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 506
[1:1:0712/140254.017125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 506 0x7fd3e490f070 0xd007b7d7e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 481 0x7fd3e490f070 0xd007b85260 
[1:1:0712/140254.135480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/140254.135717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140254.144533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/140254.144709:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
		remove user.12_f44c037 -> 0
		remove user.13_40cad0e6 -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/140258.937029:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140258.938541:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bj.meituan.com/yanhui/"
[1:1:0712/140258.998471:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 482, 7fd3e7254881
[1:1:0712/140259.026802:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"457 0x7fd3e490f070 0xd007b692e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140259.027208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"457 0x7fd3e490f070 0xd007b692e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140259.027626:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140259.028236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){n().then(t)}
[1:1:0712/140259.028423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140259.029785:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140259.029962:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 100
[1:1:0712/140259.030466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 595
[1:1:0712/140259.030668:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 595 0x7fd3e490f070 0xd00cc94be0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 482 0x7fd3e490f070 0xd0079d0ce0 
[1:1:0712/140259.125221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 494 0x7fd3faf99080 0xd006e86240 1 0 0xd006e86258 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140259.168483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , ;var App=webpackJsonpApp([16],{118:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule"
[1:1:0712/140259.168741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140259.315683:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bj.meituan.com/yanhui/"
[1:1:0712/140259.549499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , document.readyState
[1:1:0712/140259.549794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140259.797021:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 506, 7fd3e7254881
[1:1:0712/140259.823811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"481 0x7fd3e490f070 0xd007b85260 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140259.824218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"481 0x7fd3e490f070 0xd007b85260 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140259.824656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140259.825225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140259.825460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140259.878754:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140259.879073:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 2000
[1:1:0712/140259.879562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 618
[1:1:0712/140259.879819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7fd3e490f070 0xd00eca3a60 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 506 0x7fd3e490f070 0xd007b7d7e0 
[1:1:0712/140300.123812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140300.124089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140300.124517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 633
[1:1:0712/140300.124756:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7fd3e490f070 0xd00de15fe0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 506 0x7fd3e490f070 0xd007b7d7e0 
[1:1:0712/140300.259366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 511 0x7fd3e68372e0 0xd00d3fa360 , "https://bj.meituan.com/yanhui/"
[1:1:0712/140300.260604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , window.qq = window.qq || {};
qq.maps = qq.maps || {};
window.soso || (window.soso = qq);
soso.map
[1:1:0712/140300.260841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140302.450989:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 498, 7fd3e7254881
[1:1:0712/140302.480230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"401 0x7fd3e490f070 0xd007718860 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140302.480622:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"401 0x7fd3e490f070 0xd007718860 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140302.481083:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140302.481731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , t, (){clearTimeout(jn);try{Cn()}catch(t){}finally{wn()===at?jn=A(t,On):clearTimeout(jn)}}
[1:1:0712/140302.482055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140302.483844:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140302.484103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 5000
[1:1:0712/140302.484547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 669
[1:1:0712/140302.484790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7fd3e490f070 0xd00e2f51e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 498 0x7fd3e490f070 0xd006e87e60 
[1:1:0712/140303.087825:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://bj.meituan.com/yanhui/"
[1:1:0712/140303.088659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&r(+n.data.slice(t.length))}
[1:1:0712/140303.088816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140303.344773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/140303.344966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140303.357789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/140303.358101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140303.422809:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 595, 7fd3e7254881
[1:1:0712/140303.434797:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"482 0x7fd3e490f070 0xd0079d0ce0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140303.435010:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"482 0x7fd3e490f070 0xd0079d0ce0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140303.435272:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140303.435924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){n().then(t)}
[1:1:0712/140303.436046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140303.437297:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140303.437413:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140303.437619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 697
[1:1:0712/140303.437740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7fd3e490f070 0xd00e63c1e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 595 0x7fd3e490f070 0xd00cc94be0 
[1:1:0712/140303.808820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 633, 7fd3e7254881
[1:1:0712/140303.828078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14eecf8e2860","ptid":"506 0x7fd3e490f070 0xd007b7d7e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140303.828314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bj.meituan.com/","ptid":"506 0x7fd3e490f070 0xd007b7d7e0 ","rf":"5:3_https://bj.meituan.com/"}
[1:1:0712/140303.828620:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bj.meituan.com/yanhui/"
[1:1:0712/140303.828975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140303.829100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140303.830658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3dcc53229c8, 0xd006fff950
[1:1:0712/140303.830777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bj.meituan.com/yanhui/", 0
[1:1:0712/140303.831033:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bj.meituan.com/, 700
[1:1:0712/140303.831151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7fd3e490f070 0xd00c6551e0 , 5:3_https://bj.meituan.com/, 1, -5:3_https://bj.meituan.com/, 633 0x7fd3e490f070 0xd00de15fe0 
[1:1:0712/140303.853520:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bj.meituan.com/yanhui/"
[1:1:0712/140303.854483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bj.meituan.com/, 14eecf8e2860, , Qi.u.onreadystatechange, (){if(4===u.readyState){var t=u.status;200<=t&&t<400?(Fi=0,a(M,u.status,"ajax-"+o),Ci=[]):i?a(P,u.st
[1:1:0712/140303.854716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bj.meituan.com/yanhui/", "bj.meituan.com", 3, 1, , , 0
[1:1:0712/140303.855895:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bj.meituan.com/yanhui/"
[1:1:0712/140303.858946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bj.meituan.com/yanhui/"
[1:1:0712/140303.861878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bj.meituan.com/yanhui/"
