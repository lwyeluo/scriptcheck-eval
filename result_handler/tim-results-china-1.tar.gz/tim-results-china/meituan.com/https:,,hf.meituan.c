[0712/140034.788019:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140034.788418:INFO:switcher_clone.cc(787)] backtrace rip is 7fc02ec14891
[0712/140035.747270:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140035.747580:INFO:switcher_clone.cc(787)] backtrace rip is 7ff075dd8891
[1:1:0712/140035.751852:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/140035.752107:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/140035.758209:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/140037.421915:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140037.422407:INFO:switcher_clone.cc(787)] backtrace rip is 7f7bb60c8891
[20944:20944:0712/140037.494260:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dff50f57-9551-45bb-8efa-9a58276685e4
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[20976:20976:0712/140037.696173:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20976
[20989:20989:0712/140037.696610:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20989
[20944:20944:0712/140038.017967:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[20944:20974:0712/140038.018756:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/140038.018981:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/140038.019195:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/140038.019779:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/140038.019934:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/140038.022952:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2ce12537, 1
[1:1:0712/140038.023262:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3c155de1, 0
[1:1:0712/140038.023423:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2324b, 3
[1:1:0712/140038.023605:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xc6579e, 2
[1:1:0712/140038.023810:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe15d153c 3725ffffffe12c ffffff9e57ffffffc600 4b320200 , 10104, 4
[1:1:0712/140038.024768:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20944:20974:0712/140038.024972:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�]<7%�,�W�
[20944:20974:0712/140038.025036:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �]<7%�,�W�
[1:1:0712/140038.025155:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0740130a0, 3
[20944:20974:0712/140038.025341:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/140038.025338:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff07419e080, 2
[20944:20974:0712/140038.025416:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20997, 4, e15d153c 3725e12c 9e57c600 4b320200 
[1:1:0712/140038.025501:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff05de61d20, -2
[1:1:0712/140038.043627:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/140038.044450:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c6579e
[1:1:0712/140038.045403:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c6579e
[1:1:0712/140038.046947:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c6579e
[1:1:0712/140038.048372:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.048601:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.048781:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.048956:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.049572:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c6579e
[1:1:0712/140038.049885:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff075dd87ba
[1:1:0712/140038.050011:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff075dcfdef, 7ff075dd877a, 7ff075dda0cf
[1:1:0712/140038.055555:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c6579e
[1:1:0712/140038.055880:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c6579e
[1:1:0712/140038.056586:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c6579e
[1:1:0712/140038.058800:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.059036:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.059267:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.059491:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c6579e
[1:1:0712/140038.060957:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c6579e
[1:1:0712/140038.061312:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff075dd87ba
[1:1:0712/140038.061446:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff075dcfdef, 7ff075dd877a, 7ff075dda0cf
[1:1:0712/140038.069050:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/140038.069544:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/140038.069730:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffed9129cc8, 0x7ffed9129c48)
[1:1:0712/140038.086166:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/140038.091923:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[20944:20944:0712/140038.582800:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20944:20944:0712/140038.584022:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20944:20956:0712/140038.606614:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[20944:20956:0712/140038.606747:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[20944:20944:0712/140038.606958:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[20944:20944:0712/140038.607054:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[20944:20944:0712/140038.607226:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,20997, 4
[1:7:0712/140038.611471:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/140038.679905:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x6be7d590220
[1:1:0712/140038.680207:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[20944:20969:0712/140038.755286:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/140039.090672:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/140040.679059:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[20944:20944:0712/140040.680823:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[1:1:0712/140040.680767:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[20944:20944:0712/140040.680934:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/140041.482142:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140041.643360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 078118c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/140041.643659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140041.663156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 078118c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/140041.663425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140041.812139:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140041.812371:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140042.139566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140042.149754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 078118c81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/140042.150071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140042.166706:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140042.171587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 078118c81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/140042.171792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140042.177416:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/140042.182416:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x6be7d58ee20
[20944:20944:0712/140042.183115:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/140042.182664:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[20944:20944:0712/140042.201528:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0712/140042.239296:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[20944:20944:0712/140042.241876:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[20944:20944:0712/140042.242071:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[20944:20944:0712/140042.259849:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/140042.756452:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7ff05fa3c2e0 0x6be7d8204e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140042.757864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 078118c81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/140042.758142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140042.759696:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20944:20944:0712/140042.801154:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/140042.803967:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x6be7d58f820
[1:1:0712/140042.804235:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[20944:20944:0712/140042.808870:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/140042.824488:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/140042.824824:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[20944:20944:0712/140042.826177:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[20944:20944:0712/140042.836399:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20944:20944:0712/140042.837426:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20944:20956:0712/140042.843504:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[20944:20956:0712/140042.843601:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[20944:20944:0712/140042.843736:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[20944:20944:0712/140042.843849:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[20944:20944:0712/140042.843991:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,20997, 4
[1:7:0712/140042.847137:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/140043.376906:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/140043.870912:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7ff05fa3c2e0 0x6be7d919e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/140043.872231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 078118c81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/140043.872550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/140043.873402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20944:20944:0712/140044.114175:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[20944:20944:0712/140044.114270:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/140044.126661:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140044.321269:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140044.746876:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140044.747125:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[20944:20944:0712/140044.784119:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[20944:20974:0712/140044.784576:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/140044.784773:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/140044.784985:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/140044.785384:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/140044.785528:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/140044.788786:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3bfe622b, 1
[1:1:0712/140044.789186:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xde724e4, 0
[1:1:0712/140044.789422:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x5155f7f, 3
[1:1:0712/140044.789638:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2f1663d1, 2
[1:1:0712/140044.789846:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe424ffffffe70d 2b62fffffffe3b ffffffd163162f 7f5f1505 , 10104, 5
[1:1:0712/140044.791129:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20944:20974:0712/140044.791444:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�$�+b�;�c/_�PL
[20944:20974:0712/140044.791533:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �$�+b�;�c/_�O�PL
[20944:20974:0712/140044.791880:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 21041, 5, e424e70d 2b62fe3b d163162f 7f5f1505 
[1:1:0712/140044.791671:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0740130a0, 3
[1:1:0712/140044.792429:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff07419e080, 2
[1:1:0712/140044.792674:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff05de61d20, -2
[1:1:0712/140044.817547:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/140044.817938:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f1663d1
[1:1:0712/140044.818331:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f1663d1
[1:1:0712/140044.818988:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f1663d1
[1:1:0712/140044.820495:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.820741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.820963:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.821182:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.821886:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f1663d1
[1:1:0712/140044.822213:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff075dd87ba
[1:1:0712/140044.822401:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff075dcfdef, 7ff075dd877a, 7ff075dda0cf
[1:1:0712/140044.824643:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f1663d1
[1:1:0712/140044.825045:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f1663d1
[1:1:0712/140044.825836:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f1663d1
[1:1:0712/140044.827920:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.828181:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.828447:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.828684:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f1663d1
[1:1:0712/140044.829956:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f1663d1
[1:1:0712/140044.830381:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff075dd87ba
[1:1:0712/140044.830561:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff075dcfdef, 7ff075dd877a, 7ff075dda0cf
[1:1:0712/140044.839721:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/140044.840399:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/140044.840598:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffed9129cc8, 0x7ffed9129c48)
[1:1:0712/140044.857145:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/140044.861530:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/140044.951221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 537, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140044.955770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 078118dae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/140044.956071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/140044.964636:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/140045.049232:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x6be7d57f220
[1:1:0712/140045.049579:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[20944:20944:0712/140045.469844:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20944:20944:0712/140045.476823:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20944:20956:0712/140045.514485:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[20944:20956:0712/140045.514628:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[20944:20944:0712/140045.515120:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://hf.meituan.com/
[20944:20944:0712/140045.515212:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://hf.meituan.com/, https://hf.meituan.com/, 1
[20944:20944:0712/140045.515368:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://hf.meituan.com/, HTTP/1.1 200 OK Server: openresty Date: Fri, 12 Jul 2019 21:00:45 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: ci=56; path=/; expires=Tue, 10 Sep 2019 21:00:45 GMT; domain=.meituan.com Set-Cookie: rvct=56%2C1%2C99%2C106; path=/; expires=Tue, 10 Sep 2019 21:00:45 GMT; domain=.meituan.com Content-Encoding: gzip  ,21041, 5
[1:7:0712/140045.519936:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/140045.550725:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://hf.meituan.com/
[20944:20944:0712/140045.675515:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://hf.meituan.com/, https://hf.meituan.com/, 1
[20944:20944:0712/140045.675622:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://hf.meituan.com/, https://hf.meituan.com
[1:1:0712/140045.725454:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140045.759758:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140045.773898:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140045.797341:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140045.797618:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hf.meituan.com/"
[1:1:0712/140045.920031:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/140046.106546:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140046.118347:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 149, "https://hf.meituan.com/"
[1:1:0712/140046.120765:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140046.126632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , ;!function(t,e){"function"==typeof define&&define.amd?define(e):"object"==typeof exports?module.expo
[1:1:0712/140046.126896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140046.403946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 149, "https://hf.meituan.com/"
[1:1:0712/140046.459340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 153, "https://hf.meituan.com/"
[1:1:0712/140046.460649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , ;!function(){"use strict";function t(t){if("string"!=typeof t&&(t=t.toString()),/[^a-z0-9\-#$%&'*+.\
[1:1:0712/140046.460873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140046.463785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 153, "https://hf.meituan.com/"
[1:1:0712/140046.471337:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 153, "https://hf.meituan.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/140046.538009:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.074883, 330, 1
[1:1:0712/140046.538263:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140047.129048:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140047.129228:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hf.meituan.com/"
[1:1:0712/140047.129638:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7ff05db14070 0x6be7d890560 , "https://hf.meituan.com/"
[1:1:0712/140047.130204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , window.comPtData = window.comPtData || {};
window.comPtData['header'] = {"currentCity":{"id":56,"nam
[1:1:0712/140047.130320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140047.271520:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.142397, 1407, 1
[1:1:0712/140047.271822:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140047.408826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7ff05fa3c2e0 0x6be7d7490e0 , "https://hf.meituan.com/"
[1:1:0712/140047.411042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , !function(){"use strict";var u=!0,n="_MeiTuanALogObject",l=1,r="dianping_nova",h="waimai",m="group",
[1:1:0712/140047.411168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140047.416139:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1576f02229c8, 0x6be7d3f41a8
[1:1:0712/140047.416254:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 100
[1:1:0712/140047.416423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 254
[1:1:0712/140047.416543:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 254 0x7ff05db14070 0x6be7d74d960 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 215 0x7ff05fa3c2e0 0x6be7d7490e0 
[1:1:0712/140047.598703:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140047.599233:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140047.599721:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140047.600193:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140047.600551:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[20944:20944:0712/140114.831475:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/140114.872693:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/140115.129489:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1576f02229c8, 0x6be7d3f41a8
[1:1:0712/140115.129814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 100
[1:1:0712/140115.130200:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 283
[1:1:0712/140115.130483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 283 0x7ff05db14070 0x6be7d6b4ce0 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 215 0x7ff05fa3c2e0 0x6be7d7490e0 
[1:1:0712/140115.183976:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1576f02229c8, 0x6be7d3f41a8
[1:1:0712/140115.184277:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 1000
[1:1:0712/140115.184753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 284
[1:1:0712/140115.185042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 284 0x7ff05db14070 0x6be7d7b9de0 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 215 0x7ff05fa3c2e0 0x6be7d7490e0 
[1:1:0712/140115.287556:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1576f02229c8, 0x6be7d3f41a8
[1:1:0712/140115.288815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 0
[1:1:0712/140115.289271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 299
[1:1:0712/140115.290039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 299 0x7ff05db14070 0x6be7d9c3ce0 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 215 0x7ff05fa3c2e0 0x6be7d7490e0 
[1:1:0712/140115.765008:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/140115.765193:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://hf.meituan.com/"
[1:1:0712/140115.766045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7ff05db14070 0x6be7d9c8960 , "https://hf.meituan.com/"
[1:1:0712/140115.768940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , window.AppData = {"bannerList":[{"position":1,"content":[{"url":"http:\u002F\u002Fp0.meituan.net\u00
[1:1:0712/140115.769066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140115.776104:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7ff05db14070 0x6be7d9c8960 , "https://hf.meituan.com/"
[1:1:0712/140115.847633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/140115.847970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[0712/140115.940448:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/140115.940862:INFO:switcher_clone.cc(787)] backtrace rip is 7fb82dd5f891
[1:1:0712/140116.446566:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 254, 7ff060459881
[1:1:0712/140116.452637:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"337234322860","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140116.452932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hf.meituan.com/","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140116.453220:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hf.meituan.com/"
[1:1:0712/140116.453730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , t, (){clearTimeout(jn);try{Cn()}catch(t){}finally{wn()===at?jn=A(t,On):clearTimeout(jn)}}
[1:1:0712/140116.453930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140116.456626:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1576f02229c8, 0x6be7d3f4150
[1:1:0712/140116.456816:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 5000
[1:1:0712/140116.457153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 332
[1:1:0712/140116.457339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 332 0x7ff05db14070 0x6be7d29d4e0 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 254 0x7ff05db14070 0x6be7d74d960 
[1:1:0712/140116.473186:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 283, 7ff060459881
[1:1:0712/140116.487461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"337234322860","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140116.487854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hf.meituan.com/","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140116.488146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hf.meituan.com/"
[1:1:0712/140116.488631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , (){n().then(t)}
[1:1:0712/140116.488846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140116.490659:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1576f02229c8, 0x6be7d3f4150
[1:1:0712/140116.490907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 100
[1:1:0712/140116.491246:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 333
[1:1:0712/140116.491437:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7ff05db14070 0x6be7cece0e0 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 283 0x7ff05db14070 0x6be7d6b4ce0 
[1:1:0712/140116.494289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 299, 7ff060459881
[1:1:0712/140116.509156:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"337234322860","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140116.509445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hf.meituan.com/","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140116.509722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hf.meituan.com/"
[1:1:0712/140116.510227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140116.510403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140116.516900:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1576f02229c8, 0x6be7d3f4150
[1:1:0712/140116.517085:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 0
[1:1:0712/140116.517411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 334
[1:1:0712/140116.517601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 334 0x7ff05db14070 0x6be7d29d8e0 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 299 0x7ff05db14070 0x6be7d9c3ce0 
[1:1:0712/140116.685469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7ff07419e080 0x6be7d776600 1 0 0x6be7d776618 , "https://hf.meituan.com/"
[1:1:0712/140116.697107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , ;"use strict";function Nb(e){function t(e,t){return null==e||"http://www.w3.org/1999/xhtml"===e?oe(t
[1:1:0712/140116.697365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140116.714666:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140117.072284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7ff07419e080 0x6be7d776600 1 0 0x6be7d776618 , "https://hf.meituan.com/"
[1:1:0712/140117.151642:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7ff07419e080 0x6be7d543d80 1 0 0x6be7d543d98 , "https://hf.meituan.com/"
[1:1:0712/140117.162732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , ;var App=webpackJsonpApp([8],{0:function(e,t,n){(function(t){function r(e){return(r="function"==type
[1:1:0712/140117.163025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140117.263259:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7ff07419e080 0x6be7d543d80 1 0 0x6be7d543d98 , "https://hf.meituan.com/"
		remove user.11_5520e0b9 -> 0
[20944:20944:0712/140129.154125:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/5b21cddb4bb1cbc3a9c3bce0f726c75940469.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[20944:20944:0712/140129.169741:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/16442c19da1f1c4544f794e29d99c92051716.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[20944:20944:0712/140129.178349:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/8cce56c467a17e04f3094d1e455462a0132772.png'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[20944:20944:0712/140129.187277:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/e473bb428f070321269b23370ff02ba956209.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[20944:20944:0712/140129.209272:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/33ff80dc00f832d697f3e20fc030799560495.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[20944:20944:0712/140129.213061:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/a97baf515235f4c5a2b1323a741e577185048.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[20944:20944:0712/140129.225689:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/826a5ed09dab49af658c34624d75491861404.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[20944:20944:0712/140129.227993:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://hf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/daa73310c9e57454dc97f0146640fd9f69772.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[1:1:0712/140130.415420:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 5000
[1:1:0712/140130.415865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://hf.meituan.com/, 386
[1:1:0712/140130.416146:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 386 0x7ff05db14070 0x6be81f55060 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 314 0x7ff07419e080 0x6be7d543d80 1 0 0x6be7d543d98 
[1:1:0712/140131.060246:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 13.7977, 0, 0
[1:1:0712/140131.060558:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/140131.211100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , document.readyState
[1:1:0712/140131.211419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140131.375272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , (t){try{var n=[];(t||[]).forEach(function(t){n.push(t.deviceId)}),cn.did=n.map(function(t){return t.
[1:1:0712/140131.376035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140131.491221:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "upgradeneeded", "https://hf.meituan.com/"
[1:1:0712/140131.493628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , yi.onupgradeneeded, (t){bi=t.target.result,(wi=bi.createObjectStore("cache",{keyPath:"id",autoIncrement:!0})).createInde
[1:1:0712/140131.493885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140131.519378:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 284, 7ff060459881
[1:1:0712/140131.538386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"337234322860","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140131.538746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hf.meituan.com/","ptid":"215 0x7ff05fa3c2e0 0x6be7d7490e0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140131.539173:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hf.meituan.com/"
[1:1:0712/140131.539758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , fu, (){var n,r;Sn(!1),(n=uu,r={none:!0},new Ir(function(e){try{var t=Se(Gi,"4.12.0");!Gi||!te(t)||t<0?e(
[1:1:0712/140131.540032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140131.544263:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1576f02229c8, 0x6be7d3f4150
[1:1:0712/140131.544490:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 0
[1:1:0712/140131.544908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 446
[1:1:0712/140131.545149:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 446 0x7ff05db14070 0x6be82647be0 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 284 0x7ff05db14070 0x6be7d7b9de0 
[1:1:0712/140131.546567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 334, 7ff060459881
[1:1:0712/140131.567531:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"337234322860","ptid":"299 0x7ff05db14070 0x6be7d9c3ce0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140131.567980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hf.meituan.com/","ptid":"299 0x7ff05db14070 0x6be7d9c3ce0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140131.568477:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hf.meituan.com/"
[1:1:0712/140131.569092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/140131.569322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140131.571386:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1576f02229c8, 0x6be7d3f4150
[1:1:0712/140131.571603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 0
[1:1:0712/140131.572020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 448
[1:1:0712/140131.572255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 448 0x7ff05db14070 0x6be81f80660 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 334 0x7ff05db14070 0x6be7d29d8e0 
[1:1:0712/140131.574452:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 333, 7ff060459881
[1:1:0712/140131.583960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"337234322860","ptid":"283 0x7ff05db14070 0x6be7d6b4ce0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140131.584319:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://hf.meituan.com/","ptid":"283 0x7ff05db14070 0x6be7d6b4ce0 ","rf":"5:3_https://hf.meituan.com/"}
[1:1:0712/140131.584728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://hf.meituan.com/"
[1:1:0712/140131.585275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , (){n().then(t)}
[1:1:0712/140131.585487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140131.586789:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1576f02229c8, 0x6be7d3f4150
[1:1:0712/140131.587021:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://hf.meituan.com/", 100
[1:1:0712/140131.587394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://hf.meituan.com/, 450
[1:1:0712/140131.587621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7ff05db14070 0x6be82646c60 , 5:3_https://hf.meituan.com/, 1, -5:3_https://hf.meituan.com/, 333 0x7ff05db14070 0x6be7cece0e0 
[1:1:0712/140131.752039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/140131.752335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140131.770840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/140131.771153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140133.736127:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140133.736668:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140133.738192:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140133.738604:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/140133.738973:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[20944:20944:0712/140136.762155:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/140141.490415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/140141.490764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140141.502689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/140141.502963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140141.590929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/140141.591238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140141.602050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/140141.602330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140141.626208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/140141.626505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
[1:1:0712/140141.636866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://hf.meituan.com/, 337234322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/140141.637107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://hf.meituan.com/", "hf.meituan.com", 3, 1, , , 0
		remove user.12_d0823915 -> 0
		remove user.13_4f53a229 -> 0
		remove user.14_230cb015 -> 0
		remove user.15_f3b25585 -> 0
		remove user.16_bcd1f688 -> 0
