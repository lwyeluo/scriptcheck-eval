[0712/134146.796880:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134146.797307:INFO:switcher_clone.cc(787)] backtrace rip is 7f9b6c53d891
[0712/134147.775315:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134147.775778:INFO:switcher_clone.cc(787)] backtrace rip is 7f9092993891
[1:1:0712/134147.788316:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/134147.788581:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/134147.794032:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[18599:18599:0712/134149.097142:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/134149.155578:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134149.155842:INFO:switcher_clone.cc(787)] backtrace rip is 7f17282c6891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6eb10a2f-d1d9-4f86-91ac-3b3a6791d492
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[18630:18630:0712/134149.364208:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18630
[18643:18643:0712/134149.364645:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18643
[18599:18599:0712/134149.575542:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[18599:18628:0712/134149.576768:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/134149.577030:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/134149.577304:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/134149.577893:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/134149.578063:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/134149.581569:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3dae58fa, 1
[1:1:0712/134149.581926:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36cd3946, 0
[1:1:0712/134149.582141:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x19800210, 3
[1:1:0712/134149.582336:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xab71820, 2
[1:1:0712/134149.582582:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4639ffffffcd36 fffffffa58ffffffae3d 2018ffffffb70a 1002ffffff8019 , 10104, 4
[1:1:0712/134149.583555:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18599:18628:0712/134149.583796:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGF9�6�X�= �
��97
[18599:18628:0712/134149.583862:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is F9�6�X�= �
��d�97
[18599:18628:0712/134149.584160:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/134149.583991:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9090bce0a0, 3
[18599:18628:0712/134149.584222:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18651, 4, 4639cd36 fa58ae3d 2018b70a 10028019 
[1:1:0712/134149.584242:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9090d59080, 2
[1:1:0712/134149.584398:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f907aa1cd20, -2
[1:1:0712/134149.603497:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/134149.604442:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ab71820
[1:1:0712/134149.605408:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ab71820
[1:1:0712/134149.607037:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ab71820
[1:1:0712/134149.608547:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.608759:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.608941:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.609156:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.609802:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ab71820
[1:1:0712/134149.610135:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90929937ba
[1:1:0712/134149.610306:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f909298adef, 7f909299377a, 7f90929950cf
[1:1:0712/134149.617241:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ab71820
[1:1:0712/134149.617697:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ab71820
[1:1:0712/134149.618468:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ab71820
[1:1:0712/134149.620523:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.620721:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.620907:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.621133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab71820
[1:1:0712/134149.622375:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ab71820
[1:1:0712/134149.622732:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90929937ba
[1:1:0712/134149.622884:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f909298adef, 7f909299377a, 7f90929950cf
[1:1:0712/134149.626652:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/134149.626943:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/134149.627040:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe315d1fa8, 0x7ffe315d1f28)
[1:1:0712/134149.641310:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/134149.643952:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[18599:18599:0712/134150.163124:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18599:18599:0712/134150.164278:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18599:18610:0712/134150.178321:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[18599:18599:0712/134150.178419:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[18599:18610:0712/134150.178425:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[18599:18599:0712/134150.178483:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[18599:18599:0712/134150.178577:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,18651, 4
[1:7:0712/134150.180786:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[18599:18621:0712/134150.234663:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/134150.237020:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xcaa667bf220
[1:1:0712/134150.237270:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/134150.522868:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/134152.096129:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134152.100229:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18599:18599:0712/134152.290364:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[18599:18599:0712/134152.290421:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/134152.927242:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134153.206892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b06f6c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/134153.207221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134153.224768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b06f6c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/134153.225120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134153.264321:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134153.264618:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134153.690149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134153.698301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b06f6c21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/134153.698553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134153.734369:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134153.744999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b06f6c21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/134153.745302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134153.757121:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[18599:18599:0712/134153.759520:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/134153.760545:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xcaa667bde20
[1:1:0712/134153.760756:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[18599:18599:0712/134153.766565:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[18599:18599:0712/134153.793892:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[18599:18599:0712/134153.793990:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/134153.841747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134154.888170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f907c5f72e0 0xcaa668733e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134154.889610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b06f6c21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/134154.889859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134154.891709:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18599:18599:0712/134154.948401:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/134154.949912:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xcaa667be820
[1:1:0712/134154.950160:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[18599:18599:0712/134154.960846:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/134154.972503:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/134154.972790:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[18599:18599:0712/134154.983533:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[18599:18599:0712/134154.997012:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18599:18599:0712/134154.998289:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18599:18610:0712/134155.005694:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[18599:18610:0712/134155.005787:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[18599:18599:0712/134155.006028:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[18599:18599:0712/134155.006125:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[18599:18599:0712/134155.006298:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,18651, 4
[1:7:0712/134155.016512:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/134155.567979:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/134156.097713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f907c5f72e0 0xcaa66b50b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134156.098716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b06f6c21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/134156.098955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134156.099738:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18599:18599:0712/134156.199256:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[18599:18599:0712/134156.199377:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/134156.202640:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134156.625009:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[18599:18599:0712/134156.904384:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[18599:18628:0712/134156.904858:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/134156.905086:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/134156.905353:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/134156.905739:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/134156.905917:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/134156.909251:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x652c18c, 1
[1:1:0712/134156.909633:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2d8cd870, 0
[1:1:0712/134156.909840:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x35b12262, 3
[1:1:0712/134156.910048:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x299e99a5, 2
[1:1:0712/134156.910252:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 70ffffffd8ffffff8c2d ffffff8cffffffc15206 ffffffa5ffffff99ffffff9e29 6222ffffffb135 , 10104, 5
[1:1:0712/134156.911305:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18599:18628:0712/134156.911554:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGp،-��R���)b"�5
:7
[18599:18628:0712/134156.911622:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is p،-��R���)b"�5(;
:7
[1:1:0712/134156.911750:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9090bce0a0, 3
[18599:18628:0712/134156.911956:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18696, 5, 70d88c2d 8cc15206 a5999e29 6222b135 
[1:1:0712/134156.911975:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9090d59080, 2
[1:1:0712/134156.912161:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f907aa1cd20, -2
[1:1:0712/134156.936892:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/134156.937221:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 299e99a5
[1:1:0712/134156.937564:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 299e99a5
[1:1:0712/134156.938210:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 299e99a5
[1:1:0712/134156.939873:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.940171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.940395:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.940613:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.941458:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 299e99a5
[1:1:0712/134156.941859:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90929937ba
[1:1:0712/134156.942033:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f909298adef, 7f909299377a, 7f90929950cf
[1:1:0712/134156.949039:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 299e99a5
[1:1:0712/134156.949543:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 299e99a5
[1:1:0712/134156.950478:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 299e99a5
[1:1:0712/134156.953044:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.953343:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.953583:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.953822:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 299e99a5
[1:1:0712/134156.955359:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 299e99a5
[1:1:0712/134156.955834:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90929937ba
[1:1:0712/134156.956029:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f909298adef, 7f909299377a, 7f90929950cf
[1:1:0712/134156.965569:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/134156.966273:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/134156.966455:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe315d1fa8, 0x7ffe315d1f28)
[1:1:0712/134156.982923:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/134156.988847:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/134157.153974:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134157.154254:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/134157.210039:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xcaa66784220
[1:1:0712/134157.210693:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/134157.519053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/134157.522609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b06f6d4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/134157.522918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/134157.526597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[18599:18599:0712/134157.714644:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18599:18599:0712/134157.720856:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/134157.750917:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134157.751691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b06f6c21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/134157.751976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[18599:18610:0712/134157.756260:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[18599:18610:0712/134157.756351:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[18599:18599:0712/134157.756877:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://lf.meituan.com/
[18599:18599:0712/134157.756985:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://lf.meituan.com/, https://lf.meituan.com/, 1
[18599:18599:0712/134157.757167:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://lf.meituan.com/, HTTP/1.1 200 OK Server: openresty Date: Fri, 12 Jul 2019 20:41:57 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: ci=106; path=/; expires=Tue, 10 Sep 2019 20:41:57 GMT; domain=.meituan.com Set-Cookie: rvct=106; path=/; expires=Tue, 10 Sep 2019 20:41:57 GMT; domain=.meituan.com Content-Encoding: gzip  ,18696, 5
[1:7:0712/134157.762876:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/134157.809001:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://lf.meituan.com/
[18599:18599:0712/134157.918954:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://lf.meituan.com/, https://lf.meituan.com/, 1
[18599:18599:0712/134157.919080:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://lf.meituan.com/, https://lf.meituan.com
[1:1:0712/134157.956287:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134158.111539:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134158.123700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/134158.125426:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/134158.125643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b06f6d4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/134158.125911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/134158.137863:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134158.176058:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134158.176376:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://lf.meituan.com/"
[1:1:0712/134158.257830:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/134158.259054:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/134158.272489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b06f6d4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/134158.272819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/134158.315596:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134158.698612:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134158.899208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f907aa37bd0 0xcaa668a5ed8 , "https://lf.meituan.com/"
[1:1:0712/134158.902392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , ;!function(t,e){"function"==typeof define&&define.amd?define(e):"object"==typeof exports?module.expo
[1:1:0712/134158.902636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134158.914850:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134159.110071:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f907aa37bd0 0xcaa668a5ed8 , "https://lf.meituan.com/"
[1:1:0712/134159.113801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f907aa37bd0 0xcaa668a5ed8 , "https://lf.meituan.com/"
[1:1:0712/134159.121229:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f907aa37bd0 0xcaa668a5ed8 , "https://lf.meituan.com/"
[1:1:0712/134159.130040:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f907aa37bd0 0xcaa668a5ed8 , "https://lf.meituan.com/"
[1:1:0712/134159.177489:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0690789, 330, 1
[1:1:0712/134159.177765:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/134159.449420:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7f907c5f72e0 0xcaa668a5de0 , "https://lf.meituan.com/"
[1:1:0712/134159.457692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , !function(){"use strict";var u=!0,n="_MeiTuanALogObject",l=1,r="dianping_nova",h="waimai",m="group",
[1:1:0712/134159.457967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134159.477176:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21e926e229c8, 0xcaa66600160
[1:1:0712/134159.477496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 100
[1:1:0712/134159.477870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 238
[1:1:0712/134159.478127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 238 0x7f907a6cf070 0xcaa668a75e0 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 203 0x7f907c5f72e0 0xcaa668a5de0 
[1:1:0712/134159.708860:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134159.709396:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134159.711228:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134159.711709:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134159.712113:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[18599:18599:0712/134223.699821:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/134223.710028:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
		remove user.f_b79a05a8 -> 0
[1:1:0712/134223.935228:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21e926e229c8, 0xcaa66600160
[1:1:0712/134223.935524:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 100
[1:1:0712/134223.935913:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 267
[1:1:0712/134223.936184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 267 0x7f907a6cf070 0xcaa66b620e0 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 203 0x7f907c5f72e0 0xcaa668a5de0 
[1:1:0712/134224.020008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x21e926e229c8, 0xcaa66600160
[1:1:0712/134224.020367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 1000
[1:1:0712/134224.020748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 268
[1:1:0712/134224.021013:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 268 0x7f907a6cf070 0xcaa66a9e860 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 203 0x7f907c5f72e0 0xcaa668a5de0 
[1:1:0712/134224.108123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21e926e229c8, 0xcaa66600160
[1:1:0712/134224.108475:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 0
[1:1:0712/134224.108942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 285
[1:1:0712/134224.109187:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 285 0x7f907a6cf070 0xcaa66a9ede0 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 203 0x7f907c5f72e0 0xcaa668a5de0 
[1:1:0712/134224.293048:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134224.293313:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://lf.meituan.com/"
[1:1:0712/134224.294222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f907a6cf070 0xcaa665df1e0 , "https://lf.meituan.com/"
[1:1:0712/134224.295332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , window.comPtData = window.comPtData || {};
window.comPtData['header'] = {"currentCity":{"id":106,"na
[1:1:0712/134224.295572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134224.388641:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0952351, 1407, 1
[1:1:0712/134224.388922:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134224.692636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/134224.692939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[0712/134224.849654:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134224.849953:INFO:switcher_clone.cc(787)] backtrace rip is 7fe49bb4a891
[1:1:0712/134225.113568:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 238, 7f907d014881
[1:1:0712/134225.120351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e6c6e142860","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134225.120730:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://lf.meituan.com/","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134225.121136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://lf.meituan.com/"
[1:1:0712/134225.121722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , t, (){clearTimeout(jn);try{Cn()}catch(t){}finally{wn()===at?jn=A(t,On):clearTimeout(jn)}}
[1:1:0712/134225.121961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134225.123627:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x21e926e229c8, 0xcaa66600150
[1:1:0712/134225.123878:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 5000
[1:1:0712/134225.124273:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 331
[1:1:0712/134225.124512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 331 0x7f907a6cf070 0xcaa66b65260 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 238 0x7f907a6cf070 0xcaa668a75e0 
[1:1:0712/134225.126048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 267, 7f907d014881
[1:1:0712/134225.140377:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e6c6e142860","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134225.140755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://lf.meituan.com/","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134225.141160:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://lf.meituan.com/"
[1:1:0712/134225.141709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , (){n().then(t)}
[1:1:0712/134225.141922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134225.143476:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21e926e229c8, 0xcaa66600150
[1:1:0712/134225.143715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 100
[1:1:0712/134225.144106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 332
[1:1:0712/134225.144332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 332 0x7f907a6cf070 0xcaa665df4e0 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 267 0x7f907a6cf070 0xcaa66b620e0 
[1:1:0712/134225.146919:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 285, 7f907d014881
[1:1:0712/134225.162734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e6c6e142860","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134225.163081:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://lf.meituan.com/","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134225.163537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://lf.meituan.com/"
[1:1:0712/134225.164125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/134225.164344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134225.171532:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21e926e229c8, 0xcaa66600150
[1:1:0712/134225.171886:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 0
[1:1:0712/134225.172289:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 333
[1:1:0712/134225.172529:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7f907a6cf070 0xcaa668ac960 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 285 0x7f907a6cf070 0xcaa66a9ede0 
[1:1:0712/134225.270259:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134225.270535:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://lf.meituan.com/"
[1:1:0712/134225.272998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f907a6cf070 0xcaa66b61f60 , "https://lf.meituan.com/"
[1:1:0712/134225.284401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , window.AppData = {"bannerList":[{"position":1,"content":[{"url":"http:\u002F\u002Fp0.meituan.net\u00
[1:1:0712/134225.284794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134225.310867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f907a6cf070 0xcaa66b61f60 , "https://lf.meituan.com/"
[1:1:0712/134225.349987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f907a6cf070 0xcaa66b61f60 , "https://lf.meituan.com/"
[1:1:0712/134225.653797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f907a6cf070 0xcaa66b61f60 , "https://lf.meituan.com/"
[1:1:0712/134225.684493:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 299 0x7f9090d59080 0xcaa662f27e0 1 0 0xcaa662f27f8 , "https://lf.meituan.com/"
[1:1:0712/134225.716949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , ;var App=webpackJsonpApp([8],{0:function(e,t,n){(function(t){function r(e){return(r="function"==type
[1:1:0712/134225.717256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134225.918080:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 299 0x7f9090d59080 0xcaa662f27e0 1 0 0xcaa662f27f8 , "https://lf.meituan.com/"
[1:1:0712/134230.919613:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134236.104530:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134236.105043:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[18599:18599:0712/134237.085394:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/5b21cddb4bb1cbc3a9c3bce0f726c75940469.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[18599:18599:0712/134237.095397:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/16442c19da1f1c4544f794e29d99c92051716.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[18599:18599:0712/134237.104027:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/8cce56c467a17e04f3094d1e455462a0132772.png'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[18599:18599:0712/134237.139939:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/e473bb428f070321269b23370ff02ba956209.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[18599:18599:0712/134237.148976:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/33ff80dc00f832d697f3e20fc030799560495.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[18599:18599:0712/134237.158832:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/a97baf515235f4c5a2b1323a741e577185048.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[18599:18599:0712/134237.167826:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/826a5ed09dab49af658c34624d75491861404.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[18599:18599:0712/134237.173046:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://lf.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/daa73310c9e57454dc97f0146640fd9f69772.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[1:1:0712/134238.184448:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 5000
[1:1:0712/134238.184891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://lf.meituan.com/, 380
[1:1:0712/134238.185112:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 380 0x7f907a6cf070 0xcaa6b297ee0 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 299 0x7f9090d59080 0xcaa662f27e0 1 0 0xcaa662f27f8 
[1:1:0712/134238.802881:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 12.8855, 0, 0
[1:1:0712/134238.803172:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134239.143538:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://lf.meituan.com/"
[1:1:0712/134239.144743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , dispatchEvent, (e,t){if(bn._enabled){var n=G(t);if(n=rn.getClosestInstanceFromNode(n),null===n||"number"!=typeof n.
[1:1:0712/134239.144886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.197667:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://lf.meituan.com/"
[1:1:0712/134239.198125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , dispatchEvent, (e,t){if(bn._enabled){var n=G(t);if(n=rn.getClosestInstanceFromNode(n),null===n||"number"!=typeof n.
[1:1:0712/134239.198248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.233077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://lf.meituan.com/"
[1:1:0712/134239.233519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , dispatchEvent, (e,t){if(bn._enabled){var n=G(t);if(n=rn.getClosestInstanceFromNode(n),null===n||"number"!=typeof n.
[1:1:0712/134239.233637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.404257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , document.readyState
[1:1:0712/134239.404574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.500119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , (t){try{var n=[];(t||[]).forEach(function(t){n.push(t.deviceId)}),cn.did=n.map(function(t){return t.
[1:1:0712/134239.500418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.521124:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "upgradeneeded", "https://lf.meituan.com/"
[1:1:0712/134239.522487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , yi.onupgradeneeded, (t){bi=t.target.result,(wi=bi.createObjectStore("cache",{keyPath:"id",autoIncrement:!0})).createInde
[1:1:0712/134239.522711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.616357:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 268, 7f907d014881
[1:1:0712/134239.635673:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e6c6e142860","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134239.636077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://lf.meituan.com/","ptid":"203 0x7f907c5f72e0 0xcaa668a5de0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134239.636479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://lf.meituan.com/"
[1:1:0712/134239.637062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , fu, (){var n,r;Sn(!1),(n=uu,r={none:!0},new Ir(function(e){try{var t=Se(Gi,"4.12.0");!Gi||!te(t)||t<0?e(
[1:1:0712/134239.637300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.641645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21e926e229c8, 0xcaa66600150
[1:1:0712/134239.641893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 0
[1:1:0712/134239.642291:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 448
[1:1:0712/134239.642524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 448 0x7f907a6cf070 0xcaa668a3960 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 268 0x7f907a6cf070 0xcaa66a9e860 
[1:1:0712/134239.643986:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 333, 7f907d014881
[1:1:0712/134239.663275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e6c6e142860","ptid":"285 0x7f907a6cf070 0xcaa66a9ede0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134239.663883:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://lf.meituan.com/","ptid":"285 0x7f907a6cf070 0xcaa66a9ede0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134239.664337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://lf.meituan.com/"
[1:1:0712/134239.664895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/134239.665138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.667211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21e926e229c8, 0xcaa66600150
[1:1:0712/134239.667412:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 0
[1:1:0712/134239.667957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 450
[1:1:0712/134239.668232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7f907a6cf070 0xcaa6bb298e0 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 333 0x7f907a6cf070 0xcaa668ac960 
[1:1:0712/134239.684381:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 332, 7f907d014881
[1:1:0712/134239.703360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e6c6e142860","ptid":"267 0x7f907a6cf070 0xcaa66b620e0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134239.703712:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://lf.meituan.com/","ptid":"267 0x7f907a6cf070 0xcaa66b620e0 ","rf":"5:3_https://lf.meituan.com/"}
[1:1:0712/134239.704172:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://lf.meituan.com/"
[1:1:0712/134239.704710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , (){n().then(t)}
[1:1:0712/134239.704927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134239.706254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x21e926e229c8, 0xcaa66600150
[1:1:0712/134239.706851:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://lf.meituan.com/", 100
[1:1:0712/134239.707294:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://lf.meituan.com/, 452
[1:1:0712/134239.707551:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 452 0x7f907a6cf070 0xcaa6baa9be0 , 5:3_https://lf.meituan.com/, 1, -5:3_https://lf.meituan.com/, 332 0x7f907a6cf070 0xcaa665df4e0 
[1:1:0712/134240.245392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134240.245711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134240.263797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134240.264244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134244.962626:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134244.964580:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134244.965039:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[18599:18599:0712/134245.721694:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
		remove user.11_43632428 -> 0
		remove user.12_f5f82ede -> 0
		remove user.13_c36906e5 -> 0
[1:1:0712/134248.831159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134248.831476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134248.841857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134248.842127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134248.931551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134248.932640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134248.942823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134248.943067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134250.469268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134250.469447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134250.473942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134250.474115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134250.534849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134250.535032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134250.542958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134250.543180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134252.886848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134252.887085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
[1:1:0712/134252.893383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://lf.meituan.com/, 0e6c6e142860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134252.893599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://lf.meituan.com/", "lf.meituan.com", 3, 1, , , 0
		remove user.14_118d7296 -> 0
		remove user.15_95bc6dec -> 0
		remove user.16_d86b53c3 -> 0
