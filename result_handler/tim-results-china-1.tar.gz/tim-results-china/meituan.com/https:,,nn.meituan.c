[0712/134601.799243:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134601.799600:INFO:switcher_clone.cc(787)] backtrace rip is 7fd95ad3e891
[0712/134602.871629:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134602.872027:INFO:switcher_clone.cc(787)] backtrace rip is 7f98c3f5d891
[1:1:0712/134602.884947:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/134602.885224:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/134602.893410:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[19156:19156:0712/134604.297461:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ae80a010-0c8e-4aa7-8498-90190e5ff135
[0712/134604.450738:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134604.451103:INFO:switcher_clone.cc(787)] backtrace rip is 7fe4adbf2891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[19188:19188:0712/134604.650602:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=19188
[19201:19201:0712/134604.651044:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=19201
[19156:19156:0712/134604.934434:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[19156:19186:0712/134604.935168:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/134604.935378:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/134604.935596:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/134604.936218:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/134604.936381:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/134604.939402:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x19eb82b2, 1
[1:1:0712/134604.939826:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e3228bc, 0
[1:1:0712/134604.940037:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3f5132ad, 3
[1:1:0712/134604.940240:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1229dec3, 2
[1:1:0712/134604.940468:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbc28322e ffffffb2ffffff82ffffffeb19 ffffffc3ffffffde2912 ffffffad32513f , 10104, 4
[1:1:0712/134604.941456:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[19156:19186:0712/134604.941737:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�(2.�����)�2Q?�^I
[19156:19186:0712/134604.941809:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �(2.�����)�2Q?��^I
[1:1:0712/134604.941712:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98c21980a0, 3
[19156:19186:0712/134604.942099:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/134604.941975:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98c2323080, 2
[19156:19186:0712/134604.942193:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 19209, 4, bc28322e b282eb19 c3de2912 ad32513f 
[1:1:0712/134604.942236:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98abfe6d20, -2
[1:1:0712/134604.961213:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/134604.962054:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1229dec3
[1:1:0712/134604.963002:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1229dec3
[1:1:0712/134604.964603:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1229dec3
[1:1:0712/134604.966106:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.966331:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.966556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.966815:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.967480:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1229dec3
[1:1:0712/134604.967936:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f98c3f5d7ba
[1:1:0712/134604.968195:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f98c3f54def, 7f98c3f5d77a, 7f98c3f5f0cf
[1:1:0712/134604.973660:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1229dec3
[1:1:0712/134604.974049:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1229dec3
[1:1:0712/134604.974808:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1229dec3
[1:1:0712/134604.976775:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.977020:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.977253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.977477:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1229dec3
[1:1:0712/134604.978763:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1229dec3
[1:1:0712/134604.979140:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f98c3f5d7ba
[1:1:0712/134604.979278:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f98c3f54def, 7f98c3f5d77a, 7f98c3f5f0cf
[1:1:0712/134604.987221:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/134604.987698:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/134604.987906:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff18dcf408, 0x7fff18dcf388)
[1:1:0712/134605.003647:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/134605.006735:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[19156:19156:0712/134605.600516:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[19156:19156:0712/134605.601758:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[19156:19168:0712/134605.624181:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[19156:19168:0712/134605.624297:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[19156:19156:0712/134605.624503:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[19156:19156:0712/134605.624602:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[19156:19156:0712/134605.624776:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,19209, 4
[1:7:0712/134605.626708:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[19156:19181:0712/134605.691311:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/134605.696241:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2c51dff61220
[1:1:0712/134605.696460:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/134606.026943:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[19156:19156:0712/134607.891072:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[19156:19156:0712/134607.891147:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/134607.948898:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134607.952901:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134609.444528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f24e5b81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/134609.445090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134609.462027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f24e5b81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/134609.462543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134609.549742:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134609.732295:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134609.732601:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134610.172733:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134610.181310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f24e5b81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/134610.181685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134610.219220:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134610.229717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f24e5b81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/134610.229955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134610.241662:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[19156:19156:0712/134610.246594:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/134610.247669:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c51dff5fe20
[1:1:0712/134610.247910:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[19156:19156:0712/134610.262122:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[19156:19156:0712/134610.284275:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[19156:19156:0712/134610.284361:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/134610.345009:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134611.284410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f98adbc12e0 0x2c51e01d89e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134611.285805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f24e5b81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/134611.286067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134611.287530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[19156:19156:0712/134611.360602:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/134611.360876:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2c51dff60820
[1:1:0712/134611.361082:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[19156:19156:0712/134611.370571:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/134611.382843:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/134611.383034:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[19156:19156:0712/134611.411491:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[19156:19156:0712/134611.432118:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[19156:19156:0712/134611.435389:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[19156:19168:0712/134611.442013:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[19156:19168:0712/134611.442098:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[19156:19156:0712/134611.444702:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[19156:19156:0712/134611.444919:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[19156:19156:0712/134611.445201:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,19209, 4
[1:7:0712/134611.451000:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/134612.105424:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[19156:19156:0712/134612.202649:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[19156:19186:0712/134612.203160:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/134612.203472:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/134612.203884:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/134612.204589:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/134612.204860:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/134612.208881:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x30edcc52, 1
[1:1:0712/134612.209305:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15bb5170, 0
[1:1:0712/134612.209506:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x388cf225, 3
[1:1:0712/134612.209698:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15d33e3d, 2
[1:1:0712/134612.209883:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7051ffffffbb15 52ffffffccffffffed30 3d3effffffd315 25fffffff2ffffff8c38 , 10104, 5
[1:1:0712/134612.210916:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[19156:19186:0712/134612.211198:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGpQ�R��0=>�%�84aI
[19156:19186:0712/134612.211273:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is pQ�R��0=>�%�8H4aI
[1:1:0712/134612.211393:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98c21980a0, 3
[19156:19186:0712/134612.211545:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 19255, 5, 7051bb15 52cced30 3d3ed315 25f28c38 
[1:1:0712/134612.211636:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98c2323080, 2
[1:1:0712/134612.211871:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98abfe6d20, -2
[1:1:0712/134612.235346:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/134612.235724:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15d33e3d
[1:1:0712/134612.236055:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15d33e3d
[1:1:0712/134612.236751:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15d33e3d
[1:1:0712/134612.238236:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.238430:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.238616:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.238802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.239510:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15d33e3d
[1:1:0712/134612.239812:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f98c3f5d7ba
[1:1:0712/134612.239961:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f98c3f54def, 7f98c3f5d77a, 7f98c3f5f0cf
[1:1:0712/134612.246004:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15d33e3d
[1:1:0712/134612.246395:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15d33e3d
[1:1:0712/134612.247163:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15d33e3d
[1:1:0712/134612.249346:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.249615:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.250897:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.251130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15d33e3d
[1:1:0712/134612.252456:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15d33e3d
[1:1:0712/134612.252840:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f98c3f5d7ba
[1:1:0712/134612.252980:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f98c3f54def, 7f98c3f5d77a, 7f98c3f5f0cf
[1:1:0712/134612.257792:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/134612.258157:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/134612.258275:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff18dcf408, 0x7fff18dcf388)
[1:1:0712/134612.264697:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/134612.269764:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/134612.470787:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c51dff3e220
[1:1:0712/134612.471009:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/134612.790797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7f98adbc12e0 0x2c51e0351ae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/134612.791875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f24e5b81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/134612.792218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/134612.793985:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[19156:19156:0712/134612.882497:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[19156:19156:0712/134612.882603:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/134612.905277:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[19156:19156:0712/134613.521318:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[19156:19156:0712/134613.529823:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[19156:19156:0712/134613.555599:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://nn.meituan.com/
[19156:19156:0712/134613.555661:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://nn.meituan.com/, https://nn.meituan.com/, 1
[19156:19156:0712/134613.555721:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://nn.meituan.com/, HTTP/1.1 200 OK Server: openresty Date: Fri, 12 Jul 2019 20:46:13 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: ci=99; path=/; expires=Tue, 10 Sep 2019 20:46:13 GMT; domain=.meituan.com Set-Cookie: rvct=99%2C106; path=/; expires=Tue, 10 Sep 2019 20:46:13 GMT; domain=.meituan.com Content-Encoding: gzip  ,19255, 5
[19156:19168:0712/134613.566604:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[19156:19168:0712/134613.567167:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/134613.568721:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/134613.589996:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134613.604357:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://nn.meituan.com/
[19156:19156:0712/134613.797720:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://nn.meituan.com/, https://nn.meituan.com/, 1
[19156:19156:0712/134613.797832:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://nn.meituan.com/, https://nn.meituan.com
[1:1:0712/134613.840361:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134613.999011:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134614.045759:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134614.089932:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134614.090217:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nn.meituan.com/"
[1:1:0712/134614.177008:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/134614.514328:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134614.521543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169, "https://nn.meituan.com/"
[1:1:0712/134614.523480:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134614.528380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , ;!function(t,e){"function"==typeof define&&define.amd?define(e):"object"==typeof exports?module.expo
[1:1:0712/134614.528620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134614.650508:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134614.650899:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/134614.654502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 169, "https://nn.meituan.com/"
[1:1:0712/134614.739317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173, "https://nn.meituan.com/"
[1:1:0712/134614.740688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , ;!function(){"use strict";function t(t){if("string"!=typeof t&&(t=t.toString()),/[^a-z0-9\-#$%&'*+.\
[1:1:0712/134614.740943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134614.742613:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173, "https://nn.meituan.com/"
[1:1:0712/134614.750419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173, "https://nn.meituan.com/"
[1:1:0712/134614.789614:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.047513, 330, 1
[1:1:0712/134614.789949:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/134615.130589:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134615.130851:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nn.meituan.com/"
[1:1:0712/134615.131650:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 216 0x7f98abc99070 0x2c51e0257e60 , "https://nn.meituan.com/"
[1:1:0712/134615.132690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , window.comPtData = window.comPtData || {};
window.comPtData['header'] = {"currentCity":{"id":99,"nam
[1:1:0712/134615.132922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134615.191237:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.060324, 1407, 1
[1:1:0712/134615.191524:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134615.225619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 220 0x7f98adbc12e0 0x2c51e006dc60 , "https://nn.meituan.com/"
[1:1:0712/134615.233396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , !function(){"use strict";var u=!0,n="_MeiTuanALogObject",l=1,r="dianping_nova",h="waimai",m="group",
[1:1:0712/134615.233658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134615.252643:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x31c942f429c8, 0x2c51dfdc99a8
[1:1:0712/134615.252936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 100
[1:1:0712/134615.253344:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 246
[1:1:0712/134615.253604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 246 0x7f98abc99070 0x2c51e00fd660 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 220 0x7f98adbc12e0 0x2c51e006dc60 
[1:1:0712/134615.289450:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134615.289977:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134615.290448:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134615.290865:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134615.291309:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[19156:19156:0712/134639.808289:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/134639.817303:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/134640.023422:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x31c942f429c8, 0x2c51dfdc99a8
[1:1:0712/134640.023706:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 100
[1:1:0712/134640.024133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 280
[1:1:0712/134640.024398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 280 0x7f98abc99070 0x2c51e00367e0 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 220 0x7f98adbc12e0 0x2c51e006dc60 
[1:1:0712/134640.092566:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x31c942f429c8, 0x2c51dfdc99a8
[1:1:0712/134640.092836:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 1000
[1:1:0712/134640.093295:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 281
[1:1:0712/134640.093544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 281 0x7f98abc99070 0x2c51e006cae0 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 220 0x7f98adbc12e0 0x2c51e006dc60 
[1:1:0712/134640.187324:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x31c942f429c8, 0x2c51dfdc99a8
[1:1:0712/134640.187663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 0
[1:1:0712/134640.188202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 296
[1:1:0712/134640.188470:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 296 0x7f98abc99070 0x2c51e0066ee0 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 220 0x7f98adbc12e0 0x2c51e006dc60 
[1:1:0712/134640.655047:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/134640.655441:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nn.meituan.com/"
[1:1:0712/134640.657952:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f98abc99070 0x2c51e027fd60 , "https://nn.meituan.com/"
[1:1:0712/134640.668777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , window.AppData = {"bannerList":[{"position":1,"content":[{"url":"http:\u002F\u002Fp0.meituan.net\u00
[1:1:0712/134640.669124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134640.678463:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f98abc99070 0x2c51e027fd60 , "https://nn.meituan.com/"
[1:1:0712/134640.722151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/134640.722492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[0712/134640.912168:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/134640.912634:INFO:switcher_clone.cc(787)] backtrace rip is 7f3288e2f891
[1:1:0712/134641.314146:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 246, 7f98ae5de881
[1:1:0712/134641.329932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0cbd867c2860","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134641.330304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nn.meituan.com/","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134641.330711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nn.meituan.com/"
[1:1:0712/134641.331307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , t, (){clearTimeout(jn);try{Cn()}catch(t){}finally{wn()===at?jn=A(t,On):clearTimeout(jn)}}
[1:1:0712/134641.331564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134641.333936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x31c942f429c8, 0x2c51dfdc9950
[1:1:0712/134641.334162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 5000
[1:1:0712/134641.334559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 340
[1:1:0712/134641.334805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 340 0x7f98abc99070 0x2c51e05d46e0 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 246 0x7f98abc99070 0x2c51e00fd660 
[1:1:0712/134641.336363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 280, 7f98ae5de881
[1:1:0712/134641.356313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0cbd867c2860","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134641.356741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nn.meituan.com/","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134641.357054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nn.meituan.com/"
[1:1:0712/134641.357613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , (){n().then(t)}
[1:1:0712/134641.357855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134641.359379:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x31c942f429c8, 0x2c51dfdc9950
[1:1:0712/134641.359598:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 100
[1:1:0712/134641.359980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 341
[1:1:0712/134641.360217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 341 0x7f98abc99070 0x2c51dfb4ae60 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 280 0x7f98abc99070 0x2c51e00367e0 
[1:1:0712/134641.363413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 296, 7f98ae5de881
[1:1:0712/134641.378727:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0cbd867c2860","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134641.379123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nn.meituan.com/","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134641.379470:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nn.meituan.com/"
[1:1:0712/134641.380062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/134641.380363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134641.387314:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x31c942f429c8, 0x2c51dfdc9950
[1:1:0712/134641.387551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 0
[1:1:0712/134641.387927:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 342
[1:1:0712/134641.388181:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 342 0x7f98abc99070 0x2c51e05ccb60 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 296 0x7f98abc99070 0x2c51e0066ee0 
[1:1:0712/134641.610031:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 315 0x7f98c2323080 0x2c51e028a560 1 0 0x2c51e028a578 , "https://nn.meituan.com/"
[1:1:0712/134641.613360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , ;"use strict";function Nb(e){function t(e,t){return null==e||"http://www.w3.org/1999/xhtml"===e?oe(t
[1:1:0712/134641.613595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134641.892305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 315 0x7f98c2323080 0x2c51e028a560 1 0 0x2c51e028a578 , "https://nn.meituan.com/"
[1:1:0712/134641.938916:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f98c2323080 0x2c51e02a7e20 1 0 0x2c51e02a7e38 , "https://nn.meituan.com/"
[1:1:0712/134641.979916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , ;var App=webpackJsonpApp([8],{0:function(e,t,n){(function(t){function r(e){return(r="function"==type
[1:1:0712/134641.980218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134642.139829:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f98c2323080 0x2c51e02a7e20 1 0 0x2c51e02a7e38 , "https://nn.meituan.com/"
[1:1:0712/134644.855832:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[19156:19156:0712/134654.487917:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/5b21cddb4bb1cbc3a9c3bce0f726c75940469.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[19156:19156:0712/134654.497661:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/16442c19da1f1c4544f794e29d99c92051716.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[19156:19156:0712/134654.506739:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/8cce56c467a17e04f3094d1e455462a0132772.png'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[19156:19156:0712/134654.515831:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/e473bb428f070321269b23370ff02ba956209.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[19156:19156:0712/134654.527784:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/33ff80dc00f832d697f3e20fc030799560495.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[19156:19156:0712/134654.529691:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/a97baf515235f4c5a2b1323a741e577185048.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[19156:19156:0712/134654.536160:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p1.meituan.net/codeman/826a5ed09dab49af658c34624d75491861404.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[19156:19156:0712/134654.545124:INFO:CONSOLE(2)] "Mixed Content: The page at 'https://nn.meituan.com/' was loaded over HTTPS, but requested an insecure image 'http://p0.meituan.net/codeman/daa73310c9e57454dc97f0146640fd9f69772.jpg'. This content should also be served over HTTPS.", source: https://s1.meituan.net/bs/fe-web-meituan/8daf5fb/js/index.js (2)
[1:1:0712/134655.678004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 5000
[1:1:0712/134655.678511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://nn.meituan.com/, 390
[1:1:0712/134655.678762:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 390 0x7f98abc99070 0x2c51e4ac8ee0 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 317 0x7f98c2323080 0x2c51e02a7e20 1 0 0x2c51e02a7e38 
[1:1:0712/134656.149011:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 14.0098, 0, 0
[1:1:0712/134656.149280:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/134656.234143:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://nn.meituan.com/"
[1:1:0712/134656.236038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , dispatchEvent, (e,t){if(bn._enabled){var n=G(t);if(n=rn.getClosestInstanceFromNode(n),null===n||"number"!=typeof n.
[1:1:0712/134656.236356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134656.460518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , document.readyState
[1:1:0712/134656.460896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134656.578549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , (t){try{var n=[];(t||[]).forEach(function(t){n.push(t.deviceId)}),cn.did=n.map(function(t){return t.
[1:1:0712/134656.578806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134656.710847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 281, 7f98ae5de881
[1:1:0712/134656.726355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0cbd867c2860","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134656.726574:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nn.meituan.com/","ptid":"220 0x7f98adbc12e0 0x2c51e006dc60 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134656.726779:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nn.meituan.com/"
[1:1:0712/134656.727085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , fu, (){var n,r;Sn(!1),(n=uu,r={none:!0},new Ir(function(e){try{var t=Se(Gi,"4.12.0");!Gi||!te(t)||t<0?e(
[1:1:0712/134656.727192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134656.728987:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x31c942f429c8, 0x2c51dfdc9950
[1:1:0712/134656.729111:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 0
[1:1:0712/134656.729332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 449
[1:1:0712/134656.729454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 449 0x7f98abc99070 0x2c51e52d7be0 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 281 0x7f98abc99070 0x2c51e006cae0 
[1:1:0712/134656.759981:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "upgradeneeded", "https://nn.meituan.com/"
[1:1:0712/134656.761373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , yi.onupgradeneeded, (t){bi=t.target.result,(wi=bi.createObjectStore("cache",{keyPath:"id",autoIncrement:!0})).createInde
[1:1:0712/134656.761564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134656.767732:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 342, 7f98ae5de881
[1:1:0712/134656.789498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0cbd867c2860","ptid":"296 0x7f98abc99070 0x2c51e0066ee0 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134656.789841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nn.meituan.com/","ptid":"296 0x7f98abc99070 0x2c51e0066ee0 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134656.790219:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nn.meituan.com/"
[1:1:0712/134656.790755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , (){var t=void 0,n=e._state?r._onFulfilled:r._onRejected;if(void 0!==n){try{t=n(e._value)}catch(t){re
[1:1:0712/134656.790936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134656.792981:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x31c942f429c8, 0x2c51dfdc9950
[1:1:0712/134656.793153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 0
[1:1:0712/134656.793508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 453
[1:1:0712/134656.793707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 453 0x7f98abc99070 0x2c51e52d5060 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 342 0x7f98abc99070 0x2c51e05ccb60 
[1:1:0712/134656.795892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 341, 7f98ae5de881
[1:1:0712/134656.818472:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0cbd867c2860","ptid":"280 0x7f98abc99070 0x2c51e00367e0 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134656.818790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nn.meituan.com/","ptid":"280 0x7f98abc99070 0x2c51e00367e0 ","rf":"5:3_https://nn.meituan.com/"}
[1:1:0712/134656.819136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nn.meituan.com/"
[1:1:0712/134656.819658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , (){n().then(t)}
[1:1:0712/134656.819850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134656.821149:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x31c942f429c8, 0x2c51dfdc9950
[1:1:0712/134656.821328:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nn.meituan.com/", 100
[1:1:0712/134656.821662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://nn.meituan.com/, 455
[1:1:0712/134656.821854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 455 0x7f98abc99070 0x2c51e535ade0 , 5:3_https://nn.meituan.com/, 1, -5:3_https://nn.meituan.com/, 341 0x7f98abc99070 0x2c51dfb4ae60 
[1:1:0712/134657.629326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134657.629674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134657.653083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134657.653413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134700.093066:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134700.096519:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134700.096950:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134700.097479:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/134700.097898:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[19156:19156:0712/134701.802117:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
		remove user.11_e4d1dfa -> 0
[1:1:0712/134707.049272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134707.049577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134707.060726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134707.060972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134707.145138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/134707.145395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
[1:1:0712/134707.155322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nn.meituan.com/, 0cbd867c2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/134707.155587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nn.meituan.com/", "nn.meituan.com", 3, 1, , , 0
		remove user.12_e68946f -> 0
		remove user.13_602a34a2 -> 0
		remove user.14_b2dd6076 -> 0
		remove user.15_95390b8a -> 0
		remove user.16_5a8cb03b -> 0
