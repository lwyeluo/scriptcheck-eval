[0712/212640.308763:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/212640.309132:INFO:switcher_clone.cc(787)] backtrace rip is 7f921011a891
[0712/212641.296188:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/212641.296527:INFO:switcher_clone.cc(787)] backtrace rip is 7f4b74fbf891
[1:1:0712/212641.300908:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/212641.301093:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/212641.305969:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[5078:5078:0712/212642.438253:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0b712b29-c5b3-44d9-8b48-7373e8d3f913
[0712/212642.634016:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/212642.634310:INFO:switcher_clone.cc(787)] backtrace rip is 7f8861944891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5111:5111:0712/212642.838878:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5111
[5122:5122:0712/212642.839284:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5122
[5078:5078:0712/212643.015517:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[5078:5109:0712/212643.016922:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/212643.017324:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/212643.017638:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/212643.018328:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/212643.018604:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/212643.021364:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x6b8686d, 1
[1:1:0712/212643.021748:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x215d066a, 0
[1:1:0712/212643.022055:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x153a8a5a, 3
[1:1:0712/212643.022334:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x385d26e7, 2
[1:1:0712/212643.022610:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6a065d21 6d68ffffffb806 ffffffe7265d38 5affffff8a3a15 , 10104, 4
[1:1:0712/212643.023770:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5078:5109:0712/212643.024152:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGj]!mh��&]8Z�:�:
[1:1:0712/212643.024100:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4b731fa0a0, 3
[5078:5109:0712/212643.024298:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is j]!mh��&]8Z�:��:
[1:1:0712/212643.024402:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4b73385080, 2
[1:1:0712/212643.024653:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4b5d048d20, -2
[5078:5109:0712/212643.024844:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[5078:5109:0712/212643.025039:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5130, 4, 6a065d21 6d68b806 e7265d38 5a8a3a15 
[1:1:0712/212643.046415:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/212643.047311:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 385d26e7
[1:1:0712/212643.048273:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 385d26e7
[1:1:0712/212643.049896:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 385d26e7
[1:1:0712/212643.051465:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.051744:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.052016:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.052262:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.053050:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 385d26e7
[1:1:0712/212643.053430:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4b74fbf7ba
[1:1:0712/212643.053646:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4b74fb6def, 7f4b74fbf77a, 7f4b74fc10cf
[1:1:0712/212643.059971:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 385d26e7
[1:1:0712/212643.060403:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 385d26e7
[1:1:0712/212643.061204:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 385d26e7
[1:1:0712/212643.063433:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.063719:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.063986:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.064245:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 385d26e7
[1:1:0712/212643.065552:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 385d26e7
[1:1:0712/212643.065988:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4b74fbf7ba
[1:1:0712/212643.066226:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4b74fb6def, 7f4b74fbf77a, 7f4b74fc10cf
[1:1:0712/212643.073959:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/212643.074574:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/212643.074791:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd376684b8, 0x7ffd37668438)
[1:1:0712/212643.092661:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/212643.098501:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[5078:5078:0712/212643.678384:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5078:5078:0712/212643.679765:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5078:5089:0712/212643.697891:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[5078:5089:0712/212643.697986:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[5078:5078:0712/212643.698129:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[5078:5078:0712/212643.698257:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[5078:5078:0712/212643.698402:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5130, 4
[1:7:0712/212643.700040:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[5078:5100:0712/212643.774950:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/212643.845683:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xdc765ef4220
[1:1:0712/212643.845963:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/212644.165034:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/212645.353574:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212645.358115:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[5078:5078:0712/212645.655054:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[5078:5078:0712/212645.655164:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/212646.398283:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212646.617647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04b804ee1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/212646.617974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212646.631450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04b804ee1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/212646.631693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212646.678179:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212646.678431:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212646.966705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212646.974832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04b804ee1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/212646.975145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212647.009660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212647.020815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04b804ee1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/212647.021092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212647.032808:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[5078:5078:0712/212647.036173:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/212647.036263:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xdc765ef2e20
[1:1:0712/212647.036469:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5078:5078:0712/212647.053419:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[5078:5078:0712/212647.079086:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[5078:5078:0712/212647.079291:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/212647.113545:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212647.904381:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f4b5ec232e0 0xdc76617c6e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212647.905734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04b804ee1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/212647.905968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212647.908087:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5078:5078:0712/212647.976624:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/212647.977405:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xdc765ef3820
[1:1:0712/212647.977593:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5078:5078:0712/212647.983311:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/212647.995802:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/212647.995992:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[5078:5078:0712/212648.009925:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[5078:5078:0712/212648.025621:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5078:5078:0712/212648.026625:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5078:5089:0712/212648.032418:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[5078:5089:0712/212648.032497:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[5078:5078:0712/212648.035585:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[5078:5078:0712/212648.035661:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[5078:5078:0712/212648.035790:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5130, 4
[1:7:0712/212648.038941:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/212648.532952:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/212648.952573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7f4b5ec232e0 0xdc7662ad2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212648.953590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04b804ee1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/212648.953820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212648.954625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5078:5078:0712/212649.266811:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[5078:5078:0712/212649.266945:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/212649.297473:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/212649.765144:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212650.436294:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212650.436646:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[5078:5078:0712/212650.498516:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[5078:5109:0712/212650.499023:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/212650.499205:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/212650.499443:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/212650.499916:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/212650.500134:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/212650.503397:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26e0ec0c, 1
[1:1:0712/212650.503870:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xd02d7b, 0
[1:1:0712/212650.504096:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38dabfe7, 3
[1:1:0712/212650.504334:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x36337ac9, 2
[1:1:0712/212650.504548:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7b2dffffffd000 0cffffffecffffffe026 ffffffc97a3336 ffffffe7ffffffbfffffffda38 , 10104, 5
[1:1:0712/212650.505722:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5078:5109:0712/212650.506041:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING{-�
[5078:5109:0712/212650.506138:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is {-�
[5078:5109:0712/212650.506480:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5176, 5, 7b2dd000 0cece026 c97a3336 e7bfda38 
[1:1:0712/212650.506312:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4b731fa0a0, 3
[1:1:0712/212650.507080:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4b73385080, 2
[1:1:0712/212650.507397:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4b5d048d20, -2
[1:1:0712/212650.528628:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/212650.529011:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 36337ac9
[1:1:0712/212650.529360:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 36337ac9
[1:1:0712/212650.530049:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 36337ac9
[1:1:0712/212650.531526:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.531783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.532008:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.532236:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.532955:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 36337ac9
[1:1:0712/212650.533278:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4b74fbf7ba
[1:1:0712/212650.533464:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4b74fb6def, 7f4b74fbf77a, 7f4b74fc10cf
[1:1:0712/212650.539282:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 36337ac9
[1:1:0712/212650.539667:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 36337ac9
[1:1:0712/212650.540455:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 36337ac9
[1:1:0712/212650.542510:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.542799:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.543021:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.543250:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36337ac9
[1:1:0712/212650.544516:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 36337ac9
[1:1:0712/212650.544941:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4b74fbf7ba
[1:1:0712/212650.545132:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4b74fb6def, 7f4b74fbf77a, 7f4b74fc10cf
[1:1:0712/212650.552925:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/212650.553452:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/212650.553636:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd376684b8, 0x7ffd37668438)
[1:1:0712/212650.567128:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/212650.571824:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/212650.704314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/212650.709068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 04b80500e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/212650.709371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/212650.716308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/212650.773294:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xdc765ecf220
[1:1:0712/212650.773603:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5078:5078:0712/212651.001172:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5078:5078:0712/212651.006268:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5078:5089:0712/212651.023303:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[5078:5089:0712/212651.023391:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[5078:5078:0712/212651.023893:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.netbian.com/
[5078:5078:0712/212651.023989:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.netbian.com/, http://www.netbian.com/, 1
[5078:5078:0712/212651.024152:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.netbian.com/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 04:26:51 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: security_session_verify=0f05a1b7c94a6bf3eccc121ca0f30033; expires=Tue, 16-Jul-19 12:26:51 GMT; path=/; HttpOnly Set-Cookie: security_session_verify=3038a97b48b4534925b603fdb381590d; expires=Tue, 16-Jul-19 12:26:51 GMT; path=/; HttpOnly Set-Cookie: security_session_verify=3038a97b48b4534925b603fdb381590d; expires=Tue, 16-Jul-19 12:26:51 GMT; path=/; HttpOnly Server: yunjiasu-nginx CF-RAY: 4f588044f10644f7-TAO Content-Encoding: gzip  ,5176, 5
[1:7:0712/212651.026292:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/212651.067644:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.netbian.com/
[1:1:0712/212651.186131:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[5078:5078:0712/212651.204609:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.netbian.com/, http://www.netbian.com/, 1
[5078:5078:0712/212651.204709:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.netbian.com/, http://www.netbian.com
[1:1:0712/212651.269186:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212651.328723:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212651.328978:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.netbian.com/"
[1:1:0712/212651.647590:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f4b73385080 0xdc765e9eb00 1 0 0xdc765e9eb18 , "http://www.netbian.com/"
[1:1:0712/212651.694839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , /*!
 * jQuery JavaScript Library v1.4.4
 * http://jquery.com/
 *
 * Copyright 2010, John Resig

[1:1:0712/212651.695157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212651.701266:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212651.756615:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f4b73385080 0xdc765e9eb00 1 0 0xdc765e9eb18 , "http://www.netbian.com/"
[1:1:0712/212651.901272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f4b73385080 0xdc765e9eb00 1 0 0xdc765e9eb18 , "http://www.netbian.com/"
[1:1:0712/212652.001472:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.10365, 122, 1
[1:1:0712/212652.001742:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/212652.459094:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212652.459353:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.netbian.com/"
[1:1:0712/212652.460043:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f4b5ccfb070 0xdc7661dcde0 , "http://www.netbian.com/"
[1:1:0712/212652.460944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , 
document.write('<script src="/e/member/login/loginjs.php?t='+Math.random()+'"><'+'/script>');

[1:1:0712/212652.461209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212652.696852:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227, "http://www.netbian.com/"
[1:1:0712/212652.697915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , document.write("<div class=\"ulogin\"><p class=\"login\"><a href=\"javascript:;\" class=\"userface u
[1:1:0712/212652.698169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212652.702599:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227, "http://www.netbian.com/"
[1:1:0712/212652.754591:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.052696, 144, 1
[1:1:0712/212652.754908:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212653.045505:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212653.045744:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.netbian.com/"
[1:1:0712/212653.048629:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 249 0x7f4b5ccfb070 0xdc76606c360 , "http://www.netbian.com/"
[1:1:0712/212653.050061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , $("#mainShow").hover(function(){$("#smallInfo").stop(true,true).fadeIn(400);$(".tab-shadow").show();
[1:1:0712/212653.050315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212653.074636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 6000
[1:1:0712/212653.075046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 264
[1:1:0712/212653.075290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 264 0x7f4b5ccfb070 0xdc765f49b60 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 249 0x7f4b5ccfb070 0xdc76606c360 
[1:1:0712/212653.089659:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212653.094186:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212653.094680:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212653.095082:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212653.095531:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212653.169605:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.12382, 381, 1
[1:1:0712/212653.169897:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212653.252841:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212653.253137:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.netbian.com/"
[1:1:0712/212653.258042:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.netbian.com/"
[1:1:0712/212653.259917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , u, (){t.removeEventListener("DOMContentLoaded",u,
false);b.ready()}
[1:1:0712/212653.260180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212655.195780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7f4b5ec232e0 0xdc7663aa960 , "http://www.netbian.com/"
[1:1:0712/212655.219904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , (function(){var h={},mt={},c={id:"14b14198b6e26157b7eba06b390ab763",dm:["netbian.com"],js:"tongji.ba
[1:1:0712/212655.220235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212655.252724:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac190
[1:1:0712/212655.252960:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212655.253272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 339
[1:1:0712/212655.253453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 339 0x7f4b5ccfb070 0xdc766252c60 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 321 0x7f4b5ec232e0 0xdc7663aa960 
[5078:5078:0712/212731.401441:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/212731.409450:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/212731.554338:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212733.170055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/212733.170238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212733.840667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 339, 7f4b5f640881
[1:1:0712/212733.861044:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"321 0x7f4b5ec232e0 0xdc7663aa960 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212733.861224:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"321 0x7f4b5ec232e0 0xdc7663aa960 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212733.861466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212733.861771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212733.861872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212733.862229:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212733.862324:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212733.862527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 531
[1:1:0712/212733.862639:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7f4b5ccfb070 0xdc7662625e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 339 0x7f4b5ccfb070 0xdc766252c60 
[1:1:0712/212733.877574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 264, 7f4b5f6408db
[1:1:0712/212733.900077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"249 0x7f4b5ccfb070 0xdc76606c360 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212733.900394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"249 0x7f4b5ccfb070 0xdc76606c360 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212733.900841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 536
[1:1:0712/212733.901029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7f4b5ccfb070 0xdc7663bcc60 , 5:3_http://www.netbian.com/, 0, , 264 0x7f4b5ccfb070 0xdc765f49b60 
[1:1:0712/212733.901281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212733.901792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , movePic, (){$("#pic"+move).addClass("current").siblings("li").removeClass("current");var moveLen=move*lengthM
[1:1:0712/212733.901964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212733.951484:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 13
[1:1:0712/212733.951885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 537
[1:1:0712/212733.952074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 537 0x7f4b5ccfb070 0xdc7660d83e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 264 0x7f4b5ccfb070 0xdc765f49b60 
[1:1:0712/212734.957526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , document.readyState
[1:1:0712/212734.957696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212735.433036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 531, 7f4b5f640881
[1:1:0712/212735.461866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"339 0x7f4b5ccfb070 0xdc766252c60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212735.462248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"339 0x7f4b5ccfb070 0xdc766252c60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212735.462674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212735.463286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212735.463496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212735.464170:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212735.464366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212735.464735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 681
[1:1:0712/212735.464976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f4b5ccfb070 0xdc7663b8460 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 531 0x7f4b5ccfb070 0xdc7662625e0 
[1:1:0712/212735.494979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 537, 7f4b5f6408db
[1:1:0712/212735.526419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"264 0x7f4b5ccfb070 0xdc765f49b60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212735.526779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"264 0x7f4b5ccfb070 0xdc765f49b60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212735.527224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 685
[1:1:0712/212735.527451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7f4b5ccfb070 0xdc76616b660 , 5:3_http://www.netbian.com/, 0, , 537 0x7f4b5ccfb070 0xdc7660d83e0 
[1:1:0712/212735.527758:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212735.528320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0712/212735.528527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212737.228479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , document.readyState
[1:1:0712/212737.228761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212737.484111:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 536, 7f4b5f6408db
[1:1:0712/212737.494154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"264 0x7f4b5ccfb070 0xdc765f49b60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212737.494582:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"264 0x7f4b5ccfb070 0xdc765f49b60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212737.495052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 733
[1:1:0712/212737.495322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f4b5ccfb070 0xdc7658ca6e0 , 5:3_http://www.netbian.com/, 0, , 536 0x7f4b5ccfb070 0xdc7663bcc60 
[1:1:0712/212737.495659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212737.496208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , movePic, (){$("#pic"+move).addClass("current").siblings("li").removeClass("current");var moveLen=move*lengthM
[1:1:0712/212737.496442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212737.533620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 13
[1:1:0712/212737.534166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 734
[1:1:0712/212737.534471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7f4b5ccfb070 0xdc7663b93e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 536 0x7f4b5ccfb070 0xdc7663bcc60 
[1:1:0712/212738.418377:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.netbian.com/"
[1:1:0712/212738.419077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/212738.419290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212738.749768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 681, 7f4b5f640881
[1:1:0712/212738.777574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"531 0x7f4b5ccfb070 0xdc7662625e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212738.777925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"531 0x7f4b5ccfb070 0xdc7662625e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212738.778405:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212738.779012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212738.779246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212738.779966:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212738.780171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212738.780531:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 757
[1:1:0712/212738.780800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7f4b5ccfb070 0xdc7663a3460 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 681 0x7f4b5ccfb070 0xdc7663b8460 
[1:1:0712/212739.930126:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.netbian.com/"
[1:1:0712/212739.930925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , o, (){return typeof c!=="undefined"&&!c.event.triggered?c.event.handle.apply(o.elem,
arguments):B}
[1:1:0712/212739.931166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
		remove user.10_d1abf3ef -> 0
[1:1:0712/212740.028863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , document.readyState
[1:1:0712/212740.029156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212740.049053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 734, 7f4b5f6408db
[1:1:0712/212740.083008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"536 0x7f4b5ccfb070 0xdc7663bcc60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212740.083350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"536 0x7f4b5ccfb070 0xdc7663bcc60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212740.083780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 808
[1:1:0712/212740.084020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7f4b5ccfb070 0xdc7673dc860 , 5:3_http://www.netbian.com/, 0, , 734 0x7f4b5ccfb070 0xdc7663b93e0 
[1:1:0712/212740.084324:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212740.084843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0712/212740.085079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/212740.272249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 757, 7f4b5f640881
[1:1:0712/212740.306164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"681 0x7f4b5ccfb070 0xdc7663b8460 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212740.306508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"681 0x7f4b5ccfb070 0xdc7663b8460 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212740.306945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212740.307482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212740.307718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212740.308409:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212740.308601:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212740.308996:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 815
[1:1:0712/212740.309222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f4b5ccfb070 0xdc7673e0ce0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 757 0x7f4b5ccfb070 0xdc7663a3460 
[1:1:0712/212741.116174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , document.readyState
[1:1:0712/212741.116483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212741.390864:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 815, 7f4b5f640881
[1:1:0712/212741.411314:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"757 0x7f4b5ccfb070 0xdc7663a3460 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212741.411654:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"757 0x7f4b5ccfb070 0xdc7663a3460 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212741.412069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212741.412637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212741.412867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212741.413548:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212741.413742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212741.414097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 847
[1:1:0712/212741.414378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7f4b5ccfb070 0xdc765b69260 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 815 0x7f4b5ccfb070 0xdc7673e0ce0 
[1:1:0712/212741.466620:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 733, 7f4b5f6408db
[1:1:0712/212741.500917:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"536 0x7f4b5ccfb070 0xdc7663bcc60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212741.501261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"536 0x7f4b5ccfb070 0xdc7663bcc60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212741.501730:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 852
[1:1:0712/212741.501983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f4b5ccfb070 0xdc7673f27e0 , 5:3_http://www.netbian.com/, 0, , 733 0x7f4b5ccfb070 0xdc7658ca6e0 
[1:1:0712/212741.502335:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212741.502883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , movePic, (){$("#pic"+move).addClass("current").siblings("li").removeClass("current");var moveLen=move*lengthM
[1:1:0712/212741.503092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212741.537100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 13
[1:1:0712/212741.537537:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 853
[1:1:0712/212741.537765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 853 0x7f4b5ccfb070 0xdc766f57460 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 733 0x7f4b5ccfb070 0xdc7658ca6e0 
[1:1:0712/212741.574632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , document.readyState
[1:1:0712/212741.574930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212742.131525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.netbian.com/"
[1:1:0712/212742.132267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , ready, (j){j===true&&b.readyWait--;
if(!b.readyWait||j!==true&&!b.isReady){if(!t.body)return setTimeout(b.
[1:1:0712/212742.132507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212742.133047:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.netbian.com/"
[1:1:0712/212742.168273:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.netbian.com/"
[1:1:0712/212742.171613:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.netbian.com/"
[1:1:0712/212742.173058:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac2f0
[1:1:0712/212742.173275:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212742.173663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 870
[1:1:0712/212742.173906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f4b5ccfb070 0xdc765fb10e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 849 0x7f4b5ccfb070 0xdc7675aee60 
[1:1:0712/212742.300298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , , document.readyState
[1:1:0712/212742.300533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212742.302136:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 853, 7f4b5f6408db
[1:1:0712/212742.314008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"733 0x7f4b5ccfb070 0xdc7658ca6e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212742.314181:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"733 0x7f4b5ccfb070 0xdc7658ca6e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212742.314429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 876
[1:1:0712/212742.314555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 876 0x7f4b5ccfb070 0xdc7676de9e0 , 5:3_http://www.netbian.com/, 0, , 853 0x7f4b5ccfb070 0xdc766f57460 
[1:1:0712/212742.314713:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212742.315025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0712/212742.315155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212742.443267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 870, 7f4b5f640881
[1:1:0712/212742.456307:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"849 0x7f4b5ccfb070 0xdc7675aee60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212742.456627:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"849 0x7f4b5ccfb070 0xdc7675aee60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212742.456995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212742.457545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212742.457719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212742.458336:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212742.458536:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212742.458850:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 884
[1:1:0712/212742.459033:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f4b5ccfb070 0xdc7677242e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 870 0x7f4b5ccfb070 0xdc765fb10e0 
[1:1:0712/212742.883995:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 884, 7f4b5f640881
[1:1:0712/212742.895796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"870 0x7f4b5ccfb070 0xdc765fb10e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212742.895961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"870 0x7f4b5ccfb070 0xdc765fb10e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212742.896188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212742.896482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212742.896608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212742.896902:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212742.896997:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212742.897157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 905
[1:1:0712/212742.897261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 905 0x7f4b5ccfb070 0xdc766c4f0e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 884 0x7f4b5ccfb070 0xdc7677242e0 
[1:1:0712/212743.234060:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 905, 7f4b5f640881
[1:1:0712/212743.261467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"884 0x7f4b5ccfb070 0xdc7677242e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.261898:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"884 0x7f4b5ccfb070 0xdc7677242e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.262340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212743.263039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212743.263266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212743.264084:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212743.264288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212743.264718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 913
[1:1:0712/212743.264965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 913 0x7f4b5ccfb070 0xdc76732c060 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 905 0x7f4b5ccfb070 0xdc766c4f0e0 
[1:1:0712/212743.400215:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 913, 7f4b5f640881
[1:1:0712/212743.410438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"905 0x7f4b5ccfb070 0xdc766c4f0e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.410646:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"905 0x7f4b5ccfb070 0xdc766c4f0e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.410833:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212743.411116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212743.411219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212743.412467:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212743.412573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212743.412761:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 924
[1:1:0712/212743.412867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 924 0x7f4b5ccfb070 0xdc767726260 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 913 0x7f4b5ccfb070 0xdc76732c060 
[1:1:0712/212743.513962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 924, 7f4b5f640881
[1:1:0712/212743.550316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"913 0x7f4b5ccfb070 0xdc76732c060 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.550682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"913 0x7f4b5ccfb070 0xdc76732c060 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.551033:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212743.551540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212743.551732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212743.552361:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212743.552515:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212743.552856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 928
[1:1:0712/212743.553043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7f4b5ccfb070 0xdc7673f8160 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 924 0x7f4b5ccfb070 0xdc767726260 
[1:1:0712/212743.717479:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 928, 7f4b5f640881
[1:1:0712/212743.754235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"924 0x7f4b5ccfb070 0xdc767726260 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.754558:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"924 0x7f4b5ccfb070 0xdc767726260 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.754962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212743.755465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212743.755636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212743.756287:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212743.756449:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212743.756789:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 936
[1:1:0712/212743.756980:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 936 0x7f4b5ccfb070 0xdc76772ffe0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 928 0x7f4b5ccfb070 0xdc7673f8160 
[1:1:0712/212743.920515:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 936, 7f4b5f640881
[1:1:0712/212743.957487:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"928 0x7f4b5ccfb070 0xdc7673f8160 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.957905:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"928 0x7f4b5ccfb070 0xdc7673f8160 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212743.958331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212743.959029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212743.959243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212743.960030:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212743.960217:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212743.960605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 942
[1:1:0712/212743.960853:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 942 0x7f4b5ccfb070 0xdc767289760 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 936 0x7f4b5ccfb070 0xdc76772ffe0 
[1:1:0712/212744.099135:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 942, 7f4b5f640881
[1:1:0712/212744.136466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"936 0x7f4b5ccfb070 0xdc76772ffe0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.136829:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"936 0x7f4b5ccfb070 0xdc76772ffe0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.137190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212744.137693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212744.137923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212744.138666:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212744.138873:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212744.139205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 945
[1:1:0712/212744.139391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 945 0x7f4b5ccfb070 0xdc767729f60 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 942 0x7f4b5ccfb070 0xdc767289760 
[1:1:0712/212744.284714:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 945, 7f4b5f640881
[1:1:0712/212744.327709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"942 0x7f4b5ccfb070 0xdc767289760 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.328104:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"942 0x7f4b5ccfb070 0xdc767289760 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.328524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212744.329160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212744.329373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212744.330159:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212744.330352:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212744.330743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 947
[1:1:0712/212744.331029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7f4b5ccfb070 0xdc767038be0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 945 0x7f4b5ccfb070 0xdc767729f60 
[1:1:0712/212744.448461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 947, 7f4b5f640881
[1:1:0712/212744.462210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"945 0x7f4b5ccfb070 0xdc767729f60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.462390:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"945 0x7f4b5ccfb070 0xdc767729f60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.462583:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212744.463066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212744.463172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212744.463459:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212744.463554:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212744.463717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 949
[1:1:0712/212744.463830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 949 0x7f4b5ccfb070 0xdc7673f4660 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 947 0x7f4b5ccfb070 0xdc767038be0 
[1:1:0712/212744.585705:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 949, 7f4b5f640881
[1:1:0712/212744.638136:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"947 0x7f4b5ccfb070 0xdc767038be0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.638441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"947 0x7f4b5ccfb070 0xdc767038be0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.638784:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212744.639754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212744.639945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212744.640569:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212744.640724:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212744.641701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 951
[1:1:0712/212744.641910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f4b5ccfb070 0xdc76761a760 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 949 0x7f4b5ccfb070 0xdc7673f4660 
[1:1:0712/212744.791480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 951, 7f4b5f640881
[1:1:0712/212744.832630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"949 0x7f4b5ccfb070 0xdc7673f4660 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.832957:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"949 0x7f4b5ccfb070 0xdc7673f4660 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.833308:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212744.833810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212744.834018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212744.834642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212744.834796:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212744.835157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 954
[1:1:0712/212744.835349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 954 0x7f4b5ccfb070 0xdc7673f2160 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 951 0x7f4b5ccfb070 0xdc76761a760 
[1:1:0712/212744.955631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 954, 7f4b5f640881
[1:1:0712/212744.967352:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"951 0x7f4b5ccfb070 0xdc76761a760 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.967547:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"951 0x7f4b5ccfb070 0xdc76761a760 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212744.967744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212744.968069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212744.968175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212744.968467:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212744.968562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212744.968731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 956
[1:1:0712/212744.968838:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7f4b5ccfb070 0xdc765f491e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 954 0x7f4b5ccfb070 0xdc7673f2160 
[1:1:0712/212745.106824:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 956, 7f4b5f640881
[1:1:0712/212745.152778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"954 0x7f4b5ccfb070 0xdc7673f2160 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.153176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"954 0x7f4b5ccfb070 0xdc7673f2160 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.153599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212745.154261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212745.154491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212745.155331:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212745.155522:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212745.155916:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 959
[1:1:0712/212745.156166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7f4b5ccfb070 0xdc7673e6b60 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 956 0x7f4b5ccfb070 0xdc765f491e0 
[1:1:0712/212745.306621:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 959, 7f4b5f640881
[1:1:0712/212745.345912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"956 0x7f4b5ccfb070 0xdc765f491e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.346264:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"956 0x7f4b5ccfb070 0xdc765f491e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.346612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212745.347142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212745.347321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212745.347940:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212745.348115:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212745.348440:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 963
[1:1:0712/212745.348627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 963 0x7f4b5ccfb070 0xdc765f8a160 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 959 0x7f4b5ccfb070 0xdc7673e6b60 
[1:1:0712/212745.487406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 963, 7f4b5f640881
[1:1:0712/212745.524784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"959 0x7f4b5ccfb070 0xdc7673e6b60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.525125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"959 0x7f4b5ccfb070 0xdc7673e6b60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.525481:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212745.525988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212745.526201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212745.526837:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212745.526994:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212745.527341:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 965
[1:1:0712/212745.527529:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7f4b5ccfb070 0xdc767347660 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 963 0x7f4b5ccfb070 0xdc765f8a160 
[1:1:0712/212745.675010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 965, 7f4b5f640881
[1:1:0712/212745.721138:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"963 0x7f4b5ccfb070 0xdc765f8a160 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.721457:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"963 0x7f4b5ccfb070 0xdc765f8a160 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.721802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212745.722348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212745.722525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212745.723165:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212745.723323:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212745.723701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 967
[1:1:0712/212745.723889:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7f4b5ccfb070 0xdc767729fe0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 965 0x7f4b5ccfb070 0xdc767347660 
[1:1:0712/212745.869301:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 967, 7f4b5f640881
[1:1:0712/212745.895529:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"965 0x7f4b5ccfb070 0xdc767347660 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.895739:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"965 0x7f4b5ccfb070 0xdc767347660 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212745.895942:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212745.896265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212745.896373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212745.896678:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212745.896775:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212745.896977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 969
[1:1:0712/212745.897084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7f4b5ccfb070 0xdc7676d58e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 967 0x7f4b5ccfb070 0xdc767729fe0 
[1:1:0712/212746.026847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 969, 7f4b5f640881
[1:1:0712/212746.056532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"967 0x7f4b5ccfb070 0xdc767729fe0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.056941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"967 0x7f4b5ccfb070 0xdc767729fe0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.057381:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212746.057892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212746.058067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212746.058736:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212746.058893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212746.059235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 971
[1:1:0712/212746.059428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7f4b5ccfb070 0xdc765a640e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 969 0x7f4b5ccfb070 0xdc7676d58e0 
[1:1:0712/212746.178077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 971, 7f4b5f640881
[1:1:0712/212746.205185:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"969 0x7f4b5ccfb070 0xdc7676d58e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.205519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"969 0x7f4b5ccfb070 0xdc7676d58e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.205865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212746.206443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212746.206618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212746.207279:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212746.207454:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212746.207773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 973
[1:1:0712/212746.207962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7f4b5ccfb070 0xdc767726660 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 971 0x7f4b5ccfb070 0xdc765a640e0 
[1:1:0712/212746.347140:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 973, 7f4b5f640881
[1:1:0712/212746.386072:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"971 0x7f4b5ccfb070 0xdc765a640e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.386430:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"971 0x7f4b5ccfb070 0xdc765a640e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.386781:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212746.387322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212746.387545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212746.388295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212746.388458:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212746.388777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 975
[1:1:0712/212746.388962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 975 0x7f4b5ccfb070 0xdc7673f19e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 973 0x7f4b5ccfb070 0xdc767726660 
[1:1:0712/212746.527488:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 975, 7f4b5f640881
[1:1:0712/212746.565952:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"973 0x7f4b5ccfb070 0xdc767726660 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.566258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"973 0x7f4b5ccfb070 0xdc767726660 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.566663:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212746.567169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212746.567388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212746.568010:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212746.568165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212746.568526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 977
[1:1:0712/212746.568716:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7f4b5ccfb070 0xdc765f6d360 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 975 0x7f4b5ccfb070 0xdc7673f19e0 
[1:1:0712/212746.719854:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 977, 7f4b5f640881
[1:1:0712/212746.758407:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"975 0x7f4b5ccfb070 0xdc7673f19e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.758726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"975 0x7f4b5ccfb070 0xdc7673f19e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.759084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212746.759609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212746.759787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212746.760428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212746.760586:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212746.760905:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 979
[1:1:0712/212746.761091:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7f4b5ccfb070 0xdc765a64f60 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 977 0x7f4b5ccfb070 0xdc765f6d360 
[1:1:0712/212746.896912:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 979, 7f4b5f640881
[1:1:0712/212746.909361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"977 0x7f4b5ccfb070 0xdc765f6d360 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.909576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"977 0x7f4b5ccfb070 0xdc765f6d360 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212746.909777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212746.910071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212746.910173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212746.910524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212746.910626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212746.910797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 981
[1:1:0712/212746.910915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7f4b5ccfb070 0xdc765f868e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 979 0x7f4b5ccfb070 0xdc765a64f60 
[1:1:0712/212747.050466:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 981, 7f4b5f640881
[1:1:0712/212747.097780:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"979 0x7f4b5ccfb070 0xdc765a64f60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212747.098153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"979 0x7f4b5ccfb070 0xdc765a64f60 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212747.098619:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212747.099238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/212747.099465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212747.100236:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0712/212747.100423:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0712/212747.100875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 983
[1:1:0712/212747.101125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f4b5ccfb070 0xdc765b2a660 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 981 0x7f4b5ccfb070 0xdc765f868e0 
[1:1:0712/212747.104200:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 852, 7f4b5f6408db
[1:1:0712/212747.150772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"733 0x7f4b5ccfb070 0xdc7658ca6e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212747.151055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"733 0x7f4b5ccfb070 0xdc7658ca6e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212747.151439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 986
[1:1:0712/212747.151728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7f4b5ccfb070 0xdc767350260 , 5:3_http://www.netbian.com/, 0, , 852 0x7f4b5ccfb070 0xdc7673f27e0 
[1:1:0712/212747.152051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212747.152687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , movePic, (){$("#pic"+move).addClass("current").siblings("li").removeClass("current");var moveLen=move*lengthM
[1:1:0712/212747.152864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212747.186147:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 13
[1:1:0712/212747.186641:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 987
[1:1:0712/212747.186834:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 987 0x7f4b5ccfb070 0xdc7661a85e0 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 852 0x7f4b5ccfb070 0xdc7673f27e0 
[1:1:0712/212747.243076:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 987, 7f4b5f6408db
[1:1:0712/212747.283533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"852 0x7f4b5ccfb070 0xdc7673f27e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212747.283936:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"852 0x7f4b5ccfb070 0xdc7673f27e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0712/212747.284457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.netbian.com/, 991
[1:1:0712/212747.284725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 991 0x7f4b5ccfb070 0xdc7673f4ce0 , 5:3_http://www.netbian.com/, 0, , 987 0x7f4b5ccfb070 0xdc7661a85e0 
[1:1:0712/212747.285077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0712/212747.285709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , tick, (){for(var a=
c.timers,b=0;b<a.length;b++)a[b]()||a.splice(b--,1);a.length||c.fx.stop()}
[1:1:0712/212747.285933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0712/212747.289418:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 983, 7f4b5f640881
[1:1:0100/000000.339796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"006562b02860","ptid":"981 0x7f4b5ccfb070 0xdc765f868e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0100/000000.351353:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.netbian.com/","ptid":"981 0x7f4b5ccfb070 0xdc765f868e0 ","rf":"5:3_http://www.netbian.com/"}
[1:1:0100/000000.351712:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.netbian.com/"
[1:1:0100/000000.352197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.netbian.com/, 006562b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0100/000000.352346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.netbian.com/", "www.netbian.com", 3, 1, , , 0
[1:1:0100/000000.352967:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x233393c429c8, 0xdc765cac150
[1:1:0100/000000.353067:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.netbian.com/", 100
[1:1:0100/000000.353324:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.netbian.com/, 1017
[1:1:0100/000000.353460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7f4b5ccfb070 0xdc76735de60 , 5:3_http://www.netbian.com/, 1, -5:3_http://www.netbian.com/, 983 0x7f4b5ccfb070 0xdc765b2a660 
