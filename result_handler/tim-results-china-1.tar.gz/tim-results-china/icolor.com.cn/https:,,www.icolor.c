[0711/224019.100513:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/224019.100834:INFO:switcher_clone.cc(787)] backtrace rip is 7f48995a9891
[0711/224019.975577:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/224019.975878:INFO:switcher_clone.cc(787)] backtrace rip is 7fac863e2891
[1:1:0711/224019.980033:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/224019.980216:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/224019.985492:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[28934:28934:0711/224020.945383:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/bc525b5b-f97c-4af5-b701-50c34d865583
[0711/224021.378170:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/224021.378507:INFO:switcher_clone.cc(787)] backtrace rip is 7f7a97e03891
[28934:28934:0711/224021.445102:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[28934:28963:0711/224021.445912:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/224021.446149:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/224021.446388:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/224021.446959:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/224021.447107:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/224021.449997:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd82fc99, 1
[1:1:0711/224021.450316:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x37206fd9, 0
[1:1:0711/224021.450479:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38cf9822, 3
[1:1:0711/224021.450635:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x341553fd, 2
[1:1:0711/224021.450825:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd96f2037 ffffff99fffffffcffffff820d fffffffd531534 22ffffff98ffffffcf38 , 10104, 4
[1:1:0711/224021.451744:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28934:28963:0711/224021.451977:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�o 7����S4"��8�R$
[28934:28963:0711/224021.452060:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �o 7����S4"��8�b�R$
[1:1:0711/224021.451975:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac8461d0a0, 3
[1:1:0711/224021.452226:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac847a8080, 2
[28934:28963:0711/224021.452436:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[28934:28963:0711/224021.452481:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28978, 4, d96f2037 99fc820d fd531534 2298cf38 
[1:1:0711/224021.452452:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac6e46bd20, -2
[1:1:0711/224021.467194:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/224021.468327:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 341553fd
[1:1:0711/224021.469678:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 341553fd
[1:1:0711/224021.471497:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 341553fd
[1:1:0711/224021.473406:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.473642:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.473867:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.474115:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.474906:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 341553fd
[1:1:0711/224021.475319:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac863e27ba
[1:1:0711/224021.475486:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac863d9def, 7fac863e277a, 7fac863e40cf
[1:1:0711/224021.482457:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 341553fd
[1:1:0711/224021.482896:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 341553fd
[1:1:0711/224021.483807:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 341553fd
[1:1:0711/224021.486354:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.486611:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.486836:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.487060:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 341553fd
[1:1:0711/224021.488661:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 341553fd
[1:1:0711/224021.489121:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac863e27ba
[1:1:0711/224021.489286:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac863d9def, 7fac863e277a, 7fac863e40cf
[1:1:0711/224021.499061:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/224021.499704:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/224021.499886:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe412bce68, 0x7ffe412bcde8)
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/224021.516685:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/224021.523769:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[28965:28965:0711/224021.599855:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28965
[28992:28992:0711/224021.600404:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28992
[28934:28934:0711/224022.007534:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28934:28934:0711/224022.008667:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28934:28944:0711/224022.020547:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[28934:28944:0711/224022.020650:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[28934:28934:0711/224022.020828:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[28934:28934:0711/224022.020908:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[28934:28934:0711/224022.021192:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,28978, 4
[1:7:0711/224022.022736:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[28934:28955:0711/224022.090389:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/224022.108207:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x5feee3c0220
[1:1:0711/224022.108493:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/224022.412872:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0711/224023.934274:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224023.937422:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28934:28934:0711/224023.938888:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[28934:28934:0711/224023.939012:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/224025.659238:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224025.785148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1327bd461f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/224025.785419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224025.819602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1327bd461f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/224025.819945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224026.172498:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224026.172674:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224026.460203:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224026.468439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1327bd461f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/224026.468792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224026.506262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224026.509540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1327bd461f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/224026.509694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224026.513630:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/224026.517735:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x5feee3bee20
[1:1:0711/224026.517968:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[28934:28934:0711/224026.518718:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[28934:28934:0711/224026.524159:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[28934:28934:0711/224026.558413:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[28934:28934:0711/224026.558589:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/224026.577129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224027.330873:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fac700462e0 0x5feee6258e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224027.332441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1327bd461f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/224027.332578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224027.334438:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28934:28934:0711/224027.376742:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/224027.379506:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x5feee3bf820
[1:1:0711/224027.379731:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[28934:28934:0711/224027.384018:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/224027.402088:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/224027.402340:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[28934:28934:0711/224027.403817:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[28934:28934:0711/224027.415387:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28934:28934:0711/224027.416593:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28934:28944:0711/224027.422625:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[28934:28944:0711/224027.422747:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[28934:28934:0711/224027.422882:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[28934:28934:0711/224027.422959:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[28934:28934:0711/224027.423093:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,28978, 4
[1:7:0711/224027.425705:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/224027.854497:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/224028.267348:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fac700462e0 0x5feee625160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224028.268485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1327bd461f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/224028.268739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224028.269517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[28934:28934:0711/224028.365997:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[28934:28934:0711/224028.366145:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/224028.414479:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/224028.616463:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224029.154575:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224029.154866:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[28934:28934:0711/224029.191857:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[28934:28963:0711/224029.192345:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/224029.192591:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/224029.192843:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/224029.193269:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/224029.193586:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/224029.196621:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2df5dea7, 1
[1:1:0711/224029.196984:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15488111, 0
[1:1:0711/224029.197206:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1baf45dd, 3
[1:1:0711/224029.197385:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x34ffe9be, 2
[1:1:0711/224029.197556:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 11ffffff814815 ffffffa7ffffffdefffffff52d ffffffbeffffffe9ffffffff34 ffffffdd45ffffffaf1b , 10104, 5
[1:1:0711/224029.198560:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28934:28963:0711/224029.198830:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�H���-���4�E��T$
[28934:28963:0711/224029.198914:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �H���-���4�E����T$
[1:1:0711/224029.198820:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac8461d0a0, 3
[1:1:0711/224029.199040:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac847a8080, 2
[28934:28963:0711/224029.199217:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29032, 5, 11814815 a7def52d bee9ff34 dd45af1b 
[1:1:0711/224029.199258:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fac6e46bd20, -2
[1:1:0711/224029.221789:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/224029.222121:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34ffe9be
[1:1:0711/224029.222458:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34ffe9be
[1:1:0711/224029.223071:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34ffe9be
[1:1:0711/224029.224592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.224859:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.225075:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.225277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.225918:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34ffe9be
[1:1:0711/224029.226216:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac863e27ba
[1:1:0711/224029.226354:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac863d9def, 7fac863e277a, 7fac863e40cf
[1:1:0711/224029.232036:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34ffe9be
[1:1:0711/224029.232540:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34ffe9be
[1:1:0711/224029.233452:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34ffe9be
[1:1:0711/224029.235937:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.236187:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.236325:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.236607:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34ffe9be
[1:1:0711/224029.238323:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34ffe9be
[1:1:0711/224029.238755:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fac863e27ba
[1:1:0711/224029.238912:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fac863d9def, 7fac863e277a, 7fac863e40cf
[1:1:0711/224029.245247:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/224029.245630:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/224029.245721:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe412bce68, 0x7ffe412bcde8)
[1:1:0711/224029.259732:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/224029.264958:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/224029.380744:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x5feee392220
[1:1:0711/224029.380895:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/224029.427780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224029.433171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1327bd5909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/224029.433510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224029.440651:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[28934:28934:0711/224030.800747:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28934:28934:0711/224030.807247:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28934:28934:0711/224030.839174:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.icolor.com.cn/
[28934:28934:0711/224030.839296:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.icolor.com.cn/, https://www.icolor.com.cn/design/designer/search, 1
[28934:28944:0711/224030.839363:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[28934:28944:0711/224030.839475:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[28934:28934:0711/224030.839500:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.icolor.com.cn/, HTTP/1.1 200 OK Server: Apache-Coyote/1.1 Set-Cookie: HYSESSIONID=679485937E38BDF911C47F08E740AE73; Path=""; HttpOnly Content-Type: text/html;charset=utf-8 Content-Language: zh Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 05:40:27 GMT  ,29032, 5
[1:7:0711/224030.843382:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/224030.875334:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.icolor.com.cn/
[28934:28934:0711/224031.041859:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.icolor.com.cn/, https://www.icolor.com.cn/, 1
[28934:28934:0711/224031.041925:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.icolor.com.cn/, https://www.icolor.com.cn
[1:1:0711/224031.075258:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/224031.141083:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224031.182718:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/224031.243851:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224031.244104:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224032.425780:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224032.864910:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_NAME_NOT_RESOLVED","https://same.icolor.com.cn/s?z=icolor&c=49"
[1:1:0711/224032.957086:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_NAME_NOT_RESOLVED","https://same.icolor.com.cn/s?z=icolor&c=50"
[1:1:0711/224032.983686:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_NAME_NOT_RESOLVED","https://same.icolor.com.cn/s?z=icolor&c=51"
[1:1:0711/224033.629947:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fac6e11e070 0x5feee62b560 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224033.632493:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224033.643219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , /*! jQuery v2.2.1 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof mo
[1:1:0711/224033.643450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224033.933891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fac6e11e070 0x5feee62b560 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224034.285883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fac6e11e070 0x5feee62b560 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224034.287166:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fac6e11e070 0x5feee62b560 , "https://www.icolor.com.cn/design/designer/search"
		remove user.f_98401df1 -> 0
[1:1:0711/224034.291543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fac6e11e070 0x5feee62b560 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224034.395868:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.463339, 168, 1
[1:1:0711/224034.396143:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224034.623283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7fac700462e0 0x5feee72d760 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224034.632634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0711/224034.632910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224034.678555:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3604a1d629c8, 0x5feee2091a8
[1:1:0711/224034.678825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 0
[1:1:0711/224034.679331:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 403
[1:1:0711/224034.679583:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 403 0x7fac6e11e070 0x5feee8e91e0 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 285 0x7fac700462e0 0x5feee72d760 
[1:1:0711/224034.682366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 86400000
[1:1:0711/224034.682844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 405
[1:1:0711/224034.683080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 405 0x7fac6e11e070 0x5feee8db3e0 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 285 0x7fac700462e0 0x5feee72d760 
[1:1:0711/224035.739883:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224035.740028:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224035.740602:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 341 0x7fac6e11e070 0x5feee8f3460 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224035.741736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
    var search_url_dest = "";
    $(function(){
        var $searchOptions = $('#content-search-con
[1:1:0711/224035.741933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224035.748289:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 341 0x7fac6e11e070 0x5feee8f3460 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224035.750791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 341 0x7fac6e11e070 0x5feee8f3460 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224035.755442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 341 0x7fac6e11e070 0x5feee8f3460 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224035.814694:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0747452, 237, 1
[1:1:0711/224035.814984:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224037.017429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 403, 7fac70a63881
[1:1:0711/224037.031068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"285 0x7fac700462e0 0x5feee72d760 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224037.031420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"285 0x7fac700462e0 0x5feee72d760 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224037.031814:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224037.032573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0711/224037.032789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224037.062646:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3604a1d629c8, 0x5feee209150
[1:1:0711/224037.062929:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 500
[1:1:0711/224037.063406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 508
[1:1:0711/224037.063640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 508 0x7fac6e11e070 0x5feeeb7b6e0 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 403 0x7fac6e11e070 0x5feee8e91e0 
[1:1:0711/224037.158503:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3604a1d629c8, 0x5feee209150
[1:1:0711/224037.158773:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 500
[1:1:0711/224037.159240:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 509
[1:1:0711/224037.159467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 509 0x7fac6e11e070 0x5feeeba6fe0 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 403 0x7fac6e11e070 0x5feee8e91e0 
[1:1:0711/224038.536537:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224038.537101:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224038.537494:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224038.537875:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224038.538227:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224040.187931:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224040.188127:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224040.199195:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0109792, 164, 1
[1:1:0711/224040.199360:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224041.234047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539 0x7fac700462e0 0x5feee724be0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224041.241132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , window._agl = window._agl || [];window._agl.push(["ext", {xAngeliaLogid: "24349733382434973305", bcl
[1:1:0711/224041.241379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[28934:28934:0711/224044.444967:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/224044.489582:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/224044.585581:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3604a1d629c8, 0x5feee209148
[1:1:0711/224044.585749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 50
[1:1:0711/224044.585947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 669
[1:1:0711/224044.586075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7fac6e11e070 0x5feeeb22060 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 539 0x7fac700462e0 0x5feee724be0 
[1:1:0711/224045.171526:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 12000
[1:1:0711/224045.172092:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 673
[1:1:0711/224045.172344:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7fac6e11e070 0x5feef000060 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 539 0x7fac700462e0 0x5feee724be0 
[1:1:0711/224045.266464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540 0x7fac700462e0 0x5feee728b60 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224045.268475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0711/224045.268595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
		remove user.10_e8fb9765 -> 0
		remove user.11_9327cded -> 0
		remove user.12_7a5b3325 -> 0
		remove user.13_4dcc5ae5 -> 0
		remove user.14_71315457 -> 0
[1:1:0711/224047.204821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224047.279207:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 509, 7fac70a63881
[1:1:0711/224047.310439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"403 0x7fac6e11e070 0x5feee8e91e0 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224047.310810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"403 0x7fac6e11e070 0x5feee8e91e0 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224047.311207:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224047.311868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , Zc, (){Rc&&(v.clearTimeout(Rc),Rc=void 0);void 0===Sc||Tc[Sc]&&!Uc||(Vc[Sc]||Wc.Wf()||0>=Xc--?(ab("GTM",
[1:1:0711/224047.312136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224049.348109:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224049.348386:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224049.379369:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.030751, 213, 1
[1:1:0711/224049.379603:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224050.470524:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224050.473341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (){for(var t=arguments.length,e=Array(t),r=0;r<t;r++)e[r]=arguments[r];return a.apply(n,o.concat(e))
[1:1:0711/224050.473531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224050.635304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/224050.635524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224051.642872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 669, 7fac70a63881
[1:1:0711/224051.657694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"539 0x7fac700462e0 0x5feee724be0 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224051.657886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"539 0x7fac700462e0 0x5feee724be0 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224051.658113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224051.658477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (){n.dispatch(new d.default(e.EVENT.URL_CHANGE,{url:t.target.location.href}))}
[1:1:0711/224051.658596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224051.678749:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224051.679189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , a.onreadystatechange, (){4===a.readyState&&s()}
[1:1:0711/224051.679329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224051.679692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224051.680959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224052.659518:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224052.660387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , Pa.d.onerror, (){d.onerror=null;c&&c()}
[1:1:0711/224052.660647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224053.017813:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224053.018027:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224053.021115:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 726 0x7fac6e11e070 0x5feeec595e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224053.022133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.write('<div  style="width:955px;height:100px;border:none;padding:0px;margin:0px;overflow:hi
[1:1:0711/224053.022331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224053.029737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 726 0x7fac6e11e070 0x5feeec595e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224053.067589:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0493829, 134, 1
[1:1:0711/224053.067766:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224053.840451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.readyState
[1:1:0711/224053.840712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224055.272206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224055.272994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , Pa.d.onerror, (){d.onerror=null;c&&c()}
[1:1:0711/224055.273202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224055.356376:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224055.357345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0711/224055.357599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224055.360920:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3604a1d629c8, 0x5feee209210
[1:1:0711/224055.361149:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 500
[1:1:0711/224055.361644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 872
[1:1:0711/224055.361884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 872 0x7fac6e11e070 0x5feef96a5e0 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 788 0x7fac6e11e070 0x5feef8a6860 
[1:1:0711/224055.588864:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224055.589078:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224055.589947:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 798 0x7fac6e11e070 0x5feef225fe0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224055.591002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
    function icdeal1()
    {
        if($("#xieyi1").is(':checked')){
            $("#submitform1")
[1:1:0711/224055.591173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224055.616543:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0274429, 287, 1
[1:1:0711/224055.616824:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224056.447889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.readyState
[1:1:0711/224056.448068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224058.258297:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224058.259310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , () {
        if (window.orientation === 180 || window.orientation === 0) {
            window.loca
[1:1:0711/224058.259572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224059.775418:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224059.775684:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224059.776627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7fac6e11e070 0x5feef6f9ce0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224059.778029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
	var _hmt = _hmt || [];
	(function() {
		var hm = document.createElement("script");
		hm.src = "htt
[1:1:0711/224059.778324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224059.785638:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7fac6e11e070 0x5feef6f9ce0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224059.812177:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0362849, 72, 1
[1:1:0711/224059.812447:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224059.986561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 872, 7fac70a63881
[1:1:0711/224100.019502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"788 0x7fac6e11e070 0x5feef8a6860 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224100.019919:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"788 0x7fac6e11e070 0x5feef8a6860 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224100.020395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224100.021040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , Zc, (){Rc&&(v.clearTimeout(Rc),Rc=void 0);void 0===Sc||Tc[Sc]&&!Uc||(Vc[Sc]||Wc.Wf()||0>=Xc--?(ab("GTM",
[1:1:0711/224100.021341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224100.568121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.readyState
[1:1:0711/224100.568471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224100.814482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 673, 7fac70a638db
[1:1:0711/224100.857385:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"539 0x7fac700462e0 0x5feee724be0 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224100.857778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"539 0x7fac700462e0 0x5feee724be0 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224100.858247:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 1007
[1:1:0711/224100.858505:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7fac6e11e070 0x5fef0822660 , 5:3_https://www.icolor.com.cn/, 0, , 673 0x7fac6e11e070 0x5feef000060 
[1:1:0711/224100.858868:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224100.859472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (){t.eventHandler({type:e.E_TYPE.HEARTBEAT,target:window})}
[1:1:0711/224100.859708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224102.947873:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224102.948098:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224102.953045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 972 0x7fac6e11e070 0x5feef88fe60 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224102.955407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , /*! layer-v2.3 弹层组件 License LGPL  http://layer.layui.com/ By 贤心 */
;!function(a,b){"use 
[1:1:0711/224102.955599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224103.053284:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3604a1d629c8, 0x5feee2091a8
[1:1:0711/224103.053506:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 100
[1:1:0711/224103.053932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1048
[1:1:0711/224103.054176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1048 0x7fac6e11e070 0x5feee8b9960 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 972 0x7fac6e11e070 0x5feef88fe60 
[1:1:0711/224103.056928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 972 0x7fac6e11e070 0x5feef88fe60 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224103.059959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 972 0x7fac6e11e070 0x5feef88fe60 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224103.082775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 972 0x7fac6e11e070 0x5feef88fe60 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224103.805116:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224103.807670:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[28934:28934:0711/224104.156477:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/224104.157859:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x5feedfa6820
[1:1:0711/224104.158056:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[28934:28934:0711/224104.163114:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: POST_IFRAME_0, 4, 4, 
[28934:28934:0711/224104.204404:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.icolor.com.cn/, https://www.icolor.com.cn/, 4
[28934:28934:0711/224104.204552:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.icolor.com.cn/, https://www.icolor.com.cn
[1:1:0711/224104.243431:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3604a1d629c8, 0x5feee2091c8
[1:1:0711/224104.243632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 200
[1:1:0711/224104.243861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1079
[1:1:0711/224104.244013:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7fac6e11e070 0x5fef0d43460 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 972 0x7fac6e11e070 0x5feef88fe60 
[1:1:0711/224104.249232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x3604a1d629c8, 0x5feee2091c8
[1:1:0711/224104.249366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 2000
[1:1:0711/224104.249533:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1082
[1:1:0711/224104.249637:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1082 0x7fac6e11e070 0x5fef0d47a60 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 972 0x7fac6e11e070 0x5feef88fe60 
[1:1:0711/224104.252914:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 500
[1:1:0711/224104.253120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 1083
[1:1:0711/224104.253237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7fac6e11e070 0x5fef0d2d360 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 972 0x7fac6e11e070 0x5feef88fe60 
[1:1:0711/224104.255628:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.30729, 1, 0
[1:1:0711/224104.255744:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224105.497413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.readyState
[1:1:0711/224105.497654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[28934:28934:0711/224106.397116:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224108.319133:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/224108.319293:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.icolor.com.cn
[28934:28934:0711/224108.320937:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.icolor.com.cn/
[1:1:0711/224108.392819:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224108.393035:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224108.423626:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0304949, 157, 1
[1:1:0711/224108.423811:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224108.424547:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1048, 7fac70a63881
[1:1:0711/224108.468837:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224108.469256:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224108.469759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224108.470517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , j, (){(g?1989===parseInt(c("#"+i).css("width")):f[d||i])?function(){b&&b();try{g||e.removeChild(h)}catc
[1:1:0711/224108.470747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[28934:28934:0711/224108.505246:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28934:28934:0711/224108.512805:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28934:28944:0711/224108.540416:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[28934:28944:0711/224108.540517:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[28934:28934:0711/224108.545570:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://sh-trail.ntalker.com/
[28934:28934:0711/224108.545648:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://sh-trail.ntalker.com/, https://sh-trail.ntalker.com/trail/trail/userinfo.php?action=save&url=https%3A%2F%2Fwww.icolor.com.cn%2Fdesign%2Fdesigner%2Fsearch&siteid=lb_1000&uid=lb_1000_ISME9754_anonymous&uname=Anonymous&device=WAP&isvip=0&userlevel=1&cid=guestD169E222-158B-5D95-AD7A-E4AC0572A8C6&sid=1562909607269060&log=1&pageid=1562910063344&etype=pv&edata=&sourceid=&sourcename=&keyid=&keyword=&country=&province=&city=&lan=en-US&scr=1276*647&cookie=1&flash=0.0.0.0&sellerid=&ttl=%E8%A3%85%E4%BF%AE%E8%AE%BE%E8%AE%A1%E5%B8%88%E5%A4%A7%E5%85%A8%2C%E8%A3%85%E4%BF%AE%E5%AE%B6%E5%B1%85%E6%90%AD%E9%85%8D%E8%AE%BE%E8%AE%A1%E5%B8%88%E5%93%AA%E4%B8%AA%E5%A5%BD%2C%E5%AE%B6%E8%A3%85%E8%AE%BE%E8%AE%A1%E5%B8%88%E6%8E%92%E5%90%8D-iColor%E8%A3%85%E4%BF%AE%E7%BD%91, 4
[28934:28934:0711/224108.545809:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://sh-trail.ntalker.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 05:41:08 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Access-Control-Allow-Origin: * Content-Encoding: gzip  ,29032, 5
[1:7:0711/224108.547315:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/224109.080347:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1096 0x7fac700462e0 0x5fef0d45c60 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224109.083289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0711/224109.083484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224109.206272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1097 0x7fac700462e0 0x5fef0d45d60 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224109.207688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (function(){var h={},mt={},c={id:"60925cbfbdc097b3cfc9493e515f0d24",dm:["icolor.com.cn"],js:"tongji.
[1:1:0711/224109.207826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224109.230280:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3604a1d629c8, 0x5feee209188
[1:1:0711/224109.230498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 100
[1:1:0711/224109.230889:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1213
[1:1:0711/224109.231079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1213 0x7fac6e11e070 0x5fef0d47360 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 1097 0x7fac700462e0 0x5fef0d45d60 
[1:1:0711/224109.539721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1079, 7fac70a63881
[1:1:0711/224109.592709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224109.593055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224109.593503:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224109.594108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (){r&&"function"==typeof r&&r(),clearTimeout(n.getRegionTimer),n.getRegionTimer=null}
[1:1:0711/224109.594319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224109.858240:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224109.859030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , Pa.d.onerror, (){d.onerror=null;c&&c()}
[1:1:0711/224109.859251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224109.916833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 1083, 7fac70a638db
[1:1:0711/224109.976250:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224109.976609:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224109.977090:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 1248
[1:1:0711/224109.977326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1248 0x7fac6e11e070 0x5fef0fc6fe0 , 5:3_https://www.icolor.com.cn/, 0, , 1083 0x7fac6e11e070 0x5fef0d2d360 
[1:1:0711/224109.977737:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224109.978364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (){a.setAttribute("loadTime",parseInt(a.getAttribute("loadTime"))+1),parseInt(a.getAttribute("loadTi
[1:1:0711/224109.978622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224110.599795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.readyState
[1:1:0711/224110.600086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224110.714415:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1082, 7fac70a63881
[1:1:0711/224110.770757:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224110.771152:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"972 0x7fac6e11e070 0x5feef88fe60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224110.771651:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224110.772404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (){!0!==e.base.chatLoading&&(t={lang:(e.extParmas.lan||"zh_cn")+".js"+e.baseExt},e.global.themes?(t.
[1:1:0711/224110.772583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224112.815537:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224112.815805:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224112.817170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1191 0x7fac6e11e070 0x5fef0d919e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224112.819961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
	function refreshKeyWords () {
	    var prevHref = document.referrer
	    var host = prevHref.split
[1:1:0711/224112.820224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224112.880962:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1191 0x7fac6e11e070 0x5fef0d919e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224112.885659:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1191 0x7fac6e11e070 0x5fef0d919e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224112.895877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1191 0x7fac6e11e070 0x5fef0d919e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224113.123780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1191 0x7fac6e11e070 0x5fef0d919e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224113.143441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1191 0x7fac6e11e070 0x5fef0d919e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224113.173025:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1191 0x7fac6e11e070 0x5fef0d919e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224113.388917:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.572877, 5, 0
[1:1:0711/224113.389176:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224113.683028:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://sh-trail.ntalker.com/
[1:1:0711/224113.919419:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224113.920042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , a.complete.a.onload, (){clearInterval(o),t.call(nTalk,this)}
[1:1:0711/224113.920200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224113.959715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 1007, 7fac70a638db
[1:1:0711/224114.023330:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"673 0x7fac6e11e070 0x5feef000060 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224114.023723:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"673 0x7fac6e11e070 0x5feef000060 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224114.024257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.icolor.com.cn/, 1371
[1:1:0711/224114.024548:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1371 0x7fac6e11e070 0x5fef13185e0 , 5:3_https://www.icolor.com.cn/, 0, , 1007 0x7fac6e11e070 0x5fef0822660 
[1:1:0711/224114.024976:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224114.025715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , (){t.eventHandler({type:e.E_TYPE.HEARTBEAT,target:window})}
[1:1:0711/224114.026056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224115.128127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1213, 7fac70a63881
[1:1:0711/224115.174727:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"1097 0x7fac700462e0 0x5fef0d45d60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224115.174920:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"1097 0x7fac700462e0 0x5fef0d45d60 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224115.175182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224115.175532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224115.175666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224115.176060:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3604a1d629c8, 0x5feee209150
[1:1:0711/224115.176161:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 100
[1:1:0711/224115.176340:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1390
[1:1:0711/224115.176450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1390 0x7fac6e11e070 0x5fef13ef660 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 1213 0x7fac6e11e070 0x5fef0d47360 
[1:1:0711/224116.649114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.readyState
[1:1:0711/224116.649353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224119.452450:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224119.452736:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224119.469751:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1335 0x7fac6e11e070 0x5fef12ee560 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224119.565238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , /*! jQuery UI - v1.11.2 - 2015-01-04
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0711/224119.565548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
		remove user.11_29189e3e -> 0
		remove user.12_a99e28c0 -> 0
[1:1:0711/224121.292541:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.83955, 0, 0
[1:1:0711/224121.292765:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224121.903379:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224121.903837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xc[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0711/224121.903978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224121.904729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224121.906662:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224121.907393:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xdc35e3f1890
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224122.474148:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28934:28934:0711/224122.483242:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://sh-trail.ntalker.com/, https://sh-trail.ntalker.com/, 4
[28934:28934:0711/224122.483393:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://sh-trail.ntalker.com/, https://sh-trail.ntalker.com
[1:1:0711/224124.761035:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224124.761460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/224124.761563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224124.765176:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1390, 7fac70a63881
[1:1:0711/224124.801283:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"155b78b02860","ptid":"1213 0x7fac6e11e070 0x5fef0d47360 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224124.801485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.icolor.com.cn/","ptid":"1213 0x7fac6e11e070 0x5fef0d47360 ","rf":"5:3_https://www.icolor.com.cn/"}
[1:1:0711/224124.801724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224124.802149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224124.802257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224124.802600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3604a1d629c8, 0x5feee209150
[1:1:0711/224124.802705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 100
[1:1:0711/224124.802966:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1683
[1:1:0711/224124.803085:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1683 0x7fac6e11e070 0x5fef1dc5160 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 1390 0x7fac6e11e070 0x5fef13ef660 
[1:1:0711/224125.069453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1402 0x7fac700462e0 0x5feee0b5ce0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224125.070177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , trail_getregion_6A483811({"data":{"province":"北京","city":"北京","country":"中国","ip":"218.2
[1:1:0711/224125.070338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224125.070973:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224125.071976:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3604a1d629c8, 0x5feee209210
[1:1:0711/224125.072183:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 0
[1:1:0711/224125.072376:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1688
[1:1:0711/224125.072485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1688 0x7fac6e11e070 0x5fef1dc5ae0 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 1402 0x7fac700462e0 0x5feee0b5ce0 
[1:1:0711/224125.138406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1403 0x7fac700462e0 0x5feee09eee0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224125.142372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
/* @file lang/zh_cn.js
 * @date 2018.10.29 11:30:08 
 */
(function($){
	$.lang = {
		language: 
[1:1:0711/224125.142579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224125.152637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224125.154121:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3604a1d629c8, 0x5feee209210
[1:1:0711/224125.154321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 0
[1:1:0711/224125.154787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1692
[1:1:0711/224125.155047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1692 0x7fac6e11e070 0x5fef1b89260 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 1403 0x7fac700462e0 0x5feee09eee0 
[1:1:0711/224128.914760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , document.readyState
[1:1:0711/224128.915019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224129.432326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1472 0x7fac700462e0 0x5fef141b760 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224129.445584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
/* @file mqtt31.js
 * @date 2018.10.29 11:30:08 
 */
"undefined"==typeof nTalk&&(nTalk={}),nTal
[1:1:0711/224129.445936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224129.459789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224129.461166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3604a1d629c8, 0x5feee209210
[1:1:0711/224129.461376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 0
[1:1:0711/224129.461876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1833
[1:1:0711/224129.462157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1833 0x7fac6e11e070 0x5fef1e21860 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 1472 0x7fac700462e0 0x5fef141b760 
[1:1:0711/224129.554625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1473 0x7fac700462e0 0x5fef154c3e0 , "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224129.568200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.icolor.com.cn/, 155b78b02860, , , 
/* @file mqtt.chat.js
 * @date 2018.10.29 11:30:08 
 */
!function(t,e){t.Connection={name:"Conn
[1:1:0711/224129.568450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.icolor.com.cn/design/designer/search", "www.icolor.com.cn", 3, 1, , , 0
[1:1:0711/224129.582028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.icolor.com.cn/design/designer/search"
[1:1:0711/224129.583058:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3604a1d629c8, 0x5feee209210
[1:1:0711/224129.583221:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.icolor.com.cn/design/designer/search", 0
[1:1:0711/224129.583608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.icolor.com.cn/, 1836
[1:1:0711/224129.583809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1836 0x7fac6e11e070 0x5fef1e66960 , 5:3_https://www.icolor.com.cn/, 1, -5:3_https://www.icolor.com.cn/, 1473 0x7fac700462e0 0x5fef154c3e0 
[28934:28934:0711/224129.898918:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
