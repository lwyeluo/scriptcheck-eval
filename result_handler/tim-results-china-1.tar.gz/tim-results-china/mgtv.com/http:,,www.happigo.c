[0712/050458.774571:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/050458.775113:INFO:switcher_clone.cc(787)] backtrace rip is 7f5f3a9d1891
[0712/050459.722968:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/050459.723242:INFO:switcher_clone.cc(787)] backtrace rip is 7fec76e39891
[1:1:0712/050459.727322:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/050459.727561:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/050459.733458:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[81412:81412:0712/050500.831544:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6fa4f649-7d1d-40fa-8416-823496fe1abc
[0712/050501.151180:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/050501.151615:INFO:switcher_clone.cc(787)] backtrace rip is 7f8d6c992891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[81412:81412:0712/050501.419521:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[81412:81442:0712/050501.420543:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/050501.420746:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/050501.421146:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/050501.421822:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/050501.421985:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/050501.425075:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3f31e029, 1
[1:1:0712/050501.425466:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x22ba2a36, 0
[1:1:0712/050501.425579:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x381c97ac, 3
[1:1:0712/050501.425676:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2d19bf3f, 2
[1:1:0712/050501.425808:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 362affffffba22 29ffffffe0313f 3fffffffbf192d ffffffacffffff971c38 , 10104, 4
[81444:81444:0712/050501.426341:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=81444
[1:1:0712/050501.426709:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[81458:81458:0712/050501.426812:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=81458
[81412:81442:0712/050501.427095:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING6*�")�1??�-��8T�
[81412:81442:0712/050501.427185:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 6*�")�1??�-��8T�
[1:1:0712/050501.426951:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec750740a0, 3
[1:1:0712/050501.427434:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec751ff080, 2
[81412:81442:0712/050501.427540:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[81412:81442:0712/050501.427616:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 81457, 4, 362aba22 29e0313f 3fbf192d ac971c38 
[1:1:0712/050501.427616:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec5eec2d20, -2
[1:1:0712/050501.439966:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/050501.440744:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d19bf3f
[1:1:0712/050501.441556:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d19bf3f
[1:1:0712/050501.442827:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d19bf3f
[1:1:0712/050501.443594:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.443738:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.443873:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.444016:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.444387:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d19bf3f
[1:1:0712/050501.444590:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec76e397ba
[1:1:0712/050501.444697:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec76e30def, 7fec76e3977a, 7fec76e3b0cf
[1:1:0712/050501.446962:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d19bf3f
[1:1:0712/050501.447181:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d19bf3f
[1:1:0712/050501.447609:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d19bf3f
[1:1:0712/050501.448700:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.448850:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.448990:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.449122:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d19bf3f
[1:1:0712/050501.450214:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d19bf3f
[1:1:0712/050501.450577:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec76e397ba
[1:1:0712/050501.450709:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec76e30def, 7fec76e3977a, 7fec76e3b0cf
[1:1:0712/050501.459437:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/050501.460002:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/050501.460224:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc0b969b8, 0x7ffcc0b96938)
[1:1:0712/050501.479253:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/050501.486710:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[81412:81434:0712/050502.060021:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[81412:81412:0712/050502.088649:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[81412:81412:0712/050502.089985:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[81412:81423:0712/050502.098582:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[81412:81423:0712/050502.098708:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[81412:81412:0712/050502.098875:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[81412:81412:0712/050502.098986:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[81412:81412:0712/050502.099176:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,81457, 4
[1:7:0712/050502.101595:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/050502.184537:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1f55217e0220
[1:1:0712/050502.184746:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/050502.566802:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[81412:81412:0712/050504.194021:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[81412:81412:0712/050504.194145:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/050504.251728:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/050504.255846:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/050505.217840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14812b261f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/050505.218144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/050505.234553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14812b261f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/050505.234823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/050505.315259:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/050505.593856:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/050505.594148:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050506.056029:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050506.064095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14812b261f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/050506.064352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/050506.099087:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050506.109267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14812b261f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/050506.109544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/050506.121429:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[81412:81412:0712/050506.123856:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/050506.124841:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1f55217dee20
[1:1:0712/050506.125114:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[81412:81412:0712/050506.130761:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[81412:81412:0712/050506.159755:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[81412:81412:0712/050506.159911:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/050506.174483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050507.050867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7fec60a9d2e0 0x1f5521aa7be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050507.052202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14812b261f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/050507.052502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/050507.054022:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[81412:81412:0712/050507.103169:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/050507.104024:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1f55217df820
[1:1:0712/050507.104271:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[81412:81412:0712/050507.113842:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/050507.122851:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/050507.123088:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[81412:81412:0712/050507.125396:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[81412:81412:0712/050507.137022:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[81412:81412:0712/050507.138027:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[81412:81423:0712/050507.143895:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[81412:81423:0712/050507.143981:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[81412:81412:0712/050507.144123:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[81412:81412:0712/050507.144199:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[81412:81412:0712/050507.144335:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,81457, 4
[1:7:0712/050507.150814:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/050507.704891:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/050508.042581:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fec60a9d2e0 0x1f5521b8ffe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050508.043604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14812b261f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/050508.043917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/050508.044689:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050508.299915:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[81412:81412:0712/050508.304056:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[81412:81412:0712/050508.304181:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/050508.665612:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[81412:81412:0712/050509.189348:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[81412:81442:0712/050509.189788:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/050509.189985:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/050509.190219:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/050509.190598:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/050509.190740:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/050509.193832:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x276b2bbf, 1
[1:1:0712/050509.194206:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1f8da8a7, 0
[1:1:0712/050509.194363:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3ddf8c27, 3
[1:1:0712/050509.194507:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x18a2fbfa, 2
[1:1:0712/050509.194657:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa7ffffffa8ffffff8d1f ffffffbf2b6b27 fffffffafffffffbffffffa218 27ffffff8cffffffdf3d , 10104, 5
[1:1:0712/050509.196008:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[81412:81442:0712/050509.196312:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����+k'���'��=��
[81412:81442:0712/050509.196383:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����+k'���'��=�;��
[1:1:0712/050509.196307:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec750740a0, 3
[1:1:0712/050509.196556:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec751ff080, 2
[81412:81442:0712/050509.196649:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 81508, 5, a7a88d1f bf2b6b27 fafba218 278cdf3d 
[1:1:0712/050509.196806:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec5eec2d20, -2
[1:1:0712/050509.220425:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/050509.220809:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18a2fbfa
[1:1:0712/050509.221059:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18a2fbfa
[1:1:0712/050509.221315:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18a2fbfa
[1:1:0712/050509.221733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.221889:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.221983:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.222079:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.222307:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18a2fbfa
[1:1:0712/050509.222439:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec76e397ba
[1:1:0712/050509.222512:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec76e30def, 7fec76e3977a, 7fec76e3b0cf
[1:1:0712/050509.223970:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18a2fbfa
[1:1:0712/050509.224127:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18a2fbfa
[1:1:0712/050509.224385:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18a2fbfa
[1:1:0712/050509.225048:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.225174:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.225274:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.225364:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18a2fbfa
[1:1:0712/050509.225828:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18a2fbfa
[1:1:0712/050509.226006:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec76e397ba
[1:1:0712/050509.226080:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec76e30def, 7fec76e3977a, 7fec76e3b0cf
[1:1:0712/050509.228167:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/050509.228488:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/050509.228579:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc0b969b8, 0x7ffcc0b96938)
[1:1:0712/050509.239123:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/050509.243431:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/050509.284762:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/050509.285035:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/050509.426693:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1f55217c9220
[1:1:0712/050509.426984:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/050509.755211:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/050509.760312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 14812b3909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/050509.760615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/050509.768590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/050509.901466:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/050509.902207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14812b261f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/050509.902439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/050510.040303:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/050510.042010:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/050510.042243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 14812b3909f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/050510.042520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[81412:81412:0712/050510.093037:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[81412:81412:0712/050510.125251:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[81412:81442:0712/050510.125730:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/050510.125941:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/050510.126166:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/050510.126631:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/050510.126814:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/050510.129212:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x13d67640, 1
[1:1:0712/050510.129639:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1c8370a6, 0
[1:1:0712/050510.129888:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3560ffa3, 3
[1:1:0712/050510.130074:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xbbf4144, 2
[1:1:0712/050510.130259:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa670ffffff831c 4076ffffffd613 4441ffffffbf0b ffffffa3ffffffff6035 , 10104, 6
[1:1:0712/050510.131250:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[81412:81442:0712/050510.131550:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�p�@v�DA���`5��
[81412:81442:0712/050510.131621:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �p�@v�DA���`5�/��
[81412:81442:0712/050510.131924:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 81523, 6, a670831c 4076d613 4441bf0b a3ff6035 
[1:1:0712/050510.131747:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec750740a0, 3
[1:1:0712/050510.132507:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec751ff080, 2
[1:1:0712/050510.132740:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec5eec2d20, -2
[81412:81412:0712/050510.153692:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/050510.159701:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/050510.160058:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bbf4144
[1:1:0712/050510.160372:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bbf4144
[1:1:0712/050510.160994:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bbf4144
[1:1:0712/050510.162457:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.162687:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.162912:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.163139:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.163843:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bbf4144
[1:1:0712/050510.164188:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec76e397ba
[1:1:0712/050510.164379:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec76e30def, 7fec76e3977a, 7fec76e3b0cf
[1:1:0712/050510.170150:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bbf4144
[1:1:0712/050510.170601:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bbf4144
[1:1:0712/050510.171379:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bbf4144
[1:1:0712/050510.173410:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.173665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.173901:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.174124:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bbf4144
[1:1:0712/050510.175451:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bbf4144
[1:1:0712/050510.175857:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec76e397ba
[1:1:0712/050510.176039:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec76e30def, 7fec76e3977a, 7fec76e3b0cf
[1:1:0712/050510.183486:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/050510.184025:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/050510.184218:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcc0b969b8, 0x7ffcc0b96938)
[81412:81412:0712/050510.186704:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.happigo.com/
[81412:81412:0712/050510.186798:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.happigo.com/, https://www.happigo.com/, 1
[81412:81412:0712/050510.186952:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.happigo.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 12:05:09 GMT content-type:text/html; charset=UTF-8 server:nginx vary:Accept-Encoding set-cookie:PHPSESSID=gkn4afoghfqj7gfoqb1p83prg7; path=/; domain=happigo.com expires:Thu, 19 Nov 1981 08:52:00 GMT cache-control:no-store, no-cache, must-revalidate, post-check=0, pre-check=0 pragma:no-cache content-encoding:gzip  ,0, 6
[1:1:0712/050510.205562:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/050510.209775:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[81412:81423:0712/050510.213615:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[81412:81423:0712/050510.213669:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[3:3:0712/050510.253826:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/050510.255860:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/050510.256763:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/050510.257016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 14812b3909f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/050510.257299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:7:0712/050510.331452:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/050510.465511:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1f55217de220
[1:1:0712/050510.465788:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/050510.526678:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.happigo.com/
[1:1:0712/050510.738129:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[81412:81412:0712/050510.763547:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.happigo.com/, https://www.happigo.com/, 1
[81412:81412:0712/050510.763700:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.happigo.com/, https://www.happigo.com
[1:1:0712/050510.837831:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/050510.874570:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/050510.927078:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/050510.927329:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.happigo.com/"
[1:1:0712/050511.128219:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/050511.339597:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/050511.450907:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/050511.487782:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 152, "https://www.happigo.com/"
[1:1:0712/050511.496854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , var TINGYUN=function(e,t,n){function r(e){var t=!!e&&"length"in e&&e.length,n=typeof e;return"functi
[1:1:0712/050511.497141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050511.513348:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/050511.618161:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/050511.666562:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/050511.727509:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/050511.805825:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://usatoday.com/"
[1:1:0712/050511.930038:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gome.com.cn/"
[1:1:0712/050512.004264:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/050512.072466:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/050512.138168:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/050520.433445:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/050520.434015:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/050520.434417:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/050520.434849:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/050520.435283:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[81412:81412:0712/050531.607581:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/050531.614246:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/050531.733050:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.happigo.com/", 2000
[1:1:0712/050531.735224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 212
[1:1:0712/050531.735766:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 212 0x7fec5eb75070 0x1f55218d71e0 , 6:3_https://www.happigo.com/, 1, -6:3_https://www.happigo.com/, 152
[1:1:0712/050531.748419:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.happigo.com/", 10000
[1:1:0712/050531.752435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 213
[1:1:0712/050531.752731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 213 0x7fec5eb75070 0x1f55218b5460 , 6:3_https://www.happigo.com/, 1, -6:3_https://www.happigo.com/, 152
[1:1:0712/050531.927383:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/050532.183542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/050532.183882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050532.728562:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fec5eeddbd0 0x1f5521ae9658 , "https://www.happigo.com/"
[1:1:0712/050532.736974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindo
[1:1:0712/050532.737290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
		remove user.10_9d151103 -> 0
[1:1:0712/050532.916034:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fec5eeddbd0 0x1f5521ae9658 , "https://www.happigo.com/"
[1:1:0712/050532.925205:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fec5eeddbd0 0x1f5521ae9658 , "https://www.happigo.com/"
[1:1:0712/050532.938116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fec5eeddbd0 0x1f5521ae9658 , "https://www.happigo.com/"
[1:1:0712/050532.945404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fec5eeddbd0 0x1f5521ae9658 , "https://www.happigo.com/"
[1:1:0712/050533.077939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , document.readyState
[1:1:0712/050533.078191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050533.221090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , document.readyState
[1:1:0712/050533.221321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050533.262351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7fec5eeddbd0 0x1f552193d958 , "https://www.happigo.com/"
[1:1:0712/050533.272273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , /*! jQuery UI - v1.8.23 - 2012-08-15
* https://github.com/jquery/jquery-ui
* Includes: jquery.ui.cor
[1:1:0712/050533.272470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050533.817382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7fec5eeddbd0 0x1f552193d958 , "https://www.happigo.com/"
[1:1:0712/050533.855655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7fec5eeddbd0 0x1f552193d958 , "https://www.happigo.com/"
[1:1:0712/050533.873009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7fec5eeddbd0 0x1f552193d958 , "https://www.happigo.com/"
[1:1:0712/050534.060813:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.247567, 136, 1
[1:1:0712/050534.061017:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/050534.097588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , document.readyState
[1:1:0712/050534.097767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050534.932221:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/050534.932529:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.happigo.com/"
[1:1:0712/050534.935946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7fec5eb75070 0x1f552207d8e0 , "https://www.happigo.com/"
[1:1:0712/050534.939568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , ;
$(window).scroll(function () {
    var t_height = $(".full_big_eye").outerHeight() + $(".header").
[1:1:0712/050534.939863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050535.358514:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.425897, 1426, 1
[1:1:0712/050535.358830:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/050535.469418:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 212, 7fec614ba8db
[1:1:0712/050535.490967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f386f7a2860","ptid":"152","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050535.491364:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.happigo.com/","ptid":"152","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050535.491882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 474
[1:1:0712/050535.492133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 474 0x7fec5eb75070 0x1f5522077060 , 6:3_https://www.happigo.com/, 0, , 212 0x7fec5eb75070 0x1f55218d71e0 
[1:1:0712/050535.492511:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.happigo.com/"
[1:1:0712/050535.493198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , (){0!=(Pt.flags&jt)&&Pt.before(this,t);try{var n=e.apply(this,arguments)}catch(r){throw 0!=(Pt.flags
[1:1:0712/050535.493423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050537.669431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , document.readyState
[1:1:0712/050537.716965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050540.082119:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/050540.082385:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.happigo.com/"
[1:1:0712/050540.085872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fec5eb75070 0x1f5522199c60 , "https://www.happigo.com/"
[1:1:0712/050540.087785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , (function (jQuery) {
    jQuery.fn.focusMap = function (options) {
        var defaults = {
        
[1:1:0712/050540.088261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050540.095505:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fec5eb75070 0x1f5522199c60 , "https://www.happigo.com/"
[1:1:0712/050540.117352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fec5eb75070 0x1f5522199c60 , "https://www.happigo.com/"
[1:1:0712/050540.124781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fec5eb75070 0x1f5522199c60 , "https://www.happigo.com/"
[1:1:0712/050540.127047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fec5eb75070 0x1f5522199c60 , "https://www.happigo.com/"
[1:1:0712/050540.166206:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fec5eb75070 0x1f5522199c60 , "https://www.happigo.com/"
[1:1:0712/050540.355183:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.272723, 1562, 1
[1:1:0712/050540.355483:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/050540.442413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 474, 7fec614ba8db
[1:1:0712/050540.473465:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"212 0x7fec5eb75070 0x1f55218d71e0 ","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050540.473820:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"212 0x7fec5eb75070 0x1f55218d71e0 ","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050540.474291:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 766
[1:1:0712/050540.474549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 766 0x7fec5eb75070 0x1f552295d760 , 6:3_https://www.happigo.com/, 0, , 474 0x7fec5eb75070 0x1f5522077060 
[1:1:0712/050540.474884:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.happigo.com/"
[1:1:0712/050540.475423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , (){0!=(Pt.flags&jt)&&Pt.before(this,t);try{var n=e.apply(this,arguments)}catch(r){throw 0!=(Pt.flags
[1:1:0712/050540.475664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050544.541175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , document.readyState
[1:1:0712/050544.541359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/050549.927733:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/050549.928048:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.happigo.com/"
[1:1:0712/050549.929157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 721 0x7fec5eb75070 0x1f5521ffb3e0 , "https://www.happigo.com/"
[1:1:0712/050549.930877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , 
$(document).ready(function(){
    $(".prev").click(function(){
    	/*
    	var names =document.get
[1:1:0712/050549.931111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050549.949564:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0213249, 118, 1
[1:1:0712/050549.949755:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[81412:81412:0712/050553.880170:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/050558.031724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 766, 7fec614ba8db
[1:1:0712/050558.050277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"474 0x7fec5eb75070 0x1f5522077060 ","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050558.050484:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"474 0x7fec5eb75070 0x1f5522077060 ","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050558.050736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 1326
[1:1:0712/050558.050858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7fec5eb75070 0x1f552335c2e0 , 6:3_https://www.happigo.com/, 0, , 766 0x7fec5eb75070 0x1f552295d760 
[1:1:0712/050558.051052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.happigo.com/"
[1:1:0712/050558.051338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , (){0!=(Pt.flags&jt)&&Pt.before(this,t);try{var n=e.apply(this,arguments)}catch(r){throw 0!=(Pt.flags
[1:1:0712/050558.051477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050558.052091:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 213, 7fec614ba8db
[1:1:0712/050558.070193:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f386f7a2860","ptid":"152","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050558.070373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.happigo.com/","ptid":"152","rf":"6:3_https://www.happigo.com/"}
[1:1:0712/050558.070613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.happigo.com/, 1327
[1:1:0712/050558.070728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7fec5eb75070 0x1f5522fbb9e0 , 6:3_https://www.happigo.com/, 0, , 213 0x7fec5eb75070 0x1f55218b5460 
[1:1:0712/050558.070895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.happigo.com/"
[1:1:0712/050558.071164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , (){0!=(Pt.flags&jt)&&Pt.before(this,t);try{var n=e.apply(this,arguments)}catch(r){throw 0!=(Pt.flags
[1:1:0712/050558.071266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050559.397975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , document.readyState
[1:1:0712/050559.398173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/050607.372657:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/050607.372889:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.happigo.com/"
[1:1:0712/050607.374130:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7fec5eb75070 0x1f5522fdc1e0 , "https://www.happigo.com/"
[1:1:0712/050607.375825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.happigo.com/, 1f386f7a2860, , , 
$("#every_day_ajax").click(function(){
    var data_page = $("#every_day_ajax").attr("data-every-pa
[1:1:0712/050607.376048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.happigo.com/", "www.happigo.com", 3, 1, , , 0
[1:1:0712/050607.538485:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.165476, 896, 1
[1:1:0712/050607.538671:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
