[0711/224236.955690:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/224236.955988:INFO:switcher_clone.cc(787)] backtrace rip is 7f5273389891
[0711/224238.025492:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/224238.025810:INFO:switcher_clone.cc(787)] backtrace rip is 7f2e46204891
[1:1:0711/224238.029919:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/224238.030109:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/224238.035385:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[29192:29192:0711/224239.137524:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/154d884c-3696-4fea-aed3-de6bc017887e
[29192:29192:0711/224239.564485:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[29192:29221:0711/224239.565220:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/224239.565452:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/224239.565704:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/224239.566305:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/224239.566459:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/224239.568877:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c327b26, 1
[1:1:0711/224239.569258:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3434411a, 0
[1:1:0711/224239.569479:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x86240c5, 3
[1:1:0711/224239.569707:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x21a31753, 2
[1:1:0711/224239.569953:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1a413434 267b323c 5317ffffffa321 ffffffc5406208 , 10104, 4
[1:1:0711/224239.570866:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[29192:29221:0711/224239.571148:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGA44&{2<S�!�@b��x+
[29192:29221:0711/224239.571220:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is A44&{2<S�!�@b����x+
[1:1:0711/224239.571115:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e4443f0a0, 3
[29192:29221:0711/224239.571627:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/224239.571395:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e445ca080, 2
[29192:29221:0711/224239.571703:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29236, 4, 1a413434 267b323c 5317a321 c5406208 
[1:1:0711/224239.571778:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e2e28dd20, -2
[1:1:0711/224239.583575:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/224239.584494:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 21a31753
[1:1:0711/224239.585445:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 21a31753
[1:1:0711/224239.587014:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 21a31753
[1:1:0711/224239.588539:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.588761:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.588979:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.589215:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.589876:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 21a31753
[1:1:0711/224239.590258:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e462047ba
[1:1:0711/224239.590430:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e461fbdef, 7f2e4620477a, 7f2e462060cf
[0711/224239.591973:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/224239.592402:INFO:switcher_clone.cc(787)] backtrace rip is 7f0353bcf891
[1:1:0711/224239.596087:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 21a31753
[1:1:0711/224239.596521:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 21a31753
[1:1:0711/224239.597296:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 21a31753
[1:1:0711/224239.599334:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.599580:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.599873:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.600145:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 21a31753
[1:1:0711/224239.601423:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 21a31753
[1:1:0711/224239.601812:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e462047ba
[1:1:0711/224239.601979:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e461fbdef, 7f2e4620477a, 7f2e462060cf
[1:1:0711/224239.609963:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/224239.610479:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/224239.610663:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffded9bc8b8, 0x7ffded9bc838)
[1:1:0711/224239.627730:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/224239.634169:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[29223:29223:0711/224239.833914:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=29223
[29250:29250:0711/224239.835785:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=29250
[29192:29192:0711/224240.162038:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29192:29192:0711/224240.163592:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29192:29202:0711/224240.167427:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[29192:29192:0711/224240.167574:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[29192:29202:0711/224240.167540:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[29192:29192:0711/224240.167619:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[29192:29192:0711/224240.167689:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,29236, 4
[1:7:0711/224240.178690:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[29192:29213:0711/224240.242607:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/224240.296162:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xca46a6cc220
[1:1:0711/224240.296516:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/224240.575038:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[29192:29192:0711/224241.919526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[29192:29192:0711/224241.919703:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/224241.924162:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224241.927980:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/224242.851080:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224242.904139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/224242.904436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224242.920494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/224242.920788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224243.165081:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224243.165364:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224243.580417:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224243.589124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/224243.589423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224243.611961:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224243.624301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/224243.624566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224243.636963:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[29192:29192:0711/224243.640906:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/224243.642440:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xca46a6cae20
[1:1:0711/224243.642667:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[29192:29192:0711/224243.653502:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[29192:29192:0711/224243.674980:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[29192:29192:0711/224243.675193:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/224243.702817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224244.234536:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f2e2fe682e0 0xca46a6dad60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224244.235905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/224244.236124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224244.237637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[29192:29192:0711/224244.307456:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/224244.306735:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xca46a6cb820
[1:1:0711/224244.308358:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[29192:29192:0711/224244.314113:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/224244.327038:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/224244.327183:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[29192:29192:0711/224244.334769:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[29192:29192:0711/224244.346433:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29192:29192:0711/224244.347512:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29192:29202:0711/224244.353594:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[29192:29202:0711/224244.353688:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[29192:29192:0711/224244.353835:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[29192:29192:0711/224244.353912:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[29192:29192:0711/224244.354049:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,29236, 4
[1:7:0711/224244.358415:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/224244.999724:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/224245.250941:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f2e2fe682e0 0xca46a766ce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224245.251987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/224245.252480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224245.253256:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[29192:29192:0711/224245.442465:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[29192:29192:0711/224245.442651:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/224245.459460:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/224245.665309:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224245.971622:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224245.971904:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224246.177639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224246.181140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/224246.181435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224246.189103:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224246.241806:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224246.243330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/224246.243983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/224246.346667:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224246.348075:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/224246.348280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/224246.348565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224246.514765:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224246.515647:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/224246.515935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/224246.516228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224246.940154:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0711/224247.124992:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gmx.net/"
[1:1:0711/224247.293821:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/224247.486770:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/224247.555060:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/224247.664183:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/224247.719535:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/224247.778262:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[29192:29192:0711/224247.854354:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[29192:29221:0711/224247.854609:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/224247.854782:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/224247.854993:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/224247.855418:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/224247.855559:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/224247.859146:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x198a505e, 1
[1:1:0711/224247.859551:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1de44d15, 0
[1:1:0711/224247.859752:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x9accaa8, 3
[1:1:0711/224247.859947:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x190d8b5e, 2
[1:1:0711/224247.860173:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 154dffffffe41d 5e50ffffff8a19 5effffff8b0d19 ffffffa8ffffffcaffffffac09 , 10104, 5
[1:1:0711/224247.861203:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[29192:29221:0711/224247.861488:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGM�^P�^��ʬ	��x+
[29192:29221:0711/224247.861570:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is M�^P�^��ʬ	��x+
[1:1:0711/224247.861483:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e4443f0a0, 3
[29192:29221:0711/224247.861944:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29290, 5, 154de41d 5e508a19 5e8b0d19 a8caac09 
[1:1:0711/224247.861726:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e445ca080, 2
[1:1:0711/224247.862154:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e2e28dd20, -2
[1:1:0711/224247.877920:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/224247.878369:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 190d8b5e
[1:1:0711/224247.878743:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 190d8b5e
[1:1:0711/224247.879482:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 190d8b5e
[1:1:0711/224247.881198:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.881421:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.881634:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.881847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.882270:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 190d8b5e
[1:1:0711/224247.882449:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e462047ba
[1:1:0711/224247.882554:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e461fbdef, 7f2e4620477a, 7f2e462060cf
[1:1:0711/224247.884865:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 190d8b5e
[1:1:0711/224247.885061:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 190d8b5e
[1:1:0711/224247.885329:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 190d8b5e
[1:1:0711/224247.885973:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.886120:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.886221:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.886316:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 190d8b5e
[1:1:0711/224247.886807:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 190d8b5e
[1:1:0711/224247.886964:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e462047ba
[1:1:0711/224247.887037:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e461fbdef, 7f2e4620477a, 7f2e462060cf
[1:1:0711/224247.889246:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/224247.889554:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/224247.889640:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffded9bc8b8, 0x7ffded9bc838)
[1:1:0711/224247.903735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224247.904775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224247.905234:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/224247.905070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224247.909496:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/224247.963673:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224247.964636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224247.964917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.047057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.047973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224248.048297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.065218:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xca46a692220
[1:1:0711/224248.065499:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/224248.141299:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.142245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224248.142518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.259628:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.260587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224248.260869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.392955:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.393952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224248.394250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.508059:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.509058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224248.509355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.624482:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.625484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224248.625756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.673584:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.674531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224248.674802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.760483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.761452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224248.761766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.814801:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.815757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224248.816065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.902341:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.903300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224248.903570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224248.962846:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224248.963800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224248.964120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224249.050202:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224249.051198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224249.051487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224249.113431:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224249.114395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/224249.114666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/224249.201072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/224249.202017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1703432509f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/224249.202287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[29192:29192:0711/224249.494533:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29192:29192:0711/224249.502846:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29192:29202:0711/224249.533488:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[29192:29202:0711/224249.533589:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[29192:29192:0711/224249.533979:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://auto.365jia.cn/
[29192:29192:0711/224249.534056:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://auto.365jia.cn/, http://auto.365jia.cn/, 1
[29192:29192:0711/224249.534178:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://auto.365jia.cn/, HTTP/1.1 200 OK Server: Tengine Content-Type: text/html; charset=utf-8 Content-Length: 14950 Connection: keep-alive Date: Fri, 12 Jul 2019 03:46:19 GMT X-Powered-By: PHP/5.6.36 Cache-Control: public, max-age=7200 Expires: Fri, 12 Jul 2019 05:46:19 GMT Last-Modified: Fri, 12 Jul 2019 03:46:19 GMT Pragma: public Etag: W/"2171cd217ace23217167f55914168cdb" Content-Encoding: gzip Ali-Swift-Global-Savetime: 1562903179 Via: cache13.l2nu20-3[109,200-0,M], cache26.l2nu20-3[111,0], kunlun1.cn1478[0,200-0,H], kunlun7.cn1478[1,0] Age: 6990 X-Cache: HIT TCP_HIT dirn:0:382519943 X-Swift-SaveTime: Fri, 12 Jul 2019 03:46:19 GMT X-Swift-CacheTime: 7200 Timing-Allow-Origin: * EagleId: 70366c1b15629101696321168e  ,29290, 5
[1:7:0711/224249.538869:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/224249.589487:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://auto.365jia.cn/
[1:1:0711/224249.693322:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/224249.714998:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/224249.716700:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:1_chrome-search://local-ntp/, 4:4_chrome-search://most-visited/
[1:1:0711/224249.717000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 170343121f78, , handlePostMessage, (event) {
  var cmd = event.data.cmd;
  var args = event.data;
  if (cmd === 'loaded') {
    tilesAr
[1:1:0711/224249.717288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[29192:29192:0711/224249.726012:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://auto.365jia.cn/, http://auto.365jia.cn/, 1
[29192:29192:0711/224249.726095:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://auto.365jia.cn/, http://auto.365jia.cn
[1:1:0711/224249.765063:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224249.840335:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/224249.932948:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224249.933217:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://auto.365jia.cn/"
[1:1:0711/224250.303997:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224250.701367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f2e2e2a8bd0 0xca46a7b86d8 , "http://auto.365jia.cn/"
[1:1:0711/224250.708272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , /*! jQuery v1.8.2 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};retu
[1:1:0711/224250.708505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224250.709990:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_3a13f6ab -> 0
[1:1:0711/224250.862347:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f2e2e2a8bd0 0xca46a7b86d8 , "http://auto.365jia.cn/"
[1:1:0711/224250.873605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f2e2e2a8bd0 0xca46a7b86d8 , "http://auto.365jia.cn/"
[1:1:0711/224252.104608:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.24369, 0, 0
[1:1:0711/224252.104892:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224252.197970:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224252.198189:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://auto.365jia.cn/"
[1:1:0711/224252.199531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f2e2df40070 0xca46a7b0e60 , "http://auto.365jia.cn/"
[1:1:0711/224252.200018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , if (typeof jQuery === "undefined") {
    document.write('<script type="text/javascript" src="/js/jQu
[1:1:0711/224252.200220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224252.202234:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f2e2df40070 0xca46a7b0e60 , "http://auto.365jia.cn/"
[1:1:0711/224252.231430:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f2e2df40070 0xca46a7b0e60 , "http://auto.365jia.cn/"
[1:1:0711/224252.239992:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f2e2df40070 0xca46a7b0e60 , "http://auto.365jia.cn/"
[1:1:0711/224252.320698:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f2e2df40070 0xca46a7b0e60 , "http://auto.365jia.cn/"
[1:1:0711/224252.337597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 222 0x7f2e2df40070 0xca46a7b0e60 , "http://auto.365jia.cn/"
[1:1:0711/224252.512344:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.314156, 810, 1
[1:1:0711/224252.512520:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224253.700526:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224253.700798:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://auto.365jia.cn/"
[1:1:0711/224253.701764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f2e2df40070 0xca46ad3e3e0 , "http://auto.365jia.cn/"
[1:1:0711/224253.702803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , BAIDU_CLB_fillSlot(6132827);
[1:1:0711/224253.703021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224257.726225:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224257.726701:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224257.727046:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224257.727463:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224257.727854:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[29192:29192:0711/224301.835615:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/224301.886068:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[29192:29192:0711/224301.898935:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132827&dri=0&dis=0&dai=0&ps=45x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=424&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910174, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224301.905479:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132827&dri=0&dis=0&dai=0&ps=45x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=424&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910174, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224302.829372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/224302.829681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224303.357888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392, "http://auto.365jia.cn/"
[1:1:0711/224303.359194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "71331225326c7f14","tuid" : "6132827_0","placement" : {"basic" : {"sspId
[1:1:0711/224303.359451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224303.375020:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392, "http://auto.365jia.cn/"
[1:1:0711/224303.399062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392, "http://auto.365jia.cn/"
[29192:29192:0711/224303.498314:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132828&dri=0&dis=0&dai=0&ps=50x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=424&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910183, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224303.507950:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132828&dri=0&dis=0&dai=0&ps=50x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=424&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910183, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224304.664943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224304.665224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224305.150021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478, "http://auto.365jia.cn/"
[1:1:0711/224305.150773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "bf980a34030cb97e","tuid" : "6132828_0","placement" : {"basic" : {"sspId
[1:1:0711/224305.150885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224305.157551:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478, "http://auto.365jia.cn/"
[1:1:0711/224305.170096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478, "http://auto.365jia.cn/"
[29192:29192:0711/224305.261802:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132829&dri=0&dis=0&dai=0&ps=55x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=424&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910185, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224305.270969:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132829&dri=0&dis=0&dai=0&ps=55x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=424&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910185, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224305.584723:WARNING:one_google_bar_fetcher_impl.cc(315)] Request failed with error: -102: net::ERR_CONNECTION_REFUSED
[1:1:0711/224306.135974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224306.136290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224306.921863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "http://auto.365jia.cn/"
[1:1:0711/224306.923408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "edcee5cb78124a0a","tuid" : "6132829_0","placement" : {"basic" : {"sspId
[1:1:0711/224306.924266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224306.939298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "http://auto.365jia.cn/"
[1:1:0711/224306.969614:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0312412, 128, 1
[1:1:0711/224306.969784:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224307.117407:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 576 0x7f2e2fe682e0 0xca46b2a9ee0 , "http://auto.365jia.cn/"
[1:1:0711/224307.121191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (function(){var h={},mt={},c={id:"26095012d467586b2d582e39b320fb1a",dm:["365jia.cn"],js:"tongji.baid
[1:1:0711/224307.121322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224307.147284:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276948
[1:1:0711/224307.147531:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224307.147857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 627
[1:1:0711/224307.148047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f2e2df40070 0xca46a579de0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 576 0x7f2e2fe682e0 0xca46b2a9ee0 
[1:1:0711/224307.484737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224307.485002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224308.117004:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224308.117259:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://auto.365jia.cn/"
[1:1:0711/224308.118159:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 615 0x7f2e2df40070 0xca46accec60 , "http://auto.365jia.cn/"
[1:1:0711/224308.118986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , BAIDU_CLB_fillSlot(6134097);
[1:1:0711/224308.119199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[29192:29192:0711/224308.218208:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6134097&dri=0&dis=0&dai=0&ps=141x902&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x502&pss=1200x502&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910188, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224308.223728:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6134097&dri=0&dis=0&dai=0&ps=141x902&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1040x502&pss=1200x502&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910188, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224308.719919:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 627, 7f2e30885881
[1:1:0711/224308.732281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"576 0x7f2e2fe682e0 0xca46b2a9ee0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224308.732656:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"576 0x7f2e2fe682e0 0xca46b2a9ee0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224308.733328:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224308.733946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224308.734920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224308.736057:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224308.736262:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224308.736616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 672
[1:1:0711/224308.736872:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7f2e2df40070 0xca46b2a9560 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 627 0x7f2e2df40070 0xca46a579de0 
[1:1:0711/224308.827249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224308.827535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224309.098853:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669, "http://auto.365jia.cn/"
[1:1:0711/224309.100082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "22ec206cc37bf78d","tuid" : "6134097_0","placement" : {"basic" : {"sspId
[1:1:0711/224309.100333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224309.115994:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669, "http://auto.365jia.cn/"
[1:1:0711/224309.138758:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669, "http://auto.365jia.cn/"
[29192:29192:0711/224309.364598:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6134098&dri=0&dis=0&dai=0&ps=523x902&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x537&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910189, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224309.376336:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6134098&dri=0&dis=0&dai=0&ps=523x902&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x537&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910189, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224309.464291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224309.464579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224309.491752:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 672, 7f2e30885881
[1:1:0711/224309.522214:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"627 0x7f2e2df40070 0xca46a579de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224309.522571:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"627 0x7f2e2df40070 0xca46a579de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224309.522952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224309.523490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224309.523759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224309.524848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224309.525070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224309.525448:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 707
[1:1:0711/224309.525862:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f2e2df40070 0xca46acbbf60 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 672 0x7f2e2df40070 0xca46b2a9560 
[1:1:0711/224310.303491:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://auto.365jia.cn/"
[1:1:0711/224310.305486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/224310.305722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224310.381377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 705, "http://auto.365jia.cn/"
[1:1:0711/224310.382673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "ea58f1a0c319f037","tuid" : "6134098_0","placement" : {"basic" : {"sspId
[1:1:0711/224310.382900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224310.398035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 705, "http://auto.365jia.cn/"
[1:1:0711/224310.483128:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.086081, 416, 1
[1:1:0711/224310.483398:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224310.522190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224310.522487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224310.525604:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 707, 7f2e30885881
[1:1:0711/224310.555228:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"672 0x7f2e2df40070 0xca46b2a9560 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224310.555584:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"672 0x7f2e2df40070 0xca46b2a9560 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224310.556015:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224310.556569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224310.556777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224310.557433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224310.557632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224310.557974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 751
[1:1:0711/224310.558199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7f2e2df40070 0xca46a803e60 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 707 0x7f2e2df40070 0xca46acbbf60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224311.602766:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224311.603029:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://auto.365jia.cn/"
[1:1:0711/224311.603980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 746 0x7f2e2df40070 0xca46ad25c60 , "http://auto.365jia.cn/"
[1:1:0711/224311.604788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , BAIDU_CLB_fillSlot(6136948);
[1:1:0711/224311.604999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[29192:29192:0711/224311.695894:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136948&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910192, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224311.709740:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136948&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910192, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224311.853978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224311.854254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224311.857384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 751, 7f2e30885881
[1:1:0711/224311.889124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"707 0x7f2e2df40070 0xca46acbbf60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224311.889467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"707 0x7f2e2df40070 0xca46acbbf60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224311.889867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224311.890402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224311.890626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224311.891266:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224311.891456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224311.891845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 781
[1:1:0711/224311.892093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7f2e2df40070 0xca46ad21de0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 751 0x7f2e2df40070 0xca46a803e60 
[1:1:0711/224312.459106:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777, "http://auto.365jia.cn/"
[1:1:0711/224312.460478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "71ea49013e318d66","tuid" : "6136948_0","placement" : {"basic" : {"sspId
[1:1:0711/224312.460820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224312.475301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777, "http://auto.365jia.cn/"
[1:1:0711/224312.490515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777, "http://auto.365jia.cn/"
[1:1:0711/224312.524969:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/224312.525441:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[29192:29192:0711/224312.568585:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136952&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910193, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224312.577736:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136952&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910193, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224312.602898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224312.603163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224312.665847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 781, 7f2e30885881
[1:1:0711/224312.699369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"751 0x7f2e2df40070 0xca46a803e60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224312.699719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"751 0x7f2e2df40070 0xca46a803e60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224312.700142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224312.700683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224312.700897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224312.701540:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224312.701733:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224312.702199:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 804
[1:1:0711/224312.702424:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f2e2df40070 0xca46a579de0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 781 0x7f2e2df40070 0xca46ad21de0 
[1:1:0711/224313.231404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 802, "http://auto.365jia.cn/"
[1:1:0711/224313.232664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "02827b117b04235b","tuid" : "6136952_0","placement" : {"basic" : {"sspId
[1:1:0711/224313.232955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224313.248052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 802, "http://auto.365jia.cn/"
[1:1:0711/224313.263119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 802, "http://auto.365jia.cn/"
[29192:29192:0711/224313.329411:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136953&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910193, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224313.335543:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136953&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910193, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224313.351544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224313.351869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224313.398433:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 804, 7f2e30885881
[1:1:0711/224313.420749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"781 0x7f2e2df40070 0xca46ad21de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224313.421108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"781 0x7f2e2df40070 0xca46ad21de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224313.421531:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224313.422100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224313.422333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224313.422998:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224313.423187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224313.423551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 829
[1:1:0711/224313.423772:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f2e2df40070 0xca46b0c2de0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 804 0x7f2e2df40070 0xca46a579de0 
[1:1:0711/224313.860031:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 826, "http://auto.365jia.cn/"
[1:1:0711/224313.861331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "1275ef7656ae61f1","tuid" : "6136953_0","placement" : {"basic" : {"sspId
[1:1:0711/224313.861525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224313.876364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 826, "http://auto.365jia.cn/"
[1:1:0711/224313.891436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 826, "http://auto.365jia.cn/"
[29192:29192:0711/224313.964283:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136956&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910194, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224313.977036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224313.977242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224313.978562:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 829, 7f2e30885881
[29192:29192:0711/224313.979340:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6136956&dri=0&dis=0&dai=0&ps=1788x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x1802&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910194, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224313.990070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"804 0x7f2e2df40070 0xca46a579de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224313.990242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"804 0x7f2e2df40070 0xca46a579de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224313.990461:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224313.990774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224313.990902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224313.991239:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224313.991342:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224313.991507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 848
[1:1:0711/224313.991615:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 848 0x7f2e2df40070 0xca46acdabe0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 829 0x7f2e2df40070 0xca46b0c2de0 
[1:1:0711/224314.596094:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846, "http://auto.365jia.cn/"
[1:1:0711/224314.597349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "5d99a57b75ab10eb","tuid" : "6136956_0","placement" : {"basic" : {"sspId
[1:1:0711/224314.597537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224314.612421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846, "http://auto.365jia.cn/"
[1:1:0711/224314.633778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846, "http://auto.365jia.cn/"
[1:1:0711/224314.642994:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846, "http://auto.365jia.cn/"
[1:1:0711/224314.652359:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846, "http://auto.365jia.cn/"
[1:1:0711/224314.658715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846, "http://auto.365jia.cn/"
[1:1:0711/224314.691214:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.079859, 135, 1
[1:1:0711/224314.691525:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224314.724806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224314.725142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224314.729002:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 848, 7f2e30885881
[1:1:0711/224314.771558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"829 0x7f2e2df40070 0xca46b0c2de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224314.771871:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"829 0x7f2e2df40070 0xca46b0c2de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224314.772237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224314.772773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224314.772948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224314.773580:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224314.773738:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224314.774083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 886
[1:1:0711/224314.774331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 886 0x7f2e2df40070 0xca46b672860 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 848 0x7f2e2df40070 0xca46acdabe0 
[1:1:0711/224315.627969:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224315.628138:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://auto.365jia.cn/"
[1:1:0711/224315.628633:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 881 0x7f2e2df40070 0xca46b895be0 , "http://auto.365jia.cn/"
[1:1:0711/224315.629104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , BAIDU_CLB_fillSlot(6132823);
[1:1:0711/224315.629226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[29192:29192:0711/224315.894220:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132823&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910196, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224315.908071:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132823&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910196, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224316.164071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224316.164371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224316.167514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 886, 7f2e30885881
[1:1:0711/224316.207502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"848 0x7f2e2df40070 0xca46acdabe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224316.207931:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"848 0x7f2e2df40070 0xca46acdabe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224316.208397:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224316.208967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224316.209184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224316.209869:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224316.210075:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224316.210441:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 916
[1:1:0711/224316.210702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7f2e2df40070 0xca46b8ffa60 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 886 0x7f2e2df40070 0xca46b672860 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224316.431270:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 907, "http://auto.365jia.cn/"
[1:1:0711/224316.432831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "018a215edf07d24e","tuid" : "6132823_0","placement" : {"basic" : {"sspId
[1:1:0711/224316.433118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224316.450976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 907, "http://auto.365jia.cn/"
[1:1:0711/224316.470706:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 907, "http://auto.365jia.cn/"
[29192:29192:0711/224316.568845:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132825&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910197, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224316.583607:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132825&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910197, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224316.800771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224316.801072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224316.827487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 916, 7f2e30885881
[1:1:0711/224316.845888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"886 0x7f2e2df40070 0xca46b672860 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224316.846261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"886 0x7f2e2df40070 0xca46b672860 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224316.846668:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224316.847368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224316.847646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224316.848533:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224316.848800:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224316.849238:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 931
[1:1:0711/224316.849486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7f2e2df40070 0xca46b9349e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 916 0x7f2e2df40070 0xca46b8ffa60 
[1:1:0711/224317.298564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 927, "http://auto.365jia.cn/"
[1:1:0711/224317.299945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "fa8b85fd94a379a8","tuid" : "6132825_0","placement" : {"basic" : {"sspId
[1:1:0711/224317.300187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224317.307055:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 927, "http://auto.365jia.cn/"
[1:1:0711/224317.324282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 927, "http://auto.365jia.cn/"
[29192:29192:0711/224317.396342:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132824&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910197, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224317.414012:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132824&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910197, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224317.481833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224317.482121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224317.526518:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 931, 7f2e30885881
[1:1:0711/224317.566416:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"916 0x7f2e2df40070 0xca46b8ffa60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224317.566769:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"916 0x7f2e2df40070 0xca46b8ffa60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224317.567180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224317.567718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224317.567995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224317.568641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224317.568834:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224317.569213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 950
[1:1:0711/224317.569438:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 950 0x7f2e2df40070 0xca46ae50460 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 931 0x7f2e2df40070 0xca46b9349e0 
[1:1:0711/224318.030463:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 948, "http://auto.365jia.cn/"
[1:1:0711/224318.031731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "96ba96340007b16c","tuid" : "6132824_0","placement" : {"basic" : {"sspId
[1:1:0711/224318.031987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224318.047136:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 948, "http://auto.365jia.cn/"
[1:1:0711/224318.063260:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 948, "http://auto.365jia.cn/"
[29192:29192:0711/224318.132171:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132826&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910198, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[29192:29192:0711/224318.143387:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rcxm?di=6132826&dri=0&dis=0&dai=0&ps=0x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910173920&ti=%E5%AE%89%E5%BE%BD%E6%B1%BD%E8%BD%A6%E7%BD%91-%E5%90%88%E8%82%A5%E6%B1%BD%E8%BD%A6%E7%BD%91-%E4%B8%87%E5%AE%B6%E6%B1%BD%E8%BD%A6%E7%BD%91-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E4%B8%87%E5%AE%B6%E7%83%AD%E7%BA%BF--%E5%AE%89%E5%BE%BD%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1200x2070&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562903179&rw=517&ltu=http%3A%2F%2Fauto.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910198, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/224318.215712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224318.216008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224318.219189:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 950, 7f2e30885881
[1:1:0711/224318.258585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"931 0x7f2e2df40070 0xca46b9349e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224318.258947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"931 0x7f2e2df40070 0xca46b9349e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224318.259337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224318.259883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224318.260165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224318.260811:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224318.261009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224318.261391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 972
[1:1:0711/224318.261617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7f2e2df40070 0xca46b94cc60 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 950 0x7f2e2df40070 0xca46ae50460 
[1:1:0711/224318.876996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224318.877337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224318.925413:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971, "http://auto.365jia.cn/"
[1:1:0711/224318.926620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , ___adblockplus({"queryid" : "988c8f6f6b0ef8d2","tuid" : "6132826_0","placement" : {"basic" : {"sspId
[1:1:0711/224318.926837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224318.942113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971, "http://auto.365jia.cn/"
[1:1:0711/224318.957574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971, "http://auto.365jia.cn/"
[1:1:0711/224318.963606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971, "http://auto.365jia.cn/"
[1:1:0711/224318.974005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971, "http://auto.365jia.cn/"
[1:1:0711/224318.983342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://auto.365jia.cn/"
[1:1:0711/224319.386997:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276a10
[1:1:0711/224319.387275:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224319.387662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1008
[1:1:0711/224319.387924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1008 0x7f2e2df40070 0xca46b8f1ce0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 971
[1:1:0711/224319.439110:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 13
[1:1:0711/224319.439582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1010
[1:1:0711/224319.439844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7f2e2df40070 0xca46ba3e8e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 971
[1:1:0711/224319.490020:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 5000
[1:1:0711/224319.490464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1014
[1:1:0711/224319.490697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7f2e2df40070 0xca46ad0f160 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 971
[29192:29192:0711/224319.582930:INFO:CONSOLE(7)] "141", source: http://auto.365jia.cn/images/jiehun2019/js/scrollTop.js?v=1975 (7)
[29192:29192:0711/224319.811746:INFO:CONSOLE(2)] "Synchronous XMLHttpRequest on the main thread is deprecated because of its detrimental effects to the end user's experience. For more help, check https://xhr.spec.whatwg.org/.", source: http://auto.365jia.cn/js/jQuery/jquery-1.8.2.min.js (2)
[1:1:0711/224319.820045:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:7:0711/224319.826137:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 20
[1:7:0711/224320.113379:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 21
[1:7:0711/224320.115442:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 22
[1:7:0711/224320.117854:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 23
[1:7:0711/224320.216819:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 28
[1:7:0711/224320.911420:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 29
[1:7:0711/224320.913540:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 30
[1:7:0711/224321.051791:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 31
[1:7:0711/224321.052191:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 32
[1:7:0711/224321.689534:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 33
[1:7:0711/224321.689969:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 34
[1:7:0711/224321.690739:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 35
[1:7:0711/224321.693752:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 36
[1:1:0711/224321.986430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x927772229c8, 0xca46a276a10
[1:1:0711/224321.986709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 600
[1:1:0711/224321.987126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1028
[1:1:0711/224321.987376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1028 0x7f2e2df40070 0xca46a7b3560 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 971
[1:1:0711/224321.993519:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 900, 0x927772229c8, 0xca46a276a10
[1:1:0711/224321.993747:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 900
[1:1:0711/224321.994152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1029
[1:1:0711/224321.994391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f2e2df40070 0xca46bc4d8e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 971
[1:1:0711/224321.995615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 850, 0x927772229c8, 0xca46a276a10
[1:1:0711/224321.995841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 850
[1:1:0711/224321.996275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1030
[1:1:0711/224321.996568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f2e2df40070 0xca46b11dbe0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 971
[1:1:0711/224322.151377:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://auto.365jia.cn/"
[1:1:0711/224322.236451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 972, 7f2e30885881
[1:1:0711/224322.267392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"950 0x7f2e2df40070 0xca46ae50460 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224322.267764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"950 0x7f2e2df40070 0xca46ae50460 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224322.268205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224322.268761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224322.268996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224322.269793:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224322.270011:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224322.270370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1057
[1:1:0711/224322.270741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1057 0x7f2e2df40070 0xca46b7b9360 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 972 0x7f2e2df40070 0xca46b94cc60 
[1:1:0711/224322.419687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224322.419995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[29192:29192:0711/224324.007574:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/224324.203965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1008, 7f2e30885881
[1:1:0711/224324.247708:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.248059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.248470:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224324.249015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224324.249251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224324.250856:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1010, 7f2e308858db
[1:1:0711/224324.284393:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.284731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.285143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1097
[1:1:0711/224324.285381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7f2e2df40070 0xca46b0d7760 , 5:3_http://auto.365jia.cn/, 0, , 1010 0x7f2e2df40070 0xca46ba3e8e0 
[1:1:0711/224324.285800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224324.286312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224324.286538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224324.287688:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224324.287933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224324.288280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1098
[1:1:0711/224324.288525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1098 0x7f2e2df40070 0xca46ad037e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1010 0x7f2e2df40070 0xca46ba3e8e0 
[1:1:0711/224324.337870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1057, 7f2e30885881
[1:1:0711/224324.385811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"972 0x7f2e2df40070 0xca46b94cc60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.386555:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"972 0x7f2e2df40070 0xca46b94cc60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.386973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224324.387546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224324.387840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224324.388505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224324.388705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224324.389534:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1105
[1:1:0711/224324.389751:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7f2e2df40070 0xca46acf7be0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1057 0x7f2e2df40070 0xca46b7b9360 
[1:1:0711/224324.544382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224324.544739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224324.730596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1028, 7f2e30885881
[1:1:0711/224324.770633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.770963:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.771364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224324.771954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){    $(".load_more_bg").html('加载更多'); }
[1:1:0711/224324.772182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224324.785635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1030, 7f2e30885881
[1:1:0711/224324.815370:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.815851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.816392:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224324.817076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , () {
         if($(".ads_top_2019_tl").length>0) {
            $(".ads_top_2019_tl").each(function()
[1:1:0711/224324.817279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224324.842632:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1029, 7f2e30885881
[1:1:0711/224324.890474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.890861:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224324.891341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224324.891956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , () {

            insertAdByPos('ads_area_3', 1);  //3
            insertAdByPos('ads_area_6', 4);  
[1:1:0711/224324.892227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224325.749571:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1097, 7f2e308858db
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224325.805253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1010 0x7f2e2df40070 0xca46ba3e8e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224325.805647:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1010 0x7f2e2df40070 0xca46ba3e8e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224325.806276:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1157
[1:1:0711/224325.806577:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1157 0x7f2e2df40070 0xca46ae615e0 , 5:3_http://auto.365jia.cn/, 0, , 1097 0x7f2e2df40070 0xca46b0d7760 
[1:1:0711/224325.807037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224325.807739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224325.808061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224325.813307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1098, 7f2e30885881
[1:1:0711/224325.864060:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1010 0x7f2e2df40070 0xca46ba3e8e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224325.864519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1010 0x7f2e2df40070 0xca46ba3e8e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224325.864999:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224325.865546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224325.865784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224326.159020:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1105, 7f2e30885881
[1:1:0711/224326.185270:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1057 0x7f2e2df40070 0xca46b7b9360 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224326.185642:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1057 0x7f2e2df40070 0xca46b7b9360 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224326.186067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224326.186688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224326.186938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224326.187604:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224326.187818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224326.188197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1178
[1:1:0711/224326.188431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1178 0x7f2e2df40070 0xca46ae8fae0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1105 0x7f2e2df40070 0xca46acf7be0 
[1:1:0711/224326.189884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1014, 7f2e308858db
[1:1:0711/224326.223963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224326.224383:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"971","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224326.224866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1179
[1:1:0711/224326.225183:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1179 0x7f2e2df40070 0xca46b8c3660 , 5:3_http://auto.365jia.cn/, 0, , 1014 0x7f2e2df40070 0xca46ad0f160 
[1:1:0711/224326.225558:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224326.226115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){rules()}
[1:1:0711/224326.226337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224326.264363:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224326.264618:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224326.265124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1182
[1:1:0711/224326.265428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1182 0x7f2e2df40070 0xca46c100fe0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1014 0x7f2e2df40070 0xca46ad0f160 
[1:1:0711/224326.641450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224326.641755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224327.318658:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1157, 7f2e308858db
[1:1:0711/224327.360969:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1097 0x7f2e2df40070 0xca46b0d7760 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224327.361196:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1097 0x7f2e2df40070 0xca46b0d7760 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224327.361465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1225
[1:1:0711/224327.361585:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1225 0x7f2e2df40070 0xca46b9513e0 , 5:3_http://auto.365jia.cn/, 0, , 1157 0x7f2e2df40070 0xca46ae615e0 
[1:1:0711/224327.361781:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224327.362066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224327.362215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224328.229780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1182, 7f2e30885881
[1:1:0711/224328.287769:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1014 0x7f2e2df40070 0xca46ad0f160 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224328.287997:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1014 0x7f2e2df40070 0xca46ad0f160 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224328.288207:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224328.288543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224328.288653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224328.289238:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1178, 7f2e30885881
[1:1:0711/224328.347046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1105 0x7f2e2df40070 0xca46acf7be0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224328.347452:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1105 0x7f2e2df40070 0xca46acf7be0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224328.347912:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224328.348642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224328.348879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224328.349662:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224328.349931:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224328.350349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1251
[1:1:0711/224328.350572:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7f2e2df40070 0xca46c100ce0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1178 0x7f2e2df40070 0xca46ae8fae0 
[1:1:0711/224328.512294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224328.512604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224329.265336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1225, 7f2e308858db
[1:1:0711/224329.331374:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1157 0x7f2e2df40070 0xca46ae615e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224329.331762:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1157 0x7f2e2df40070 0xca46ae615e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224329.332282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1277
[1:1:0711/224329.332532:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1277 0x7f2e2df40070 0xca46c295a60 , 5:3_http://auto.365jia.cn/, 0, , 1225 0x7f2e2df40070 0xca46b9513e0 
[1:1:0711/224329.332981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224329.333659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224329.333886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224329.334846:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224329.335045:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224329.335610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1278
[1:1:0711/224329.335868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1278 0x7f2e2df40070 0xca46c2adc60 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1225 0x7f2e2df40070 0xca46b9513e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224330.179055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1251, 7f2e30885881
[1:1:0711/224330.240794:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1178 0x7f2e2df40070 0xca46ae8fae0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.241219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1178 0x7f2e2df40070 0xca46ae8fae0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.241710:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224330.242344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224330.242570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224330.243366:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224330.243564:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224330.244017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1313
[1:1:0711/224330.244262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1313 0x7f2e2df40070 0xca46c15bbe0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1251 0x7f2e2df40070 0xca46c100ce0 
[1:1:0711/224330.303308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224330.303732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224330.783308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1277, 7f2e308858db
[1:1:0711/224330.806570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1225 0x7f2e2df40070 0xca46b9513e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.806747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1225 0x7f2e2df40070 0xca46b9513e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.806950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1326
[1:1:0711/224330.807199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7f2e2df40070 0xca46a7005e0 , 5:3_http://auto.365jia.cn/, 0, , 1277 0x7f2e2df40070 0xca46c295a60 
[1:1:0711/224330.807632:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224330.808280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224330.808507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224330.848050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1278, 7f2e30885881
[1:1:0711/224330.872295:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1225 0x7f2e2df40070 0xca46b9513e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.872490:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1225 0x7f2e2df40070 0xca46b9513e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.872717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224330.873100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224330.873210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224330.873829:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1179, 7f2e308858db
[1:1:0711/224330.891657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1014 0x7f2e2df40070 0xca46ad0f160 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.891841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1014 0x7f2e2df40070 0xca46ad0f160 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224330.892140:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1328
[1:1:0711/224330.892256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1328 0x7f2e2df40070 0xca46c2c0060 , 5:3_http://auto.365jia.cn/, 0, , 1179 0x7f2e2df40070 0xca46b8c3660 
[1:1:0711/224330.892452:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224330.892724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){rules()}
[1:1:0711/224330.892829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224330.909443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224330.909602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224330.909780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1329
[1:1:0711/224330.909890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f2e2df40070 0xca46c2b21e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1179 0x7f2e2df40070 0xca46b8c3660 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/224331.671473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224331.671716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224331.843008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1313, 7f2e30885881
[1:1:0711/224331.898856:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1251 0x7f2e2df40070 0xca46c100ce0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224331.899162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1251 0x7f2e2df40070 0xca46c100ce0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224331.899540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224331.900035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224331.900207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224331.900852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224331.901006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224331.901350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1353
[1:1:0711/224331.901539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7f2e2df40070 0xca46c2a5a60 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1313 0x7f2e2df40070 0xca46c15bbe0 
[1:1:0711/224332.162187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1326, 7f2e308858db
[1:1:0711/224332.215816:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1277 0x7f2e2df40070 0xca46c295a60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224332.216100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1277 0x7f2e2df40070 0xca46c295a60 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224332.216528:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1362
[1:1:0711/224332.216725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1362 0x7f2e2df40070 0xca46c3b6360 , 5:3_http://auto.365jia.cn/, 0, , 1326 0x7f2e2df40070 0xca46a7005e0 
[1:1:0711/224332.217052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224332.217542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224332.217718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224332.224960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1329, 7f2e30885881
[1:1:0711/224332.280887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1179 0x7f2e2df40070 0xca46b8c3660 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224332.281274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1179 0x7f2e2df40070 0xca46b8c3660 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224332.281722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224332.282318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224332.282535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224332.347839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://auto.365jia.cn/"
[1:1:0711/224332.348680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , ready, (a){if(a===!0?--p.readyWait:p.isReady)return;if(!e.body)return setTimeout(p.ready,1);p.isReady=!0;if
[1:1:0711/224332.348912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224332.349414:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://auto.365jia.cn/"
[29192:29192:0711/224332.362311:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/224332.362988:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xca46b9a1820
[1:1:0711/224332.363181:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[29192:29192:0711/224332.372511:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0711/224332.380678:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/224332.380827:INFO:render_frame_impl.cc(7019)] 	 [url] = http://auto.365jia.cn
[1:1:0711/224332.381661:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://auto.365jia.cn/"
[1:1:0711/224332.382527:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://auto.365jia.cn/"
[1:1:0711/224332.383197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276af0
[1:1:0711/224332.383310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224332.383494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1377
[1:1:0711/224332.383605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1377 0x7f2e2df40070 0xca46c292560 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1335 0x7f2e2df40070 0xca46c2b2de0 
[29192:29192:0711/224332.386044:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://auto.365jia.cn/
[29192:29192:0711/224332.399703:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29192:29192:0711/224332.403034:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29192:29202:0711/224332.411867:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[29192:29192:0711/224332.411909:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[29192:29192:0711/224332.411949:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/wh/o.htm?ltr=, 4
[29192:29202:0711/224332.411957:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[29192:29192:0711/224332.412005:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://pos.baidu.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 04:31:46 GMT Last-Modified: Wed, 10 Jul 2019 09:58:10 GMT P3p: CP=" OTI DSP COR IVA OUR IND COM " Server: nginx Accept-Ranges: bytes Content-Length: 553 Content-Type: text/html Etag: "5d25b6b2-229"  ,29290, 5
[1:7:0711/224332.415367:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/224332.833881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , document.readyState
[1:1:0711/224332.834165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224332.983871:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1362, 7f2e308858db
[1:1:0711/224333.001798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1326 0x7f2e2df40070 0xca46a7005e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.001978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1326 0x7f2e2df40070 0xca46a7005e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.002192:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1400
[1:1:0711/224333.002305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1400 0x7f2e2df40070 0xca46c1121e0 , 5:3_http://auto.365jia.cn/, 0, , 1362 0x7f2e2df40070 0xca46c3b6360 
[1:1:0711/224333.002512:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224333.002795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224333.002908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224333.003235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224333.003332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224333.003515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1401
[1:1:0711/224333.003627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1401 0x7f2e2df40070 0xca46c4396e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1362 0x7f2e2df40070 0xca46c3b6360 
[1:1:0711/224333.475369:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://pos.baidu.com/
[1:1:0711/224333.500334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1377, 7f2e30885881
[1:1:0711/224333.520821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1335 0x7f2e2df40070 0xca46c2b2de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.521016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1335 0x7f2e2df40070 0xca46c2b2de0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.521215:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224333.521521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224333.521646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224333.521944:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224333.522040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224333.522208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1411
[1:1:0711/224333.522313:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1411 0x7f2e2df40070 0xca46c2b5fe0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1377 0x7f2e2df40070 0xca46c292560 
[1:1:0711/224333.899495:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1401, 7f2e30885881
[1:1:0711/224333.925501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1362 0x7f2e2df40070 0xca46c3b6360 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.925956:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1362 0x7f2e2df40070 0xca46c3b6360 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.926338:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224333.926840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224333.927059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224333.963548:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1400, 7f2e308858db
[1:1:0711/224333.987206:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1362 0x7f2e2df40070 0xca46c3b6360 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.987467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1362 0x7f2e2df40070 0xca46c3b6360 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224333.987829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1425
[1:1:0711/224333.988003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7f2e2df40070 0xca46c425fe0 , 5:3_http://auto.365jia.cn/, 0, , 1400 0x7f2e2df40070 0xca46c1121e0 
[1:1:0711/224333.988283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224333.988677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224333.988848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224333.989371:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224333.989516:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224333.989773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1426
[1:1:0711/224333.989927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1426 0x7f2e2df40070 0xca46c4514e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1400 0x7f2e2df40070 0xca46c1121e0 
[1:1:0711/224334.174965:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[29192:29192:0711/224334.180680:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/, 4
[29192:29192:0711/224334.180780:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0711/224334.180755:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1411, 7f2e30885881
[1:1:0711/224334.241975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1377 0x7f2e2df40070 0xca46c292560 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224334.242414:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1377 0x7f2e2df40070 0xca46c292560 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224334.242961:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224334.243648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224334.243942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224334.244623:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224334.244834:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224334.245163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1444
[1:1:0711/224334.245355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1444 0x7f2e2df40070 0xca46b8953e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1411 0x7f2e2df40070 0xca46c2b5fe0 
[1:1:0711/224334.791386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1426, 7f2e30885881
[1:1:0711/224334.848930:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1400 0x7f2e2df40070 0xca46c1121e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224334.849236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1400 0x7f2e2df40070 0xca46c1121e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224334.849618:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224334.850116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224334.850303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224335.007965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1425, 7f2e308858db
[1:1:0711/224335.027456:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1400 0x7f2e2df40070 0xca46c1121e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224335.027635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1400 0x7f2e2df40070 0xca46c1121e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224335.027887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1470
[1:1:0711/224335.028030:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1470 0x7f2e2df40070 0xca46c3bd2e0 , 5:3_http://auto.365jia.cn/, 0, , 1425 0x7f2e2df40070 0xca46c425fe0 
[1:1:0711/224335.028221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224335.028510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224335.028613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224335.028961:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224335.029073:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224335.029233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1471
[1:1:0711/224335.029341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1471 0x7f2e2df40070 0xca46c483960 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1425 0x7f2e2df40070 0xca46c425fe0 
[1:1:0711/224335.089128:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/224335.473295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1444, 7f2e30885881
[1:1:0711/224335.531615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1411 0x7f2e2df40070 0xca46c2b5fe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224335.531922:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1411 0x7f2e2df40070 0xca46c2b5fe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224335.532321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224335.532823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224335.532997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224335.533636:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224335.533792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224335.534127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1481
[1:1:0711/224335.534318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1481 0x7f2e2df40070 0xca46c452ee0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1444 0x7f2e2df40070 0xca46b8953e0 
[1:1:0711/224335.535820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1328, 7f2e308858db
[1:1:0711/224335.594680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1179 0x7f2e2df40070 0xca46b8c3660 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224335.594953:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1179 0x7f2e2df40070 0xca46b8c3660 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224335.595383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1483
[1:1:0711/224335.595576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1483 0x7f2e2df40070 0xca46c2c2460 , 5:3_http://auto.365jia.cn/, 0, , 1328 0x7f2e2df40070 0xca46c2c0060 
[1:1:0711/224335.595896:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224335.596393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){rules()}
[1:1:0711/224335.596566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224336.200829:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1471, 7f2e30885881
[1:1:0711/224336.265582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1425 0x7f2e2df40070 0xca46c425fe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224336.265970:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1425 0x7f2e2df40070 0xca46c425fe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224336.266431:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224336.267032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224336.267272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224336.428837:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1470, 7f2e308858db
[1:1:0711/224336.488466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1425 0x7f2e2df40070 0xca46c425fe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224336.488652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1425 0x7f2e2df40070 0xca46c425fe0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224336.488886:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1506
[1:1:0711/224336.489013:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1506 0x7f2e2df40070 0xca46c459e60 , 5:3_http://auto.365jia.cn/, 0, , 1470 0x7f2e2df40070 0xca46c3bd2e0 
[1:1:0711/224336.489205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224336.489547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224336.489657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224336.489987:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224336.490086:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224336.490243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1507
[1:1:0711/224336.490367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1507 0x7f2e2df40070 0xca46c3b6260 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1470 0x7f2e2df40070 0xca46c3bd2e0 
[1:1:0711/224336.566594:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/224336.566810:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0711/224336.697805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1481, 7f2e30885881
[1:1:0711/224336.737656:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1444 0x7f2e2df40070 0xca46b8953e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224336.737845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1444 0x7f2e2df40070 0xca46b8953e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224336.738069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224336.738398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/224336.738506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224336.738805:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x927772229c8, 0xca46a276950
[1:1:0711/224336.738902:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 100
[1:1:0711/224336.739068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1523
[1:1:0711/224336.739173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1523 0x7f2e2df40070 0xca46c56c5e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1481 0x7f2e2df40070 0xca46c452ee0 
[1:1:0711/224337.228874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1507, 7f2e30885881
[1:1:0711/224337.299480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"122e021c2860","ptid":"1470 0x7f2e2df40070 0xca46c3bd2e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224337.299882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://auto.365jia.cn/","ptid":"1470 0x7f2e2df40070 0xca46c3bd2e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224337.300405:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224337.301053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , , (){cN=b}
[1:1:0711/224337.301278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224337.303144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1506, 7f2e308858db
[1:1:0711/224337.356938:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1470 0x7f2e2df40070 0xca46c3bd2e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224337.357256:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1470 0x7f2e2df40070 0xca46c3bd2e0 ","rf":"5:3_http://auto.365jia.cn/"}
[1:1:0711/224337.357667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://auto.365jia.cn/, 1542
[1:1:0711/224337.357856:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1542 0x7f2e2df40070 0xca46c587060 , 5:3_http://auto.365jia.cn/, 0, , 1506 0x7f2e2df40070 0xca46c459e60 
[1:1:0711/224337.358191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://auto.365jia.cn/"
[1:1:0711/224337.358727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://auto.365jia.cn/, 122e021c2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0711/224337.358901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://auto.365jia.cn/", "auto.365jia.cn", 3, 1, , , 0
[1:1:0711/224337.359682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x927772229c8, 0xca46a276950
[1:1:0711/224337.359838:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://auto.365jia.cn/", 0
[1:1:0711/224337.360150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://auto.365jia.cn/, 1543
[1:1:0711/224337.360331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1543 0x7f2e2df40070 0xca46c5911e0 , 5:3_http://auto.365jia.cn/, 1, -5:3_http://auto.365jia.cn/, 1506 0x7f2e2df40070 0xca46c459e60 
