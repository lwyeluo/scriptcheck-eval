[0711/225326.627745:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/225326.628168:INFO:switcher_clone.cc(787)] backtrace rip is 7fb6efdee891
[0711/225327.618051:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/225327.618548:INFO:switcher_clone.cc(787)] backtrace rip is 7fbb4a3f7891
[1:1:0711/225327.632770:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/225327.633106:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/225327.638415:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[30719:30719:0711/225328.764460:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/fc8777df-363c-4600-9862-7082d2c40762
[0711/225329.143719:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/225329.144128:INFO:switcher_clone.cc(787)] backtrace rip is 7fc1117a7891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[30719:30719:0711/225329.381132:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[30719:30750:0711/225329.382031:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/225329.382271:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/225329.382522:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/225329.383242:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/225329.383432:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/225329.386750:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x17f81620, 1
[1:1:0711/225329.387123:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3bea6141, 0
[1:1:0711/225329.387314:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3ff9381c, 3
[1:1:0711/225329.387507:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x29c7631d, 2
[1:1:0711/225329.387728:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4161ffffffea3b 2016fffffff817 1d63ffffffc729 1c38fffffff93f , 10104, 4
[1:1:0711/225329.388759:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30719:30750:0711/225329.389025:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGAa�; �c�)8�?7��%
[30719:30750:0711/225329.389111:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Aa�; �c�)8�?��7��%
[30719:30750:0711/225329.389416:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/225329.389229:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbb486320a0, 3
[30719:30750:0711/225329.389481:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30764, 4, 4161ea3b 2016f817 1d63c729 1c38f93f 
[1:1:0711/225329.389539:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbb487bd080, 2
[1:1:0711/225329.389694:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbb32480d20, -2
[30753:30753:0711/225329.391447:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30753
[30765:30765:0711/225329.391830:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30765
[1:1:0711/225329.402379:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/225329.403007:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 29c7631d
[1:1:0711/225329.403667:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 29c7631d
[1:1:0711/225329.404749:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 29c7631d
[1:1:0711/225329.405299:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.405405:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.405502:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.405602:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.405823:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 29c7631d
[1:1:0711/225329.405992:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbb4a3f77ba
[1:1:0711/225329.406082:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbb4a3eedef, 7fbb4a3f777a, 7fbb4a3f90cf
[1:1:0711/225329.408268:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 29c7631d
[1:1:0711/225329.408432:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 29c7631d
[1:1:0711/225329.408700:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 29c7631d
[1:1:0711/225329.409392:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.409509:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.409606:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.409706:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29c7631d
[1:1:0711/225329.410186:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 29c7631d
[1:1:0711/225329.410348:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbb4a3f77ba
[1:1:0711/225329.410423:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbb4a3eedef, 7fbb4a3f777a, 7fbb4a3f90cf
[1:1:0711/225329.412605:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/225329.412837:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/225329.412961:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff47dd8068, 0x7fff47dd7fe8)
[1:1:0711/225329.422726:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/225329.429948:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[30719:30741:0711/225330.069648:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[30719:30719:0711/225330.104414:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30719:30719:0711/225330.106505:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30719:30719:0711/225330.109784:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[30719:30730:0711/225330.109759:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[30719:30719:0711/225330.109827:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[30719:30719:0711/225330.109885:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,30764, 4
[30719:30730:0711/225330.109882:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/225330.111872:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/225330.138865:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x98a1986220
[1:1:0711/225330.139012:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/225330.450950:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[30719:30719:0711/225331.651355:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[30719:30719:0711/225331.651519:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/225331.666153:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225331.667936:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/225332.178600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c2146c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/225332.178793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/225332.183889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c2146c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/225332.184005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/225332.188887:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/225332.266130:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/225332.266280:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/225332.722553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/225332.732406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c2146c81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/225332.732650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/225332.762453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/225332.772389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c2146c81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/225332.772589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/225332.783978:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/225332.787314:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x98a1984e20
[1:1:0711/225332.787482:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[30719:30719:0711/225332.788469:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[30719:30719:0711/225332.806050:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0711/225332.827438:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[30719:30719:0711/225332.854843:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[30719:30719:0711/225332.854984:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[30719:30719:0711/225332.887419:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0711/225333.616060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7fbb3405b2e0 0x98a1beafe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/225333.616791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c2146c81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/225333.616955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/225333.617511:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30719:30719:0711/225333.679201:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[30719:30719:0711/225333.681364:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/225333.681436:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x98a1985820
[1:1:0711/225333.681663:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/225333.703728:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/225333.703976:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[30719:30719:0711/225333.705155:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[30719:30719:0711/225333.716374:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30719:30719:0711/225333.717406:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30719:30730:0711/225333.723376:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[30719:30730:0711/225333.723469:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[30719:30719:0711/225333.723606:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[30719:30719:0711/225333.723683:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[30719:30719:0711/225333.723820:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,30764, 4
[1:7:0711/225333.728949:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/225334.364376:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/225334.792708:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7fbb3405b2e0 0x98a1ccb8e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/225334.793765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c2146c81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/225334.793999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/225334.794769:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30719:30719:0711/225334.865941:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[30719:30719:0711/225334.866002:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/225334.908712:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/225335.244155:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/225335.804635:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/225335.804932:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/225336.272571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/225336.277205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c2146db09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/225336.277523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/225336.285983:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/225336.606109:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/225336.606895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c2146c81f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/225336.607116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[30719:30719:0711/225336.757256:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[30719:30750:0711/225336.757695:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/225336.757888:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/225336.758112:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/225336.758491:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/225336.758682:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/225336.761999:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x71ca396, 1
[1:1:0711/225336.762355:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x17d8980c, 0
[1:1:0711/225336.762504:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x105bdda1, 3
[1:1:0711/225336.762674:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x10737a22, 2
[1:1:0711/225336.762772:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 0cffffff98ffffffd817 ffffff96ffffffa31c07 227a7310 ffffffa1ffffffdd5b10 , 10104, 5
[1:1:0711/225336.763427:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30719:30750:0711/225336.763596:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����"zs��[(��%
[1:1:0711/225336.763574:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbb486320a0, 3
[30719:30750:0711/225336.763717:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����"zs��[�S(��%
[1:1:0711/225336.763719:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbb487bd080, 2
[1:1:0711/225336.763816:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbb32480d20, -2
[30719:30750:0711/225336.763902:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30817, 5, 0c98d817 96a31c07 227a7310 a1dd5b10 
[1:1:0711/225336.784498:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/225336.784949:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10737a22
[1:1:0711/225336.785295:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10737a22
[1:1:0711/225336.786023:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10737a22
[1:1:0711/225336.787658:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.787871:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.788075:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.788281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.789060:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10737a22
[1:1:0711/225336.789389:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbb4a3f77ba
[1:1:0711/225336.789546:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbb4a3eedef, 7fbb4a3f777a, 7fbb4a3f90cf
[1:1:0711/225336.795698:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10737a22
[1:1:0711/225336.796067:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10737a22
[1:1:0711/225336.796847:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10737a22
[1:1:0711/225336.798889:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.799102:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.799282:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.799472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10737a22
[1:1:0711/225336.800736:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10737a22
[1:1:0711/225336.801099:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbb4a3f77ba
[1:1:0711/225336.801237:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbb4a3eedef, 7fbb4a3f777a, 7fbb4a3f90cf
[1:1:0711/225336.810992:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/225336.811616:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/225336.811830:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff47dd8068, 0x7fff47dd7fe8)
[1:1:0711/225336.825143:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/225336.829601:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/225336.843162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/225336.845226:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/225336.845491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c2146db09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/225336.845829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/225336.975878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/225336.976839:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/225336.977077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c2146db09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/225336.977351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/225337.055026:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x98a195f220
[1:1:0711/225337.055206:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[30719:30719:0711/225337.428717:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30719:30719:0711/225337.434565:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30719:30730:0711/225337.451699:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[30719:30730:0711/225337.451896:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[30719:30719:0711/225337.452036:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://home.365jia.cn/
[30719:30719:0711/225337.452094:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://home.365jia.cn/, http://home.365jia.cn/, 1
[30719:30719:0711/225337.452174:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://home.365jia.cn/, HTTP/1.1 200 OK Server: Tengine Content-Type: text/html; charset=utf-8 Content-Length: 35274 Connection: keep-alive Date: Fri, 12 Jul 2019 05:51:50 GMT X-Powered-By: PHP/5.6.36 Cache-Control: public, max-age=300 Expires: Fri, 12 Jul 2019 05:56:50 GMT Last-Modified: Fri, 12 Jul 2019 05:51:50 GMT Pragma: public Etag: W/"307f34cd6133a6e8e1475db2bd3ca889" Content-Encoding: gzip Ali-Swift-Global-Savetime: 1562910710 Via: cache13.l2nu20-3[0,200-0,H], cache5.l2nu20-3[0,0], kunlun1.cn1478[28,200-0,M], kunlun3.cn1478[30,0] Age: 107 X-Cache: MISS TCP_MISS dirn:-2:-2 X-Swift-SaveTime: Fri, 12 Jul 2019 05:53:37 GMT X-Swift-CacheTime: 193 Timing-Allow-Origin: * EagleId: 70366c1715629108175485702e  ,30817, 5
[1:7:0711/225337.465566:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/225337.502848:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://home.365jia.cn/
[30719:30719:0711/225337.653369:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://home.365jia.cn/, http://home.365jia.cn/, 1
[30719:30719:0711/225337.653487:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://home.365jia.cn/, http://home.365jia.cn
[1:1:0711/225337.660243:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/225337.751973:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/225337.827704:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/225337.887045:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/225337.887318:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://home.365jia.cn/"
[1:1:0711/225337.925068:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0711/225337.953843:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 120 0x7fbb32133070 0x98a19a83e0 , "http://home.365jia.cn/"
[1:1:0711/225337.956641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , 
var site_url = {"rexian":"http:\/\/rexian.365jia.cn","click":"http:\/\/click.365jia.cn","img":"http
[1:1:0711/225337.957021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225337.959252:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225337.963023:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 120 0x7fbb32133070 0x98a19a83e0 , "http://home.365jia.cn/"
[1:1:0711/225337.966466:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gmx.net/"
[1:1:0711/225338.105274:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/225338.121403:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/225338.224491:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/225338.307763:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/225338.372293:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/225338.506385:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/225338.569658:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0711/225338.600177:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225339.063350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fbb3249bbd0 0x98a1a735d8 , "http://home.365jia.cn/"
[1:1:0711/225339.069246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , /*!
 * jQuery JavaScript Library v1.5.1
 * http://jquery.com/
 *
 * Copyright 2011, John Resig
 * Du
[1:1:0711/225339.069502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225339.226353:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fbb3249bbd0 0x98a1a735d8 , "http://home.365jia.cn/"
[1:1:0711/225339.271340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fbb3249bbd0 0x98a1a735d8 , "http://home.365jia.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/225339.356389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fbb3249bbd0 0x98a1a735d8 , "http://home.365jia.cn/"
[1:1:0711/225339.500460:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225339.501039:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225339.501461:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225339.501873:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225339.502289:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225340.398023:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.17566, 2, 0
[1:1:0711/225340.398281:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/225341.834226:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/225341.834487:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://home.365jia.cn/"
[1:1:0711/225341.837572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fbb32133070 0x98a1cc89e0 , "http://home.365jia.cn/"
[1:1:0711/225341.838671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , if (typeof jQuery === "undefined") {
    document.write('<script type="text/javascript" src="/js/jQu
[1:1:0711/225341.838953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225341.845681:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fbb32133070 0x98a1cc89e0 , "http://home.365jia.cn/"
[1:1:0711/225341.870171:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fbb32133070 0x98a1cc89e0 , "http://home.365jia.cn/"
[1:1:0711/225341.882081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fbb32133070 0x98a1cc89e0 , "http://home.365jia.cn/"
[1:1:0711/225341.897146:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0625379, 156, 1
[1:1:0711/225341.897396:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/225342.491168:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/225342.491468:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://home.365jia.cn/"
[1:1:0711/225342.492471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 348 0x7fbb32133070 0x98a1bb37e0 , "http://home.365jia.cn/"
[1:1:0711/225342.494400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , 

 function top_login_msg_box_close(){
    $('#top_login_channel_info').hide();
    var date = new D
[1:1:0711/225342.494623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225342.503090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 348 0x7fbb32133070 0x98a1bb37e0 , "http://home.365jia.cn/"
		remove user.10_d01917ad -> 0
[30719:30719:0711/225351.778407:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/225351.816888:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[30719:30719:0711/225351.885789:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363173&dri=0&dis=0&dai=0&ps=36x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=424&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910823, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225351.888123:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363173&dri=0&dis=0&dai=0&ps=36x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=424&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910823, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225352.511544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/225352.511835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225353.102546:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435, "http://home.365jia.cn/"
[1:1:0711/225353.103664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "78839a18b82d66a0","tuid" : "2363173_0","placement" : {"basic" : {"sspId
[1:1:0711/225353.103951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225353.121664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435, "http://home.365jia.cn/"
[1:1:0711/225353.144280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435, "http://home.365jia.cn/"
[30719:30719:0711/225353.229165:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363140&dri=0&dis=0&dai=0&ps=41x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=424&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910833, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225353.236009:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363140&dri=0&dis=0&dai=0&ps=41x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=424&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910833, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225353.702751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225353.703037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225354.442004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495, "http://home.365jia.cn/"
[1:1:0711/225354.442952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "c87160dd172a5207","tuid" : "2363140_0","placement" : {"basic" : {"sspId
[1:1:0711/225354.443083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225354.451699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495, "http://home.365jia.cn/"
[1:1:0711/225354.456767:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495, "http://home.365jia.cn/"
[30719:30719:0711/225354.525296:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363188&dri=0&dis=0&dai=0&ps=46x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=424&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910835, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225354.537625:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363188&dri=0&dis=0&dai=0&ps=46x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1200x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=424&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910835, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225354.967713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225354.967899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225356.038512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568, "http://home.365jia.cn/"
[1:1:0711/225356.039917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "852ce229da6ef42c","tuid" : "2363188_0","placement" : {"basic" : {"sspId
[1:1:0711/225356.040120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225356.050240:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568, "http://home.365jia.cn/"
[1:1:0711/225356.054812:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568, "http://home.365jia.cn/"
[30719:30719:0711/225356.119639:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363182&dri=0&dis=0&dai=0&ps=51x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910836, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225356.128663:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363182&dri=0&dis=0&dai=0&ps=51x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910836, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225356.376466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225356.376633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225357.269804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653, "http://home.365jia.cn/"
[1:1:0711/225357.270476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "6bc2f4f0ed164306","tuid" : "2363182_0","placement" : {"basic" : {"sspId
[1:1:0711/225357.270591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225357.277230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653, "http://home.365jia.cn/"
[1:1:0711/225357.281911:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653, "http://home.365jia.cn/"
[30719:30719:0711/225357.360840:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363183&dri=0&dis=0&dai=0&ps=56x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910837, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225357.370938:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363183&dri=0&dis=0&dai=0&ps=56x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910837, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225357.542625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225357.542864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225359.193648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 733, "http://home.365jia.cn/"
[1:1:0711/225359.194317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "09e9ea8e04472923","tuid" : "2363183_0","placement" : {"basic" : {"sspId
[1:1:0711/225359.194440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225359.201118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 733, "http://home.365jia.cn/"
[1:1:0711/225359.208609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 733, "http://home.365jia.cn/"
[30719:30719:0711/225359.267290:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363139&dri=0&dis=0&dai=0&ps=61x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910839, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225359.276765:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363139&dri=0&dis=0&dai=0&ps=61x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910839, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225359.288856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225359.289027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225400.311828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225400.312008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225400.329598:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790, "http://home.365jia.cn/"
[1:1:0711/225400.330962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "d34d2fd676035284","tuid" : "2363139_0","placement" : {"basic" : {"sspId
[1:1:0711/225400.331149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[30719:30719:0711/225400.360523:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/225400.362913:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x98a195d420
[1:1:0711/225400.364043:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[30719:30719:0711/225400.367960:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[30719:30719:0711/225400.405878:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://home.365jia.cn/, http://home.365jia.cn/, 4
[30719:30719:0711/225400.406010:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://home.365jia.cn/, http://home.365jia.cn
[1:1:0711/225400.432149:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/225400.435634:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x98a22eb220
[1:1:0711/225400.435892:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[30719:30719:0711/225400.469608:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[30719:30719:0711/225400.473631:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0711/225400.478884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://home.365jia.cn/"
[30719:30719:0711/225400.487143:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://home.365jia.cn/, http://home.365jia.cn/, 5
[30719:30719:0711/225400.487222:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://home.365jia.cn/, http://home.365jia.cn
[1:1:0711/225400.515090:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 15dc0517a5f8, 5:3_http://home.365jia.cn/, 5:5_http://home.365jia.cn/, about:blank
[1:1:0711/225400.515295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://home.365jia.cn/-5:5_http://home.365jia.cn/, 15dc0517a5f8, 15dc05082860, open, 
[1:1:0711/225400.515433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "home.365jia.cn", 5, 2, http://home.365jia.cn, home.365jia.cn, 3
[30719:30719:0711/225400.516558:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0711/225400.516696:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://365jia.cn/ads/m.min.js:1:1)
	http://365jia.cn/ads/m.min.js:1:1
	HTMLIFrameElement.onload (http://home.365jia.cn/:343:154)
	Object.render (http://365jia.cn/ads/m.min.js:1:1)
	Object.callback (http://365jia.cn/ads/m.min.js:1:1)
	http://365jia.cn/ads/m.min.js:1:1
	http://pos.baidu.com/jcam?di=2363139&dri=0&dis=0&dai=0&ps=61x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910839:1:1

[1:1:0711/225400.531044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://home.365jia.cn/-5:5_http://home.365jia.cn/-5:3_http://home.365jia.cn/, 15dc05082860, 15dc0517a5f8, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0711/225400.531299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 3, , , 0
[1:1:0711/225400.532022:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://365jia.cn/ads/m.min.js:1:1)
	Object.callback (http://365jia.cn/ads/m.min.js:1:1)
	http://365jia.cn/ads/m.min.js:1:1
	http://pos.baidu.com/jcam?di=2363139&dri=0&dis=0&dai=0&ps=61x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1200x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910839:1:1

[1:1:0711/225400.538031:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 500
[1:1:0711/225400.538274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 868
[1:1:0711/225400.538391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7fbb32133070 0x98a203f5e0 , 5:3_http://home.365jia.cn/, 3, -5:3_http://home.365jia.cn/-5:5_http://home.365jia.cn/-5:3_http://home.365jia.cn/, 790
[1:1:0711/225400.539877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 50
[1:1:0711/225400.540047:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 869
[1:1:0711/225400.540169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 869 0x7fbb32133070 0x98a15ed5e0 , 5:3_http://home.365jia.cn/, 3, -5:3_http://home.365jia.cn/-5:5_http://home.365jia.cn/-5:3_http://home.365jia.cn/, 790
[1:1:0711/225400.560297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790, "http://home.365jia.cn/"
[1:1:0711/225400.572679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790, "http://home.365jia.cn/"
[1:1:0711/225400.574157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790, "http://home.365jia.cn/"
[1:1:0711/225400.577540:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790, "http://home.365jia.cn/"
[1:1:0711/225400.665705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790, "http://home.365jia.cn/"
[1:1:0711/225400.729079:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.169346, 201, 1
[1:1:0711/225400.729324:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/225401.023165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 804 0x7fbb3405b2e0 0x98a2891760 , "http://home.365jia.cn/"
[1:1:0711/225401.027039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (function(){var h={},mt={},c={id:"26095012d467586b2d582e39b320fb1a",dm:["365jia.cn"],js:"tongji.baid
[1:1:0711/225401.027279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225401.045691:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c948
[1:1:0711/225401.045990:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225401.046367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 928
[1:1:0711/225401.046600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7fbb32133070 0x98a12ebee0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 804 0x7fbb3405b2e0 0x98a2891760 
[1:1:0711/225401.583187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 600000
[1:1:0711/225401.583628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 958
[1:1:0711/225401.583855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7fbb32133070 0x98a20379e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 804 0x7fbb3405b2e0 0x98a2891760 
[1:1:0711/225401.584778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 5000
[1:1:0711/225401.585267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 959
[1:1:0711/225401.585499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7fbb32133070 0x98a2834de0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 804 0x7fbb3405b2e0 0x98a2891760 
[1:1:0711/225402.113681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225402.114044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/225404.808669:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/225404.808977:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://home.365jia.cn/"
[1:1:0711/225404.809908:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7fbb32133070 0x98a1c93ee0 , "http://home.365jia.cn/"
[1:1:0711/225404.810737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , BAIDU_CLB_fillSlot(2363204);
[1:1:0711/225404.811005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[30719:30719:0711/225404.871217:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363204&dri=0&dis=0&dai=0&ps=629x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x629&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910845, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225404.880882:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363204&dri=0&dis=0&dai=0&ps=629x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x629&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910845, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225405.097502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 869, 7fbb34a788db
[1:1:0711/225405.141600:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc0508286015dc0517a5f815dc05082860","ptid":"790","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225405.142060:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/-5:5_http://home.365jia.cn/-5:3_http://home.365jia.cn/","ptid":"790","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225405.142562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1028
[1:1:0711/225405.142806:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1028 0x7fbb32133070 0x98a279f460 , 5:3_http://home.365jia.cn/, 0, , 869 0x7fbb32133070 0x98a15ed5e0 
[1:1:0711/225405.143205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225405.143780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225405.144090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225406.351415:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 868, 7fbb34a788db
[1:1:0711/225406.399757:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc0508286015dc0517a5f815dc05082860","ptid":"790","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225406.400292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/-5:5_http://home.365jia.cn/-5:3_http://home.365jia.cn/","ptid":"790","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225406.400890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1040
[1:1:0711/225406.401228:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7fbb32133070 0x98a2dc3060 , 5:3_http://home.365jia.cn/, 0, , 868 0x7fbb32133070 0x98a203f5e0 
[1:1:0711/225406.401642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225406.402269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225406.402528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225406.457813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 928, 7fbb34a78881
[1:1:0711/225406.474881:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"804 0x7fbb3405b2e0 0x98a2891760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225406.475301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"804 0x7fbb3405b2e0 0x98a2891760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225406.475746:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225406.476379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225406.476608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225406.477372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225406.477572:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225406.477934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1042
[1:1:0711/225406.478176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1042 0x7fbb32133070 0x98a2daa3e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 928 0x7fbb32133070 0x98a12ebee0 
[1:1:0711/225406.875911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225406.876247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/225408.366195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1026, "http://home.365jia.cn/"
[1:1:0711/225408.367841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "16b3a22d1be00fa3","tuid" : "2363204_0","placement" : {"basic" : {"sspId
[1:1:0711/225408.368083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225408.387832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1026, "http://home.365jia.cn/"
[1:1:0711/225408.404813:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1026, "http://home.365jia.cn/"
[30719:30719:0711/225408.511215:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363221&dri=0&dis=0&dai=0&ps=629x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x629&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910848, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225408.521617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1028, 7fbb34a788db
[30719:30719:0711/225408.522625:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363221&dri=0&dis=0&dai=0&ps=629x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x629&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910848, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225408.542970:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"869 0x7fbb32133070 0x98a15ed5e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225408.543177:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"869 0x7fbb32133070 0x98a15ed5e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225408.543907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1097
[1:1:0711/225408.544148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7fbb32133070 0x98a2df7de0 , 5:3_http://home.365jia.cn/, 0, , 1028 0x7fbb32133070 0x98a279f460 
[1:1:0711/225408.544558:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225408.545094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225408.545272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225408.954915:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1040, 7fbb34a788db
[1:1:0711/225409.001066:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"868 0x7fbb32133070 0x98a203f5e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225409.001362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"868 0x7fbb32133070 0x98a203f5e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225409.001830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1105
[1:1:0711/225409.001978:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7fbb32133070 0x98a2f18f60 , 5:3_http://home.365jia.cn/, 0, , 1040 0x7fbb32133070 0x98a2dc3060 
[1:1:0711/225409.002179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225409.002468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225409.002577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225409.018224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1042, 7fbb34a78881
[1:1:0711/225409.034841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"928 0x7fbb32133070 0x98a12ebee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225409.035045:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"928 0x7fbb32133070 0x98a12ebee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225409.035288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225409.035600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225409.035705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225409.036501:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225409.036714:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225409.037164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1107
[1:1:0711/225409.037404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1107 0x7fbb32133070 0x98a2167560 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1042 0x7fbb32133070 0x98a2daa3e0 
[1:1:0711/225409.039236:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 959, 7fbb34a788db
[1:1:0711/225409.066584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"804 0x7fbb3405b2e0 0x98a2891760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225409.066777:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"804 0x7fbb3405b2e0 0x98a2891760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225409.067048:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1109
[1:1:0711/225409.067165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7fbb32133070 0x98a2f167e0 , 5:3_http://home.365jia.cn/, 0, , 959 0x7fbb32133070 0x98a2834de0 
[1:1:0711/225409.067338:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225409.067621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/225409.067727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225409.427805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225409.428086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225411.015891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098, "http://home.365jia.cn/"
[1:1:0711/225411.016634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "e984bfbc5f0ae172","tuid" : "2363221_0","placement" : {"basic" : {"sspId
[1:1:0711/225411.016754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225411.025070:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098, "http://home.365jia.cn/"
[1:1:0711/225411.036801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098, "http://home.365jia.cn/"
[30719:30719:0711/225411.107678:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363228&dri=0&dis=0&dai=0&ps=629x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x629&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910851, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225411.124752:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363228&dri=0&dis=0&dai=0&ps=629x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x629&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910851, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225411.176078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1097, 7fbb34a788db
[1:1:0711/225411.214832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1028 0x7fbb32133070 0x98a279f460 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225411.215153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1028 0x7fbb32133070 0x98a279f460 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225411.215626:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1160
[1:1:0711/225411.215838:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1160 0x7fbb32133070 0x98a2e487e0 , 5:3_http://home.365jia.cn/, 0, , 1097 0x7fbb32133070 0x98a2df7de0 
[1:1:0711/225411.216171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225411.216771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225411.216962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225411.356782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://home.365jia.cn/"
[1:1:0711/225411.357211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0711/225411.357339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225411.361027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1105, 7fbb34a788db
[1:1:0711/225411.377966:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1040 0x7fbb32133070 0x98a2dc3060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225411.378153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1040 0x7fbb32133070 0x98a2dc3060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225411.378433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1164
[1:1:0711/225411.378551:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1164 0x7fbb32133070 0x98a2e38ce0 , 5:3_http://home.365jia.cn/, 0, , 1105 0x7fbb32133070 0x98a2f18f60 
[1:1:0711/225411.378751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225411.379036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225411.379139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225411.392148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1107, 7fbb34a78881
[1:1:0711/225411.412508:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1042 0x7fbb32133070 0x98a2daa3e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225411.412721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1042 0x7fbb32133070 0x98a2daa3e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225411.412972:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225411.413303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225411.413563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225411.414350:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225411.414554:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225411.414955:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1165
[1:1:0711/225411.415198:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7fbb32133070 0x98a2f97860 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1107 0x7fbb32133070 0x98a2167560 
[1:1:0711/225411.457121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225411.457393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225412.258250:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1159, "http://home.365jia.cn/"
[1:1:0711/225412.259576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "2df6ab9dd45ec73e","tuid" : "2363228_0","placement" : {"basic" : {"sspId
[1:1:0711/225412.259767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225412.272733:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1159, "http://home.365jia.cn/"
[1:1:0711/225412.342182:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.070806, 265, 1
[1:1:0711/225412.342476:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/225412.349278:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1160, 7fbb34a788db
[1:1:0711/225412.388830:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1097 0x7fbb32133070 0x98a2df7de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225412.389057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1097 0x7fbb32133070 0x98a2df7de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225412.390390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1205
[1:1:0711/225412.390670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1205 0x7fbb32133070 0x98a2f4ece0 , 5:3_http://home.365jia.cn/, 0, , 1160 0x7fbb32133070 0x98a2e487e0 
[1:1:0711/225412.391070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225412.391609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225412.391841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225412.499579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225412.499914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225412.532185:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1165, 7fbb34a78881
[1:1:0711/225412.563377:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1107 0x7fbb32133070 0x98a2167560 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225412.563582:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1107 0x7fbb32133070 0x98a2167560 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225412.563996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225412.564502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225412.564721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225412.565049:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225412.565149:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225412.565320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1209
[1:1:0711/225412.565431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1209 0x7fbb32133070 0x98a2e9ad60 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1165 0x7fbb32133070 0x98a2f97860 
[1:1:0711/225412.585818:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1164, 7fbb34a788db
[1:1:0711/225412.612575:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1105 0x7fbb32133070 0x98a2f18f60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225412.612886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1105 0x7fbb32133070 0x98a2f18f60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225412.613268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1210
[1:1:0711/225412.613457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1210 0x7fbb32133070 0x98a2e408e0 , 5:3_http://home.365jia.cn/, 0, , 1164 0x7fbb32133070 0x98a2e38ce0 
[1:1:0711/225412.613776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225412.614252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225412.614433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225413.218899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1109, 7fbb34a788db
[1:1:0711/225413.253569:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"959 0x7fbb32133070 0x98a2834de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225413.253909:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"959 0x7fbb32133070 0x98a2834de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225413.254384:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1218
[1:1:0711/225413.254625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1218 0x7fbb32133070 0x98a2f5ec60 , 5:3_http://home.365jia.cn/, 0, , 1109 0x7fbb32133070 0x98a2f167e0 
[1:1:0711/225413.255025:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225413.255563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/225413.255840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[30719:30719:0711/225413.753444:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/225414.362581:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/225414.362840:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://home.365jia.cn/"
[1:1:0711/225414.363831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1202 0x7fbb32133070 0x98a2f46f60 , "http://home.365jia.cn/"
[1:1:0711/225414.364771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , BAIDU_CLB_fillSlot(2363203);
[1:1:0711/225414.365054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[30719:30719:0711/225414.441237:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363203&dri=0&dis=0&dai=0&ps=1305x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1305&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910854, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225414.455692:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363203&dri=0&dis=0&dai=0&ps=1305x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1305&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910854, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225414.517047:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1205, 7fbb34a788db
[1:1:0711/225414.539697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1160 0x7fbb32133070 0x98a2e487e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225414.540108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1160 0x7fbb32133070 0x98a2e487e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225414.540636:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1256
[1:1:0711/225414.540916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1256 0x7fbb32133070 0x98a2f3c0e0 , 5:3_http://home.365jia.cn/, 0, , 1205 0x7fbb32133070 0x98a2f4ece0 
[1:1:0711/225414.541409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225414.541949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225414.542176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225414.580895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225414.581174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225414.693847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1209, 7fbb34a78881
[1:1:0711/225414.721152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1165 0x7fbb32133070 0x98a2f97860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225414.721494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1165 0x7fbb32133070 0x98a2f97860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225414.721898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225414.722446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225414.722700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225414.723438:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225414.723639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225414.724029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1260
[1:1:0711/225414.724351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1260 0x7fbb32133070 0x98a2daf060 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1209 0x7fbb32133070 0x98a2e9ad60 
[1:1:0711/225414.725893:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1210, 7fbb34a788db
[1:1:0711/225414.768847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1164 0x7fbb32133070 0x98a2e38ce0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225414.769195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1164 0x7fbb32133070 0x98a2e38ce0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225414.769680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1261
[1:1:0711/225414.769919:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1261 0x7fbb32133070 0x98a281ffe0 , 5:3_http://home.365jia.cn/, 0, , 1210 0x7fbb32133070 0x98a2e408e0 
[1:1:0711/225414.770300:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225414.770840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225414.771087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225415.584011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1255, "http://home.365jia.cn/"
[1:1:0711/225415.585745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "e4d13e63ea5cfe34","tuid" : "2363203_0","placement" : {"basic" : {"sspId
[1:1:0711/225415.586002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225415.606621:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[30719:30719:0711/225415.609501:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/225415.611821:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x98a303b420
[1:1:0711/225415.612067:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[30719:30719:0711/225415.617824:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[30719:30719:0711/225415.648698:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://home.365jia.cn/, http://home.365jia.cn/, 6
[30719:30719:0711/225415.648870:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://home.365jia.cn/, http://home.365jia.cn
[1:1:0711/225415.651720:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://home.365jia.cn/"
[1:1:0711/225415.677464:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/225415.679496:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 15dc0515a190, 5:3_http://home.365jia.cn/, 5:6_http://home.365jia.cn/, about:blank
[1:1:0711/225415.679694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://home.365jia.cn/-5:6_http://home.365jia.cn/, 15dc0515a190, 15dc05082860, open, 
[1:1:0711/225415.679881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "home.365jia.cn", 6, 2, http://home.365jia.cn, home.365jia.cn, 3
[1:1:0711/225415.681047:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://365jia.cn/ads/m.min.js:1:1)
	http://365jia.cn/ads/m.min.js:1:1
	HTMLIFrameElement.onload (http://home.365jia.cn/:768:156)
	Object.render (http://365jia.cn/ads/m.min.js:1:1)
	Object.callback (http://365jia.cn/ads/m.min.js:1:1)
	http://365jia.cn/ads/m.min.js:1:1
	http://pos.baidu.com/jcam?di=2363203&dri=0&dis=0&dai=0&ps=1305x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1305&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910854:1:1

[1:1:0711/225415.689843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://home.365jia.cn/-5:6_http://home.365jia.cn/-5:3_http://home.365jia.cn/, 15dc05082860, 15dc0515a190, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0711/225415.690193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 3, , , 0
[1:1:0711/225415.690990:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://365jia.cn/ads/m.min.js:1:1)
	Object.callback (http://365jia.cn/ads/m.min.js:1:1)
	http://365jia.cn/ads/m.min.js:1:1
	http://pos.baidu.com/jcam?di=2363203&dri=0&dis=0&dai=0&ps=1305x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1305&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910854:1:1

[1:1:0711/225415.706801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1255, "http://home.365jia.cn/"
[1:1:0711/225415.717267:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1255, "http://home.365jia.cn/"
[30719:30719:0711/225415.784167:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363218&dri=0&dis=0&dai=0&ps=1370x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1370&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910856, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225415.800110:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363218&dri=0&dis=0&dai=0&ps=1370x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1370&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910856, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225415.818734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225415.819015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225415.867458:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1256, 7fbb34a788db
[1:1:0711/225415.887359:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1205 0x7fbb32133070 0x98a2f4ece0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225415.887730:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1205 0x7fbb32133070 0x98a2f4ece0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225415.888238:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1320
[1:1:0711/225415.888521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7fbb32133070 0x98a1c3f9e0 , 5:3_http://home.365jia.cn/, 0, , 1256 0x7fbb32133070 0x98a2f3c0e0 
[1:1:0711/225415.888938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225415.889569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225415.889801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225415.929403:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1260, 7fbb34a78881
[1:1:0711/225415.970621:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1209 0x7fbb32133070 0x98a2e9ad60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225415.970818:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1209 0x7fbb32133070 0x98a2e9ad60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225415.971052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225415.971358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225415.971494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225415.971786:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225415.971880:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225415.972046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1323
[1:1:0711/225415.972152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1323 0x7fbb32133070 0x98a2895860 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1260 0x7fbb32133070 0x98a2daf060 
[1:1:0711/225415.972713:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1261, 7fbb34a788db
[1:1:0711/225416.021621:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1210 0x7fbb32133070 0x98a2e408e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225416.021979:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1210 0x7fbb32133070 0x98a2e408e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225416.022498:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1326
[1:1:0711/225416.022750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7fbb32133070 0x98a15707e0 , 5:3_http://home.365jia.cn/, 0, , 1261 0x7fbb32133070 0x98a281ffe0 
[1:1:0711/225416.023168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225416.023782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225416.024047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/225417.824917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225417.825143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225417.874516:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1317, "http://home.365jia.cn/"
[1:1:0711/225417.875205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , ___adblockplus({"queryid" : "e76e4b4b65bb0a61","tuid" : "2363218_0","placement" : {"basic" : {"sspId
[1:1:0711/225417.875322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225417.881059:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1317, "http://home.365jia.cn/"
[1:1:0711/225417.885923:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1317, "http://home.365jia.cn/"
[30719:30719:0711/225417.973279:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363230&dri=0&dis=0&dai=0&ps=1370x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1370&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910858, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[30719:30719:0711/225417.983751:INFO:CONSOLE(14)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/jcam?di=2363230&dri=0&dis=0&dai=0&ps=1370x0&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562910822851&ti=%E5%90%88%E8%82%A5%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%90%88%E8%82%A5%E5%AE%B6%E8%A3%85%E7%BD%91-%E5%90%88%E8%82%A5%E8%A3%85%E4%BF%AE%E7%BD%91-%E4%B8%87%E5%AE%B6%E5%AE%B6%E5%B1%85%E7%BD%91-%E5%AE%89%E5%BE%BD%E5%AE%B6%E5%B1%85%E9%97%A8%E6%88%B7&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1200x1370&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562910710&rw=471&ltu=http%3A%2F%2Fhome.365jia.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562910858, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://365jia.cn/ads/m.min.js (14)
[1:1:0711/225418.148775:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1320, 7fbb34a788db
[1:1:0711/225418.179014:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1256 0x7fbb32133070 0x98a2f3c0e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.179367:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1256 0x7fbb32133070 0x98a2f3c0e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.179939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1367
[1:1:0711/225418.180163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1367 0x7fbb32133070 0x98a2f1d860 , 5:3_http://home.365jia.cn/, 0, , 1320 0x7fbb32133070 0x98a1c3f9e0 
[1:1:0711/225418.180505:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225418.181040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225418.181224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225418.302635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1326, 7fbb34a788db
[1:1:0711/225418.349088:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1261 0x7fbb32133070 0x98a281ffe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.349391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1261 0x7fbb32133070 0x98a281ffe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.349851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1374
[1:1:0711/225418.350071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1374 0x7fbb32133070 0x98a1c32960 , 5:3_http://home.365jia.cn/, 0, , 1326 0x7fbb32133070 0x98a15707e0 
[1:1:0711/225418.350410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225418.350906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225418.351126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225418.446337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1323, 7fbb34a78881
[1:1:0711/225418.464278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1260 0x7fbb32133070 0x98a2daf060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.464571:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1260 0x7fbb32133070 0x98a2daf060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.464922:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225418.465468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225418.465638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225418.466270:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225418.466425:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225418.466751:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1376
[1:1:0711/225418.466933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1376 0x7fbb32133070 0x98a2813960 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1323 0x7fbb32133070 0x98a2895860 
[1:1:0711/225418.758410:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1218, 7fbb34a788db
[1:1:0711/225418.791808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1109 0x7fbb32133070 0x98a2f167e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.792202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1109 0x7fbb32133070 0x98a2f167e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225418.792712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1385
[1:1:0711/225418.792954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1385 0x7fbb32133070 0x98a215c2e0 , 5:3_http://home.365jia.cn/, 0, , 1218 0x7fbb32133070 0x98a2f5ec60 
[1:1:0711/225418.793392:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225418.794013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/225418.794167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225418.985058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225418.985383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225419.819625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1367, 7fbb34a788db
[1:1:0711/225419.840729:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1320 0x7fbb32133070 0x98a1c3f9e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225419.840911:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1320 0x7fbb32133070 0x98a1c3f9e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225419.841130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1409
[1:1:0711/225419.841241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1409 0x7fbb32133070 0x98a2e131e0 , 5:3_http://home.365jia.cn/, 0, , 1367 0x7fbb32133070 0x98a2f1d860 
[1:1:0711/225419.841459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225419.841739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225419.841849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225419.843526:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1374, 7fbb34a788db
[1:1:0711/225419.883982:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1326 0x7fbb32133070 0x98a15707e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225419.884269:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1326 0x7fbb32133070 0x98a15707e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225419.884717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1410
[1:1:0711/225419.884906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1410 0x7fbb32133070 0x98a2de78e0 , 5:3_http://home.365jia.cn/, 0, , 1374 0x7fbb32133070 0x98a1c32960 
[1:1:0711/225419.885211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225419.885710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225419.885887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225419.929467:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1376, 7fbb34a78881
[1:1:0711/225419.964439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1323 0x7fbb32133070 0x98a2895860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225419.964748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1323 0x7fbb32133070 0x98a2895860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225419.965115:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225419.965679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225419.965858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225419.966541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225419.966745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225419.967167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1413
[1:1:0711/225419.967393:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7fbb32133070 0x98a2dea6e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1376 0x7fbb32133070 0x98a2813960 
[1:1:0711/225420.163074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225420.163263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225420.502994:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1409, 7fbb34a788db
[1:1:0711/225420.521070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1367 0x7fbb32133070 0x98a2f1d860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225420.521251:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1367 0x7fbb32133070 0x98a2f1d860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225420.521485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1431
[1:1:0711/225420.521598:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1431 0x7fbb32133070 0x98a1c527e0 , 5:3_http://home.365jia.cn/, 0, , 1409 0x7fbb32133070 0x98a2e131e0 
[1:1:0711/225420.521782:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225420.522065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225420.522168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225420.621980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1410, 7fbb34a788db
[1:1:0711/225420.682862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1374 0x7fbb32133070 0x98a1c32960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225420.683141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1374 0x7fbb32133070 0x98a1c32960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225420.683551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1435
[1:1:0711/225420.683760:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1435 0x7fbb32133070 0x98a2daa160 , 5:3_http://home.365jia.cn/, 0, , 1410 0x7fbb32133070 0x98a2de78e0 
[1:1:0711/225420.684080:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225420.684600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225420.684780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225420.846378:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1413, 7fbb34a78881
[1:1:0711/225420.905571:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1376 0x7fbb32133070 0x98a2813960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225420.905884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1376 0x7fbb32133070 0x98a2813960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225420.906244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225420.906768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225420.906944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225420.907568:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225420.907730:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225420.908054:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1442
[1:1:0711/225420.908243:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1442 0x7fbb32133070 0x98a2daafe0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1413 0x7fbb32133070 0x98a2dea6e0 
[1:1:0711/225421.353739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225421.353932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225421.386487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1431, 7fbb34a788db
[1:1:0711/225421.444981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1409 0x7fbb32133070 0x98a2e131e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.445268:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1409 0x7fbb32133070 0x98a2e131e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.445686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1460
[1:1:0711/225421.445897:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1460 0x7fbb32133070 0x98a2dba260 , 5:3_http://home.365jia.cn/, 0, , 1431 0x7fbb32133070 0x98a1c527e0 
[1:1:0711/225421.446230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225421.446727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225421.446904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225421.545016:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1442, 7fbb34a78881
[1:1:0711/225421.584877:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1413 0x7fbb32133070 0x98a2dea6e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.585081:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1413 0x7fbb32133070 0x98a2dea6e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.585300:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225421.585608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225421.585754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225421.586063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225421.586161:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225421.586332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1465
[1:1:0711/225421.586445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1465 0x7fbb32133070 0x98a2e20fe0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1442 0x7fbb32133070 0x98a2daafe0 
[1:1:0711/225421.607772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225421.608083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225421.715954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1435, 7fbb34a788db
[1:1:0711/225421.734888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1410 0x7fbb32133070 0x98a2de78e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.735075:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1410 0x7fbb32133070 0x98a2de78e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.735297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1472
[1:1:0711/225421.735421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1472 0x7fbb32133070 0x98a2da90e0 , 5:3_http://home.365jia.cn/, 0, , 1435 0x7fbb32133070 0x98a2daa160 
[1:1:0711/225421.735610:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225421.735942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225421.736048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225421.859029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225421.859271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225421.922872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1460, 7fbb34a788db
[1:1:0711/225421.985230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1431 0x7fbb32133070 0x98a1c527e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.985512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1431 0x7fbb32133070 0x98a1c527e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225421.985932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1478
[1:1:0711/225421.986127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1478 0x7fbb32133070 0x98a2dc1060 , 5:3_http://home.365jia.cn/, 0, , 1460 0x7fbb32133070 0x98a2dba260 
[1:1:0711/225421.986461:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225421.986966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225421.987144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225421.989826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1385, 7fbb34a788db
[1:1:0711/225422.049351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1218 0x7fbb32133070 0x98a2f5ec60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.049630:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1218 0x7fbb32133070 0x98a2f5ec60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.050041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1481
[1:1:0711/225422.050236:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1481 0x7fbb32133070 0x98a2daf060 , 5:3_http://home.365jia.cn/, 0, , 1385 0x7fbb32133070 0x98a215c2e0 
[1:1:0711/225422.050540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225422.051037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/225422.051226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225422.054062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1465, 7fbb34a78881
[1:1:0711/225422.114673:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1442 0x7fbb32133070 0x98a2daafe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.115001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1442 0x7fbb32133070 0x98a2daafe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.115383:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225422.115960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225422.116173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225422.116802:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225422.116986:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225422.117305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1489
[1:1:0711/225422.117493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1489 0x7fbb32133070 0x98a2f35fe0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1465 0x7fbb32133070 0x98a2e20fe0 
[1:1:0711/225422.300548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225422.300723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225422.302217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1478, 7fbb34a788db
[1:1:0711/225422.355135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1460 0x7fbb32133070 0x98a2dba260 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.355428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1460 0x7fbb32133070 0x98a2dba260 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.355826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1500
[1:1:0711/225422.356078:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1500 0x7fbb32133070 0x98a1c39060 , 5:3_http://home.365jia.cn/, 0, , 1478 0x7fbb32133070 0x98a2dc1060 
[1:1:0711/225422.356418:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225422.356911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225422.357100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225422.359764:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1472, 7fbb34a788db
[1:1:0711/225422.424681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1435 0x7fbb32133070 0x98a2daa160 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.425045:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1435 0x7fbb32133070 0x98a2daa160 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.425542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1503
[1:1:0711/225422.425795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1503 0x7fbb32133070 0x98a2dc74e0 , 5:3_http://home.365jia.cn/, 0, , 1472 0x7fbb32133070 0x98a2da90e0 
[1:1:0711/225422.426211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225422.426807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225422.427066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225422.947310:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1489, 7fbb34a78881
[1:1:0711/225422.972343:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1465 0x7fbb32133070 0x98a2e20fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.972554:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1465 0x7fbb32133070 0x98a2e20fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225422.972754:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225422.973073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225422.973180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225422.973464:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225422.973558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225422.973723:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1520
[1:1:0711/225422.973828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1520 0x7fbb32133070 0x98a2de0160 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1489 0x7fbb32133070 0x98a2f35fe0 
[1:1:0711/225423.012989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225423.013202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.047724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1500, 7fbb34a788db
[1:1:0711/225423.085299:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1478 0x7fbb32133070 0x98a2dc1060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.085586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1478 0x7fbb32133070 0x98a2dc1060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.085981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1523
[1:1:0711/225423.086278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1523 0x7fbb32133070 0x98a2d9bfe0 , 5:3_http://home.365jia.cn/, 0, , 1500 0x7fbb32133070 0x98a1c39060 
[1:1:0711/225423.086711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.087324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225423.087520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.090103:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1503, 7fbb34a788db
[1:1:0711/225423.161138:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1472 0x7fbb32133070 0x98a2da90e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.161422:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1472 0x7fbb32133070 0x98a2da90e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.161810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1526
[1:1:0711/225423.161999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1526 0x7fbb32133070 0x98a2f50d60 , 5:3_http://home.365jia.cn/, 0, , 1503 0x7fbb32133070 0x98a2dc74e0 
[1:1:0711/225423.162323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.162798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225423.162976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.397080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225423.397277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.398615:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1520, 7fbb34a78881
[1:1:0711/225423.417726:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1489 0x7fbb32133070 0x98a2f35fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.417928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1489 0x7fbb32133070 0x98a2f35fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.418181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.418494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225423.418595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.418880:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225423.418971:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225423.419150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1535
[1:1:0711/225423.419272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1535 0x7fbb32133070 0x98a3172760 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1520 0x7fbb32133070 0x98a2de0160 
[1:1:0711/225423.419782:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1523, 7fbb34a788db
[1:1:0711/225423.442044:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1500 0x7fbb32133070 0x98a1c39060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.442290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1500 0x7fbb32133070 0x98a1c39060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.442514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1536
[1:1:0711/225423.442622:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1536 0x7fbb32133070 0x98a1d910e0 , 5:3_http://home.365jia.cn/, 0, , 1523 0x7fbb32133070 0x98a2d9bfe0 
[1:1:0711/225423.442807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.443103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225423.443233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.478113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225423.478304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.520713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225423.520889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.522348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1536, 7fbb34a788db
[1:1:0711/225423.542214:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1523 0x7fbb32133070 0x98a2d9bfe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.542404:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1523 0x7fbb32133070 0x98a2d9bfe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.542647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1543
[1:1:0711/225423.542767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1543 0x7fbb32133070 0x98a1c452e0 , 5:3_http://home.365jia.cn/, 0, , 1536 0x7fbb32133070 0x98a1d910e0 
[1:1:0711/225423.542941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.543247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225423.543364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.598050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1535, 7fbb34a78881
[1:1:0711/225423.646282:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1520 0x7fbb32133070 0x98a2de0160 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.646479:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1520 0x7fbb32133070 0x98a2de0160 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.646682:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.646987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225423.647092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.647408:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225423.647505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225423.647677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1548
[1:1:0711/225423.647785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1548 0x7fbb32133070 0x98a1c454e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1535 0x7fbb32133070 0x98a3172760 
[1:1:0711/225423.719196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225423.719452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.722740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1526, 7fbb34a788db
[1:1:0711/225423.794270:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1503 0x7fbb32133070 0x98a2dc74e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.794614:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1503 0x7fbb32133070 0x98a2dc74e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.795148:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1553
[1:1:0711/225423.795375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1553 0x7fbb32133070 0x98a2e1cf60 , 5:3_http://home.365jia.cn/, 0, , 1526 0x7fbb32133070 0x98a2f50d60 
[1:1:0711/225423.795676:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.796154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225423.796373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225423.850812:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1543, 7fbb34a788db
[1:1:0711/225423.909297:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1536 0x7fbb32133070 0x98a1d910e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.909568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1536 0x7fbb32133070 0x98a1d910e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225423.909987:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1557
[1:1:0711/225423.910171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1557 0x7fbb32133070 0x98a1cd4ae0 , 5:3_http://home.365jia.cn/, 0, , 1543 0x7fbb32133070 0x98a1c452e0 
[1:1:0711/225423.910504:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225423.910996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225423.911161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225424.025344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225424.025655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225424.072102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1548, 7fbb34a78881
[1:1:0711/225424.110227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1535 0x7fbb32133070 0x98a3172760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225424.110649:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1535 0x7fbb32133070 0x98a3172760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225424.111107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225424.111808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225424.112064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225424.112850:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225424.113055:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225424.113472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1570
[1:1:0711/225424.113719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1570 0x7fbb32133070 0x98a2f57ee0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1548 0x7fbb32133070 0x98a1c454e0 
[1:1:0711/225424.229119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1557, 7fbb34a788db
[1:1:0711/225424.306937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1543 0x7fbb32133070 0x98a1c452e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225424.307296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1543 0x7fbb32133070 0x98a1c452e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225424.307805:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1577
[1:1:0711/225424.308052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1577 0x7fbb32133070 0x98a31725e0 , 5:3_http://home.365jia.cn/, 0, , 1557 0x7fbb32133070 0x98a1cd4ae0 
[1:1:0711/225424.308504:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225424.309142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225424.309384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225424.447175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225424.447493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225424.526958:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1553, 7fbb34a788db
[1:1:0711/225424.578969:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1526 0x7fbb32133070 0x98a2f50d60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225424.579247:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1526 0x7fbb32133070 0x98a2f50d60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225424.579670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1587
[1:1:0711/225424.579862:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1587 0x7fbb32133070 0x98a25773e0 , 5:3_http://home.365jia.cn/, 0, , 1553 0x7fbb32133070 0x98a2e1cf60 
[1:1:0711/225424.580194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225424.580698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225424.580876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.024882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1570, 7fbb34a78881
[1:1:0711/225425.090513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1548 0x7fbb32133070 0x98a1c454e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.090928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1548 0x7fbb32133070 0x98a1c454e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.091404:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225425.092095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225425.092317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.093085:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225425.093287:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225425.093699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1599
[1:1:0711/225425.093939:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1599 0x7fbb32133070 0x98a2f46960 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1570 0x7fbb32133070 0x98a2f57ee0 
[1:1:0711/225425.096651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1577, 7fbb34a788db
[1:1:0711/225425.166114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1557 0x7fbb32133070 0x98a1cd4ae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.166394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1557 0x7fbb32133070 0x98a1cd4ae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.166848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1603
[1:1:0711/225425.167042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1603 0x7fbb32133070 0x98a2de7960 , 5:3_http://home.365jia.cn/, 0, , 1577 0x7fbb32133070 0x98a31725e0 
[1:1:0711/225425.167377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225425.167877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225425.168053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.440544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225425.440872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.445532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1587, 7fbb34a788db
[1:1:0711/225425.495206:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1553 0x7fbb32133070 0x98a2e1cf60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.495414:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1553 0x7fbb32133070 0x98a2e1cf60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.495743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1615
[1:1:0711/225425.495937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1615 0x7fbb32133070 0x98a1c28be0 , 5:3_http://home.365jia.cn/, 0, , 1587 0x7fbb32133070 0x98a25773e0 
[1:1:0711/225425.496272:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225425.496740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225425.496856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.521582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1603, 7fbb34a788db
[1:1:0711/225425.560994:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1577 0x7fbb32133070 0x98a31725e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.561337:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1577 0x7fbb32133070 0x98a31725e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.561844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1618
[1:1:0711/225425.562088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1618 0x7fbb32133070 0x98a2037760 , 5:3_http://home.365jia.cn/, 0, , 1603 0x7fbb32133070 0x98a2de7960 
[1:1:0711/225425.562468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225425.563084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225425.563319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.695460:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1599, 7fbb34a78881
[1:1:0711/225425.761258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1570 0x7fbb32133070 0x98a2f57ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.761564:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1570 0x7fbb32133070 0x98a2f57ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225425.761938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225425.762437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225425.762612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.763235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225425.763416:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225425.763759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1626
[1:1:0711/225425.763951:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1626 0x7fbb32133070 0x98a2de5ee0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1599 0x7fbb32133070 0x98a2f46960 
[1:1:0711/225425.894634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225425.894952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225425.996546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1615, 7fbb34a788db
[1:1:0711/225426.016921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1587 0x7fbb32133070 0x98a25773e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.017118:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1587 0x7fbb32133070 0x98a25773e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.017344:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1636
[1:1:0711/225426.017456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1636 0x7fbb32133070 0x98a2deba60 , 5:3_http://home.365jia.cn/, 0, , 1615 0x7fbb32133070 0x98a1c28be0 
[1:1:0711/225426.017646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225426.017953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225426.018068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225426.108494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1618, 7fbb34a788db
[1:1:0711/225426.133715:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1603 0x7fbb32133070 0x98a2de7960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.134130:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1603 0x7fbb32133070 0x98a2de7960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.134632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1647
[1:1:0711/225426.134847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1647 0x7fbb32133070 0x98a34d9760 , 5:3_http://home.365jia.cn/, 0, , 1618 0x7fbb32133070 0x98a2037760 
[1:1:0711/225426.135179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225426.135683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225426.135910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225426.333553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225426.333727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225426.407538:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1626, 7fbb34a78881
[1:1:0711/225426.468726:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1599 0x7fbb32133070 0x98a2f46960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.469072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1599 0x7fbb32133070 0x98a2f46960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.469426:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225426.469985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225426.470212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225426.470901:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225426.471063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225426.471387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1656
[1:1:0711/225426.471576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1656 0x7fbb32133070 0x98a2f359e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1626 0x7fbb32133070 0x98a2de5ee0 
[1:1:0711/225426.472455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1636, 7fbb34a788db
[1:1:0711/225426.501585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1615 0x7fbb32133070 0x98a1c28be0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.501774:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1615 0x7fbb32133070 0x98a1c28be0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225426.502030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1659
[1:1:0711/225426.502147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1659 0x7fbb32133070 0x98a1bf7de0 , 5:3_http://home.365jia.cn/, 0, , 1636 0x7fbb32133070 0x98a2deba60 
[1:1:0711/225426.502335:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225426.502620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225426.502724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225426.973035:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1647, 7fbb34a788db
[1:1:0711/225427.052752:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1618 0x7fbb32133070 0x98a2037760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.053121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1618 0x7fbb32133070 0x98a2037760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.053616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1673
[1:1:0711/225427.053863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1673 0x7fbb32133070 0x98a279fd60 , 5:3_http://home.365jia.cn/, 0, , 1647 0x7fbb32133070 0x98a34d9760 
[1:1:0711/225427.054306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.054921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225427.055162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.172261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225427.172443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.225476:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1659, 7fbb34a788db
[1:1:0711/225427.255557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1636 0x7fbb32133070 0x98a2deba60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.255753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1636 0x7fbb32133070 0x98a2deba60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.255970:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1683
[1:1:0711/225427.256194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1683 0x7fbb32133070 0x98a2035660 , 5:3_http://home.365jia.cn/, 0, , 1659 0x7fbb32133070 0x98a1bf7de0 
[1:1:0711/225427.256386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.256680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225427.256792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.278828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1656, 7fbb34a78881
[1:1:0711/225427.345360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1626 0x7fbb32133070 0x98a2de5ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.345678:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1626 0x7fbb32133070 0x98a2de5ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.346084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.346591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225427.346764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.347531:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225427.347742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225427.348284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1686
[1:1:0711/225427.348481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1686 0x7fbb32133070 0x98a2d9b8e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1656 0x7fbb32133070 0x98a2f359e0 
[1:1:0711/225427.350502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1481, 7fbb34a788db
[1:1:0711/225427.414428:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1385 0x7fbb32133070 0x98a215c2e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.414707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1385 0x7fbb32133070 0x98a215c2e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.415114:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1689
[1:1:0711/225427.415310:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1689 0x7fbb32133070 0x98a2f67b60 , 5:3_http://home.365jia.cn/, 0, , 1481 0x7fbb32133070 0x98a2daf060 
[1:1:0711/225427.415622:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.416149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/225427.416326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.477018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225427.477209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.478479:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1673, 7fbb34a788db
[1:1:0711/225427.522645:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1647 0x7fbb32133070 0x98a34d9760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.522856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1647 0x7fbb32133070 0x98a34d9760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.523170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1695
[1:1:0711/225427.523361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1695 0x7fbb32133070 0x98a2deaee0 , 5:3_http://home.365jia.cn/, 0, , 1673 0x7fbb32133070 0x98a279fd60 
[1:1:0711/225427.523569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.523855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225427.523964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.526399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1686, 7fbb34a78881
[1:1:0711/225427.593652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1656 0x7fbb32133070 0x98a2f359e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.593958:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1656 0x7fbb32133070 0x98a2f359e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.594327:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.594833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225427.595009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.595636:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225427.595805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225427.596152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1696
[1:1:0711/225427.596345:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1696 0x7fbb32133070 0x98a2e1c360 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1686 0x7fbb32133070 0x98a2d9b8e0 
[1:1:0711/225427.669114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225427.669364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.821832:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1683, 7fbb34a788db
[1:1:0711/225427.873786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1659 0x7fbb32133070 0x98a1bf7de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.873980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1659 0x7fbb32133070 0x98a1bf7de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.874226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1706
[1:1:0711/225427.874341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1706 0x7fbb32133070 0x98a342b4e0 , 5:3_http://home.365jia.cn/, 0, , 1683 0x7fbb32133070 0x98a2035660 
[1:1:0711/225427.874532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.874821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225427.874927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225427.924049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1695, 7fbb34a788db
[1:1:0711/225427.997738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1673 0x7fbb32133070 0x98a279fd60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.998088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1673 0x7fbb32133070 0x98a279fd60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225427.998607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1709
[1:1:0711/225427.998854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1709 0x7fbb32133070 0x98a1c0e6e0 , 5:3_http://home.365jia.cn/, 0, , 1695 0x7fbb32133070 0x98a2deaee0 
[1:1:0711/225427.999254:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225427.999892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225428.000113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225428.082692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225428.083021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225428.252468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1696, 7fbb34a78881
[1:1:0711/225428.325717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1686 0x7fbb32133070 0x98a2d9b8e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225428.326040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1686 0x7fbb32133070 0x98a2d9b8e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225428.326409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225428.326917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225428.327104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225428.327732:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225428.327891:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225428.328215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1728
[1:1:0711/225428.328475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1728 0x7fbb32133070 0x98a1a63ce0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1696 0x7fbb32133070 0x98a2e1c360 
[1:1:0711/225428.570624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225428.570808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225428.889803:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1706, 7fbb34a788db
[1:1:0711/225428.910999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1683 0x7fbb32133070 0x98a2035660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225428.911180:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1683 0x7fbb32133070 0x98a2035660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225428.911419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1747
[1:1:0711/225428.911536:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1747 0x7fbb32133070 0x98a342b160 , 5:3_http://home.365jia.cn/, 0, , 1706 0x7fbb32133070 0x98a342b4e0 
[1:1:0711/225428.911719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225428.912013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225428.912115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225428.939706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1709, 7fbb34a788db
[1:1:0711/225428.985838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1695 0x7fbb32133070 0x98a2deaee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225428.986115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1695 0x7fbb32133070 0x98a2deaee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225428.986523:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1749
[1:1:0711/225428.986721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1749 0x7fbb32133070 0x98a2891c60 , 5:3_http://home.365jia.cn/, 0, , 1709 0x7fbb32133070 0x98a1c0e6e0 
[1:1:0711/225428.987073:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225428.987574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225428.987752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.183797:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1728, 7fbb34a78881
[1:1:0711/225429.217814:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1696 0x7fbb32133070 0x98a2e1c360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.218003:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1696 0x7fbb32133070 0x98a2e1c360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.218203:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225429.218519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225429.218621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.219010:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225429.219106:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225429.219315:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1757
[1:1:0711/225429.219421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1757 0x7fbb32133070 0x98a2dbf860 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1728 0x7fbb32133070 0x98a1a63ce0 
[1:1:0711/225429.255160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225429.255329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.256600:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1749, 7fbb34a788db
[1:1:0711/225429.292158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1709 0x7fbb32133070 0x98a1c0e6e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.292354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1709 0x7fbb32133070 0x98a1c0e6e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.292835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1760
[1:1:0711/225429.293102:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1760 0x7fbb32133070 0x98a2d78d60 , 5:3_http://home.365jia.cn/, 0, , 1749 0x7fbb32133070 0x98a2891c60 
[1:1:0711/225429.293523:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225429.294129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225429.294350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.297423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1747, 7fbb34a788db
[1:1:0711/225429.380932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1706 0x7fbb32133070 0x98a342b4e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.381210:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1706 0x7fbb32133070 0x98a342b4e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.381619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1762
[1:1:0711/225429.381814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1762 0x7fbb32133070 0x98a3172660 , 5:3_http://home.365jia.cn/, 0, , 1747 0x7fbb32133070 0x98a342b160 
[1:1:0711/225429.382117:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225429.382617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225429.382794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.612908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225429.613085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.683994:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1757, 7fbb34a78881
[1:1:0711/225429.747649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1728 0x7fbb32133070 0x98a1a63ce0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.747968:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1728 0x7fbb32133070 0x98a1a63ce0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.748322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225429.748860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225429.749039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.749671:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225429.749830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225429.750166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1773
[1:1:0711/225429.750354:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1773 0x7fbb32133070 0x98a2d74ee0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1757 0x7fbb32133070 0x98a2dbf860 
[1:1:0711/225429.815830:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1760, 7fbb34a788db
[1:1:0711/225429.838033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1749 0x7fbb32133070 0x98a2891c60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.838212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1749 0x7fbb32133070 0x98a2891c60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.838428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1776
[1:1:0711/225429.838540:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1776 0x7fbb32133070 0x98a1cd4960 , 5:3_http://home.365jia.cn/, 0, , 1760 0x7fbb32133070 0x98a2d78d60 
[1:1:0711/225429.838761:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225429.839052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225429.839154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225429.840068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1762, 7fbb34a788db
[1:1:0711/225429.863608:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1747 0x7fbb32133070 0x98a342b160 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.863853:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1747 0x7fbb32133070 0x98a342b160 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225429.864177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1778
[1:1:0711/225429.864334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1778 0x7fbb32133070 0x98a2e1ac60 , 5:3_http://home.365jia.cn/, 0, , 1762 0x7fbb32133070 0x98a3172660 
[1:1:0711/225429.864578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225429.864998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225429.865151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225430.013296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225430.013503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225430.057946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1776, 7fbb34a788db
[1:1:0711/225430.111268:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1760 0x7fbb32133070 0x98a2d78d60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225430.111548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1760 0x7fbb32133070 0x98a2d78d60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225430.111981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1791
[1:1:0711/225430.112178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1791 0x7fbb32133070 0x98a20362e0 , 5:3_http://home.365jia.cn/, 0, , 1776 0x7fbb32133070 0x98a1cd4960 
[1:1:0711/225430.112508:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225430.113031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225430.113230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225430.115944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1773, 7fbb34a78881
[1:1:0711/225430.185612:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1757 0x7fbb32133070 0x98a2dbf860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225430.185897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1757 0x7fbb32133070 0x98a2dbf860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225430.186200:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225430.186605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225430.186785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225430.187205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225430.187340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225430.187568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1800
[1:1:0711/225430.187773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1800 0x7fbb32133070 0x98a2db24e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1773 0x7fbb32133070 0x98a2d74ee0 
[1:1:0711/225430.223200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225430.223429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225430.338527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1778, 7fbb34a788db
[1:1:0711/225430.411466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1762 0x7fbb32133070 0x98a3172660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225430.411716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1762 0x7fbb32133070 0x98a3172660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225430.412074:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1808
[1:1:0711/225430.412233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1808 0x7fbb32133070 0x98a2e46b60 , 5:3_http://home.365jia.cn/, 0, , 1778 0x7fbb32133070 0x98a2e1ac60 
[1:1:0711/225430.412496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225430.413017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225430.413238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.098443:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1791, 7fbb34a788db
[1:1:0711/225431.120780:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1776 0x7fbb32133070 0x98a1cd4960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.120994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1776 0x7fbb32133070 0x98a1cd4960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.121218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1825
[1:1:0711/225431.121329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1825 0x7fbb32133070 0x98a2e1ac60 , 5:3_http://home.365jia.cn/, 0, , 1791 0x7fbb32133070 0x98a20362e0 
[1:1:0711/225431.121520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225431.121810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225431.121950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.176208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225431.176390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.177717:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1800, 7fbb34a78881
[1:1:0711/225431.250286:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1773 0x7fbb32133070 0x98a2d74ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.250682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1773 0x7fbb32133070 0x98a2d74ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.251204:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225431.251836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225431.252108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.252871:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225431.253090:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225431.253493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1829
[1:1:0711/225431.253735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1829 0x7fbb32133070 0x98a2f009e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1800 0x7fbb32133070 0x98a2db24e0 
[1:1:0711/225431.256288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1808, 7fbb34a788db
[1:1:0711/225431.332675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1778 0x7fbb32133070 0x98a2e1ac60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.332984:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1778 0x7fbb32133070 0x98a2e1ac60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.333385:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1832
[1:1:0711/225431.333576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1832 0x7fbb32133070 0x98a2f97f60 , 5:3_http://home.365jia.cn/, 0, , 1808 0x7fbb32133070 0x98a2e46b60 
[1:1:0711/225431.333877:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225431.334393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225431.334568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.368059:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1825, 7fbb34a788db
[1:1:0711/225431.391368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1791 0x7fbb32133070 0x98a20362e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.391560:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1791 0x7fbb32133070 0x98a20362e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.391777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1836
[1:1:0711/225431.391887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1836 0x7fbb32133070 0x98a2040760 , 5:3_http://home.365jia.cn/, 0, , 1825 0x7fbb32133070 0x98a2e1ac60 
[1:1:0711/225431.392142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225431.392429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225431.392532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.513321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225431.513560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.590022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1829, 7fbb34a78881
[1:1:0711/225431.660693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1800 0x7fbb32133070 0x98a2db24e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.661035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1800 0x7fbb32133070 0x98a2db24e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.661381:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225431.661890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225431.662073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.662667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225431.662817:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225431.663182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1847
[1:1:0711/225431.663368:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1847 0x7fbb32133070 0x98a2772e60 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1829 0x7fbb32133070 0x98a2f009e0 
[1:1:0711/225431.725586:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1836, 7fbb34a788db
[1:1:0711/225431.749397:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1825 0x7fbb32133070 0x98a2e1ac60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.749583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1825 0x7fbb32133070 0x98a2e1ac60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.749806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1851
[1:1:0711/225431.749918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1851 0x7fbb32133070 0x98a2deaae0 , 5:3_http://home.365jia.cn/, 0, , 1836 0x7fbb32133070 0x98a2040760 
[1:1:0711/225431.750183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225431.750769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225431.751004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.792751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225431.792925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225431.910761:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1832, 7fbb34a788db
[1:1:0711/225431.980551:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1808 0x7fbb32133070 0x98a2e46b60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.980833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1808 0x7fbb32133070 0x98a2e46b60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225431.981250:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1859
[1:1:0711/225431.981448:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1859 0x7fbb32133070 0x98a2d770e0 , 5:3_http://home.365jia.cn/, 0, , 1832 0x7fbb32133070 0x98a2f97f60 
[1:1:0711/225431.981783:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225431.982283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225431.982459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.034974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1689, 7fbb34a788db
[1:1:0711/225432.109583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1481 0x7fbb32133070 0x98a2daf060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.109921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1481 0x7fbb32133070 0x98a2daf060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.110443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1863
[1:1:0711/225432.110695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1863 0x7fbb32133070 0x98a2dbf860 , 5:3_http://home.365jia.cn/, 0, , 1689 0x7fbb32133070 0x98a2f67b60 
[1:1:0711/225432.111070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225432.111712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/225432.111977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.115486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1847, 7fbb34a78881
[1:1:0711/225432.161686:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1829 0x7fbb32133070 0x98a2f009e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.161996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1829 0x7fbb32133070 0x98a2f009e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.162410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225432.162916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225432.163099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.163733:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225432.163890:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225432.164257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1871
[1:1:0711/225432.164453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1871 0x7fbb32133070 0x98a2e20660 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1847 0x7fbb32133070 0x98a2772e60 
[1:1:0711/225432.298106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1851, 7fbb34a788db
[1:1:0711/225432.321211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1836 0x7fbb32133070 0x98a2040760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.321401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1836 0x7fbb32133070 0x98a2040760 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.321631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1876
[1:1:0711/225432.321741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1876 0x7fbb32133070 0x98a25352e0 , 5:3_http://home.365jia.cn/, 0, , 1851 0x7fbb32133070 0x98a2deaae0 
[1:1:0711/225432.321926:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225432.322238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225432.322343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.424029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225432.424316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.579428:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1859, 7fbb34a788db
[1:1:0711/225432.607367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1832 0x7fbb32133070 0x98a2f97f60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.607561:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1832 0x7fbb32133070 0x98a2f97f60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.607785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1883
[1:1:0711/225432.607895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1883 0x7fbb32133070 0x98a34d98e0 , 5:3_http://home.365jia.cn/, 0, , 1859 0x7fbb32133070 0x98a2d770e0 
[1:1:0711/225432.608074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225432.608386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225432.608494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.748554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1871, 7fbb34a78881
[1:1:0711/225432.770727:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1847 0x7fbb32133070 0x98a2772e60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.770925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1847 0x7fbb32133070 0x98a2772e60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.771132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225432.771459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225432.771585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.771883:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225432.771980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225432.772151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1888
[1:1:0711/225432.772262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1888 0x7fbb32133070 0x98a2dea860 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1871 0x7fbb32133070 0x98a2e20660 
[1:1:0711/225432.797440:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1876, 7fbb34a788db
[1:1:0711/225432.821728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1851 0x7fbb32133070 0x98a2deaae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.821912:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1851 0x7fbb32133070 0x98a2deaae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225432.822141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1889
[1:1:0711/225432.822253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1889 0x7fbb32133070 0x98a2e463e0 , 5:3_http://home.365jia.cn/, 0, , 1876 0x7fbb32133070 0x98a25352e0 
[1:1:0711/225432.822459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225432.822740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225432.822841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225432.851645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225432.851819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.115813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1889, 7fbb34a788db
[1:1:0711/225433.172331:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1876 0x7fbb32133070 0x98a25352e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.172570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1876 0x7fbb32133070 0x98a25352e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.172795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1902
[1:1:0711/225433.172907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1902 0x7fbb32133070 0x98a2f136e0 , 5:3_http://home.365jia.cn/, 0, , 1889 0x7fbb32133070 0x98a2e463e0 
[1:1:0711/225433.173104:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225433.173411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225433.173516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.197781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225433.197959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.199390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1888, 7fbb34a78881
[1:1:0711/225433.235143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1871 0x7fbb32133070 0x98a2e20660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.235439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1871 0x7fbb32133070 0x98a2e20660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.235777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225433.236187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225433.236330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.236773:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225433.236908:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225433.237147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1908
[1:1:0711/225433.237302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1908 0x7fbb32133070 0x98a2f9ad60 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1888 0x7fbb32133070 0x98a2dea860 
[1:1:0711/225433.297332:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1883, 7fbb34a788db
[1:1:0711/225433.320113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1859 0x7fbb32133070 0x98a2d770e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.320297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1859 0x7fbb32133070 0x98a2d770e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.320541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1911
[1:1:0711/225433.320659:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1911 0x7fbb32133070 0x98a2746460 , 5:3_http://home.365jia.cn/, 0, , 1883 0x7fbb32133070 0x98a34d98e0 
[1:1:0711/225433.320833:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225433.321130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225433.321235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.347376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1902, 7fbb34a788db
[1:1:0711/225433.373578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1889 0x7fbb32133070 0x98a2e463e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.373763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1889 0x7fbb32133070 0x98a2e463e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.373983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1914
[1:1:0711/225433.374095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1914 0x7fbb32133070 0x98a2e48ce0 , 5:3_http://home.365jia.cn/, 0, , 1902 0x7fbb32133070 0x98a2f136e0 
[1:1:0711/225433.374286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225433.374598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225433.374703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.611669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225433.611853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.644652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1908, 7fbb34a78881
[1:1:0711/225433.678004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1888 0x7fbb32133070 0x98a2dea860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.678210:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1888 0x7fbb32133070 0x98a2dea860 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.678417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225433.678753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225433.678862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.679158:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225433.679255:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225433.679426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1925
[1:1:0711/225433.679592:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1925 0x7fbb32133070 0x98a16aefe0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1908 0x7fbb32133070 0x98a2f9ad60 
[1:1:0711/225433.704431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1914, 7fbb34a788db
[1:1:0711/225433.751715:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1902 0x7fbb32133070 0x98a2f136e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.752060:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1902 0x7fbb32133070 0x98a2f136e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.752581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1926
[1:1:0711/225433.752829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1926 0x7fbb32133070 0x98a28acae0 , 5:3_http://home.365jia.cn/, 0, , 1914 0x7fbb32133070 0x98a2e48ce0 
[1:1:0711/225433.753207:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225433.753847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225433.754068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.757377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1911, 7fbb34a788db
[1:1:0711/225433.823619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1883 0x7fbb32133070 0x98a34d98e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.823899:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1883 0x7fbb32133070 0x98a34d98e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225433.824293:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1929
[1:1:0711/225433.824486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1929 0x7fbb32133070 0x98a2f4a260 , 5:3_http://home.365jia.cn/, 0, , 1911 0x7fbb32133070 0x98a2746460 
[1:1:0711/225433.824911:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225433.825528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225433.825790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.915519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225433.915725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225433.978890:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1925, 7fbb34a78881
[1:1:0711/225434.065275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1908 0x7fbb32133070 0x98a2f9ad60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.065628:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1908 0x7fbb32133070 0x98a2f9ad60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.065989:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225434.067108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225434.067283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225434.068003:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225434.068220:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225434.068841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1938
[1:1:0711/225434.069096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1938 0x7fbb32133070 0x98a2f595e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1925 0x7fbb32133070 0x98a16aefe0 
[1:1:0711/225434.070201:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1926, 7fbb34a788db
[1:1:0711/225434.108375:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1914 0x7fbb32133070 0x98a2e48ce0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.108553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1914 0x7fbb32133070 0x98a2e48ce0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.108855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1945
[1:1:0711/225434.108969:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1945 0x7fbb32133070 0x98a2dad660 , 5:3_http://home.365jia.cn/, 0, , 1926 0x7fbb32133070 0x98a28acae0 
[1:1:0711/225434.109147:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225434.109459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225434.109606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225434.236530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225434.236808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225434.361129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1929, 7fbb34a788db
[1:1:0711/225434.394432:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1911 0x7fbb32133070 0x98a2746460 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.394726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1911 0x7fbb32133070 0x98a2746460 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.395032:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1958
[1:1:0711/225434.395188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1958 0x7fbb32133070 0x98a28acae0 , 5:3_http://home.365jia.cn/, 0, , 1929 0x7fbb32133070 0x98a2f4a260 
[1:1:0711/225434.395451:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225434.395869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225434.396016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225434.798950:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1945, 7fbb34a788db
[1:1:0711/225434.821981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1926 0x7fbb32133070 0x98a28acae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.822162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1926 0x7fbb32133070 0x98a28acae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.822381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1969
[1:1:0711/225434.822491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1969 0x7fbb32133070 0x98a2da9ee0 , 5:3_http://home.365jia.cn/, 0, , 1945 0x7fbb32133070 0x98a2dad660 
[1:1:0711/225434.822674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225434.822977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225434.823085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225434.823896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1938, 7fbb34a78881
[1:1:0711/225434.853706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1925 0x7fbb32133070 0x98a16aefe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.853992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1925 0x7fbb32133070 0x98a16aefe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225434.854266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225434.854674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225434.854853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225434.855276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225434.855410:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225434.855648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1970
[1:1:0711/225434.855840:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1970 0x7fbb32133070 0x98a2e386e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1938 0x7fbb32133070 0x98a2f595e0 
[1:1:0711/225434.893217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225434.893439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225434.967739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1958, 7fbb34a788db
[1:1:0711/225435.040603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1929 0x7fbb32133070 0x98a2f4a260 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.040911:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1929 0x7fbb32133070 0x98a2f4a260 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.041308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1977
[1:1:0711/225435.041497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1977 0x7fbb32133070 0x98a356f660 , 5:3_http://home.365jia.cn/, 0, , 1958 0x7fbb32133070 0x98a28acae0 
[1:1:0711/225435.041835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225435.042317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225435.042490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225435.169318:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1969, 7fbb34a788db
[1:1:0711/225435.240040:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1945 0x7fbb32133070 0x98a2dad660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.240316:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1945 0x7fbb32133070 0x98a2dad660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.240705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1981
[1:1:0711/225435.240937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1981 0x7fbb32133070 0x98a2746460 , 5:3_http://home.365jia.cn/, 0, , 1969 0x7fbb32133070 0x98a2da9ee0 
[1:1:0711/225435.241375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225435.241990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225435.242211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225435.394490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225435.394793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225435.399719:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1970, 7fbb34a78881
[1:1:0711/225435.476201:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1938 0x7fbb32133070 0x98a2f595e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.476513:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1938 0x7fbb32133070 0x98a2f595e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.476937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225435.477443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225435.477616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225435.478252:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225435.478410:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225435.478748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1989
[1:1:0711/225435.478966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1989 0x7fbb32133070 0x98a2de1e60 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1970 0x7fbb32133070 0x98a2e386e0 
[1:1:0711/225435.553214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1981, 7fbb34a788db
[1:1:0711/225435.631185:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1969 0x7fbb32133070 0x98a2da9ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.631599:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1969 0x7fbb32133070 0x98a2da9ee0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.632122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1997
[1:1:0711/225435.632378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1997 0x7fbb32133070 0x98a31723e0 , 5:3_http://home.365jia.cn/, 0, , 1981 0x7fbb32133070 0x98a2746460 
[1:1:0711/225435.632755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225435.633311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225435.633489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225435.831189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , document.readyState
[1:1:0711/225435.831364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225435.833028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1977, 7fbb34a788db
[1:1:0711/225435.859327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1958 0x7fbb32133070 0x98a28acae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.859516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1958 0x7fbb32133070 0x98a28acae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225435.859746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2005
[1:1:0711/225435.859862:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2005 0x7fbb32133070 0x98a1bf7fe0 , 5:3_http://home.365jia.cn/, 0, , 1977 0x7fbb32133070 0x98a356f660 
[1:1:0711/225435.860101:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225435.860391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225435.860495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225436.214338:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 1989, 7fbb34a78881
[1:1:0711/225436.277308:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1970 0x7fbb32133070 0x98a2e386e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225436.277514:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1970 0x7fbb32133070 0x98a2e386e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225436.277720:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225436.278023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225436.278169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225436.278475:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225436.278642:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225436.279047:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2019
[1:1:0711/225436.279351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2019 0x7fbb32133070 0x98a2dd8260 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 1989 0x7fbb32133070 0x98a2de1e60 
[1:1:0711/225436.281397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1997, 7fbb34a788db
[1:1:0711/225436.331977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1981 0x7fbb32133070 0x98a2746460 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225436.332238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1981 0x7fbb32133070 0x98a2746460 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225436.332468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2022
[1:1:0711/225436.332579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2022 0x7fbb32133070 0x98a2de51e0 , 5:3_http://home.365jia.cn/, 0, , 1997 0x7fbb32133070 0x98a31723e0 
[1:1:0711/225436.332763:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225436.333058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225436.333194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225436.334103:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2005, 7fbb34a788db
[1:1:0711/225436.366704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1977 0x7fbb32133070 0x98a356f660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225436.366887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1977 0x7fbb32133070 0x98a356f660 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225436.367116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2025
[1:1:0711/225436.367233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2025 0x7fbb32133070 0x98a2de5de0 , 5:3_http://home.365jia.cn/, 0, , 2005 0x7fbb32133070 0x98a1bf7fe0 
[1:1:0711/225436.367407:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225436.367688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225436.367792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225437.137053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2022, 7fbb34a788db
[1:1:0711/225437.213229:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1997 0x7fbb32133070 0x98a31723e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.213526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1997 0x7fbb32133070 0x98a31723e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.213928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2047
[1:1:0711/225437.214117:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2047 0x7fbb32133070 0x98a2db1fe0 , 5:3_http://home.365jia.cn/, 0, , 2022 0x7fbb32133070 0x98a2de51e0 
[1:1:0711/225437.214466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.214947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225437.215119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225437.217697:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2019, 7fbb34a78881
[1:1:0711/225437.293220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"1989 0x7fbb32133070 0x98a2de1e60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.293557:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"1989 0x7fbb32133070 0x98a2de1e60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.293909:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.294430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225437.294607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225437.295203:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225437.295384:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225437.295712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2050
[1:1:0711/225437.295903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2050 0x7fbb32133070 0x98a34ceae0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 2019 0x7fbb32133070 0x98a2dd8260 
[1:1:0711/225437.297972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2025, 7fbb34a788db
[1:1:0711/225437.363873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2005 0x7fbb32133070 0x98a1bf7fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.364068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2005 0x7fbb32133070 0x98a1bf7fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.364290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2054
[1:1:0711/225437.364446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2054 0x7fbb32133070 0x98a1a73360 , 5:3_http://home.365jia.cn/, 0, , 2025 0x7fbb32133070 0x98a2de5de0 
[1:1:0711/225437.364632:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.364911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225437.365015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225437.501152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 1863, 7fbb34a788db
[1:1:0711/225437.524588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1689 0x7fbb32133070 0x98a2f67b60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.524763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1689 0x7fbb32133070 0x98a2f67b60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.524977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2061
[1:1:0711/225437.525088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2061 0x7fbb32133070 0x98a2e20de0 , 5:3_http://home.365jia.cn/, 0, , 1863 0x7fbb32133070 0x98a2dbf860 
[1:1:0711/225437.525265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.525578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/225437.525682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225437.551444:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2047, 7fbb34a788db
[1:1:0711/225437.622428:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2022 0x7fbb32133070 0x98a2de51e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.622701:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2022 0x7fbb32133070 0x98a2de51e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.623083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2065
[1:1:0711/225437.623272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2065 0x7fbb32133070 0x98a3172360 , 5:3_http://home.365jia.cn/, 0, , 2047 0x7fbb32133070 0x98a2db1fe0 
[1:1:0711/225437.623603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.624072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225437.624242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[30719:30719:0711/225437.759984:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/225437.772765:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2050, 7fbb34a78881
[1:1:0711/225437.847595:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"2019 0x7fbb32133070 0x98a2dd8260 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.847901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"2019 0x7fbb32133070 0x98a2dd8260 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.848249:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.848777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225437.848952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225437.849572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225437.849739:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225437.850186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2070
[1:1:0711/225437.850385:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2070 0x7fbb32133070 0x98a19bac60 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 2050 0x7fbb32133070 0x98a34ceae0 
[1:1:0711/225437.852422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2054, 7fbb34a788db
[1:1:0711/225437.906541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2025 0x7fbb32133070 0x98a2de5de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.906725:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2025 0x7fbb32133070 0x98a2de5de0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.906945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2073
[1:1:0711/225437.907054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2073 0x7fbb32133070 0x98a3760a60 , 5:3_http://home.365jia.cn/, 0, , 2054 0x7fbb32133070 0x98a1a73360 
[1:1:0711/225437.907236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.907543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225437.907648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225437.927891:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2065, 7fbb34a788db
[1:1:0711/225437.954701:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2047 0x7fbb32133070 0x98a2db1fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.954942:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2047 0x7fbb32133070 0x98a2db1fe0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225437.955244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2076
[1:1:0711/225437.955414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2076 0x7fbb32133070 0x98a1d910e0 , 5:3_http://home.365jia.cn/, 0, , 2065 0x7fbb32133070 0x98a3172360 
[1:1:0711/225437.955677:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225437.956056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225437.956205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225438.006500:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2070, 7fbb34a78881
[1:1:0711/225438.033099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"2050 0x7fbb32133070 0x98a34ceae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.033296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"2050 0x7fbb32133070 0x98a34ceae0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.033525:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225438.033826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225438.033932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225438.034220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225438.034315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225438.034480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2082
[1:1:0711/225438.034609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2082 0x7fbb32133070 0x98a2f00360 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 2070 0x7fbb32133070 0x98a19bac60 
[1:1:0711/225438.106835:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2076, 7fbb34a788db
[1:1:0711/225438.149078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2065 0x7fbb32133070 0x98a3172360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.149437:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2065 0x7fbb32133070 0x98a3172360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.149990:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2091
[1:1:0711/225438.150234:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2091 0x7fbb32133070 0x98a3760e60 , 5:3_http://home.365jia.cn/, 0, , 2076 0x7fbb32133070 0x98a1d910e0 
[1:1:0711/225438.150621:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225438.151213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225438.151452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225438.268195:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2073, 7fbb34a788db
[1:1:0711/225438.300051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2054 0x7fbb32133070 0x98a1a73360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.300296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2054 0x7fbb32133070 0x98a1a73360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.300630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2098
[1:1:0711/225438.300791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2098 0x7fbb32133070 0x98a19ba960 , 5:3_http://home.365jia.cn/, 0, , 2073 0x7fbb32133070 0x98a3760a60 
[1:1:0711/225438.301051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225438.301446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225438.301612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225438.805529:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2082, 7fbb34a78881
[1:1:0711/225438.886133:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"2070 0x7fbb32133070 0x98a19bac60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.886443:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"2070 0x7fbb32133070 0x98a19bac60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.886813:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225438.887315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225438.887488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225438.888138:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225438.888304:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225438.888625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2113
[1:1:0711/225438.888836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2113 0x7fbb32133070 0x98a28acd60 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 2082 0x7fbb32133070 0x98a2f00360 
[1:1:0711/225438.890785:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2091, 7fbb34a788db
[1:1:0711/225438.949503:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2076 0x7fbb32133070 0x98a1d910e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.949689:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2076 0x7fbb32133070 0x98a1d910e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.949939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2116
[1:1:0711/225438.950048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2116 0x7fbb32133070 0x98a2d770e0 , 5:3_http://home.365jia.cn/, 0, , 2091 0x7fbb32133070 0x98a3760e60 
[1:1:0711/225438.950219:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225438.950494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225438.950597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225438.951774:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2098, 7fbb34a788db
[1:1:0711/225438.975975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2073 0x7fbb32133070 0x98a3760a60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.976148:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2073 0x7fbb32133070 0x98a3760a60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225438.976366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2119
[1:1:0711/225438.976475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2119 0x7fbb32133070 0x98a1bfda60 , 5:3_http://home.365jia.cn/, 0, , 2098 0x7fbb32133070 0x98a19ba960 
[1:1:0711/225438.976644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225438.976948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225438.977054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.120134:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2113, 7fbb34a78881
[1:1:0711/225439.144582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"2082 0x7fbb32133070 0x98a2f00360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.144797:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"2082 0x7fbb32133070 0x98a2f00360 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.145008:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.145300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225439.145416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.145703:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225439.145818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225439.145990:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2128
[1:1:0711/225439.146098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2128 0x7fbb32133070 0x98a1990560 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 2113 0x7fbb32133070 0x98a28acd60 
[1:1:0711/225439.146641:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2116, 7fbb34a788db
[1:1:0711/225439.172634:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2091 0x7fbb32133070 0x98a3760e60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.172837:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2091 0x7fbb32133070 0x98a3760e60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.173069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2130
[1:1:0711/225439.173182:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2130 0x7fbb32133070 0x98a2dacf60 , 5:3_http://home.365jia.cn/, 0, , 2116 0x7fbb32133070 0x98a2d770e0 
[1:1:0711/225439.173355:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.173625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225439.173724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.199028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2119, 7fbb34a788db
[1:1:0711/225439.235384:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2098 0x7fbb32133070 0x98a19ba960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.235665:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2098 0x7fbb32133070 0x98a19ba960 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.236097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2132
[1:1:0711/225439.236289:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2132 0x7fbb32133070 0x98a2e9a060 , 5:3_http://home.365jia.cn/, 0, , 2119 0x7fbb32133070 0x98a1bfda60 
[1:1:0711/225439.236585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.237070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225439.237243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.287733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2130, 7fbb34a788db
[1:1:0711/225439.372811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2116 0x7fbb32133070 0x98a2d770e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.373093:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2116 0x7fbb32133070 0x98a2d770e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.373484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2136
[1:1:0711/225439.373674:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2136 0x7fbb32133070 0x98a1d910e0 , 5:3_http://home.365jia.cn/, 0, , 2130 0x7fbb32133070 0x98a2dacf60 
[1:1:0711/225439.374014:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.374491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225439.374675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.440759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2128, 7fbb34a78881
[1:1:0711/225439.495189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"2113 0x7fbb32133070 0x98a28acd60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.495382:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"2113 0x7fbb32133070 0x98a28acd60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.495586:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.495958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225439.496066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.496361:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225439.496459:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225439.496627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2142
[1:1:0711/225439.496737:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2142 0x7fbb32133070 0x98a1957860 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 2128 0x7fbb32133070 0x98a1990560 
[1:1:0711/225439.547209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2136, 7fbb34a788db
[1:1:0711/225439.612915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2130 0x7fbb32133070 0x98a2dacf60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.613224:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2130 0x7fbb32133070 0x98a2dacf60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.613614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2147
[1:1:0711/225439.613805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2147 0x7fbb32133070 0x98a2f1a5e0 , 5:3_http://home.365jia.cn/, 0, , 2136 0x7fbb32133070 0x98a1d910e0 
[1:1:0711/225439.614133:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.614611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225439.614787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.831773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2132, 7fbb34a788db
[1:1:0711/225439.871768:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2119 0x7fbb32133070 0x98a1bfda60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.871990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2119 0x7fbb32133070 0x98a1bfda60 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.872220:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2156
[1:1:0711/225439.872330:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2156 0x7fbb32133070 0x98a1c20de0 , 5:3_http://home.365jia.cn/, 0, , 2132 0x7fbb32133070 0x98a2e9a060 
[1:1:0711/225439.872513:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.872805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225439.872931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.897811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2142, 7fbb34a78881
[1:1:0711/225439.961179:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"15dc05082860","ptid":"2128 0x7fbb32133070 0x98a1990560 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.961579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://home.365jia.cn/","ptid":"2128 0x7fbb32133070 0x98a1990560 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225439.962054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225439.962697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/225439.962949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225439.963757:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a911df629c8, 0x98a157c950
[1:1:0711/225439.964005:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://home.365jia.cn/", 100
[1:1:0711/225439.964419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2159
[1:1:0711/225439.964666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2159 0x7fbb32133070 0x98a197c1e0 , 5:3_http://home.365jia.cn/, 1, -5:3_http://home.365jia.cn/, 2142 0x7fbb32133070 0x98a1957860 
[1:1:0711/225439.967683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2147, 7fbb34a788db
[1:1:0711/225440.050519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2136 0x7fbb32133070 0x98a1d910e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225440.050907:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2136 0x7fbb32133070 0x98a1d910e0 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225440.051479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2162
[1:1:0711/225440.051766:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2162 0x7fbb32133070 0x98a2df74e0 , 5:3_http://home.365jia.cn/, 0, , 2147 0x7fbb32133070 0x98a2f1a5e0 
[1:1:0711/225440.052242:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225440.052904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225440.053118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0711/225440.476377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2156, 7fbb34a788db
[1:1:0711/225440.570423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"2132 0x7fbb32133070 0x98a2e9a060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225440.570700:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"2132 0x7fbb32133070 0x98a2e9a060 ","rf":"5:3_http://home.365jia.cn/"}
[1:1:0711/225440.571097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://home.365jia.cn/, 2179
[1:1:0711/225440.571421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2179 0x7fbb32133070 0x98a2e13860 , 5:3_http://home.365jia.cn/, 0, , 2156 0x7fbb32133070 0x98a1c20de0 
[1:1:0711/225440.571791:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://home.365jia.cn/"
[1:1:0711/225440.572365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://home.365jia.cn/, 15dc05082860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0711/225440.572580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://home.365jia.cn/", "home.365jia.cn", 3, 1, , , 0
[1:1:0100/000000.620671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://home.365jia.cn/, 2159, 7fbb34a78881
