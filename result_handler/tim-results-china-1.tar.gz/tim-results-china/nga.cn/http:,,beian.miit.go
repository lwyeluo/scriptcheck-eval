[0713/020340.394084:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/020340.394430:INFO:switcher_clone.cc(787)] backtrace rip is 7f45e09be891
[0713/020341.481938:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/020341.482301:INFO:switcher_clone.cc(787)] backtrace rip is 7fd393fbb891
[1:1:0713/020341.493302:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/020341.493567:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/020341.504124:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[39099:39099:0713/020342.790792:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/7309c936-5364-4771-b09d-345ef85104f5
[0713/020343.028284:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/020343.028664:INFO:switcher_clone.cc(787)] backtrace rip is 7fb3e217a891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[39132:39132:0713/020343.237993:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=39132
[39143:39143:0713/020343.238454:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=39143
[39099:39099:0713/020343.349991:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[39099:39129:0713/020343.350704:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/020343.350931:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/020343.351165:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/020343.351771:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/020343.351961:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/020343.354928:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x39d2de71, 1
[1:1:0713/020343.355284:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2fcc8fff, 0
[1:1:0713/020343.355501:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xe01cada, 3
[1:1:0713/020343.355735:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x7fc43ec, 2
[1:1:0713/020343.355988:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffffffffff8fffffffcc2f 71ffffffdeffffffd239 ffffffec43fffffffc07 ffffffdaffffffca010e , 10104, 4
[1:1:0713/020343.357235:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[39099:39129:0713/020343.357548:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���/q��9�C���Ž�+
[39099:39129:0713/020343.357644:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���/q��9�C�����Ž�+
[1:1:0713/020343.357530:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3921f60a0, 3
[1:1:0713/020343.357792:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd392381080, 2
[39099:39129:0713/020343.358010:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/020343.357983:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd37c044d20, -2
[39099:39129:0713/020343.358093:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 39151, 4, ff8fcc2f 71ded239 ec43fc07 daca010e 
[1:1:0713/020343.379127:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/020343.380086:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7fc43ec
[1:1:0713/020343.381188:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7fc43ec
[1:1:0713/020343.383071:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7fc43ec
[1:1:0713/020343.384880:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.385116:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.385339:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.385606:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.386280:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7fc43ec
[1:1:0713/020343.386682:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd393fbb7ba
[1:1:0713/020343.386856:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd393fb2def, 7fd393fbb77a, 7fd393fbd0cf
[1:1:0713/020343.390209:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7fc43ec
[1:1:0713/020343.390623:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7fc43ec
[1:1:0713/020343.391380:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7fc43ec
[1:1:0713/020343.393359:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.393599:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.393814:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.394027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc43ec
[1:1:0713/020343.394769:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7fc43ec
[1:1:0713/020343.395168:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd393fbb7ba
[1:1:0713/020343.395345:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd393fb2def, 7fd393fbb77a, 7fd393fbd0cf
[1:1:0713/020343.398274:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/020343.398757:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/020343.398940:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd346c7cf8, 0x7ffd346c7c78)
[1:1:0713/020343.415400:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/020343.421301:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[39099:39099:0713/020344.014722:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39099:39099:0713/020344.015819:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[39099:39110:0713/020344.033472:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[39099:39110:0713/020344.033565:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[39099:39099:0713/020344.034922:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[39099:39099:0713/020344.035001:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[39099:39099:0713/020344.035135:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,39151, 4
[1:7:0713/020344.038964:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[39099:39121:0713/020344.085207:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/020344.131112:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xde7eb1ee220
[1:1:0713/020344.131417:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/020344.508834:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[39099:39099:0713/020346.228809:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[39099:39099:0713/020346.228930:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/020346.272206:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020346.275816:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/020347.248393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 294ab78e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/020347.248710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020347.279160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 294ab78e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/020347.279469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020347.329861:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/020347.511202:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020347.511444:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020347.898789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020347.901437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 294ab78e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/020347.901586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020347.917947:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020347.928404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 294ab78e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/020347.928667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020347.940539:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[39099:39099:0713/020347.943688:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/020347.943961:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xde7eb1ece20
[1:1:0713/020347.944139:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[39099:39099:0713/020347.952324:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[39099:39099:0713/020347.975611:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[39099:39099:0713/020347.975775:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/020347.981898:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020348.820512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7fd37dc1f2e0 0xde7eb358e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020348.821835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 294ab78e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/020348.822032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020348.823513:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[39099:39099:0713/020348.889306:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/020348.891284:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xde7eb1ed820
[1:1:0713/020348.891539:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[39099:39099:0713/020348.897102:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/020348.909995:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/020348.910203:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[39099:39099:0713/020348.913803:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[39099:39099:0713/020348.924910:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39099:39099:0713/020348.925932:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[39099:39110:0713/020348.931823:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[39099:39110:0713/020348.931910:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[39099:39099:0713/020348.932068:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[39099:39099:0713/020348.932142:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[39099:39099:0713/020348.932279:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,39151, 4
[1:7:0713/020348.935996:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/020349.598714:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/020350.111140:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7fd37dc1f2e0 0xde7eb46a1e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020350.113591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 294ab78e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/020350.114302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020350.116393:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[39099:39099:0713/020350.271286:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[39099:39099:0713/020350.271436:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/020350.292526:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/020350.952906:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[39099:39099:0713/020351.103489:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[39099:39129:0713/020351.104357:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/020351.104813:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/020351.105199:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/020351.106070:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/020351.106493:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/020351.112415:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36d6567a, 1
[1:1:0713/020351.113413:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xf51f3b8, 0
[1:1:0713/020351.113829:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2b58c49, 3
[1:1:0713/020351.114224:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xa40a844, 2
[1:1:0713/020351.114879:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb8fffffff3510f 7a56ffffffd636 44ffffffa8400a 49ffffff8cffffffb502 , 10104, 5
[1:1:0713/020351.117453:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[39099:39129:0713/020351.118034:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��QzV�6D�@
I��r��+
[39099:39129:0713/020351.118215:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��QzV�6D�@
I��hyr��+
[39099:39129:0713/020351.118749:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 39195, 5, b8f3510f 7a56d636 44a8400a 498cb502 
[1:1:0713/020351.118647:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd3921f60a0, 3
[1:1:0713/020351.119218:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd392381080, 2
[1:1:0713/020351.119625:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd37c044d20, -2
[1:1:0713/020351.136441:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/020351.136671:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a40a844
[1:1:0713/020351.136866:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a40a844
[1:1:0713/020351.137155:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a40a844
[1:1:0713/020351.137663:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.137777:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.137878:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.137980:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.138231:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a40a844
[1:1:0713/020351.138415:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd393fbb7ba
[1:1:0713/020351.138510:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd393fb2def, 7fd393fbb77a, 7fd393fbd0cf
[1:1:0713/020351.140046:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a40a844
[1:1:0713/020351.140231:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a40a844
[1:1:0713/020351.140543:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a40a844
[1:1:0713/020351.141287:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.141425:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.141533:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.141642:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a40a844
[1:1:0713/020351.142121:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a40a844
[1:1:0713/020351.142334:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd393fbb7ba
[1:1:0713/020351.142430:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd393fb2def, 7fd393fbb77a, 7fd393fbd0cf
[1:1:0713/020351.144738:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/020351.145123:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/020351.145230:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd346c7cf8, 0x7ffd346c7c78)
[1:1:0713/020351.165962:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/020351.171824:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/020351.326795:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xde7eb1bb220
[1:1:0713/020351.326993:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/020351.462073:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020351.462404:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[39099:39099:0713/020351.761727:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39099:39099:0713/020351.766801:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[39099:39110:0713/020351.783278:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[39099:39110:0713/020351.783374:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[39099:39099:0713/020351.783783:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[39099:39099:0713/020351.783866:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[39099:39099:0713/020351.784008:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 09:03:51 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: JSESSIONID=25jql1Xm4l5HajffidLt5b9A6Wz1bAwTG-NTBNwILysd1-fxdToJ!-81678781; path=/; HttpOnly Content-Encoding: gzip X-Via-JSL: 17c65b8,- Set-Cookie: __jsluid_h=0ecc59378400533c372e699fcf27495a; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,39195, 5
[1:7:0713/020351.792036:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/020351.841674:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/020351.846935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 294ab7a0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/020351.847551:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[1:1:0713/020351.847237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/020351.855482:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/020351.908416:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[39099:39099:0713/020351.940729:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[39099:39099:0713/020351.940837:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0713/020351.983856:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/020352.079788:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/020352.080049:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/"
[1:1:0713/020352.168889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/020352.169648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 294ab78e1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/020352.169880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/020352.217372:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://beian.miit.gov.cn/styles/styles.css"
[1:1:0713/020352.285321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7fd392381080 0xde7eb2f69c0 1 0 0xde7eb2f69d8 , "http://beian.miit.gov.cn/"
[1:1:0713/020352.291554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 05d26bb22860, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0713/020352.291759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0713/020352.765228:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/020353.086838:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020353.087352:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020353.089966:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020353.090508:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020353.090930:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/020353.299400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7fd392381080 0xde7eb2f69c0 1 0 0xde7eb2f69d8 , "http://beian.miit.gov.cn/"
[1:1:0713/020353.304539:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x364bdeee29c8, 0xde7eb04f9a0
[1:1:0713/020353.304731:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://beian.miit.gov.cn/", 0
[1:1:0713/020353.305135:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 146
[1:1:0713/020353.305337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 146 0x7fd37bcf7070 0xde7eb2cfe60 , 5:3_http://beian.miit.gov.cn/, 1, -5:3_http://beian.miit.gov.cn/, 139 0x7fd392381080 0xde7eb2f69c0 1 0 0xde7eb2f69d8 
[1:1:0713/020353.313473:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://beian.miit.gov.cn/"
[1:1:0713/020353.373197:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/020353.373349:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
[1:1:0713/020353.391112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 146, 7fd37e63c881
[1:1:0713/020353.399941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05d26bb22860","ptid":"139 0x7fd392381080 0xde7eb2f69c0 1 0 0xde7eb2f69d8 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0713/020353.400252:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://beian.miit.gov.cn/","ptid":"139 0x7fd392381080 0xde7eb2f69c0 1 0 0xde7eb2f69d8 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0713/020353.400551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://beian.miit.gov.cn/"
[1:1:0713/020353.401400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 05d26bb22860, , , (){if(D.isReady)return;if(document.readyState!="loaded"&&document.readyState!="complete"){setTimeout
[1:1:0713/020353.401614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0713/020428.031628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 05d26bb22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/020428.031871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[39099:39099:0713/020428.436091:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[39099:39099:0713/020428.489311:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/020428.508206:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
