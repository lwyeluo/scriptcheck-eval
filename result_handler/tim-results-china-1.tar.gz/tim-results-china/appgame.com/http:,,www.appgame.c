[0712/095325.905456:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095325.905882:INFO:switcher_clone.cc(787)] backtrace rip is 7fd0fddb9891
[0712/095327.023463:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095327.024012:INFO:switcher_clone.cc(787)] backtrace rip is 7fc05ce57891
[1:1:0712/095327.038461:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/095327.038797:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/095327.044903:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[119522:119522:0712/095328.287603:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6ebd7c4b-3e39-48e5-b51e-7493e52cbd52
[0712/095328.589556:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095328.589932:INFO:switcher_clone.cc(787)] backtrace rip is 7f6ec3110891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[119522:119522:0712/095328.788219:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[119522:119552:0712/095328.788955:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/095328.789159:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095328.789446:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095328.790032:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095328.790181:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/095328.793435:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1e5646e9, 1
[1:1:0712/095328.793785:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15028b00, 0
[1:1:0712/095328.793962:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10b3c443, 3
[1:1:0712/095328.794121:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x70a5664, 2
[1:1:0712/095328.794344:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 00ffffff8b0215 ffffffe946561e 64560a07 43ffffffc4ffffffb310 , 10104, 4
[1:1:0712/095328.795408:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119522:119552:0712/095328.795631:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING
[119522:119552:0712/095328.795672:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 
[1:1:0712/095328.795629:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc05b0920a0, 3
[1:1:0712/095328.795844:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc05b21d080, 2
[119522:119552:0712/095328.795981:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[119522:119552:0712/095328.796008:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119568, 4, 008b0215 e946561e 64560a07 43c4b310 
[1:1:0712/095328.796002:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc044ee0d20, -2
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/095328.816100:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095328.817010:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 70a5664
[1:1:0712/095328.817997:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 70a5664
[1:1:0712/095328.819624:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 70a5664
[1:1:0712/095328.821206:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[119554:119554:0712/095328.821278:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119554
[1:1:0712/095328.821425:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[1:1:0712/095328.821614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[119569:119569:0712/095328.821757:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119569
[1:1:0712/095328.821791:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[1:1:0712/095328.822559:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 70a5664
[1:1:0712/095328.822966:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc05ce577ba
[1:1:0712/095328.823153:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc05ce4edef, 7fc05ce5777a, 7fc05ce590cf
[1:1:0712/095328.828894:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 70a5664
[1:1:0712/095328.829168:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 70a5664
[1:1:0712/095328.829584:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 70a5664
[1:1:0712/095328.830712:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[1:1:0712/095328.830853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[1:1:0712/095328.831042:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[1:1:0712/095328.831182:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 70a5664
[1:1:0712/095328.831690:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 70a5664
[1:1:0712/095328.831991:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc05ce577ba
[1:1:0712/095328.832068:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc05ce4edef, 7fc05ce5777a, 7fc05ce590cf
[1:1:0712/095328.834794:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095328.835045:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095328.835134:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc9733b928, 0x7ffc9733b8a8)
[1:1:0712/095328.850397:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095328.857511:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[119522:119522:0712/095329.363749:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119522:119522:0712/095329.366962:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119522:119534:0712/095329.388788:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[119522:119534:0712/095329.388920:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[119522:119522:0712/095329.389050:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[119522:119522:0712/095329.389134:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[119522:119522:0712/095329.389270:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,119568, 4
[1:7:0712/095329.391613:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[119522:119546:0712/095329.433161:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/095329.538081:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1ff8d9647220
[1:1:0712/095329.538444:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/095329.923807:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/095331.353854:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095331.358337:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[119522:119522:0712/095331.521473:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[119522:119522:0712/095331.521580:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095332.294963:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095332.462256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21e1aea41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095332.462565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095332.478782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21e1aea41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095332.478972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095332.587910:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095332.588180:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095332.822443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095332.825051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21e1aea41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095332.825198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095332.851523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095332.861864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21e1aea41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095332.862067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095332.873672:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/095332.877563:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1ff8d9645e20
[1:1:0712/095332.877723:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[119522:119522:0712/095332.881210:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[119522:119522:0712/095332.895054:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[119522:119522:0712/095332.934572:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[119522:119522:0712/095332.934728:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095332.973951:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095333.712679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7fc046abb2e0 0x1ff8d988b960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095333.713374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21e1aea41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/095333.713504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095333.714057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119522:119522:0712/095333.774277:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/095333.776608:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1ff8d9646820
[1:1:0712/095333.776816:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[119522:119522:0712/095333.781485:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/095333.793121:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/095333.793317:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[119522:119522:0712/095333.799322:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[119522:119522:0712/095333.810409:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119522:119522:0712/095333.811462:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119522:119534:0712/095333.817608:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[119522:119534:0712/095333.817696:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[119522:119522:0712/095333.817877:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[119522:119522:0712/095333.817954:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[119522:119522:0712/095333.818092:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,119568, 4
[1:7:0712/095333.820576:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095334.421250:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/095334.873389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fc046abb2e0 0x1ff8d98af6e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095334.874484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21e1aea41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/095334.874732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095334.875464:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119522:119522:0712/095334.976852:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[119522:119522:0712/095334.977009:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/095334.985659:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095335.256760:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095335.850274:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095335.850573:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[119522:119522:0712/095335.888509:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[119522:119552:0712/095335.888986:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/095335.889208:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095335.889470:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095335.889893:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095335.890042:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/095335.893012:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x14418464, 1
[1:1:0712/095335.893414:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x241a0bd3, 0
[1:1:0712/095335.893613:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1000fcfd, 3
[1:1:0712/095335.893818:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x34af67c9, 2
[1:1:0712/095335.894006:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd30b1a24 64ffffff844114 ffffffc967ffffffaf34 fffffffdfffffffc0010 , 10104, 5
[1:1:0712/095335.895097:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119522:119552:0712/095335.895389:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�$d�A�g�4��
[119522:119552:0712/095335.895459:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �$d�A�g�4��
[1:1:0712/095335.895383:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc05b0920a0, 3
[1:1:0712/095335.895665:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc05b21d080, 2
[119522:119552:0712/095335.895760:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119618, 5, d30b1a24 64844114 c967af34 fdfc0010 
[1:1:0712/095335.895942:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc044ee0d20, -2
[1:1:0712/095335.917516:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095335.917922:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34af67c9
[1:1:0712/095335.918252:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34af67c9
[1:1:0712/095335.918922:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34af67c9
[1:1:0712/095335.920488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.920732:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.920999:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.921276:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.921966:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34af67c9
[1:1:0712/095335.922290:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc05ce577ba
[1:1:0712/095335.922480:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc05ce4edef, 7fc05ce5777a, 7fc05ce590cf
[1:1:0712/095335.927966:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 34af67c9
[1:1:0712/095335.928352:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 34af67c9
[1:1:0712/095335.929161:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 34af67c9
[1:1:0712/095335.931584:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.931906:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.932140:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.932397:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 34af67c9
[1:1:0712/095335.933626:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 34af67c9
[1:1:0712/095335.934025:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc05ce577ba
[1:1:0712/095335.934195:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc05ce4edef, 7fc05ce5777a, 7fc05ce590cf
[1:1:0712/095335.941726:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095335.942268:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095335.942462:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc9733b928, 0x7ffc9733b8a8)
[1:1:0712/095335.956770:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095335.961578:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/095336.196423:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1ff8d9623220
[1:1:0712/095336.196704:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/095336.245584:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 543, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095336.250804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21e1aeb6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/095336.251122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095336.259187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[119522:119522:0712/095336.583636:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119522:119522:0712/095336.588544:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119522:119534:0712/095336.612139:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[119522:119534:0712/095336.612230:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[119522:119522:0712/095336.618818:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.appgame.com/
[119522:119522:0712/095336.618891:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.appgame.com/, http://www.appgame.com/, 1
[119522:119522:0712/095336.618993:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.appgame.com/, HTTP/1.1 200 OK Server: nginx/1.10.3 (Ubuntu) Date: Fri, 12 Jul 2019 16:53:36 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Link: <http://www.appgame.com/wp-json/>; rel="https://api.w.org/" X-Cache-Debug: /     Content-Encoding: gzip  ,119618, 5
[1:7:0712/095336.622025:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095336.639827:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.appgame.com/
[119522:119522:0712/095336.798145:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.appgame.com/, http://www.appgame.com/, 1
[119522:119522:0712/095336.798277:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.appgame.com/, http://www.appgame.com
[1:1:0712/095336.832632:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095336.965050:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095337.089449:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095337.089723:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.appgame.com/"
[1:1:0712/095337.164265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 120 0x7fc044b93070 0x1ff8d96325e0 , "http://www.appgame.com/"
[1:1:0712/095337.167806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.appgame.com/, 2c0f56f42860, , , 
;(function(){//pc端跳转
	var userAgentInfo = navigator.userAgent,
		Agents = new Array("Android"
[1:1:0712/095337.168152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.appgame.com/", "www.appgame.com", 3, 1, , , 0
[1:1:0712/095337.341468:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/095337.341778:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.appgame.com
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/095338.444822:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095338.445420:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095338.445867:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095338.447052:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095338.449118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095358.650516:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","http://h5.static.myappgame.com/common/WeixinApi.js"
[1:1:0712/095400.724430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.appgame.com/, 2c0f56f42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/095400.724771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.appgame.com/", "www.appgame.com", 3, 1, , , 0
[1:1:0712/095400.725885:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[119522:119522:0712/095401.053426:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.appgame.com/
[119522:119522:0712/095401.146876:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/095401.199255:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[119522:119522:0712/095402.403791:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119522:119522:0712/095402.404993:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119522:119534:0712/095402.423971:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[119522:119522:0712/095402.424139:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.appgame.com/
[119522:119522:0712/095402.424194:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.appgame.com/, http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171, 1
[119522:119534:0712/095402.424151:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[119522:119522:0712/095402.424235:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.appgame.com/, HTTP/1.1 200 OK Server: nginx/1.10.3 (Ubuntu) Date: Fri, 12 Jul 2019 16:54:01 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: am_force_theme_layout=desktop; path=/ Link: <http://www.appgame.com/wp-json/>; rel="https://api.w.org/" X-Cache-Debug: /?am_force_theme_layout=desktop&cachever=1562950417171     Content-Encoding: gzip  ,119618, 5
[1:7:0712/095402.427068:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095402.540993:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.appgame.com/
[1:1:0712/095402.811953:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[119522:119522:0712/095402.827061:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.appgame.com/, http://www.appgame.com/, 1
[119522:119522:0712/095402.827178:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.appgame.com/, http://www.appgame.com
[1:1:0712/095402.915270:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095402.950326:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095403.057951:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095403.058214:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171"
[1:1:0712/095403.104532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7fc044b93070 0x1ff8d96a51e0 , "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171"
[1:1:0712/095403.107445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.appgame.com/, 2c0f56f42860, , , 
;(function(){//pc端跳转
 var userAgentInfo = navigator.userAgent,
    Agents = new Array("Androi
[1:1:0712/095403.107685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171", "www.appgame.com", 3, 1, , , 0
[1:1:0712/095403.122621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7fc044b93070 0x1ff8d96a51e0 , "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171"
		remove user.10_1c4aa92b -> 0
		remove user.11_d9a35cc0 -> 0
		remove user.12_d7ca3ff7 -> 0
		remove user.13_e6c3e6c9 -> 0
		remove user.14_f88e5b46 -> 0
[1:1:0712/095403.826313:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095405.083823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7fc044efbbd0 0x1ff8d9782dd8 , "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171"
[1:1:0712/095405.089278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.appgame.com/, 2c0f56f42860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/095405.089537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171", "www.appgame.com", 3, 1, , , 0
[1:1:0712/095405.357323:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7fc044efbbd0 0x1ff8d9782dd8 , "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171"
[1:1:0712/095405.403868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7fc044efbbd0 0x1ff8d9782dd8 , "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171"
[1:1:0712/095405.410741:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7fc044efbbd0 0x1ff8d9782dd8 , "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171"
[1:1:0712/095405.573105:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1c4a034a4438, 0x1ff8d923d9a8
[1:1:0712/095405.573355:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.appgame.com/?am_force_theme_layout=desktop&cachever=1562950417171", 0
[1:1:0712/095405.573968:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.appgame.com/, 569
[1:1:0712/095405.574195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7fc044b93070 0x1ff8d9b3fae0 , 5:3_http://www.appgame.com/, 1, -5:3_http://www.appgame.com/, 503 0x7fc044efbbd0 0x1ff8d9782dd8 
[1:1:0712/095405.605664:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.251415, 166, 1
[1:1:0712/095405.605924:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
