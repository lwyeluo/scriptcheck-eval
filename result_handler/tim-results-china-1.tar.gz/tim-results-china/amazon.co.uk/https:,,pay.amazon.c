[0711/195910.589922:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195910.590308:INFO:switcher_clone.cc(787)] backtrace rip is 7f8d19a4f891
[0711/195911.587657:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195911.587981:INFO:switcher_clone.cc(787)] backtrace rip is 7f70fc46b891
[1:1:0711/195911.593281:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/195911.593473:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/195911.598630:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[5770:5770:0711/195912.763648:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/7172c21c-ced8-4418-894a-3e691b81724a
[0711/195912.940524:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195912.940889:INFO:switcher_clone.cc(787)] backtrace rip is 7f81ae7ff891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5801:5801:0711/195913.178566:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5801
[5813:5813:0711/195913.179011:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5813
[5770:5770:0711/195913.364310:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[5770:5799:0711/195913.365234:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/195913.365468:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/195913.365679:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/195913.366268:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/195913.366441:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/195913.369580:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x347a3e70, 1
[1:1:0711/195913.369982:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x26fedcc9, 0
[1:1:0711/195913.370227:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x310b1834, 3
[1:1:0711/195913.370455:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3849521a, 2
[1:1:0711/195913.370711:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc9ffffffdcfffffffe26 703e7a34 1a524938 34180b31 , 10104, 4
[1:1:0711/195913.371956:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5770:5799:0711/195913.372280:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���&p>z4RI841��N
[5770:5799:0711/195913.372360:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���&p>z4RI841�A��N
[1:1:0711/195913.372266:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70fa6a60a0, 3
[5770:5799:0711/195913.372668:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[5770:5799:0711/195913.372741:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5821, 4, c9dcfe26 703e7a34 1a524938 34180b31 
[1:1:0711/195913.372500:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70fa831080, 2
[1:1:0711/195913.373436:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70e44f4d20, -2
[1:1:0711/195913.391612:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/195913.392474:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3849521a
[1:1:0711/195913.393412:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3849521a
[1:1:0711/195913.394924:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3849521a
[1:1:0711/195913.396470:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.396695:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.396915:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.397150:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.397838:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3849521a
[1:1:0711/195913.398220:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70fc46b7ba
[1:1:0711/195913.398408:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f70fc462def, 7f70fc46b77a, 7f70fc46d0cf
[1:1:0711/195913.404254:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3849521a
[1:1:0711/195913.404655:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3849521a
[1:1:0711/195913.405446:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3849521a
[1:1:0711/195913.407521:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.407748:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.408002:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.408240:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3849521a
[1:1:0711/195913.409528:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3849521a
[1:1:0711/195913.409922:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70fc46b7ba
[1:1:0711/195913.410096:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f70fc462def, 7f70fc46b77a, 7f70fc46d0cf
[1:1:0711/195913.418614:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/195913.419220:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/195913.419432:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff1ae3c3b8, 0x7fff1ae3c338)
[1:1:0711/195913.430997:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/195913.434994:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[5770:5770:0711/195914.125304:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5770:5770:0711/195914.126545:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5770:5780:0711/195914.141231:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[5770:5780:0711/195914.141352:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[5770:5770:0711/195914.141517:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[5770:5770:0711/195914.141611:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[5770:5770:0711/195914.141783:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5821, 4
[1:7:0711/195914.143886:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[5770:5792:0711/195914.172252:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/195914.264940:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x11da59ace220
[1:1:0711/195914.265222:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/195914.634559:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[5770:5770:0711/195916.295921:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[5770:5770:0711/195916.295993:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/195916.352173:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195916.356564:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195917.528391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 201d477c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/195917.528691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195917.545320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 201d477c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/195917.545585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195917.619798:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195917.964164:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195917.964422:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195918.273139:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195918.281977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 201d477c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/195918.282226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195918.304750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195918.316799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 201d477c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/195918.317068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195918.329007:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[5770:5770:0711/195918.331548:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/195918.332226:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x11da59acce20
[1:1:0711/195918.333448:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5770:5770:0711/195918.337580:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[5770:5770:0711/195918.359115:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[5770:5770:0711/195918.359204:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/195918.378427:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195919.248940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f70e60cf2e0 0x11da59cffbe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195919.250295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 201d477c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/195919.250532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195919.251966:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5770:5770:0711/195919.317138:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/195919.318936:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x11da59acd820
[1:1:0711/195919.319677:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5770:5770:0711/195919.323377:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/195919.338287:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/195919.338471:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[5770:5770:0711/195919.345663:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[5770:5770:0711/195919.360132:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5770:5770:0711/195919.361078:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5770:5780:0711/195919.366648:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[5770:5780:0711/195919.366733:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[5770:5770:0711/195919.366872:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[5770:5770:0711/195919.366943:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[5770:5770:0711/195919.367067:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5821, 4
[1:7:0711/195919.370123:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/195919.940670:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/195920.458541:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7f70e60cf2e0 0x11da59e879e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195920.459523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 201d477c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/195920.459734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195920.460438:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5770:5770:0711/195920.587762:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[5770:5770:0711/195920.587867:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/195920.603293:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[5770:5770:0711/195920.926853:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[5770:5799:0711/195920.927309:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/195920.927504:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/195920.927693:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/195920.928213:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/195920.928385:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/195920.931938:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b741817, 1
[1:1:0711/195920.932262:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x292b37a8, 0
[1:1:0711/195920.932475:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3d169c02, 3
[1:1:0711/195920.932670:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2c25b095, 2
[1:1:0711/195920.932873:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa8372b29 1718741b ffffff95ffffffb0252c 02ffffff9c163d , 10104, 5
[1:1:0711/195920.933898:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5770:5799:0711/195920.934164:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�7+)t��%,�=��N
[5770:5799:0711/195920.934228:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �7+)t��%,�=Xf��N
[5770:5799:0711/195920.934533:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5867, 5, a8372b29 1718741b 95b0252c 029c163d 
[1:1:0711/195920.934340:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70fa6a60a0, 3
[1:1:0711/195920.935009:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70fa831080, 2
[1:1:0711/195920.935230:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70e44f4d20, -2
[1:1:0711/195920.942715:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195920.952026:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/195920.952382:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2c25b095
[1:1:0711/195920.952720:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2c25b095
[1:1:0711/195920.953355:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2c25b095
[1:1:0711/195920.954668:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.954878:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.955079:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.955247:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.955905:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2c25b095
[1:1:0711/195920.956174:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70fc46b7ba
[1:1:0711/195920.956310:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f70fc462def, 7f70fc46b77a, 7f70fc46d0cf
[1:1:0711/195920.961763:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2c25b095
[1:1:0711/195920.962120:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2c25b095
[1:1:0711/195920.962804:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2c25b095
[1:1:0711/195920.964707:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.964954:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.965137:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.965319:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c25b095
[1:1:0711/195920.966498:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2c25b095
[1:1:0711/195920.966860:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70fc46b7ba
[1:1:0711/195920.966990:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f70fc462def, 7f70fc46b77a, 7f70fc46d0cf
[1:1:0711/195920.974259:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/195920.974729:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/195920.974899:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff1ae3c3b8, 0x7fff1ae3c338)
[1:1:0711/195920.987634:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/195920.991715:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/195921.155193:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x11da59aaa220
[1:1:0711/195921.155457:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/195921.627765:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195921.628087:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195921.941573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195921.946634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/195921.946964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195921.954820:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195922.074531:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195922.075327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 201d477c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/195922.075569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195922.260343:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195922.262005:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/195922.262238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/195922.262510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195922.379299:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195922.393157:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/195922.393435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/195922.393699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195922.933588:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0711/195923.290576:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gmx.net/"
[1:1:0711/195923.356562:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/195923.469419:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/195923.545749:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/195923.599450:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/195923.647581:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/195923.702896:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0711/195923.885322:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195923.885820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195923.885972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195923.976061:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195923.976522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195923.976655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[5770:5770:0711/195924.097780:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5770:5770:0711/195924.119601:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[5770:5799:0711/195924.119960:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0711/195924.120159:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/195924.120331:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/195924.120718:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/195924.120887:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0711/195924.124163:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36e78dd0, 1
[1:1:0711/195924.124444:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24643815, 0
[1:1:0711/195924.124631:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2f5ae9be, 3
[1:1:0711/195924.124803:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x988f20a, 2
[1:1:0711/195924.124940:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 15386424 ffffffd0ffffff8dffffffe736 0afffffff2ffffff8809 ffffffbeffffffe95a2f , 10104, 6
[1:1:0711/195924.125887:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5770:5799:0711/195924.126046:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING8d$Ѝ�6
�	��Z/2�N
[5770:5799:0711/195924.126081:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 8d$Ѝ�6
�	��Z/��2�N
[1:1:0711/195924.126141:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70fa6a60a0, 3
[1:1:0711/195924.126235:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70fa831080, 2
[1:1:0711/195924.126323:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70e44f4d20, -2
[5770:5770:0711/195924.130777:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5770:5799:0711/195924.133010:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5884, 6, 15386424 d08de736 0af28809 bee95a2f 
[5770:5770:0711/195924.141012:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pay.amazon.co.uk/
[5770:5770:0711/195924.141101:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://pay.amazon.co.uk/, https://pay.amazon.co.uk/?ld=AWREUKAPAFooter, 1
[5770:5770:0711/195924.141240:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://pay.amazon.co.uk/, HTTP/1.1 200 OK Server: Server Date: Fri, 12 Jul 2019 02:59:23 GMT Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive X-Frame-Options: ALLOW-FROM https://pay.amazon.com X-XSS-Protection: 1; mode=block X-Content-Type-Options: nosniff X-UA-Compatible: IE=edge Content-Security-Policy: frame-ancestors https://pay.amazon.com ETag: W/"2a58619f5e929a244faeaaae5f136e52-gzip" Cache-Control: max-age=0, private, must-revalidate X-Request-Id: 77f3c77a-0470-4dd9-ba4f-b0021b62282c X-Runtime: 0.108000 Strict-Transport-Security: max-age=31536000 Set-Cookie: pay-session-id=ca1dd6234bff197cbd4d5d7d2eb25474; domain=amazon.com; path=/; expires=Sun, 12 Jul 2020 02:59:23 -0000; secure Set-Cookie: _rails-root_session=VitRb1FmZzRCd1VZTU55YUlqRjZzWTdMVFRaUjZ6c2VtMnZuOXF6V2ppQy80YzQzSGJLdTBCOW44b3RrN2hFa08yNXBBYWlKRmt1aTJ1QnpBL3d2ckFwTUR6M3E1T3czWHJmTjF4ZWc5VVVDZW05OTUxc2MyNkVSQXVGSkg5QmpNTG9iU3VRY05hRjBQN0pqWERSQjUzbDNOYitrY0Vsc0t4cXJnSnZxWFJnQjQ5eFUramNnbmZobTNOd0k0YW5Ed2RhOUpXU09UMnV0ZXdTOUhKeDc3OFBPQ0RPWnVCWlJBWWtuVlErY1NJa2M2S2tPQW1LYnB5RGRhclRIbkt5WHpGS1loVHBmRjNZL0RNemFYdndYSnBRR0Jxc3NDSXJYcTlGTXY4ZTJuL0ZmWVRqRC9FYnhsYjZwd3FnS2YvSlotLWVEdE16dXhiZTJWeG1BZDZUanZlSXc9PQ%3D%3D--89dfaebbd4c0264bb7089166c82afd4941beeccf; path=/; expires=Sun, 12 Jul 2020 02:59:23 -0000; secure; HttpOnly Vary: Accept-Encoding,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment,User-Agent Content-Encoding: gzip x-amz-rid: 71EMF97WBMWRTGFS161Y  ,0, 6
[3:3:0711/195924.145102:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/195924.147142:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.147578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195924.147713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.153217:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/195924.153516:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 988f20a
[1:1:0711/195924.153783:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 988f20a
[1:1:0711/195924.154349:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 988f20a
[1:1:0711/195924.155803:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.155993:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.156176:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.156353:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.157010:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 988f20a
[1:1:0711/195924.157288:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70fc46b7ba
[1:1:0711/195924.157439:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f70fc462def, 7f70fc46b77a, 7f70fc46d0cf
[5770:5780:0711/195924.162542:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[5770:5780:0711/195924.162623:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[1:1:0711/195924.163119:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 988f20a
[1:1:0711/195924.163466:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 988f20a
[1:1:0711/195924.164220:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 988f20a
[1:1:0711/195924.166236:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.166441:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.166630:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.166829:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 988f20a
[1:1:0711/195924.168056:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 988f20a
[1:1:0711/195924.168420:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70fc46b7ba
[1:1:0711/195924.168557:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f70fc462def, 7f70fc46b77a, 7f70fc46d0cf
[1:1:0711/195924.176209:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/195924.176694:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/195924.176856:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff1ae3c3b8, 0x7fff1ae3c338)
[1:1:0711/195924.190728:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/195924.195213:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/195924.214439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.215309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195924.215539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:7:0711/195924.272252:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/195924.369895:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.370810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195924.371105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.395011:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.395937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195924.396228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.442079:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x11da59ad0220
[1:1:0711/195924.442385:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/195924.485080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.486008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195924.486274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.499631:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://pay.amazon.co.uk/
[1:1:0711/195924.560823:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.561759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195924.562048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.603961:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.604836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195924.605117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.668681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.669602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195924.669862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.772857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.773789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195924.774150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[5770:5770:0711/195924.783433:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://pay.amazon.co.uk/, https://pay.amazon.co.uk/, 1
[5770:5770:0711/195924.783522:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://pay.amazon.co.uk/, https://pay.amazon.co.uk
[1:1:0711/195924.787733:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195924.934812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195924.935755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195924.936078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195924.993627:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195925.040005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195925.040928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195925.041211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195925.050106:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195925.050304:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195925.127401:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195925.128324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195925.128629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195925.182243:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195925.183156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/195925.183441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195925.222411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195925.223264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 201d478f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/195925.223520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195925.794681:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/195926.167617:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f70e450fbd0 0x11da59d670d8 , "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195926.183906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , // For license information, see `https://m.media-amazon.com/images/G/01/EPSMarketingJRubyWebsite/ass
[1:1:0711/195926.184255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195926.186338:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195931.923323:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195931.923921:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195931.924325:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195931.924730:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195931.925104:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[5770:5770:0711/195935.596315:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/195935.601510:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/195935.767808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3fcea53229c8, 0x11da596f7160
[1:1:0711/195935.768077:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", 0
[1:1:0711/195935.768647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pay.amazon.co.uk/, 233
[1:1:0711/195935.768938:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 233 0x7f70e41a7070 0x11da59d6f760 , 6:3_https://pay.amazon.co.uk/, 1, -6:3_https://pay.amazon.co.uk/, 187 0x7f70e450fbd0 0x11da59d670d8 
[1:1:0711/195937.110351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/195937.110667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195938.028510:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pay.amazon.co.uk/, 233, 7f70e6aec881
[1:1:0711/195938.033722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"148776882860","ptid":"187 0x7f70e450fbd0 0x11da59d670d8 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195938.033889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pay.amazon.co.uk/","ptid":"187 0x7f70e450fbd0 0x11da59d670d8 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195938.034067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195938.034367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , (){var e=p();e&&f(e)}
[1:1:0711/195938.034462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195938.307954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195938.308823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , XMLHttpRequest.corsMetadata.corsType.n.onreadystatechange, (){4===this.readyState&&200===this.status&&t(this.responseText)}
[1:1:0711/195938.308937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195938.309349:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195938.310883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[5770:5770:0711/195938.363575:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/195938.365590:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x11da59ace420
[1:1:0711/195938.365871:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5770:5770:0711/195938.368568:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: destination_publishing_iframe_amazonwebstore_0_name, 4, 4, 
[1:1:0711/195938.398938:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/195938.399235:INFO:render_frame_impl.cc(7019)] 	 [url] = https://pay.amazon.co.uk
[5770:5770:0711/195938.401100:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://pay.amazon.co.uk/
[1:1:0711/195938.726625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f70e450fbd0 0x11da59d676d8 , "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195938.731283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var instal
[1:1:0711/195938.731438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[5770:5770:0711/195938.747904:INFO:CONSOLE(279)] "Initiating assets startup", source: https://d1215ijo50bwf7.cloudfront.net/design/assets-AmazonPay.js (279)
[5770:5770:0711/195938.930079:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5770:5770:0711/195938.935726:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5770:5780:0711/195938.968270:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[5770:5780:0711/195938.968395:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[5770:5770:0711/195938.968564:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://amazonwebstore.demdex.net/
[5770:5770:0711/195938.968643:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://amazonwebstore.demdex.net/, https://amazonwebstore.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fpay.amazon.co.uk, 4
[5770:5770:0711/195938.968779:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://amazonwebstore.demdex.net/, HTTP/1.1 200 OK Accept-Ranges: bytes Cache-Control: max-age=21600 Content-Encoding: gzip Content-Type: text/html Expires: Thu, 01 Jan 1970 00:00:00 GMT Last-Modified: Thu, 11 Jul 2019 09:17:01 GMT P3P: policyref="/w3c/p3p.xml", CP="NOI NID CURa ADMa DEVa PSAa PSDa OUR SAMa BUS PUR COM NAV INT" Pragma: no-cache Set-Cookie: demdex=24114595814138362962233171275659633142;Path=/;Domain=.demdex.net;Expires=Wed, 08-Jan-2020 02:59:38 GMT;Max-Age=15552000 Vary: Accept-Encoding, User-Agent X-TID: IgBQsANVQts= Content-Length: 2764 Connection: keep-alive  ,5884, 6
[1:7:0711/195938.973800:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/195941.536839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195941.538857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195943.198933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/195943.199104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195944.299070:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 378 0x7f70e60cf2e0 0x11da5a0f1ae0 , "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195944.316136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , // For license information, see `https://assets.adobedtm.com/extensions/EP971e6ad26efe44ab86e98d3905
[1:1:0711/195944.316480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195944.318874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[5770:5770:0711/195944.423048:INFO:CONSOLE(2)] "Account is amznpaymentsglobalprod", source: https://m.media-amazon.com/images/G/01/EPSMarketingJRubyWebsite/assets/mindstorms/launch-ENff4f46bd00c34da69c9f7262573232e2.min.js (2)
[1:1:0711/195944.442925:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", 0
[1:1:0711/195944.443964:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pay.amazon.co.uk/, 550
[1:1:0711/195944.444311:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 550 0x7f70e41a7070 0x11da5adcd4e0 , 6:3_https://pay.amazon.co.uk/, 1, -6:3_https://pay.amazon.co.uk/, 378 0x7f70e60cf2e0 0x11da5a0f1ae0 
[1:1:0711/195944.534176:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", 100
[1:1:0711/195944.534814:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pay.amazon.co.uk/, 551
[1:1:0711/195944.535177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 551 0x7f70e41a7070 0x11da5b1e7360 , 6:3_https://pay.amazon.co.uk/, 1, -6:3_https://pay.amazon.co.uk/, 378 0x7f70e60cf2e0 0x11da5a0f1ae0 
[1:1:0711/195946.051417:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://amazonwebstore.demdex.net/
[1:1:0711/195950.136924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/195950.137222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195950.621470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , handler, (entries, observer) {
        for (entry of entries) {
            if (entry.isIntersecting) {
     
[1:1:0711/195950.621799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195951.836806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , () {
                    nav.classList.remove("main-nav__shadow");
                }
[1:1:0711/195951.836992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195952.306473:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pay.amazon.co.uk/, 550, 7f70e6aec881
[1:1:0711/195952.341162:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"148776882860","ptid":"378 0x7f70e60cf2e0 0x11da5a0f1ae0 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195952.341488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pay.amazon.co.uk/","ptid":"378 0x7f70e60cf2e0 0x11da5a0f1ae0 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195952.341800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195952.342690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , undefined
[1:1:0711/195952.342893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195952.345660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pay.amazon.co.uk/, 551, 7f70e6aec8db
[1:1:0711/195952.376712:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"148776882860","ptid":"378 0x7f70e60cf2e0 0x11da5a0f1ae0 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195952.377119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pay.amazon.co.uk/","ptid":"378 0x7f70e60cf2e0 0x11da5a0f1ae0 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195952.377692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://pay.amazon.co.uk/, 699
[1:1:0711/195952.377974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f70e41a7070 0x11da5b63ad60 , 6:3_https://pay.amazon.co.uk/, 0, , 551 0x7f70e41a7070 0x11da5b1e7360 
[1:1:0711/195952.378332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195952.378964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , AppMeasurement.g.H, (){var e;if(g.isReadyToTrack()&&(g.vb(),g.l!=d))for(;0<g.l.length;)(e=g.l.shift()).Ab.apply(e.Bb,e.y
[1:1:0711/195952.379117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195952.998391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3fcea53229c8, 0x11da596f7150
[1:1:0711/195952.998683:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", 5000
[1:1:0711/195952.999255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pay.amazon.co.uk/, 724
[1:1:0711/195952.999484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7f70e41a7070 0x11da5b636de0 , 6:3_https://pay.amazon.co.uk/, 1, -6:3_https://pay.amazon.co.uk/, 551 0x7f70e41a7070 0x11da5b1e7360 
[1:1:0711/195953.184244:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f70e60cf2e0 0x11da5b1db360 , "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195953.185345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , // For license information, see `https://m.media-amazon.com/images/G/01/EPSMarketingJRubyWebsite/ass
[1:1:0711/195953.185490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195953.186287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195953.270190:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f70e60cf2e0 0x11da5b1db360 , "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195953.285854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195953.290117:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2a4234a54a78
[5770:5770:0711/195953.292916:INFO:CONSOLE(2)] "Uncaught TypeError: Cannot read property 'querySelectorAll' of null", source: https://pay.amazon.co.uk/?ld=AWREUKAPAFooter (2)
[5770:5770:0711/195953.405909:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://amazonwebstore.demdex.net/, https://amazonwebstore.demdex.net/, 4
[1:1:0711/195953.405885:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[5770:5770:0711/195953.406038:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://amazonwebstore.demdex.net/, https://amazonwebstore.demdex.net
[1:1:0711/195955.090006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/195955.090181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[5770:5770:0711/195957.452784:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/195958.576008:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195959.114127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/195959.114298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195959.432422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://pay.amazon.co.uk/, 724, 7f70e6aec881
[1:1:0711/195959.447052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"148776882860","ptid":"551 0x7f70e41a7070 0x11da5b1e7360 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195959.447284:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://pay.amazon.co.uk/","ptid":"551 0x7f70e41a7070 0x11da5b1e7360 ","rf":"6:3_https://pay.amazon.co.uk/"}
[1:1:0711/195959.447523:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195959.447874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , (){t.F&&(t.complete?t.ra():(g.trackOffline&&t.abort&&t.abort(),t.Ka()))}
[1:1:0711/195959.448023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/195959.776180:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195959.776334:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://amazonwebstore.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fpay.amazon.co.uk"
[1:1:0711/195959.777697:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 792 0x7f70e41a7070 0x11da5b1f0260 , "https://amazonwebstore.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fpay.amazon.co.uk"
[1:1:0711/195959.791675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://amazonwebstore.demdex.net/, 148776918308, , , 
var Demdex={version:"6.1",dest:"5",PROTOCOL:"https:"==document.location.protocol?"https:":"http:",C
[1:1:0711/195959.791933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://amazonwebstore.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fpay.amazon.co.uk", "amazonwebstore.demdex.net", 4, 1, https://pay.amazon.co.uk, pay.amazon.co.uk, 3
[1:1:0711/195959.792510:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195959.826672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195959.827459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -6:4_https://amazonwebstore.demdex.net/-6:3_https://pay.amazon.co.uk/, 148776882860, 148776918308, , (){r.className="aamIframeLoaded",n.iframeHasLoaded=!0,n.fireIframeLoadedCallbacks(e),n.requestToProc
[1:1:0711/195959.827706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 2, , , 0
[1:1:0711/195959.828275:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0711/195959.984554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/195959.985482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , t.onload.t.ra, (){if(t.Ta&&(g.ja=Date.now()-t.Ta),g.eb(e),t.Ga(),g.Db(),g.da(),g.p=0,g.W(),t.Ea){t.Ea=!1;try{g.doPo
[1:1:0711/195959.985710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200000.139154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200000.139520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200000.477729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/200000.479011:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 6:3_https://pay.amazon.co.uk/, 6:4_https://amazonwebstore.demdex.net/
[1:1:0711/200000.479211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , e, (e){if("string"==typeof n&&e.origin!==n||"[object Function]"===Object.prototype.toString.call(n)&&!1
[1:1:0711/200000.479386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200000.946001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200000.946315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200001.628440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200001.628613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200001.722384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200001.722547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200001.808967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200001.809297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200001.921902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200001.922087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.101828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.102101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.346341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.346601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.491606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.491902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.619142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.619382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.734445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.734710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.789982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.790223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.838340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.838504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.889562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.889822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200002.993000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200002.993172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200003.142455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200003.142726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200003.229144:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/200003.230152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , e, (c) {
        "readystatechange" === c.type && "complete" !== k.readyState || a || (a = !0, b.call(l
[1:1:0711/200003.230395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
[1:1:0711/200003.232815:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/200003.233747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/200003.234225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/200003.234902:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter"
[1:1:0711/200003.332441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://pay.amazon.co.uk/, 148776882860, , , document.readyState
[1:1:0711/200003.332766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pay.amazon.co.uk/?ld=AWREUKAPAFooter", "pay.amazon.co.uk", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
