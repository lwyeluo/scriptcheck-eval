[0711/194833.866013:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/194833.866407:INFO:switcher_clone.cc(787)] backtrace rip is 7ff90599e891
[0711/194834.774280:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/194834.774607:INFO:switcher_clone.cc(787)] backtrace rip is 7f2d5a251891
[1:1:0711/194834.789134:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/194834.789502:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/194834.795155:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0711/194836.142810:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/194836.143112:INFO:switcher_clone.cc(787)] backtrace rip is 7fcacb734891
[4256:4256:0711/194836.168600:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/51b85ddf-e4a0-4280-99c1-572e7ccea77d
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[4288:4288:0711/194836.348527:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4288
[4300:4300:0711/194836.348995:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4300
[4256:4256:0711/194836.707364:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[4256:4285:0711/194836.708204:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/194836.708401:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/194836.708615:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/194836.709162:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/194836.709311:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/194836.711897:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xfc088f8, 1
[1:1:0711/194836.712201:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3fc66ca, 0
[1:1:0711/194836.712364:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3c148f4, 3
[1:1:0711/194836.712670:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x30bebddd, 2
[1:1:0711/194836.712902:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffca66fffffffc03 fffffff8ffffff88ffffffc00f ffffffddffffffbdffffffbe30 fffffff448ffffffc103 , 10104, 4
[1:1:0711/194836.714168:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4256:4285:0711/194836.714449:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�f����ݽ�0�H���@
[4256:4285:0711/194836.714531:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �f����ݽ�0�H����@
[1:1:0711/194836.714430:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2d5848c0a0, 3
[1:1:0711/194836.714661:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2d58617080, 2
[4256:4285:0711/194836.714847:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/194836.714807:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2d422dad20, -2
[4256:4285:0711/194836.714915:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4308, 4, ca66fc03 f888c00f ddbdbe30 f448c103 
[1:1:0711/194836.736942:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/194836.737976:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30bebddd
[1:1:0711/194836.739096:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30bebddd
[1:1:0711/194836.740914:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30bebddd
[1:1:0711/194836.742345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.742561:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.742741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.742938:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.743601:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30bebddd
[1:1:0711/194836.743904:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2d5a2517ba
[1:1:0711/194836.744034:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2d5a248def, 7f2d5a25177a, 7f2d5a2530cf
[1:1:0711/194836.750734:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30bebddd
[1:1:0711/194836.751171:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30bebddd
[1:1:0711/194836.752010:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30bebddd
[1:1:0711/194836.754093:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.754283:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.754495:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.754682:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bebddd
[1:1:0711/194836.755901:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30bebddd
[1:1:0711/194836.756258:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2d5a2517ba
[1:1:0711/194836.756406:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2d5a248def, 7f2d5a25177a, 7f2d5a2530cf
[1:1:0711/194836.764184:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/194836.764715:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/194836.764873:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff9884a4f8, 0x7fff9884a478)
[1:1:0711/194836.780765:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/194836.786694:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[4256:4256:0711/194837.338181:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4256:4256:0711/194837.339751:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4256:4267:0711/194837.352799:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[4256:4267:0711/194837.352920:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[4256:4256:0711/194837.353136:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[4256:4256:0711/194837.353225:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[4256:4256:0711/194837.353403:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,4308, 4
[1:7:0711/194837.355344:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[4256:4279:0711/194837.411849:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/194837.504244:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3549ca2f220
[1:1:0711/194837.504530:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/194837.993294:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[4256:4256:0711/194839.450954:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[4256:4256:0711/194839.451027:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/194839.489525:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194839.493428:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/194840.832006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 360ac1101f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/194840.832310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/194840.849021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 360ac1101f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/194840.849297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/194840.920193:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/194841.154115:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/194841.154410:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/194841.440708:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/194841.448757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 360ac1101f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/194841.449038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/194841.485522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/194841.490713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 360ac1101f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/194841.490986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/194841.502831:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[4256:4256:0711/194841.505828:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/194841.506145:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3549ca2de20
[1:1:0711/194841.506352:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[4256:4256:0711/194841.512817:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[4256:4256:0711/194841.543200:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[4256:4256:0711/194841.543299:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/194841.584255:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/194842.224242:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7f2d43eb52e0 0x3549c5e6fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/194842.225592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 360ac1101f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/194842.225828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/194842.227320:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4256:4256:0711/194842.274280:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/194842.276514:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3549ca2e820
[1:1:0711/194842.276755:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[4256:4256:0711/194842.280866:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/194842.298321:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/194842.298470:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[4256:4256:0711/194842.305795:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[4256:4256:0711/194842.317452:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4256:4256:0711/194842.318479:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4256:4256:0711/194842.324805:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[4256:4256:0711/194842.324893:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[4256:4256:0711/194842.325027:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,4308, 4
[4256:4267:0711/194842.329242:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[4256:4267:0711/194842.329360:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/194842.331223:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/194842.699153:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/194843.179126:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f2d43eb52e0 0x3549cc84a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/194843.180193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 360ac1101f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/194843.180546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/194843.181323:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4256:4256:0711/194843.322895:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[4256:4256:0711/194843.323012:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/194843.353377:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/194843.687433:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/194844.102936:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/194844.103179:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4256:4256:0711/194844.111291:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[4256:4285:0711/194844.112201:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/194844.112465:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/194844.112652:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/194844.113025:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/194844.113162:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/194844.116710:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b0423b6, 1
[1:1:0711/194844.117097:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xf2771a0, 0
[1:1:0711/194844.117254:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x39ae02b4, 3
[1:1:0711/194844.117414:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x261e8a8b, 2
[1:1:0711/194844.117564:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa071270f ffffffb623041b ffffff8bffffff8a1e26 ffffffb402ffffffae39 , 10104, 5
[1:1:0711/194844.118553:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4256:4285:0711/194844.118771:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�q'�#��&��9?�@
[4256:4285:0711/194844.118839:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �q'�#��&��9�?�@
[1:1:0711/194844.118960:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2d5848c0a0, 3
[4256:4285:0711/194844.119126:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4354, 5, a071270f b623041b 8b8a1e26 b402ae39 
[1:1:0711/194844.119195:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2d58617080, 2
[1:1:0711/194844.119429:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2d422dad20, -2
[1:1:0711/194844.141177:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/194844.141541:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 261e8a8b
[1:1:0711/194844.141839:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 261e8a8b
[1:1:0711/194844.142467:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 261e8a8b
[1:1:0711/194844.143891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.144078:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.144273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.144498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.145146:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 261e8a8b
[1:1:0711/194844.145456:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2d5a2517ba
[1:1:0711/194844.145592:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2d5a248def, 7f2d5a25177a, 7f2d5a2530cf
[1:1:0711/194844.148472:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 261e8a8b
[1:1:0711/194844.148659:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 261e8a8b
[1:1:0711/194844.148935:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 261e8a8b
[1:1:0711/194844.149658:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.149776:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.149869:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.149961:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 261e8a8b
[1:1:0711/194844.150410:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 261e8a8b
[1:1:0711/194844.150593:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2d5a2517ba
[1:1:0711/194844.150674:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2d5a248def, 7f2d5a25177a, 7f2d5a2530cf
[1:1:0711/194844.152895:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/194844.153259:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/194844.153347:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff9884a4f8, 0x7fff9884a478)
[1:1:0711/194844.169698:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/194844.174729:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/194844.381296:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3549c9d6220
[1:1:0711/194844.381488:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/194844.681151:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/194844.685735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 360ac12309f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/194844.686012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/194844.691689:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4256:4256:0711/194845.728841:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4256:4256:0711/194845.737553:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4256:4267:0711/194845.769491:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[4256:4267:0711/194845.769591:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[4256:4256:0711/194845.770009:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://aws.amazon.com/
[4256:4256:0711/194845.770103:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://aws.amazon.com/, https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter, 1
[4256:4256:0711/194845.770234:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://aws.amazon.com/, HTTP/1.1 200 status:200 content-type:text/html;charset=UTF-8 server:Server date:Fri, 12 Jul 2019 02:48:45 GMT x-frame-options:SAMEORIGIN x-content-type-options:nosniff x-amz-id-1:N7ATY5BETBQHTWM5T3ZH last-modified:Tue, 09 Jul 2019 06:33:16 GMT cache-control:no-store, no-cache, must-revalidate content-encoding:gzip vary:accept-encoding,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment,User-Agent set-cookie:aws-priv=eyJ2IjoxLCJldSI6MCwic3QiOjB9; Version=1; Comment="Anonymous cookie for privacy regulations"; Domain=.amazon.com; Max-Age=94672800; Expires=Mon, 11-Jul-2022 20:48:45 GMT; Path=/ set-cookie:aws-csds-token=76df236f-6f9e-4025-9d4a-38bd454f4880; Version=1; Comment="Anonymous metrics validation token"; Max-Age=900; Expires=Fri, 12-Jul-2019 03:03:45 GMT; Path=/ set-cookie:aws_lang=en; Domain=.amazon.com; Path=/ x-amz-rid:N7ATY5BETBQHTWM5T3ZH x-cache:Miss from cloudfront via:1.1 e9ba0a9a729ff2960a04323bf1833df8.cloudfront.net (CloudFront) x-amz-cf-pop:SFO5-C3 x-amz-cf-id:BNgtzLcw6rKNWywaYOtWu4WsZTejIOOeH7aiFEUCcpulBZx4H1cmsQ==  ,4354, 5
[1:7:0711/194845.774209:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/194845.825341:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://aws.amazon.com/
[4256:4256:0711/194845.995135:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://aws.amazon.com/, https://aws.amazon.com/, 1
[4256:4256:0711/194845.995740:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://aws.amazon.com/, https://aws.amazon.com
[1:1:0711/194845.996995:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/194846.094487:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/194846.172230:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/194846.254432:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/194846.254651:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/194847.990875:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 231 0x7f2d41f8d070 0x3549cbdf060 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194847.994001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , 
  var AWS = {
    PageSettings: {
      supportedLanguages: ['ar', 'en', 'es', 'de', 'fr', 'id', 'i
[1:1:0711/194847.994235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194847.996032:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194848.040126:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194848.149883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 246 0x7f2d422f5bd0 0x3549cbd8458 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194848.160375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , /*6b61447d852966a68d491394f7dccddd*/(function(win){"use strict";var listeners=[];var doc=win.documen
[1:1:0711/194848.160656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194848.474008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3732588229c8, 0x3549c399160
[1:1:0711/194848.474190:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 4
[1:1:0711/194848.474416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 253
[1:1:0711/194848.474576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 253 0x7f2d41f8d070 0x3549cbf3e60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 246 0x7f2d422f5bd0 0x3549cbd8458 
		remove user.f_124014f7 -> 0
		remove user.10_3ef9ba81 -> 0
[1:1:0711/194848.496282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3732588229c8, 0x3549c399160
[1:1:0711/194848.496645:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 4
[1:1:0711/194848.497278:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 254
[1:1:0711/194848.497539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 254 0x7f2d41f8d070 0x3549cbf35e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 246 0x7f2d422f5bd0 0x3549cbd8458 
[1:1:0711/194848.713709:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3732588229c8, 0x3549c399160
[1:1:0711/194848.713872:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 4
[1:1:0711/194848.714097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 255
[1:1:0711/194848.714199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 255 0x7f2d41f8d070 0x3549cbebf60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 246 0x7f2d422f5bd0 0x3549cbd8458 
[1:1:0711/194848.718837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 246 0x7f2d422f5bd0 0x3549cbd8458 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194848.797267:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x3732588229c8, 0x3549c399260
[1:1:0711/194848.797462:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 30
[1:1:0711/194848.797692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 259
[1:1:0711/194848.797808:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 259 0x7f2d41f8d070 0x3549cbe12e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 246 0x7f2d422f5bd0 0x3549cbd8458 
[1:1:0711/194849.147323:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 246 0x7f2d422f5bd0 0x3549cbd8458 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194849.153514:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 246 0x7f2d422f5bd0 0x3549cbd8458 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194849.373325:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3732588229c8, 0x3549c3991a8
[1:1:0711/194849.373638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 100
[1:1:0711/194849.374287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 293
[1:1:0711/194849.374538:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 293 0x7f2d41f8d070 0x3549cbf7ae0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 246 0x7f2d422f5bd0 0x3549cbd8458 
[1:1:0711/194849.382317:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.667062, 0, 0
[1:1:0711/194849.382531:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/194850.066563:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/194850.066726:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194850.154374:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0877149, 219, 1
[1:1:0711/194850.154677:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/194850.162076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0711/194850.162344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194850.675090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 253, 7f2d448d2881
[1:1:0711/194850.693186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194850.693512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194850.693885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194850.694553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0711/194850.694725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194850.727508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 254, 7f2d448d2881
[1:1:0711/194850.734553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194850.734717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194850.734901:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194850.735236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0711/194850.735335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194850.744199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 255, 7f2d448d2881
[1:1:0711/194850.750199:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194850.750356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194850.750569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194850.750896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0711/194850.750996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194853.912337:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194853.912790:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194853.913179:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194853.913579:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194853.913996:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0711/194856.688836:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/194857.049870:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194857.050128:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194857.050693:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 439
[1:1:0711/194857.050985:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 439 0x7f2d41f8d070 0x3549d37cd60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 255 0x7f2d41f8d070 0x3549cbebf60 
[1:1:0711/194857.061222:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194857.061490:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194857.062120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 440
[1:1:0711/194857.062347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 440 0x7f2d41f8d070 0x3549cbf7c60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 255 0x7f2d41f8d070 0x3549cbebf60 
[1:1:0711/194857.068536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3732588229c8, 0x3549c399150
[1:1:0711/194857.069699:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 4
[1:1:0711/194857.070371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 441
[1:1:0711/194857.070609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 441 0x7f2d41f8d070 0x3549d0a2fe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 255 0x7f2d41f8d070 0x3549cbebf60 
[1:1:0711/194857.072957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3732588229c8, 0x3549c399150
[1:1:0711/194857.073207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 4
[1:1:0711/194857.073762:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 442
[1:1:0711/194857.074008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 442 0x7f2d41f8d070 0x3549cb00160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 255 0x7f2d41f8d070 0x3549cbebf60 
[1:1:0711/194857.106764:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 259, 7f2d448d2881
[1:1:0711/194857.123459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194857.123839:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194857.124477:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194857.125561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , AppMeasurement.a.Qa, (){a.b=a.d.body;a.b?(a.v=function(c){var b,d,f,e,g;if(!(a.d&&a.d.getElementById("cppXYctnr")||c&&c["
[1:1:0711/194857.125817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194857.198351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 293, 7f2d448d2881
[1:1:0711/194857.221825:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194857.222277:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"246 0x7f2d422f5bd0 0x3549cbd8458 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194857.222803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194857.223698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){loop(pollGroup)}
[1:1:0711/194857.224008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194857.273647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194857.273972:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194857.274776:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 455
[1:1:0711/194857.275039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 455 0x7f2d41f8d070 0x3549d4427e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 293 0x7f2d41f8d070 0x3549cbf7ae0 
[1:1:0711/194857.406307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3732588229c8, 0x3549c399150
[1:1:0711/194857.406575:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 100
[1:1:0711/194857.407141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 457
[1:1:0711/194857.407569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 457 0x7f2d41f8d070 0x3549d0885e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 293 0x7f2d41f8d070 0x3549cbf7ae0 
[1:1:0711/194858.323653:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/194858.323944:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194858.325576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0711/194858.325826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[4256:4256:0711/194858.432314:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/194858.792358:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.468136, 1830, 1
[1:1:0711/194858.792646:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/194900.094172:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 20
[1:1:0711/194900.094487:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 500
[1:1:0711/194900.094599:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 500 0x7f2d41f8d070 0x3549d7b3de0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 345 0x7f2d41f8d070 0x3549cc541e0 
[1:1:0711/194900.094914:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x3732588229c8, 0x3549d6ac300
[1:1:0711/194900.095011:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 10000
[1:1:0711/194900.095207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 501
[1:1:0711/194900.095310:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 501 0x7f2d41f8d070 0x3549d688360 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 345 0x7f2d41f8d070 0x3549cc541e0 
[1:1:0711/194901.475854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/194901.476174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.364504:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 439, 7f2d448d2881
[1:1:0711/194902.385479:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.385873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.386317:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194902.387054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=foresterUrl}
[1:1:0711/194902.387269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.395204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 440, 7f2d448d2881
[1:1:0711/194902.427032:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.427384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.427804:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194902.428621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=csdsUrl}
[1:1:0711/194902.428871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.452588:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 441, 7f2d448d2881
[1:1:0711/194902.476262:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.476626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.477063:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194902.477859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0711/194902.478073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.520360:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3732588229c8, 0x3549c399150
[1:1:0711/194902.520638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 50
[1:1:0711/194902.521429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 591
[1:1:0711/194902.521692:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7f2d41f8d070 0x3549cc171e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 441 0x7f2d41f8d070 0x3549d0a2fe0 
[1:1:0711/194902.557850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 442, 7f2d448d2881
[1:1:0711/194902.584238:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.584600:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"255 0x7f2d41f8d070 0x3549cbebf60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.585030:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194902.585751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0711/194902.586043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.631093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 455, 7f2d448d2881
[1:1:0711/194902.659407:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"293 0x7f2d41f8d070 0x3549cbf7ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.659790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"293 0x7f2d41f8d070 0x3549cbf7ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.660261:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194902.661028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194902.661253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.697735:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 457, 7f2d448d2881
[1:1:0711/194902.716735:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"293 0x7f2d41f8d070 0x3549cbf7ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.717104:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"293 0x7f2d41f8d070 0x3549cbf7ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194902.717538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194902.718281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){loop(pollGroup)}
[1:1:0711/194902.718516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.740669:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194902.740978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194902.741746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 600
[1:1:0711/194902.742077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f2d41f8d070 0x3549d6d5860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 457 0x7f2d41f8d070 0x3549d0885e0 
[1:1:0711/194902.863753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3732588229c8, 0x3549c399150
[1:1:0711/194902.864057:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 100
[1:1:0711/194902.864587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 602
[1:1:0711/194902.864827:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f2d41f8d070 0x3549d683a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 457 0x7f2d41f8d070 0x3549d0885e0 
[1:1:0711/194902.909681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194902.912402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0711/194902.912629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194902.937036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399518
[1:1:0711/194902.937310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194902.937885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 608
[1:1:0711/194902.938129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f2d41f8d070 0x3549da6d160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 464
[1:1:0711/194902.951057:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399518
[1:1:0711/194902.951332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194902.951980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 609
[1:1:0711/194902.952235:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f2d41f8d070 0x3549da63ee0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 464
[1:1:0711/194902.982798:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399518
[1:1:0711/194902.983105:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194902.983660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 613
[1:1:0711/194902.983982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f2d41f8d070 0x3549d0a23e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 464
[1:1:0711/194903.793652:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/194903.793955:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194903.795250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0711/194903.795488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194903.800852:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7f2d41f8d070 0x3549d68a060 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194904.906685:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194904.907299:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194908.821636:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 5.02731, 0, 0
[1:1:0711/194908.821797:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/194909.132517:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 500, 7f2d448d28db
[1:1:0711/194909.150206:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"345 0x7f2d41f8d070 0x3549cc541e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194909.150593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"345 0x7f2d41f8d070 0x3549cc541e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194909.151123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 638
[1:1:0711/194909.151390:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 638 0x7f2d41f8d070 0x3549d68a7e0 , 5:3_https://aws.amazon.com/, 0, , 500 0x7f2d41f8d070 0x3549d7b3de0 
[1:1:0711/194909.151747:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194909.152637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){var watchedHeaderHeight=Math.floor(document.getElementsByClassName("m-page-header")[0].offsetHeig
[1:1:0711/194909.152866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194912.077741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194912.078012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194913.627172:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 591, 7f2d448d2881
[1:1:0711/194913.658855:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"441 0x7f2d41f8d070 0x3549d0a2fe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194913.659211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"441 0x7f2d41f8d070 0x3549d0a2fe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194913.659605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194913.660280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){X=0;D()}
[1:1:0711/194913.660509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194913.664202:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3732588229c8, 0x3549c399150
[1:1:0711/194913.664407:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 50
[1:1:0711/194913.664949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 676
[1:1:0711/194913.665136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f2d41f8d070 0x3549d6774e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 591 0x7f2d41f8d070 0x3549cc171e0 
[1:1:0711/194913.803418:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 600, 7f2d448d2881
[1:1:0711/194913.813604:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"457 0x7f2d41f8d070 0x3549d0885e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194913.813798:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"457 0x7f2d41f8d070 0x3549d0885e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194913.814018:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194913.814359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194913.814487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194913.990836:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 608, 7f2d448d2881
[1:1:0711/194914.002060:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"464","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.002248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"464","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.002449:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194914.003167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194914.003339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194914.009262:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 609, 7f2d448d2881
[1:1:0711/194914.032725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"464","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.032984:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"464","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.033339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194914.033779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194914.033886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194914.037086:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 602, 7f2d448d2881
[1:1:0711/194914.047046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"457 0x7f2d41f8d070 0x3549d0885e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.047232:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"457 0x7f2d41f8d070 0x3549d0885e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.047479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194914.047828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){loop(pollGroup)}
[1:1:0711/194914.047931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194914.056305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194914.056507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194914.056737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 689
[1:1:0711/194914.056850:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f2d41f8d070 0x3549c5e6260 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 602 0x7f2d41f8d070 0x3549d683a60 
[1:1:0711/194914.065726:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3732588229c8, 0x3549c399150
[1:1:0711/194914.065886:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 200
[1:1:0711/194914.066104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 691
[1:1:0711/194914.066212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f2d41f8d070 0x3549d67b5e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 602 0x7f2d41f8d070 0x3549d683a60 
[1:1:0711/194914.079396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194914.079580:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194914.079785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 694
[1:1:0711/194914.079897:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f2d41f8d070 0x3549f3e3e60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 602 0x7f2d41f8d070 0x3549d683a60 
[1:1:0711/194914.086161:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3732588229c8, 0x3549c399150
[1:1:0711/194914.086287:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 200
[1:1:0711/194914.086515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 695
[1:1:0711/194914.086651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f2d41f8d070 0x3549d675a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 602 0x7f2d41f8d070 0x3549d683a60 
[1:1:0711/194914.153143:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 613, 7f2d448d2881
[1:1:0711/194914.187193:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"464","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.187562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"464","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194914.188026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194914.188777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194914.188957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194914.374866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 624 0x7f2d43eb52e0 0x3549cbd9fe0 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194914.378735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , !function(){var librastandardlib_event_utils_onWindowLoad,librastandardlib_event_utils_onDOMContentL
[1:1:0711/194914.378954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194914.575281:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/194914.575514:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194914.577445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0711/194914.577710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194914.584209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f2d41f8d070 0x3549d67d060 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.053691:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3732588229c8, 0x3549c399198
[1:1:0711/194915.053935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 5000
[1:1:0711/194915.054613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 753
[1:1:0711/194915.054810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7f2d41f8d070 0x3549c64db60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 631 0x7f2d41f8d070 0x3549d67d060 
[1:1:0711/194915.062106:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f2d41f8d070 0x3549d67d060 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.065054:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f2d41f8d070 0x3549d67d060 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.066524:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.068123:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.068738:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.069701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.070598:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.074722:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.076925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399210
[1:1:0711/194915.077036:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194915.077240:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 761
[1:1:0711/194915.077347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7f2d41f8d070 0x3549d6e4e60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 631 0x7f2d41f8d070 0x3549d67d060 
[1:1:0711/194915.077858:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399210
[1:1:0711/194915.077990:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194915.078257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 762
[1:1:0711/194915.078390:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 762 0x7f2d41f8d070 0x3549c651260 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 631 0x7f2d41f8d070 0x3549d67d060 
[1:1:0711/194915.078778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399210
[1:1:0711/194915.078883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194915.079073:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 763
[1:1:0711/194915.079185:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 763 0x7f2d41f8d070 0x3549d44a360 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 631 0x7f2d41f8d070 0x3549d67d060 
[1:1:0711/194915.079512:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399210
[1:1:0711/194915.079626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194915.079951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 764
[1:1:0711/194915.080191:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7f2d41f8d070 0x3549cbd94e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 631 0x7f2d41f8d070 0x3549d67d060 
[1:1:0711/194915.080630:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.547550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.561791:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.564464:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.888284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 638, 7f2d448d28db
[1:1:0711/194915.928346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"500 0x7f2d41f8d070 0x3549d7b3de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194915.928748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"500 0x7f2d41f8d070 0x3549d7b3de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194915.929271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 785
[1:1:0711/194915.929517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7f2d41f8d070 0x3549d6c7660 , 5:3_https://aws.amazon.com/, 0, , 638 0x7f2d41f8d070 0x3549d68a7e0 
[1:1:0711/194915.929891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.930786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){var watchedHeaderHeight=Math.floor(document.getElementsByClassName("m-page-header")[0].offsetHeig
[1:1:0711/194915.931009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194915.938144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 501, 7f2d448d2881
[1:1:0711/194915.976189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"345 0x7f2d41f8d070 0x3549cc541e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194915.976661:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"345 0x7f2d41f8d070 0x3549cc541e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194915.977203:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194915.978183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){clearInterval(watchHeader)}
[1:1:0711/194915.978376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194916.103130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194916.103297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194917.213260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 676, 7f2d448d2881
[1:1:0711/194917.236899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"591 0x7f2d41f8d070 0x3549cc171e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194917.237101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"591 0x7f2d41f8d070 0x3549cc171e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194917.237477:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194917.237872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){X=0;D()}
[1:1:0711/194917.238024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194917.240989:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3732588229c8, 0x3549c399150
[1:1:0711/194917.241219:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 50
[1:1:0711/194917.241897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 804
[1:1:0711/194917.242143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f2d41f8d070 0x3549d6d44e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 676 0x7f2d41f8d070 0x3549d6774e0 
[1:1:0711/194917.316987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7f2d43eb52e0 0x3549d71db60 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194917.319101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , /*
 * Copyright (c) 2007-2015, Marketo, Inc. All rights reserved.
 * Marketo marketing automation we
[1:1:0711/194917.319314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194917.321936:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194917.579978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 689, 7f2d448d2881
[1:1:0711/194917.616455:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194917.616879:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194917.617256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194917.617976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194917.618154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194917.624265:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 694, 7f2d448d2881
[1:1:0711/194917.666629:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194917.667069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194917.667532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194917.668311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194917.668495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194918.103481:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 691, 7f2d448d2881
[1:1:0711/194918.114941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194918.115119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194918.115319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194918.115674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){if(id===count){that.logger.info("Saw new content event");that.processAspects();that.processEvents
[1:1:0711/194918.115876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194918.117907:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 695, 7f2d448d2881
[1:1:0711/194918.142347:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194918.142558:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"602 0x7f2d41f8d070 0x3549d683a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194918.142820:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194918.143702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){if(id===count){that.logger.info("Saw new content event");that.processAspects();that.processEvents
[1:1:0711/194918.143993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194918.253401:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194918.253626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194918.254182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 829
[1:1:0711/194918.254379:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f2d41f8d070 0x3549f3e06e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 695 0x7f2d41f8d070 0x3549d675a60 
[1:1:0711/194918.427035:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194918.427243:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194918.427473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 830
[1:1:0711/194918.427593:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7f2d41f8d070 0x3549d6d5b60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 695 0x7f2d41f8d070 0x3549d675a60 
[1:1:0711/194919.976595:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 761, 7f2d448d2881
[1:1:0711/194920.008918:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194920.009236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194920.009604:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194920.010347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194920.010529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[4256:4256:0711/194920.433084:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/194921.834122:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194921.834284:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194921.834515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 857
[1:1:0711/194921.834893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 857 0x7f2d41f8d070 0x3549d688ee0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 761 0x7f2d41f8d070 0x3549d6e4e60 
[1:1:0711/194921.842763:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194921.842998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194921.843546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 858
[1:1:0711/194921.843740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f2d41f8d070 0x354a08bcbe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 761 0x7f2d41f8d070 0x3549d6e4e60 
[1:1:0711/194921.848119:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194921.848361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194921.848848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 859
[1:1:0711/194921.849035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 859 0x7f2d41f8d070 0x3549cbd3860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 761 0x7f2d41f8d070 0x3549d6e4e60 
[1:1:0711/194921.903988:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 762, 7f2d448d2881
[1:1:0711/194921.948936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194921.949341:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194921.949790:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194921.950671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194921.950909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194921.956543:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194921.956777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194921.957444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 867
[1:1:0711/194921.957693:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 867 0x7f2d41f8d070 0x3549d672760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 762 0x7f2d41f8d070 0x3549c651260 
[1:1:0711/194921.960178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 763, 7f2d448d2881
[1:1:0711/194922.001346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194922.001646:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194922.002010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194922.002723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194922.002899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194922.004294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3732588229c8, 0x3549c399150
[1:1:0711/194922.004456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 800
[1:1:0711/194922.005147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 870
[1:1:0711/194922.005370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f2d41f8d070 0x3549c651ce0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 763 0x7f2d41f8d070 0x3549d44a360 
[1:1:0711/194922.008793:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194922.008999:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194922.009595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 871
[1:1:0711/194922.009800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7f2d41f8d070 0x3549d098de0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 763 0x7f2d41f8d070 0x3549d44a360 
[1:1:0711/194922.156559:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 764, 7f2d448d2881
[1:1:0711/194922.168896:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194922.169217:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194922.169598:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194922.170229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194922.170411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194922.171274:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3732588229c8, 0x3549c399150
[1:1:0711/194922.171447:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 800
[1:1:0711/194922.171855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 879
[1:1:0711/194922.172057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 879 0x7f2d41f8d070 0x3549d2f4060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 764 0x7f2d41f8d070 0x3549cbd94e0 
[1:1:0711/194922.173753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194922.173927:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194922.174323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 880
[1:1:0711/194922.174512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7f2d41f8d070 0x3549d67d2e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 764 0x7f2d41f8d070 0x3549cbd94e0 
[1:1:0711/194922.440572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){if(!docHead.classList.contains(fontClass)){localStorage.setItem(KEY,fontClass);docHead.classList.
[1:1:0711/194922.440900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194922.485343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194922.485670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/194922.932090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 804, 7f2d448d2881
[1:1:0711/194922.954063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"676 0x7f2d41f8d070 0x3549d6774e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194922.954497:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"676 0x7f2d41f8d070 0x3549d6774e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194922.955026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194922.955552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){X=0;D()}
[1:1:0711/194922.955707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194922.973339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194922.989771:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399500
[1:1:0711/194922.990071:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194922.990591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 892
[1:1:0711/194922.990778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f2d41f8d070 0x3549d6734e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 804 0x7f2d41f8d070 0x3549d6d44e0 
[1:1:0711/194923.000923:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399500
[1:1:0711/194923.001168:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194923.001771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 893
[1:1:0711/194923.002194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 893 0x7f2d41f8d070 0x3549cbe18e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 804 0x7f2d41f8d070 0x3549d6d44e0 
[4256:4256:0711/194923.006732:INFO:CONSOLE(19)] "Uncaught Error: Load timeout for modules: libra/libra-bundle
http://requirejs.org/docs/errors.html#timeout", source: https://a0.awsstatic.com/libra/1.0.284/libra-head.js (19)
[4256:4256:0711/194923.007418:INFO:CONSOLE(48)] "Uncaught Script error.", source: https://a0.awsstatic.com/libra/1.0.284/libra-head.js (48)
[1:1:0711/194923.744286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 829, 7f2d448d2881
[1:1:0711/194923.767760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"695 0x7f2d41f8d070 0x3549d675a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194923.767963:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"695 0x7f2d41f8d070 0x3549d675a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194923.768263:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194923.768772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194923.768919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194923.769479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3732588229c8, 0x3549c399150
[1:1:0711/194923.769583:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 800
[1:1:0711/194923.769790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 914
[1:1:0711/194923.769897:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 914 0x7f2d41f8d070 0x354a0f64360 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 829 0x7f2d41f8d070 0x3549f3e06e0 
[1:1:0711/194923.771314:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194923.771415:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194923.771604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 915
[1:1:0711/194923.771707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 915 0x7f2d41f8d070 0x354a0f5cf60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 829 0x7f2d41f8d070 0x3549f3e06e0 
[1:1:0711/194923.772406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 830, 7f2d448d2881
[1:1:0711/194923.805543:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"695 0x7f2d41f8d070 0x3549d675a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194923.805909:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"695 0x7f2d41f8d070 0x3549d675a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194923.806332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194923.807017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194923.807192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194923.808334:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3732588229c8, 0x3549c399150
[1:1:0711/194923.808509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 800
[1:1:0711/194923.809007:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 917
[1:1:0711/194923.809201:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7f2d41f8d070 0x354a0f64060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 830 0x7f2d41f8d070 0x3549d6d5b60 
[1:1:0711/194923.813064:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399150
[1:1:0711/194923.813292:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194923.813899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 918
[1:1:0711/194923.814135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7f2d41f8d070 0x3549cbe19e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 830 0x7f2d41f8d070 0x3549d6d5b60 
[1:1:0711/194924.946747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 753, 7f2d448d2881
[1:1:0711/194924.974364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194924.974546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"631 0x7f2d41f8d070 0x3549d67d060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194924.974774:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194924.975110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){b.F&&(b.complete?b.va():(a.trackOffline&&b.abort&&b.abort(),b.Ga()))}
[1:1:0711/194924.975212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194924.976790:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3732588229c8, 0x3549c399150
[1:1:0711/194924.976897:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 500
[1:1:0711/194924.977108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 948
[1:1:0711/194924.977214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 948 0x7f2d41f8d070 0x3549d6d66e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 753 0x7f2d41f8d070 0x3549c64db60 
[1:1:0711/194924.978150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 857, 7f2d448d2881
[1:1:0711/194924.990393:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"761 0x7f2d41f8d070 0x3549d6e4e60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194924.990550:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"761 0x7f2d41f8d070 0x3549d6e4e60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194924.990776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194924.991083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=foresterUrl}
[1:1:0711/194924.991184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194925.027309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 858, 7f2d448d2881
[1:1:0711/194925.042489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"761 0x7f2d41f8d070 0x3549d6e4e60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.042677:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"761 0x7f2d41f8d070 0x3549d6e4e60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.042908:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194925.043252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=csdsUrl}
[1:1:0711/194925.043372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194925.046801:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 859, 7f2d448d2881
[1:1:0711/194925.059702:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"761 0x7f2d41f8d070 0x3549d6e4e60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.059878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"761 0x7f2d41f8d070 0x3549d6e4e60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.060111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194925.060539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194925.060656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194925.062478:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 867, 7f2d448d2881
[1:1:0711/194925.099208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"762 0x7f2d41f8d070 0x3549c651260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.099575:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"762 0x7f2d41f8d070 0x3549c651260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.100069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194925.100973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194925.101155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194925.188663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 871, 7f2d448d2881
[1:1:0711/194925.214345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"763 0x7f2d41f8d070 0x3549d44a360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.214732:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"763 0x7f2d41f8d070 0x3549d44a360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194925.215217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194925.216255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194925.216506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194927.107205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 880, 7f2d448d2881
[1:1:0711/194927.126448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"764 0x7f2d41f8d070 0x3549cbd94e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194927.127940:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"764 0x7f2d41f8d070 0x3549cbd94e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194927.128587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194927.129437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194927.129988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194927.297851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194927.298094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194927.401181:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 870, 7f2d448d2881
[1:1:0711/194927.415251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"763 0x7f2d41f8d070 0x3549d44a360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194927.415439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"763 0x7f2d41f8d070 0x3549d44a360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194927.415664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194927.416007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0711/194927.416135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194929.242027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 879, 7f2d448d2881
[1:1:0711/194929.275992:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"764 0x7f2d41f8d070 0x3549cbd94e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194929.276178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"764 0x7f2d41f8d070 0x3549cbd94e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194929.276379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194929.276741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0711/194929.276850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194929.500348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 892, 7f2d448d2881
[1:1:0711/194929.544534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"804 0x7f2d41f8d070 0x3549d6d44e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194929.544943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"804 0x7f2d41f8d070 0x3549d6d44e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194929.545468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194929.546345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194929.546571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194929.554772:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 893, 7f2d448d2881
[1:1:0711/194929.578312:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"804 0x7f2d41f8d070 0x3549d6d44e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194929.578510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"804 0x7f2d41f8d070 0x3549d6d44e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194929.578767:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194929.579132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){(new Image).src=url}
[1:1:0711/194929.579235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194929.631909:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 899 0x7f2d43eb52e0 0x354a0d6d960 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194929.634076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , /*
 * Copyright (c) 2007-2015, Marketo, Inc. All rights reserved.
 * Marketo marketing automation we
[1:1:0711/194929.634229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194929.646939:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194929.983873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 915, 7f2d448d2881
[1:1:0711/194930.021135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"829 0x7f2d41f8d070 0x3549f3e06e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.021351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"829 0x7f2d41f8d070 0x3549f3e06e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.021654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194930.022539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194930.022834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194930.025261:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 918, 7f2d448d2881
[1:1:0711/194930.045395:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"830 0x7f2d41f8d070 0x3549d6d5b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.045859:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"830 0x7f2d41f8d070 0x3549d6d5b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.046394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194930.047369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/194930.047602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194930.201423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 914, 7f2d448d2881
[1:1:0711/194930.223089:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"829 0x7f2d41f8d070 0x3549f3e06e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.223465:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"829 0x7f2d41f8d070 0x3549f3e06e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.223883:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194930.224367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0711/194930.224494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194930.530639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 917, 7f2d448d2881
[1:1:0711/194930.573914:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"830 0x7f2d41f8d070 0x3549d6d5b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.574105:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"830 0x7f2d41f8d070 0x3549d6d5b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194930.574310:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194930.574649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0711/194930.574765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194931.666903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 948, 7f2d448d2881
[1:1:0711/194931.721188:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1797ecba2860","ptid":"753 0x7f2d41f8d070 0x3549c64db60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194931.721638:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"753 0x7f2d41f8d070 0x3549c64db60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0711/194931.722149:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194931.723118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , AppMeasurement.a.ka, (){if(a.q&&(a.B&&a.B.complete&&a.B.F&&a.B.va(),a.q))return;a.Ja=n;if(a.qa)a.ma>a.N&&a.Pa(a.i),a.ua(5
[1:1:0711/194931.723360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/194933.867598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194933.867848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194933.911844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194933.912528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , b.onload.b.va, (){a.ab(c);b.Da();a.rb();a.ga();a.q=0;a.ka();if(b.Ba){b.Ba=!1;try{a.doPostbacks(a.X(b.responseText))
[1:1:0711/194933.912682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194934.452672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194934.453139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , O.d.onreadystatechange, (){2<=d.readyState&&d.abort()}
[1:1:0711/194934.453281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194936.261276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194936.261488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194937.237889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194937.238143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194937.792159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194937.792396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194937.989202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194937.989443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194938.102183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1170 0x7f2d43eb52e0 0x3549d683f60 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194938.121556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (function(){define("libra/core/libra-namespace",[],function(){if(typeof Libra!=="object"){Libra={}}r
[1:1:0711/194938.121767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194938.251398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/194942.913626:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194942.914109:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194942.914515:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/194942.914935:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[4256:4256:0711/194943.851883:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/194946.043600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399210
[1:1:0711/194946.043893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194946.044459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1186
[1:1:0711/194946.044754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1186 0x7f2d41f8d070 0x354a2ca48e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1170 0x7f2d43eb52e0 0x3549d683f60 
[1:1:0711/194947.081751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , document.readyState
[1:1:0711/194947.082057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194947.404585:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter"
[1:1:0711/194947.405466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1797ecba2860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0711/194947.405718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0711/194947.426862:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3732588229c8, 0x3549c399210
[1:1:0711/194947.427123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=UK_amazonfooter", 0
[1:1:0711/194947.427769:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1218
[1:1:0711/194947.428005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1218 0x7f2d41f8d070 0x354a0fe5e60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1184
