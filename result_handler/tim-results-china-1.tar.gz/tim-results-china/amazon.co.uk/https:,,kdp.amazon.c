[0711/195333.897996:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195333.898523:INFO:switcher_clone.cc(787)] backtrace rip is 7f4c1b41e891
[0711/195334.792881:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195334.793149:INFO:switcher_clone.cc(787)] backtrace rip is 7f1ded7f9891
[1:1:0711/195334.797223:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/195334.797412:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/195334.802049:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[5019:5019:0711/195335.896334:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/e93d25df-e850-49c9-a509-6bd99ff9afa8
[0711/195336.273081:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195336.273550:INFO:switcher_clone.cc(787)] backtrace rip is 7fc3763bd891
[5019:5019:0711/195336.342989:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[5019:5049:0711/195336.343788:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/195336.344013:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/195336.344227:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/195336.344821:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/195336.344971:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/195336.347717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x332662f1, 1
[1:1:0711/195336.348111:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3ab90856, 0
[1:1:0711/195336.348303:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x705a238, 3
[1:1:0711/195336.348487:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2fd43117, 2
[1:1:0711/195336.348719:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5608ffffffb93a fffffff1622633 1731ffffffd42f 38ffffffa20507 , 10104, 4
[1:1:0711/195336.349636:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5019:5049:0711/195336.349895:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGV�:�b&31�/8�)��
[5019:5049:0711/195336.349965:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is V�:�b&31�/8��+)��
[1:1:0711/195336.349884:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1deba340a0, 3
[1:1:0711/195336.350125:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1debbbf080, 2
[5019:5049:0711/195336.350291:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/195336.350271:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1dd5882d20, -2
[5019:5049:0711/195336.350371:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5064, 4, 5608b93a f1622633 1731d42f 38a20507 
[1:1:0711/195336.372363:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/195336.373453:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2fd43117
[1:1:0711/195336.374451:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2fd43117
[1:1:0711/195336.376349:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2fd43117
[1:1:0711/195336.378242:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.378473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.378727:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.378957:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.379755:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2fd43117
[1:1:0711/195336.380153:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1ded7f97ba
[1:1:0711/195336.380322:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1ded7f0def, 7f1ded7f977a, 7f1ded7fb0cf
[1:1:0711/195336.387438:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2fd43117
[1:1:0711/195336.387880:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2fd43117
[1:1:0711/195336.388809:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2fd43117
[1:1:0711/195336.391340:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.391600:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.391859:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.392087:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fd43117
[1:1:0711/195336.393696:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2fd43117
[1:1:0711/195336.394169:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1ded7f97ba
[1:1:0711/195336.394334:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1ded7f0def, 7f1ded7f977a, 7f1ded7fb0cf
[1:1:0711/195336.404080:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/195336.404686:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/195336.404864:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc3a111658, 0x7ffc3a1115d8)
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/195336.420467:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/195336.426499:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5051:5051:0711/195336.507645:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5051
[5078:5078:0711/195336.508130:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5078
[5019:5019:0711/195336.916094:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5019:5019:0711/195336.917499:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5019:5030:0711/195336.932046:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[5019:5019:0711/195336.932401:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[5019:5019:0711/195336.932816:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[5019:5030:0711/195336.932829:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[5019:5019:0711/195336.933040:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5064, 4
[1:7:0711/195336.937622:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[5019:5041:0711/195336.974946:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/195337.003275:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x31d759cf9220
[1:1:0711/195337.017219:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/195337.252500:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[5019:5019:0711/195338.606361:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[5019:5019:0711/195338.606448:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/195338.646836:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195338.650249:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195339.554610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 213203341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/195339.555001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195339.573845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 213203341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/195339.574120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195339.642639:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195340.009471:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195340.009787:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195340.412292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195340.420803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 213203341f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/195340.421062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195340.457173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195340.467597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 213203341f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/195340.467894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195340.479899:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[5019:5019:0711/195340.481940:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/195340.484263:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x31d759cf7e20
[1:1:0711/195340.484484:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5019:5019:0711/195340.489695:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[5019:5019:0711/195340.522483:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[5019:5019:0711/195340.522682:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/195340.593195:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195341.451995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7f1dd745d2e0 0x31d759f3a4e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195341.453382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 213203341f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/195341.453624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195341.455133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5019:5019:0711/195341.522137:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/195341.523778:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x31d759cf8820
[1:1:0711/195341.523968:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5019:5019:0711/195341.528564:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/195341.545969:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/195341.546196:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[5019:5019:0711/195341.547242:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[5019:5019:0711/195341.558784:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5019:5019:0711/195341.560015:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5019:5030:0711/195341.567657:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[5019:5030:0711/195341.567761:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[5019:5019:0711/195341.567996:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[5019:5019:0711/195341.568127:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[5019:5019:0711/195341.568312:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5064, 4
[1:7:0711/195341.575266:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/195342.224941:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/195342.462737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 491 0x7f1dd745d2e0 0x31d75a0b9f60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195342.463812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 213203341f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/195342.464105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195342.464870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5019:5019:0711/195342.608474:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[5019:5019:0711/195342.608612:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/195342.640854:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195343.709444:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195344.812718:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195344.813018:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[5019:5019:0711/195345.000776:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[5019:5049:0711/195345.001345:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/195345.001613:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/195345.001893:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/195345.002335:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/195345.002509:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/195345.005391:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b7a051c, 1
[1:1:0711/195345.005751:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x18f3d0c2, 0
[1:1:0711/195345.005932:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2977f418, 3
[1:1:0711/195345.006157:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ae38ed2, 2
[1:1:0711/195345.006329:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc2ffffffd0fffffff318 1c057a3b ffffffd2ffffff8effffffe31a 18fffffff47729 , 10104, 5
[1:1:0711/195345.008717:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5019:5049:0711/195345.008995:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���z;Ҏ��w)���
[5019:5049:0711/195345.009100:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���z;Ҏ��w)�����
[1:1:0711/195345.008987:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1deba340a0, 3
[1:1:0711/195345.009226:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1debbbf080, 2
[5019:5049:0711/195345.009365:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5118, 5, c2d0f318 1c057a3b d28ee31a 18f47729 
[1:1:0711/195345.009470:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1dd5882d20, -2
[1:1:0711/195345.030349:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/195345.030716:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ae38ed2
[1:1:0711/195345.031074:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ae38ed2
[1:1:0711/195345.031719:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ae38ed2
[1:1:0711/195345.033190:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.033409:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.033634:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.033847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.034554:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ae38ed2
[1:1:0711/195345.034878:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1ded7f97ba
[1:1:0711/195345.035089:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1ded7f0def, 7f1ded7f977a, 7f1ded7fb0cf
[1:1:0711/195345.040821:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ae38ed2
[1:1:0711/195345.041230:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ae38ed2
[1:1:0711/195345.041985:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ae38ed2
[1:1:0711/195345.044131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.044379:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.044597:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.044824:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ae38ed2
[1:1:0711/195345.046121:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ae38ed2
[1:1:0711/195345.046516:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1ded7f97ba
[1:1:0711/195345.046687:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1ded7f0def, 7f1ded7f977a, 7f1ded7fb0cf
[1:1:0711/195345.053486:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/195345.053996:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/195345.054206:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc3a111658, 0x7ffc3a1115d8)
[1:1:0711/195345.065837:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/195345.070659:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/195345.281251:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x31d759cdc220
[1:1:0711/195345.281522:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/195345.350184:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 600, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195345.354707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2132034709f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/195345.354994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195345.362819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[5019:5019:0711/195346.922149:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5019:5019:0711/195346.929634:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5019:5030:0711/195346.947690:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[5019:5030:0711/195346.947809:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[5019:5019:0711/195346.948308:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://kdp.amazon.com/
[5019:5019:0711/195346.948419:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kdp.amazon.com/, https://kdp.amazon.com/en_US/, 1
[5019:5019:0711/195346.948708:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://kdp.amazon.com/, HTTP/1.1 200 OK Server: Server Date: Fri, 12 Jul 2019 02:53:46 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive x-amz-id-1: GF12T3J8WMG5DDWYZV3W x-amz-id-2: ipw-na-1e-740fbdfe.us-east-1.amazon.com X-Frame-Options: DENY Cache-Control: no-cache, no-store, must-revalidate, max-age=0 Pragma: no-cache Expires: Thu, 01 Jan 1970 00:00:00 GMT X-UA-Compatible: IE=edge,chrome=1 Content-Security-Policy-Report-Only: report-uri /csp-report; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://m.media-amazon.com https://images-na.ssl-images-amazon.com https://c2c.amazon.com https://fls-na.amazon.com https://d2pj26hw09r2m6.cloudfront.net; X-Content-Security-Policy-Report-Only: report-uri /csp-report; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://m.media-amazon.com https://images-na.ssl-images-amazon.com https://c2c.amazon.com https://fls-na.amazon.com https://d2pj26hw09r2m6.cloudfront.net; X-WebKit-CSP-Report-Only: report-uri /csp-report; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://m.media-amazon.com https://images-na.ssl-images-amazon.com https://c2c.amazon.com https://fls-na.amazon.com https://d2pj26hw09r2m6.cloudfront.net; Content-Language: en-US Content-Encoding: gzip Vary: Accept-Encoding,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment,User-Agent Set-Cookie: ubid-main=133-0156954-0777455; Domain=.amazon.com; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ Set-Cookie: kdp-lc-main=en_US; Domain=.amazon.com; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ x-amz-rid: GF12T3J8WMG5DDWYZV3W  ,5118, 5
[1:7:0711/195346.953246:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/195346.984364:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://kdp.amazon.com/
[5019:5019:0711/195347.165155:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kdp.amazon.com/, https://kdp.amazon.com/, 1
[5019:5019:0711/195347.165280:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://kdp.amazon.com/, https://kdp.amazon.com
[1:1:0711/195347.202377:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195347.203171:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195347.303140:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195347.424500:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195347.424782:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kdp.amazon.com/en_US/"
[1:1:0711/195347.441940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143 0x7f1dd5535070 0x31d759dc2ee0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195347.443999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , var aPageStart = (new Date()).getTime();
[1:1:0711/195347.444351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195347.447956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143 0x7f1dd5535070 0x31d759dc2ee0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195347.451851:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143 0x7f1dd5535070 0x31d759dc2ee0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195347.461434:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195347.513507:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/195348.417232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 194 0x7f1dd5535070 0x31d759db9060 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195348.424557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , 
(function(f,h,H,t){function u(a,b){n&&n.count&&n.count("aui:"+a,0===b?0:b||(n.count("aui:"+a)||0)+1
[1:1:0711/195348.424807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195348.433576:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1bc8d5e7f50
[1:1:0711/195348.447482:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x2fd24d7c29c8, 0x31d7598039a0
[1:1:0711/195348.447755:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 20
[1:1:0711/195348.448232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 197
[1:1:0711/195348.448461:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 197 0x7f1dd5535070 0x31d759f3cfe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 194 0x7f1dd5535070 0x31d759db9060 
[1:1:0711/195348.570643:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d7598039a0
[1:1:0711/195348.570954:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195348.571382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 199
[1:1:0711/195348.571623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 199 0x7f1dd5535070 0x31d759f048e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 194 0x7f1dd5535070 0x31d759db9060 
[1:1:0711/195348.599487:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 194 0x7f1dd5535070 0x31d759db9060 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195348.626894:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195348.627197:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195348.627586:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 212
[1:1:0711/195348.627883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 212 0x7f1dd5535070 0x31d759f04760 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 194 0x7f1dd5535070 0x31d759db9060 
[1:1:0711/195348.667525:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.071794, 622, 1
[1:1:0711/195348.667787:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195348.713438:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195348.945137:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195348.945500:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kdp.amazon.com/en_US/"
[1:1:0711/195348.946513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f1dd5535070 0x31d75a08a8e0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195348.948121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , 
P.when('A').execute(function(A) {
A.on('bidi-shim:add-dir-auto', function() {
A.$('textarea, input[
[1:1:0711/195348.948410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195348.963395:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0177112, 72, 1
[1:1:0711/195348.963645:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195348.976506:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 197, 7f1dd7e7a881
[1:1:0711/195348.987213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"194 0x7f1dd5535070 0x31d759db9060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195348.987535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"194 0x7f1dd5535070 0x31d759db9060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195348.987835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195348.988431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , ba, (){h.body?m.trigger("a-bodyBegin"):setTimeout(ba,20)}
[1:1:0711/195348.988650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195349.004630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 199, 7f1dd7e7a881
[1:1:0711/195349.012717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"194 0x7f1dd5535070 0x31d759db9060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195349.013034:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"194 0x7f1dd5535070 0x31d759db9060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195349.013345:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195349.013897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195349.014121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195349.015117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195349.015327:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195349.015713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 235
[1:1:0711/195349.015943:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 235 0x7f1dd5535070 0x31d759f637e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 199 0x7f1dd5535070 0x31d759f048e0 
[1:1:0711/195349.124589:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195349.124874:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kdp.amazon.com/en_US/"
[1:1:0711/195349.125797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 234 0x7f1dd5535070 0x31d7596421e0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195349.127046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , 
P.when('A', 'Jele', 'JeleScripterReady', 'ready').execute(function(A, Jele, JeleScripterReady){
Jel
[1:1:0711/195349.127326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195349.137137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 234 0x7f1dd5535070 0x31d7596421e0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195349.183429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d7598039e8
[1:1:0711/195349.183694:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195349.184093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 250
[1:1:0711/195349.184359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 250 0x7f1dd5535070 0x31d759f4f1e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 234 0x7f1dd5535070 0x31d7596421e0 
[1:1:0711/195349.190721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://kdp.amazon.com/en_US/"
[1:1:0711/195349.815065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 250, 7f1dd7e7a881
[1:1:0711/195349.830196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"234 0x7f1dd5535070 0x31d7596421e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195349.830588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"234 0x7f1dd5535070 0x31d7596421e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195349.830916:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195349.831487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195349.831723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195349.832513:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195349.832714:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195349.833115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 276
[1:1:0711/195349.833349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 276 0x7f1dd5535070 0x31d75a171e60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 250 0x7f1dd5535070 0x31d759f4f1e0 
[1:1:0711/195349.895122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 212, 7f1dd7e7a881
[1:1:0711/195349.900402:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"194 0x7f1dd5535070 0x31d759db9060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195349.900731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"194 0x7f1dd5535070 0x31d759db9060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195349.901008:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195349.901575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0711/195349.901781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195349.922990:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195349.923251:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195349.923640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 281
[1:1:0711/195349.923879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 281 0x7f1dd5535070 0x31d75a5248e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 212 0x7f1dd5535070 0x31d759f04760 
[1:1:0711/195350.017477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f1dd745d2e0 0x31d75a5226e0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195350.042561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (function(c){var b=window.AmazonUIPageJS||window.P,d=b._namespace||b.attributeErrors,a=d?d("AmazonUI
[1:1:0711/195350.042911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195350.054239:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803960
[1:1:0711/195350.054508:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195350.054905:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 291
[1:1:0711/195350.055125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 291 0x7f1dd5535070 0x31d759fd5260 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 288 0x7f1dd745d2e0 0x31d75a5226e0 
[1:1:0711/195350.338481:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 291, 7f1dd7e7a881
[1:1:0711/195350.351392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"288 0x7f1dd745d2e0 0x31d75a5226e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195350.351734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"288 0x7f1dd745d2e0 0x31d75a5226e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195350.352038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195350.352641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195350.352876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195350.353576:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195350.353772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195350.354148:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 296
[1:1:0711/195350.354371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 296 0x7f1dd5535070 0x31d75a179d60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 291 0x7f1dd5535070 0x31d759fd5260 
[1:1:0711/195351.295285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 296, 7f1dd7e7a881
[1:1:0711/195351.308741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"291 0x7f1dd5535070 0x31d759fd5260 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.309094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"291 0x7f1dd5535070 0x31d759fd5260 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.309418:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195351.310002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195351.310327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195351.311028:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.311226:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.311594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 305
[1:1:0711/195351.311894:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 305 0x7f1dd5535070 0x31d759641460 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 296 0x7f1dd5535070 0x31d75a179d60 
[1:1:0711/195351.386778:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 281, 7f1dd7e7a881
[1:1:0711/195351.392747:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"212 0x7f1dd5535070 0x31d759f04760 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.393081:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"212 0x7f1dd5535070 0x31d759f04760 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.393366:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195351.393938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0711/195351.394162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195351.413791:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.414079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195351.414480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 309
[1:1:0711/195351.414710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 309 0x7f1dd5535070 0x31d75a106ee0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 281 0x7f1dd5535070 0x31d75a5248e0 
[1:1:0711/195351.462311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 305, 7f1dd7e7a881
[1:1:0711/195351.476118:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"296 0x7f1dd5535070 0x31d75a179d60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.476466:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"296 0x7f1dd5535070 0x31d75a179d60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.476765:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195351.477310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195351.477520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195351.478338:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.478556:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.479042:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 312
[1:1:0711/195351.479310:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 312 0x7f1dd5535070 0x31d759b59a60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 305 0x7f1dd5535070 0x31d759641460 
[1:1:0711/195351.629563:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 312, 7f1dd7e7a881
[1:1:0711/195351.643892:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"305 0x7f1dd5535070 0x31d759641460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.644278:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"305 0x7f1dd5535070 0x31d759641460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.644581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195351.645133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195351.645353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195351.646049:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.646242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.646604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 321
[1:1:0711/195351.646819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 321 0x7f1dd5535070 0x31d75a10bd60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 312 0x7f1dd5535070 0x31d759b59a60 
[1:1:0711/195351.691885:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.692209:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.692833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 322
[1:1:0711/195351.693101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 322 0x7f1dd5535070 0x31d759cbeee0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 312 0x7f1dd5535070 0x31d759b59a60 
[1:1:0711/195351.700262:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.700484:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0711/195351.700847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 323
[1:1:0711/195351.701080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 323 0x7f1dd5535070 0x31d759ee7f60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 312 0x7f1dd5535070 0x31d759b59a60 
[1:1:0711/195351.703874:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.704121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.704480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 324
[1:1:0711/195351.704706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 324 0x7f1dd5535070 0x31d759f4e3e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 312 0x7f1dd5535070 0x31d759b59a60 
[1:1:0711/195351.709860:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.710096:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.710631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 325
[1:1:0711/195351.710863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 325 0x7f1dd5535070 0x31d759f53160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 312 0x7f1dd5535070 0x31d759b59a60 
[1:1:0711/195351.715697:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.715945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.716328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 326
[1:1:0711/195351.716550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7f1dd5535070 0x31d75a526160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 312 0x7f1dd5535070 0x31d759b59a60 
[1:1:0711/195351.768298:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 321, 7f1dd7e7a881
[1:1:0711/195351.785277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"312 0x7f1dd5535070 0x31d759b59a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.785642:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"312 0x7f1dd5535070 0x31d759b59a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.785966:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195351.786588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195351.786818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195351.787517:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.787734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.788206:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 331
[1:1:0711/195351.788492:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 331 0x7f1dd5535070 0x31d75a0f4a60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 321 0x7f1dd5535070 0x31d75a10bd60 
[1:1:0711/195351.794143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.794361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.794733:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 332
[1:1:0711/195351.794988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 332 0x7f1dd5535070 0x31d75a0cc860 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 321 0x7f1dd5535070 0x31d75a10bd60 
[1:1:0711/195351.799315:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.799537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.799908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 333
[1:1:0711/195351.800177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7f1dd5535070 0x31d759f4e3e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 321 0x7f1dd5535070 0x31d75a10bd60 
[1:1:0711/195351.815597:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.815928:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.816308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 334
[1:1:0711/195351.816522:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 334 0x7f1dd5535070 0x31d75a4da7e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 321 0x7f1dd5535070 0x31d75a10bd60 
[1:1:0711/195351.857955:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.858270:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.858650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 336
[1:1:0711/195351.858873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 336 0x7f1dd5535070 0x31d75a10afe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 321 0x7f1dd5535070 0x31d75a10bd60 
[1:1:0711/195351.888561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 323, 7f1dd7e7a881
[1:1:0711/195351.895737:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"312 0x7f1dd5535070 0x31d759b59a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.896116:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"312 0x7f1dd5535070 0x31d759b59a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.896426:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195351.897008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0711/195351.897231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195351.898078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.898298:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0711/195351.898689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 340
[1:1:0711/195351.898914:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 340 0x7f1dd5535070 0x31d759f614e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 323 0x7f1dd5535070 0x31d759ee7f60 
[1:1:0711/195351.949223:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 331, 7f1dd7e7a881
[1:1:0711/195351.957230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"321 0x7f1dd5535070 0x31d75a10bd60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.957541:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"321 0x7f1dd5535070 0x31d75a10bd60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195351.957834:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195351.958332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195351.958568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195351.959294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.959503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195351.959887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 346
[1:1:0711/195351.960172:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 346 0x7f1dd5535070 0x31d75a089760 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 331 0x7f1dd5535070 0x31d75a0f4a60 
[1:1:0711/195351.963168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195351.963643:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0711/195351.964197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 347
[1:1:0711/195351.964441:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 347 0x7f1dd5535070 0x31d759db9560 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 331 0x7f1dd5535070 0x31d75a0f4a60 
[1:1:0711/195352.288474:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 333, 7f1dd7e7a881
[1:1:0711/195352.295900:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"321 0x7f1dd5535070 0x31d75a10bd60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195352.296245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"321 0x7f1dd5535070 0x31d75a10bd60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195352.296529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.297160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){return b.apply(null,f)}
[1:1:0711/195352.297494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195352.299276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195352.299466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 100
[1:1:0711/195352.299820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 353
[1:1:0711/195352.300072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 353 0x7f1dd5535070 0x31d75a5214e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 333 0x7f1dd5535070 0x31d759f4e3e0 
[1:1:0711/195352.311245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 340, 7f1dd7e7a881
[1:1:0711/195352.325531:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"323 0x7f1dd5535070 0x31d759ee7f60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195352.325859:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"323 0x7f1dd5535070 0x31d759ee7f60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195352.326173:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.326732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0711/195352.326937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195352.327722:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195352.328000:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0711/195352.328381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 354
[1:1:0711/195352.328619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 354 0x7f1dd5535070 0x31d75a089fe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 340 0x7f1dd5535070 0x31d759f614e0 
[1:1:0711/195352.366597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f1dd745d2e0 0x31d75a107460 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.481451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , /*
 Highcharts JS v3.0.10 (2014-03-10)

 (c) 2009-2014 Torstein Honsi

 License: www.highcharts.com/
[1:1:0711/195352.481748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195352.731989:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 346, 7f1dd7e7a881
[1:1:0711/195352.747252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"331 0x7f1dd5535070 0x31d75a0f4a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195352.747594:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"331 0x7f1dd5535070 0x31d75a0f4a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195352.747908:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.748487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195352.748706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195352.749399:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195352.749593:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195352.750119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 363
[1:1:0711/195352.750357:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 363 0x7f1dd5535070 0x31d75a171960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 346 0x7f1dd5535070 0x31d75a089760 
[1:1:0711/195352.775063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195352.775345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195352.775732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 364
[1:1:0711/195352.776004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7f1dd5535070 0x31d75a0f8ce0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 346 0x7f1dd5535070 0x31d75a089760 
[1:1:0711/195352.862557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.863291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){e[a]||(e[a]=1,A(a))}
[1:1:0711/195352.863505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195352.948077:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803a20
[1:1:0711/195352.948417:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195352.948805:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 369
[1:1:0711/195352.949026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 369 0x7f1dd5535070 0x31d759b49ee0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 355 0x7f1dd5535070 0x31d75a4da7e0 
[1:1:0711/195352.957976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 10000
[1:1:0711/195352.958451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 370
[1:1:0711/195352.958699:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7f1dd5535070 0x31d75a179960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 355 0x7f1dd5535070 0x31d75a4da7e0 
[1:1:0711/195352.963523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.968769:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.969389:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.970548:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0711/195352.988483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.002220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d7598039f0
[1:1:0711/195353.002565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195353.002971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 376
[1:1:0711/195353.003201:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 376 0x7f1dd5535070 0x31d75a0f4360 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 355 0x7f1dd5535070 0x31d75a4da7e0 
[1:1:0711/195353.008631:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d7598039f0
[1:1:0711/195353.008830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195353.009181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 377
[1:1:0711/195353.009378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 377 0x7f1dd5535070 0x31d75a4ff760 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 355 0x7f1dd5535070 0x31d75a4da7e0 
[1:1:0711/195353.012277:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x2fd24d7c29c8, 0x31d7598039f0
[1:1:0711/195353.012517:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1500
[1:1:0711/195353.012881:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 378
[1:1:0711/195353.013149:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 378 0x7f1dd5535070 0x31d75a528de0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 355 0x7f1dd5535070 0x31d75a4da7e0 
[1:1:0711/195353.069530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 354, 7f1dd7e7a881
[1:1:0711/195353.086532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"340 0x7f1dd5535070 0x31d759f614e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.086886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"340 0x7f1dd5535070 0x31d759f614e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.087188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.087768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0711/195353.088021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.088840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195353.089053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0711/195353.089460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 382
[1:1:0711/195353.089701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 382 0x7f1dd5535070 0x31d759cff9e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 354 0x7f1dd5535070 0x31d75a089fe0 
[1:1:0711/195353.091164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 353, 7f1dd7e7a881
[1:1:0711/195353.109686:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"333 0x7f1dd5535070 0x31d759f4e3e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.110057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"333 0x7f1dd5535070 0x31d759f4e3e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.110478:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.111068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){return b.apply(null,f)}
[1:1:0711/195353.111292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.153726:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 309, 7f1dd7e7a881
[1:1:0711/195353.161920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"281 0x7f1dd5535070 0x31d75a5248e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.162262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"281 0x7f1dd5535070 0x31d75a5248e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.162596:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.163152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0711/195353.163379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.175892:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195353.176140:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195353.176542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 384
[1:1:0711/195353.176770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 384 0x7f1dd5535070 0x31d75a0f4260 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 309 0x7f1dd5535070 0x31d75a106ee0 
[1:1:0711/195353.178479:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 347, 7f1dd7e7a881
[1:1:0711/195353.194481:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"331 0x7f1dd5535070 0x31d75a0f4a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.194930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"331 0x7f1dd5535070 0x31d75a0f4a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.195612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.196259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){return b.apply(null,f)}
[1:1:0711/195353.196528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.252597:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 363, 7f1dd7e7a881
[1:1:0711/195353.269118:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"346 0x7f1dd5535070 0x31d75a089760 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.269494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"346 0x7f1dd5535070 0x31d75a089760 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.269844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.270500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195353.270713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.271415:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195353.271606:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195353.272004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 386
[1:1:0711/195353.272275:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 386 0x7f1dd5535070 0x31d75a4ff3e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 363 0x7f1dd5535070 0x31d75a171960 
[1:1:0711/195353.626269:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 369, 7f1dd7e7a881
[1:1:0711/195353.642001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"355 0x7f1dd5535070 0x31d75a4da7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.642364:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"355 0x7f1dd5535070 0x31d75a4da7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.642671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.643191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , q, (){d.log({k:"rtiming",value:l()+"~"+p()},"csm")}
[1:1:0711/195353.643403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.690584:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195353.691059:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195353.691386:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195353.691757:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195353.692088:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195353.698861:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 382, 7f1dd7e7a881
[1:1:0711/195353.717834:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"354 0x7f1dd5535070 0x31d75a089fe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.718165:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"354 0x7f1dd5535070 0x31d75a089fe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.718566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.719117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0711/195353.719323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.764855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 386, 7f1dd7e7a881
[1:1:0711/195353.773075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"363 0x7f1dd5535070 0x31d75a171960 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.773409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"363 0x7f1dd5535070 0x31d75a171960 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195353.773886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.774451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195353.774724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.775437:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195353.775652:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195353.776044:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 399
[1:1:0711/195353.776264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 399 0x7f1dd5535070 0x31d75a0f8ce0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 386 0x7f1dd5535070 0x31d75a4ff3e0 
[1:1:0711/195353.936232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7f1dd745d2e0 0x31d75a4dcee0 , "https://kdp.amazon.com/en_US/"
[1:1:0711/195353.950586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (function(c,e,t){function n(a){for(var b={},c,g,u=0;u<a.length;u++)g=a[u],c=g.r+g.s+g.m,g.c&&(b[c]||
[1:1:0711/195353.950911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195353.963654:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195353.963965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195353.964381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 403
[1:1:0711/195353.964647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 403 0x7f1dd5535070 0x31d759edf9e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 393 0x7f1dd745d2e0 0x31d75a4dcee0 
[1:1:0711/195353.978746:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195353.979068:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195353.979473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 405
[1:1:0711/195353.979778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 405 0x7f1dd5535070 0x31d7596418e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 393 0x7f1dd745d2e0 0x31d75a4dcee0 
[1:1:0711/195353.980884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600000, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195353.981083:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 600000
[1:1:0711/195353.981446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 406
[1:1:0711/195353.981689:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 406 0x7f1dd5535070 0x31d75a0f78e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 393 0x7f1dd745d2e0 0x31d75a4dcee0 
[1:1:0711/195354.007179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195354.007441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 10000
[1:1:0711/195354.008064:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 407
[1:1:0711/195354.008423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 407 0x7f1dd5535070 0x31d759f4c060 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 393 0x7f1dd745d2e0 0x31d75a4dcee0 
[1:1:0711/195354.014430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195354.017774:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195354.018291:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 408
[1:1:0711/195354.018563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 408 0x7f1dd5535070 0x31d759641ce0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 393 0x7f1dd745d2e0 0x31d75a4dcee0 
[1:1:0711/195354.044245:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195354.044679:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195354.045208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 409
[1:1:0711/195354.045472:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 409 0x7f1dd5535070 0x31d75a105d60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 393 0x7f1dd745d2e0 0x31d75a4dcee0 
[1:1:0711/195354.074390:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x2fd24d7c29c8, 0x31d7598039c8
[1:1:0711/195354.074754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0711/195354.075239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 410
[1:1:0711/195354.075520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 410 0x7f1dd5535070 0x31d75a5220e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 393 0x7f1dd745d2e0 0x31d75a4dcee0 
[1:1:0711/195354.187477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 399, 7f1dd7e7a881
[1:1:0711/195354.208941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"386 0x7f1dd5535070 0x31d75a4ff3e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.209298:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"386 0x7f1dd5535070 0x31d75a4ff3e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.209728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195354.210262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195354.210471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195354.211267:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195354.211487:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195354.211932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 422
[1:1:0711/195354.212202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 422 0x7f1dd5535070 0x31d75aa7c160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 399 0x7f1dd5535070 0x31d75a0f8ce0 
[1:1:0711/195354.384984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 405, 7f1dd7e7a881
[1:1:0711/195354.400917:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.401248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.401631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195354.402332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , n, (){var b=k.length;if(0<b){for(var c=[],a=0;a<b;a++){var d=k[a].api;d.ready()?(d.on({ts:f.d,ns:y}),p.
[1:1:0711/195354.402610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195354.404767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 408, 7f1dd7e7a881
[1:1:0711/195354.425866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.426207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.426603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195354.427289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195354.427528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195354.453920:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 409, 7f1dd7e7a881
[1:1:0711/195354.469877:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.470285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.470759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195354.471402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195354.471643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195354.530835:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 410, 7f1dd7e7a881
[1:1:0711/195354.551167:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.551510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.551947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195354.552485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195354.552705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195354.575567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 384, 7f1dd7e7a881
[1:1:0711/195354.582702:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"309 0x7f1dd5535070 0x31d75a106ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.583042:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"309 0x7f1dd5535070 0x31d75a106ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.583450:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195354.584069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0711/195354.584293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195354.603640:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195354.603931:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195354.604350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 434
[1:1:0711/195354.604585:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 434 0x7f1dd5535070 0x31d75a52e560 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 384 0x7f1dd5535070 0x31d75a0f4260 
[1:1:0711/195354.606072:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 422, 7f1dd7e7a881
[1:1:0711/195354.624125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"399 0x7f1dd5535070 0x31d75a0f8ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.624576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"399 0x7f1dd5535070 0x31d75a0f8ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195354.625178:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195354.625807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195354.626039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195354.626734:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195354.627003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195354.627401:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 435
[1:1:0711/195354.627624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 435 0x7f1dd5535070 0x31d759f4ec60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 422 0x7f1dd5535070 0x31d75aa7c160 
		remove user.10_776a56ff -> 0
		remove user.11_da122f51 -> 0
		remove user.12_c8303165 -> 0
		remove user.13_bb724cb9 -> 0
		remove user.14_72c84724 -> 0
[1:1:0711/195357.161639:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195357.162164:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0711/195358.100522:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[5019:5019:0711/195358.113016:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/195401.810065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 378, 7f1dd7e7a881
[1:1:0711/195401.829106:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"355 0x7f1dd5535070 0x31d75a4da7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195401.829490:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"355 0x7f1dd5535070 0x31d75a4da7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195401.829880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195401.830410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){a("beforeAfterLoad");a("afterLoad")}
[1:1:0711/195401.830612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195401.833044:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195401.833248:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195401.833611:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 476
[1:1:0711/195401.833851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 476 0x7f1dd5535070 0x31d759641e60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 378 0x7f1dd5535070 0x31d75a528de0 
[1:1:0711/195401.838359:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195401.838555:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195401.838928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 477
[1:1:0711/195401.839150:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 477 0x7f1dd5535070 0x31d75c9cc160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 378 0x7f1dd5535070 0x31d75a528de0 
[1:1:0711/195401.986562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/195401.986915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195402.299195:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 435, 7f1dd7e7a881
[1:1:0711/195402.318867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"422 0x7f1dd5535070 0x31d75aa7c160 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195402.319233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"422 0x7f1dd5535070 0x31d75aa7c160 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195402.319608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195402.320302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195402.320548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195402.321261:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195402.321471:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195402.321863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 495
[1:1:0711/195402.322109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7f1dd5535070 0x31d75a16a4e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 435 0x7f1dd5535070 0x31d759f4ec60 
[1:1:0711/195402.434674:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 403, 7f1dd7e7a881
[1:1:0711/195402.454664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195402.455027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195402.455421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195402.455950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , k, (){for(var a=0;a<B.length;a++)B[a]();q.length&&d(n(q.splice(0,q.length)),N,K,H);A=L=0}
[1:1:0711/195402.456194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195402.463638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 434, 7f1dd7e7a881
[1:1:0711/195402.484563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"384 0x7f1dd5535070 0x31d75a0f4260 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195402.484898:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"384 0x7f1dd5535070 0x31d75a0f4260 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195402.485286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195402.485821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0711/195402.486049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195402.504967:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195402.505262:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195402.505650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 501
[1:1:0711/195402.505877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 501 0x7f1dd5535070 0x31d75cdcc260 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 434 0x7f1dd5535070 0x31d75a52e560 
[1:1:0711/195403.018554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pointerenter", "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.019402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , k, (a){return"undefined"===typeof c||a&&c.event.triggered===a.type?void 0:c.event.handle.apply(k.elem,a
[1:1:0711/195403.019652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195403.051020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.083223:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pointermove", "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.107251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.108585:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.132850:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.142425:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195403.142649:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 10000
[1:1:0711/195403.143045:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 508
[1:1:0711/195403.143284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 508 0x7f1dd5535070 0x31d759f53160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 
[1:1:0711/195403.145119:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195403.145336:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0711/195403.145683:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 509
[1:1:0711/195403.145901:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 509 0x7f1dd5535070 0x31d75ccac0e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 
[1:1:0711/195403.153400:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195403.154648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0711/195403.155010:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 510
[1:1:0711/195403.155249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 510 0x7f1dd5535070 0x31d75ccb7060 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 
[1:1:0711/195403.156502:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195403.156692:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195403.157041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 511
[1:1:0711/195403.157272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7f1dd5535070 0x31d75ccf0160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 
[1:1:0711/195403.289543:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 495, 7f1dd7e7a881
[1:1:0711/195403.315007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"435 0x7f1dd5535070 0x31d759f4ec60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195403.315416:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"435 0x7f1dd5535070 0x31d759f4ec60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195403.315855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.316525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195403.316751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195403.317376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195403.317476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195403.317652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 539
[1:1:0711/195403.317758:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 539 0x7f1dd5535070 0x31d75ccf0de0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 495 0x7f1dd5535070 0x31d75a16a4e0 
[1:1:0711/195403.877497:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 370, 7f1dd7e7a8db
[1:1:0711/195403.901581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"355 0x7f1dd5535070 0x31d75a4da7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195403.901982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"355 0x7f1dd5535070 0x31d75a4da7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195403.902546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 551
[1:1:0711/195403.902791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 551 0x7f1dd5535070 0x31d75a0f8c60 , 5:3_https://kdp.amazon.com/, 0, , 370 0x7f1dd5535070 0x31d75a179960 
[1:1:0711/195403.903108:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.903789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){c.ue&&a.pec<a.ec&&c.uex("at");a.pec=a.ec}
[1:1:0711/195403.904034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195403.934990:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 511, 7f1dd7e7a881
[1:1:0711/195403.962680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195403.963003:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195403.963409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195403.963910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195403.964083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.055532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 510, 7f1dd7e7a881
[1:1:0711/195404.065605:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.065871:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.066151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.066583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195404.066739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.323970:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 539, 7f1dd7e7a881
[1:1:0711/195404.348616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"495 0x7f1dd5535070 0x31d75a16a4e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.348922:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"495 0x7f1dd5535070 0x31d75a16a4e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.349299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.349851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195404.350026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.350687:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195404.350847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195404.351182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 561
[1:1:0711/195404.351377:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f1dd5535070 0x31d75cca7560 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 539 0x7f1dd5535070 0x31d75ccf0de0 
[1:1:0711/195404.505833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 501, 7f1dd7e7a881
[1:1:0711/195404.516080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"434 0x7f1dd5535070 0x31d75a52e560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.516267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"434 0x7f1dd5535070 0x31d75a52e560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.516461:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.516777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0711/195404.516885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.523372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195404.523496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195404.523692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 565
[1:1:0711/195404.523801:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f1dd5535070 0x31d75cf21be0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 501 0x7f1dd5535070 0x31d75cdcc260 
[1:1:0711/195404.637784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 509, 7f1dd7e7a881
[1:1:0711/195404.666184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.666524:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"490 0x7f1de4846960 0x31d759f07ce0 0x31d759f07cf0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.666924:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.667424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195404.667630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.716180:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.716877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){clearTimeout(ea);Q=4;D()}
[1:1:0711/195404.717059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.728189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.732818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 100
[1:1:0711/195404.733028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 571
[1:1:0711/195404.733131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7f1dd5535070 0x31d75cf0e7e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 
[1:1:0711/195404.733694:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 200
[1:1:0711/195404.733853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 572
[1:1:0711/195404.733954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 572 0x7f1dd5535070 0x31d75cdc1060 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 
[1:1:0711/195404.734185:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.734637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2fd24d7c29c8, 0x31d7598039f0
[1:1:0711/195404.734732:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 100
[1:1:0711/195404.734872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 573
[1:1:0711/195404.734969:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f1dd5535070 0x31d75cf21860 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 
[1:1:0711/195404.737414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195404.737514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195404.737689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 574
[1:1:0711/195404.737791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f1dd5535070 0x31d75cf0a2e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 
[1:1:0711/195404.738480:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195404.738576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0711/195404.738736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 575
[1:1:0711/195404.738833:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f1dd5535070 0x31d759d4ce60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 
[1:1:0711/195404.764583:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 407, 7f1dd7e7a881
[1:1:0711/195404.773775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.774137:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"393 0x7f1dd745d2e0 0x31d75a4dcee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.774605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.775459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , k, (){for(var a=0;a<B.length;a++)B[a]();q.length&&d(n(q.splice(0,q.length)),N,K,H);A=L=0}
[1:1:0711/195404.775764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.968024:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 561, 7f1dd7e7a881
[1:1:0711/195404.975803:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"539 0x7f1dd5535070 0x31d75ccf0de0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.976168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"539 0x7f1dd5535070 0x31d75ccf0de0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195404.976620:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195404.977311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195404.977542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195404.978323:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195404.978495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195404.978899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 591
[1:1:0711/195404.979095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7f1dd5535070 0x31d75d1fbb60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 561 0x7f1dd5535070 0x31d75cca7560 
[1:1:0711/195405.122989:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195405.123300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 10000
[1:1:0711/195405.123690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 595
[1:1:0711/195405.124024:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 595 0x7f1dd5535070 0x31d75cf0efe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 561 0x7f1dd5535070 0x31d75cca7560 
[1:1:0711/195405.139082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x2fd24d7c29c8, 0x31d759803ab0
[1:1:0711/195405.139357:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0711/195405.139788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 596
[1:1:0711/195405.140040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7f1dd5535070 0x31d75ccf05e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 561 0x7f1dd5535070 0x31d75cca7560 
[1:1:0711/195405.168129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 574, 7f1dd7e7a881
[1:1:0711/195405.192070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.192428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.192842:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.193378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195405.193585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.426730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 571, 7f1dd7e7a8db
[1:1:0711/195405.452239:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.452592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.453029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 606
[1:1:0711/195405.453256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f1dd5535070 0x31d75ceefbe0 , 5:3_https://kdp.amazon.com/, 0, , 571 0x7f1dd5535070 0x31d75cf0e7e0 
[1:1:0711/195405.453543:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.454110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0711/195405.454329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.498384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 573, 7f1dd7e7a881
[1:1:0711/195405.522282:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.522629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.523038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.523592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195405.523851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.564342:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 572, 7f1dd7e7a8db
[1:1:0711/195405.579186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.579557:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.580034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 614
[1:1:0711/195405.580278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f1dd5535070 0x31d75d43fee0 , 5:3_https://kdp.amazon.com/, 0, , 572 0x7f1dd5535070 0x31d75cdc1060 
[1:1:0711/195405.580585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.581147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0711/195405.581365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.672184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){J.splice(0).forEach(function(a){q(a,{clog:1})})}
[1:1:0711/195405.672495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.703230:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 591, 7f1dd7e7a881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/195405.722914:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"561 0x7f1dd5535070 0x31d75cca7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.723308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"561 0x7f1dd5535070 0x31d75cca7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.723709:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.724343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195405.724562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.725254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195405.725470:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195405.725864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 624
[1:1:0711/195405.726113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 624 0x7f1dd5535070 0x31d75cf0a9e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 591 0x7f1dd5535070 0x31d75d1fbb60 
[1:1:0711/195405.796729:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 596, 7f1dd7e7a881
[1:1:0711/195405.822755:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"561 0x7f1dd5535070 0x31d75cca7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.823127:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"561 0x7f1dd5535070 0x31d75cca7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.823503:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.824060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195405.824263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.880025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 575, 7f1dd7e7a881
[1:1:0711/195405.896599:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.896932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"546 0x7f1de4846960 0x31d75d1a2c40 0x31d75d1a2c50 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.897321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.897884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195405.898135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.907558:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 565, 7f1dd7e7a881
[1:1:0711/195405.932178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"501 0x7f1dd5535070 0x31d75cdcc260 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.932566:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"501 0x7f1dd5535070 0x31d75cdcc260 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195405.933024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195405.933596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0711/195405.933806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195405.950321:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195405.950596:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0711/195405.951017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 633
[1:1:0711/195405.951259:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f1dd5535070 0x31d759d87fe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 565 0x7f1dd5535070 0x31d75cf21be0 
[1:1:0711/195405.990247:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 606, 7f1dd7e7a8db
[1:1:0711/195406.018967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"571 0x7f1dd5535070 0x31d75cf0e7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.019345:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"571 0x7f1dd5535070 0x31d75cf0e7e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.019780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 634
[1:1:0711/195406.020067:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7f1dd5535070 0x31d75a3bd560 , 5:3_https://kdp.amazon.com/, 0, , 606 0x7f1dd5535070 0x31d75ceefbe0 
[1:1:0711/195406.020394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.020997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0711/195406.021247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.197514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 624, 7f1dd7e7a881
[1:1:0711/195406.221316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"591 0x7f1dd5535070 0x31d75d1fbb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.221670:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"591 0x7f1dd5535070 0x31d75d1fbb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.222085:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.222635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195406.222846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.223548:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195406.223742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.224181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 638
[1:1:0711/195406.224413:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 638 0x7f1dd5535070 0x31d75cff98e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 624 0x7f1dd5535070 0x31d75cf0a9e0 
[1:1:0711/195406.229429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195406.229658:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.230013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 639
[1:1:0711/195406.230273:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7f1dd5535070 0x31d75d4f1ae0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 624 0x7f1dd5535070 0x31d75cf0a9e0 
[1:1:0711/195406.248350:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0711/195406.248817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 640
[1:1:0711/195406.249083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7f1dd5535070 0x31d75d4e71e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 624 0x7f1dd5535070 0x31d75cf0a9e0 
[1:1:0711/195406.278708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 614, 7f1dd7e7a8db
[1:1:0711/195406.307813:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"572 0x7f1dd5535070 0x31d75cdc1060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.308166:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"572 0x7f1dd5535070 0x31d75cdc1060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.308595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 644
[1:1:0711/195406.308836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7f1dd5535070 0x31d75b969ee0 , 5:3_https://kdp.amazon.com/, 0, , 614 0x7f1dd5535070 0x31d75d43fee0 
[1:1:0711/195406.309161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.309707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0711/195406.309926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.369719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){K=null;m("dwe",p);d()}
[1:1:0711/195406.370015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.372897:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195406.373129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0711/195406.373553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 649
[1:1:0711/195406.373783:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f1dd5535070 0x31d759b3f5e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 629 0x7f1de4846960 0x31d75d4766a0 0x31d75d4766b0 
[1:1:0711/195406.374846:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195406.375142:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.375535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 650
[1:1:0711/195406.375756:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7f1dd5535070 0x31d75d43d160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 629 0x7f1de4846960 0x31d75d4766a0 0x31d75d4766b0 
[1:1:0711/195406.376839:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2fd24d7c29c8, 0x31d759803968
[1:1:0711/195406.377029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0711/195406.377395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 651
[1:1:0711/195406.377620:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 651 0x7f1dd5535070 0x31d75cbfc360 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 629 0x7f1de4846960 0x31d75d4766a0 0x31d75d4766b0 
[1:1:0711/195406.474394:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 634, 7f1dd7e7a8db
[1:1:0711/195406.503328:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"606 0x7f1dd5535070 0x31d75ceefbe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.503681:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"606 0x7f1dd5535070 0x31d75ceefbe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.504151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 655
[1:1:0711/195406.504384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7f1dd5535070 0x31d75d4357e0 , 5:3_https://kdp.amazon.com/, 0, , 634 0x7f1dd5535070 0x31d75a3bd560 
[1:1:0711/195406.504721:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.505299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0711/195406.505512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.539927:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 638, 7f1dd7e7a881
[1:1:0711/195406.567866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"624 0x7f1dd5535070 0x31d75cf0a9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.568292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"624 0x7f1dd5535070 0x31d75cf0a9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.568683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.569259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195406.569479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.570210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195406.570407:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.570782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 657
[1:1:0711/195406.571004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 657 0x7f1dd5535070 0x31d75cff4260 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 638 0x7f1dd5535070 0x31d75cff98e0 
[1:1:0711/195406.627397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 640, 7f1dd7e7a8db
[1:1:0711/195406.653920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"624 0x7f1dd5535070 0x31d75cf0a9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.654303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"624 0x7f1dd5535070 0x31d75cf0a9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.654736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 660
[1:1:0711/195406.654958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 660 0x7f1dd5535070 0x31d7597f83e0 , 5:3_https://kdp.amazon.com/, 0, , 640 0x7f1dd5535070 0x31d75d4e71e0 
[1:1:0711/195406.655299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.655835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){k.reduce(g,function(a,b){return a&&"loaded"===b.status},!0)&&(a(),clearInterval(c))}
[1:1:0711/195406.656071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.659117:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 644, 7f1dd7e7a8db
[1:1:0711/195406.669388:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"614 0x7f1dd5535070 0x31d75d43fee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.669696:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"614 0x7f1dd5535070 0x31d75d43fee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.670116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 661
[1:1:0711/195406.670376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7f1dd5535070 0x31d75ceefbe0 , 5:3_https://kdp.amazon.com/, 0, , 644 0x7f1dd5535070 0x31d75b969ee0 
[1:1:0711/195406.670663:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.671229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0711/195406.671451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.677040:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 650, 7f1dd7e7a881
[1:1:0711/195406.701465:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"629 0x7f1de4846960 0x31d75d4766a0 0x31d75d4766b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.701813:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"629 0x7f1de4846960 0x31d75d4766a0 0x31d75d4766b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.702207:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.702728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195406.702935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.756233:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 649, 7f1dd7e7a881
[1:1:0711/195406.780716:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"629 0x7f1de4846960 0x31d75d4766a0 0x31d75d4766b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.781070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"629 0x7f1de4846960 0x31d75d4766a0 0x31d75d4766b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.781458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.781972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , , (){z(b)}
[1:1:0711/195406.782186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.811740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 655, 7f1dd7e7a8db
[1:1:0711/195406.838069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"634 0x7f1dd5535070 0x31d75a3bd560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.838419:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"634 0x7f1dd5535070 0x31d75a3bd560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.838839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 664
[1:1:0711/195406.839063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f1dd5535070 0x31d75cf0aae0 , 5:3_https://kdp.amazon.com/, 0, , 655 0x7f1dd5535070 0x31d75d4357e0 
[1:1:0711/195406.839387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.839940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0711/195406.840187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.872120:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 657, 7f1dd7e7a881
[1:1:0711/195406.899892:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d982cf02860","ptid":"638 0x7f1dd5535070 0x31d75cff98e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.900296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"638 0x7f1dd5535070 0x31d75cff98e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0711/195406.900678:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0711/195406.901208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0711/195406.901427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0711/195406.902071:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195406.902288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.902876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 665
[1:1:0711/195406.903076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7f1dd5535070 0x31d75d432a60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 657 0x7f1dd5535070 0x31d75cff4260 
[1:1:0711/195406.918429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195406.918713:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.919105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 666
[1:1:0711/195406.919350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7f1dd5535070 0x31d75d4350e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 657 0x7f1dd5535070 0x31d75cff4260 
[1:1:0711/195406.930269:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195406.930552:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.930961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 667
[1:1:0711/195406.931201:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f1dd5535070 0x31d75ccb7de0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 657 0x7f1dd5535070 0x31d75cff4260 
[1:1:0711/195406.941680:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2fd24d7c29c8, 0x31d759803950
[1:1:0711/195406.941967:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0711/195406.942414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 668
[1:1:0711/195406.942686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f1dd5535070 0x31d75cf21160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 657 0x7f1dd5535070 0x31d75cff4260 
[1:1:0711/195406.989046:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 661, 7f1dd7e7a8db
[1:1:0100/000000.017098:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"644 0x7f1dd5535070 0x31d75b969ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0100/000000.043533:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"644 0x7f1dd5535070 0x31d75b969ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0100/000000.043918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 686
[1:1:0100/000000.044063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f1dd5535070 0x31d75cf2ade0 , 5:3_https://kdp.amazon.com/, 0, , 661 0x7f1dd5535070 0x31d75ceefbe0 
[1:1:0100/000000.044318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0100/000000.044888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 0d982cf02860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0100/000000.045067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
