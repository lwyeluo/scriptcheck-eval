[0712/073325.792551:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/073325.792957:INFO:switcher_clone.cc(787)] backtrace rip is 7f0c55c9b891
[0712/073326.676199:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/073326.676640:INFO:switcher_clone.cc(787)] backtrace rip is 7f767431d891
[1:1:0712/073326.688503:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/073326.688772:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/073326.695193:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[101085:101085:0712/073327.810984:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1bd5d290-dc98-45b1-909b-f67f2ee6bb97
[0712/073328.071755:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/073328.072054:INFO:switcher_clone.cc(787)] backtrace rip is 7ffbbbdcc891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[101085:101085:0712/073328.294848:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[101085:101115:0712/073328.295536:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/073328.295813:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/073328.296013:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[3:3:0712/073328.296383:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/073328.296482:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/073328.298945:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x11f6ebeb, 1
[1:1:0712/073328.299320:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x46c06e4, 0
[1:1:0712/073328.299522:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d0b1e9f, 3
[1:1:0712/073328.299833:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e01d04e, 2
[1:1:0712/073328.300089:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe4066c04 ffffffebffffffebfffffff611 4effffffd0012e ffffff9f1e0b2d , 10104, 4
[1:1:0712/073328.301247:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[101085:101115:0712/073328.301385:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�l���N�.�-��� 
[101085:101115:0712/073328.301428:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �l���N�.�-���� 
[101085:101115:0712/073328.301580:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[101085:101115:0712/073328.301616:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 101130, 4, e4066c04 ebebf611 4ed0012e 9f1e0b2d 
[1:1:0712/073328.301905:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f76725580a0, 3
[1:1:0712/073328.302023:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f76726e3080, 2
[1:1:0712/073328.302111:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f765c3a6d20, -2
[101117:101117:0712/073328.305930:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=101117
[101131:101131:0712/073328.306241:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=101131
[1:1:0712/073328.314870:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/073328.315451:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e01d04e
[1:1:0712/073328.316171:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e01d04e
[1:1:0712/073328.317256:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e01d04e
[1:1:0712/073328.317951:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.318057:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.318155:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.318252:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.318462:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e01d04e
[1:1:0712/073328.318609:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f767431d7ba
[1:1:0712/073328.318700:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7674314def, 7f767431d77a, 7f767431f0cf
[1:1:0712/073328.322356:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e01d04e
[1:1:0712/073328.322740:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e01d04e
[1:1:0712/073328.323484:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e01d04e
[1:1:0712/073328.325560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.325780:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.325974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.326156:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e01d04e
[1:1:0712/073328.327396:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e01d04e
[1:1:0712/073328.327834:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f767431d7ba
[1:1:0712/073328.327975:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7674314def, 7f767431d77a, 7f767431f0cf
[1:1:0712/073328.336137:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/073328.336616:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/073328.336787:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcb1395898, 0x7ffcb1395818)
[1:1:0712/073328.353744:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/073328.358704:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[101085:101085:0712/073328.893669:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[101085:101085:0712/073328.895122:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[101085:101108:0712/073328.902382:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/073328.911384:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2cc3438dd220
[1:1:0712/073328.911786:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[101085:101096:0712/073328.916972:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[101085:101096:0712/073328.917079:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[101085:101085:0712/073328.917095:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[101085:101085:0712/073328.917187:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[101085:101085:0712/073328.917372:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,101130, 4
[1:7:0712/073328.920041:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/073329.611716:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[101085:101085:0712/073331.210591:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[101085:101085:0712/073331.210737:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/073331.256688:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073331.260251:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073332.127777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c464fa81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/073332.128108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073332.144745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c464fa81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/073332.145064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073332.226777:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073332.466804:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073332.467114:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073332.663798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073332.671984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c464fa81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/073332.672284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073332.725055:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073332.735840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c464fa81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/073332.736175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073332.741170:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[101085:101085:0712/073332.744936:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/073332.745845:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2cc3438dbe20
[1:1:0712/073332.746104:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[101085:101085:0712/073332.759105:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[101085:101085:0712/073332.779910:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[101085:101085:0712/073332.780061:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[101085:101085:0712/073332.786323:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/073332.828493:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073333.743552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f765df812e0 0x2cc343b7c560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073333.744976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c464fa81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/073333.745192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073333.746681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073333.826208:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2cc3438dc820
[1:1:0712/073333.826420:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/073333.845834:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/073333.846059:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[101085:101085:0712/073333.855201:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[101085:101085:0712/073333.864753:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[101085:101085:0712/073333.882000:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[101085:101085:0712/073333.892285:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[101085:101085:0712/073333.892771:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[101085:101096:0712/073333.894325:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[101085:101096:0712/073333.894369:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[101085:101085:0712/073333.895897:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[101085:101085:0712/073333.895935:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[101085:101085:0712/073333.895994:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,101130, 4
[1:7:0712/073333.906961:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/073334.425426:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/073334.809689:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7f765df812e0 0x2cc343a1fa60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073334.811038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c464fa81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/073334.811295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073334.812262:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[101085:101085:0712/073334.877157:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[101085:101085:0712/073334.877298:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/073334.883005:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073335.271941:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073335.974368:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073335.974605:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[101085:101085:0712/073336.049263:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[101085:101115:0712/073336.049514:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/073336.049645:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/073336.049831:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/073336.050106:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/073336.050220:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/073336.052865:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe21cddf, 1
[1:1:0712/073336.053223:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x17c05526, 0
[1:1:0712/073336.053383:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1f089a49, 3
[1:1:0712/073336.053546:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x230dfb05, 2
[1:1:0712/073336.053695:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2655ffffffc017 ffffffdfffffffcd210e 05fffffffb0d23 49ffffff9a081f , 10104, 5
[1:1:0712/073336.054708:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[101085:101115:0712/073336.054953:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING&U���!�#I�
�� 
[101085:101115:0712/073336.055031:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is &U���!�#I�|
�� 
[101085:101115:0712/073336.055296:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 101185, 5, 2655c017 dfcd210e 05fb0d23 499a081f 
[1:1:0712/073336.055165:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f76725580a0, 3
[1:1:0712/073336.055741:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f76726e3080, 2
[1:1:0712/073336.056026:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f765c3a6d20, -2
[1:1:0712/073336.077632:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/073336.078038:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 230dfb05
[1:1:0712/073336.078359:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 230dfb05
[1:1:0712/073336.079020:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 230dfb05
[1:1:0712/073336.080936:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.081192:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.081395:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.081592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.082291:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 230dfb05
[1:1:0712/073336.082642:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f767431d7ba
[1:1:0712/073336.082838:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7674314def, 7f767431d77a, 7f767431f0cf
[1:1:0712/073336.086814:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 230dfb05
[1:1:0712/073336.087220:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 230dfb05
[1:1:0712/073336.088009:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 230dfb05
[1:1:0712/073336.090058:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.090295:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.090501:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.090710:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230dfb05
[1:1:0712/073336.092009:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 230dfb05
[1:1:0712/073336.092389:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f767431d7ba
[1:1:0712/073336.092540:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7674314def, 7f767431d77a, 7f767431f0cf
[1:1:0712/073336.100423:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/073336.101049:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/073336.101259:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcb1395898, 0x7ffcb1395818)
[1:1:0712/073336.113046:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/073336.119704:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/073336.238924:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073336.240658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c464fbb0640, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/073336.240812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/073336.243063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073336.344048:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2cc3438aa220
[1:1:0712/073336.344359:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[101085:101085:0712/073337.206993:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[101085:101085:0712/073337.216288:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[101085:101096:0712/073337.245404:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[101085:101096:0712/073337.245522:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[101085:101085:0712/073337.246042:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.fandom.com/
[101085:101085:0712/073337.246165:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.fandom.com/, https://www.fandom.com/explore, 1
[101085:101085:0712/073337.246337:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.fandom.com/, HTTP/1.1 200 status:200 cache-control:max-age=60, stale-while-revalidate=86400, stale-if-error=86400 content-encoding:gzip content-security-policy:upgrade-insecure-requests content-security-policy-report-only:default-src https: 'self' data: blob:; script-src https: 'self' data: 'unsafe-inline' 'unsafe-eval' blob:; style-src https: 'self' 'unsafe-inline' blob:; report-uri https://services.fandom.com/csp-logger/csp/upstream content-type:text/html; charset=UTF-8 link:<https://www.fandom.com/wp-json/>; rel="https://api.w.org/" link:<https://www.fandom.com/?p=3211>; rel=shortlink server:Apache x-datacenter:SJC via:1.1 varnish via:1.1 varnish accept-ranges:bytes date:Fri, 12 Jul 2019 14:33:37 GMT age:156 x-served-by:cache-wk-sjc3162-WIKIA, cache-tyo19938-TYO x-cache:HIT, HIT x-cache-hits:8, 1 x-timer:S1562942017.331390,VS0,VE1 vary:Fastly-SSL, Fastly-SSL, Accept-Language,Geo-Region,Accept-Encoding content-length:87838  ,101185, 5
[1:7:0712/073337.250956:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/073337.285889:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.fandom.com/
[101085:101085:0712/073337.483509:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.fandom.com/, https://www.fandom.com/, 1
[101085:101085:0712/073337.483612:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.fandom.com/, https://www.fandom.com
[1:1:0712/073337.501156:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073337.501967:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073337.640305:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073337.675119:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073337.675405:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073337.688237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 133 0x7f765c059070 0x2cc3439c9460 , "https://www.fandom.com/explore"
[1:1:0712/073337.689900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , 
(function () {
	'use strict';

	function getWindowWidth() {
		return window.innerWidth
			|| docume
[1:1:0712/073337.690132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073337.691993:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073337.703859:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 133 0x7f765c059070 0x2cc3439c9460 , "https://www.fandom.com/explore"
[1:1:0712/073337.710817:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 133 0x7f765c059070 0x2cc3439c9460 , "https://www.fandom.com/explore"
[1:1:0712/073337.729396:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 133 0x7f765c059070 0x2cc3439c9460 , "https://www.fandom.com/explore"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/073338.179080:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073338.386240:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073338.467838:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073338.478110:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073338.510527:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179 0x7f765df812e0 0x2cc3439d29e0 , "https://www.fandom.com/explore"
[1:1:0712/073338.517987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0712/073338.518258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073338.636631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f765df812e0 0x2cc3439d86e0 , "https://www.fandom.com/explore"
[1:1:0712/073338.642693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (function(E){var window=this;var aa=function(a){var b=0;return function(){return b<a.length?{done:!1
[1:1:0712/073338.642970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073338.828602:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x3f54ab2e29c8, 0x2cc343489990
[1:1:0712/073338.828879:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fandom.com/explore", 1000
[1:1:0712/073338.829259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 191
[1:1:0712/073338.829507:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 191 0x7f765c059070 0x2cc3439c9ae0 , 5:3_https://www.fandom.com/, 1, -5:3_https://www.fandom.com/, 180 0x7f765df812e0 0x2cc3439d86e0 
[1:1:0712/073338.902556:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073338.902830:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073338.945161:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073338.964856:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073338.983763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (c){var d=a.google_lt_queue=a.google_lt_queue||[];q(c.getEntries(),function(e){return d.push(e)})}
[1:1:0712/073338.984092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073339.070497:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073339.070723:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073339.075402:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073339.096098:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073339.105238:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073339.105382:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073339.393311:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073339.397130:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073339.510065:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073339.510292:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073339.586148:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073339.635946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 225 0x7f765df812e0 0x2cc343ecbd60 , "https://www.fandom.com/explore"
[1:1:0712/073339.653493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (function(_){var window=this,document=this.document;var ea,ia,ja,na,oa,pa,sa,ta,xa,Ba,Aa,za,Da,Ja,Ha
[1:1:0712/073339.653833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073340.289804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 226 0x7f765df812e0 0x2cc343eff260 , "https://www.fandom.com/explore"
[1:1:0712/073340.290740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , processGoogleToken({"newToken":"NT","validLifetimeSecs":300,"freshLifetimeSecs":300,"1p_jar":"","puc
[1:1:0712/073340.290926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073340.397943:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073340.398183:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073340.510447:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 191, 7f765e99e881
[1:1:0712/073340.523284:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05cafd822860","ptid":"180 0x7f765df812e0 0x2cc3439d86e0 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073340.523604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fandom.com/","ptid":"180 0x7f765df812e0 0x2cc3439d86e0 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073340.523898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fandom.com/explore"
[1:1:0712/073340.524430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (){return g.processGoogleToken(d,1)}
[1:1:0712/073340.524603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073341.643898:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073341.698342:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073341.892187:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073341.892424:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073342.043479:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.150982, 933, 1
[1:1:0712/073342.043729:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073342.400717:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073342.400879:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073345.363482:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073345.364061:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073345.364464:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073345.366365:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073345.366780:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073357.525071:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 463 0x7f765c3c1bd0 0x2cc343ec83d8 , "https://www.fandom.com/explore"
[1:1:0712/073357.531896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , !function(e){function r(e,r,o){return 4===arguments.length?t.apply(this,arguments):void n(e,{declara
[1:1:0712/073357.532120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073358.939546:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 463 0x7f765c3c1bd0 0x2cc343ec83d8 , "https://www.fandom.com/explore"
[1:1:0712/073359.001050:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.065284, 212, 1
[1:1:0712/073359.001370:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[101085:101085:0712/073359.060234:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/073359.095145:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/073359.319268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/073359.323528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073359.900438:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073359.901733:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073359.902966:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[1:1:0712/073359.904399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , window.twttr = (function(d, s, id) {
	var js, fjs = d.getElementsByTagName(s)[0],
		t = window.twttr
[1:1:0712/073359.904629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073359.914588:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[1:1:0712/073359.926194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[101085:101085:0712/073359.950268:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.fandom.com/, https://www.fandom.com/, 1
[101085:101085:0712/073359.950419:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.fandom.com/, https://www.fandom.com
[101085:101085:0712/073359.974680:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.fandom.com/, https://www.fandom.com/, 1
[101085:101085:0712/073359.974762:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.fandom.com/, https://www.fandom.com
[1:1:0712/073402.057655:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3f54ab2e29c8, 0x2cc343489998
[1:1:0712/073402.057909:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fandom.com/explore", 100
[1:1:0712/073402.058362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 561
[1:1:0712/073402.058613:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f765c059070 0x2cc344cf0860 , 5:3_https://www.fandom.com/, 1, -5:3_https://www.fandom.com/, 502 0x7f765c059070 0x2cc34480dde0 
[1:1:0712/073403.807663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[1:1:0712/073403.819788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[1:1:0712/073403.896433:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[1:1:0712/073403.901016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[1:1:0712/073403.905046:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f765c059070 0x2cc34480dde0 , "https://www.fandom.com/explore"
[1:1:0712/073403.926694:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 4.02457, 2, 0
[1:1:0712/073403.926854:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073404.272546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (a){Z(243,a.level);Z(244,a.charging);Z(242,!0)}
[1:1:0712/073404.272818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073404.349550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073404.349804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073404.381329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , () {
          self.trigger('updated');
        }
[1:1:0712/073404.381544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073405.818717:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_INVALID_ARGUMENT","https://connect.facebook.net/en_US/sdk.js"
[1:1:0712/073406.850158:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073406.850436:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.fandom.com/explore"
[1:1:0712/073406.852967:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f765c059070 0x2cc3453dbc60 , "https://www.fandom.com/explore"
[1:1:0712/073406.855215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , /**
 * Fastly Insights.js
 * Build generated: 2019-06-21
 * https://github.com/fastly/insights.js
 *
[1:1:0712/073406.855452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073406.863150:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.fandom.com/explore"
[1:1:0712/073406.870323:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.fandom.com/explore"
[101085:101085:0712/073406.873997:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/073406.876498:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2cc3438a9820
[1:1:0712/073406.876757:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[101085:101085:0712/073406.882173:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: __cmpLocator, 4, 4, 
[101085:101085:0712/073406.916592:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.fandom.com/, https://www.fandom.com/, 4
[101085:101085:0712/073406.916770:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.fandom.com/, https://www.fandom.com
[1:1:0712/073407.992928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 561, 7f765e99e881
[1:1:0712/073408.029720:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05cafd822860","ptid":"502 0x7f765c059070 0x2cc34480dde0 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073408.030133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fandom.com/","ptid":"502 0x7f765c059070 0x2cc34480dde0 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073408.030513:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fandom.com/explore"
[1:1:0712/073408.031279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , attachEvent, () {
      this.initialised || (this.lastKnownScrollY = this.getScrollY(), this.initialised = !0, th
[1:1:0712/073408.031505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073408.216133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073408.216452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073409.216740:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.fandom.com/explore"
[1:1:0712/073409.217660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , throttled, () {
			var now = Date.now();
			var remaining = wait - (now - previous);
			context = this;
			args
[1:1:0712/073409.217895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073409.980844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7f765df812e0 0x2cc345541ae0 , "https://www.fandom.com/explore"
[1:1:0712/073409.982170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , function udm_(e,t){var n="comScore=",r=document,i=r.cookie,s="",o="indexOf",u="substring",a="length"
[1:1:0712/073409.982483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073410.574338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 684 0x7f765df812e0 0x2cc34566c160 , "https://www.fandom.com/explore"
[1:1:0712/073410.576268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , /* Copyright (c) 2008-2018, Quantcast Corp. */
/* Version: 4c19192-20180628134937 */
window.__qc=fun
[1:1:0712/073410.576589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073410.642748:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 685 0x7f765df812e0 0x2cc343ec2560 , "https://www.fandom.com/explore"
[1:1:0712/073410.652014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , 



/* ControlTag Loader for Wikia 44c1a380-770f-11df-93f2-0800200c9a66 */
(function(w, cs) {
  
  i
[1:1:0712/073410.652303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073411.120800:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 (Forbidden)","https://cdn.petametrics.com/l9ehhrb6mtv75bp2.js?ts=434150"
[1:1:0712/073411.784406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073411.784746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073413.449648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 797 0x7f765df812e0 0x2cc345672ae0 , "https://www.fandom.com/explore"
[1:1:0712/073413.450921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , var beacon_id = "WVP1Fba9iV"; var session_id = "4XcO8ZvXcF"; var varnishTime = "Fri, 12 Jul 2019 14:
[1:1:0712/073413.451186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073413.452063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fandom.com/explore"
[1:1:0712/073413.618559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073413.618803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073415.066782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073415.067113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073415.559792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073415.559993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073415.780806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073415.781124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073415.958773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073415.959032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.018022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.018297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.152072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.152279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.362131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.362424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.423895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.424101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.519021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.519223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.588725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.589000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.650171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.650495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.820038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.820352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073416.909592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073416.909896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.158416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.158743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.332074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.332286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.504419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.504714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.611369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.611629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.681008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.681288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.750811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.751110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.823097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.823296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.864557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.864780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073417.962946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073417.963220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073418.133350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073418.133683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/073418.279390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073418.279677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073418.445172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073418.445463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073418.681526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073418.681884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073418.758264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073418.758439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073418.840329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073418.840514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073418.953299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073418.953639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.007528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.007707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.100856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.101201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.194181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.194431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.278928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.279269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.358408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.358730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.441859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.442041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.525984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.526309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073419.850167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073419.850507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073420.124023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073420.124202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073420.299067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073420.299269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073420.524550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073420.525073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073420.836869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073420.837198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[101085:101085:0712/073420.975319:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/073421.066259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.066585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073421.126304:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","https://platform.twitter.com/widgets.js"
[1:1:0712/073421.183207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.183522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073421.540020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.540359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073421.652655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.652909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073421.749876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.750084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073421.822764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.823022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073421.876688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.877000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073421.984062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073421.984342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.059419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.059658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.191507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.191776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.298791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.299104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.362938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.363128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.444674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.444927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.496013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.496225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.559586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.559834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.654492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.654740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.718932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.719285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.770435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.770618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.838690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.838945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.948970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.949230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073422.994174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073422.994461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.060358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.060626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.105866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.106057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.170724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.170911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.243616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.243807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.350698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.351035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.405981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.406165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.523415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.523706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.636943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.637191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.746699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.747003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.846432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.846635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073423.955779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073423.956031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.045377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.045759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.133743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.133992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.211514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.211802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.263924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.264132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.338938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.339118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.446647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.446919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.567943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.568199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.675246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.675498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.758203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.758481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.864316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.864623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073424.949958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073424.950265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.033922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.034230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.157597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.157927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.210584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.210788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.278021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.278295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.413023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.413355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.483420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.483603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.610148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.610397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.713961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.714296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.810496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.810762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.892287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.892579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073425.986633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073425.986811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.095297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.095544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.210780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.211108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.330769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.331151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.446066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.446357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.566995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.567237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.631145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.631383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.706308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.706486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.754439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.754615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.824818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.825144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073426.944030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073426.944276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073427.039344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073427.039653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073427.139703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073427.140005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073427.411484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073427.411798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073427.756467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073427.756710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073428.000194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073428.000459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073428.195127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073428.195401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073428.394979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073428.395217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073428.601437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073428.601643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073428.706105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073428.706329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073428.797553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073428.797736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073428.894144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073428.894427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073429.289003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073429.289309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073429.751511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073429.751716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073430.417809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073430.418055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073430.899910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073430.900101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073431.299482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073431.299731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073431.913747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073431.914122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073432.179966:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1254 0x7f765df812e0 0x2cc3448a10e0 , "https://www.fandom.com/explore"
[1:1:0712/073432.181135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , /*
 Quantcast measurement tag
 Copyright (c) 2008-2019, Quantcast Corp.
*/
(function(e,l,k){var m=fu
[1:1:0712/073432.181326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073432.214909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fandom.com/explore"
[1:1:0712/073432.757123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073432.757299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073433.358466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073433.358785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073433.779266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073433.779561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073434.020584:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1308 0x7f765df812e0 0x2cc343eb3360 , "https://www.fandom.com/explore"
[1:1:0712/073434.027871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , /**
 * @version v6.44.10
 * @copyright Copyright 2019 Krux Digital, Inc. All Rights Reserved.
 */
!f
[1:1:0712/073434.028087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073434.033983:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073434.059031:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fandom.com/explore"
[1:1:0712/073434.434403:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073434.435523:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073434.592234:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3f54ab2e29c8, 0x2cc343489a10
[1:1:0712/073434.592439:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fandom.com/explore", 100
[1:1:0712/073434.593466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 1321
[1:1:0712/073434.593598:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1321 0x7f765c059070 0x2cc3456cad60 , 5:3_https://www.fandom.com/, 1, -5:3_https://www.fandom.com/, 1308 0x7f765df812e0 0x2cc343eb3360 
[1:1:0712/073434.603007:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x3f54ab2e29c8, 0x2cc343489a10
[1:1:0712/073434.603258:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fandom.com/explore", 6000
[1:1:0712/073434.603614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 1323
[1:1:0712/073434.603809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1323 0x7f765c059070 0x2cc3448cb0e0 , 5:3_https://www.fandom.com/, 1, -5:3_https://www.fandom.com/, 1308 0x7f765df812e0 0x2cc343eb3360 
[1:1:0712/073434.834626:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3f54ab2e29c8, 0x2cc343489a10
[1:1:0712/073434.834794:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.fandom.com/explore", 1
[1:1:0712/073434.834978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 1327
[1:1:0712/073434.835087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7f765c059070 0x2cc34399f160 , 5:3_https://www.fandom.com/, 1, -5:3_https://www.fandom.com/, 1308 0x7f765df812e0 0x2cc343eb3360 
[1:1:0712/073434.889441:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[101085:101085:0712/073434.899246:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/073434.905478:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x2cc3438a7a20
[1:1:0712/073434.905939:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[101085:101085:0712/073434.907454:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/073434.942005:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/073434.942288:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.fandom.com
[101085:101085:0712/073434.944470:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.fandom.com/
[101085:101085:0712/073434.967925:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[101085:101085:0712/073434.969748:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[101085:101096:0712/073435.010615:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[101085:101096:0712/073435.010724:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[101085:101085:0712/073435.010954:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://cdn.krxd.net/
[101085:101085:0712/073435.011056:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://cdn.krxd.net/, https://cdn.krxd.net/partnerjs/xdi/proxy.3d2100fd7107262ecb55ce6847f01fa5.html#!kxcid=KPSUiAKl&kxt=https%3A%2F%2Fwww.fandom.com&kxcl=cdn&kxp=, 5
[101085:101085:0712/073435.011234:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://cdn.krxd.net/, HTTP/1.1 200 OK Last-Modified: Tue, 21 Feb 2017 17:50:54 GMT ETag: "3d2100fd7107262ecb55ce6847f01fa5" Cache-Control: public, max-age=315360000 Expires: Fri, 19 Feb 2027 17:50:50 GMT Content-Type: text/html X-CDN-Backend: 4FrRTvEr9h480D4BywjehZ--F_Partner_JS_S3 Content-Encoding: gzip Content-Length: 525 Accept-Ranges: bytes Date: Fri, 12 Jul 2019 08:57:08 GMT Via: 1.1 varnish Age: 26243474 X-Served-By: cache-tyo19944-TYO X-Cache: HIT X-Cache-Hits: 159943 X-Timer: S1562921829.699738,VS0,VE0 Vary: Accept-Encoding P3P: policyref="https://cdn.krxd.net/kruxcontent/p3p.xml", CP="NON DSP COR NID OUR DEL SAM OTR UNR COM NAV INT DEM CNT STA PRE LOC OTC"  ,101185, 5
[1:7:0712/073435.015144:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/073436.453809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , document.readyState
[1:1:0712/073436.454126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073437.906062:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://cdn.krxd.net/
[1:1:0712/073438.831322:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 1321, 7f765e99e881
[1:1:0712/073438.857119:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05cafd822860","ptid":"1308 0x7f765df812e0 0x2cc343eb3360 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073438.857319:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fandom.com/","ptid":"1308 0x7f765df812e0 0x2cc343eb3360 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073438.857581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fandom.com/explore"
[1:1:0712/073438.857883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (){return w()}
[1:1:0712/073438.858123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073438.887494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.fandom.com/, 1327, 7f765e99e881
[1:1:0712/073438.938507:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05cafd822860","ptid":"1308 0x7f765df812e0 0x2cc343eb3360 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073438.938711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.fandom.com/","ptid":"1308 0x7f765df812e0 0x2cc343eb3360 ","rf":"5:3_https://www.fandom.com/"}
[1:1:0712/073438.938973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.fandom.com/explore"
[1:1:0712/073438.939283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , , (){return t.apply(null,n)}
[1:1:0712/073438.939387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
[1:1:0712/073439.315226:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.fandom.com/explore"
[1:1:0712/073439.315935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.fandom.com/, 05cafd822860, , Ma.b.onload, (){b&&"number"==typeof b.width&&3===b.width?ga("__qca"):Aa()}
[1:1:0712/073439.316253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.fandom.com/explore", "www.fandom.com", 3, 1, , , 0
