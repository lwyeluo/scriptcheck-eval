[0712/072008.030246:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/072008.030589:INFO:switcher_clone.cc(787)] backtrace rip is 7f372d102891
[0712/072009.076115:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/072009.076655:INFO:switcher_clone.cc(787)] backtrace rip is 7f1112bba891
[1:1:0712/072009.091137:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/072009.091501:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/072009.097130:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[99370:99370:0712/072010.264783:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dc075200-3e81-4b7e-89a3-4fae2c3e5b40
[0712/072010.565979:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/072010.566495:INFO:switcher_clone.cc(787)] backtrace rip is 7fb7e7a32891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[99403:99403:0712/072010.799099:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=99403
[99415:99415:0712/072010.799498:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=99415
[99370:99370:0712/072010.892155:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[99370:99400:0712/072010.892975:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/072010.893179:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/072010.893398:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/072010.894047:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/072010.894250:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/072010.897413:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x365dbbdb, 1
[1:1:0712/072010.897796:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x8769c6f, 0
[1:1:0712/072010.898003:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3a371d12, 3
[1:1:0712/072010.898233:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb62e7c3, 2
[1:1:0712/072010.898451:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6fffffff9c7608 ffffffdbffffffbb5d36 ffffffc3ffffffe7620b 121d373a , 10104, 4
[1:1:0712/072010.899426:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99370:99400:0712/072010.899744:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGo�vۻ]6��b7:��r

[1:1:0712/072010.899714:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1110df50a0, 3
[99370:99400:0712/072010.899877:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is o�vۻ]6��b7:H��r

[1:1:0712/072010.899942:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1110f80080, 2
[99370:99400:0712/072010.900162:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/072010.900102:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10fac43d20, -2
[99370:99400:0712/072010.900232:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99423, 4, 6f9c7608 dbbb5d36 c3e7620b 121d373a 
[1:1:0712/072010.920326:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/072010.921221:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b62e7c3
[1:1:0712/072010.922190:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b62e7c3
[1:1:0712/072010.923833:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b62e7c3
[1:1:0712/072010.925334:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.925521:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.925726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.925942:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.926566:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b62e7c3
[1:1:0712/072010.926912:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1112bba7ba
[1:1:0712/072010.927051:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1112bb1def, 7f1112bba77a, 7f1112bbc0cf
[1:1:0712/072010.932735:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b62e7c3
[1:1:0712/072010.933130:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b62e7c3
[1:1:0712/072010.933861:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b62e7c3
[1:1:0712/072010.935912:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.936106:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.936293:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.936478:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b62e7c3
[1:1:0712/072010.937713:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b62e7c3
[1:1:0712/072010.938084:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1112bba7ba
[1:1:0712/072010.938220:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1112bb1def, 7f1112bba77a, 7f1112bbc0cf
[1:1:0712/072010.945901:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/072010.946362:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/072010.946508:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc7f7cf818, 0x7ffc7f7cf798)
[1:1:0712/072010.960852:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/072010.966636:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[99370:99370:0712/072011.444384:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99370:99370:0712/072011.445803:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99370:99382:0712/072011.467380:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[99370:99382:0712/072011.467508:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[99370:99370:0712/072011.467690:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[99370:99370:0712/072011.467793:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[99370:99370:0712/072011.468071:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,99423, 4
[1:7:0712/072011.476303:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[99370:99395:0712/072011.538410:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/072011.618768:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x69d7e856220
[1:1:0712/072011.619068:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/072012.026748:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[99370:99370:0712/072013.808222:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[99370:99370:0712/072013.808374:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/072013.860096:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072013.864432:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072015.054305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/072015.054631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072015.073430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/072015.073663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072015.116936:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072015.271204:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072015.271382:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072015.594264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072015.604485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/072015.604879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072015.643988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072015.651785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/072015.652029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072015.658121:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[99370:99370:0712/072015.661455:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/072015.661573:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x69d7e854e20
[1:1:0712/072015.661778:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[99370:99370:0712/072015.669276:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[99370:99370:0712/072015.702371:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[99370:99370:0712/072015.702528:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/072015.768090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072016.513540:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f10fc81e2e0 0x69d7e8f9160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072016.514864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/072016.515059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072016.516564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[99370:99370:0712/072016.585123:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/072016.587592:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x69d7e855820
[1:1:0712/072016.587813:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[99370:99370:0712/072016.592510:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/072016.608400:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/072016.608661:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[99370:99370:0712/072016.610874:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[99370:99370:0712/072016.622223:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99370:99370:0712/072016.623270:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99370:99382:0712/072016.629240:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[99370:99382:0712/072016.629331:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[99370:99370:0712/072016.629493:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[99370:99370:0712/072016.629570:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[99370:99370:0712/072016.629728:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,99423, 4
[1:7:0712/072016.636515:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/072017.389374:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/072017.971846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f10fc81e2e0 0x69d7eaca960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072017.972893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/072017.973136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072017.973912:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[99370:99370:0712/072018.197691:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[99370:99370:0712/072018.197864:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/072018.235555:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[99370:99370:0712/072018.638729:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[99370:99400:0712/072018.639170:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/072018.639358:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/072018.639618:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/072018.640061:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/072018.640236:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/072018.643692:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e7b95ee, 1
[1:1:0712/072018.644223:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x263a3c70, 0
[1:1:0712/072018.644437:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x32cd6acf, 3
[1:1:0712/072018.644625:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15628f59, 2
[1:1:0712/072018.644800:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 703c3a26 ffffffeeffffff957b2e 59ffffff8f6215 ffffffcf6affffffcd32 , 10104, 5
[1:1:0712/072018.645812:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99370:99400:0712/072018.646086:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGp<:&�{.Y�b�j�27�r

[99370:99400:0712/072018.646155:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is p<:&�{.Y�b�j�2��7�r

[99370:99400:0712/072018.646428:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99466, 5, 703c3a26 ee957b2e 598f6215 cf6acd32 
[1:1:0712/072018.646281:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1110df50a0, 3
[1:1:0712/072018.646838:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1110f80080, 2
[1:1:0712/072018.647111:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10fac43d20, -2
[1:1:0712/072018.669126:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/072018.669538:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15628f59
[1:1:0712/072018.669896:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15628f59
[1:1:0712/072018.670577:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15628f59
[1:1:0712/072018.672078:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.672304:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.672522:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.672739:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.673566:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15628f59
[1:1:0712/072018.673999:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1112bba7ba
[1:1:0712/072018.674196:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1112bb1def, 7f1112bba77a, 7f1112bbc0cf
[1:1:0712/072018.680064:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15628f59
[1:1:0712/072018.680522:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15628f59
[1:1:0712/072018.681321:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15628f59
[1:1:0712/072018.683386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.683664:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.683958:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.684212:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15628f59
[1:1:0712/072018.685492:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15628f59
[1:1:0712/072018.685898:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1112bba7ba
[1:1:0712/072018.686087:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1112bb1def, 7f1112bba77a, 7f1112bbc0cf
[1:1:0712/072018.693888:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/072018.694443:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/072018.694631:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc7f7cf818, 0x7ffc7f7cf798)
[1:1:0712/072018.708780:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/072018.713268:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/072018.759330:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072018.905943:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x69d7e7fb220
[1:1:0712/072018.906237:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/072019.304270:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072019.304571:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072019.710051:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072019.715284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/072019.715617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072019.723793:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072019.846720:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072019.847743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/072019.848098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072019.998480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072020.000368:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/072020.000625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/072020.000914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072020.083873:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072020.085210:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/072020.085522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/072020.085882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072020.851110:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/072020.934885:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/072021.007338:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/072021.117221:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0712/072021.164743:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0712/072021.244006:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0712/072021.285500:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0712/072021.377440:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0712/072021.471942:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072021.472893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072021.473167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072021.781649:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072021.782636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072021.782926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072021.846136:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072021.847098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072021.847427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072021.925273:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072021.926273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072021.926564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072021.971040:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072021.972025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072021.972367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.037737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.038694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072022.038968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.082807:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.083778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072022.084120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.215053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.216037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072022.216374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.246139:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.247073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072022.247366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.340392:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.341294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072022.341608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.404768:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.405830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072022.406106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.493573:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.494579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072022.494887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.601857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.602924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072022.603222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.666534:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.667561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072022.667883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.729842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.730807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072022.731095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072022.794821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072022.795781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072022.796105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[99370:99370:0712/072023.414711:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('http://arrow.wikia.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/072026.526665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b8e67961f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/072026.526979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072026.600669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.601585:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/072026.601799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/072026.602132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072026.682132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.684059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072026.684557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072026.715896:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.716806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072026.717127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072026.785692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.786596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072026.786954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072026.812702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.813664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072026.813964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072026.852504:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.853040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072026.853185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072026.871710:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.872194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072026.872334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072026.900250:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/072026.922969:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072026.923449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072026.923673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.063845:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.064357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/072027.064507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.123072:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/072027.146302:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/072027.173365:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0712/072027.210307:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0712/072027.251602:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0712/072027.319603:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0712/072027.333779:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0712/072027.445323:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.445800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.445940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.475455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.475921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.476103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.496561:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.497038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.497192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.566191:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.567091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.567325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.635181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.636080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.636316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.735132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.736132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.736374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.803703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.804608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.804842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072027.848081:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072027.848576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b8e67a8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/072027.848719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[99370:99370:0712/072028.130196:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('http://arrow.wikia.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
[99370:99370:0712/072028.254889:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99370:99370:0712/072028.295944:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[99370:99400:0712/072028.296475:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/072028.296772:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/072028.297000:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/072028.297494:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/072028.297679:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/072028.301135:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b3941c6, 1
[1:1:0712/072028.301539:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3f52fdba, 0
[1:1:0712/072028.301817:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x23d75181, 3
[1:1:0712/072028.302012:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x206944d8, 2
[1:1:0712/072028.302264:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbafffffffd523f ffffffc641393b ffffffd8446920 ffffff8151ffffffd723 , 10104, 6
[1:1:0712/072028.303384:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99370:99400:0712/072028.303770:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��R?�A9;�Di �Q�#��r

[99370:99400:0712/072028.303867:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��R?�A9;�Di �Q�#���r

[1:1:0712/072028.303764:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1110df50a0, 3
[99370:99400:0712/072028.304235:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99483, 6, bafd523f c641393b d8446920 8151d723 
[1:1:0712/072028.304189:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1110f80080, 2
[1:1:0712/072028.304688:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f10fac43d20, -2
[1:1:0712/072028.327534:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/072028.327950:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 206944d8
[1:1:0712/072028.328282:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 206944d8
[1:1:0712/072028.328905:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 206944d8
[1:1:0712/072028.330369:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.330600:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.330840:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.331056:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.331746:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 206944d8
[1:1:0712/072028.332114:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1112bba7ba
[1:1:0712/072028.332295:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1112bb1def, 7f1112bba77a, 7f1112bbc0cf
[99370:99370:0712/072028.336687:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/072028.337993:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 206944d8
[1:1:0712/072028.338462:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 206944d8
[1:1:0712/072028.339266:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 206944d8
[1:1:0712/072028.341358:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.341620:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.341877:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.342124:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 206944d8
[1:1:0712/072028.343395:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 206944d8
[1:1:0712/072028.343803:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1112bba7ba
[1:1:0712/072028.344004:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1112bb1def, 7f1112bba77a, 7f1112bbc0cf
[1:1:0712/072028.352422:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/072028.352951:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/072028.353154:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc7f7cf818, 0x7ffc7f7cf798)
[1:1:0712/072028.354515:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072028.354931:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072028.355297:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072028.355881:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072028.356325:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[99370:99382:0712/072028.363692:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[99370:99382:0712/072028.363784:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[99370:99370:0712/072028.363992:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://arrow.fandom.com/
[99370:99370:0712/072028.364048:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://arrow.fandom.com/, https://arrow.fandom.com/wiki/Arrowverse_Wiki, 1
[99370:99370:0712/072028.364150:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://arrow.fandom.com/, HTTP/1.1 200 status:200 content-encoding:gzip content-language:en content-security-policy:upgrade-insecure-requests content-security-policy-report-only:default-src https: 'self' data: blob:; script-src https: 'self' data: 'unsafe-inline' 'unsafe-eval' blob:; style-src https: 'self' 'unsafe-inline' blob:; report-uri https://services.fandom.com/csp-logger/csp/app content-type:text/html; charset=utf-8 etag:"20190712132719-1562783215262" last-modified:Fri, 12 Jul 2019 13:27:19 GMT server:nginx/1.16.0 x-backend-response-time:1.062 x-content-type-options:nosniff x-span-id:104a3778-c276-41a5-8997-4faf80efdf4e x-trace-id:aa74af8e-a27e-44bd-bc4a-1c19a6bcae0e x-datacenter:SJC x-cacheable:YES accept-ranges:bytes date:Fri, 12 Jul 2019 14:20:28 GMT age:3176 x-served-by:mediawiki-prod-77b77fd697-lkj66, cache-wk-sjc3163-WIKIA, cache-hnd18742-HND x-cache:ORIGIN, HIT, HIT x-cache-hits:ORIGIN, 7, 1 x-timer:S1562941228.195939,VS0,VE1 vary:Accept-Encoding, Cookie set-cookie:Geo={%22region%22:%22BJ%22%2C%22country%22:%22CN%22%2C%22continent%22:%22AS%22}; path=/ cache-control:private, s-maxage=0, max-age=0, must-revalidate content-length:48007  ,0, 6
[1:1:0712/072028.367914:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/072028.372270:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/072028.380223:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/072028.436629:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/072028.591372:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x69d7e852220
[1:1:0712/072028.591647:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/072028.638953:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://arrow.fandom.com/
[99370:99370:0712/072028.901023:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://arrow.fandom.com/, https://arrow.fandom.com/, 1
[99370:99370:0712/072028.901137:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://arrow.fandom.com/, https://arrow.fandom.com
[1:1:0712/072028.934774:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072029.154002:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072029.198630:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072029.233457:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072029.233704:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072030.320679:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072030.483370:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072030.988385:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072031.092674:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072031.171019:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072031.833281:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072031.960178:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072034.302644:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072042.123329:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f10fa8f6070 0x69d7eb8e5e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072042.124589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , 
var Wikia={},
wgUseSiteJs=true,
wgWikiVertical="tv",
wgWikiCategories=["tv"],
wgMessages={"category
[1:1:0712/072042.124718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072042.125807:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072042.127772:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f10fa8f6070 0x69d7eb8e5e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072042.129065:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f10fa8f6070 0x69d7eb8e5e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072042.130243:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f10fa8f6070 0x69d7eb8e5e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072042.133149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f10fa8f6070 0x69d7eb8e5e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072042.138772:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f10fa8f6070 0x69d7eb8e5e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[99370:99370:0712/072051.884756:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/072051.953512:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/072052.039568:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df208
[1:1:0712/072052.039855:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072052.040469:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 273
[1:1:0712/072052.040719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 273 0x7f10fa8f6070 0x69d7eb82760 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 233 0x7f10fa8f6070 0x69d7eb8e5e0 
[1:1:0712/072052.062631:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 9.93537, 0, 0
[1:1:0712/072052.062903:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072052.302334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/072052.302643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072052.707212:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072052.707486:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072052.708617:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f10fa8f6070 0x69d7e67f960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072052.709527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , /*<![CDATA[*/window.mw.fk&&delete mw;/*]]>*/
[1:1:0712/072052.709717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072052.712729:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f10fa8f6070 0x69d7e67f960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072052.774373:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f10fa8f6070 0x69d7e67f960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072053.012063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df6b0
[1:1:0712/072053.012362:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072053.012747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 305
[1:1:0712/072053.012942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 305 0x7f10fa8f6070 0x69d7eb74760 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 274 0x7f10fa8f6070 0x69d7e67f960 
[1:1:0712/072053.455237:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df6b0
[1:1:0712/072053.455516:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072053.455843:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 307
[1:1:0712/072053.455962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 307 0x7f10fa8f6070 0x69d7e67fa60 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 274 0x7f10fa8f6070 0x69d7e67f960 
[1:1:0712/072053.485024:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.777418, 1, 0
[1:1:0712/072053.485275:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072053.504251:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 273, 7f10fd23b881
[1:1:0712/072053.508506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"233 0x7f10fa8f6070 0x69d7eb8e5e0 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072053.508668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"233 0x7f10fa8f6070 0x69d7eb8e5e0 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072053.508827:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072053.509146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072053.509254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072053.573028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , document.readyState
[1:1:0712/072053.573224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072054.044583:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072054.044808:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.052993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f10fa8f6070 0x69d7eb56960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.054455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , 
	require(['wikia.trackingOptIn'], function(trackingOptIn) {
		trackingOptIn.pushToUserConsentQueue(
[1:1:0712/072054.054647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072054.055438:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df1a0
[1:1:0712/072054.055604:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072054.055985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 335
[1:1:0712/072054.056176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 335 0x7f10fa8f6070 0x69d7eb85a60 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 309 0x7f10fa8f6070 0x69d7eb56960 
[1:1:0712/072054.097227:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f10fa8f6070 0x69d7eb56960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.099062:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df1a0
[1:1:0712/072054.099297:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072054.099797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 358
[1:1:0712/072054.100108:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 358 0x7f10fa8f6070 0x69d7eb56f60 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 309 0x7f10fa8f6070 0x69d7eb56960 
[1:1:0712/072054.102422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f10fa8f6070 0x69d7eb56960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.103830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df1a0
[1:1:0712/072054.104141:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072054.104658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 361
[1:1:0712/072054.104904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 361 0x7f10fa8f6070 0x69d7eb74ae0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 309 0x7f10fa8f6070 0x69d7eb56960 
[1:1:0712/072054.107624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f10fa8f6070 0x69d7eb56960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.109176:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df1a0
[1:1:0712/072054.109439:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072054.109882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 364
[1:1:0712/072054.110145:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7f10fa8f6070 0x69d7e95f760 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 309 0x7f10fa8f6070 0x69d7eb56960 
[1:1:0712/072054.112844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f10fa8f6070 0x69d7eb56960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.114667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df1a0
[1:1:0712/072054.114888:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072054.115321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 367
[1:1:0712/072054.115570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 367 0x7f10fa8f6070 0x69d7eb235e0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 309 0x7f10fa8f6070 0x69d7eb56960 
[1:1:0712/072054.117885:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f10fa8f6070 0x69d7eb56960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.120907:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7f10fa8f6070 0x69d7eb56960 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.122851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df1a0
[1:1:0712/072054.123054:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072054.123590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 372
[1:1:0712/072054.123857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 372 0x7f10fa8f6070 0x69d7f5e94e0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 309 0x7f10fa8f6070 0x69d7eb56960 
[1:1:0712/072054.152395:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.107504, 169, 1
[1:1:0712/072054.152671:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072054.154483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 305, 7f10fd23b881
[1:1:0712/072054.173091:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"274 0x7f10fa8f6070 0x69d7e67f960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072054.173540:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"274 0x7f10fa8f6070 0x69d7e67f960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072054.173973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.175249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072054.175518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072054.355772:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 307, 7f10fd23b881
[1:1:0712/072054.364061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"274 0x7f10fa8f6070 0x69d7e67f960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072054.364393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"274 0x7f10fa8f6070 0x69d7e67f960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072054.364749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072054.365385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072054.365624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072055.310534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , document.readyState
[1:1:0712/072055.310848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072056.185510:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072056.185830:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.187077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f10fa8f6070 0x69d7f5f34e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.188333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , 
			window.adslots2.push(["top_leaderboard_ab"]);
		
[1:1:0712/072056.188623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072056.265503:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0794239, 713, 1
[1:1:0712/072056.265779:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072056.267306:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 335, 7f10fd23b881
[1:1:0712/072056.288516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.288920:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.289236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.289943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072056.290160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072056.293036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 358, 7f10fd23b881
[1:1:0712/072056.306157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.306504:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.306827:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.307464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072056.307740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072056.329453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 361, 7f10fd23b881
[1:1:0712/072056.345313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.345877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.346200:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.346839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072056.347077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072056.669280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 364, 7f10fd23b881
[1:1:0712/072056.681482:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.681849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.682204:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.682949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072056.683187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072056.688461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 367, 7f10fd23b881
[1:1:0712/072056.709435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.709798:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.710110:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.710747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072056.710968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072056.732464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 372, 7f10fd23b881
[1:1:0712/072056.751024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.751418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"309 0x7f10fa8f6070 0x69d7eb56960 ","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072056.751786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072056.752429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (){try{var reqId=Math.random(),m=[],x,y;for(x=0,y=ids.length;x<y;x+=1){var module=ids[x];m[x]=proces
[1:1:0712/072056.752632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[99370:99370:0712/072057.119399:INFO:CONSOLE(0)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://fonts.gstatic.com/s/rubik/v7/iJWHBXyIfDnIV7F6iGmd8WD07oB-.woff2", source: https://arrow.fandom.com/wiki/Arrowverse_Wiki (0)
[99370:99370:0712/072057.143430:INFO:CONSOLE(0)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://fonts.gstatic.com/s/rubik/v7/iJWKBXyIfDnIV7nBrXyw023e.woff2", source: https://arrow.fandom.com/wiki/Arrowverse_Wiki (0)
[1:1:0712/072058.218466:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072058.453676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , document.readyState
[1:1:0712/072058.454048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072058.712302:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072058.712568:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072058.713560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f10fa8f6070 0x69d7ef12e60 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072058.714513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , 
									window.adslots2.push(["top_boxad"]);
							
[1:1:0712/072058.714773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072059.002131:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.289487, 2645, 1
[1:1:0712/072059.002494:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072059.756430:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072059.757400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , t.onreadystatechange, (){4===this.readyState&&(200===this.status?(cn("instant-config","has response",this.response),e(this
[1:1:0712/072059.757638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072059.758550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072059.761250:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
		remove user.10_93837a08 -> 0
[1:1:0712/072102.793345:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072103.028644:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xbaf159829c8, 0x69d7e6df210
[1:1:0712/072103.028924:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 2000
[1:1:0712/072103.029421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 686
[1:1:0712/072103.029688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f10fa8f6070 0x69d7f95b760 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 459
[1:1:0712/072103.139898:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xbaf159829c8, 0x69d7e6df210
[1:1:0712/072103.140141:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 2000
[1:1:0712/072103.140535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 691
[1:1:0712/072103.140774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f10fa8f6070 0x69d7fbe25e0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 459
[1:1:0712/072105.396512:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xbaf159829c8, 0x69d7e6df460
[1:1:0712/072105.396820:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 2000
[1:1:0712/072105.397349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 700
[1:1:0712/072105.397594:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f10fa8f6070 0x69d80287ce0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 459
[1:1:0712/072105.476011:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.501965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.512025:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.892497:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.902498:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.913265:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.924353:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.955657:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072105.994774:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072106.089161:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072107.786155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7f10fc81e2e0 0x69d7f3fede0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072107.791254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0712/072107.791514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
		remove user.11_97eccaf -> 0
[1:1:0712/072108.975115:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f10fc81e2e0 0x69d7f30e060 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072108.976469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , function udm_(e,t){var n="comScore=",r=document,i=r.cookie,s="",o="indexOf",u="substring",a="length"
[1:1:0712/072108.976697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.119330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , document.readyState
[1:1:0712/072109.120531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.392017:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072109.392303:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.393286:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 501 0x7f10fa8f6070 0x69d7ef7eb60 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.394389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , JSSnippetsStack.push({dependencies:["/extensions/wikia/AjaxPoll/css/AjaxPoll.scss","/extensions/wiki
[1:1:0712/072109.394608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.531443:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.139026, 1227, 1
[1:1:0712/072109.531750:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072109.551597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.552866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.553098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.634638:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.635697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.635946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.649342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.650469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.650691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.689134:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.690457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.690733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.706144:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.707332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.707589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.781940:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.783160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.783385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.828618:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.829803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.830025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.866478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.867674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.867919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.904293:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.905512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.905736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.949092:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.950616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.950934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072109.976865:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072109.978381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072109.978686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.015274:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.016622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.016911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.054554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.055935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.056233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.128725:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.130014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.130268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.160143:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.161424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.161766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.190540:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.191842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.192128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.231127:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.232372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.232656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.289007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.290273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.290522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.313564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.314750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.314972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.353657:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.354912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.355145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.379519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.380750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.381000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.449596:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.451051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.451330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.475072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.478184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.478457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.519802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.521660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.521997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.566291:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.567642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.567952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.634373:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.635607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.635856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.675146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.676446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.676753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.714119:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.715351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.715620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.751490:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.752716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.752961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.802187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.803410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.803715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.818485:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.819731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.820013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.860736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.861954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.862185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.901814:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.903077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.903309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.933758:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.934979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.935218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.952281:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.953486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.953764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072110.995389:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072110.996957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072110.997209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.035064:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.036304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.036571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.114965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.116249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.116514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.159385:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.160658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.160900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.203596:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.224110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.226564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.268081:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.269328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.269565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.313870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.315111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.315337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.334584:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.336120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.336466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.371775:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.373026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.373252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.391247:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.392503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.392734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.456062:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.457372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.457648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.496878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.499449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.499726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.526550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.527780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.528040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.567496:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.568773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.569005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.650440:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.651668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.651979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.699052:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.700068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.700309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.745781:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.747016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.747256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.780933:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.781989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.782213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/072111.822610:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.823863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.824105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.860014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.861453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.861765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.902623:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.904063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.904320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072111.942034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072111.944552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072111.944879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.025141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.026153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.026398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.050592:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.051898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.052140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.074972:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.076267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.076536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.098471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.099906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.100218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.180224:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.181547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.181799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.221055:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.222296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.222532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.244268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.245491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.245743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.261388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.262576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.262793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.308227:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.309452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.309682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.355470:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.357172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.357428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.370487:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.371678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.371923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.411228:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.412480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.412702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.462551:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.463831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.464068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.485351:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.486565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.486830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.528587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.529809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.530031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.557809:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.559023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.559242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.636517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.637744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.637981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.650874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.652067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.652313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.677916:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.679176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onload, if(typeof ImgLzy==='object'){ImgLzy.load(this)}
[1:1:0712/072112.679403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.726094:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581 0x7f10fc81e2e0 0x69d7f2c0e60 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.733474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , /* Copyright (c) 2008-2018, Quantcast Corp. */
/* Version: 4c19192-20180628134937 */
window.__qc=fun
[1:1:0712/072112.733747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.780448:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 582 0x7f10fc81e2e0 0x69d7f50b8e0 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072112.783563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (function(){var a=window.SambaTV=window.SambaTV||[];a.attrs||(a.attrs={});var b=function(a){var b=[]
[1:1:0712/072112.783853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072112.785056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xbaf159829c8, 0x69d7e6df190
[1:1:0712/072112.785272:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 0
[1:1:0712/072112.785699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 840
[1:1:0712/072112.785942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7f10fa8f6070 0x69d7f4bb4e0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 582 0x7f10fc81e2e0 0x69d7f50b8e0 
[99370:99370:0712/072113.727200:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/072116.890424:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072116.890839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072116.890952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072116.891191:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072116.892875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072116.985397:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072116.986157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072116.987105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072116.987644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072116.990042:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072117.072380:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 691, 7f10fd23b881
[1:1:0712/072117.117187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"459","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072117.117524:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"459","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072117.117880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072117.118480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , 
[1:1:0712/072117.118672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[99370:99370:0712/072117.149359:INFO:CONSOLE(298)] "Created ad slot top_leaderboard", source: https://slot1-images.wikia.nocookie.net/__am/1562783215262/groups/-/abtesting,oasis_blocking,universal_analytics_js,adengine3_top_js,tracking_opt_in_js,qualaroo_blocking_js (298)
[99370:99370:0712/072117.188449:INFO:CONSOLE(298)] "Created ad slot top_leaderboard_ab", source: https://slot1-images.wikia.nocookie.net/__am/1562783215262/groups/-/abtesting,oasis_blocking,universal_analytics_js,adengine3_top_js,tracking_opt_in_js,qualaroo_blocking_js (298)
[99370:99370:0712/072117.200393:INFO:CONSOLE(298)] "Created ad slot top_boxad", source: https://slot1-images.wikia.nocookie.net/__am/1562783215262/groups/-/abtesting,oasis_blocking,universal_analytics_js,adengine3_top_js,tracking_opt_in_js,qualaroo_blocking_js (298)
[99370:99370:0712/072117.219436:INFO:CONSOLE(298)] "Created ad slot invisible_high_impact_2", source: https://slot1-images.wikia.nocookie.net/__am/1562783215262/groups/-/abtesting,oasis_blocking,universal_analytics_js,adengine3_top_js,tracking_opt_in_js,qualaroo_blocking_js (298)
[1:1:0712/072117.312586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072117.312995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072117.313106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072117.313903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072117.315939:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072117.610700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0xbaf159829c8, 0x69d7e6df210
[1:1:0712/072117.610964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 6000
[1:1:0712/072117.611368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 899
[1:1:0712/072117.611587:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 899 0x7f10fa8f6070 0x69d7f5f4be0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 729
[1:1:0712/072117.984616:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072117.985037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072117.985154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072117.985397:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072117.986699:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072118.148812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072118.149567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , _t, (){ht.landscape()?(Et("portrait"),St("landscape"),
At("landscape")):(Et("landscape"),St("portrait"),
[1:1:0712/072118.149754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.085777:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.086780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072120.087118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.087979:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.091404:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.142591:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.143578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072120.143934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.144894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.147413:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.192382:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 700, 7f10fd23b881
[1:1:0712/072120.235601:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2b29382860","ptid":"459","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072120.235973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://arrow.fandom.com/","ptid":"459","rf":"6:3_https://arrow.fandom.com/"}
[1:1:0712/072120.236375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.237342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , d, (e,t){if(t&&clearTimeout(p),null!=m){var n=[];e&&(_.logMessage("Auction ".concat(h," timedOut")),c=y
[1:1:0712/072120.237570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.277407:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.278278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072120.278481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.375891:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "timeout", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.427105:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.427940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072120.428179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.428712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.431098:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.552242:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.553323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072120.553558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.554110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.556285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.700057:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 748 0x7f10fc81e2e0 0x69d801ca560 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.711157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , 
/* CLIENTCONFIG build v1.0.21*/
!function (n, e) { "use strict"; var o = "1.0.21", t = "NOLBUNDLE
[1:1:0712/072120.711460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072120.807384:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 749 0x7f10fc81e2e0 0x69d7f85ef60 , "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072120.822558:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072120.829379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , , (function(E){var window=this;var aa=function(a){var b=0;return function(){return b<a.length?{done:!1
[1:1:0712/072120.829638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072121.310501:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0xbaf159829c8, 0x69d7e6df190
[1:1:0712/072121.310777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://arrow.fandom.com/wiki/Arrowverse_Wiki", 1000
[1:1:0712/072121.311251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://arrow.fandom.com/, 939
[1:1:0712/072121.311488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 939 0x7f10fa8f6070 0x69d81479ee0 , 6:3_https://arrow.fandom.com/, 1, -6:3_https://arrow.fandom.com/, 749 0x7f10fc81e2e0 0x69d7f85ef60 
[1:1:0712/072121.334233:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072121.391156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072121.392146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://arrow.fandom.com/, 1f2b29382860, , onreadystatechange, (){if(i.readyState===y){"function"==typeof f&&f(a.origin);var e=i.status;200<=e&&e<300||304===e?c.su
[1:1:0712/072121.392384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://arrow.fandom.com/wiki/Arrowverse_Wiki", "arrow.fandom.com", 3, 1, , , 0
[1:1:0712/072121.393087:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
[1:1:0712/072121.395672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://arrow.fandom.com/wiki/Arrowverse_Wiki"
