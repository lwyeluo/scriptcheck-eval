[0712/233427.767337:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233427.767704:INFO:switcher_clone.cc(787)] backtrace rip is 7fce5f662891
[0712/233428.807483:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233428.808033:INFO:switcher_clone.cc(787)] backtrace rip is 7f38f8fc1891
[1:1:0712/233428.820055:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/233428.820307:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/233428.825979:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/233430.254306:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233430.254578:INFO:switcher_clone.cc(787)] backtrace rip is 7f9c6c8ef891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[20537:20537:0712/233430.471425:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20537
[20547:20547:0712/233430.471954:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20547
[20504:20504:0712/233430.485971:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/8272ad7b-193e-48e8-8005-9797b076a3b0
[20504:20504:0712/233430.942274:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[20504:20534:0712/233430.943106:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/233430.943304:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/233430.943534:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/233430.944109:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/233430.944283:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/233430.947120:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x38519c6, 1
[1:1:0712/233430.947444:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x27b5397a, 0
[1:1:0712/233430.947631:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb7e5061, 3
[1:1:0712/233430.947834:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x17a70650, 2
[1:1:0712/233430.948056:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7a39ffffffb527 ffffffc619ffffff8503 5006ffffffa717 61507e0b , 10104, 4
[1:1:0712/233430.949009:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20504:20534:0712/233430.949257:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGz9�'��P�aP~��Q<
[20504:20534:0712/233430.949344:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is z9�'��P�aP~��Q<
[1:1:0712/233430.949251:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38f71fc0a0, 3
[1:1:0712/233430.949446:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38f7387080, 2
[20504:20534:0712/233430.949622:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/233430.949596:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38e104ad20, -2
[20504:20534:0712/233430.949699:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20557, 4, 7a39b527 c6198503 5006a717 61507e0b 
[1:1:0712/233430.967763:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/233430.968613:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 17a70650
[1:1:0712/233430.969574:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 17a70650
[1:1:0712/233430.971354:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 17a70650
[1:1:0712/233430.973178:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.973465:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.973688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.973925:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.974774:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 17a70650
[1:1:0712/233430.975145:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38f8fc17ba
[1:1:0712/233430.975307:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38f8fb8def, 7f38f8fc177a, 7f38f8fc30cf
[1:1:0712/233430.982300:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 17a70650
[1:1:0712/233430.982776:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 17a70650
[1:1:0712/233430.983680:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 17a70650
[1:1:0712/233430.986156:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.986387:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.986639:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.986860:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 17a70650
[1:1:0712/233430.988423:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 17a70650
[1:1:0712/233430.988858:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38f8fc17ba
[1:1:0712/233430.989078:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38f8fb8def, 7f38f8fc177a, 7f38f8fc30cf
[1:1:0712/233430.998556:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/233430.999086:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/233430.999257:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffd0f4e5f8, 0x7fffd0f4e578)
[1:1:0712/233431.017455:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/233431.024362:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[20504:20504:0712/233431.656220:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20504:20504:0712/233431.657425:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20504:20516:0712/233431.677475:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[20504:20516:0712/233431.677591:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[20504:20504:0712/233431.677832:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[20504:20504:0712/233431.677932:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[20504:20504:0712/233431.678125:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,20557, 4
[1:7:0712/233431.684189:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[20504:20527:0712/233431.741544:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/233431.759913:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x30c2f58bc220
[1:1:0712/233431.760149:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/233432.055130:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/233433.549975:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233433.553291:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[20504:20504:0712/233433.603981:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[20504:20504:0712/233433.604069:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/233434.917680:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233435.146353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3235f3701f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/233435.146647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233435.162558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3235f3701f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/233435.162744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233435.334293:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233435.334580:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233435.824022:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233435.832181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3235f3701f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/233435.832504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233435.875975:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233435.888843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3235f3701f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/233435.889099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233435.903864:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/233435.907680:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x30c2f58bae20
[1:1:0712/233435.907877:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[20504:20504:0712/233435.908624:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[20504:20504:0712/233435.918678:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[20504:20504:0712/233435.954719:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[20504:20504:0712/233435.954885:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/233436.018741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233436.695734:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f38e2c252e0 0x30c2f5b4a5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233436.696437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3235f3701f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/233436.696559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233436.697117:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20504:20504:0712/233436.727389:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/233436.730135:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x30c2f58bb820
[1:1:0712/233436.730377:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[20504:20504:0712/233436.734149:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/233436.752428:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/233436.752683:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[20504:20504:0712/233436.753915:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[20504:20504:0712/233436.765649:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20504:20504:0712/233436.766721:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20504:20516:0712/233436.773014:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[20504:20516:0712/233436.773140:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[20504:20504:0712/233436.773245:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[20504:20504:0712/233436.773323:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[20504:20504:0712/233436.773463:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,20557, 4
[1:7:0712/233436.777849:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/233437.311804:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/233437.979531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f38e2c252e0 0x30c2f5b3fe60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233437.980815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3235f3701f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/233437.981050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233437.981807:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20504:20504:0712/233438.137641:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[20504:20504:0712/233438.137763:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/233438.150500:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[20504:20504:0712/233438.470309:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[20504:20534:0712/233438.470725:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/233438.470902:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/233438.471124:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/233438.471486:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/233438.471653:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/233438.474684:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3ee67f5f, 1
[1:1:0712/233438.475016:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2f3a1918, 0
[1:1:0712/233438.475177:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x123a87ed, 3
[1:1:0712/233438.475340:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xab4677f, 2
[1:1:0712/233438.475481:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 18193a2f 5f7fffffffe63e 7f67ffffffb40a ffffffedffffff873a12 , 10104, 5
[1:1:0712/233438.476456:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20504:20534:0712/233438.476701:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING:/_�>g�
�:��Q<
[20504:20534:0712/233438.476766:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is :/_�>g�
�:���Q<
[1:1:0712/233438.476693:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38f71fc0a0, 3
[1:1:0712/233438.476864:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38f7387080, 2
[20504:20534:0712/233438.477050:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20602, 5, 18193a2f 5f7fe63e 7f67b40a ed873a12 
[1:1:0712/233438.477052:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f38e104ad20, -2
[1:1:0712/233438.499230:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/233438.499548:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ab4677f
[1:1:0712/233438.499880:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ab4677f
[1:1:0712/233438.500512:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ab4677f
[1:1:0712/233438.501893:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.502072:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.502282:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.502464:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.503111:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ab4677f
[1:1:0712/233438.503415:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38f8fc17ba
[1:1:0712/233438.503553:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38f8fb8def, 7f38f8fc177a, 7f38f8fc30cf
[1:1:0712/233438.509294:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ab4677f
[1:1:0712/233438.509657:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ab4677f
[1:1:0712/233438.510421:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ab4677f
[1:1:0712/233438.512342:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.512460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.512558:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.512663:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ab4677f
[1:1:0712/233438.513104:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ab4677f
[1:1:0712/233438.513296:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f38f8fc17ba
[1:1:0712/233438.513392:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f38f8fb8def, 7f38f8fc177a, 7f38f8fc30cf
[1:1:0712/233438.515588:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/233438.515892:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/233438.515980:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffd0f4e5f8, 0x7fffd0f4e578)
[1:1:0712/233438.528523:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/233438.532769:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/233438.566059:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233438.716604:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x30c2f589e220
[1:1:0712/233438.716878:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/233439.238594:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233439.238827:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233439.622766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233439.627215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3235f382e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/233439.627521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/233439.632408:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233439.715542:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233439.716223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3235f3701f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/233439.716432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233439.739020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233439.740600:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/233439.740820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3235f382e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/233439.741098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[20504:20504:0712/233439.780141:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20504:20504:0712/233439.785689:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20504:20516:0712/233439.807922:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[20504:20516:0712/233439.808042:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[20504:20504:0712/233439.808514:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://wenku.it168.com/
[20504:20504:0712/233439.808628:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://wenku.it168.com/, http://wenku.it168.com/wenji/2743, 1
[20504:20504:0712/233439.808791:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://wenku.it168.com/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 06:34:39 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Server: nginx Vary: Accept-Encoding X-Powered-By: PHP/7.1.24 Cache-Control: max-age=3600, public Content-Encoding: gzip Set-Cookie: wenku_it168=wenkuit1682; path=/ Cache-Control: private X-Ser: BC165_dx-lt-yd-jiangsu-zhenjiang-3-cache-13, BC145_dx-lt-yd-zhejiang-jinhua-5-cache-13, BC55_ck-zhejiang-hangzhou-1-cache-1, BC156_ck-beijing-beijing-2-cache-2 X-Cache: MISS from BC156_ck-beijing-beijing-2-cache-2(baishan)  ,20602, 5
[1:7:0712/233439.815511:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/233439.860249:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://wenku.it168.com/
[1:1:0712/233439.883433:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233439.884295:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/233439.884527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3235f382e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/233439.884803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/233439.973499:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[20504:20504:0712/233439.983449:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://wenku.it168.com/, http://wenku.it168.com/, 1
[20504:20504:0712/233439.983545:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://wenku.it168.com/, http://wenku.it168.com
[1:1:0712/233440.081882:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233440.162469:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/233440.225435:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233440.225726:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wenku.it168.com/wenji/2743"
[1:1:0712/233440.298238:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0712/233440.438504:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.researchgate.net/?_sg=GTTcjmmIjXiKFH9nfUmSzdlSVNCfHlOW5NedMmBB5tECtK-L3s9hJP_gtJf5_sYEDAmD6IvCizZl"
[1:1:0712/233440.532211:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233440.591694:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.fandom.com/"
[1:1:0712/233440.649557:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://stackoverflow.com/"
[1:1:0712/233440.726517:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/233440.737734:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7f38e1065bd0 0x30c2f59be4d8 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233440.761558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , /*! jQuery v1.8.2 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};retu
[1:1:0712/233440.761855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233440.764269:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233440.803276:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.springer.com/"
[1:1:0712/233440.851452:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wish.com/"
[1:1:0712/233440.931822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7f38e1065bd0 0x30c2f59be4d8 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233440.935423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7f38e1065bd0 0x30c2f59be4d8 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233440.950234:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0197461, 52, 1
[1:1:0712/233440.950397:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233440.994435:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233440.994651:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wenku.it168.com/wenji/2743"
[1:1:0712/233440.995435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f38e0cfd070 0x30c2f5974260 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233440.996559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , 
    $(function () {
        $.get('/islogin?r='+Math.random(), function (xhr) {
            if(xhr.
[1:1:0712/233440.996755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233441.011936:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0170939, 82, 1
[1:1:0712/233441.012082:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233441.093595:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233441.093859:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.094815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179 0x7f38e0cfd070 0x30c2f59b7ce0 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.095970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , 
        var mobileUrl = '/3g/wenji/2743';
        //是否是手机端访问
        if (navigator.
[1:1:0712/233441.096186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233441.598031:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.504014, 802, 1
[1:1:0712/233441.598263:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233441.683498:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233441.683707:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.684478:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f38e0cfd070 0x30c2f5bf8be0 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.685795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , 
        $(function () {
            $("#toPage").click(function (eventObject) {
                var
[1:1:0712/233441.686003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233441.723458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f38e0cfd070 0x30c2f5bf8be0 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.731226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f38e0cfd070 0x30c2f5bf8be0 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.732579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 1000
[1:1:0712/233441.733040:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 196
[1:1:0712/233441.733286:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 196 0x7f38e0cfd070 0x30c2f58fad60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 187 0x7f38e0cfd070 0x30c2f5bf8be0 
[1:1:0712/233441.745109:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.06129, 55, 1
[1:1:0712/233441.745337:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233441.828886:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233441.829120:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.829856:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f38e0cfd070 0x30c2f58af360 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.830913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , 
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
   
[1:1:0712/233441.831113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233441.839761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f38e0cfd070 0x30c2f58af360 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233441.851381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233443.620537:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 196, 7f38e3642881
[1:1:0712/233443.630823:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"187 0x7f38e0cfd070 0x30c2f5bf8be0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233443.631111:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"187 0x7f38e0cfd070 0x30c2f5bf8be0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233443.631395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233443.632237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , sendPV()
[1:1:0712/233443.632474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233443.657542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437170
[1:1:0712/233443.657790:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233443.658171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 249
[1:1:0712/233443.658424:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 249 0x7f38e0cfd070 0x30c2f59be9e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 196 0x7f38e0cfd070 0x30c2f58fad60 
[1:1:0712/233443.716677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 234 0x7f38e2c252e0 0x30c2f5974f60 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233443.725867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , (function(){var h={},mt={},c={id:"5e7db88b9c87b18fa16f090e752d5567",dm:["it168.com"],js:"tongji.baid
[1:1:0712/233443.726097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233443.757412:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437148
[1:1:0712/233443.757738:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233443.758121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 254
[1:1:0712/233443.758389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 254 0x7f38e0cfd070 0x30c2f5b05b60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 234 0x7f38e2c252e0 0x30c2f5974f60 
[1:1:0712/233449.018012:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233449.018488:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233449.018839:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233449.019209:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233449.019548:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[20504:20504:0712/233516.709498:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/233516.721015:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/233516.837867:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233516.895660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 235 0x7f38e2c252e0 0x30c2f5ad06e0 , "http://wenku.it168.com/wenji/2743"
[1:1:0712/233516.902444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , (function(){var h={},mt={},c={id:"983c7d083f0d950dce43cb213ea922de",dm:["wenku.it168.com"],js:"tongj
[1:1:0712/233516.902865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233516.928732:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437140
[1:1:0712/233516.929013:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233516.929446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 317
[1:1:0712/233516.929802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 317 0x7f38e0cfd070 0x30c2f59bc6e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 235 0x7f38e2c252e0 0x30c2f5ad06e0 
[1:1:0712/233517.116287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233517.117072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete 
[1:1:0712/233517.117305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233517.118532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233517.121315:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233517.122012:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2f8830fafbb8
[1:1:0712/233517.198276:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 249, 7f38e3642881
[1:1:0712/233517.210390:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"196 0x7f38e0cfd070 0x30c2f58fad60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233517.210855:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"196 0x7f38e0cfd070 0x30c2f58fad60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233517.211252:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233517.211925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233517.212163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233517.212854:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233517.213095:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233517.213584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 344
[1:1:0712/233517.213815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 344 0x7f38e0cfd070 0x30c2f5787560 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 249 0x7f38e0cfd070 0x30c2f59be9e0 
[1:1:0712/233517.369777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/233517.370093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233517.849007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 254, 7f38e3642881
[1:1:0712/233517.854271:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"234 0x7f38e2c252e0 0x30c2f5974f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233517.854579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"234 0x7f38e2c252e0 0x30c2f5974f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233517.854976:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233517.855595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233517.855811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233517.856664:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233517.856866:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233517.857295:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 363
[1:1:0712/233517.857524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 363 0x7f38e0cfd070 0x30c2f5ada4e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 254 0x7f38e0cfd070 0x30c2f5b05b60 
[1:1:0712/233518.083302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 317, 7f38e3642881
[1:1:0712/233518.095121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"235 0x7f38e2c252e0 0x30c2f5ad06e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.095441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"235 0x7f38e2c252e0 0x30c2f5ad06e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.095868:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.096518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233518.096729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233518.097513:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233518.097710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233518.098081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 369
[1:1:0712/233518.098483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 369 0x7f38e0cfd070 0x30c2f5ad3860 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 317 0x7f38e0cfd070 0x30c2f59bc6e0 
[1:1:0712/233518.163449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 344, 7f38e3642881
[1:1:0712/233518.179244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"249 0x7f38e0cfd070 0x30c2f59be9e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.179536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"249 0x7f38e0cfd070 0x30c2f59be9e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.179918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.180581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233518.180790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233518.181371:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233518.181573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233518.181945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 373
[1:1:0712/233518.182195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 373 0x7f38e0cfd070 0x30c2f5acf6e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 344 0x7f38e0cfd070 0x30c2f5787560 
[1:1:0712/233518.599024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , document.readyState
[1:1:0712/233518.599350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233518.791330:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.792100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , f.onload, (){f.onload=v;f=window[d]=v;a&&a(b)}
[1:1:0712/233518.792371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233518.820268:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 363, 7f38e3642881
[1:1:0712/233518.838007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"254 0x7f38e0cfd070 0x30c2f5b05b60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.838436:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"254 0x7f38e0cfd070 0x30c2f5b05b60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.838841:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.839499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233518.839712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233518.840451:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233518.840645:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233518.841028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 412
[1:1:0712/233518.841273:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 412 0x7f38e0cfd070 0x30c2f5ad80e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 363 0x7f38e0cfd070 0x30c2f5ada4e0 
[1:1:0712/233518.879821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.880700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/233518.880913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233518.890182:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.890936:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.892818:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.895988:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.897573:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f54372f0
[1:1:0712/233518.897774:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233518.898155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 416
[1:1:0712/233518.898415:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 416 0x7f38e0cfd070 0x30c2f68a8260 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 371 0x7f38e0cfd070 0x30c2f5ad8e60 
[1:1:0712/233518.898801:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.899741:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f54371f0
[1:1:0712/233518.899945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233518.900371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 417
[1:1:0712/233518.900596:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 417 0x7f38e0cfd070 0x30c2f68a8ce0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 371 0x7f38e0cfd070 0x30c2f5ad8e60 
[1:1:0712/233518.929827:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 373, 7f38e3642881
[1:1:0712/233518.947981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"344 0x7f38e0cfd070 0x30c2f5787560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.948346:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"344 0x7f38e0cfd070 0x30c2f5787560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233518.948733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233518.949388:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233518.949620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233518.950180:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233518.950425:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233518.950809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 420
[1:1:0712/233518.951040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 420 0x7f38e0cfd070 0x30c2f5ad38e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 373 0x7f38e0cfd070 0x30c2f5acf6e0 
[1:1:0712/233519.160825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , , document.readyState
[1:1:0712/233519.161115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233519.517968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 420, 7f38e3642881
[1:1:0712/233519.536668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"373 0x7f38e0cfd070 0x30c2f5acf6e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.536992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"373 0x7f38e0cfd070 0x30c2f5acf6e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.537407:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233519.538028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233519.538260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233519.538849:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233519.539042:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233519.539417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 436
[1:1:0712/233519.539650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7f38e0cfd070 0x30c2f68b6ee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 420 0x7f38e0cfd070 0x30c2f5ad38e0 
[1:1:0712/233519.561377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 416, 7f38e3642881
[1:1:0712/233519.580382:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"371 0x7f38e0cfd070 0x30c2f5ad8e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.580740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"371 0x7f38e0cfd070 0x30c2f5ad8e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.581161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233519.581758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233519.581967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233519.582725:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233519.582916:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233519.583290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 438
[1:1:0712/233519.583539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 438 0x7f38e0cfd070 0x30c2f68b26e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 416 0x7f38e0cfd070 0x30c2f68a8260 
[1:1:0712/233519.624392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 417, 7f38e3642881
[1:1:0712/233519.643265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"371 0x7f38e0cfd070 0x30c2f5ad8e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.643631:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"371 0x7f38e0cfd070 0x30c2f5ad8e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.644040:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233519.644683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233519.644892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233519.645616:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233519.645805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233519.646177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 443
[1:1:0712/233519.646435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 443 0x7f38e0cfd070 0x30c2f68c6de0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 417 0x7f38e0cfd070 0x30c2f68a8ce0 
[1:1:0712/233519.775385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 436, 7f38e3642881
[1:1:0712/233519.796097:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"420 0x7f38e0cfd070 0x30c2f5ad38e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.796579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"420 0x7f38e0cfd070 0x30c2f5ad38e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.797043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233519.797800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233519.798039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233519.798694:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233519.798898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233519.799274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 451
[1:1:0712/233519.799500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 451 0x7f38e0cfd070 0x30c2f59317e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 436 0x7f38e0cfd070 0x30c2f68b6ee0 
[1:1:0712/233519.941423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 438, 7f38e3642881
[1:1:0712/233519.960830:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"416 0x7f38e0cfd070 0x30c2f68a8260 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.961176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"416 0x7f38e0cfd070 0x30c2f68a8260 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233519.961538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233519.962148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233519.962324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233519.963066:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233519.963226:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233519.963608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 459
[1:1:0712/233519.963800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 459 0x7f38e0cfd070 0x30c2f596e760 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 438 0x7f38e0cfd070 0x30c2f68b26e0 
[1:1:0712/233519.986532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 443, 7f38e3642881
[1:1:0712/233520.005889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"417 0x7f38e0cfd070 0x30c2f68a8ce0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.006195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"417 0x7f38e0cfd070 0x30c2f68a8ce0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.006556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.007149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233520.007323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.008208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.008446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.008862:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 460
[1:1:0712/233520.009056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 460 0x7f38e0cfd070 0x30c2f58e4b60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 443 0x7f38e0cfd070 0x30c2f68c6de0 
[1:1:0712/233520.010701:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 451, 7f38e3642881
[1:1:0712/233520.035294:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"436 0x7f38e0cfd070 0x30c2f68b6ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.035687:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"436 0x7f38e0cfd070 0x30c2f68b6ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.036122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.036911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.037132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.037813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.038012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.038450:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 462
[1:1:0712/233520.038737:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 462 0x7f38e0cfd070 0x30c2f62e4fe0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 451 0x7f38e0cfd070 0x30c2f59317e0 
[1:1:0712/233520.174884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 462, 7f38e3642881
[1:1:0712/233520.194161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"451 0x7f38e0cfd070 0x30c2f59317e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.194453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"451 0x7f38e0cfd070 0x30c2f59317e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.194836:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.195404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.195578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.196121:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.196276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.196660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 474
[1:1:0712/233520.196850:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 474 0x7f38e0cfd070 0x30c2f59358e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 462 0x7f38e0cfd070 0x30c2f62e4fe0 
[1:1:0712/233520.238709:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 459, 7f38e3642881
[1:1:0712/233520.258178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"438 0x7f38e0cfd070 0x30c2f68b26e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.258496:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"438 0x7f38e0cfd070 0x30c2f68b26e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.258887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.259459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233520.259647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.260306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.260460:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.260837:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 478
[1:1:0712/233520.261026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 478 0x7f38e0cfd070 0x30c2f59c4f60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 459 0x7f38e0cfd070 0x30c2f596e760 
[1:1:0712/233520.282997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 460, 7f38e3642881
[1:1:0712/233520.302507:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"443 0x7f38e0cfd070 0x30c2f68c6de0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.302848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"443 0x7f38e0cfd070 0x30c2f68c6de0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.303190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.303754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233520.303927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.304577:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.304789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.305142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 479
[1:1:0712/233520.305328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 479 0x7f38e0cfd070 0x30c2f68ca7e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 460 0x7f38e0cfd070 0x30c2f58e4b60 
[1:1:0712/233520.327302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 474, 7f38e3642881
[1:1:0712/233520.347176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"462 0x7f38e0cfd070 0x30c2f62e4fe0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.347489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"462 0x7f38e0cfd070 0x30c2f62e4fe0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.347899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.348619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.348864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.349538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.349757:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.350207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 481
[1:1:0712/233520.350457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7f38e0cfd070 0x30c2f5b396e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 474 0x7f38e0cfd070 0x30c2f59358e0 
[1:1:0712/233520.414068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 481, 7f38e3642881
[1:1:0712/233520.434075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"474 0x7f38e0cfd070 0x30c2f59358e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.434384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"474 0x7f38e0cfd070 0x30c2f59358e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.434778:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.438992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.439181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.443573:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.443761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.444127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 488
[1:1:0712/233520.444313:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 488 0x7f38e0cfd070 0x30c2f58a57e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 481 0x7f38e0cfd070 0x30c2f5b396e0 
[1:1:0712/233520.505886:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 478, 7f38e3642881
[1:1:0712/233520.525714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"459 0x7f38e0cfd070 0x30c2f596e760 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.526006:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"459 0x7f38e0cfd070 0x30c2f596e760 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.526341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.526915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233520.527090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.527770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.527928:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.528277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 494
[1:1:0712/233520.528464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 494 0x7f38e0cfd070 0x30c2f68b5c60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 478 0x7f38e0cfd070 0x30c2f59c4f60 
[1:1:0712/233520.529843:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 479, 7f38e3642881
[1:1:0712/233520.550065:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"460 0x7f38e0cfd070 0x30c2f58e4b60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.550363:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"460 0x7f38e0cfd070 0x30c2f58e4b60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.550745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.551288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233520.551460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.552129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.552284:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.552627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 495
[1:1:0712/233520.552848:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7f38e0cfd070 0x30c2f68c6160 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 479 0x7f38e0cfd070 0x30c2f68ca7e0 
[1:1:0712/233520.554167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 488, 7f38e3642881
[1:1:0712/233520.574006:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"481 0x7f38e0cfd070 0x30c2f5b396e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.574308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"481 0x7f38e0cfd070 0x30c2f5b396e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.574648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.575318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.575492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.576037:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.576193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.576536:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 496
[1:1:0712/233520.576741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 496 0x7f38e0cfd070 0x30c2f5935d60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 488 0x7f38e0cfd070 0x30c2f58a57e0 
[1:1:0712/233520.598632:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 496, 7f38e3642881
[1:1:0712/233520.618553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"488 0x7f38e0cfd070 0x30c2f58a57e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.618882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"488 0x7f38e0cfd070 0x30c2f58a57e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.619222:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.619808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.619996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.620514:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.620674:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.621041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 500
[1:1:0712/233520.621239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 500 0x7f38e0cfd070 0x30c2f59c43e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 496 0x7f38e0cfd070 0x30c2f5935d60 
[1:1:0712/233520.673413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 500, 7f38e3642881
[1:1:0712/233520.699130:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"496 0x7f38e0cfd070 0x30c2f5935d60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.699517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"496 0x7f38e0cfd070 0x30c2f5935d60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.699964:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.700725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.700964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.701619:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.701832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.702270:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 509
[1:1:0712/233520.702510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 509 0x7f38e0cfd070 0x30c2f62e5a60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 500 0x7f38e0cfd070 0x30c2f59c43e0 
[1:1:0712/233520.769681:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 494, 7f38e3642881
[1:1:0712/233520.790040:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"478 0x7f38e0cfd070 0x30c2f59c4f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.790363:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"478 0x7f38e0cfd070 0x30c2f59c4f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.790708:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.791296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233520.791482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.792177:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.792334:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.792680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 513
[1:1:0712/233520.792896:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7f38e0cfd070 0x30c2f68b69e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 494 0x7f38e0cfd070 0x30c2f68b5c60 
[1:1:0712/233520.851985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 495, 7f38e3642881
[1:1:0712/233520.872487:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"479 0x7f38e0cfd070 0x30c2f68ca7e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.872794:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"479 0x7f38e0cfd070 0x30c2f68ca7e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.873137:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.873695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233520.873888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.874544:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.874697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.875224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 517
[1:1:0712/233520.875412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 517 0x7f38e0cfd070 0x30c2f59be460 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 495 0x7f38e0cfd070 0x30c2f68c6160 
[1:1:0712/233520.918590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 509, 7f38e3642881
[1:1:0712/233520.939584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"500 0x7f38e0cfd070 0x30c2f59c43e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.939929:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"500 0x7f38e0cfd070 0x30c2f59c43e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.940281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.940878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233520.941065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.941588:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.941741:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233520.942112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 521
[1:1:0712/233520.942312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 521 0x7f38e0cfd070 0x30c2f59317e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 509 0x7f38e0cfd070 0x30c2f62e5a60 
[1:1:0712/233520.965489:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 513, 7f38e3642881
[1:1:0712/233520.986194:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"494 0x7f38e0cfd070 0x30c2f68b5c60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.986513:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"494 0x7f38e0cfd070 0x30c2f68b5c60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233520.986906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233520.987476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233520.987651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233520.988325:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233520.988481:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233520.988855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 523
[1:1:0712/233520.989047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7f38e0cfd070 0x30c2f59bdd60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 513 0x7f38e0cfd070 0x30c2f68b69e0 
[1:1:0712/233521.032544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 521, 7f38e3642881
[1:1:0712/233521.053184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"509 0x7f38e0cfd070 0x30c2f62e5a60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.053505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"509 0x7f38e0cfd070 0x30c2f62e5a60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.053866:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.054444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.054628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.055211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.055366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.055714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 528
[1:1:0712/233521.055924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7f38e0cfd070 0x30c2f5aceee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 521 0x7f38e0cfd070 0x30c2f59317e0 
[1:1:0712/233521.057298:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 517, 7f38e3642881
[1:1:0712/233521.081051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"495 0x7f38e0cfd070 0x30c2f68c6160 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.081380:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"495 0x7f38e0cfd070 0x30c2f68c6160 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.081729:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.082451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233521.082671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.083557:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.083755:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.084231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 529
[1:1:0712/233521.084471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7f38e0cfd070 0x30c2f68ca460 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 517 0x7f38e0cfd070 0x30c2f59be460 
[1:1:0712/233521.086559:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 528, 7f38e3642881
[1:1:0712/233521.099660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"521 0x7f38e0cfd070 0x30c2f59317e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.099960:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"521 0x7f38e0cfd070 0x30c2f59317e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.100236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.100659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.100816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.101190:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.101320:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.101569:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 532
[1:1:0712/233521.101722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f38e0cfd070 0x30c2f68a81e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 528 0x7f38e0cfd070 0x30c2f5aceee0 
[1:1:0712/233521.122067:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 523, 7f38e3642881
[1:1:0712/233521.132065:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"513 0x7f38e0cfd070 0x30c2f68b69e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.132282:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"513 0x7f38e0cfd070 0x30c2f68b69e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.132537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.132992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233521.133145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.133586:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.133718:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.133983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 537
[1:1:0712/233521.134135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 537 0x7f38e0cfd070 0x30c2f59a2360 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 523 0x7f38e0cfd070 0x30c2f59bdd60 
[1:1:0712/233521.134768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 532, 7f38e3642881
[1:1:0712/233521.144333:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"528 0x7f38e0cfd070 0x30c2f5aceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.144516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"528 0x7f38e0cfd070 0x30c2f5aceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.144745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.145146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.145300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.145641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.145772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.146024:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 538
[1:1:0712/233521.146180:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 538 0x7f38e0cfd070 0x30c2f68c4fe0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 532 0x7f38e0cfd070 0x30c2f68a81e0 
[1:1:0712/233521.185292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 538, 7f38e3642881
[1:1:0712/233521.207226:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"532 0x7f38e0cfd070 0x30c2f68a81e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.207554:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"532 0x7f38e0cfd070 0x30c2f68a81e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.207924:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.208562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.208739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.209297:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.209454:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.209800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 541
[1:1:0712/233521.210012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 541 0x7f38e0cfd070 0x30c2f66e8fe0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 538 0x7f38e0cfd070 0x30c2f68c4fe0 
[1:1:0712/233521.211647:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 529, 7f38e3642881
[1:1:0712/233521.233130:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"517 0x7f38e0cfd070 0x30c2f59be460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.233457:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"517 0x7f38e0cfd070 0x30c2f59be460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.233802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.234352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233521.234527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.235275:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.235435:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.235779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 543
[1:1:0712/233521.235985:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 543 0x7f38e0cfd070 0x30c2f5914e60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 529 0x7f38e0cfd070 0x30c2f68ca460 
[1:1:0712/233521.237628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 541, 7f38e3642881
[1:1:0712/233521.258611:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"538 0x7f38e0cfd070 0x30c2f68c4fe0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.258959:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"538 0x7f38e0cfd070 0x30c2f68c4fe0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.259310:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.259947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.260123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.260642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.260795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.261161:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 547
[1:1:0712/233521.261349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 547 0x7f38e0cfd070 0x30c2f5bf74e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 541 0x7f38e0cfd070 0x30c2f66e8fe0 
[1:1:0712/233521.327116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 537, 7f38e3642881
[1:1:0712/233521.348047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"523 0x7f38e0cfd070 0x30c2f59bdd60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.348306:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"523 0x7f38e0cfd070 0x30c2f59bdd60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.348632:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.349174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233521.349350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.350070:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.350281:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.350714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 553
[1:1:0712/233521.351011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 553 0x7f38e0cfd070 0x30c2f59356e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 537 0x7f38e0cfd070 0x30c2f59a2360 
[1:1:0712/233521.353071:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 547, 7f38e3642881
[1:1:0712/233521.371175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"541 0x7f38e0cfd070 0x30c2f66e8fe0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.371497:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"541 0x7f38e0cfd070 0x30c2f66e8fe0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.371844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.372650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.372885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.373576:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.373775:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.374234:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 556
[1:1:0712/233521.374483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 556 0x7f38e0cfd070 0x30c2f68a8ae0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 547 0x7f38e0cfd070 0x30c2f5bf74e0 
[1:1:0712/233521.450131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 543, 7f38e3642881
[1:1:0712/233521.471808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"529 0x7f38e0cfd070 0x30c2f68ca460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.472227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"529 0x7f38e0cfd070 0x30c2f68ca460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.472661:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.473337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233521.473555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.474257:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.474417:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.474766:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 562
[1:1:0712/233521.475012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 562 0x7f38e0cfd070 0x30c2f5a2a7e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 543 0x7f38e0cfd070 0x30c2f5914e60 
[1:1:0712/233521.476657:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 556, 7f38e3642881
[1:1:0712/233521.496719:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"547 0x7f38e0cfd070 0x30c2f5bf74e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.496914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"547 0x7f38e0cfd070 0x30c2f5bf74e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.497140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.497467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.497573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.497816:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.497911:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.498122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 565
[1:1:0712/233521.498231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f38e0cfd070 0x30c2f5419ee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 556 0x7f38e0cfd070 0x30c2f68a8ae0 
[1:1:0712/233521.517959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 553, 7f38e3642881
[1:1:0712/233521.524143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"537 0x7f38e0cfd070 0x30c2f59a2360 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.524289:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"537 0x7f38e0cfd070 0x30c2f59a2360 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.524465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.524768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233521.524871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.525210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.525308:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.525477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 571
[1:1:0712/233521.525586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7f38e0cfd070 0x30c2f5ad7c60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 553 0x7f38e0cfd070 0x30c2f59356e0 
[1:1:0712/233521.526013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 565, 7f38e3642881
[1:1:0712/233521.532235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"556 0x7f38e0cfd070 0x30c2f68a8ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.532361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"556 0x7f38e0cfd070 0x30c2f68a8ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.532515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.532760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.532861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.533116:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.533211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.533362:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 572
[1:1:0712/233521.533465:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 572 0x7f38e0cfd070 0x30c2f5970560 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 565 0x7f38e0cfd070 0x30c2f5419ee0 
[1:1:0712/233521.546815:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 572, 7f38e3642881
[1:1:0712/233521.552945:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"565 0x7f38e0cfd070 0x30c2f5419ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.553098:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"565 0x7f38e0cfd070 0x30c2f5419ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.553277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.553574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.553676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.553911:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.554039:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.554211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 574
[1:1:0712/233521.554316:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f38e0cfd070 0x30c2f68ce2e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 572 0x7f38e0cfd070 0x30c2f5970560 
[1:1:0712/233521.601426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 574, 7f38e3642881
[1:1:0712/233521.623150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"572 0x7f38e0cfd070 0x30c2f5970560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.623445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"572 0x7f38e0cfd070 0x30c2f5970560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.623784:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.624408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.624583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.625138:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.625295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.625638:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 578
[1:1:0712/233521.625823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 578 0x7f38e0cfd070 0x30c2f5941760 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 574 0x7f38e0cfd070 0x30c2f68ce2e0 
[1:1:0712/233521.649239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 562, 7f38e3642881
[1:1:0712/233521.671124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"543 0x7f38e0cfd070 0x30c2f5914e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.671430:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"543 0x7f38e0cfd070 0x30c2f5914e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.671771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.672318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233521.672491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.673174:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.673341:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.673807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 582
[1:1:0712/233521.674010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7f38e0cfd070 0x30c2f5935ae0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 562 0x7f38e0cfd070 0x30c2f5a2a7e0 
[1:1:0712/233521.675340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 571, 7f38e3642881
[1:1:0712/233521.697329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"553 0x7f38e0cfd070 0x30c2f59356e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.697648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"553 0x7f38e0cfd070 0x30c2f59356e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.698004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.698570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233521.698742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.699440:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.699595:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.699938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 583
[1:1:0712/233521.700147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7f38e0cfd070 0x30c2f59361e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 571 0x7f38e0cfd070 0x30c2f5ad7c60 
[1:1:0712/233521.701407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 578, 7f38e3642881
[1:1:0712/233521.719159:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"574 0x7f38e0cfd070 0x30c2f68ce2e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.719371:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"574 0x7f38e0cfd070 0x30c2f68ce2e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.719575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.719889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.720009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.720268:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.720374:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.720552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 584
[1:1:0712/233521.720661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7f38e0cfd070 0x30c2f5b396e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 578 0x7f38e0cfd070 0x30c2f5941760 
[1:1:0712/233521.734942:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 584, 7f38e3642881
[1:1:0712/233521.741405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"578 0x7f38e0cfd070 0x30c2f5941760 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.741574:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"578 0x7f38e0cfd070 0x30c2f5941760 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.741754:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.742105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.742211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.742448:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.742543:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.742713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 586
[1:1:0712/233521.742819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 586 0x7f38e0cfd070 0x30c2f68a81e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 584 0x7f38e0cfd070 0x30c2f5b396e0 
[1:1:0712/233521.754223:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 586, 7f38e3642881
[1:1:0712/233521.760411:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"584 0x7f38e0cfd070 0x30c2f5b396e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.760547:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"584 0x7f38e0cfd070 0x30c2f5b396e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.760721:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.761029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.761136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.761379:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.761472:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.761650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 588
[1:1:0712/233521.761767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7f38e0cfd070 0x30c2f59368e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 586 0x7f38e0cfd070 0x30c2f68a81e0 
[1:1:0712/233521.789686:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 588, 7f38e3642881
[1:1:0712/233521.811632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"586 0x7f38e0cfd070 0x30c2f68a81e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.811932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"586 0x7f38e0cfd070 0x30c2f68a81e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.812317:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.812925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.813130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.813669:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.813827:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.814221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 591
[1:1:0712/233521.814409:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7f38e0cfd070 0x30c2f62e6de0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 588 0x7f38e0cfd070 0x30c2f59368e0 
[1:1:0712/233521.816384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 582, 7f38e3642881
[1:1:0712/233521.838627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"562 0x7f38e0cfd070 0x30c2f5a2a7e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.838970:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"562 0x7f38e0cfd070 0x30c2f5a2a7e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.839356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.839952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233521.840183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.840876:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.841080:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.841474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 593
[1:1:0712/233521.841696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 593 0x7f38e0cfd070 0x30c2f58a49e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 582 0x7f38e0cfd070 0x30c2f5935ae0 
[1:1:0712/233521.843063:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 583, 7f38e3642881
[1:1:0712/233521.865260:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"571 0x7f38e0cfd070 0x30c2f5ad7c60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.865616:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"571 0x7f38e0cfd070 0x30c2f5ad7c60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.865991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.866590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233521.866799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.867513:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.867706:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.868111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 595
[1:1:0712/233521.868337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 595 0x7f38e0cfd070 0x30c2f59be460 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 583 0x7f38e0cfd070 0x30c2f59361e0 
[1:1:0712/233521.869644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 591, 7f38e3642881
[1:1:0712/233521.891981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"588 0x7f38e0cfd070 0x30c2f59368e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.892367:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"588 0x7f38e0cfd070 0x30c2f59368e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.892748:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.893392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.893612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.894225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.894430:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.894842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 596
[1:1:0712/233521.895130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7f38e0cfd070 0x30c2f5956be0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 591 0x7f38e0cfd070 0x30c2f62e6de0 
[1:1:0712/233521.922165:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 596, 7f38e3642881
[1:1:0712/233521.944675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"591 0x7f38e0cfd070 0x30c2f62e6de0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.945007:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"591 0x7f38e0cfd070 0x30c2f62e6de0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.945401:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.946209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.946423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.946979:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.947186:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.947559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 598
[1:1:0712/233521.947776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7f38e0cfd070 0x30c2f68b08e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 596 0x7f38e0cfd070 0x30c2f5956be0 
[1:1:0712/233521.949105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 593, 7f38e3642881
[1:1:0712/233521.960278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"582 0x7f38e0cfd070 0x30c2f5935ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.960598:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"582 0x7f38e0cfd070 0x30c2f5935ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.960967:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.961568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233521.961770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.962484:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.962670:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233521.963051:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 600
[1:1:0712/233521.963283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f38e0cfd070 0x30c2f59351e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 593 0x7f38e0cfd070 0x30c2f58a49e0 
[1:1:0712/233521.964569:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 598, 7f38e3642881
[1:1:0712/233521.987272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"596 0x7f38e0cfd070 0x30c2f5956be0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.987638:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"596 0x7f38e0cfd070 0x30c2f5956be0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233521.988064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233521.988679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233521.988888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233521.989474:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233521.989668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233521.990105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 602
[1:1:0712/233521.990339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f38e0cfd070 0x30c2f59a9560 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 598 0x7f38e0cfd070 0x30c2f68b08e0 
[1:1:0712/233521.991799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 595, 7f38e3642881
[1:1:0712/233522.014882:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"583 0x7f38e0cfd070 0x30c2f59361e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.015233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"583 0x7f38e0cfd070 0x30c2f59361e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.015600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.016185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233522.016388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.017067:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.017256:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.017649:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 604
[1:1:0712/233522.017874:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f38e0cfd070 0x30c2f541a6e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 595 0x7f38e0cfd070 0x30c2f59be460 
[1:1:0712/233522.041651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 602, 7f38e3642881
[1:1:0712/233522.064293:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"598 0x7f38e0cfd070 0x30c2f68b08e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.064652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"598 0x7f38e0cfd070 0x30c2f68b08e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.065050:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.065694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.065909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.066520:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.066738:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.067163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 606
[1:1:0712/233522.067389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f38e0cfd070 0x30c2f68c05e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 602 0x7f38e0cfd070 0x30c2f59a9560 
[1:1:0712/233522.068818:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 600, 7f38e3642881
[1:1:0712/233522.091435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"593 0x7f38e0cfd070 0x30c2f58a49e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.091806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"593 0x7f38e0cfd070 0x30c2f58a49e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.092227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.092848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233522.093058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.093808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.094000:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.094425:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 608
[1:1:0712/233522.094660:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f38e0cfd070 0x30c2f66e82e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 600 0x7f38e0cfd070 0x30c2f59351e0 
[1:1:0712/233522.096110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 606, 7f38e3642881
[1:1:0712/233522.119054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"602 0x7f38e0cfd070 0x30c2f59a9560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.119424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"602 0x7f38e0cfd070 0x30c2f59a9560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.119823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.120504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.120743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.121348:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.121542:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.121928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 611
[1:1:0712/233522.122205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7f38e0cfd070 0x30c2f5924ae0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 606 0x7f38e0cfd070 0x30c2f68c05e0 
[1:1:0712/233522.171021:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 604, 7f38e3642881
[1:1:0712/233522.183417:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"595 0x7f38e0cfd070 0x30c2f59be460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.183761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"595 0x7f38e0cfd070 0x30c2f59be460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.184162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.184795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233522.185001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.185696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.185886:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.186380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 614
[1:1:0712/233522.186624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f38e0cfd070 0x30c2f58fa2e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 604 0x7f38e0cfd070 0x30c2f541a6e0 
[1:1:0712/233522.187907:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 611, 7f38e3642881
[1:1:0712/233522.211068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"606 0x7f38e0cfd070 0x30c2f68c05e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.211460:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"606 0x7f38e0cfd070 0x30c2f68c05e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.211845:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.212514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.212731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.213323:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.213515:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.213899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 615
[1:1:0712/233522.214182:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7f38e0cfd070 0x30c2f59241e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 611 0x7f38e0cfd070 0x30c2f5924ae0 
[1:1:0712/233522.215567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 608, 7f38e3642881
[1:1:0712/233522.238355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"600 0x7f38e0cfd070 0x30c2f59351e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.238696:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"600 0x7f38e0cfd070 0x30c2f59351e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.239075:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.239642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233522.239851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.240570:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.240787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.241332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 617
[1:1:0712/233522.241561:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7f38e0cfd070 0x30c2f59c43e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 608 0x7f38e0cfd070 0x30c2f66e82e0 
[1:1:0712/233522.242964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 615, 7f38e3642881
[1:1:0712/233522.265858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"611 0x7f38e0cfd070 0x30c2f5924ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.266221:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"611 0x7f38e0cfd070 0x30c2f5924ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.266625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.267293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.267502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.268060:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.268284:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.268678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 619
[1:1:0712/233522.268906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f38e0cfd070 0x30c2f68ce2e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 615 0x7f38e0cfd070 0x30c2f59241e0 
[1:1:0712/233522.296225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 619, 7f38e3642881
[1:1:0712/233522.319189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"615 0x7f38e0cfd070 0x30c2f59241e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.319540:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"615 0x7f38e0cfd070 0x30c2f59241e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.319921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.320554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.320767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.321349:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.321543:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.321928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 622
[1:1:0712/233522.322197:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f38e0cfd070 0x30c2f5ad04e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 619 0x7f38e0cfd070 0x30c2f68ce2e0 
[1:1:0712/233522.323556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 614, 7f38e3642881
[1:1:0712/233522.346439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"604 0x7f38e0cfd070 0x30c2f541a6e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.346771:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"604 0x7f38e0cfd070 0x30c2f541a6e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.347161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.347753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233522.347971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.348681:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.348897:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.349307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 623
[1:1:0712/233522.349527:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7f38e0cfd070 0x30c2f68c07e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 614 0x7f38e0cfd070 0x30c2f58fa2e0 
[1:1:0712/233522.350874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 622, 7f38e3642881
[1:1:0712/233522.373940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"619 0x7f38e0cfd070 0x30c2f68ce2e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.374313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"619 0x7f38e0cfd070 0x30c2f68ce2e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.374696:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.375350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.375563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.376123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.376352:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.376743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 626
[1:1:0712/233522.376985:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7f38e0cfd070 0x30c2f5935ae0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 622 0x7f38e0cfd070 0x30c2f5ad04e0 
[1:1:0712/233522.378411:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 617, 7f38e3642881
[1:1:0712/233522.401609:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"608 0x7f38e0cfd070 0x30c2f66e82e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.401972:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"608 0x7f38e0cfd070 0x30c2f66e82e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.402409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.403047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233522.403271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.403965:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.404181:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.404575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 627
[1:1:0712/233522.404811:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f38e0cfd070 0x30c2f68b5560 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 617 0x7f38e0cfd070 0x30c2f59c43e0 
[1:1:0712/233522.414050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 626, 7f38e3642881
[1:1:0712/233522.426832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"622 0x7f38e0cfd070 0x30c2f5ad04e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.427209:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"622 0x7f38e0cfd070 0x30c2f5ad04e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.427594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.428234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.428445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.429005:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.429252:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.429651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 629
[1:1:0712/233522.429877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7f38e0cfd070 0x30c2f5913660 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 626 0x7f38e0cfd070 0x30c2f5935ae0 
[1:1:0712/233522.457963:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 629, 7f38e3642881
[1:1:0712/233522.481290:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"626 0x7f38e0cfd070 0x30c2f5935ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.481666:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"626 0x7f38e0cfd070 0x30c2f5935ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.482074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.482768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.482991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.483657:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.483877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.484343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 632
[1:1:0712/233522.484578:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 632 0x7f38e0cfd070 0x30c2f56fbde0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 629 0x7f38e0cfd070 0x30c2f5913660 
[1:1:0712/233522.485896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 623, 7f38e3642881
[1:1:0712/233522.509466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"614 0x7f38e0cfd070 0x30c2f58fa2e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.509765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"614 0x7f38e0cfd070 0x30c2f58fa2e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.510122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.510699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233522.510907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.511637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.511835:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.512258:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 633
[1:1:0712/233522.512483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f38e0cfd070 0x30c2f66e8460 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 623 0x7f38e0cfd070 0x30c2f68c07e0 
[1:1:0712/233522.514080:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 632, 7f38e3642881
[1:1:0712/233522.537566:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"629 0x7f38e0cfd070 0x30c2f5913660 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.537945:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"629 0x7f38e0cfd070 0x30c2f5913660 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.538382:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.539037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.539273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.539833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.540023:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.540427:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 636
[1:1:0712/233522.540655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7f38e0cfd070 0x30c2f68ceee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 632 0x7f38e0cfd070 0x30c2f56fbde0 
[1:1:0712/233522.541955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 627, 7f38e3642881
[1:1:0712/233522.565369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"617 0x7f38e0cfd070 0x30c2f59c43e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.565724:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"617 0x7f38e0cfd070 0x30c2f59c43e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.566106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.566723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233522.566936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.567698:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.567893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.568300:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 637
[1:1:0712/233522.568527:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f38e0cfd070 0x30c2f5924560 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 627 0x7f38e0cfd070 0x30c2f68b5560 
[1:1:0712/233522.598084:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 636, 7f38e3642881
[1:1:0712/233522.618020:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"632 0x7f38e0cfd070 0x30c2f56fbde0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.618395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"632 0x7f38e0cfd070 0x30c2f56fbde0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.618774:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.619432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.619653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.620235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.620434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.620808:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 639
[1:1:0712/233522.621023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7f38e0cfd070 0x30c2f68b6860 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 636 0x7f38e0cfd070 0x30c2f68ceee0 
[1:1:0712/233522.622353:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 633, 7f38e3642881
[1:1:0712/233522.646806:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"623 0x7f38e0cfd070 0x30c2f68c07e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.647157:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"623 0x7f38e0cfd070 0x30c2f68c07e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.647556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.648125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233522.648352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.649061:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.649267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.649656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 641
[1:1:0712/233522.649879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7f38e0cfd070 0x30c2f66e88e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 633 0x7f38e0cfd070 0x30c2f66e8460 
[1:1:0712/233522.651331:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 639, 7f38e3642881
[1:1:0712/233522.674957:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"636 0x7f38e0cfd070 0x30c2f68ceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.675361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"636 0x7f38e0cfd070 0x30c2f68ceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.675745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.676371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.676598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.677156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.677364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.677749:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 643
[1:1:0712/233522.677971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7f38e0cfd070 0x30c2f59243e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 639 0x7f38e0cfd070 0x30c2f68b6860 
[1:1:0712/233522.679388:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 637, 7f38e3642881
[1:1:0712/233522.706279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"627 0x7f38e0cfd070 0x30c2f68b5560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.706625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"627 0x7f38e0cfd070 0x30c2f68b5560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.707000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.707604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233522.707810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.708522:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.708721:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.709097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 645
[1:1:0712/233522.709336:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 645 0x7f38e0cfd070 0x30c2f68b62e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 637 0x7f38e0cfd070 0x30c2f5924560 
[1:1:0712/233522.734599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 643, 7f38e3642881
[1:1:0712/233522.758119:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"639 0x7f38e0cfd070 0x30c2f68b6860 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.758495:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"639 0x7f38e0cfd070 0x30c2f68b6860 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.758874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.759503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.759722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.760326:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.760519:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.760901:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 647
[1:1:0712/233522.761120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7f38e0cfd070 0x30c2f5ad3460 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 643 0x7f38e0cfd070 0x30c2f59243e0 
[1:1:0712/233522.762547:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 641, 7f38e3642881
[1:1:0712/233522.786341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"633 0x7f38e0cfd070 0x30c2f66e8460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.786703:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"633 0x7f38e0cfd070 0x30c2f66e8460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.787084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.787702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233522.787914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.788623:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.788814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.789197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 649
[1:1:0712/233522.789435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f38e0cfd070 0x30c2f5936960 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 641 0x7f38e0cfd070 0x30c2f66e88e0 
[1:1:0712/233522.790806:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 647, 7f38e3642881
[1:1:0712/233522.814421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"643 0x7f38e0cfd070 0x30c2f59243e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.814870:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"643 0x7f38e0cfd070 0x30c2f59243e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.815279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.815889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.816098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.816687:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.816881:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.817292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 651
[1:1:0712/233522.817542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 651 0x7f38e0cfd070 0x30c2f5970e60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 647 0x7f38e0cfd070 0x30c2f5ad3460 
[1:1:0712/233522.819400:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 645, 7f38e3642881
[1:1:0712/233522.843528:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"637 0x7f38e0cfd070 0x30c2f5924560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.843868:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"637 0x7f38e0cfd070 0x30c2f5924560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.844261:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.844914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233522.845146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.845865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.846060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.846490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 653
[1:1:0712/233522.846717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 653 0x7f38e0cfd070 0x30c2f68c6be0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 645 0x7f38e0cfd070 0x30c2f68b62e0 
[1:1:0712/233522.855968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 651, 7f38e3642881
[1:1:0712/233522.879653:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"647 0x7f38e0cfd070 0x30c2f5ad3460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.879999:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"647 0x7f38e0cfd070 0x30c2f5ad3460 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.880397:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.881010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.881218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.881796:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.881985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.882423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 655
[1:1:0712/233522.882646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7f38e0cfd070 0x30c2f68b6860 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 651 0x7f38e0cfd070 0x30c2f5970e60 
[1:1:0712/233522.911716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 655, 7f38e3642881
[1:1:0712/233522.936757:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"651 0x7f38e0cfd070 0x30c2f5970e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.937134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"651 0x7f38e0cfd070 0x30c2f5970e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.937533:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.938185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.938449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.939008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.939313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.939701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 658
[1:1:0712/233522.939924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7f38e0cfd070 0x30c2f59b23e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 655 0x7f38e0cfd070 0x30c2f68b6860 
[1:1:0712/233522.941213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 649, 7f38e3642881
[1:1:0712/233522.965397:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"641 0x7f38e0cfd070 0x30c2f66e88e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.965804:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"641 0x7f38e0cfd070 0x30c2f66e88e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.966213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.966850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233522.967061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.967798:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.967996:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233522.968523:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 659
[1:1:0712/233522.968768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 659 0x7f38e0cfd070 0x30c2f58e4b60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 649 0x7f38e0cfd070 0x30c2f5936960 
[1:1:0712/233522.970254:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 658, 7f38e3642881
[1:1:0712/233522.994432:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"655 0x7f38e0cfd070 0x30c2f68b6860 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.994784:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"655 0x7f38e0cfd070 0x30c2f68b6860 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233522.995163:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233522.995789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233522.996000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233522.996582:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233522.996774:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233522.997155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 662
[1:1:0712/233522.997396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7f38e0cfd070 0x30c2f5c92ee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 658 0x7f38e0cfd070 0x30c2f59b23e0 
[1:1:0712/233522.998807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 653, 7f38e3642881
[1:1:0712/233523.022927:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"645 0x7f38e0cfd070 0x30c2f68b62e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.023267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"645 0x7f38e0cfd070 0x30c2f68b62e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.023656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.024247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233523.024466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.025152:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.025373:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.025758:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 663
[1:1:0712/233523.025979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f38e0cfd070 0x30c2f59354e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 653 0x7f38e0cfd070 0x30c2f68c6be0 
[1:1:0712/233523.051593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 662, 7f38e3642881
[1:1:0712/233523.075571:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"658 0x7f38e0cfd070 0x30c2f59b23e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.075938:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"658 0x7f38e0cfd070 0x30c2f59b23e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.076337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.076948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.077157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.077733:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.077924:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.078357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 665
[1:1:0712/233523.078583:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7f38e0cfd070 0x30c2f68d1f60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 662 0x7f38e0cfd070 0x30c2f5c92ee0 
[1:1:0712/233523.079954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 659, 7f38e3642881
[1:1:0712/233523.104725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"649 0x7f38e0cfd070 0x30c2f5936960 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.105134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"649 0x7f38e0cfd070 0x30c2f5936960 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.106250:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.106925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233523.107148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.107881:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.108106:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.108523:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 667
[1:1:0712/233523.108766:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f38e0cfd070 0x30c2f66e82e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 659 0x7f38e0cfd070 0x30c2f58e4b60 
[1:1:0712/233523.110196:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 665, 7f38e3642881
[1:1:0712/233523.133903:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"662 0x7f38e0cfd070 0x30c2f5c92ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.134476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"662 0x7f38e0cfd070 0x30c2f5c92ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.134847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.135476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.135685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.136291:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.136509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.136899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 669
[1:1:0712/233523.137124:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f38e0cfd070 0x30c2f59b62e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 665 0x7f38e0cfd070 0x30c2f68d1f60 
[1:1:0712/233523.138560:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 663, 7f38e3642881
[1:1:0712/233523.159271:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"653 0x7f38e0cfd070 0x30c2f68c6be0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.159650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"653 0x7f38e0cfd070 0x30c2f68c6be0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.160064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.160685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233523.160903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.161627:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.161829:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.162212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 671
[1:1:0712/233523.162507:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 671 0x7f38e0cfd070 0x30c2f62e6e60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 663 0x7f38e0cfd070 0x30c2f59354e0 
[1:1:0712/233523.188213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 669, 7f38e3642881
[1:1:0712/233523.202005:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"665 0x7f38e0cfd070 0x30c2f68d1f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.202403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"665 0x7f38e0cfd070 0x30c2f68d1f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.202788:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.203413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.203625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.204185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.204393:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.204780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 673
[1:1:0712/233523.205003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f38e0cfd070 0x30c2f61ee660 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 669 0x7f38e0cfd070 0x30c2f59b62e0 
[1:1:0712/233523.225590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 667, 7f38e3642881
[1:1:0712/233523.249744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"659 0x7f38e0cfd070 0x30c2f58e4b60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.250089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"659 0x7f38e0cfd070 0x30c2f58e4b60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.250519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.251085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233523.251293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.252001:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.252189:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.252600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 676
[1:1:0712/233523.252858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f38e0cfd070 0x30c2f5931ee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 667 0x7f38e0cfd070 0x30c2f66e82e0 
[1:1:0712/233523.254182:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 673, 7f38e3642881
[1:1:0712/233523.279033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"669 0x7f38e0cfd070 0x30c2f59b62e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.279422:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"669 0x7f38e0cfd070 0x30c2f59b62e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.279812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.280449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.280660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.281220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.281440:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.281835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 677
[1:1:0712/233523.282064:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7f38e0cfd070 0x30c2f59c43e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 673 0x7f38e0cfd070 0x30c2f61ee660 
[1:1:0712/233523.283498:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 671, 7f38e3642881
[1:1:0712/233523.302693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"663 0x7f38e0cfd070 0x30c2f59354e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.303009:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"663 0x7f38e0cfd070 0x30c2f59354e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.303393:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.303986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233523.304194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.304948:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.305142:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.305546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 679
[1:1:0712/233523.305769:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f38e0cfd070 0x30c2f5878a60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 671 0x7f38e0cfd070 0x30c2f62e6e60 
[1:1:0712/233523.307141:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 677, 7f38e3642881
[1:1:0712/233523.331491:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"673 0x7f38e0cfd070 0x30c2f61ee660 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.331817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"673 0x7f38e0cfd070 0x30c2f61ee660 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.332190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.332797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.333007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.333583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.333778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.334158:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 681
[1:1:0712/233523.334453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f38e0cfd070 0x30c2f68ceee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 677 0x7f38e0cfd070 0x30c2f59c43e0 
[1:1:0712/233523.363622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 681, 7f38e3642881
[1:1:0712/233523.386441:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"677 0x7f38e0cfd070 0x30c2f59c43e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.386849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"677 0x7f38e0cfd070 0x30c2f59c43e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.387251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.387934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.388165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.388766:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.388982:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.389422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 684
[1:1:0712/233523.389653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7f38e0cfd070 0x30c2f68b26e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 681 0x7f38e0cfd070 0x30c2f68ceee0 
[1:1:0712/233523.391050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 676, 7f38e3642881
[1:1:0712/233523.416191:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"667 0x7f38e0cfd070 0x30c2f66e82e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.416576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"667 0x7f38e0cfd070 0x30c2f66e82e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.416966:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.417549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233523.417758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.418518:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.418713:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.419109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 685
[1:1:0712/233523.419337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7f38e0cfd070 0x30c2f59243e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 676 0x7f38e0cfd070 0x30c2f5931ee0 
[1:1:0712/233523.420766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 684, 7f38e3642881
[1:1:0712/233523.445200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"681 0x7f38e0cfd070 0x30c2f68ceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.445573:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"681 0x7f38e0cfd070 0x30c2f68ceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.445955:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.446659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.446872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.447451:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.447653:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.448042:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 688
[1:1:0712/233523.448272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7f38e0cfd070 0x30c2f5935a60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 684 0x7f38e0cfd070 0x30c2f68b26e0 
[1:1:0712/233523.449606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 679, 7f38e3642881
[1:1:0712/233523.474125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"671 0x7f38e0cfd070 0x30c2f62e6e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.474500:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"671 0x7f38e0cfd070 0x30c2f62e6e60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.474882:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.475459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233523.475677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.476395:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.476611:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.476991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 689
[1:1:0712/233523.477212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f38e0cfd070 0x30c2f5c92ee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 679 0x7f38e0cfd070 0x30c2f5878a60 
[1:1:0712/233523.503770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 688, 7f38e3642881
[1:1:0712/233523.528462:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"684 0x7f38e0cfd070 0x30c2f68b26e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.528831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"684 0x7f38e0cfd070 0x30c2f68b26e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.529265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.529977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.530218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.530809:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.531002:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.531385:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 691
[1:1:0712/233523.531616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f38e0cfd070 0x30c2f68c0760 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 688 0x7f38e0cfd070 0x30c2f5935a60 
[1:1:0712/233523.532987:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 685, 7f38e3642881
[1:1:0712/233523.547652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"676 0x7f38e0cfd070 0x30c2f5931ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.547983:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"676 0x7f38e0cfd070 0x30c2f5931ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.548356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.548956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233523.549163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.549869:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.550060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.550485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 693
[1:1:0712/233523.550712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f38e0cfd070 0x30c2f68d1060 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 685 0x7f38e0cfd070 0x30c2f59243e0 
[1:1:0712/233523.552073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 691, 7f38e3642881
[1:1:0712/233523.576661:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"688 0x7f38e0cfd070 0x30c2f5935a60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.577017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"688 0x7f38e0cfd070 0x30c2f5935a60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.577396:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.578052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.578310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.578879:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.579070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.579468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 695
[1:1:0712/233523.579700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f38e0cfd070 0x30c2f68caf60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 691 0x7f38e0cfd070 0x30c2f68c0760 
[1:1:0712/233523.581039:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 689, 7f38e3642881
[1:1:0712/233523.607615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"679 0x7f38e0cfd070 0x30c2f5878a60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.608029:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"679 0x7f38e0cfd070 0x30c2f5878a60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.608412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.609003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233523.609210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.609925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.610147:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.610551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 697
[1:1:0712/233523.610779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7f38e0cfd070 0x30c2f56fb260 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 689 0x7f38e0cfd070 0x30c2f5c92ee0 
[1:1:0712/233523.637202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 695, 7f38e3642881
[1:1:0712/233523.662167:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"691 0x7f38e0cfd070 0x30c2f68c0760 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.662553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"691 0x7f38e0cfd070 0x30c2f68c0760 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.662940:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.663605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.663828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.664385:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.664606:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.665106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 699
[1:1:0712/233523.665334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f38e0cfd070 0x30c2f68b26e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 695 0x7f38e0cfd070 0x30c2f68caf60 
[1:1:0712/233523.666733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 693, 7f38e3642881
[1:1:0712/233523.691579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"685 0x7f38e0cfd070 0x30c2f59243e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.691927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"685 0x7f38e0cfd070 0x30c2f59243e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.692351:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.692937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233523.693183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.694046:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.694290:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.694725:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 701
[1:1:0712/233523.694947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f38e0cfd070 0x30c2f5c55360 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 693 0x7f38e0cfd070 0x30c2f68d1060 
[1:1:0712/233523.696310:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 699, 7f38e3642881
[1:1:0712/233523.721186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"695 0x7f38e0cfd070 0x30c2f68caf60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.721568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"695 0x7f38e0cfd070 0x30c2f68caf60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.721961:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.722666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.722897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.723571:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.723795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.724190:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 703
[1:1:0712/233523.724417:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7f38e0cfd070 0x30c2f66e8ae0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 699 0x7f38e0cfd070 0x30c2f68b26e0 
[1:1:0712/233523.725904:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 697, 7f38e3642881
[1:1:0712/233523.750854:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"689 0x7f38e0cfd070 0x30c2f5c92ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.751160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"689 0x7f38e0cfd070 0x30c2f5c92ee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.751538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.752083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233523.752297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.753029:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.753223:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.753617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 705
[1:1:0712/233523.753840:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7f38e0cfd070 0x30c2f68ceee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 697 0x7f38e0cfd070 0x30c2f56fb260 
[1:1:0712/233523.780364:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 703, 7f38e3642881
[1:1:0712/233523.806710:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"699 0x7f38e0cfd070 0x30c2f68b26e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.807073:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"699 0x7f38e0cfd070 0x30c2f68b26e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.807460:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.808116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.808343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.808957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.809363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.809817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 707
[1:1:0712/233523.810087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f38e0cfd070 0x30c2f68d1f60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 703 0x7f38e0cfd070 0x30c2f66e8ae0 
[1:1:0712/233523.812092:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 701, 7f38e3642881
[1:1:0712/233523.824611:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"693 0x7f38e0cfd070 0x30c2f68d1060 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.824931:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"693 0x7f38e0cfd070 0x30c2f68d1060 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.825306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.825911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233523.826160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.826867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.827066:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.827448:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 709
[1:1:0712/233523.827682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f38e0cfd070 0x30c2f548f1e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 701 0x7f38e0cfd070 0x30c2f5c55360 
[1:1:0712/233523.829011:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 707, 7f38e3642881
[1:1:0712/233523.853982:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"703 0x7f38e0cfd070 0x30c2f66e8ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.854338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"703 0x7f38e0cfd070 0x30c2f66e8ae0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.854735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.855339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.855565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.856137:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.856326:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.856728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 711
[1:1:0712/233523.856953:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f38e0cfd070 0x30c2f5bfa860 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 707 0x7f38e0cfd070 0x30c2f68d1f60 
[1:1:0712/233523.858326:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 705, 7f38e3642881
[1:1:0712/233523.880126:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"697 0x7f38e0cfd070 0x30c2f56fb260 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.880472:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"697 0x7f38e0cfd070 0x30c2f56fb260 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.880852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.881440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233523.881668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.882360:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.882602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.882982:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 713
[1:1:0712/233523.883267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f38e0cfd070 0x30c2f62dcce0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 705 0x7f38e0cfd070 0x30c2f68ceee0 
[1:1:0712/233523.921049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 711, 7f38e3642881
[1:1:0712/233523.929565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"707 0x7f38e0cfd070 0x30c2f68d1f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.929854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"707 0x7f38e0cfd070 0x30c2f68d1f60 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.930206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.930829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.931038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.931695:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.931901:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.932286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 715
[1:1:0712/233523.932529:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f38e0cfd070 0x30c2f59b4560 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 711 0x7f38e0cfd070 0x30c2f5bfa860 
[1:1:0712/233523.933921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 709, 7f38e3642881
[1:1:0712/233523.959168:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"701 0x7f38e0cfd070 0x30c2f5c55360 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.959500:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"701 0x7f38e0cfd070 0x30c2f5c55360 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.959896:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.960498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233523.960724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.961416:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.961621:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233523.962005:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 717
[1:1:0712/233523.962262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7f38e0cfd070 0x30c2f5936d60 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 709 0x7f38e0cfd070 0x30c2f548f1e0 
[1:1:0712/233523.963678:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 715, 7f38e3642881
[1:1:0712/233523.989334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"711 0x7f38e0cfd070 0x30c2f5bfa860 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.989702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"711 0x7f38e0cfd070 0x30c2f5bfa860 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233523.990097:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233523.990785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233523.990996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233523.991599:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233523.991791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233523.992175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 719
[1:1:0712/233523.992398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f38e0cfd070 0x30c2f68afee0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 715 0x7f38e0cfd070 0x30c2f59b4560 
[1:1:0712/233523.993792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 713, 7f38e3642881
[1:1:0712/233524.012786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"705 0x7f38e0cfd070 0x30c2f68ceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.013162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"705 0x7f38e0cfd070 0x30c2f68ceee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.013559:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233524.014175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233524.014404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233524.015114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233524.015303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233524.015704:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 721
[1:1:0712/233524.015930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7f38e0cfd070 0x30c2f58b7fe0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 713 0x7f38e0cfd070 0x30c2f62dcce0 
[1:1:0712/233524.042802:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 719, 7f38e3642881
[1:1:0712/233524.068397:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"715 0x7f38e0cfd070 0x30c2f59b4560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.068789:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"715 0x7f38e0cfd070 0x30c2f59b4560 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.069179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233524.069813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233524.070024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233524.070665:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233524.070859:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233524.071244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 723
[1:1:0712/233524.071467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7f38e0cfd070 0x30c2f5c928e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 719 0x7f38e0cfd070 0x30c2f68afee0 
[1:1:0712/233524.072866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 717, 7f38e3642881
[1:1:0712/233524.098458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"709 0x7f38e0cfd070 0x30c2f548f1e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.098846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"709 0x7f38e0cfd070 0x30c2f548f1e0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.099235:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233524.099873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0712/233524.100085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233524.100814:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233524.101007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233524.101389:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 725
[1:1:0712/233524.101645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f38e0cfd070 0x30c2f68b6460 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 717 0x7f38e0cfd070 0x30c2f5936d60 
[1:1:0712/233524.103049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 723, 7f38e3642881
[1:1:0712/233524.117047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"719 0x7f38e0cfd070 0x30c2f68afee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.117365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"719 0x7f38e0cfd070 0x30c2f68afee0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.117751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233524.118337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , PvTrack.track, (){if(E){if(K()&&F&&S()){var a=v+"?v=3.6",c="&p1="+f.p1+"&p2="+f.p2+"&p3="+f.p3+"&p4="+f.p4+"&p5="+f
[1:1:0712/233524.118589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233524.119156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233524.119347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 0
[1:1:0712/233524.119747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 727
[1:1:0712/233524.119974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f38e0cfd070 0x30c2f59367e0 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 723 0x7f38e0cfd070 0x30c2f5c928e0 
[1:1:0712/233524.121310:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 721, 7f38e3642881
[1:1:0712/233524.146853:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b502d8e2860","ptid":"713 0x7f38e0cfd070 0x30c2f62dcce0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.147195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wenku.it168.com/","ptid":"713 0x7f38e0cfd070 0x30c2f62dcce0 ","rf":"5:3_http://wenku.it168.com/"}
[1:1:0712/233524.147584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wenku.it168.com/wenji/2743"
[1:1:0712/233524.148148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wenku.it168.com/, 2b502d8e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/233524.148360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wenku.it168.com/wenji/2743", "wenku.it168.com", 3, 1, , , 0
[1:1:0712/233524.149078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x8ba10e29c8, 0x30c2f5437150
[1:1:0712/233524.149271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wenku.it168.com/wenji/2743", 100
[1:1:0712/233524.149705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 729
[1:1:0712/233524.149934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f38e0cfd070 0x30c2f5936960 , 5:3_http://wenku.it168.com/, 1, -5:3_http://wenku.it168.com/, 721 0x7f38e0cfd070 0x30c2f58b7fe0 
[1:1:0100/000000.179271:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wenku.it168.com/, 727, 7f38e3642881
