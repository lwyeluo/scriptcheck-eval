[0711/203638.857778:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/203638.858176:INFO:switcher_clone.cc(787)] backtrace rip is 7f8a9a1cb891
[0711/203639.829418:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/203639.829685:INFO:switcher_clone.cc(787)] backtrace rip is 7ff88a795891
[1:1:0711/203639.837755:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/203639.838076:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/203639.843452:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[12282:12282:0711/203640.881588:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/466be336-4b8d-4944-bb5a-656906e62000
[0711/203641.206306:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/203641.206722:INFO:switcher_clone.cc(787)] backtrace rip is 7f48b7042891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[12313:12313:0711/203641.385404:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=12313
[12325:12325:0711/203641.385878:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=12325
[12282:12282:0711/203641.558936:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[12282:12311:0711/203641.559861:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/203641.560122:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/203641.560332:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/203641.560943:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/203641.561086:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/203641.563984:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x104bd74b, 1
[1:1:0711/203641.564286:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x845c3d8, 0
[1:1:0711/203641.564457:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1e9c8804, 3
[1:1:0711/203641.564684:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x160fe1fc, 2
[1:1:0711/203641.564875:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd8ffffffc34508 4bffffffd74b10 fffffffcffffffe10f16 04ffffff88ffffff9c1e , 10104, 4
[1:1:0711/203641.565836:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12282:12311:0711/203641.566026:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��EK�K�������:
[12282:12311:0711/203641.566093:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��EK�K����x����:
[1:1:0711/203641.566205:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff8889d00a0, 3
[12282:12311:0711/203641.566365:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[12282:12311:0711/203641.566455:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 12333, 4, d8c34508 4bd74b10 fce10f16 04889c1e 
[1:1:0711/203641.566418:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff888b5b080, 2
[1:1:0711/203641.566639:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff87281ed20, -2
[1:1:0711/203641.586171:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/203641.586748:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 160fe1fc
[1:1:0711/203641.587369:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 160fe1fc
[1:1:0711/203641.588334:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 160fe1fc
[1:1:0711/203641.588905:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.589021:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.589116:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.589215:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.589439:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 160fe1fc
[1:1:0711/203641.589572:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff88a7957ba
[1:1:0711/203641.589681:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff88a78cdef, 7ff88a79577a, 7ff88a7970cf
[1:1:0711/203641.591082:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 160fe1fc
[1:1:0711/203641.591235:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 160fe1fc
[1:1:0711/203641.591506:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 160fe1fc
[1:1:0711/203641.592196:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.592305:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.592400:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.592495:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fe1fc
[1:1:0711/203641.592978:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 160fe1fc
[1:1:0711/203641.593137:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff88a7957ba
[1:1:0711/203641.593220:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff88a78cdef, 7ff88a79577a, 7ff88a7970cf
[1:1:0711/203641.595373:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/203641.595645:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/203641.595740:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe3785be38, 0x7ffe3785bdb8)
[1:1:0711/203641.610514:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/203641.618447:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[12282:12282:0711/203642.277406:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12282:12282:0711/203642.278867:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12282:12292:0711/203642.296096:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[12282:12292:0711/203642.296231:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[12282:12282:0711/203642.296405:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[12282:12282:0711/203642.296511:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[12282:12282:0711/203642.296707:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,12333, 4
[1:7:0711/203642.298715:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[12282:12303:0711/203642.323115:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/203642.387867:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1558ff04b220
[1:1:0711/203642.388213:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/203642.770354:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[12282:12282:0711/203644.498700:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[12282:12282:0711/203644.498855:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/203644.555169:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/203644.559191:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/203645.523996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e5d63c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/203645.524356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/203645.559283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e5d63c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/203645.559556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/203645.602478:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/203645.890091:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203645.890325:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/203646.222183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/203646.230295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e5d63c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/203646.230532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/203646.265874:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/203646.278511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e5d63c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/203646.278812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/203646.293008:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[12282:12282:0711/203646.295919:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/203646.297362:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1558ff049e20
[1:1:0711/203646.297559:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[12282:12282:0711/203646.304123:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[12282:12282:0711/203646.365874:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[12282:12282:0711/203646.366033:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/203646.416194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/203647.185532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7ff8743f92e0 0x1558ff1e4ae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/203647.186806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e5d63c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/203647.187003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/203647.188371:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[12282:12282:0711/203647.251037:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/203647.253368:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1558ff04a820
[1:1:0711/203647.253616:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[12282:12282:0711/203647.261700:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/203647.276504:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/203647.276747:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[12282:12282:0711/203647.284679:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[12282:12282:0711/203647.299369:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12282:12282:0711/203647.300630:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12282:12292:0711/203647.306723:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[12282:12292:0711/203647.306809:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[12282:12282:0711/203647.306964:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[12282:12282:0711/203647.307039:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[12282:12282:0711/203647.307174:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,12333, 4
[1:7:0711/203647.310548:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/203647.954700:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/203648.236750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7ff8743f92e0 0x1558ff2b4be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/203648.237779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e5d63c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/203648.238036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/203648.238785:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[12282:12282:0711/203648.282313:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[12282:12282:0711/203648.282426:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/203648.312809:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/203648.812754:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[12282:12282:0711/203649.007986:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[12282:12311:0711/203649.008482:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/203649.008752:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/203649.008986:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/203649.009408:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/203649.009574:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/203649.012619:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36a57c19, 1
[1:1:0711/203649.012954:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e4b03f9, 0
[1:1:0711/203649.013099:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1e13f2a7, 3
[1:1:0711/203649.013237:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x28efd904, 2
[1:1:0711/203649.013406:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff9034b2e 197cffffffa536 04ffffffd9ffffffef28 ffffffa7fffffff2131e , 10104, 5
[1:1:0711/203649.014344:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12282:12311:0711/203649.014559:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�K.|�6��(����:
[12282:12311:0711/203649.014624:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �K.|�6��(������:
[1:1:0711/203649.014733:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff8889d00a0, 3
[12282:12311:0711/203649.014879:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 12378, 5, f9034b2e 197ca536 04d9ef28 a7f2131e 
[1:1:0711/203649.014924:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff888b5b080, 2
[1:1:0711/203649.015100:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff87281ed20, -2
[1:1:0711/203649.039193:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/203649.039554:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 28efd904
[1:1:0711/203649.039853:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 28efd904
[1:1:0711/203649.040532:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 28efd904
[1:1:0711/203649.041920:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.042102:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.042292:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.042473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.043124:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 28efd904
[1:1:0711/203649.043444:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff88a7957ba
[1:1:0711/203649.043582:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff88a78cdef, 7ff88a79577a, 7ff88a7970cf
[1:1:0711/203649.049250:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 28efd904
[1:1:0711/203649.049613:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 28efd904
[1:1:0711/203649.050340:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 28efd904
[1:1:0711/203649.052362:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.052581:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.052763:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.052952:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28efd904
[1:1:0711/203649.054183:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 28efd904
[1:1:0711/203649.054562:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff88a7957ba
[1:1:0711/203649.054716:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff88a78cdef, 7ff88a79577a, 7ff88a7970cf
[1:1:0711/203649.063763:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/203649.064405:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/203649.064597:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe3785be38, 0x7ffe3785bdb8)
[1:1:0711/203649.083036:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/203649.086463:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/203649.254088:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1558ff01e220
[1:1:0711/203649.254274:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/203649.263185:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203649.263423:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[12282:12282:0711/203649.548572:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12282:12282:0711/203649.555080:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12282:12292:0711/203649.586053:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[12282:12292:0711/203649.586156:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[12282:12282:0711/203649.586839:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.xuexila.com/
[12282:12282:0711/203649.586998:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.xuexila.com/, http://www.xuexila.com/, 1
[12282:12282:0711/203649.587130:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.xuexila.com/, HTTP/1.1 200 OK Server: Tengine Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Wed, 10 Jul 2019 07:07:15 GMT ETag: W/"f85db91aee36d51:0" X-Powered-By: ASP.NET Date: Thu, 11 Jul 2019 06:25:40 GMT Ali-Swift-Global-Savetime: 1562826341 Via: cache13.l2nu20-3[0,200-0,H], cache40.l2nu20-3[0,0], kunlun1.cn1478[0,200-0,H], kunlun10.cn1478[1,0] Age: 76269 X-Cache: HIT TCP_MEM_HIT dirn:0:480529620 X-Swift-SaveTime: Thu, 11 Jul 2019 06:36:40 GMT X-Swift-CacheTime: 345600 Timing-Allow-Origin: * EagleId: 70366c1e15629026094964977e Content-Encoding: gzip  ,12378, 5
[1:7:0711/203649.591166:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/203649.637165:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.xuexila.com/
[1:1:0711/203649.762280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/203649.765121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19e5d64f09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/203649.765417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[12282:12282:0711/203649.769694:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.xuexila.com/, http://www.xuexila.com/, 1
[12282:12282:0711/203649.769812:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.xuexila.com/, http://www.xuexila.com
[1:1:0711/203649.773182:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/203649.830443:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/203649.887482:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/203650.035577:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203650.035762:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.xuexila.com/"
[1:1:0711/203650.219353:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/203650.220281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 19e5d63c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/203650.220502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/203650.235539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 140, "http://www.xuexila.com/"
[1:1:0711/203650.236423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , function uaredirect(f){try{if(document.getElementById("bdmark")!=null){return}var b=false;if(argumen
[1:1:0711/203650.236538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203650.239071:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 140, "http://www.xuexila.com/"
[1:1:0711/203650.463756:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7ff888b5b080 0x1558ff19a1a0 1 0 0x1558ff19a1b8 , "http://www.xuexila.com/"
[1:1:0711/203650.500865:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/203650.504063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , /*! jQuery v1.10.2 | (c) 2005, 2013 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingUR
[1:1:0711/203650.504206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/203650.804843:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7ff888b5b080 0x1558ff19a1a0 1 0 0x1558ff19a1b8 , "http://www.xuexila.com/"
[1:1:0711/203650.810209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7ff888b5b080 0x1558ff19a1a0 1 0 0x1558ff19a1b8 , "http://www.xuexila.com/"
[1:1:0711/203650.818494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7ff888b5b080 0x1558ff19a1a0 1 0 0x1558ff19a1b8 , "http://www.xuexila.com/"
[1:1:0711/203650.843302:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.04142, 87, 1
[1:1:0711/203650.843510:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/203651.115790:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203651.116022:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.xuexila.com/"
[1:1:0711/203651.116918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 191 0x7ff8724d1070 0x1558ff305860 , "http://www.xuexila.com/"
[1:1:0711/203651.117805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , f_links("title");
[1:1:0711/203651.118016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203651.268755:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.152637, 1386, 1
[1:1:0711/203651.269020:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/203651.712571:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/203651.713166:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/203651.713650:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/203651.714129:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/203651.714602:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/203651.892527:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203651.892796:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.xuexila.com/"
[1:1:0711/203651.893611:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7ff8724d1070 0x1558ff2636e0 , "http://www.xuexila.com/"
[1:1:0711/203651.894443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , f_links("conten");
[1:1:0711/203651.894650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203651.957595:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.064749, 724, 1
[1:1:0711/203651.957895:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/203652.140966:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 249 0x7ff8743f92e0 0x1558ff126060 , "http://www.xuexila.com/"
[1:1:0711/203652.142227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0711/203652.142482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203652.660971:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203652.661263:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.xuexila.com/"
[1:1:0711/203652.662207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7ff8724d1070 0x1558ff246060 , "http://www.xuexila.com/"
[1:1:0711/203652.663085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , f_links("foot");
[1:1:0711/203652.663299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203652.696026:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0347252, 197, 1
[1:1:0711/203652.696333:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/203653.108832:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203653.109104:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.xuexila.com/"
[1:1:0711/203653.117088:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7ff8724d1070 0x1558ff2e8160 , "http://www.xuexila.com/"
[1:1:0711/203653.118547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , var IMYUAN;IMYUAN||(IMYUAN={});(function(a){a.fn.extend({returntop:function(){if(this[0]){var b=this
[1:1:0711/203653.118798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203653.135985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7ff8724d1070 0x1558ff2e8160 , "http://www.xuexila.com/"
[1:1:0711/203653.141367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7ff8724d1070 0x1558ff2e8160 , "http://www.xuexila.com/"
[1:1:0711/203653.425899:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338, "http://www.xuexila.com/"
[1:1:0711/203653.433817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , (function(){function p(){this.c="1254123450";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0711/203653.434070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203653.792621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "http://www.xuexila.com/"
[1:1:0711/203653.796217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0711/203653.796542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203656.527796:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361 0x7ff8743f92e0 0x1558ff2e8360 , "http://www.xuexila.com/"
[1:1:0711/203656.554401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , (function(){var h={},mt={},c={id:"21dde1905f8a020144845db642076ab0",dm:["xuexila.com","mip-xuexila-c
[1:1:0711/203656.554715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203656.583325:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca190
[1:1:0711/203656.583597:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203656.584054:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 391
[1:1:0711/203656.584292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 391 0x7ff8724d1070 0x1558ff6f4de0 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 361 0x7ff8743f92e0 0x1558ff2e8360 
[12282:12282:0711/203701.744395:INFO:CONSOLE(2)] "Uncaught TypeError: a(...) is not a function", source: http://js.xuexila.com/xuexila/top.js (2)
[12282:12282:0711/203702.205813:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s95.cnzz.com/z_stat.php?id=1254123450&web_id=1254123450, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.xuexila.com/tongji.js (1)
[12282:12282:0711/203702.209822:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s95.cnzz.com/z_stat.php?id=1254123450&web_id=1254123450, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.xuexila.com/tongji.js (1)
[12282:12282:0711/203702.226254:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1254123450&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/z_stat.php?id=1254123450&web_id=1254123450 (17)
[12282:12282:0711/203702.230304:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1254123450&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/z_stat.php?id=1254123450&web_id=1254123450 (17)
[3:3:0711/203702.266438:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/203702.370912:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 600000
[1:1:0711/203702.371383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.xuexila.com/, 436
[1:1:0711/203702.371619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7ff8724d1070 0x1558ff49e260 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 361 0x7ff8743f92e0 0x1558ff2e8360 
[1:1:0711/203702.372748:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 5000
[1:1:0711/203702.373200:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.xuexila.com/, 437
[1:1:0711/203702.373440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 437 0x7ff8724d1070 0x1558ffa1dbe0 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 361 0x7ff8743f92e0 0x1558ff2e8360 
[1:1:0711/203702.837813:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/203703.090853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/203703.091166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[12282:12282:0711/203703.343423:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/203704.356141:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 391, 7ff874e16881
[1:1:0711/203704.380513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"361 0x7ff8743f92e0 0x1558ff2e8360 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203704.380882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"361 0x7ff8743f92e0 0x1558ff2e8360 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203704.381253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203704.381872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203704.382143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203704.382976:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203704.383197:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203704.383576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 481
[1:1:0711/203704.383812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7ff8724d1070 0x1558ff6f6860 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 391 0x7ff8724d1070 0x1558ff6f4de0 
[1:1:0711/203704.422078:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.xuexila.com/"
[1:1:0711/203704.422895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0711/203704.423146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203704.632116:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/203704.632395:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.xuexila.com/"
[1:1:0711/203704.633616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7ff8724d1070 0x1558ff2ea860 , "http://www.xuexila.com/"
[1:1:0711/203704.637129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.xuexila.com/"
[1:1:0711/203704.637776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , q, (e){(a.addEventListener||"load"===e.type||"complete"===a.readyState)&&(_(),x.ready())}
[1:1:0711/203704.638030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[12282:12282:0711/203704.639295:INFO:CONSOLE(728)] "Uncaught SyntaxError: missing ) after argument list", source: http://www.xuexila.com/ (728)
[1:1:0711/203704.717618:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.xuexila.com/"
[1:1:0711/203704.829285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , document.readyState
[1:1:0711/203704.829610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203705.945899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 481, 7ff874e16881
[1:1:0711/203705.972208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"391 0x7ff8724d1070 0x1558ff6f4de0 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203705.972690:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"391 0x7ff8724d1070 0x1558ff6f4de0 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203705.973041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203705.973815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203705.974119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203705.975350:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203705.975667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203705.976351:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 532
[1:1:0711/203705.976790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7ff8724d1070 0x1558ffc39560 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 481 0x7ff8724d1070 0x1558ff6f6860 
[1:1:0711/203706.033702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , document.readyState
[1:1:0711/203706.034032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203707.147004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.xuexila.com/"
[1:1:0711/203707.147780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0711/203707.148076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203707.157579:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.xuexila.com/"
[1:1:0711/203707.160575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.xuexila.com/"
[1:1:0711/203707.161883:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca2f0
[1:1:0711/203707.162053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203707.162456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 561
[1:1:0711/203707.162643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7ff8724d1070 0x1558ff2c1860 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 528 0x7ff8724d1070 0x1558ffc39060 
[1:1:0711/203707.242007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , , document.readyState
[1:1:0711/203707.242179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203708.002449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 561, 7ff874e16881
[1:1:0711/203708.034993:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"528 0x7ff8724d1070 0x1558ffc39060 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203708.035431:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"528 0x7ff8724d1070 0x1558ffc39060 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203708.035792:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203708.036484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203708.036728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203708.037542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203708.037744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203708.038172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 601
[1:1:0711/203708.038462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 601 0x7ff8724d1070 0x1558ff099d60 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 561 0x7ff8724d1070 0x1558ff2c1860 
[1:1:0711/203708.154806:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.xuexila.com/, 437, 7ff874e168db
[1:1:0711/203708.162812:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"361 0x7ff8743f92e0 0x1558ff2e8360 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203708.162948:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"361 0x7ff8743f92e0 0x1558ff2e8360 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203708.163106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.xuexila.com/, 608
[1:1:0711/203708.163239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7ff8724d1070 0x1558ff02eee0 , 5:3_http://www.xuexila.com/, 0, , 437 0x7ff8724d1070 0x1558ffa1dbe0 
[1:1:0711/203708.163393:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203708.163662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/203708.163764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203708.625892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 601, 7ff874e16881
[1:1:0711/203708.636102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"561 0x7ff8724d1070 0x1558ff2c1860 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203708.636329:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"561 0x7ff8724d1070 0x1558ff2c1860 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203708.637834:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203708.638429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203708.638606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203708.639298:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203708.639498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203708.639829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 631
[1:1:0711/203708.640017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7ff8724d1070 0x1558ff13cd60 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 601 0x7ff8724d1070 0x1558ff099d60 
[1:1:0711/203709.055241:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 631, 7ff874e16881
[1:1:0711/203709.082392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"601 0x7ff8724d1070 0x1558ff099d60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203709.082737:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"601 0x7ff8724d1070 0x1558ff099d60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203709.083017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203709.083543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203709.083719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203709.084346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203709.084500:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203709.084866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 654
[1:1:0711/203709.085052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7ff8724d1070 0x1558ffc4e260 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 631 0x7ff8724d1070 0x1558ff13cd60 
[1:1:0711/203709.431610:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 654, 7ff874e16881
[1:1:0711/203709.440340:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"631 0x7ff8724d1070 0x1558ff13cd60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203709.440542:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"631 0x7ff8724d1070 0x1558ff13cd60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203709.440782:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203709.441109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203709.441212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203709.441503:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203709.441598:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203709.441903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 675
[1:1:0711/203709.442092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7ff8724d1070 0x1558ffb344e0 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 654 0x7ff8724d1070 0x1558ffc4e260 
[1:1:0711/203709.824025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 675, 7ff874e16881
[1:1:0711/203709.852609:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"654 0x7ff8724d1070 0x1558ffc4e260 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203709.852978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"654 0x7ff8724d1070 0x1558ffc4e260 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203709.853265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203709.853776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203709.853971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203709.854601:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203709.854780:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203709.855129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 699
[1:1:0711/203709.855315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7ff8724d1070 0x1558ff0b3e60 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 675 0x7ff8724d1070 0x1558ffb344e0 
[1:1:0711/203710.236478:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 699, 7ff874e16881
[1:1:0711/203710.269144:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"675 0x7ff8724d1070 0x1558ffb344e0 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.269458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"675 0x7ff8724d1070 0x1558ffb344e0 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.269736:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203710.270291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203710.270466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203710.271131:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203710.271287:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203710.271617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 716
[1:1:0711/203710.271816:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 716 0x7ff8724d1070 0x1558ff03eb60 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 699 0x7ff8724d1070 0x1558ff0b3e60 
[1:1:0711/203710.376667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 716, 7ff874e16881
[1:1:0711/203710.411772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"699 0x7ff8724d1070 0x1558ff0b3e60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.412156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"699 0x7ff8724d1070 0x1558ff0b3e60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.412511:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203710.413208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203710.413428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203710.414232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203710.414427:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203710.414825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 721
[1:1:0711/203710.415082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7ff8724d1070 0x155900379360 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 716 0x7ff8724d1070 0x1558ff03eb60 
[1:1:0711/203710.635551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 721, 7ff874e16881
[1:1:0711/203710.644576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"716 0x7ff8724d1070 0x1558ff03eb60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.644767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"716 0x7ff8724d1070 0x1558ff03eb60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.644930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203710.645241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203710.645344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203710.645634:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203710.645729:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203710.645894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 734
[1:1:0711/203710.646009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7ff8724d1070 0x1558ffbf9c60 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 721 0x7ff8724d1070 0x155900379360 
[1:1:0711/203710.752095:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 734, 7ff874e16881
[1:1:0711/203710.783818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"721 0x7ff8724d1070 0x155900379360 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.784191:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"721 0x7ff8724d1070 0x155900379360 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203710.784490:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203710.788850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203710.789038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203710.793687:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203710.793869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203710.794235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 743
[1:1:0711/203710.794430:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7ff8724d1070 0x155900426660 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 734 0x7ff8724d1070 0x1558ffbf9c60 
[1:1:0711/203711.141872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 743, 7ff874e16881
[1:1:0711/203711.160012:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"734 0x7ff8724d1070 0x1558ffbf9c60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.160350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"734 0x7ff8724d1070 0x1558ffbf9c60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.160625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203711.161112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203711.161293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203711.161915:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203711.162065:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203711.162412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 763
[1:1:0711/203711.162611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 763 0x7ff8724d1070 0x1558ff49ec60 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 743 0x7ff8724d1070 0x155900426660 
[1:1:0711/203711.349108:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 763, 7ff874e16881
[1:1:0711/203711.359388:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"743 0x7ff8724d1070 0x155900426660 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.359583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"743 0x7ff8724d1070 0x155900426660 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.359751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203711.360076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203711.360185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203711.360532:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203711.360632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203711.360797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 770
[1:1:0711/203711.360902:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7ff8724d1070 0x1558ffc4e460 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 763 0x7ff8724d1070 0x1558ff49ec60 
[1:1:0711/203711.481853:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 770, 7ff874e16881
[1:1:0711/203711.507836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"763 0x7ff8724d1070 0x1558ff49ec60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.508217:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"763 0x7ff8724d1070 0x1558ff49ec60 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.508602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203711.509225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203711.509457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203711.510226:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203711.510452:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203711.510857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 775
[1:1:0711/203711.511090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7ff8724d1070 0x1558ff2e80e0 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 770 0x7ff8724d1070 0x1558ffc4e460 
[1:1:0711/203711.642899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 775, 7ff874e16881
[1:1:0711/203711.673647:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"770 0x7ff8724d1070 0x1558ffc4e460 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.673963:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"770 0x7ff8724d1070 0x1558ffc4e460 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.674246:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203711.674823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203711.675010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203711.675661:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203711.675819:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203711.676143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 777
[1:1:0711/203711.676332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 777 0x7ff8724d1070 0x1558ffa1e160 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 775 0x7ff8724d1070 0x1558ff2e80e0 
[1:1:0711/203711.791071:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 777, 7ff874e16881
[1:1:0711/203711.800091:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"775 0x7ff8724d1070 0x1558ff2e80e0 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.800226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"775 0x7ff8724d1070 0x1558ff2e80e0 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.800378:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203711.800856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203711.801076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203711.801875:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203711.802071:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203711.802465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 779
[1:1:0711/203711.802718:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 779 0x7ff8724d1070 0x1558ffd6e960 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 777 0x7ff8724d1070 0x1558ffa1e160 
[1:1:0711/203711.942264:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 779, 7ff874e16881
[1:1:0711/203711.980362:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"777 0x7ff8724d1070 0x1558ffa1e160 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.980669:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"777 0x7ff8724d1070 0x1558ffa1e160 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203711.980938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203711.981459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203711.981656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203711.982251:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203711.982398:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203711.982726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 781
[1:1:0711/203711.982905:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7ff8724d1070 0x1558ffce0260 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 779 0x7ff8724d1070 0x1558ffd6e960 
[1:1:0711/203712.124363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 781, 7ff874e16881
[1:1:0711/203712.133641:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"779 0x7ff8724d1070 0x1558ffd6e960 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203712.133780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"779 0x7ff8724d1070 0x1558ffd6e960 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0711/203712.133930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0711/203712.134222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0711/203712.134328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0711/203712.134616:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0711/203712.134739:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0711/203712.134899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 783
[1:1:0711/203712.135004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7ff8724d1070 0x155900345760 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 781 0x7ff8724d1070 0x1558ffce0260 
[1:1:0711/203712.247260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 783, 7ff874e16881
[1:1:0711/203712.271996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2774e8842860","ptid":"781 0x7ff8724d1070 0x1558ffce0260 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0100/000000.272304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.xuexila.com/","ptid":"781 0x7ff8724d1070 0x1558ffce0260 ","rf":"5:3_http://www.xuexila.com/"}
[1:1:0100/000000.287106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.xuexila.com/"
[1:1:0100/000000.289325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.xuexila.com/, 2774e8842860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0100/000000.289400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.xuexila.com/", "www.xuexila.com", 3, 1, , , 0
[1:1:0100/000000.289949:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2026c23429c8, 0x1558fe9ca150
[1:1:0100/000000.290033:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.xuexila.com/", 100
[1:1:0100/000000.290480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.xuexila.com/, 786
[1:1:0100/000000.290661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7ff8724d1070 0x1559003794e0 , 5:3_http://www.xuexila.com/, 1, -5:3_http://www.xuexila.com/, 783 0x7ff8724d1070 0x155900345760 
