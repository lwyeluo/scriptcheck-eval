[0711/202729.174457:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/202729.174740:INFO:switcher_clone.cc(787)] backtrace rip is 7fc0d898c891
[0711/202730.094847:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/202730.095146:INFO:switcher_clone.cc(787)] backtrace rip is 7f234a56b891
[1:1:0711/202730.099656:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/202730.099856:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/202730.104810:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[11089:11089:0711/202731.074526:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/8e89024f-5dc5-4fff-a4e6-fcb8dd18b62d
[0711/202731.556444:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/202731.556887:INFO:switcher_clone.cc(787)] backtrace rip is 7fea46b2c891
[11089:11089:0711/202731.615224:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[11089:11118:0711/202731.616059:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/202731.616304:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/202731.616551:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/202731.617291:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/202731.617499:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/202731.621032:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x30ccaeb9, 1
[1:1:0711/202731.621392:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xf95ffc9, 0
[1:1:0711/202731.621594:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3a4b4c87, 3
[1:1:0711/202731.621808:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3c076c85, 2
[1:1:0711/202731.622044:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc9ffffffffffffff950f ffffffb9ffffffaeffffffcc30 ffffff856c073c ffffff874c4b3a , 10104, 4
[1:1:0711/202731.623045:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11089:11118:0711/202731.623306:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING������0�l<�LK:?�E
[11089:11118:0711/202731.623377:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ������0�l<�LK:8.?�E
[1:1:0711/202731.623297:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f23487a60a0, 3
[1:1:0711/202731.623484:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2348931080, 2
[11089:11118:0711/202731.623650:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/202731.623635:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f23325f4d20, -2
[11089:11118:0711/202731.623717:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 11134, 4, c9ff950f b9aecc30 856c073c 874c4b3a 
[1:1:0711/202731.642295:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/202731.643141:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c076c85
[1:1:0711/202731.644103:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c076c85
[1:1:0711/202731.645653:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c076c85
[1:1:0711/202731.647268:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.647498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.647729:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.647944:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.648575:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c076c85
[1:1:0711/202731.648944:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f234a56b7ba
[1:1:0711/202731.649104:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f234a562def, 7f234a56b77a, 7f234a56d0cf
[1:1:0711/202731.654773:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c076c85
[1:1:0711/202731.655124:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c076c85
[1:1:0711/202731.655900:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c076c85
[1:1:0711/202731.658312:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.658552:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.658787:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.658987:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c076c85
[1:1:0711/202731.660196:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c076c85
[1:1:0711/202731.660538:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f234a56b7ba
[1:1:0711/202731.660666:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f234a562def, 7f234a56b77a, 7f234a56d0cf
[1:1:0711/202731.668244:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/202731.668844:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/202731.668983:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde8a3ecc8, 0x7ffde8a3ec48)
[1:1:0711/202731.685766:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/202731.691121:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[11120:11120:0711/202731.806471:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11120
[11148:11148:0711/202731.806906:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11148
[11089:11089:0711/202732.237683:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11089:11089:0711/202732.239260:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11089:11100:0711/202732.251587:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[11089:11100:0711/202732.251691:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[11089:11089:0711/202732.251806:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[11089:11089:0711/202732.251881:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[11089:11089:0711/202732.252050:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,11134, 4
[1:7:0711/202732.254213:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[11089:11111:0711/202732.290208:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/202732.379771:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x21eb271e9220
[1:1:0711/202732.380113:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/202732.718588:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[11089:11089:0711/202734.310885:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[11089:11089:0711/202734.311039:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/202734.358870:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202734.362236:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/202735.469659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 086d58b81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/202735.469957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202735.500971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 086d58b81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/202735.501265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202735.556673:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202735.877134:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202735.877424:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202736.217738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202736.225800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 086d58b81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/202736.226087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202736.261130:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202736.271577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 086d58b81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/202736.271871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202736.283652:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/202736.287215:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x21eb271e7e20
[1:1:0711/202736.287446:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[11089:11089:0711/202736.290476:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[11089:11089:0711/202736.293539:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[11089:11089:0711/202736.329936:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[11089:11089:0711/202736.330085:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/202736.330856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[11089:11089:0711/202736.354820:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0711/202737.219572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7f23341cf2e0 0x21eb271c64e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202737.220964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 086d58b81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/202737.221234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202737.222748:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202737.294127:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x21eb271e8820
[1:1:0711/202737.294379:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[11089:11089:0711/202737.299834:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/202737.303729:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/202737.303980:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[11089:11089:0711/202737.311477:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[11089:11089:0711/202737.325377:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[11089:11089:0711/202737.335952:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11089:11089:0711/202737.336996:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11089:11089:0711/202737.343715:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[11089:11089:0711/202737.343801:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[11089:11089:0711/202737.343934:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,11134, 4
[11089:11100:0711/202737.343935:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[11089:11100:0711/202737.344041:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/202737.350487:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/202737.751419:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/202738.228085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7f23341cf2e0 0x21eb27588f60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202738.229134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 086d58b81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/202738.229360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202738.230153:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[11089:11089:0711/202738.377046:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[11089:11089:0711/202738.377105:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/202738.394975:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/202738.685261:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202739.190773:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202739.191045:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[11089:11089:0711/202739.243731:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[11089:11118:0711/202739.244224:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/202739.244467:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/202739.244996:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/202739.245464:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/202739.245650:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/202739.249118:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xf94c057, 1
[1:1:0711/202739.249488:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36475fb8, 0
[1:1:0711/202739.249674:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x49497, 3
[1:1:0711/202739.249889:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b1d601c, 2
[1:1:0711/202739.250100:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb85f4736 57ffffffc0ffffff940f 1c601d1b ffffff97ffffff940400 , 10104, 5
[1:1:0711/202739.251106:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11089:11118:0711/202739.251385:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�_G6W��`��
[11089:11118:0711/202739.251453:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �_G6W��`��
[1:1:0711/202739.251564:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f23487a60a0, 3
[11089:11118:0711/202739.251712:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 11186, 5, b85f4736 57c0940f 1c601d1b 97940400 
[1:1:0711/202739.251799:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2348931080, 2
[1:1:0711/202739.252008:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f23325f4d20, -2
[1:1:0711/202739.273126:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/202739.273528:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b1d601c
[1:1:0711/202739.273862:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b1d601c
[1:1:0711/202739.274521:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b1d601c
[1:1:0711/202739.275977:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.276261:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.276479:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.276692:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.277383:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b1d601c
[1:1:0711/202739.277700:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f234a56b7ba
[1:1:0711/202739.277869:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f234a562def, 7f234a56b77a, 7f234a56d0cf
[1:1:0711/202739.283829:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b1d601c
[1:1:0711/202739.284269:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b1d601c
[1:1:0711/202739.285042:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b1d601c
[1:1:0711/202739.287599:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.287899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.288131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.288403:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b1d601c
[1:1:0711/202739.290022:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b1d601c
[1:1:0711/202739.290482:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f234a56b7ba
[1:1:0711/202739.290659:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f234a562def, 7f234a56b77a, 7f234a56d0cf
[1:1:0711/202739.293374:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/202739.293925:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/202739.294126:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde8a3ecc8, 0x7ffde8a3ec48)
[1:1:0711/202739.306302:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/202739.311554:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/202739.486751:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/202739.490062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 086d58cb09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/202739.490429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/202739.498247:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/202739.501324:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x21eb271b1220
[1:1:0711/202739.501550:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[11089:11089:0711/202739.673148:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11089:11089:0711/202739.685640:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11089:11100:0711/202739.731690:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[11089:11100:0711/202739.731788:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[11089:11089:0711/202739.732361:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.ihuaben.com/
[11089:11089:0711/202739.732466:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.ihuaben.com/, http://www.ihuaben.com/, 1
[11089:11089:0711/202739.732631:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.ihuaben.com/, HTTP/1.1 200 OK Server: nginx/1.13.8 Date: Fri, 12 Jul 2019 03:27:39 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Frame-Options: SAMEORIGIN Content-Encoding: gzip  ,11186, 5
[1:7:0711/202739.736023:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/202739.748221:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.ihuaben.com/
[11089:11089:0711/202739.873862:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.ihuaben.com/, http://www.ihuaben.com/, 1
[11089:11089:0711/202739.873949:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.ihuaben.com/, http://www.ihuaben.com
[1:1:0711/202739.908490:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/202739.974352:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202740.109554:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202740.109849:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.ihuaben.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/202740.559355:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202741.269849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 197 0x7f233260fbd0 0x21eb273769d8 , "http://www.ihuaben.com/"
[1:1:0711/202741.281656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , /*! jQuery v1.12.2 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0711/202741.281953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202741.295268:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202741.296588:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202741.296988:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202741.297612:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202741.300772:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202741.301141:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202741.509420:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 197 0x7f233260fbd0 0x21eb273769d8 , "http://www.ihuaben.com/"
[1:1:0711/202741.521467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 197 0x7f233260fbd0 0x21eb273769d8 , "http://www.ihuaben.com/"
[1:1:0711/202741.619433:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 197 0x7f233260fbd0 0x21eb273769d8 , "http://www.ihuaben.com/"
[1:1:0711/202741.821136:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 197 0x7f233260fbd0 0x21eb273769d8 , "http://www.ihuaben.com/"
[3:3:0711/202751.383454:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/202751.453740:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 9.94594, 0, 0
[1:1:0711/202751.454008:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202751.834859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/202751.835133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202752.131860:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202752.132177:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.ihuaben.com/"
[1:1:0711/202752.135858:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 249 0x7f23322a7070 0x21eb26dbefe0 , "http://www.ihuaben.com/"
[1:1:0711/202752.137904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , var tempList=[],searchClass={noShowHistory:!1,showHistory:function(){if(!searchClass.noShowHistory){
[1:1:0711/202752.138126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202752.149040:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 249 0x7f23322a7070 0x21eb26dbefe0 , "http://www.ihuaben.com/"
[1:1:0711/202752.265249:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.132941, 686, 1
[1:1:0711/202752.265534:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202752.494541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202752.494848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[11089:11089:0711/202753.513176:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/202754.702503:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202754.702704:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.ihuaben.com/"
[1:1:0711/202754.703572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f23322a7070 0x21eb2758f3e0 , "http://www.ihuaben.com/"
[1:1:0711/202754.704914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , 
	var activeBar = $("ul[lang=navTab]  a.active");
	activeBar.removeClass("active");
	$("ul[lang=navT
[1:1:0711/202754.705266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202754.739019:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f23322a7070 0x21eb2758f3e0 , "http://www.ihuaben.com/"
[1:1:0711/202754.752706:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 319 0x7f23322a7070 0x21eb2758f3e0 , "http://www.ihuaben.com/"
[1:1:0711/202754.814290:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x37d2950e29c8, 0x21eb26f7ea08
[1:1:0711/202754.814462:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 1000
[1:1:0711/202754.814642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 409
[1:1:0711/202754.814753:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 409 0x7f23322a7070 0x21eb27943be0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 319 0x7f23322a7070 0x21eb2758f3e0 
[1:1:0711/202754.871218:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.168468, 220, 1
[1:1:0711/202754.871477:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202756.176241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202756.176480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202757.155483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.ihuaben.com/"
[1:1:0711/202757.156524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , r.handle, (a){return"undefined"==typeof n||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,
[1:1:0711/202757.156675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202757.740929:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202757.741081:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.ihuaben.com/"
[1:1:0711/202757.742835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7f23322a7070 0x21eb279726e0 , "http://www.ihuaben.com/"
[1:1:0711/202757.746995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , (function(){$("#huabenMore").click(function(){$(".TopButtonsBG").is(":hidden")?($(".TopButtonsBG").s
[1:1:0711/202757.747178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202758.337060:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.595979, 0, 0
[1:1:0711/202758.337270:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[11089:11089:0711/202758.342261:INFO:CONSOLE(61)] "%c ", source: http://static.ihuaben.com/main/core/foot.js?v=20190708 (61)
[11089:11089:0711/202758.346606:INFO:CONSOLE(61)] "%c 
话本小说欢迎你!

", source: http://static.ihuaben.com/main/core/foot.js?v=20190708 (61)
[11089:11089:0711/202758.350699:INFO:CONSOLE(61)] "%c ", source: http://static.ihuaben.com/main/core/foot.js?v=20190708 (61)
[1:1:0711/202759.337938:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 409, 7f2334bec881
[1:1:0711/202759.361805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"319 0x7f23322a7070 0x21eb2758f3e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202759.362170:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"319 0x7f23322a7070 0x21eb2758f3e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202759.362513:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202759.363153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , (){var a=$(window).width();520>a?(resetWidth(),$(".left-side li").css("margin-left")&&1>$(".left-sid
[1:1:0711/202759.363379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202759.704797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202759.705112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/202800.413585:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202800.413862:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.ihuaben.com/"
[1:1:0711/202800.417716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 524 0x7f23322a7070 0x21eb27ec3c60 , "http://www.ihuaben.com/"
[1:1:0711/202800.420577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , !function(e){function n(o){if(t[o])return t[o].exports;var r=t[o]={i:o,l:!1,exports:{}};return e[o].
[1:1:0711/202800.420822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[11089:11089:0711/202800.451140:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://ae.bdstatic.com/xz/msite/static/sdk/main.833c272c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://msite.baidu.com/sdk/c.js?appid=1576400978095822 (1)
[11089:11089:0711/202800.460331:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://ae.bdstatic.com/xz/msite/static/sdk/main.833c272c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://msite.baidu.com/sdk/c.js?appid=1576400978095822 (1)
[1:1:0711/202800.550775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202800.551059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202800.863003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202800.863313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202801.163896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202801.164190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202801.215137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202801.216382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202801.281774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202801.282075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202801.400928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567 0x7f2348931080 0x21eb273696a0 1 0 0x21eb273696b8 , "http://www.ihuaben.com/"
[1:1:0711/202801.415080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , !function(t){function n(e){if(r[e])return r[e].exports;var i=r[e]={i:e,l:!1,exports:{}};return t[e].
[1:1:0711/202801.415363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202801.540831:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.ihuaben.com/"
[1:1:0711/202801.552647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567 0x7f2348931080 0x21eb273696a0 1 0 0x21eb273696b8 , "http://www.ihuaben.com/"
[1:1:0711/202801.581924:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567 0x7f2348931080 0x21eb273696a0 1 0 0x21eb273696b8 , "http://www.ihuaben.com/"
[1:1:0711/202801.622694:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x37d2950e29c8, 0x21eb26f7e9d0
[1:1:0711/202801.623057:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 1000
[1:1:0711/202801.623449:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 587
[1:1:0711/202801.623725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 587 0x7f23322a7070 0x21eb28443a60 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 567 0x7f2348931080 0x21eb273696a0 1 0 0x21eb273696b8 
[1:1:0711/202801.631590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.ihuaben.com/"
[1:1:0711/202801.869470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202801.869809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202802.417509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202802.417900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202802.659242:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 617 0x7f23341cf2e0 0x21eb2794f860 , "http://www.ihuaben.com/"
[1:1:0711/202802.661945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , /*
	 * Copyright 2010 Nicholas C. Zakas. All rights reserved.
	 * BSD Licensed.
	 * modified by wush
[1:1:0711/202802.662226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202802.696547:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 618 0x7f23341cf2e0 0x21eb281dd7e0 , "http://www.ihuaben.com/"
[1:1:0711/202802.705280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , (function(){function p(){this.c="1258673561";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0711/202802.705577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202802.915254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202802.915582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202802.988797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 627 0x7f23341cf2e0 0x21eb281a99e0 , "http://www.ihuaben.com/"
[1:1:0711/202802.990762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():t()}(this,functi
[1:1:0711/202802.990908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202803.238907:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 587, 7f2334bec881
[1:1:0711/202803.268903:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"567 0x7f2348931080 0x21eb273696a0 1 0 0x21eb273696b8 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202803.269252:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"567 0x7f2348931080 0x21eb273696a0 1 0 0x21eb273696b8 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202803.269551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202803.270078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , (){$SA.webTrack(a)}
[1:1:0711/202803.270260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202803.626366:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202803.626645:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 200
[1:1:0711/202803.627053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 676
[1:1:0711/202803.627342:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f23322a7070 0x21eb2737ea60 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 587 0x7f23322a7070 0x21eb28443a60 
[1:1:0711/202804.202225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202804.202427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202805.035793:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 676, 7f2334bec881
[1:1:0711/202805.071543:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"587 0x7f23322a7070 0x21eb28443a60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202805.071951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"587 0x7f23322a7070 0x21eb28443a60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202805.072282:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202805.072918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , (){e.isEnd()}
[1:1:0711/202805.073144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202805.292008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 698 0x7f23341cf2e0 0x21eb27945ee0 , "http://www.ihuaben.com/"
[1:1:0711/202805.295035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0711/202805.295228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202805.328048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 699 0x7f23341cf2e0 0x21eb270999e0 , "http://www.ihuaben.com/"
[1:1:0711/202805.331205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , (function(){var h={},mt={},c={id:"d8f55433af86e4f29978b4f0d0340955",dm:["ihuaben.com"],js:"tongji.ba
[1:1:0711/202805.331336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202805.360142:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e940
[1:1:0711/202805.360392:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202805.360747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 724
[1:1:0711/202805.360944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7f23322a7070 0x21eb27a2c760 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 699 0x7f23341cf2e0 0x21eb270999e0 
[1:1:0711/202805.436160:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 600000
[1:1:0711/202805.436695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.ihuaben.com/, 737
[1:1:0711/202805.436966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 737 0x7f23322a7070 0x21eb26dbcfe0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 699 0x7f23341cf2e0 0x21eb270999e0 
[1:1:0711/202805.438056:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 5000
[1:1:0711/202805.438454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.ihuaben.com/, 738
[1:1:0711/202805.438696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7f23322a7070 0x21eb2795e3e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 699 0x7f23341cf2e0 0x21eb270999e0 
[1:1:0711/202805.592881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202805.593075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202805.706319:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.ihuaben.com/"
[1:1:0711/202805.706747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0711/202805.706909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202805.739579:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.ihuaben.com/"
[1:1:0711/202805.740167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , img.onload, (t){this.onload=null,e.isEnd()}
[1:1:0711/202805.740320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/202806.413728:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 724, 7f2334bec881
[1:1:0711/202806.429512:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"699 0x7f23341cf2e0 0x21eb270999e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202806.429717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"699 0x7f23341cf2e0 0x21eb270999e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202806.429880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202806.430201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202806.430309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202806.430677:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202806.430776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202806.430973:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 769
[1:1:0711/202806.431111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7f23322a7070 0x21eb27976a60 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 724 0x7f23322a7070 0x21eb27a2c760 
[1:1:0711/202806.526676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202806.526914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202806.670218:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.ihuaben.com/"
[1:1:0711/202806.670776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , g.onload, (){g.onload=w;g=window[d]=w;a&&a(b)}
[1:1:0711/202806.670931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202806.679847:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.ihuaben.com/"
[1:1:0711/202806.716029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.ihuaben.com/"
[1:1:0711/202806.721046:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.ihuaben.com/"
[1:1:0711/202806.722785:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7eaf0
[1:1:0711/202806.723004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202806.723445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 785
[1:1:0711/202806.723694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7f23322a7070 0x21eb281a9860 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 773 0x7f23322a7070 0x21eb27097360 
[1:1:0711/202806.810192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , , document.readyState
[1:1:0711/202806.810435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202807.061512:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 785, 7f2334bec881
[1:1:0711/202807.082558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"773 0x7f23322a7070 0x21eb27097360 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.082861:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"773 0x7f23322a7070 0x21eb27097360 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.083128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202807.083665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202807.083838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202807.084535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202807.084696:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202807.085015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 807
[1:1:0711/202807.085203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7f23322a7070 0x21eb2723e5e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 785 0x7f23322a7070 0x21eb281a9860 
[1:1:0711/202807.233680:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 807, 7f2334bec881
[1:1:0711/202807.259548:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"785 0x7f23322a7070 0x21eb281a9860 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.259934:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"785 0x7f23322a7070 0x21eb281a9860 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.260250:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202807.260945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202807.261160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202807.261957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202807.262150:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202807.262557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 815
[1:1:0711/202807.262789:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f23322a7070 0x21eb27591d60 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 807 0x7f23322a7070 0x21eb2723e5e0 
[1:1:0711/202807.461468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 815, 7f2334bec881
[1:1:0711/202807.472053:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"807 0x7f23322a7070 0x21eb2723e5e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.472248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"807 0x7f23322a7070 0x21eb2723e5e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.472431:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202807.472783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202807.472888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202807.473185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202807.473279:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202807.473474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 826
[1:1:0711/202807.473588:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 826 0x7f23322a7070 0x21eb279613e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 815 0x7f23322a7070 0x21eb27591d60 
[1:1:0711/202807.612518:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 826, 7f2334bec881
[1:1:0711/202807.632133:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"815 0x7f23322a7070 0x21eb27591d60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.632350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"815 0x7f23322a7070 0x21eb27591d60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.632600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202807.632905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202807.633010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202807.633306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202807.633411:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202807.633610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 829
[1:1:0711/202807.633719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f23322a7070 0x21eb27297760 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 826 0x7f23322a7070 0x21eb279613e0 
[1:1:0711/202807.747924:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 829, 7f2334bec881
[1:1:0711/202807.786406:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"826 0x7f23322a7070 0x21eb279613e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.786755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"826 0x7f23322a7070 0x21eb279613e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.787012:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202807.787552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202807.787735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202807.788331:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202807.788479:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202807.788833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 832
[1:1:0711/202807.789013:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 832 0x7f23322a7070 0x21eb28217fe0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 829 0x7f23322a7070 0x21eb27297760 
[1:1:0711/202807.911116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 832, 7f2334bec881
[1:1:0711/202807.921214:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"829 0x7f23322a7070 0x21eb27297760 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.921352:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"829 0x7f23322a7070 0x21eb27297760 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202807.921496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202807.921813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202807.921916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202807.922209:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202807.922303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202807.922473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 835
[1:1:0711/202807.922606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 835 0x7f23322a7070 0x21eb284070e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 832 0x7f23322a7070 0x21eb28217fe0 
[1:1:0711/202808.062385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 835, 7f2334bec881
[1:1:0711/202808.092120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"832 0x7f23322a7070 0x21eb28217fe0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.092324:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"832 0x7f23322a7070 0x21eb28217fe0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.092485:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202808.092845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202808.092963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202808.093273:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202808.093368:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202808.093538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 837
[1:1:0711/202808.093675:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7f23322a7070 0x21eb2725d960 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 835 0x7f23322a7070 0x21eb284070e0 
[1:1:0711/202808.236748:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 837, 7f2334bec881
[1:1:0711/202808.270497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"835 0x7f23322a7070 0x21eb284070e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.270849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"835 0x7f23322a7070 0x21eb284070e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.271118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202808.271638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202808.271831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202808.272458:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202808.272612:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202808.273037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 839
[1:1:0711/202808.273241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 839 0x7f23322a7070 0x21eb271895e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 837 0x7f23322a7070 0x21eb2725d960 
[1:1:0711/202808.408587:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 839, 7f2334bec881
[1:1:0711/202808.419490:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"837 0x7f23322a7070 0x21eb2725d960 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.419667:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"837 0x7f23322a7070 0x21eb2725d960 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.419866:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202808.420185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202808.420302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202808.420606:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202808.420701:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202808.420908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 841
[1:1:0711/202808.421018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7f23322a7070 0x21eb2723e1e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 839 0x7f23322a7070 0x21eb271895e0 
[1:1:0711/202808.556253:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 841, 7f2334bec881
[1:1:0711/202808.590010:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"839 0x7f23322a7070 0x21eb271895e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.590344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"839 0x7f23322a7070 0x21eb271895e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.590611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202808.591156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202808.591332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202808.592014:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202808.592174:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202808.592494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 843
[1:1:0711/202808.592694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 843 0x7f23322a7070 0x21eb27978be0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 841 0x7f23322a7070 0x21eb2723e1e0 
[1:1:0711/202808.721017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 843, 7f2334bec881
[1:1:0711/202808.736912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"841 0x7f23322a7070 0x21eb2723e1e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.737224:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"841 0x7f23322a7070 0x21eb2723e1e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.737489:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202808.738063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202808.738239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202808.738890:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202808.739049:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202808.739368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 845
[1:1:0711/202808.739553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 845 0x7f23322a7070 0x21eb2737ea60 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 843 0x7f23322a7070 0x21eb27978be0 
[1:1:0711/202808.874258:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 845, 7f2334bec881
[1:1:0711/202808.907989:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"843 0x7f23322a7070 0x21eb27978be0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.908320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"843 0x7f23322a7070 0x21eb27978be0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202808.908584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202808.909151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202808.909328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202808.909987:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202808.910148:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202808.910501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 847
[1:1:0711/202808.910690:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7f23322a7070 0x21eb27950760 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 845 0x7f23322a7070 0x21eb2737ea60 
[1:1:0711/202809.046222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 847, 7f2334bec881
[1:1:0711/202809.079583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"845 0x7f23322a7070 0x21eb2737ea60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.079911:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"845 0x7f23322a7070 0x21eb2737ea60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.080213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202809.080758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202809.080937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202809.081540:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202809.081702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202809.082066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 849
[1:1:0711/202809.082250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f23322a7070 0x21eb279485e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 847 0x7f23322a7070 0x21eb27950760 
[1:1:0711/202809.233166:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 849, 7f2334bec881
[1:1:0711/202809.267026:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"847 0x7f23322a7070 0x21eb27950760 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.267354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"847 0x7f23322a7070 0x21eb27950760 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.267615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202809.268181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202809.268360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202809.268997:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202809.269171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202809.269493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 851
[1:1:0711/202809.269685:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7f23322a7070 0x21eb281a5560 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 849 0x7f23322a7070 0x21eb279485e0 
[1:1:0711/202809.404721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 851, 7f2334bec881
[1:1:0711/202809.415742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"849 0x7f23322a7070 0x21eb279485e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.415948:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"849 0x7f23322a7070 0x21eb279485e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.416136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202809.416439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202809.416542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202809.416832:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202809.416928:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202809.417180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 856
[1:1:0711/202809.417371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 856 0x7f23322a7070 0x21eb2723e7e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 851 0x7f23322a7070 0x21eb281a5560 
[1:1:0711/202809.564427:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 856, 7f2334bec881
[1:1:0711/202809.583530:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"851 0x7f23322a7070 0x21eb281a5560 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.583732:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"851 0x7f23322a7070 0x21eb281a5560 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.583890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202809.584244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202809.584349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202809.584642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202809.584736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202809.584902:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 858
[1:1:0711/202809.585006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f23322a7070 0x21eb273761e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 856 0x7f23322a7070 0x21eb2723e7e0 
[1:1:0711/202809.738738:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 858, 7f2334bec881
[1:1:0711/202809.773415:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"856 0x7f23322a7070 0x21eb2723e7e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.773745:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"856 0x7f23322a7070 0x21eb2723e7e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.774008:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202809.774537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202809.774711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202809.775357:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202809.775514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202809.775846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 860
[1:1:0711/202809.776032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 860 0x7f23322a7070 0x21eb279588e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 858 0x7f23322a7070 0x21eb273761e0 
[1:1:0711/202809.919007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 860, 7f2334bec881
[1:1:0711/202809.946882:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"858 0x7f23322a7070 0x21eb273761e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.947091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"858 0x7f23322a7070 0x21eb273761e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202809.947263:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202809.947559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202809.947659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202809.947941:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202809.948033:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202809.948198:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 862
[1:1:0711/202809.948333:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f23322a7070 0x21eb281ad1e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 860 0x7f23322a7070 0x21eb279588e0 
[1:1:0711/202810.085877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 862, 7f2334bec881
[1:1:0711/202810.124913:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"860 0x7f23322a7070 0x21eb279588e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.125259:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"860 0x7f23322a7070 0x21eb279588e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.125562:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202810.126138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202810.126342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202810.127000:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202810.127162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202810.127533:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 864
[1:1:0711/202810.127745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7f23322a7070 0x21eb26fb62e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 862 0x7f23322a7070 0x21eb281ad1e0 
[1:1:0711/202810.282190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 864, 7f2334bec881
[1:1:0711/202810.317099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"862 0x7f23322a7070 0x21eb281ad1e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.317480:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"862 0x7f23322a7070 0x21eb281ad1e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.317839:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202810.318459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202810.318632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202810.319233:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202810.319437:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202810.319810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 866
[1:1:0711/202810.319990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 866 0x7f23322a7070 0x21eb2816f0e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 864 0x7f23322a7070 0x21eb26fb62e0 
[1:1:0711/202810.464297:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 866, 7f2334bec881
[1:1:0711/202810.515944:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"864 0x7f23322a7070 0x21eb26fb62e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.516299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"864 0x7f23322a7070 0x21eb26fb62e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.516615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202810.517128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202810.517478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202810.518107:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202810.518261:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202810.518606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 869
[1:1:0711/202810.518795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 869 0x7f23322a7070 0x21eb279508e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 866 0x7f23322a7070 0x21eb2816f0e0 
[1:1:0711/202810.520286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.ihuaben.com/, 738, 7f2334bec8db
[1:1:0711/202810.556265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"699 0x7f23341cf2e0 0x21eb270999e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.556700:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"699 0x7f23341cf2e0 0x21eb270999e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.557174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.ihuaben.com/, 871
[1:1:0711/202810.557465:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7f23322a7070 0x21eb2723e1e0 , 5:3_http://www.ihuaben.com/, 0, , 738 0x7f23322a7070 0x21eb2795e3e0 
[1:1:0711/202810.557813:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202810.558392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0711/202810.558590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202810.654443:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 869, 7f2334bec881
[1:1:0711/202810.666094:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"866 0x7f23322a7070 0x21eb2816f0e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.666290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"866 0x7f23322a7070 0x21eb2816f0e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.666475:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202810.666829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202810.666936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202810.667241:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202810.667339:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202810.667547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 873
[1:1:0711/202810.667682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7f23322a7070 0x21eb284a8460 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 869 0x7f23322a7070 0x21eb279508e0 
[1:1:0711/202810.817784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 873, 7f2334bec881
[1:1:0711/202810.856010:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"869 0x7f23322a7070 0x21eb279508e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.856335:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"869 0x7f23322a7070 0x21eb279508e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.856640:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202810.857180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202810.857365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202810.858063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202810.858228:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202810.858718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 875
[1:1:0711/202810.858920:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7f23322a7070 0x21eb281ad1e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 873 0x7f23322a7070 0x21eb284a8460 
[1:1:0711/202810.983379:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 875, 7f2334bec881
[1:1:0711/202810.994927:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"873 0x7f23322a7070 0x21eb284a8460 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.995120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"873 0x7f23322a7070 0x21eb284a8460 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202810.995286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202810.995663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202810.995832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202810.996261:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202810.996364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202810.996544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 877
[1:1:0711/202810.996715:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 877 0x7f23322a7070 0x21eb272bbae0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 875 0x7f23322a7070 0x21eb281ad1e0 
[1:1:0711/202811.130213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 877, 7f2334bec881
[1:1:0711/202811.169445:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"875 0x7f23322a7070 0x21eb281ad1e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.169806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"875 0x7f23322a7070 0x21eb281ad1e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.170087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202811.170615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202811.170819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202811.171475:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202811.171660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202811.171998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 879
[1:1:0711/202811.172194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 879 0x7f23322a7070 0x21eb27a0de60 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 877 0x7f23322a7070 0x21eb272bbae0 
[1:1:0711/202811.314461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 879, 7f2334bec881
[1:1:0711/202811.352947:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"877 0x7f23322a7070 0x21eb272bbae0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.353262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"877 0x7f23322a7070 0x21eb272bbae0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.353539:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202811.354090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202811.354285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202811.354992:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202811.355156:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202811.355490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 881
[1:1:0711/202811.355712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 881 0x7f23322a7070 0x21eb273761e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 879 0x7f23322a7070 0x21eb27a0de60 
[1:1:0711/202811.489973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 881, 7f2334bec881
[1:1:0711/202811.501486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"879 0x7f23322a7070 0x21eb27a0de60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.501688:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"879 0x7f23322a7070 0x21eb27a0de60 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.501881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202811.502208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202811.502311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202811.502603:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202811.502698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202811.502890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 883
[1:1:0711/202811.502995:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 883 0x7f23322a7070 0x21eb2794d4e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 881 0x7f23322a7070 0x21eb273761e0 
[1:1:0711/202811.658361:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 883, 7f2334bec881
[1:1:0711/202811.694324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"881 0x7f23322a7070 0x21eb273761e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.694658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"881 0x7f23322a7070 0x21eb273761e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0711/202811.694941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0711/202811.695456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0711/202811.695632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0711/202811.696316:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0711/202811.696472:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0711/202811.696814:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 885
[1:1:0711/202811.697021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 885 0x7f23322a7070 0x21eb2843f9e0 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 883 0x7f23322a7070 0x21eb2794d4e0 
[1:1:0711/202811.808465:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 885, 7f2334bec881
[1:1:0100/000000.854434:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0d38d2b02860","ptid":"883 0x7f23322a7070 0x21eb2794d4e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0100/000000.856733:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.ihuaben.com/","ptid":"883 0x7f23322a7070 0x21eb2794d4e0 ","rf":"5:3_http://www.ihuaben.com/"}
[1:1:0100/000000.857063:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.ihuaben.com/"
[1:1:0100/000000.857819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.ihuaben.com/, 0d38d2b02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0100/000000.858026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.ihuaben.com/", "www.ihuaben.com", 3, 1, , , 0
[1:1:0100/000000.858770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37d2950e29c8, 0x21eb26f7e950
[1:1:0100/000000.858920:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.ihuaben.com/", 100
[1:1:0100/000000.859268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.ihuaben.com/, 910
[1:1:0100/000000.859447:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 910 0x7f23322a7070 0x21eb281a9860 , 5:3_http://www.ihuaben.com/, 1, -5:3_http://www.ihuaben.com/, 885 0x7f23322a7070 0x21eb2843f9e0 
