[0711/204109.492192:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/204109.492574:INFO:switcher_clone.cc(787)] backtrace rip is 7f91124db891
[0711/204110.321171:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/204110.321433:INFO:switcher_clone.cc(787)] backtrace rip is 7fc47539f891
[1:1:0711/204110.325280:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/204110.325434:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/204110.330176:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[12993:12993:0711/204111.264044:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/2987ba4d-8932-4e95-86a7-39b4e436ee6f
[0711/204111.615624:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/204111.616081:INFO:switcher_clone.cc(787)] backtrace rip is 7f06a5f47891
[12993:12993:0711/204111.709326:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[12993:13021:0711/204111.710194:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/204111.710402:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/204111.710662:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/204111.711255:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/204111.711418:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/204111.714254:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x34a0fe34, 1
[1:1:0711/204111.714700:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3914acd1, 0
[1:1:0711/204111.714912:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xdb41af3, 3
[1:1:0711/204111.715125:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x6712f11, 2
[1:1:0711/204111.715432:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd1ffffffac1439 34fffffffeffffffa034 112f7106 fffffff31affffffb40d , 10104, 4
[1:1:0711/204111.716674:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12993:13021:0711/204111.716970:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGѬ94��4/q��_
[12993:13021:0711/204111.717036:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ѭ94��4/q��xl_
[1:1:0711/204111.716966:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc4735da0a0, 3
[12993:13021:0711/204111.717324:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/204111.717262:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc473765080, 2
[12993:13021:0711/204111.717396:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13037, 4, d1ac1439 34fea034 112f7106 f31ab40d 
[1:1:0711/204111.717472:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45d428d20, -2
[1:1:0711/204111.738080:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/204111.739130:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6712f11
[1:1:0711/204111.740316:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6712f11
[1:1:0711/204111.742240:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6712f11
[1:1:0711/204111.744090:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.744347:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.744575:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.744796:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.745621:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6712f11
[1:1:0711/204111.746023:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc47539f7ba
[1:1:0711/204111.746203:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc475396def, 7fc47539f77a, 7fc4753a10cf
[1:1:0711/204111.753280:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6712f11
[1:1:0711/204111.753738:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6712f11
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/204111.754664:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6712f11
[1:1:0711/204111.757242:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.757485:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.757729:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.758005:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6712f11
[1:1:0711/204111.759582:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6712f11
[1:1:0711/204111.760029:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc47539f7ba
[1:1:0711/204111.760225:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc475396def, 7fc47539f77a, 7fc4753a10cf
[1:1:0711/204111.769977:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/204111.770633:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/204111.770811:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe8a310988, 0x7ffe8a310908)
[1:1:0711/204111.788344:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/204111.794124:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[13024:13024:0711/204111.835678:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13024
[13051:13051:0711/204111.836937:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13051
[12993:12993:0711/204112.258180:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12993:12993:0711/204112.259610:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12993:13003:0711/204112.270935:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[12993:13003:0711/204112.271035:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[12993:12993:0711/204112.271126:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[12993:12993:0711/204112.271205:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[12993:12993:0711/204112.271330:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,13037, 4
[1:7:0711/204112.277706:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[12993:13014:0711/204112.336363:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/204112.413081:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x31a291e46220
[1:1:0711/204112.413346:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/204112.738456:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[12993:12993:0711/204114.374386:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[12993:12993:0711/204114.374504:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/204114.377772:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204114.381637:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/204115.536857:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/204115.678707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20576b0a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/204115.679016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/204115.696232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20576b0a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/204115.696536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/204115.929764:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/204115.930018:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/204116.284972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/204116.293058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20576b0a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/204116.293321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/204116.344663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/204116.355159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20576b0a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/204116.355428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/204116.367319:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[12993:12993:0711/204116.373249:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/204116.374809:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x31a291e44e20
[1:1:0711/204116.375062:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[12993:12993:0711/204116.380311:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[12993:12993:0711/204116.417179:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[12993:12993:0711/204116.417379:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/204116.480273:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/204117.554940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7fc45f0032e0 0x31a292024360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/204117.556226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20576b0a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/204117.556531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/204117.557970:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[12993:12993:0711/204117.635650:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/204117.636883:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x31a291e45820
[1:1:0711/204117.638511:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[12993:12993:0711/204117.645365:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/204117.659712:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/204117.659988:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[12993:12993:0711/204117.668671:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[12993:12993:0711/204117.680109:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12993:12993:0711/204117.681124:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12993:13003:0711/204117.684920:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[12993:13003:0711/204117.685033:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[12993:12993:0711/204117.685234:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[12993:12993:0711/204117.685327:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[12993:12993:0711/204117.685536:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,13037, 4
[1:7:0711/204117.689584:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/204118.038208:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/204118.466218:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7fc45f0032e0 0x31a2920bec60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/204118.467262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20576b0a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/204118.467509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/204118.468293:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[12993:12993:0711/204118.546431:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[12993:12993:0711/204118.546548:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/204118.569701:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/204118.996898:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/204119.615312:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/204119.615581:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[12993:12993:0711/204119.715250:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[12993:13021:0711/204119.715768:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/204119.716001:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/204119.716289:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/204119.716751:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/204119.716941:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/204119.720289:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1a54b09e, 1
[1:1:0711/204119.720663:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24790713, 0
[1:1:0711/204119.720849:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x12f361a7, 3
[1:1:0711/204119.721029:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x361812ad, 2
[1:1:0711/204119.721398:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 13077924 ffffff9effffffb0541a ffffffad121836 ffffffa761fffffff312 , 10104, 5
[1:1:0711/204119.722543:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12993:13021:0711/204119.722791:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGy$��T�6�a�>
[12993:13021:0711/204119.722861:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is y$��T�6�a�hy>
[1:1:0711/204119.722966:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc4735da0a0, 3
[12993:13021:0711/204119.723126:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13088, 5, 13077924 9eb0541a ad121836 a761f312 
[1:1:0711/204119.723209:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc473765080, 2
[1:1:0711/204119.723419:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc45d428d20, -2
[1:1:0711/204119.744430:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/204119.744824:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 361812ad
[1:1:0711/204119.745185:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 361812ad
[1:1:0711/204119.745835:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 361812ad
[1:1:0711/204119.747295:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.747529:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.747775:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.748018:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.748772:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 361812ad
[1:1:0711/204119.749131:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc47539f7ba
[1:1:0711/204119.749317:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc475396def, 7fc47539f77a, 7fc4753a10cf
[1:1:0711/204119.755133:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 361812ad
[1:1:0711/204119.755551:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 361812ad
[1:1:0711/204119.756354:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 361812ad
[1:1:0711/204119.758404:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.758652:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.758872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.759126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 361812ad
[1:1:0711/204119.760452:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 361812ad
[1:1:0711/204119.760855:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc47539f7ba
[1:1:0711/204119.761025:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc475396def, 7fc47539f77a, 7fc4753a10cf
[1:1:0711/204119.767675:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/204119.768717:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/204119.768923:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe8a310988, 0x7ffe8a310908)
[1:1:0711/204119.782602:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/204119.787305:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/204119.958090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/204119.962754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20576b1d09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/204119.963041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/204119.970760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/204120.055737:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x31a291e18220
[1:1:0711/204120.056007:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[12993:12993:0711/204120.784870:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12993:12993:0711/204120.786744:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12993:13003:0711/204120.815703:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[12993:13003:0711/204120.815804:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[12993:12993:0711/204120.816325:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.bayueju.com/
[12993:12993:0711/204120.816436:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.bayueju.com/, http://www.bayueju.com/, 1
[12993:12993:0711/204120.816621:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.bayueju.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 03:41:20 GMT Server: Apache/2.4.10 (Debian) Set-Cookie: PHPSESSID=okrg17bcbb870s07q4ikfh0t11; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: private Pragma: no-cache Vary: Accept-Encoding Content-Encoding: gzip Content-Length: 16466 Keep-Alive: timeout=5, max=100 Connection: Keep-Alive Content-Type: text/html; charset=utf-8  ,13088, 5
[1:7:0711/204120.821051:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/204120.868641:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.bayueju.com/
[12993:12993:0711/204121.028764:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.bayueju.com/, http://www.bayueju.com/, 1
[12993:12993:0711/204121.028881:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.bayueju.com/, http://www.bayueju.com
[1:1:0711/204121.035871:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/204121.127031:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/204121.156837:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/204121.200866:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/204121.201139:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.bayueju.com/"
[1:1:0711/204121.378109:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/204121.565970:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/204122.165781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7fc45d443bd0 0x31a291f13758 , "http://www.bayueju.com/"
[1:1:0711/204122.176258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , /*! jQuery v3.1.1 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"use strict";"objec
[1:1:0711/204122.176514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204122.205191:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204122.725140:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7fc45d443bd0 0x31a29229f158 , "http://www.bayueju.com/"
[1:1:0711/204122.744452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , /*! jQuery UI - v1.12.1 - 2016-09-14
* http://jqueryui.com
* Includes: widget.js, position.js, data.
[1:1:0711/204122.744737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204124.045749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7fc45d443bd0 0x31a29229f158 , "http://www.bayueju.com/"
[1:1:0711/204124.269516:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7fc45d443bd0 0x31a29229f158 , "http://www.bayueju.com/"
[1:1:0711/204124.345327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7fc45d443bd0 0x31a29229f158 , "http://www.bayueju.com/"
[1:1:0711/204124.596448:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.552443, 1744, 0
[1:1:0711/204124.596678:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/204125.799053:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/204125.799352:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.bayueju.com/"
[1:1:0711/204125.976157:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.176755, 1136, 1
[1:1:0711/204125.976492:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/204126.701631:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/204126.701856:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.bayueju.com/"
[1:1:0711/204126.706165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fc45d0db070 0x31a2929560e0 , "http://www.bayueju.com/"
[1:1:0711/204126.717711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , /**
 * jquery.elastislide.js v1.1.0
 * http://www.codrops.com
 *
 * Licensed under the MIT license.

[1:1:0711/204126.717986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204128.762652:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204128.763108:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204128.769997:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204128.770419:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204128.770785:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204129.820711:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.11883, 0, 0
[1:1:0711/204129.820989:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/204131.658582:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/204131.658834:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.bayueju.com/"
[1:1:0711/204131.667802:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fc45d0db070 0x31a292d52de0 , "http://www.bayueju.com/"
[1:1:0711/204131.703199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , /**
 * Swiper 4.1.6
 * Most modern mobile touch slider and framework with hardware accelerated trans
[1:1:0711/204131.703564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204131.747371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fc45d0db070 0x31a292d52de0 , "http://www.bayueju.com/"
[1:1:0711/204131.840388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.bayueju.com/"
[1:1:0711/204131.847106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe736ee229c8, 0x31a2917c3238
[1:1:0711/204131.847331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 0
[1:1:0711/204131.847743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 510
[1:1:0711/204131.847996:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 510 0x7fc45d0db070 0x31a291f24d60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 416 0x7fc45d0db070 0x31a292d52de0 
[1:1:0711/204131.848896:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe736ee229c8, 0x31a2917c3238
[1:1:0711/204131.849090:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 0
[1:1:0711/204131.849426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 511
[1:1:0711/204131.849704:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7fc45d0db070 0x31a292b3dc60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 416 0x7fc45d0db070 0x31a292d52de0 
[1:1:0711/204131.850442:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe736ee229c8, 0x31a2917c3238
[1:1:0711/204131.850633:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 0
[1:1:0711/204131.850968:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 512
[1:1:0711/204131.851188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 512 0x7fc45d0db070 0x31a292bbc660 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 416 0x7fc45d0db070 0x31a292d52de0 
[3:3:0711/204133.354046:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[12993:12993:0711/204133.440028:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/204134.474634:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442 0x7fc45f0032e0 0x31a2930d4060 , "http://www.bayueju.com/"
[1:1:0711/204134.482194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , (function(){var h={},mt={},c={id:"96bf536611699e9ac914702f147fedd1",dm:["bayueju.com"],js:"tongji.ba
[1:1:0711/204134.482450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204134.518204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3148
[1:1:0711/204134.518477:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204134.518879:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 627
[1:1:0711/204134.519113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7fc45d0db070 0x31a292c5dbe0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 442 0x7fc45f0032e0 0x31a2930d4060 
[1:1:0711/204136.375065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/204136.375368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204137.397106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 510, 7fc45fa20881
[1:1:0711/204137.411872:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"416 0x7fc45d0db070 0x31a292d52de0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204137.412070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"416 0x7fc45d0db070 0x31a292d52de0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204137.412230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204137.412580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/204137.412686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204137.415635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204137.415745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 0
[1:1:0711/204137.415912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 733
[1:1:0711/204137.416018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7fc45d0db070 0x31a292ce9360 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 510 0x7fc45d0db070 0x31a291f24d60 
[1:1:0711/204137.439849:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 511, 7fc45fa20881
[1:1:0711/204137.452313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"416 0x7fc45d0db070 0x31a292d52de0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204137.452532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"416 0x7fc45d0db070 0x31a292d52de0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204137.452698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204137.453001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/204137.453104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204137.552370:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204137.552634:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 0
[1:1:0711/204137.553079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 736
[1:1:0711/204137.553284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 736 0x7fc45d0db070 0x31a291dda7e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 511 0x7fc45d0db070 0x31a292b3dc60 
[1:1:0711/204137.555064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 512, 7fc45fa20881
[1:1:0711/204137.593499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"416 0x7fc45d0db070 0x31a292d52de0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204137.593897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"416 0x7fc45d0db070 0x31a292d52de0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204137.594255:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204137.594909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/204137.595128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204138.853635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204138.853812:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204138.853993:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 745
[1:1:0711/204138.854125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7fc45d0db070 0x31a293ad3d60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 512 0x7fc45d0db070 0x31a292bbc660 
[1:1:0711/204140.146160:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204140.146401:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204140.146686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 754
[1:1:0711/204140.146848:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7fc45d0db070 0x31a293ad34e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 512 0x7fc45d0db070 0x31a292bbc660 
[1:1:0711/204140.150443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204140.150727:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 0
[1:1:0711/204140.151167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 755
[1:1:0711/204140.151414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7fc45d0db070 0x31a292b6d2e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 512 0x7fc45d0db070 0x31a292bbc660 
[1:1:0711/204140.431727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pointermove", "http://www.bayueju.com/"
[1:1:0711/204140.432249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , E, (t){var i=this.touchEventsData,a=this.params,r=this.touches,n=this.rtl,o=t;if(o.originalEvent&&(o=o.
[1:1:0711/204140.432383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204140.433773:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pointermove", "http://www.bayueju.com/"
[1:1:0711/204142.765807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 627, 7fc45fa20881
[1:1:0711/204142.808502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"442 0x7fc45f0032e0 0x31a2930d4060 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204142.808889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"442 0x7fc45f0032e0 0x31a2930d4060 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204142.809244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204142.809978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204142.810201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204142.811131:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204142.811329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204142.811749:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 802
[1:1:0711/204142.811992:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7fc45d0db070 0x31a294151160 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 627 0x7fc45d0db070 0x31a292c5dbe0 
[1:1:0711/204144.173159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204144.173411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204145.462718:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 733, 7fc45fa20881
[1:1:0711/204145.501303:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"510 0x7fc45d0db070 0x31a291f24d60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204145.501710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"510 0x7fc45d0db070 0x31a291f24d60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204145.502061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204145.502730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/204145.502912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204145.544678:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 736, 7fc45fa20881
[1:1:0711/204145.564873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"511 0x7fc45d0db070 0x31a292b3dc60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204145.565178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"511 0x7fc45d0db070 0x31a292b3dc60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204145.565457:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204145.565982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/204145.566154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204146.211138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 755, 7fc45fa20881
[1:1:0711/204146.234014:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"512 0x7fc45d0db070 0x31a292bbc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204146.234399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"512 0x7fc45d0db070 0x31a292bbc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204146.234752:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204146.235353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0711/204146.235557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204147.271537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204147.271959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204147.272114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204147.326315:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204147.326768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204147.326938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204147.339179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204147.339701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204147.339814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204147.492634:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 745, 7fc45fa20881
[1:1:0711/204147.532760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"512 0x7fc45d0db070 0x31a292bbc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204147.533068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"512 0x7fc45d0db070 0x31a292bbc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204147.533390:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204147.533959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , (){e.params.autoplay.reverseDirection?e.params.loop?(e.loopFix(),e.slidePrev(e.params.speed,!0,!0),e
[1:1:0711/204147.534133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204147.858474:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 802, 7fc45fa20881
[1:1:0711/204147.879791:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"627 0x7fc45d0db070 0x31a292c5dbe0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204147.880052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"627 0x7fc45d0db070 0x31a292c5dbe0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204147.880306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204147.880716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204147.880862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204147.881311:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204147.881450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204147.881680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 885
[1:1:0711/204147.881833:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 885 0x7fc45d0db070 0x31a2941ff460 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 802 0x7fc45d0db070 0x31a294151160 
[1:1:0711/204148.005388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204148.005813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/204148.005921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204148.201777:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 754, 7fc45fa20881
[1:1:0711/204148.214820:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"512 0x7fc45d0db070 0x31a292bbc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204148.215004:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"512 0x7fc45d0db070 0x31a292bbc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204148.215192:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204148.215517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , (){e.params.autoplay.reverseDirection?e.params.loop?(e.loopFix(),e.slidePrev(e.params.speed,!0,!0),e
[1:1:0711/204148.215638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204148.319790:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204148.320254:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/204148.648983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204148.649219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204149.242961:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.bayueju.com/"
[1:1:0711/204149.243406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , resizeHandler, (){e&&!e.destroyed&&e.initialized&&(e.emit("beforeResize"),e.emit("resize"))}
[1:1:0711/204149.243520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204149.493494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.bayueju.com/"
[1:1:0711/204151.050792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204151.051536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204151.051787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204151.170439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204151.171081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204151.171257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204151.254479:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204151.255202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204151.255396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204152.167225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 885, 7fc45fa20881
[1:1:0711/204152.210978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"802 0x7fc45d0db070 0x31a294151160 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204152.211308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"802 0x7fc45d0db070 0x31a294151160 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204152.211679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204152.212361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204152.212547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204152.213292:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204152.213446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204152.213854:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 943
[1:1:0711/204152.214038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 943 0x7fc45d0db070 0x31a2937f5f60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 885 0x7fc45d0db070 0x31a2941ff460 
[1:1:0711/204152.844786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204152.844953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204153.872754:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 943, 7fc45fa20881
[1:1:0711/204153.905204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"885 0x7fc45d0db070 0x31a2941ff460 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204153.905500:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"885 0x7fc45d0db070 0x31a2941ff460 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204153.905832:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204153.906260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204153.906415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204153.906905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204153.907070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204153.907320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 979
[1:1:0711/204153.907504:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7fc45d0db070 0x31a293ae3160 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 943 0x7fc45d0db070 0x31a2937f5f60 
[1:1:0711/204154.314681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204154.315001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204154.463439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204154.464597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , d, (e){var t=e&&e.target?e.target.dom7EventData||[]:[];t.unshift(e),n.apply(this,t)}
[1:1:0711/204154.464818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204154.467787:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3300
[1:1:0711/204154.468021:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204154.468467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1005
[1:1:0711/204154.468745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7fc45d0db070 0x31a295c14260 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 961 0x7fc46c3ec960 0x31a29309bba0 0x31a29309bbb0 
[1:1:0711/204154.472078:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204154.490837:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204154.493245:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3210
[1:1:0711/204154.493413:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204154.493751:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1007
[1:1:0711/204154.493942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7fc45d0db070 0x31a2946e8a60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 961 0x7fc46c3ec960 0x31a29309bba0 0x31a29309bbb0 
[1:1:0711/204154.495547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204155.302249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204155.303327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204155.303592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[12993:12993:0711/204155.325927:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/204155.406622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204155.407069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204155.407181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204155.525765:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204155.526456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204155.526642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204155.663782:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 979, 7fc45fa20881
[1:1:0711/204155.693007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"943 0x7fc45d0db070 0x31a2937f5f60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204155.693228:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"943 0x7fc45d0db070 0x31a2937f5f60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204155.693478:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204155.693802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204155.693905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204155.694224:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204155.694337:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204155.694503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1037
[1:1:0711/204155.694627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1037 0x7fc45d0db070 0x31a29468ce60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 979 0x7fc45d0db070 0x31a293ae3160 
[1:1:0711/204155.811817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204155.812304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204155.812413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204156.043130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204156.043768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204156.043954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204156.073212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204156.074030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204156.074286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204156.219001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204156.219171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204156.949579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1037, 7fc45fa20881
[1:1:0711/204156.982736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"979 0x7fc45d0db070 0x31a293ae3160 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204156.982923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"979 0x7fc45d0db070 0x31a293ae3160 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204156.983149:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204156.983479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204156.983636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204156.983942:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204156.984038:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204156.984212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1059
[1:1:0711/204156.984323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1059 0x7fc45d0db070 0x31a2940cc660 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1037 0x7fc45d0db070 0x31a29468ce60 
[1:1:0711/204157.071718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204157.071893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204157.775970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204157.776306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204157.779817:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1059, 7fc45fa20881
[1:1:0711/204157.804988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1037 0x7fc45d0db070 0x31a29468ce60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204157.805190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1037 0x7fc45d0db070 0x31a29468ce60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204157.805405:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204157.805717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204157.805820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204157.806151:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204157.806249:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204157.806418:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1099
[1:1:0711/204157.806526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7fc45d0db070 0x31a29615bbe0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1059 0x7fc45d0db070 0x31a2940cc660 
[1:1:0711/204157.901876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1005, 7fc45fa20881
[1:1:0711/204157.940271:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"961 0x7fc46c3ec960 0x31a29309bba0 0x31a29309bbb0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204157.940681:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"961 0x7fc46c3ec960 0x31a29309bba0 0x31a29309bbb0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204157.941148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204157.941870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , (){e.params.autoplay.reverseDirection?e.params.loop?(e.loopFix(),e.slidePrev(e.params.speed,!0,!0),e
[1:1:0711/204157.942121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204158.096010:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204158.096313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204158.096770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1100
[1:1:0711/204158.097084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7fc45d0db070 0x31a292e174e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1005 0x7fc45d0db070 0x31a295c14260 
[1:1:0711/204158.278307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204158.278469:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204158.278644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1102
[1:1:0711/204158.278755:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1102 0x7fc45d0db070 0x31a292d50e60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1005 0x7fc45d0db070 0x31a295c14260 
[1:1:0711/204158.651405:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1007, 7fc45fa20881
[1:1:0711/204158.676684:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"961 0x7fc46c3ec960 0x31a29309bba0 0x31a29309bbb0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204158.676895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"961 0x7fc46c3ec960 0x31a29309bba0 0x31a29309bbb0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204158.677124:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204158.677523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , (){e.params.autoplay.reverseDirection?e.params.loop?(e.loopFix(),e.slidePrev(e.params.speed,!0,!0),e
[1:1:0711/204158.677631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204158.834380:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204158.834607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204158.834936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1112
[1:1:0711/204158.835126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7fc45d0db070 0x31a292bf80e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1007 0x7fc45d0db070 0x31a2946e8a60 
[1:1:0711/204159.061712:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204159.061927:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204159.062251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1113
[1:1:0711/204159.062458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1113 0x7fc45d0db070 0x31a292d50e60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1007 0x7fc45d0db070 0x31a2946e8a60 
[1:1:0711/204159.978863:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204159.979299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204159.979925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204200.168344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204200.168994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204200.169168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204200.332411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204200.332903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , l, (){n&&n()}
[1:1:0711/204200.333094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/204200.952141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204200.952331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204201.013572:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1099, 7fc45fa20881
[1:1:0711/204201.073110:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1059 0x7fc45d0db070 0x31a2940cc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204201.073497:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1059 0x7fc45d0db070 0x31a2940cc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204201.073967:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204201.074694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204201.074967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204201.075823:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204201.076037:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204201.076481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1141
[1:1:0711/204201.076745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1141 0x7fc45d0db070 0x31a2943376e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1099 0x7fc45d0db070 0x31a29615bbe0 
[1:1:0711/204201.739369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204201.739628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204201.923948:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1141, 7fc45fa20881
[1:1:0711/204201.973218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1099 0x7fc45d0db070 0x31a29615bbe0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204201.973537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1099 0x7fc45d0db070 0x31a29615bbe0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204201.973900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204201.974427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204201.974623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204201.975254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204201.975435:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204201.975756:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1161
[1:1:0711/204201.975977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1161 0x7fc45d0db070 0x31a295dd1960 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1141 0x7fc45d0db070 0x31a2943376e0 
[1:1:0711/204202.207882:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204202.208571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , d, (e){var t=e&&e.target?e.target.dom7EventData||[]:[];t.unshift(e),n.apply(this,t)}
[1:1:0711/204202.208753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204202.210816:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3210
[1:1:0711/204202.210977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204202.211295:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1168
[1:1:0711/204202.211514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1168 0x7fc45d0db070 0x31a2934f4160 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1153 0x7fc46c3ec960 0x31a2967d6880 0x31a2967d6890 
[1:1:0711/204202.213575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204202.231536:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204202.233834:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3210
[1:1:0711/204202.233995:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204202.234309:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1169
[1:1:0711/204202.234603:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7fc45d0db070 0x31a292bc00e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1153 0x7fc46c3ec960 0x31a2967d6880 0x31a2967d6890 
[1:1:0711/204202.236297:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204202.612283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204202.612461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204202.614261:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1161, 7fc45fa20881
[1:1:0711/204202.667011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1141 0x7fc45d0db070 0x31a2943376e0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204202.667208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1141 0x7fc45d0db070 0x31a2943376e0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204202.667407:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204202.667755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204202.667865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204202.668163:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204202.668259:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204202.668425:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1182
[1:1:0711/204202.668532:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1182 0x7fc45d0db070 0x31a29615ade0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1161 0x7fc45d0db070 0x31a295dd1960 
[1:1:0711/204203.237947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204203.238441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204203.281414:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1182, 7fc45fa20881
[1:1:0711/204203.340687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1161 0x7fc45d0db070 0x31a295dd1960 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204203.341038:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1161 0x7fc45d0db070 0x31a295dd1960 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204203.341410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204203.341972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204203.342203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204203.342859:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204203.343040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204203.343368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1208
[1:1:0711/204203.343560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1208 0x7fc45d0db070 0x31a295b43460 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1182 0x7fc45d0db070 0x31a29615ade0 
[1:1:0711/204204.124269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204204.124461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204204.155403:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204204.155830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , q.handle, (b){return"undefined"!=typeof r&&r.event.triggered!==b.type?r.event.dispatch.apply(a,arguments):void
[1:1:0711/204204.155946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204204.202781:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 5000
[1:1:0711/204204.203076:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.bayueju.com/, 1227
[1:1:0711/204204.203206:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1227 0x7fc45d0db070 0x31a292bdfc60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1207 0x7fc473765080 0x31a2943e0740 1 0 0x31a2943e0758 
[1:1:0711/204204.212721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.bayueju.com/"
[1:1:0711/204204.213869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.bayueju.com/"
[1:1:0711/204204.214553:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c32f0
[1:1:0711/204204.214656:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204204.214820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1228
[1:1:0711/204204.214940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1228 0x7fc45d0db070 0x31a29615be60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1207 0x7fc473765080 0x31a2943e0740 1 0 0x31a2943e0758 
[1:1:0711/204204.540587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , document.readyState
[1:1:0711/204204.540825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204204.772334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1228, 7fc45fa20881
[1:1:0711/204204.830678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1207 0x7fc473765080 0x31a2943e0740 1 0 0x31a2943e0758 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204204.831110:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1207 0x7fc473765080 0x31a2943e0740 1 0 0x31a2943e0758 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204204.831605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204204.832257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204204.832689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204204.833463:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204204.833652:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204204.834037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1261
[1:1:0711/204204.834272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1261 0x7fc45d0db070 0x31a292b43460 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1228 0x7fc45d0db070 0x31a29615be60 
[1:1:0711/204205.645649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1261, 7fc45fa20881
[1:1:0711/204205.696249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1228 0x7fc45d0db070 0x31a29615be60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204205.696544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1228 0x7fc45d0db070 0x31a29615be60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204205.696919:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204205.697414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204205.697659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204205.698277:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204205.698426:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204205.698740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1283
[1:1:0711/204205.698922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1283 0x7fc45d0db070 0x31a2940cbce0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1261 0x7fc45d0db070 0x31a292b43460 
[1:1:0711/204205.811567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1168, 7fc45fa20881
[1:1:0711/204205.876987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1153 0x7fc46c3ec960 0x31a2967d6880 0x31a2967d6890 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204205.877301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1153 0x7fc46c3ec960 0x31a2967d6880 0x31a2967d6890 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204205.877684:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204205.878267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , (){e.params.autoplay.reverseDirection?e.params.loop?(e.loopFix(),e.slidePrev(e.params.speed,!0,!0),e
[1:1:0711/204205.878441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204205.968550:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204205.968767:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204205.969009:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1291
[1:1:0711/204205.969129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1291 0x7fc45d0db070 0x31a29350b5e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1168 0x7fc45d0db070 0x31a2934f4160 
[1:1:0711/204206.166931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204206.167142:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204206.167443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1293
[1:1:0711/204206.167624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1293 0x7fc45d0db070 0x31a29643b660 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1168 0x7fc45d0db070 0x31a2934f4160 
[1:1:0711/204206.532414:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1169, 7fc45fa20881
[1:1:0711/204206.596194:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1153 0x7fc46c3ec960 0x31a2967d6880 0x31a2967d6890 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204206.596580:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1153 0x7fc46c3ec960 0x31a2967d6880 0x31a2967d6890 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204206.597059:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204206.597769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , , (){e.params.autoplay.reverseDirection?e.params.loop?(e.loopFix(),e.slidePrev(e.params.speed,!0,!0),e
[1:1:0711/204206.597996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204206.795848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204206.796074:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204206.796433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1299
[1:1:0711/204206.796626:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1299 0x7fc45d0db070 0x31a29356c1e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1169 0x7fc45d0db070 0x31a292bc00e0 
[1:1:0711/204207.031912:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204207.032130:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204207.032480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1300
[1:1:0711/204207.032671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1300 0x7fc45d0db070 0x31a294337860 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1169 0x7fc45d0db070 0x31a292bc00e0 
[1:1:0711/204207.633789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1283, 7fc45fa20881
[1:1:0711/204207.686202:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1261 0x7fc45d0db070 0x31a292b43460 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204207.686505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1261 0x7fc45d0db070 0x31a292b43460 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204207.686901:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204207.687407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204207.687610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204207.688229:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204207.688385:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204207.688769:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1311
[1:1:0711/204207.688955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1311 0x7fc45d0db070 0x31a2946e28e0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1283 0x7fc45d0db070 0x31a2940cbce0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/204208.191642:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1311, 7fc45fa20881
[1:1:0711/204208.234325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1283 0x7fc45d0db070 0x31a2940cbce0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204208.234662:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1283 0x7fc45d0db070 0x31a2940cbce0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204208.235094:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204208.235651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204208.235853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204208.236530:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204208.236800:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204208.237132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1326
[1:1:0711/204208.237327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7fc45d0db070 0x31a2946eea60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1311 0x7fc45d0db070 0x31a2946e28e0 
[1:1:0711/204208.358287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204208.358753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , d, (e){var t=e&&e.target?e.target.dom7EventData||[]:[];t.unshift(e),n.apply(this,t)}
[1:1:0711/204208.358866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204208.359735:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3210
[1:1:0711/204208.359870:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204208.360038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1329
[1:1:0711/204208.360144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7fc45d0db070 0x31a29415aee0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1327 0x7fc46c3ec960 0x31a294ada920 0x31a294ada930 
[1:1:0711/204208.360922:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204208.367674:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204208.370464:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xe736ee229c8, 0x31a2917c3210
[1:1:0711/204208.370662:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 3000
[1:1:0711/204208.370984:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1330
[1:1:0711/204208.371100:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1330 0x7fc45d0db070 0x31a295fd8f60 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1327 0x7fc46c3ec960 0x31a294ada920 0x31a294ada930 
[1:1:0711/204208.371879:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://www.bayueju.com/"
[1:1:0711/204208.404803:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1326, 7fc45fa20881
[1:1:0711/204208.435270:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1311 0x7fc45d0db070 0x31a2946e28e0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204208.435572:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1311 0x7fc45d0db070 0x31a2946e28e0 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204208.436033:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204208.436548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204208.436738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204208.437372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204208.437526:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204208.437860:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1335
[1:1:0711/204208.438050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1335 0x7fc45d0db070 0x31a2935cc660 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1326 0x7fc45d0db070 0x31a2946eea60 
[1:1:0711/204208.860127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1335, 7fc45fa20881
[1:1:0711/204208.890622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1326 0x7fc45d0db070 0x31a2946eea60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204208.890927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1326 0x7fc45d0db070 0x31a2946eea60 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204208.891251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204208.891666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204208.891827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204208.892315:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204208.892450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204208.892686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1351
[1:1:0711/204208.892838:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1351 0x7fc45d0db070 0x31a29653d860 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1335 0x7fc45d0db070 0x31a2935cc660 
[1:1:0711/204209.073641:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1351, 7fc45fa20881
[1:1:0711/204209.092243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1335 0x7fc45d0db070 0x31a2935cc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204209.092469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1335 0x7fc45d0db070 0x31a2935cc660 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204209.092673:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204209.093000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204209.093106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204209.093407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204209.093507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204209.093678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1356
[1:1:0711/204209.093786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1356 0x7fc45d0db070 0x31a2964bc760 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1351 0x7fc45d0db070 0x31a29653d860 
[1:1:0711/204209.337835:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1356, 7fc45fa20881
[1:1:0711/204209.392250:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1351 0x7fc45d0db070 0x31a29653d860 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204209.392586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1351 0x7fc45d0db070 0x31a29653d860 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204209.392942:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204209.393476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/204209.393663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
[1:1:0711/204209.398204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xe736ee229c8, 0x31a2917c3150
[1:1:0711/204209.398367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.bayueju.com/", 100
[1:1:0711/204209.402657:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.bayueju.com/, 1365
[1:1:0711/204209.402852:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1365 0x7fc45d0db070 0x31a292b67ee0 , 5:3_http://www.bayueju.com/, 1, -5:3_http://www.bayueju.com/, 1356 0x7fc45d0db070 0x31a2964bc760 
[1:1:0711/204209.404876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.bayueju.com/, 1227, 7fc45fa208db
[1:1:0711/204209.459859:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0b7c822c2860","ptid":"1207 0x7fc473765080 0x31a2943e0740 1 0 0x31a2943e0758 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204209.460216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.bayueju.com/","ptid":"1207 0x7fc473765080 0x31a2943e0740 1 0 0x31a2943e0758 ","rf":"5:3_http://www.bayueju.com/"}
[1:1:0711/204209.460608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.bayueju.com/, 1368
[1:1:0711/204209.460797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1368 0x7fc45d0db070 0x31a291e23e60 , 5:3_http://www.bayueju.com/, 0, , 1227 0x7fc45d0db070 0x31a292bdfc60 
[1:1:0711/204209.461122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.bayueju.com/"
[1:1:0711/204209.461601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.bayueju.com/, 0b7c822c2860, , e, (){return a.apply(b||this,d.concat(f.call(arguments)))}
[1:1:0711/204209.461772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.bayueju.com/", "www.bayueju.com", 3, 1, , , 0
