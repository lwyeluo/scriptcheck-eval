[0712/120813.490454:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120813.490752:INFO:switcher_clone.cc(787)] backtrace rip is 7f224242a891
[0712/120814.566748:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120814.567030:INFO:switcher_clone.cc(787)] backtrace rip is 7f13f0294891
[1:1:0712/120814.571305:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/120814.571487:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/120814.576739:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[7865:7865:0712/120816.133277:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/120816.196088:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120816.196494:INFO:switcher_clone.cc(787)] backtrace rip is 7f0bed6be891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/9a13a02f-e512-4851-9112-0c3c12f1355d
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[7897:7897:0712/120816.435854:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7897
[7909:7909:0712/120816.436276:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7909
[7865:7865:0712/120816.593067:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[7865:7895:0712/120816.593922:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/120816.594133:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/120816.594438:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/120816.595084:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/120816.595270:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/120816.598482:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x23321bec, 1
[1:1:0712/120816.598833:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3cc42445, 0
[1:1:0712/120816.598998:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1e084f5, 3
[1:1:0712/120816.599167:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x23755da3, 2
[1:1:0712/120816.599367:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4524ffffffc43c ffffffec1b3223 ffffffa35d7523 fffffff5ffffff84ffffffe001 , 10104, 4
[1:1:0712/120816.600326:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7865:7895:0712/120816.600647:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGE$�<�2#�]u#���-�6
[7865:7895:0712/120816.600727:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is E$�<�2#�]u#���8n-�6
[1:1:0712/120816.600639:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13ee4cf0a0, 3
[1:1:0712/120816.600831:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13ee65a080, 2
[7865:7895:0712/120816.600995:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/120816.600988:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13d831dd20, -2
[7865:7895:0712/120816.601062:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7917, 4, 4524c43c ec1b3223 a35d7523 f584e001 
[1:1:0712/120816.621266:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/120816.622178:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 23755da3
[1:1:0712/120816.623189:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 23755da3
[1:1:0712/120816.624844:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 23755da3
[1:1:0712/120816.626363:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.626592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.626782:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.626959:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.627613:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 23755da3
[1:1:0712/120816.627942:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f13f02947ba
[1:1:0712/120816.628077:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f13f028bdef, 7f13f029477a, 7f13f02960cf
[1:1:0712/120816.630683:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 23755da3
[1:1:0712/120816.630981:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 23755da3
[1:1:0712/120816.631534:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 23755da3
[1:1:0712/120816.632705:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.632820:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.632922:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.633022:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23755da3
[1:1:0712/120816.633541:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 23755da3
[1:1:0712/120816.633730:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f13f02947ba
[1:1:0712/120816.633813:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f13f028bdef, 7f13f029477a, 7f13f02960cf
[1:1:0712/120816.636008:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/120816.636296:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/120816.636429:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaedce138, 0x7ffcaedce0b8)
[1:1:0712/120816.651816:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/120816.657677:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[7865:7865:0712/120817.175265:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7865:7865:0712/120817.176245:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7865:7876:0712/120817.197523:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[7865:7876:0712/120817.197676:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[7865:7865:0712/120817.197822:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[7865:7865:0712/120817.197915:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[7865:7865:0712/120817.198088:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,7917, 4
[1:7:0712/120817.199977:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[7865:7887:0712/120817.282655:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/120817.372510:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x33b79e5a7220
[1:1:0712/120817.374708:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/120817.846282:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[7865:7865:0712/120820.093932:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[7865:7865:0712/120820.094083:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/120820.145473:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120820.149178:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120821.261373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f5da43a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/120821.261721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120821.276845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f5da43a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/120821.277153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120821.324375:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120821.480547:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120821.480894:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120821.775861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120821.786639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f5da43a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/120821.787023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120821.821839:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120821.832030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f5da43a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/120821.832263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120821.837344:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/120821.841310:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x33b79e5a5e20
[1:1:0712/120821.841518:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7865:7865:0712/120821.852852:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[7865:7865:0712/120821.866391:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[7865:7865:0712/120821.898478:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[7865:7865:0712/120821.898640:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[7865:7865:0712/120821.920243:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/120821.920715:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120822.925461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f13d9ef82e0 0x33b79e806fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120822.926852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f5da43a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/120822.927078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120822.928603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7865:7865:0712/120822.996763:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/120822.998340:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x33b79e5a6820
[1:1:0712/120822.998547:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[7865:7865:0712/120823.005625:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/120823.015254:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/120823.015469:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[7865:7865:0712/120823.030134:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[7865:7865:0712/120823.067682:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7865:7865:0712/120823.071564:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7865:7876:0712/120823.079105:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[7865:7876:0712/120823.079205:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[7865:7865:0712/120823.079436:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[7865:7865:0712/120823.079529:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[7865:7865:0712/120823.079692:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,7917, 4
[1:7:0712/120823.081751:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/120823.484509:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/120823.798533:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f13d9ef82e0 0x33b79e95df60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120823.799594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f5da43a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/120823.799910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120823.800746:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7865:7865:0712/120823.870550:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[7865:7895:0712/120823.870972:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/120823.871157:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/120823.871384:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/120823.871758:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/120823.871898:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/120823.874889:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120823.875375:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x29fbd8c6, 1
[1:1:0712/120823.875986:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3414f105, 0
[1:1:0712/120823.876266:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1fd0a13d, 3
[1:1:0712/120823.876633:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2557018f, 2
[1:1:0712/120823.876895:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 05fffffff11434 ffffffc6ffffffd8fffffffb29 ffffff8f015725 3dffffffa1ffffffd01f , 10104, 5
[1:1:0712/120823.878689:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7865:7895:0712/120823.879092:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�4���)�W%=���/�6
[7865:7895:0712/120823.879219:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �4���)�W%=��8n�/�6
[1:1:0712/120823.879464:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13ee4cf0a0, 3
[7865:7895:0712/120823.879723:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7962, 5, 05f11434 c6d8fb29 8f015725 3da1d01f 
[1:1:0712/120823.879782:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13ee65a080, 2
[1:1:0712/120823.880134:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13d831dd20, -2
[1:1:0712/120823.898257:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/120823.898483:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2557018f
[1:1:0712/120823.898663:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2557018f
[1:1:0712/120823.898919:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2557018f
[1:1:0712/120823.899367:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.899472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.899565:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.899661:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.899889:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2557018f
[1:1:0712/120823.900018:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f13f02947ba
[1:1:0712/120823.900095:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f13f028bdef, 7f13f029477a, 7f13f02960cf
[1:1:0712/120823.901534:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2557018f
[1:1:0712/120823.901694:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2557018f
[1:1:0712/120823.901958:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2557018f
[1:1:0712/120823.902621:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.902744:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.902851:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.902948:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2557018f
[1:1:0712/120823.903650:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2557018f
[1:1:0712/120823.904118:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f13f02947ba
[1:1:0712/120823.904312:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f13f028bdef, 7f13f029477a, 7f13f02960cf
[7865:7865:0712/120823.906581:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[7865:7865:0712/120823.906977:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/120823.913842:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/120823.914456:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/120823.914647:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaedce138, 0x7ffcaedce0b8)
[1:1:0712/120823.929826:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/120823.935145:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/120824.141029:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x33b79e589220
[1:1:0712/120824.141294:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/120824.167521:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120824.866090:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120824.866369:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[7865:7865:0712/120825.018373:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7865:7865:0712/120825.057340:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[7865:7895:0712/120825.057870:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/120825.058112:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/120825.058341:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/120825.058752:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/120825.058903:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/120825.061672:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3a8c35ec, 1
[1:1:0712/120825.062011:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x238e9eca, 0
[1:1:0712/120825.062216:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x385515ef, 3
[1:1:0712/120825.062393:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb9515fd, 2
[1:1:0712/120825.062543:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcaffffff9effffff8e23 ffffffec35ffffff8c3a fffffffd15ffffff950b ffffffef155538 , 10104, 6
[1:1:0712/120825.063556:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7865:7895:0712/120825.063845:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGʞ�#�5�:���U8�/�6
[7865:7895:0712/120825.063921:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ʞ�#�5�:���U8!�/�6
[1:1:0712/120825.064061:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13ee4cf0a0, 3
[7865:7895:0712/120825.064245:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7978, 6, ca9e8e23 ec358c3a fd15950b ef155538 
[1:1:0712/120825.064242:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13ee65a080, 2
[1:1:0712/120825.064405:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f13d831dd20, -2
[1:1:0712/120825.086854:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/120825.087176:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b9515fd
[1:1:0712/120825.087461:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b9515fd
[1:1:0712/120825.088056:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b9515fd
[1:1:0712/120825.089510:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.089723:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.089924:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.090100:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.090776:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b9515fd
[1:1:0712/120825.091062:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f13f02947ba
[1:1:0712/120825.091199:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f13f028bdef, 7f13f029477a, 7f13f02960cf
[7865:7865:0712/120825.096476:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/120825.096999:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b9515fd
[1:1:0712/120825.097374:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b9515fd
[1:1:0712/120825.098114:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b9515fd
[1:1:0712/120825.100146:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.100365:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.100560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.100887:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b9515fd
[1:1:0712/120825.102478:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b9515fd
[1:1:0712/120825.102973:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f13f02947ba
[1:1:0712/120825.103152:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f13f028bdef, 7f13f029477a, 7f13f02960cf
[1:1:0712/120825.112789:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/120825.113365:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/120825.113516:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaedce138, 0x7ffcaedce0b8)
[1:1:0712/120825.129843:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/120825.135327:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[7865:7876:0712/120825.140203:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[7865:7876:0712/120825.140304:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[7865:7865:0712/120825.140497:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://ali213.fhyx.com/
[7865:7865:0712/120825.140598:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://ali213.fhyx.com/, https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3, 1
[7865:7865:0712/120825.140803:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://ali213.fhyx.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 19:08:25 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=6e47kad1son2jkuicaedik3qg7; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Strict-Transport-Security: max-age=31536000 Content-Encoding: gzip  ,0, 6
[3:3:0712/120825.146586:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/120825.212492:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/120825.294552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120825.298206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f5da44ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/120825.298556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120825.306946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120825.329185:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x33b79e59f220
[1:1:0712/120825.329504:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/120825.426501:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://ali213.fhyx.com/
[7865:7865:0712/120825.690458:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://ali213.fhyx.com/, https://ali213.fhyx.com/, 1
[7865:7865:0712/120825.690591:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://ali213.fhyx.com/, https://ali213.fhyx.com
[1:1:0712/120825.739262:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120825.803258:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120825.872248:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120825.873075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f5da43a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/120825.873305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120825.912851:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120825.913108:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120826.714670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7f13d7fd0070 0x33b79e7237e0 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120826.716796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , 
if(typeof jQuery == 'undefined') document.write(unescape("%3Cscript src='//static.fhyx.com/js/lib/j
[1:1:0712/120826.717066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/120827.028548:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120827.382844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7f13d8338bd0 0x33b79e76e6d8 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120827.394713:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120827.400491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/120827.400803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
		remove user.f_9d8b5bf -> 0
[1:1:0712/120827.784442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7f13d8338bd0 0x33b79e76e6d8 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120827.794890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7f13d8338bd0 0x33b79e76e6d8 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120827.842404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7f13d8338bd0 0x33b79e76e6d8 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120827.903028:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.156057, 91, 1
[1:1:0712/120827.903286:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120828.171697:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120828.171955:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120828.172749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f13d7fd0070 0x33b79e9090e0 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120828.173667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , 
        var http_host='ali213.fhyx.com';
        var redirecturl='https://ali213.fhyx.com%2Flist%2F
[1:1:0712/120828.173895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120828.179580:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f13d7fd0070 0x33b79e9090e0 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120828.694123:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.522024, 1, 0
[1:1:0712/120828.694389:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120829.415148:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120829.417222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , r, (e,i){var u,f,l,c,h;try{if(r&&(i||a.readyState===4)){r=t,o&&(a.onreadystatechange=v.noop,Bn&&delete 
[1:1:0712/120829.417450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120829.418714:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120829.421296:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120829.422061:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1bbcefd4b368
[1:1:0712/120829.487451:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120829.487721:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120829.635539:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.147633, 922, 1
[1:1:0712/120829.635864:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120830.189001:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120830.189268:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120830.192418:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 394 0x7f13d7fd0070 0x33b79ecf15e0 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120830.193359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , var startQQ="";
$.ajax({   
     type:"GET",
     async:false,
     url: "https://wpd.b.qq.com/c
[1:1:0712/120830.193585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120830.248755:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0593328, 136, 1
[1:1:0712/120830.249031:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120830.556197:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120830.556494:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120830.561589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 408 0x7f13d7fd0070 0x33b79ed46360 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120830.568468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , (function(){function p(){this.c="1254492981";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/120830.568696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120830.986127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423, "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120830.988227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/120830.988472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120831.004687:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423, "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120831.017113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423, "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120831.252325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120834.569721:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120834.570223:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120834.570613:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120834.571012:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120834.571418:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120835.477405:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120835.478199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/120835.478431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120835.526086:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120835.526852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/120835.527074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120835.579320:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 461 0x7f13d9ef82e0 0x33b79e90d360 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120835.585950:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120835.586489:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120835.593236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , (function(){var h={},mt={},c={id:"9aa627ea223ce1eccc4cea6a84d26b80",dm:["fhyx.com","shop.ali213.com"
[1:1:0712/120835.593547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120835.623485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e148
[1:1:0712/120835.623740:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120835.624192:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 478
[1:1:0712/120835.624443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 478 0x7f13d7fd0070 0x33b79e7272e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 461 0x7f13d9ef82e0 0x33b79e90d360 
[7865:7865:0712/120854.608359:ERROR:node_channel.cc(904)] Dropping message on closed channel.
[7865:7865:0712/120854.788961:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1254492981&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/stat.php?id=1254492981&web_id=1254492981 (17)
[7865:7865:0712/120854.792901:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1254492981&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/stat.php?id=1254492981&web_id=1254492981 (17)
[7865:7865:0712/120854.812785:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/120854.863745:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/120855.001577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 462 0x7f13d9ef82e0 0x33b79ed9fd60 , "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120855.002861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , jsoncallback({"r":0,"data":{"sign":"tencent:\/\/message\/?Menu=yes&uin=938000756&Service=58&SigT=07A
[1:1:0712/120855.005386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120855.006529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120855.290026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/120855.290296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120856.176439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 478, 7f13da915881
[1:1:0712/120856.190988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"461 0x7f13d9ef82e0 0x33b79e90d360 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120856.191339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"461 0x7f13d9ef82e0 0x33b79e90d360 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120856.191798:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120856.192446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120856.192670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120856.193530:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120856.193749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120856.194198:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 541
[1:1:0712/120856.194867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 541 0x7f13d7fd0070 0x33b79eea93e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 478 0x7f13d7fd0070 0x33b79e7272e0 
[1:1:0712/120856.622037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , document.readyState
[1:1:0712/120856.622454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120856.841056:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 541, 7f13da915881
[1:1:0712/120856.872397:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"478 0x7f13d7fd0070 0x33b79e7272e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120856.872779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"478 0x7f13d7fd0070 0x33b79e7272e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120856.873191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120856.873846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120856.874080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120856.874847:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120856.875051:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120856.875517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 583
[1:1:0712/120856.875749:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7f13d7fd0070 0x33b79ea452e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 541 0x7f13d7fd0070 0x33b79eea93e0 
[1:1:0712/120856.914799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120856.915590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/120856.915869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120856.925689:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120856.926450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120856.986687:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120856.990235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120856.991788:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e2f0
[1:1:0712/120856.992425:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120856.992892:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 589
[1:1:0712/120856.993149:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 589 0x7f13d7fd0070 0x33b79efe1960 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 549 0x7f13d7fd0070 0x33b79ec80160 
[1:1:0712/120857.344464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , , document.readyState
[1:1:0712/120857.344748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120857.903959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 589, 7f13da915881
[1:1:0712/120857.930737:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"549 0x7f13d7fd0070 0x33b79ec80160 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120857.931201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"549 0x7f13d7fd0070 0x33b79ec80160 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120857.931628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120857.932363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120857.932597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120857.933400:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120857.933640:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120857.934301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 608
[1:1:0712/120857.934571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f13d7fd0070 0x33b7a06e77e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 589 0x7f13d7fd0070 0x33b79efe1960 
[1:1:0712/120857.962750:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120857.963665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , u, (e){return typeof v=="undefined"||!!e&&v.event.triggered===e.type?t:v.event.dispatch.apply(u.elem,ar
[1:1:0712/120857.963940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120858.376473:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 608, 7f13da915881
[1:1:0712/120858.402936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"589 0x7f13d7fd0070 0x33b79efe1960 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.403314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"589 0x7f13d7fd0070 0x33b79efe1960 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.403683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120858.404326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120858.404511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120858.405237:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120858.405429:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120858.405848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 622
[1:1:0712/120858.406039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f13d7fd0070 0x33b7a00c89e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 608 0x7f13d7fd0070 0x33b7a06e77e0 
[1:1:0712/120858.508796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 622, 7f13da915881
[1:1:0712/120858.520679:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"608 0x7f13d7fd0070 0x33b7a06e77e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.520903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"608 0x7f13d7fd0070 0x33b7a06e77e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.521111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120858.521476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120858.521607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120858.521953:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120858.522056:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120858.522259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 634
[1:1:0712/120858.522403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7f13d7fd0070 0x33b7a06e0ce0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 622 0x7f13d7fd0070 0x33b7a00c89e0 
[1:1:0712/120858.635602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 634, 7f13da915881
[1:1:0712/120858.662850:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"622 0x7f13d7fd0070 0x33b7a00c89e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.663188:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"622 0x7f13d7fd0070 0x33b7a00c89e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.663566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120858.664177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120858.664398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120858.670206:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120858.670430:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120858.670875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 642
[1:1:0712/120858.671071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 642 0x7f13d7fd0070 0x33b7a02f3ae0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 634 0x7f13d7fd0070 0x33b7a06e0ce0 
[1:1:0712/120858.785426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 642, 7f13da915881
[1:1:0712/120858.812755:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"634 0x7f13d7fd0070 0x33b7a06e0ce0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.813107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"634 0x7f13d7fd0070 0x33b7a06e0ce0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.813481:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120858.814097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120858.814289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120858.815046:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120858.815211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120858.815647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 649
[1:1:0712/120858.815847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f13d7fd0070 0x33b7a0286be0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 642 0x7f13d7fd0070 0x33b7a02f3ae0 
[1:1:0712/120858.944746:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 649, 7f13da915881
[1:1:0712/120858.970124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"642 0x7f13d7fd0070 0x33b7a02f3ae0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.970587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"642 0x7f13d7fd0070 0x33b7a02f3ae0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120858.971040:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120858.971819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120858.972061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120858.973033:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120858.973236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120858.973778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 656
[1:1:0712/120858.974026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f13d7fd0070 0x33b79e5c0860 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 649 0x7f13d7fd0070 0x33b7a0286be0 
[1:1:0712/120859.110628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 656, 7f13da915881
[1:1:0712/120859.139549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"649 0x7f13d7fd0070 0x33b7a0286be0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.139983:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"649 0x7f13d7fd0070 0x33b7a0286be0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.140422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120859.141245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120859.141504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120859.142432:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120859.142654:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120859.143177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 658
[1:1:0712/120859.143425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7f13d7fd0070 0x33b7a06fa160 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 656 0x7f13d7fd0070 0x33b79e5c0860 
[1:1:0712/120859.260001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 658, 7f13da915881
[1:1:0712/120859.273018:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"656 0x7f13d7fd0070 0x33b79e5c0860 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.273303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"656 0x7f13d7fd0070 0x33b79e5c0860 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.273597:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120859.274054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120859.274204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120859.274706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120859.274845:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120859.275118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 661
[1:1:0712/120859.275275:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7f13d7fd0070 0x33b79e5c1a60 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 658 0x7f13d7fd0070 0x33b7a06fa160 
[1:1:0712/120859.413343:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 661, 7f13da915881
[1:1:0712/120859.447027:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"658 0x7f13d7fd0070 0x33b7a06fa160 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.447261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"658 0x7f13d7fd0070 0x33b7a06fa160 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.447479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120859.447858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120859.447972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120859.448310:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120859.448410:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120859.448652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 663
[1:1:0712/120859.448776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f13d7fd0070 0x33b79e58bae0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 661 0x7f13d7fd0070 0x33b79e5c1a60 
[1:1:0712/120859.578112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 663, 7f13da915881
[1:1:0712/120859.606129:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"661 0x7f13d7fd0070 0x33b79e5c1a60 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.606474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"661 0x7f13d7fd0070 0x33b79e5c1a60 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.606857:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120859.607463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120859.607662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120859.608397:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120859.608556:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120859.609036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 665
[1:1:0712/120859.609239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7f13d7fd0070 0x33b7a06eece0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 663 0x7f13d7fd0070 0x33b79e58bae0 
[1:1:0712/120859.767349:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 665, 7f13da915881
[1:1:0712/120859.797698:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"663 0x7f13d7fd0070 0x33b79e58bae0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.798161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"663 0x7f13d7fd0070 0x33b79e58bae0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.798627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120859.799422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120859.799614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120859.800411:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120859.800579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120859.801081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 667
[1:1:0712/120859.801285:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f13d7fd0070 0x33b79fa7e8e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 665 0x7f13d7fd0070 0x33b7a06eece0 
[1:1:0712/120859.936042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 667, 7f13da915881
[1:1:0712/120859.964070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"665 0x7f13d7fd0070 0x33b7a06eece0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.964414:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"665 0x7f13d7fd0070 0x33b7a06eece0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120859.964787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120859.965405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120859.965582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120859.966395:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120859.966557:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120859.966851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 669
[1:1:0712/120859.966981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f13d7fd0070 0x33b7a0306ee0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 667 0x7f13d7fd0070 0x33b79fa7e8e0 
[1:1:0712/120900.097614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 669, 7f13da915881
[1:1:0712/120900.126249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"667 0x7f13d7fd0070 0x33b79fa7e8e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.126610:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"667 0x7f13d7fd0070 0x33b79fa7e8e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.127002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120900.127608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120900.127852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120900.128589:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120900.128767:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120900.129188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 671
[1:1:0712/120900.129381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 671 0x7f13d7fd0070 0x33b7a02f0ce0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 669 0x7f13d7fd0070 0x33b7a0306ee0 
[1:1:0712/120900.264369:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 671, 7f13da915881
[1:1:0712/120900.273572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"669 0x7f13d7fd0070 0x33b7a0306ee0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.273788:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"669 0x7f13d7fd0070 0x33b7a0306ee0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.274001:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120900.274324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120900.274432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120900.274781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120900.274944:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120900.275368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 673
[1:1:0712/120900.275564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f13d7fd0070 0x33b7a0724760 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 671 0x7f13d7fd0070 0x33b7a02f0ce0 
[1:1:0712/120900.413407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 673, 7f13da915881
[1:1:0712/120900.437506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"671 0x7f13d7fd0070 0x33b7a02f0ce0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.437903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"671 0x7f13d7fd0070 0x33b7a02f0ce0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.438251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120900.438697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120900.438876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120900.439356:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120900.439495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120900.439766:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 675
[1:1:0712/120900.440020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7f13d7fd0070 0x33b79e579d60 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 673 0x7f13d7fd0070 0x33b7a0724760 
[1:1:0712/120900.555914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 675, 7f13da915881
[1:1:0712/120900.565225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"673 0x7f13d7fd0070 0x33b7a0724760 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.565415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"673 0x7f13d7fd0070 0x33b7a0724760 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.565622:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120900.566011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120900.566139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120900.566479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120900.566582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120900.566786:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 677
[1:1:0712/120900.566925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7f13d7fd0070 0x33b7a06e75e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 675 0x7f13d7fd0070 0x33b79e579d60 
[1:1:0712/120900.702127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 677, 7f13da915881
[1:1:0712/120900.730443:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"675 0x7f13d7fd0070 0x33b79e579d60 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.730807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"675 0x7f13d7fd0070 0x33b79e579d60 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.731247:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120900.731852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120900.732094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120900.732823:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120900.733015:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120900.733430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 679
[1:1:0712/120900.733621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f13d7fd0070 0x33b79ed9dce0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 677 0x7f13d7fd0070 0x33b7a06e75e0 
[1:1:0712/120900.863880:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 679, 7f13da915881
[1:1:0712/120900.874704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"677 0x7f13d7fd0070 0x33b7a06e75e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.874960:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"677 0x7f13d7fd0070 0x33b7a06e75e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120900.875182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120900.875521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120900.875630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120900.875996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120900.876115:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120900.876311:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 681
[1:1:0712/120900.876421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f13d7fd0070 0x33b79e597260 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 679 0x7f13d7fd0070 0x33b79ed9dce0 
[1:1:0712/120901.011855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 681, 7f13da915881
[1:1:0712/120901.040256:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"679 0x7f13d7fd0070 0x33b79ed9dce0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.040610:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"679 0x7f13d7fd0070 0x33b79ed9dce0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.040984:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120901.041600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120901.041779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120901.042542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120901.042706:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120901.043143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 683
[1:1:0712/120901.043343:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7f13d7fd0070 0x33b79e5c1260 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 681 0x7f13d7fd0070 0x33b79e597260 
[1:1:0712/120901.173552:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 683, 7f13da915881
[1:1:0712/120901.184699:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"681 0x7f13d7fd0070 0x33b79e597260 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.184930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"681 0x7f13d7fd0070 0x33b79e597260 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.185165:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120901.185502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120901.185619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120901.185955:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120901.186096:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120901.186300:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 685
[1:1:0712/120901.186412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7f13d7fd0070 0x33b7a071f2e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 683 0x7f13d7fd0070 0x33b79e5c1260 
[1:1:0712/120901.317671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 685, 7f13da915881
[1:1:0712/120901.347815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"683 0x7f13d7fd0070 0x33b79e5c1260 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.348227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"683 0x7f13d7fd0070 0x33b79e5c1260 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.348593:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120901.349214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120901.349396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120901.350156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120901.350320:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120901.350735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 687
[1:1:0712/120901.350925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f13d7fd0070 0x33b79e5b3860 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 685 0x7f13d7fd0070 0x33b7a071f2e0 
[1:1:0712/120901.483058:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 687, 7f13da915881
[1:1:0712/120901.514039:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"685 0x7f13d7fd0070 0x33b7a071f2e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.514423:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"685 0x7f13d7fd0070 0x33b7a071f2e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.514781:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120901.515440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120901.515623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120901.516424:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120901.516639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120901.517203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 689
[1:1:0712/120901.517401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f13d7fd0070 0x33b79e5aa8e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 687 0x7f13d7fd0070 0x33b79e5b3860 
[1:1:0712/120901.649811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 689, 7f13da915881
[1:1:0712/120901.679652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"687 0x7f13d7fd0070 0x33b79e5b3860 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.679978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"687 0x7f13d7fd0070 0x33b79e5b3860 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.680409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120901.681027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120901.681243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120901.681983:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120901.682179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120901.682600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 691
[1:1:0712/120901.682795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f13d7fd0070 0x33b7a0230be0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 689 0x7f13d7fd0070 0x33b79e5aa8e0 
[1:1:0712/120901.815361:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 691, 7f13da915881
[1:1:0712/120901.844101:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"689 0x7f13d7fd0070 0x33b79e5aa8e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.844481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"689 0x7f13d7fd0070 0x33b79e5aa8e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120901.844837:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120901.845468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120901.845663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120901.846427:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120901.846590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120901.847005:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 693
[1:1:0712/120901.847220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f13d7fd0070 0x33b7a01d61e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 691 0x7f13d7fd0070 0x33b7a0230be0 
[1:1:0712/120901.980943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 693, 7f13da915881
[1:1:0712/120902.004440:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"691 0x7f13d7fd0070 0x33b7a0230be0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120902.004687:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"691 0x7f13d7fd0070 0x33b7a0230be0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120902.004902:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120902.005254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120902.005369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120902.005708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120902.005809:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120902.006014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 695
[1:1:0712/120902.006127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f13d7fd0070 0x33b79e443160 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 693 0x7f13d7fd0070 0x33b7a01d61e0 
[1:1:0712/120902.133291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 695, 7f13da915881
[1:1:0712/120902.163835:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"693 0x7f13d7fd0070 0x33b7a01d61e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120902.164203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"693 0x7f13d7fd0070 0x33b7a01d61e0 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120902.164641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120902.165303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120902.165509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120902.166308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120902.166484:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120902.166920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 697
[1:1:0712/120902.167137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7f13d7fd0070 0x33b7a072d8e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 695 0x7f13d7fd0070 0x33b79e443160 
[1:1:0712/120902.302688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 697, 7f13da915881
[1:1:0712/120902.333803:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"255c7b822860","ptid":"695 0x7f13d7fd0070 0x33b79e443160 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120902.334098:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://ali213.fhyx.com/","ptid":"695 0x7f13d7fd0070 0x33b79e443160 ","rf":"6:3_https://ali213.fhyx.com/"}
[1:1:0712/120902.334406:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3"
[1:1:0712/120902.334820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://ali213.fhyx.com/, 255c7b822860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/120902.334961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", "ali213.fhyx.com", 3, 1, , , 0
[1:1:0712/120902.335436:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3494d75029c8, 0x33b79e41e150
[1:1:0712/120902.335571:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ali213.fhyx.com/list/index?order=1&cid1=1&cid2=3", 100
[1:1:0712/120902.335817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://ali213.fhyx.com/, 699
[1:1:0712/120902.335959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f13d7fd0070 0x33b7a07417e0 , 6:3_https://ali213.fhyx.com/, 1, -6:3_https://ali213.fhyx.com/, 697 0x7f13d7fd0070 0x33b7a072d8e0 
