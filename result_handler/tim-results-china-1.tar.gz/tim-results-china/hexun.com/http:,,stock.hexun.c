[0712/043340.138019:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043340.138363:INFO:switcher_clone.cc(787)] backtrace rip is 7faa3d361891
[0712/043341.226081:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043341.226439:INFO:switcher_clone.cc(787)] backtrace rip is 7f04370a7891
[1:1:0712/043341.238704:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/043341.238985:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/043341.248778:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[77620:77620:0712/043342.519855:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/127f8c61-5789-4fdb-b732-0227b179f31d
[0712/043342.714385:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043342.714670:INFO:switcher_clone.cc(787)] backtrace rip is 7fc889f76891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[77620:77620:0712/043342.919157:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[77620:77650:0712/043342.920008:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/043342.920237:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[3:3:0712/043342.920483:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043342.921079:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043342.921230:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/043342.924643:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x27684baf, 1
[1:1:0712/043342.925038:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3da7f3d0, 0
[1:1:0712/043342.925236:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x302352d4, 3
[1:1:0712/043342.925454:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x160fb37c, 2
[1:1:0712/043342.925688:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd0fffffff3ffffffa73d ffffffaf4b6827 7cffffffb30f16 ffffffd4522330 , 10104, 4
[1:1:0712/043342.926893:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[77620:77650:0712/043342.927165:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��=�Kh'|��R#0u�/1
[77620:77650:0712/043342.927236:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��=�Kh'|��R#0��u�/1
[1:1:0712/043342.927160:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f04352e20a0, 3
[77620:77650:0712/043342.927571:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[77620:77650:0712/043342.927640:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 77665, 4, d0f3a73d af4b6827 7cb30f16 d4522330 
[1:1:0712/043342.927653:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f043546d080, 2
[1:1:0712/043342.927851:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f041f130d20, -2
[77652:77652:0712/043342.937384:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=77652
[77666:77666:0712/043342.937800:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=77666
[1:1:0712/043342.951554:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043342.952591:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 160fb37c
[1:1:0712/043342.953807:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 160fb37c
[1:1:0712/043342.955772:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 160fb37c
[1:1:0712/043342.957672:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.957899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.958129:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.958382:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.959186:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 160fb37c
[1:1:0712/043342.959594:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f04370a77ba
[1:1:0712/043342.959764:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f043709edef, 7f04370a777a, 7f04370a90cf
[1:1:0712/043342.965902:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 160fb37c
[1:1:0712/043342.966234:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 160fb37c
[1:1:0712/043342.966946:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 160fb37c
[1:1:0712/043342.968849:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.969051:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.969224:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.969422:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 160fb37c
[1:1:0712/043342.970590:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 160fb37c
[1:1:0712/043342.970926:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f04370a77ba
[1:1:0712/043342.971051:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f043709edef, 7f04370a777a, 7f04370a90cf
[1:1:0712/043342.978477:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043342.978874:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043342.979030:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8d5fa358, 0x7fff8d5fa2d8)
[1:1:0712/043342.993503:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043342.999025:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[77620:77642:0712/043343.598294:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[77620:77620:0712/043343.606282:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043343.606942:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77620:0712/043343.621829:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[77620:77620:0712/043343.621931:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[77620:77620:0712/043343.622067:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,77665, 4
[77620:77631:0712/043343.625648:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[77620:77631:0712/043343.625733:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/043343.626679:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043343.643150:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x248322cad220
[1:1:0712/043343.643421:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/043344.029659:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[77620:77620:0712/043345.852272:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[77620:77620:0712/043345.852392:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043345.882561:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043345.886907:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043346.995995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2b05852c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043346.996346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043347.026315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2b05852c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043347.026549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043347.106519:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043347.380173:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043347.380381:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043347.633782:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043347.637407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2b05852c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043347.637542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043347.648775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043347.651675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2b05852c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043347.651819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043347.655419:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/043347.662206:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x248322cabe20
[1:1:0712/043347.662653:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[77620:77620:0712/043347.680489:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77620:77620:0712/043347.688973:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0712/043347.749001:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[77620:77620:0712/043347.752248:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[77620:77620:0712/043347.752418:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043348.558224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f0420d0b2e0 0x248322f73c60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043348.558920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2b05852c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/043348.559080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043348.559659:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[77620:77620:0712/043348.627732:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043348.629754:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x248322cac820
[1:1:0712/043348.630053:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[77620:77620:0712/043348.640236:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/043348.653198:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043348.653434:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[77620:77620:0712/043348.662286:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[77620:77620:0712/043348.675148:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043348.677016:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77631:0712/043348.685147:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[77620:77631:0712/043348.685250:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043348.688555:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[77620:77620:0712/043348.688642:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[77620:77620:0712/043348.688781:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,77665, 4
[1:7:0712/043348.690429:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043349.269519:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/043349.823916:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f0420d0b2e0 0x248322e9b960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043349.825017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2b05852c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/043349.825260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043349.826090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[77620:77620:0712/043349.947328:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[77620:77620:0712/043349.947764:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/043349.987791:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043350.493415:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77620:77620:0712/043350.604939:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[77620:77650:0712/043350.605436:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/043350.605712:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043350.605913:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043350.606302:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043350.606448:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/043350.609741:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x290eb652, 1
[1:1:0712/043350.610133:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2c94be57, 0
[1:1:0712/043350.610357:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xab697, 3
[1:1:0712/043350.610582:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x31d57e63, 2
[1:1:0712/043350.610803:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 57ffffffbeffffff942c 52ffffffb60e29 637effffffd531 ffffff97ffffffb60a00 , 10104, 5
[1:1:0712/043350.611815:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[77620:77650:0712/043350.612112:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGW��,R�)c~�1��

[77620:77650:0712/043350.612183:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is W��,R�)c~�1��

[77620:77650:0712/043350.612485:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 77717, 5, 57be942c 52b60e29 637ed531 97b60a00 
[1:1:0712/043350.612308:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f04352e20a0, 3
[1:1:0712/043350.612686:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f043546d080, 2
[1:1:0712/043350.612930:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f041f130d20, -2
[1:1:0712/043350.635108:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043350.635553:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 31d57e63
[1:1:0712/043350.635933:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 31d57e63
[1:1:0712/043350.636729:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 31d57e63
[1:1:0712/043350.638421:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.638665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.638887:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.639110:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.639918:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 31d57e63
[1:1:0712/043350.640271:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f04370a77ba
[1:1:0712/043350.640429:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f043709edef, 7f04370a777a, 7f04370a90cf
[1:1:0712/043350.647278:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 31d57e63
[1:1:0712/043350.647730:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 31d57e63
[1:1:0712/043350.648664:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 31d57e63
[1:1:0712/043350.650967:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.651245:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.651474:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.651735:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d57e63
[1:1:0712/043350.653281:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 31d57e63
[1:1:0712/043350.653758:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f04370a77ba
[1:1:0712/043350.653931:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f043709edef, 7f04370a777a, 7f04370a90cf
[1:1:0712/043350.663379:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043350.663985:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043350.664181:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8d5fa358, 0x7fff8d5fa2d8)
[1:1:0712/043350.679041:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043350.683329:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/043350.851662:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x248322c6e220
[1:1:0712/043350.851914:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/043351.012027:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043351.012341:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[77620:77620:0712/043351.497079:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0712/043351.497232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043351.502739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2b05853f0640, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/043351.503173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[77620:77620:0712/043351.503763:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043351.511206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[77620:77631:0712/043351.539911:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[77620:77631:0712/043351.540014:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043351.540642:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://stock.hexun.com/
[77620:77620:0712/043351.540749:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://stock.hexun.com/, http://stock.hexun.com/, 1
[77620:77620:0712/043351.540895:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://stock.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:33:51 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:34:24 GMT Cache-Control: max-age=60 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,77717, 5
[1:7:0712/043351.545004:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043351.559195:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://stock.hexun.com/
[1:1:0712/043351.583726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043351.584592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2b05852c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/043351.584873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043351.660959:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043351.679416:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77620:77620:0712/043351.681412:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://stock.hexun.com/, http://stock.hexun.com/, 1
[77620:77620:0712/043351.681470:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://stock.hexun.com/, http://stock.hexun.com
[1:1:0712/043351.723837:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043351.724024:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043351.826304:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043351.922476:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043351.924213:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043351.924450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2b05853f0640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043351.925047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043352.056691:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043352.057607:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043352.057830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2b05853f0640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043352.058103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043352.237341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f043546d080 0x248322841c40 1 0 0x248322841c58 , "http://stock.hexun.com/"
[1:1:0712/043352.261265:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043352.267707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , /*!
 * jQuery JavaScript Library v1.4.2
 * http://jquery.com/
 *
 * Copyright 2010, John Resig

[1:1:0712/043352.267959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043352.321375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f043546d080 0x248322841c40 1 0 0x248322841c58 , "http://stock.hexun.com/"
[1:1:0712/043352.453858:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f043546d080 0x248322841c40 1 0 0x248322841c58 , "http://stock.hexun.com/"
[1:1:0712/043352.464601:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f043546d080 0x248322841c40 1 0 0x248322841c58 , "http://stock.hexun.com/"
[1:1:0712/043352.474689:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f043546d080 0x248322841c40 1 0 0x248322841c58 , "http://stock.hexun.com/"
[1:1:0712/043352.485723:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7f043546d080 0x248322841c40 1 0 0x248322841c58 , "http://stock.hexun.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043353.133344:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043353.133814:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043353.134166:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043353.134556:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043353.134946:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043353.202164:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043353.474992:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203, "http://stock.hexun.com/"
[1:1:0712/043353.476567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , /*用于加载事件*/
var dplus_PubConfigData_Load = {
    "页面浏览": {
        "属性名�
[1:1:0712/043353.476790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043353.480619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203, "http://stock.hexun.com/"
[1:1:0712/043353.493892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203, "http://stock.hexun.com/"
[1:1:0712/043353.515011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203, "http://stock.hexun.com/"
[77620:77620:0712/043409.799112:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/043409.807152:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043409.995913:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 16.5164, 3, 0
[1:1:0712/043409.996183:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043410.439933:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043410.551031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/043410.551340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043411.088936:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043411.089189:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043411.090182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f041ede3070 0x248323299e60 , "http://stock.hexun.com/"
[1:1:0712/043411.091471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , 
  window._taboola = window._taboola || [];
  _taboola.push({article:'auto'});
  !function (e, f, u,
[1:1:0712/043411.091654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043411.100847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f041ede3070 0x248323299e60 , "http://stock.hexun.com/"
[1:1:0712/043411.144326:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29c0614c29c8, 0x248322891998
[1:1:0712/043411.144651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 3000
[1:1:0712/043411.145060:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 379
[1:1:0712/043411.145304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 379 0x7f041ede3070 0x24832354bce0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 269 0x7f041ede3070 0x248323299e60 
[1:1:0712/043411.162814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f041ede3070 0x248323299e60 , "http://stock.hexun.com/"
[1:1:0712/043411.169538:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f041ede3070 0x248323299e60 , "http://stock.hexun.com/"
[1:1:0712/043411.176782:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f041ede3070 0x248323299e60 , "http://stock.hexun.com/"
[1:1:0712/043411.180807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f041ede3070 0x248323299e60 , "http://stock.hexun.com/"
[1:1:0712/043411.193221:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.103879, 269, 1
[1:1:0712/043411.193412:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043412.173454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329 0x7f0420d0b2e0 0x2483234533e0 , "http://stock.hexun.com/"
[1:1:0712/043412.176933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , !function(a){function b(){b.done||(b.done=!0,S=!0,N=!1,P.each(ba,function(a){a._dom_loaded()}))}func
[1:1:0712/043412.177084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043413.079083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043413.079376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043414.204542:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043414.204801:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043414.207673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f041ede3070 0x2483228ac9e0 , "http://stock.hexun.com/"
[1:1:0712/043414.208719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , articleTop.scrollTop();articleTop.isLogin();
[1:1:0712/043414.208946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043414.243304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f041ede3070 0x2483228ac9e0 , "http://stock.hexun.com/"
[1:1:0712/043414.261207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f041ede3070 0x2483228ac9e0 , "http://stock.hexun.com/"
[1:1:0712/043414.289204:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f041ede3070 0x2483228ac9e0 , "http://stock.hexun.com/"
[1:1:0712/043414.382168:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.177328, 508, 1
[1:1:0712/043414.382479:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043416.188921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043416.189221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043417.470730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 379, 7f0421728881
[1:1:0712/043417.500887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"269 0x7f041ede3070 0x248323299e60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043417.501275:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"269 0x7f041ede3070 0x248323299e60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043417.501722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043417.502300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){s(i+" timeout")}
[1:1:0712/043417.502523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043417.505830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043417.506068:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043417.506544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 565
[1:1:0712/043417.506790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f041ede3070 0x2483227f2260 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 379 0x7f041ede3070 0x24832354bce0 
[1:1:0712/043417.849587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://stock.hexun.com/"
[1:1:0712/043417.851937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , c.onload, (){t(c.responseText)}
[1:1:0712/043417.852258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.055131:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043418.055444:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043418.056450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f041ede3070 0x24832378dd60 , "http://stock.hexun.com/"
[1:1:0712/043418.057368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , 
					new hexun.tool.Tab({
						containerID:"tab1"
					});
				
[1:1:0712/043418.057593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.079125:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043418.080677:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043418.082838:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x248323be9820
[1:1:0712/043418.083071:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[77620:77620:0712/043418.087783:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/043418.100566:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043418.100820:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[77620:77620:0712/043418.102177:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043418.140345:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0848422, 330, 1
[1:1:0712/043418.140654:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77620:77620:0712/043418.148506:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043418.153468:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77631:0712/043418.165324:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[77620:77631:0712/043418.165447:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043418.165610:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://stock.hexun.com/
[77620:77620:0712/043418.165691:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://stock.hexun.com/, http://stock.hexun.com/symjtjmk/, 4
[77620:77620:0712/043418.165839:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://stock.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:34:18 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:34:28 GMT Cache-Control: max-age=60 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,77717, 5
[1:7:0712/043418.174223:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043418.339337:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539 0x7f0420d0b2e0 0x248323350be0 , "http://stock.hexun.com/"
[1:1:0712/043418.341973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043418.342233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.397365:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540 0x7f0420d0b2e0 0x2483238329e0 , "http://stock.hexun.com/"
[1:1:0712/043418.407726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , //abtest111
//-> 19


    var _taboola = _taboola || [];var TRC = TRC || {};
TRC.perfConfOverride = 
[1:1:0712/043418.408059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.434579:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x29c0614c29c8, 0x248322891940
[1:1:0712/043418.434847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 10000
[1:1:0712/043418.435213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 615
[1:1:0712/043418.435446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7f041ede3070 0x2483235ee9e0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 540 0x7f0420d0b2e0 0x2483238329e0 
[1:1:0712/043418.436100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 1000
[1:1:0712/043418.436509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 616
[1:1:0712/043418.436748:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f041ede3070 0x2483235eee60 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 540 0x7f0420d0b2e0 0x2483238329e0 
[1:1:0712/043418.437272:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 5000
[1:1:0712/043418.437653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 617
[1:1:0712/043418.437885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7f041ede3070 0x24832390d060 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 540 0x7f0420d0b2e0 0x2483238329e0 
[1:1:0712/043418.438751:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 5000
[1:1:0712/043418.439183:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 618
[1:1:0712/043418.439420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f041ede3070 0x248323c958e0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 540 0x7f0420d0b2e0 0x2483238329e0 
		remove user.10_cedc9d08 -> 0
[1:1:0712/043418.508260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://stock.hexun.com/"
[1:1:0712/043418.509262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043418.509530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.584426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043418.584727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.731670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563 0x7f0420d0b2e0 0x248323396be0 , "http://stock.hexun.com/"
[1:1:0712/043418.732601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , hx_json11562931254308([{"code":"601318","name":"平安银行"}])
[1:1:0712/043418.732855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.734500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://stock.hexun.com/"
[1:1:0712/043418.776843:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f0420d0b2e0 0x24832381a760 , "http://stock.hexun.com/"
[1:1:0712/043418.777883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , jsonp1562931232405({"islogin":"False","userid":"","username":"","nickname":"","photo":"","sex":"","t
[1:1:0712/043418.778106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.830065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 565, 7f0421728881
[1:1:0712/043418.859118:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"379 0x7f041ede3070 0x24832354bce0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043418.859467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"379 0x7f041ede3070 0x24832354bce0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043418.859873:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043418.860431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043418.860672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043418.863765:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043418.864008:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043418.864367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 629
[1:1:0712/043418.864617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7f041ede3070 0x248323c932e0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 565 0x7f041ede3070 0x2483227f2260 
[1:1:0712/043419.092835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043419.093123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043419.892020:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043419.892285:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043419.893178:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 601 0x7f041ede3070 0x248323ca6de0 , "http://stock.hexun.com/"
[1:1:0712/043419.894078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , 
					new hexun.tool.Tab({
						containerID:"tab2"
					});
				
[1:1:0712/043419.894314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043419.926745:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.034368, 112, 1
[1:1:0712/043419.927044:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043420.048377:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://stock.hexun.com/
[1:1:0712/043420.339791:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://b.scorecardresearch.com/beacon.js"
[1:1:0712/043420.376168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043420.376487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043420.379733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 629, 7f0421728881
[1:1:0712/043420.408688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"565 0x7f041ede3070 0x2483227f2260 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043420.409056:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"565 0x7f041ede3070 0x2483227f2260 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043420.409471:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043420.410008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043420.410244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043420.413608:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043420.413817:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043420.414199:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 660
[1:1:0712/043420.414431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 660 0x7f041ede3070 0x248323eae260 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 629 0x7f041ede3070 0x248323c932e0 
[1:1:0712/043420.436747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043420.437101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043420.588659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 616, 7f04217288db
[1:1:0712/043420.618220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043420.618592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043420.619021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 668
[1:1:0712/043420.619295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f041ede3070 0x248323eac2e0 , 5:3_http://stock.hexun.com/, 0, , 616 0x7f041ede3070 0x2483235eee60 
[1:1:0712/043420.619630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043420.620184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043420.620425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043420.621413:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043420.621610:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043420.621973:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 669
[1:1:0712/043420.622183:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f041ede3070 0x248323c9b6e0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 616 0x7f041ede3070 0x2483235eee60 
[1:1:0712/043420.855379:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043420.855636:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043420.857995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 646 0x7f041ede3070 0x2483238316e0 , "http://stock.hexun.com/"
[1:1:0712/043420.858859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , 
					new hexun.tool.Tab({
						containerID:"006"
					});
				
[1:1:0712/043420.859079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043420.886377:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0306332, 142, 1
[1:1:0712/043420.886643:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77620:77620:0712/043420.918494:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://stock.hexun.com/, http://stock.hexun.com/, 4
[77620:77620:0712/043420.918626:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://stock.hexun.com/, http://stock.hexun.com
[1:1:0712/043420.921777:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043421.209442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043421.209725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043421.212966:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 660, 7f0421728881
[1:1:0712/043421.242380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"629 0x7f041ede3070 0x248323c932e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043421.242727:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"629 0x7f041ede3070 0x248323c932e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043421.243152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043421.243757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043421.244015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043421.248068:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043421.248312:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043421.248665:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 694
[1:1:0712/043421.248961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f041ede3070 0x248323393260 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 660 0x7f041ede3070 0x248323eae260 
[1:1:0712/043421.281420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043421.281690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043421.573703:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 669, 7f0421728881
[1:1:0712/043421.606249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"616 0x7f041ede3070 0x2483235eee60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043421.606646:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"616 0x7f041ede3070 0x2483235eee60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043421.607087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043421.607642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){s.push(e.now()-t)}
[1:1:0712/043421.607891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043421.686183:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043421.686437:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043421.687268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 677 0x7f041ede3070 0x248323c95f60 , "http://stock.hexun.com/"
[1:1:0712/043421.688170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , 
						new hexun.tool.Tab({
							containerID:"007"
						});
					
[1:1:0712/043421.688449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043421.709412:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.710677:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043421.712898:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x248323bea220
[1:1:0712/043421.713152:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[77620:77620:0712/043421.717361:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/043421.730376:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.730619:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043421.732938:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.733631:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043421.736187:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x248323f77220
[1:1:0712/043421.736452:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[77620:77620:0712/043421.744084:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77620:77620:0712/043421.746087:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/043421.746672:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.746901:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043421.749190:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/043421.760644:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x2483233daa20
[1:1:0712/043421.760878:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[77620:77620:0712/043421.763642:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[77620:77620:0712/043421.777941:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77620:77620:0712/043421.784932:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0712/043421.786367:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.786622:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043421.793493:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.799174:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043421.802612:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x2483233dd220
[1:1:0712/043421.802875:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[77620:77620:0712/043421.810610:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77620:77620:0712/043421.812637:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[1:1:0712/043421.819684:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.819978:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043421.822271:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.826361:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043421.827254:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x248323cb9420
[1:1:0712/043421.827484:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[1:1:0712/043421.834513:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.834748:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043421.840623:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.841392:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043421.848770:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x248323cba820
[1:1:0712/043421.848993:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[77620:77620:0712/043421.849871:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[77620:77620:0712/043421.863403:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043421.868294:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.868534:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043421.870808:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.875085:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043421.881334:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x248323cb8a20
[1:1:0712/043421.881586:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[77620:77620:0712/043421.882077:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[77620:77620:0712/043421.898342:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043421.899614:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.899837:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043421.910402:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.910723:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77620:77620:0712/043421.917724:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 11, 11, 
[1:1:0712/043421.917688:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 12, 0x248323fa0020
[1:1:0712/043421.917904:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 12
[77620:77620:0712/043421.931195:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043421.936710:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043421.936950:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[77620:77620:0712/043421.943746:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77620:77620:0712/043421.950498:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 12, 12, 
[77620:77620:0712/043421.963686:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043421.974256:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043421.975658:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043421.977269:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043421.982098:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 13, 0x248322c6d820
[1:1:0712/043421.982358:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 13
[77620:77620:0712/043421.992259:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://stockdata.stock.hexun.com/
[77620:77620:0712/043421.992367:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/jgcc/Iframe/stockIndex/iframe_stockjgcc.html, 8
[77620:77620:0712/043421.992554:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_http://stockdata.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:21 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Tue, 02 Jul 2019 05:18:39 GMT ETag: W/"10fca69b9530d51:a93" Content-Encoding: gzip X-Via-JSL: 0038d5f,- Set-Cookie: __jsluid_h=359201d19f516d62881b6fbcd7aeba15; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,77717, 5
[77620:77631:0712/043421.994173:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[77620:77631:0712/043421.994255:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043421.994416:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77620:77620:0712/043421.996407:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 13, 13, 
[1:7:0712/043421.997891:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77620:77620:0712/043422.003413:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0712/043422.005394:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043422.005797:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[77620:77620:0712/043422.009978:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043422.026141:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.339637, 540, 1
[1:1:0712/043422.026413:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77620:77631:0712/043422.042441:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[77620:77620:0712/043422.042515:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://stockdata.stock.hexun.com/
[77620:77620:0712/043422.042559:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/zlkp/Iframe/iframe_stockzlkp.html, 9
[77620:77631:0712/043422.042564:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043422.042624:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_http://stockdata.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:21 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Tue, 02 Jul 2019 05:22:51 GMT ETag: W/"2022a3319630d51:bda" Content-Encoding: gzip X-Via-JSL: 0038d5f,- Set-Cookie: __jsluid_h=d2f5e66e7f6a3740b87515da05addabf; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,77717, 5
[1:7:0712/043422.047328:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77620:77620:0712/043422.050199:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[77620:77620:0712/043422.062831:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043422.067646:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77620:0712/043422.084223:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://stockdata.stock.hexun.com/
[77620:77620:0712/043422.084276:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/ggzjc/Iframe/Gstock/iframe_dzjy.html, 10
[77620:77620:0712/043422.084340:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:10_http://stockdata.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:21 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Thu, 10 Jan 2019 12:57:41 GMT ETag: W/"c1459712e4a8d41:bda" Content-Encoding: gzip X-Via-JSL: 0038d5f,- Set-Cookie: __jsluid_h=0a6417d992ba22a488e8de247fdfd0b3; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,77717, 5
[77620:77631:0712/043422.084822:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 10
[77620:77631:0712/043422.084908:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 10, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/043422.086113:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77620:77620:0712/043422.106526:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043422.111476:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043422.121955:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77620:77631:0712/043422.143936:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 11
[77620:77631:0712/043422.144032:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 11, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043422.144203:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://stockdata.stock.hexun.com/
[77620:77620:0712/043422.144283:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/ggzjc/Iframe/Gstock/iframe_nbjy.html, 11
[77620:77620:0712/043422.144417:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:11_http://stockdata.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:22 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Tue, 27 Nov 2018 03:08:13 GMT ETag: W/"5a9886ffe85d41:bda" Content-Encoding: gzip X-Via-JSL: 0038d5f,- Set-Cookie: __jsluid_h=d79d03bf58a0607f113fc56ef85fdd73; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,77717, 5
[77620:77620:0712/043422.146687:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043422.150693:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0712/043422.161740:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77620:77631:0712/043422.180838:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 12
[77620:77631:0712/043422.180935:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 12, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043422.181076:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://stockdata.stock.hexun.com/
[77620:77620:0712/043422.181152:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/us/iframe/iframe_zgg.html, 12
[77620:77620:0712/043422.181280:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:12_http://stockdata.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:22 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Wed, 19 Dec 2018 12:38:18 GMT ETag: W/"9592cb89797d41:bda" Content-Encoding: gzip X-Via-JSL: 0038d5f,- X-Cache: bypass  ,77717, 5
[1:7:0712/043422.196219:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77620:77620:0712/043422.196868:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043422.201249:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77631:0712/043422.235147:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 13
[77620:77631:0712/043422.235248:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 13, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043422.235398:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://px.hexun.com/
[77620:77620:0712/043422.235475:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:13_http://px.hexun.com/, http://px.hexun.com/rest/gs/gushouclass.aspx, 13
[77620:77620:0712/043422.235613:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:13_http://px.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:22 GMT Content-Type: text/html; charset=gb2312 Content-Length: 1349 Connection: keep-alive Server: nginx Cache-Control: public, max-age=56 Content-Encoding: gzip Expires: Fri, 12 Jul 2019 11:35:18 GMT Last-Modified: Fri, 12 Jul 2019 11:30:18 GMT Content-Security-Policy: frame-ancestors 'self' *.hexun.com web.umeng.com www.growingio.com; X-Via: 1.1 wj28:2 (Cdn Cache Server V2.0), 1.1 chk29:3 (Cdn Cache Server V2.0)  ,77717, 5
[1:7:0712/043422.244728:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043422.365825:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://stock.hexun.com/"
[1:1:0712/043422.366552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043422.366802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043422.403395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043422.403699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043422.407448:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 694, 7f0421728881
[1:1:0712/043422.442759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"660 0x7f041ede3070 0x248323eae260 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043422.443121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"660 0x7f041ede3070 0x248323eae260 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043422.443551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043422.444101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043422.444313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043422.446915:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043422.447144:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043422.447509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 821
[1:1:0712/043422.447755:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f041ede3070 0x248323f2d6e0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 694 0x7f041ede3070 0x248323393260 
[1:1:0712/043422.486988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043422.487269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[77620:77620:0712/043422.709245:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043422.713482:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77631:0712/043422.744325:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[77620:77631:0712/043422.744426:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043422.744557:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://yanbao.stock.hexun.com/
[77620:77620:0712/043422.744634:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com/include/iframe_gsyb_new.html, 5
[77620:77620:0712/043422.744783:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://yanbao.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:22 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Wed, 10 Jul 2019 08:44:14 GMT ETag: W/"f84c1da7fb36d51:734" Content-Encoding: gzip X-Via-JSL: e17d292,- Set-Cookie: __jsluid_h=62d20eea7a4f5e1a2f3d30b82472aa84; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,77717, 5
[77620:77620:0712/043422.749078:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:7:0712/043422.750175:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77620:77620:0712/043422.754363:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77631:0712/043422.783467:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[77620:77631:0712/043422.783561:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043422.783758:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://yanbao.stock.hexun.com/
[77620:77620:0712/043422.783805:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com/include/iframe_jgjg_new.html#onlybiggest, 6
[77620:77620:0712/043422.783868:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_http://yanbao.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:22 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Fri, 12 Jul 2019 06:24:07 GMT ETag: W/"f1a233697a38d51:5a1" Content-Encoding: gzip X-Via-JSL: e17d292,- Set-Cookie: __jsluid_h=f8233487377d6a56d87b066e256e5bb7; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,77717, 5
[77620:77620:0712/043422.784788:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043422.785913:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0712/043422.788587:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77620:77631:0712/043422.797646:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[77620:77620:0712/043422.797681:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://yanbao.stock.hexun.com/
[77620:77620:0712/043422.797752:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com/include/iframe_jgjg_new.html#onlybestbk, 7
[77620:77631:0712/043422.797756:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043422.797859:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_http://yanbao.stock.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:34:22 GMT Content-Type: text/html Vary: Accept-Encoding Last-Modified: Fri, 12 Jul 2019 06:24:07 GMT ETag: W/"f1a233697a38d51:5a1" Content-Encoding: gzip X-Via-JSL: e17d292,- X-Cache: bypass  ,77717, 5
[1:7:0712/043422.799626:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043422.977014:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 668, 7f04217288db
[1:1:0712/043423.012235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"616 0x7f041ede3070 0x2483235eee60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043423.012829:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"616 0x7f041ede3070 0x2483235eee60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043423.013749:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 848
[1:1:0712/043423.014215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 848 0x7f041ede3070 0x24832432e4e0 , 5:3_http://stock.hexun.com/, 0, , 668 0x7f041ede3070 0x248323eac2e0 
[1:1:0712/043423.014875:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043423.016029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043423.016446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043423.018058:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043423.018443:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043423.019203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 849
[1:1:0712/043423.019675:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f041ede3070 0x24832432f7e0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 668 0x7f041ede3070 0x248323eac2e0 
[1:1:0712/043424.777910:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:8_http://stockdata.stock.hexun.com/
[1:1:0712/043425.475426:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043425.475704:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043425.479903:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 795 0x7f041ede3070 0x2483241798e0 , "http://stock.hexun.com/"
[1:1:0712/043425.485745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , if(!window.hexun){
	window.hexun={};
}
if(!hexun.tool){
	hexun.tool={};
}
(function(self){


[1:1:0712/043425.485974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043425.488101:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043425.492927:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 795 0x7f041ede3070 0x2483241798e0 , "http://stock.hexun.com/"
[1:1:0712/043425.503348:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043425.505240:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043425.508560:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 14, 0x2483233dc820
[1:1:0712/043425.508824:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 14
[77620:77620:0712/043425.513534:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 14, 14, 
[1:1:0712/043425.536281:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043425.536621:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[77620:77620:0712/043425.538876:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[1:1:0712/043425.548404:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0725951, 124, 1
[1:1:0712/043425.548678:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77620:77620:0712/043425.698171:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043425.704914:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77631:0712/043425.722342:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 14
[77620:77620:0712/043425.722461:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://widget.weibo.com/
[77620:77631:0712/043425.722474:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 14, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043425.722540:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:14_https://widget.weibo.com/, https://widget.weibo.com/relationship/followbutton.php?width=230&height=24&uid=2191812860&style=3&btn=red&dpc=1, 14
[77620:77620:0712/043425.722655:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:14_https://widget.weibo.com/, HTTP/1.1 200 OK Server: WeiBo/LB Date: Fri, 12 Jul 2019 11:34:25 GMT Content-Type: text/html Content-Length: 1041 Connection: keep-alive Vary: Host,Accept-Encoding Set-Cookie: U_TRS1=00000022.524a2da1.5d287041.71a15ffb; path=/; expires=Mon, 09-Jul-29 11:34:25 GMT; domain=.sina.com.cn Set-Cookie: U_TRS2=00000022.52712da1.5d287041.fedd19f5; path=/; domain=.sina.com.cn Content-Security-Policy: upgrade-insecure-requests xPlugins-Type: 1 Cache-Control: max-age=300, must-revalidate Pragma:  Expires: Fri, 12 Jul 2019 11:39:25 GMT Last-Modified: Fri, 12 Jul 2019 11:34:25 GMT DPOOL_HEADER: qubele35 Content-Encoding: gzip LB_HEADER: venus245 Strict-Transport-Security: max-age=31536000; preload  ,77717, 5
[1:7:0712/043425.729436:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043425.806259:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:9_http://stockdata.stock.hexun.com/
[1:1:0712/043425.979248:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:10_http://stockdata.stock.hexun.com/
[1:1:0712/043425.998125:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043425.998381:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/symjtjmk/"
[1:1:0712/043426.242697:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:11_http://stockdata.stock.hexun.com/
[1:1:0712/043426.399343:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:12_http://stockdata.stock.hexun.com/
[1:1:0712/043426.616719:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:13_http://px.hexun.com/
[1:1:0712/043426.679521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043426.679871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043426.888118:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://yanbao.stock.hexun.com/
[1:1:0712/043427.051272:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_http://yanbao.stock.hexun.com/
[1:1:0712/043427.262790:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_http://yanbao.stock.hexun.com/
[1:1:0712/043427.564534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043427.564819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043427.900884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 821, 7f0421728881
[1:1:0712/043427.946661:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"694 0x7f041ede3070 0x248323393260 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043427.947048:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"694 0x7f041ede3070 0x248323393260 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043427.947492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043427.948039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043427.948363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043427.972805:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043427.973076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043427.973468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 956
[1:1:0712/043427.973704:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7f041ede3070 0x2483242153e0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 821 0x7f041ede3070 0x248323f2d6e0 
[1:1:0712/043428.033539:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 849, 7f0421728881
[1:1:0712/043428.054395:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"668 0x7f041ede3070 0x248323eac2e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.054773:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"668 0x7f041ede3070 0x248323eac2e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.055231:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043428.055879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){s.push(e.now()-t)}
[1:1:0712/043428.056126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043428.191441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 848, 7f04217288db
[1:1:0712/043428.232466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"668 0x7f041ede3070 0x248323eac2e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.232783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"668 0x7f041ede3070 0x248323eac2e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.233226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 964
[1:1:0712/043428.233473:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 964 0x7f041ede3070 0x2483237dcfe0 , 5:3_http://stock.hexun.com/, 0, , 848 0x7f041ede3070 0x24832432e4e0 
[1:1:0712/043428.233756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043428.234300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043428.234518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043428.235168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043428.235395:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043428.235783:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 965
[1:1:0712/043428.236039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7f041ede3070 0x24832432ff60 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 848 0x7f041ede3070 0x24832432e4e0 
[1:1:0712/043428.237363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 617, 7f04217288db
[1:1:0712/043428.270160:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.270562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.271045:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 967
[1:1:0712/043428.271303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7f041ede3070 0x2483243385e0 , 5:3_http://stock.hexun.com/, 0, , 617 0x7f041ede3070 0x24832390d060 
[1:1:0712/043428.271591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043428.272187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/043428.272424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043428.275544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 618, 7f04217288db
[1:1:0712/043428.314506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.314869:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043428.315348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 968
[1:1:0712/043428.315595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 968 0x7f041ede3070 0x24832422bfe0 , 5:3_http://stock.hexun.com/, 0, , 618 0x7f041ede3070 0x248323c958e0 
[1:1:0712/043428.315920:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043428.316496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/043428.316729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043428.611727:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043428.614922:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/, 8
[77620:77620:0712/043428.614975:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com
[1:1:0712/043429.360446:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043429.360718:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stock.hexun.com/"
[1:1:0712/043429.367947:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 901 0x7f041ede3070 0x2483228e0fe0 , "http://stock.hexun.com/"
[1:1:0712/043429.375464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , // method

function strIndexReplace(_str, _index, _replace) {

    if (_str.indexOf(_index) > -1) {

[1:1:0712/043429.375736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "stock.hexun.com", 3, 1, , , 0
[1:1:0712/043429.427660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 901 0x7f041ede3070 0x2483228e0fe0 , "http://stock.hexun.com/"
[1:1:0712/043429.430823:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "stock.hexun.com", "hexun.com"
[1:1:0712/043429.443483:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77620:77620:0712/043429.444843:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043429.447013:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 15, 0x2483241f8420
[1:1:0712/043429.447499:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 15
[77620:77620:0712/043429.451883:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 15, 15, 
[1:1:0712/043429.469503:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043429.469808:INFO:render_frame_impl.cc(7019)] 	 [url] = http://stock.hexun.com
[1:1:0712/043429.474345:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 901 0x7f041ede3070 0x2483228e0fe0 , "http://stock.hexun.com/"
[1:1:0712/043429.478740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 901 0x7f041ede3070 0x2483228e0fe0 , "http://stock.hexun.com/"
[77620:77620:0712/043429.480967:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://stock.hexun.com/
[77620:77620:0712/043429.523941:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77620:77620:0712/043429.531786:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77620:77631:0712/043429.565637:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 15
[77620:77631:0712/043429.565751:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 15, HandleIncomingMessage, HandleIncomingMessage
[77620:77620:0712/043429.566052:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://utrack.hexun.com/
[77620:77620:0712/043429.566135:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:15_http://utrack.hexun.com/, http://utrack.hexun.com/usertrack.aspx?site=http%3A//stock.hexun.com/&time=1562931269433&rsite=, 15
[77620:77620:0712/043429.566277:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:15_http://utrack.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:34:29 GMT Content-Type: text/html; charset=gb2312 Content-Length: 849 Connection: keep-alive Cache-Control: no-cache Pragma: no-cache Expires: -1 X-AspNet-Version: 4.0.30319 X-Powered-By: ASP.NET Set-Cookie: HexunTrack=SID=2019071219175101338081a23c7164514b48611e60fef35a3&CITY=11&TOWN=0; domain=hexun.com; expires=Wed, 06-Apr-2022 16:00:00 GMT; path=/  ,77717, 5
[1:7:0712/043429.574452:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043429.696063:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:14_https://widget.weibo.com/
[1:1:0712/043429.776983:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043429.787760:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/, 9
[77620:77620:0712/043429.787872:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com
[1:1:0712/043429.933610:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043429.935410:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/, 10
[77620:77620:0712/043429.935507:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com
[77620:77620:0712/043430.457992:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/, 11
[77620:77620:0712/043430.458145:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com
[1:1:0712/043430.458782:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043430.630009:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043430.640003:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com/, 12
[77620:77620:0712/043430.640144:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 12, 12, http://stockdata.stock.hexun.com/, http://stockdata.stock.hexun.com
[77620:77620:0712/043430.826924:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:13_http://px.hexun.com/, http://px.hexun.com/, 13
[77620:77620:0712/043430.827059:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 13, 13, http://px.hexun.com/, http://px.hexun.com
[1:1:0712/043430.828216:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043430.915126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043430.915501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043431.018883:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043431.025643:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com/, 5
[77620:77620:0712/043431.025747:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com
[1:1:0712/043431.161544:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043431.162400:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com/, 6
[77620:77620:0712/043431.162523:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com
[1:1:0712/043431.295844:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043431.305212:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com/, 7
[77620:77620:0712/043431.305337:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://yanbao.stock.hexun.com/, http://yanbao.stock.hexun.com
[1:1:0712/043431.449296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043431.449607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[77620:77620:0712/043431.750370:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/043431.814426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 956, 7f0421728881
[1:1:0712/043431.831191:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"821 0x7f041ede3070 0x248323f2d6e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043431.831548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"821 0x7f041ede3070 0x248323f2d6e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043431.831936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043431.832581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043431.832821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043431.839535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043431.839856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043431.840229:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 1177
[1:1:0712/043431.840491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7f041ede3070 0x248324357560 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 956 0x7f041ede3070 0x2483242153e0 
[1:1:0712/043432.118544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 965, 7f0421728881
[1:1:0712/043432.167576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"848 0x7f041ede3070 0x24832432e4e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.167928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"848 0x7f041ede3070 0x24832432e4e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.168316:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043432.168889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){s.push(e.now()-t)}
[1:1:0712/043432.169108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043432.346176:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 615, 7f0421728881
[1:1:0712/043432.395707:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.396061:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"540 0x7f0420d0b2e0 0x2483238329e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.396466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043432.397012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){v(),o.measureInterval&&(this.measureInterval=setInterval(v,Math.max(Number(o.measureInterval),1e4
[1:1:0712/043432.397223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043432.413701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://stock.hexun.com/"
[1:1:0712/043432.416644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 964, 7f04217288db
[77620:77620:0712/043432.420956:INFO:CONSOLE(11)] "Uncaught TypeError: (t.TRCImpl && t.TRCImpl.getGlobalSessionData.trcBind(...)) is not a function", source: http://cdn.taboola.com/libtrc/hexun-hxcom/loader.js (11)
[1:1:0712/043432.466038:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"848 0x7f041ede3070 0x24832432e4e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.466315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"848 0x7f041ede3070 0x24832432e4e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.466745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1213
[1:1:0712/043432.466942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1213 0x7f041ede3070 0x24832438ade0 , 5:3_http://stock.hexun.com/, 0, , 964 0x7f041ede3070 0x2483237dcfe0 
[1:1:0712/043432.467260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043432.467864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043432.468056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043432.468689:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043432.468856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043432.469164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 1214
[1:1:0712/043432.469351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1214 0x7f041ede3070 0x24832442aae0 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 964 0x7f041ede3070 0x2483237dcfe0 
[1:1:0712/043432.471167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 967, 7f04217288db
[1:1:0712/043432.520710:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"617 0x7f041ede3070 0x24832390d060 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.520994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"617 0x7f041ede3070 0x24832390d060 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.521381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1217
[1:1:0712/043432.521588:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1217 0x7f041ede3070 0x2483246d4e60 , 5:3_http://stock.hexun.com/, 0, , 967 0x7f041ede3070 0x2483243385e0 
[1:1:0712/043432.521899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043432.522466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/043432.522652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043432.600338:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 968, 7f04217288db
[1:1:0712/043432.616335:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"618 0x7f041ede3070 0x248323c958e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.616555:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"618 0x7f041ede3070 0x248323c958e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043432.616780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1224
[1:1:0712/043432.616891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1224 0x7f041ede3070 0x2483247333e0 , 5:3_http://stock.hexun.com/, 0, , 968 0x7f041ede3070 0x24832422bfe0 
[1:1:0712/043432.617071:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043432.617358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/043432.617473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043432.673752:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043434.736170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1021, "http://stock.hexun.com/"
[1:1:0712/043434.737419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , eval(function (p, a, c, k, e, d) { e = function (c) { return (c < a ? "" : e(parseInt(c / a))) + ((c
[1:1:0712/043434.737656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043434.914115:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043434.914594:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[77620:77620:0712/043435.008136:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261865322, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://utrack.hexun.com/dp/hexun_uweb.js (7)
[77620:77620:0712/043435.021759:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261865322, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://utrack.hexun.com/dp/hexun_uweb.js (7)
[1:1:0712/043435.206543:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:15_http://utrack.hexun.com/
[1:1:0712/043435.285952:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043435.303188:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:14_https://widget.weibo.com/, https://widget.weibo.com/, 14
[77620:77620:0712/043435.303320:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 14, 14, https://widget.weibo.com/, https://widget.weibo.com
[1:1:0712/043435.382414:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043435.733777:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043436.566438:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043437.177665:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043437.541562:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043437.944471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043437.944710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043438.062663:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043438.504181:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043438.833548:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043439.625970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043439.626143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043441.153968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 1177, 7f0421728881
[1:1:0712/043441.221626:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"956 0x7f041ede3070 0x2483242153e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043441.222050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"956 0x7f041ede3070 0x2483242153e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043441.222524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043441.223185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043441.223409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043442.346489:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 1214, 7f0421728881
[1:1:0712/043442.364841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"964 0x7f041ede3070 0x2483237dcfe0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.365035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"964 0x7f041ede3070 0x2483237dcfe0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.365299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043442.365600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){s.push(e.now()-t)}
[1:1:0712/043442.365721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043442.596657:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043442.596817:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stockdata.stock.hexun.com/jgcc/Iframe/stockIndex/iframe_stockjgcc.html"
[1:1:0712/043442.773449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1213, 7f04217288db
[1:1:0712/043442.792306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"964 0x7f041ede3070 0x2483237dcfe0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.792532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"964 0x7f041ede3070 0x2483237dcfe0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.792765:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1431
[1:1:0712/043442.792882:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1431 0x7f041ede3070 0x248323c763e0 , 5:3_http://stock.hexun.com/, 0, , 1213 0x7f041ede3070 0x24832438ade0 
[1:1:0712/043442.793066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043442.793391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043442.793504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043442.793794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043442.793892:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043442.794057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 1432
[1:1:0712/043442.794165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1432 0x7f041ede3070 0x24832497d860 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 1213 0x7f041ede3070 0x24832438ade0 
[1:1:0712/043442.794669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1217, 7f04217288db
[1:1:0712/043442.842496:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"967 0x7f041ede3070 0x2483243385e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.842845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"967 0x7f041ede3070 0x2483243385e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.843351:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1433
[1:1:0712/043442.843621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1433 0x7f041ede3070 0x248324786fe0 , 5:3_http://stock.hexun.com/, 0, , 1217 0x7f041ede3070 0x2483246d4e60 
[1:1:0712/043442.844013:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043442.844680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/043442.844920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043442.847879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1224, 7f04217288db
[1:1:0712/043442.915225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"968 0x7f041ede3070 0x24832422bfe0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.915525:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"968 0x7f041ede3070 0x24832422bfe0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043442.915958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1437
[1:1:0712/043442.916153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1437 0x7f041ede3070 0x248323455ae0 , 5:3_http://stock.hexun.com/, 0, , 1224 0x7f041ede3070 0x2483247333e0 
[1:1:0712/043442.916480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043442.916982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/043442.917156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043443.279593:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1266, "http://stock.hexun.com/"
[1:1:0712/043443.286838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (function(){function p(){this.c="1261865322";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/043443.287107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[77620:77620:0712/043443.362384:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261865322&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261865322 (17)
[77620:77620:0712/043443.369977:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261865322&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261865322 (17)
[1:1:0712/043443.508250:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77620:77620:0712/043443.514533:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:15_http://utrack.hexun.com/, http://utrack.hexun.com/, 15
[77620:77620:0712/043443.514652:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 15, 15, http://utrack.hexun.com/, http://utrack.hexun.com
[1:1:0712/043443.655874:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043443.842150:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043443.842367:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stockdata.stock.hexun.com/zlkp/Iframe/iframe_stockzlkp.html"
[1:1:0712/043444.087256:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043444.087472:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stockdata.stock.hexun.com/ggzjc/Iframe/Gstock/iframe_dzjy.html"
[1:1:0712/043444.394022:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043444.394235:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stockdata.stock.hexun.com/ggzjc/Iframe/Gstock/iframe_nbjy.html"
[1:1:0712/043444.552882:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043444.553098:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://stockdata.stock.hexun.com/us/iframe/iframe_zgg.html"
[1:1:0712/043444.656286:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043444.656451:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://px.hexun.com/rest/gs/gushouclass.aspx"
[1:1:0712/043444.897946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , document.readyState
[1:1:0712/043444.898211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043444.966139:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043444.966395:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://yanbao.stock.hexun.com/include/iframe_gsyb_new.html"
[1:1:0712/043445.054957:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043445.055144:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://yanbao.stock.hexun.com/include/iframe_jgjg_new.html#onlybiggest"
[1:1:0712/043445.110317:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043445.110481:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://yanbao.stock.hexun.com/include/iframe_jgjg_new.html#onlybestbk"
[1:1:0712/043447.485020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043447.485303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043449.387503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 1432, 7f0421728881
[1:1:0712/043449.448773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13b32b762860","ptid":"1213 0x7f041ede3070 0x24832438ade0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043449.449162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://stock.hexun.com/","ptid":"1213 0x7f041ede3070 0x24832438ade0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043449.449648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043449.450278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){s.push(e.now()-t)}
[1:1:0712/043449.450392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043450.411089:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1452, "http://stock.hexun.com/"
[1:1:0712/043450.414463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043450.414697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043450.803514:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043451.079698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1431, 7f04217288db
[1:1:0712/043451.102085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1213 0x7f041ede3070 0x24832438ade0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043451.102272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1213 0x7f041ede3070 0x24832438ade0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043451.102516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1665
[1:1:0712/043451.102636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1665 0x7f041ede3070 0x248325145160 , 5:3_http://stock.hexun.com/, 0, , 1431 0x7f041ede3070 0x248323c763e0 
[1:1:0712/043451.102856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043451.103149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043451.103255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043451.103541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29c0614c29c8, 0x248322891950
[1:1:0712/043451.103640:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://stock.hexun.com/", 0
[1:1:0712/043451.103851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://stock.hexun.com/, 1666
[1:1:0712/043451.103967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1666 0x7f041ede3070 0x248325149760 , 5:3_http://stock.hexun.com/, 1, -5:3_http://stock.hexun.com/, 1431 0x7f041ede3070 0x248323c763e0 
[1:1:0712/043451.104471:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1433, 7f04217288db
[1:1:0712/043451.126627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1217 0x7f041ede3070 0x2483246d4e60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043451.126816:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1217 0x7f041ede3070 0x2483246d4e60 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043451.127056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1667
[1:1:0712/043451.127172:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1667 0x7f041ede3070 0x248324fd1060 , 5:3_http://stock.hexun.com/, 0, , 1433 0x7f041ede3070 0x248324786fe0 
[1:1:0712/043451.127348:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043451.127637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/043451.127777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043451.128519:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1437, 7f04217288db
[1:1:0712/043451.150643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1224 0x7f041ede3070 0x2483247333e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043451.150846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1224 0x7f041ede3070 0x2483247333e0 ","rf":"5:3_http://stock.hexun.com/"}
[1:1:0712/043451.151086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://stock.hexun.com/, 1669
[1:1:0712/043451.151202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1669 0x7f041ede3070 0x2483251a70e0 , 5:3_http://stock.hexun.com/, 0, , 1437 0x7f041ede3070 0x248323455ae0 
[1:1:0712/043451.151389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://stock.hexun.com/"
[1:1:0712/043451.151675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://stock.hexun.com/, 13b32b762860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/043451.151830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stock.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/043451.659711:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043451.659950:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/relationship/followbutton.php?width=230&height=24&uid=2191812860&style=3&btn=red&dpc=1"
[1:1:0712/043453.461928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1510, "http://stockdata.stock.hexun.com/us/iframe/iframe_zgg.html"
[1:1:0712/043453.463013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:12_http://stockdata.stock.hexun.com/, 13b32b837b98, , , if(!window.hexun){
	window.hexun={};
}
if(!hexun.tool){
	hexun.tool={};
}
(function(self){


[1:1:0712/043453.463248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://stockdata.stock.hexun.com/us/iframe/iframe_zgg.html", "stockdata.stock.hexun.com", 12, 1, http://stock.hexun.com, hexun.com, 3
[1:1:0712/043454.012314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1519, "http://px.hexun.com/rest/gs/gushouclass.aspx"
[1:1:0712/043454.015169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:13_http://px.hexun.com/, 13b32b83c8a0, , , /**
 * hexun 焦点图
 * @version 1.1.4.2
 * @author [hexun ui]zhouyunxi
 * @update 2010-12-27 
[1:1:0712/043454.015424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://px.hexun.com/rest/gs/gushouclass.aspx", "px.hexun.com", 13, 1, http://stock.hexun.com, hexun.com, 3
[1:1:0712/043454.024173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1519, "http://px.hexun.com/rest/gs/gushouclass.aspx"
[1:1:0712/043454.056188:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://px.hexun.com/rest/gs/gushouclass.aspx", 2500
[1:1:0712/043454.056480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:13_http://px.hexun.com/, 1749
[1:1:0712/043454.056629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1749 0x7f041ede3070 0x2483250193e0 , 5:13_http://px.hexun.com/, 1, -5:13_http://px.hexun.com/, 1519
