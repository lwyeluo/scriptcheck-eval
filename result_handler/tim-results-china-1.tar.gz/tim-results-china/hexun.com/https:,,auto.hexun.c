[0712/043225.136510:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043225.136867:INFO:switcher_clone.cc(787)] backtrace rip is 7fadbe678891
[0712/043226.042457:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043226.042790:INFO:switcher_clone.cc(787)] backtrace rip is 7f90fbf9a891
[1:1:0712/043226.055047:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/043226.055328:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/043226.068651:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[77494:77494:0712/043227.480953:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/043227.534202:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043227.534462:INFO:switcher_clone.cc(787)] backtrace rip is 7f9d737d5891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/e9ebb0d8-bdf4-4cbd-b58f-2713d0237fa4
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[77524:77524:0712/043227.740894:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=77524
[77537:77537:0712/043227.741300:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=77537
[77494:77494:0712/043228.057551:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[77494:77522:0712/043228.058218:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/043228.058448:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043228.058668:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043228.059271:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043228.059431:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/043228.062327:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26cd1a8d, 1
[1:1:0712/043228.062660:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2ab8678d, 0
[1:1:0712/043228.062877:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1f9e681d, 3
[1:1:0712/043228.063080:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3dbcab4, 2
[1:1:0712/043228.063312:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8d67ffffffb82a ffffff8d1affffffcd26 ffffffb4ffffffcaffffffdb03 1d68ffffff9e1f , 10104, 4
[1:1:0712/043228.064308:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[77494:77522:0712/043228.064546:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�g�*��&���h��
[77494:77522:0712/043228.064617:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �g�*��&���h��Q�
[1:1:0712/043228.064723:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90fa1d50a0, 3
[77494:77522:0712/043228.064899:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[77494:77522:0712/043228.064966:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 77545, 4, 8d67b82a 8d1acd26 b4cadb03 1d689e1f 
[1:1:0712/043228.064944:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90fa360080, 2
[1:1:0712/043228.065094:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90e4023d20, -2
[1:1:0712/043228.076619:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043228.077219:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3dbcab4
[1:1:0712/043228.077874:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3dbcab4
[1:1:0712/043228.078876:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3dbcab4
[1:1:0712/043228.079396:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.079499:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.079595:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.079693:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.079953:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3dbcab4
[1:1:0712/043228.080103:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90fbf9a7ba
[1:1:0712/043228.080181:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f90fbf91def, 7f90fbf9a77a, 7f90fbf9c0cf
[1:1:0712/043228.081647:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3dbcab4
[1:1:0712/043228.081805:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3dbcab4
[1:1:0712/043228.082106:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3dbcab4
[1:1:0712/043228.082771:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.082893:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.082992:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.083088:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3dbcab4
[1:1:0712/043228.083514:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3dbcab4
[1:1:0712/043228.083662:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90fbf9a7ba
[1:1:0712/043228.083741:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f90fbf91def, 7f90fbf9a77a, 7f90fbf9c0cf
[1:1:0712/043228.085955:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043228.086211:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043228.086301:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff04576838, 0x7fff045767b8)
[1:1:0712/043228.100862:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043228.104614:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[77494:77494:0712/043228.817798:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043228.818932:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77494:77494:0712/043228.833935:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[77494:77504:0712/043228.834020:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[77494:77494:0712/043228.834026:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[77494:77504:0712/043228.834132:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043228.834216:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,77545, 4
[1:7:0712/043228.837914:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77494:77515:0712/043228.862807:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/043228.984667:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x58ee06df220
[1:1:0712/043228.984952:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/043229.227323:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[77494:77494:0712/043230.845291:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[77494:77494:0712/043230.845368:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043230.890960:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043230.894832:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043231.883583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 152029061f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043231.884098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043231.905359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 152029061f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043231.905708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043231.983757:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043232.343411:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043232.343753:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043232.625557:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043232.633777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 152029061f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043232.634239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043232.683053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043232.693983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 152029061f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043232.694253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043232.706444:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043232.709972:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043232.709855:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x58ee06dde20
[1:1:0712/043232.710079:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[77494:77494:0712/043232.724738:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[77494:77494:0712/043232.764687:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[77494:77494:0712/043232.764839:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043232.813589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043233.658404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f90e5bfe2e0 0x58ee09483e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043233.659976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 152029061f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/043233.660285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043233.662028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[77494:77494:0712/043233.740837:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043233.742100:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x58ee06de820
[1:1:0712/043233.742337:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[77494:77494:0712/043233.748391:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/043233.758613:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043233.758764:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[77494:77494:0712/043233.763697:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[77494:77494:0712/043233.775543:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043233.775919:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77494:77494:0712/043233.779203:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[77494:77494:0712/043233.779256:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[77494:77494:0712/043233.779321:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,77545, 4
[77494:77504:0712/043233.779401:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[77494:77504:0712/043233.779561:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/043233.783071:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043234.550549:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/043234.765238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f90e5bfe2e0 0x58ee09871e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043234.766264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 152029061f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/043234.766507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043234.767271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[77494:77494:0712/043234.958472:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[77494:77494:0712/043234.958587:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/043234.989088:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77494:77494:0712/043235.306305:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[77494:77522:0712/043235.306710:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/043235.306885:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043235.307150:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043235.307447:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043235.307624:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/043235.310151:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d05610d, 1
[1:1:0712/043235.310575:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3cc1e784, 0
[1:1:0712/043235.310732:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3e7c7774, 3
[1:1:0712/043235.310875:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1670c1f0, 2
[1:1:0712/043235.311049:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff84ffffffe7ffffffc13c 0d61052d fffffff0ffffffc17016 74777c3e , 10104, 5
[1:1:0712/043235.312055:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[77494:77522:0712/043235.312285:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���<a-��ptw|>-
[77494:77522:0712/043235.312361:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���<a-��ptw|>5-
[77494:77522:0712/043235.312574:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 77592, 5, 84e7c13c 0d61052d f0c17016 74777c3e 
[1:1:0712/043235.312475:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90fa1d50a0, 3
[1:1:0712/043235.312670:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90fa360080, 2
[1:1:0712/043235.312851:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90e4023d20, -2
[1:1:0712/043235.320983:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043235.336429:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043235.336785:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1670c1f0
[1:1:0712/043235.337106:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1670c1f0
[1:1:0712/043235.337715:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1670c1f0
[1:1:0712/043235.339305:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.339491:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.339670:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.339844:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.340527:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1670c1f0
[1:1:0712/043235.340824:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90fbf9a7ba
[1:1:0712/043235.340979:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f90fbf91def, 7f90fbf9a77a, 7f90fbf9c0cf
[1:1:0712/043235.347664:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1670c1f0
[1:1:0712/043235.348182:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1670c1f0
[1:1:0712/043235.349120:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1670c1f0
[1:1:0712/043235.351680:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.352001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.352242:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.352482:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1670c1f0
[1:1:0712/043235.354055:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1670c1f0
[1:1:0712/043235.354512:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90fbf9a7ba
[1:1:0712/043235.354681:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f90fbf91def, 7f90fbf9a77a, 7f90fbf9c0cf
[1:1:0712/043235.364479:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043235.365106:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043235.365298:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff04576838, 0x7fff045767b8)
[1:1:0712/043235.382129:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043235.387598:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/043235.598395:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x58ee069e220
[1:1:0712/043235.598665:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/043235.760120:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043235.760392:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[77494:77494:0712/043236.125057:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043236.131026:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043236.158672:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043236.163435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1520291909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/043236.163763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[77494:77504:0712/043236.166448:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[77494:77504:0712/043236.166552:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043236.166971:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://auto.hexun.com/
[77494:77494:0712/043236.167067:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://auto.hexun.com/, https://auto.hexun.com/2019-07-10/197801250.html, 1
[77494:77494:0712/043236.167267:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://auto.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:32:35 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:33:36 GMT Cache-Control: max-age=60 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,77592, 5
[1:7:0712/043236.171417:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043236.172276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043236.194088:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://auto.hexun.com/
[77494:77494:0712/043236.321417:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://auto.hexun.com/, https://auto.hexun.com/, 1
[77494:77494:0712/043236.321550:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://auto.hexun.com/, https://auto.hexun.com
[1:1:0712/043236.345144:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043236.448920:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043236.516317:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043236.516591:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043236.559860:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043236.560646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 152029061f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/043236.560882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043236.771903:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 158, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043236.773977:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043236.780028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , !function(e,t){"use strict";function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a 
[1:1:0712/043236.780176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043237.691441:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043237.692002:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043237.692383:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043237.692850:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043237.693206:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[77494:77494:0712/043255.235981:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/043255.286959:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043255.480511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 158, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043255.526892:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xb48c49a29c8, 0x58ee0052198
[1:1:0712/043255.527129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 3000
[1:1:0712/043255.527524:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 209
[1:1:0712/043255.527728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 209 0x7f90e3cd6070 0x58ee02af860 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 158
[1:1:0712/043255.740131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/043255.740315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043256.193181:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f90fa360080 0x58ee06a7f60 1 0 0x58ee06a7f78 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043256.198046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (function(e,t){function _(e){var t=M[e]={};return v.each(e.split(y),function(e,n){t[n]=!0}),t}functi
[1:1:0712/043256.198209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043256.404468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f90fa360080 0x58ee06a7f60 1 0 0x58ee06a7f78 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043256.421434:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f90fa360080 0x58ee06a7f60 1 0 0x58ee06a7f78 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043256.432275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f90fa360080 0x58ee06a7f60 1 0 0x58ee06a7f78 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.390623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043257.390942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043257.403757:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.404466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , /*用于加载事件*/
var dplus_PubConfigData_Load = {
    "页面浏览": {
        "属性名�
[1:1:0712/043257.404587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043257.405802:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.406996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.418068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.423568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.454899:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.459251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.509835:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xb48c49a29c8, 0x58ee0052198
[1:1:0712/043257.510045:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 3000
[1:1:0712/043257.510447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 316
[1:1:0712/043257.510633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 316 0x7f90e3cd6070 0x58ee0f80f60 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 259
[1:1:0712/043257.530820:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.553140:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.590245:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.601169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.639462:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.234135, 277, 1
[1:1:0712/043257.639640:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043257.733931:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043257.736812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , c.onload, (){t(c.responseText)}
[1:1:0712/043257.737029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043257.740679:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052518
[1:1:0712/043257.740873:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043257.741266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 347
[1:1:0712/043257.741479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 347 0x7f90e3cd6070 0x58ee0fbcce0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 266
[1:1:0712/043257.928875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043257.929121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043258.916736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043258.917505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , c.onload, (){t(c.responseText)}
[1:1:0712/043258.917798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043258.919991:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052210
[1:1:0712/043258.920199:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043258.920625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 378
[1:1:0712/043258.920887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 378 0x7f90e3cd6070 0x58ee0f7e560 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 333
[1:1:0712/043258.943445:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043258.943770:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043258.944778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7f90e3cd6070 0x58ee0fd3ce0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043258.945688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , articleTop.scrollTop();articleTop.isLogin();
[1:1:0712/043258.945903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[77494:77494:0712/043259.055608:INFO:CONSOLE(226)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/2015/sylogo/hexun_logo.jpg'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (226)
[1:1:0712/043259.056428:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.112514, 84, 1
[1:1:0712/043259.056741:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77494:77494:0712/043259.063193:INFO:CONSOLE(226)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/images2008/emp.gif'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (226)
[1:1:0712/043259.179056:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043259.264191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 347, 7f90e661b881
[1:1:0712/043259.275282:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"266","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043259.275624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"266","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043259.276026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043259.276639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043259.276879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043259.282629:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043259.282873:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043259.283396:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 400
[1:1:0712/043259.283625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 400 0x7f90e3cd6070 0x58ee0d30860 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 347 0x7f90e3cd6070 0x58ee0fbcce0 
[1:1:0712/043259.394313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043259.394593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043259.745031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 209, 7f90e661b881
[1:1:0712/043259.759921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"158","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043259.760314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"158","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043259.760746:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043259.761377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){s(i+" timeout")}
[1:1:0712/043259.761592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043259.882077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 378, 7f90e661b881
[1:1:0712/043259.902192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"333","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043259.902536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"333","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043259.902988:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043259.903699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043259.903949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043259.907638:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043259.907859:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043259.908320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 415
[1:1:0712/043259.908552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 415 0x7f90e3cd6070 0x58ee10a17e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 378 0x7f90e3cd6070 0x58ee0f7e560 
[1:1:0712/043300.051498:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043300.051836:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043300.055312:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7f90e3cd6070 0x58ee0cb8a60 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043300.057815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , /*
	*Created by ZhangWei on 2014/11/11.
	*以stockType【0,1,2,3】为健值进行配对
	*以typ
[1:1:0712/043300.058091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043300.071598:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7f90e3cd6070 0x58ee0cb8a60 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043300.088567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7f90e3cd6070 0x58ee0cb8a60 , "https://auto.hexun.com/2019-07-10/197801250.html"
[77494:77494:0712/043300.134500:INFO:CONSOLE(283)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://imagecn.gasgoo.com/moblogo/News/UEditor/image/20190709/6369829296371907028351512.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (283)
[77494:77494:0712/043300.142129:INFO:CONSOLE(292)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://imagecn.gasgoo.com/moblogo/News/UEditor/image/20190709/6369829296404667022551040.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (292)
[1:1:0712/043300.146193:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043300.149918:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043300.150731:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x58ee106ca20
[1:1:0712/043300.150939:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[77494:77494:0712/043300.156985:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/043300.174063:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.122187, 226, 1
[1:1:0712/043300.174377:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[77494:77494:0712/043300.194592:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://auto.hexun.com/, https://auto.hexun.com/, 4
[77494:77494:0712/043300.194762:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://auto.hexun.com/, https://auto.hexun.com
[1:1:0712/043300.320929:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7f90e5bfe2e0 0x58ee0fd30e0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043300.328462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , !function(a){function b(){b.done||(b.done=!0,S=!0,N=!1,P.each(ba,function(a){a._dom_loaded()}))}func
[1:1:0712/043300.328890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043300.880837:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 400, 7f90e661b881
[1:1:0712/043300.892049:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"347 0x7f90e3cd6070 0x58ee0fbcce0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043300.892410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"347 0x7f90e3cd6070 0x58ee0fbcce0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043300.892792:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043300.893427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043300.893649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043300.897713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043300.897923:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043300.898596:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 512
[1:1:0712/043300.898858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 512 0x7f90e3cd6070 0x58ee15f6960 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 400 0x7f90e3cd6070 0x58ee0d30860 
[1:1:0712/043300.983245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043300.983559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043301.111285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 415, 7f90e661b881
[1:1:0712/043301.125172:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"378 0x7f90e3cd6070 0x58ee0f7e560 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043301.125562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"378 0x7f90e3cd6070 0x58ee0f7e560 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043301.125998:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043301.126681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043301.126898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043301.130134:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043301.130343:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043301.130848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 520
[1:1:0712/043301.131094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 520 0x7f90e3cd6070 0x58ee08198e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 415 0x7f90e3cd6070 0x58ee10a17e0 
[1:1:0712/043302.725787:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043302.726074:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043302.734243:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043302.735620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , $(function() {
	var ulr = "https://mbsug.ssl.so.com/idxdata/get?";
	var hotnum = 3 ;
	function ge
[1:1:0712/043302.735878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "auto.hexun.com", 3, 1, , , 0
[1:1:0712/043302.742062:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043302.743390:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043302.745568:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x58ee16eea20
[1:1:0712/043302.745773:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[77494:77494:0712/043302.750126:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/043302.763262:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043302.763513:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77494:0712/043302.767410:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[1:1:0712/043302.769520:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
		remove user.10_320efb6c -> 0
[1:1:0712/043302.809275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043302.861809:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[77494:77494:0712/043302.960008:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043302.966616:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77494:77504:0712/043302.995668:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[77494:77494:0712/043302.995737:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.hexun.com/
[77494:77504:0712/043302.995773:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043302.995782:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://www.hexun.com/, https://www.hexun.com/hxpage/index.html?fromhost=auto, 5
[77494:77494:0712/043302.995914:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://www.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:33:02 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:33:38 GMT Cache-Control: max-age=60 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,77592, 5
[1:7:0712/043303.001390:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043303.075262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043303.089627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
[77494:77494:0712/043303.091747:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://www.beian.gov.cn/file/ghs.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[77494:77494:0712/043303.148836:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/2015/sylogo/auto_logo.gif'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[1:1:0712/043303.148893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043303.152119:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "auto.hexun.com", "hexun.com"
[1:1:0712/043303.166484:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043303.167823:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043303.172411:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x58ee16fb220
[1:1:0712/043303.172803:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[77494:77494:0712/043303.174932:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/043303.199487:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043303.199745:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77494:0712/043303.201278:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[1:1:0712/043303.208216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043303.220986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 446 0x7f90e3cd6070 0x58ee0d29960 , "https://auto.hexun.com/2019-07-10/197801250.html"
[77494:77494:0712/043303.289901:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043303.295521:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77494:77504:0712/043303.316667:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[77494:77504:0712/043303.316729:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043303.319228:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://utrack.hexun.com/
[77494:77494:0712/043303.319270:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://utrack.hexun.com/, https://utrack.hexun.com/usertrack.aspx?site=https%3A//auto.hexun.com/2019-07-10/197801250.html&time=1562931183154&rsite=, 6
[77494:77494:0712/043303.319329:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://utrack.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:33:03 GMT Content-Type: text/html; charset=gb2312 Content-Length: 717 Connection: keep-alive Cache-Control: no-cache Pragma: no-cache Expires: -1 X-Powered-By: ASP.NET X-AspNet-Version: 2.0.50727 Set-Cookie: HexunTrack=SID=2019071219175101338081a23c7164514b48611e60fef35a3&CITY=11&TOWN=0; domain=hexun.com; expires=Wed, 06-Apr-2022 16:00:00 GMT; path=/  ,77592, 5
[1:7:0712/043303.320233:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043304.350866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 316, 7f90e661b881
[1:1:0712/043304.361425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"259","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043304.361747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"259","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043304.362123:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.362732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){s(i+" timeout")}
[1:1:0712/043304.362946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043304.495693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 510 0x7f90e5bfe2e0 0x58ee105f760 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.506877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , //abtest111
//-> 19


    var _taboola = _taboola || [];var TRC = TRC || {};
TRC.perfConfOverride = 
[1:1:0712/043304.507176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043304.540185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0xb48c49a29c8, 0x58ee0052190
[1:1:0712/043304.540522:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 10000
[1:1:0712/043304.540992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 611
[1:1:0712/043304.541225:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7f90e3cd6070 0x58ee1676360 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 510 0x7f90e5bfe2e0 0x58ee105f760 
[1:1:0712/043304.541847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 1000
[1:1:0712/043304.542260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 612
[1:1:0712/043304.542514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7f90e3cd6070 0x58ee165e0e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 510 0x7f90e5bfe2e0 0x58ee105f760 
[1:1:0712/043304.543012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 5000
[1:1:0712/043304.543442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 613
[1:1:0712/043304.543683:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f90e3cd6070 0x58ee1668260 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 510 0x7f90e5bfe2e0 0x58ee105f760 
[1:1:0712/043304.544477:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 5000
[1:1:0712/043304.544891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 614
[1:1:0712/043304.545125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f90e3cd6070 0x58ee1668860 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 510 0x7f90e5bfe2e0 0x58ee105f760 
		remove user.11_e90902b5 -> 0
[1:1:0712/043304.587477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 511 0x7f90e5bfe2e0 0x58ee0936660 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.588655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , jQuery18309446301125401295_1562931176344({"islogin":"False","userid":"","username":"","nickname":"",
[1:1:0712/043304.588917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043304.589974:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.843063:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 512, 7f90e661b881
[1:1:0712/043304.871717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"400 0x7f90e3cd6070 0x58ee0d30860 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043304.872101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"400 0x7f90e3cd6070 0x58ee0d30860 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043304.872515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.873149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043304.873379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043304.875793:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043304.876027:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043304.876498:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 622
[1:1:0712/043304.876743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f90e3cd6070 0x58ee1bb81e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 512 0x7f90e3cd6070 0x58ee15f6960 
[1:1:0712/043304.935678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043304.935970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043304.978815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 517 0x7f90e5bfe2e0 0x58ee15f66e0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.979814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , hx_json11562931180108([{"code":"000002","name":"平安银行"}])
[1:1:0712/043304.980100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043304.981733:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.998227:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 518 0x7f90e5bfe2e0 0x58ee1643360 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043304.999611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043304.999878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043305.035542:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 520, 7f90e661b881
[1:1:0712/043305.061884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"415 0x7f90e3cd6070 0x58ee10a17e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043305.062262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"415 0x7f90e3cd6070 0x58ee10a17e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043305.063519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043305.064146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043305.064380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043305.066744:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043305.066947:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043305.067371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 628
[1:1:0712/043305.067622:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7f90e3cd6070 0x58ee1669e60 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 520 0x7f90e3cd6070 0x58ee08198e0 
[1:1:0712/043305.148190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043305.148471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043306.026689:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://www.hexun.com/
[1:1:0712/043306.090183:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043306.090443:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77494:0712/043306.091900:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[77494:77494:0712/043306.137168:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043306.142347:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77494:77504:0712/043306.155566:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[77494:77504:0712/043306.155672:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043306.155702:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.hexun.com/
[77494:77494:0712/043306.155761:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.hexun.com/, https://www.hexun.com/hxpage-hcd/, 4
[77494:77494:0712/043306.155877:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://www.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:33:06 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:33:11 GMT Cache-Control: max-age=60 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,77592, 5
[1:7:0712/043306.160837:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043307.053821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 593, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.055700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , ,  //广告投放
 function hexunOutTimer(yr_n,mt_n,dt_n,hr_n,mn_n){
	var temp_date=new Date();
	if
[1:1:0712/043307.056015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043307.100376:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://auto.hexun.com/2019-07-10/197801250.html"
[77494:77494:0712/043307.114202:INFO:CONSOLE(241)] "Uncaught TypeError: Cannot read property 'style' of undefined", source: https://itv.hexun.com/lbi-html/ly/2011/allPages/hx_page_tempAd.js (241)
[1:1:0712/043307.118247:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 593, "https://auto.hexun.com/2019-07-10/197801250.html"
[77494:77494:0712/043307.120597:INFO:CONSOLE(615)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://i0.hexun.com/2017-12-27/192100705.jpg'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (615)
[1:1:0712/043307.124315:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 593, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.127278:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 593, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.136735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 593, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.137926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0xb48c49a29c8, 0x58ee00521a0
[1:1:0712/043307.138187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 50
[1:1:0712/043307.138617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 676
[1:1:0712/043307.138846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f90e3cd6070 0x58ee1a1aae0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 593
[1:1:0712/043307.141185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 593, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.203067:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://utrack.hexun.com/
[1:1:0712/043307.744282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 622, 7f90e661b881
[1:1:0712/043307.773970:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"512 0x7f90e3cd6070 0x58ee15f6960 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043307.774378:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"512 0x7f90e3cd6070 0x58ee15f6960 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043307.774821:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.775468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043307.775685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043307.795740:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043307.796034:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043307.796502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 693
[1:1:0712/043307.796731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f90e3cd6070 0x58ee19aaf60 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 622 0x7f90e3cd6070 0x58ee1bb81e0 
[1:1:0712/043307.821987:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.822916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043307.823161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043307.855025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043307.855354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043307.916917:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 628, 7f90e661b881
[1:1:0712/043307.946534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"520 0x7f90e3cd6070 0x58ee08198e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043307.946889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"520 0x7f90e3cd6070 0x58ee08198e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043307.947357:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043307.947981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043307.948263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043307.969891:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043307.970180:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043307.970651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 700
[1:1:0712/043307.970879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f90e3cd6070 0x58ee1c8f6e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 628 0x7f90e3cd6070 0x58ee1669e60 
[1:1:0712/043308.136034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043308.136319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043308.497017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 612, 7f90e661b8db
[1:1:0712/043308.527227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043308.527611:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043308.528125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 714
[1:1:0712/043308.528357:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7f90e3cd6070 0x58ee1056560 , 5:3_https://auto.hexun.com/, 0, , 612 0x7f90e3cd6070 0x58ee165e0e0 
[1:1:0712/043308.528700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043308.529311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043308.529566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043308.530652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043308.530850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043308.531270:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 715
[1:1:0712/043308.531533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f90e3cd6070 0x58ee1c8b3e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 612 0x7f90e3cd6070 0x58ee165e0e0 
[1:1:0712/043308.601254:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77494:77494:0712/043308.610915:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://www.hexun.com/, https://www.hexun.com/, 5
[77494:77494:0712/043308.611006:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://www.hexun.com/, https://www.hexun.com
[1:1:0712/043308.664923:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://www.hexun.com/
[1:1:0712/043309.511221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 681, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043309.512729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , eval(function (p, a, c, k, e, d) { e = function (c) { return (c < a ? "" : e(parseInt(c / a))) + ((c
[1:1:0712/043309.512967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[77494:77494:0712/043309.872042:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s22.cnzz.com/z_stat.php?id=1262910136, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://utrack.hexun.com/dp/hexun_uweb.js (7)
[77494:77494:0712/043309.881404:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s22.cnzz.com/z_stat.php?id=1262910136, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://utrack.hexun.com/dp/hexun_uweb.js (7)
[1:1:0712/043309.918781:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 676, 7f90e661b881
[1:1:0712/043309.939681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"593","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043309.939876:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"593","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043309.940176:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043309.940502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){
            typeof $.hxpctraffic !== "undefined" && $.hxpctraffic("HXGG20190415",false, "浏览�
[1:1:0712/043309.940608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043310.122749:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[77494:77494:0712/043310.126776:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://utrack.hexun.com/, https://utrack.hexun.com/, 6
[77494:77494:0712/043310.126887:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://utrack.hexun.com/, https://utrack.hexun.com
[1:1:0712/043310.202385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 688 0x7f90e5bfe2e0 0x58ee10c48e0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043310.203272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , function udm_(e,t){var n="comScore=",r=document,i=r.cookie,s="",o="indexOf",u="substring",a="length"
[1:1:0712/043310.203430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043310.253900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 689 0x7f90e5bfe2e0 0x58ee1d6eee0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043310.254704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , /* NKS0406 */!function(){function h(){document.addEventListener?(document.removeEventListener("DOMCo
[1:1:0712/043310.254832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043310.290352:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 693, 7f90e661b881
[1:1:0712/043310.316832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"622 0x7f90e3cd6070 0x58ee1bb81e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043310.317232:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"622 0x7f90e3cd6070 0x58ee1bb81e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043310.317633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043310.317981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043310.318140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043310.323165:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043310.323423:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043310.323970:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 772
[1:1:0712/043310.324175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 772 0x7f90e3cd6070 0x58ee1ee2ee0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 693 0x7f90e3cd6070 0x58ee19aaf60 
[1:1:0712/043310.336082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043310.336245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043310.393276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043310.393723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043310.393843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043310.394599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 700, 7f90e661b881
[1:1:0712/043310.405209:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"628 0x7f90e3cd6070 0x58ee1669e60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043310.405412:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"628 0x7f90e3cd6070 0x58ee1669e60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043310.405650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043310.405983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043310.406208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043310.409094:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043310.409225:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043310.409403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 776
[1:1:0712/043310.409512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 776 0x7f90e3cd6070 0x58ee1b6e7e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 700 0x7f90e3cd6070 0x58ee1c8f6e0 
[1:1:0712/043310.498253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043310.498547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[77494:77494:0712/043310.596454:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://i0.hexun.com/2016/pc/ad/bannercode/img/bg_btm.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[77494:77494:0712/043310.610067:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/zl/hx/articlePage/images/appbtn.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[77494:77494:0712/043310.634493:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/zl/hx/articlePage/images/share.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[77494:77494:0712/043310.644872:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/zl/hx/articlePage/images/share.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[77494:77494:0712/043310.652333:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/zl/hx/articlePage/images/share.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[77494:77494:0712/043310.666916:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://img.hexun.com/zl/hx/index/images/dong.gif'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[77494:77494:0712/043310.682734:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://i0.hexun.com/2016/pc/ad/bannercode/img/popBg.png'. This content should also be served over HTTPS.", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043311.093862:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 715, 7f90e661b881
[1:1:0712/043311.124885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"612 0x7f90e3cd6070 0x58ee165e0e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.125200:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"612 0x7f90e3cd6070 0x58ee165e0e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.125605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043311.126121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){s.push(e.now()-t)}
[1:1:0712/043311.126290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043311.127443:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 714, 7f90e661b8db
[1:1:0712/043311.160728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"612 0x7f90e3cd6070 0x58ee165e0e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.161019:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"612 0x7f90e3cd6070 0x58ee165e0e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.161471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 828
[1:1:0712/043311.161672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7f90e3cd6070 0x58ee1cb62e0 , 5:3_https://auto.hexun.com/, 0, , 714 0x7f90e3cd6070 0x58ee1056560 
[1:1:0712/043311.161960:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043311.162574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043311.162755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043311.163493:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043311.163657:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043311.164038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 829
[1:1:0712/043311.164228:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f90e3cd6070 0x58ee1ddd2e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 714 0x7f90e3cd6070 0x58ee1056560 
[1:1:0712/043311.314664:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043311.491013:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043311.578035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 736 0x7f90e5bfe2e0 0x58ee19aa460 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043311.578712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , /* NKS0406 */!function(){function h(){document.addEventListener?(document.removeEventListener("DOMCo
[1:1:0712/043311.578830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043311.762228:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 613, 7f90e661b8db
[77494:77494:0712/043311.763258:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.hexun.com/, https://www.hexun.com/, 4
[77494:77494:0712/043311.763304:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.hexun.com/, https://www.hexun.com
[1:1:0712/043311.789874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.790072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.790321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 849
[1:1:0712/043311.790461:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f90e3cd6070 0x58ee1f9d1e0 , 5:3_https://auto.hexun.com/, 0, , 613 0x7f90e3cd6070 0x58ee1668260 
[1:1:0712/043311.790613:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043311.790920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/043311.791024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043311.803879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 614, 7f90e661b8db
[1:1:0712/043311.815171:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.815350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043311.815610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 850
[1:1:0712/043311.815725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f90e3cd6070 0x58ee1135660 , 5:3_https://auto.hexun.com/, 0, , 614 0x7f90e3cd6070 0x58ee1668860 
[1:1:0712/043311.815874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043311.816174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/043311.816278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043311.940325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 752, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043311.947844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (function(){function p(){this.c="1262910136";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/043311.948106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[77494:77494:0712/043312.021298:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1262910136&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s22.cnzz.com/z_stat.php?id=1262910136 (17)
[77494:77494:0712/043312.030653:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1262910136&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s22.cnzz.com/z_stat.php?id=1262910136 (17)
[1:1:0712/043312.162478:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043312.579012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043312.579184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043312.580385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 772, 7f90e661b881
[1:1:0712/043312.597222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"693 0x7f90e3cd6070 0x58ee19aaf60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043312.597461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"693 0x7f90e3cd6070 0x58ee19aaf60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043312.597773:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043312.598189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043312.598350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043312.635091:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 776, 7f90e661b881
[1:1:0712/043312.660028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"700 0x7f90e3cd6070 0x58ee1c8f6e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043312.660325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"700 0x7f90e3cd6070 0x58ee1c8f6e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043312.660723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043312.661354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/043312.661528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043312.705245:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043312.706005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , r, (e,i){var u,f,l,c,h;try{if(r&&(i||a.readyState===4)){r=t,o&&(a.onreadystatechange=v.noop,Bn&&delete 
[1:1:0712/043312.706185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043312.707412:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043312.709758:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043312.710448:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2496b4c1c7c8
[77494:77494:0712/043312.725386:INFO:CONSOLE(3)] "[object Object]", source: https://i2.hexun.com/2016/modules/hxpctraffic.0.0.1.min.js?v=1 (3)
[1:1:0712/043313.575354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043313.575597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043314.055234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 829, 7f90e661b881
[1:1:0712/043314.073361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"714 0x7f90e3cd6070 0x58ee1056560 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043314.073568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"714 0x7f90e3cd6070 0x58ee1056560 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043314.073805:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043314.074164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){s.push(e.now()-t)}
[1:1:0712/043314.074273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043314.110517:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043314.110671:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.hexun.com/hxpage/index.html?fromhost=auto"
[1:1:0712/043314.153250:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0426459, 259, 1
[1:1:0712/043314.153548:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043314.218061:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043314.422783:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 828, 7f90e661b8db
[1:1:0712/043314.461208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"714 0x7f90e3cd6070 0x58ee1056560 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043314.461503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"714 0x7f90e3cd6070 0x58ee1056560 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043314.461936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 914
[1:1:0712/043314.462136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 914 0x7f90e3cd6070 0x58ee22fba60 , 5:3_https://auto.hexun.com/, 0, , 828 0x7f90e3cd6070 0x58ee1cb62e0 
[1:1:0712/043314.462434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043314.463000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043314.463202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043314.463881:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043314.464039:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043314.464468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 915
[1:1:0712/043314.464660:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 915 0x7f90e3cd6070 0x58ee19a13e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 828 0x7f90e3cd6070 0x58ee1cb62e0 
[1:1:0712/043314.823848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 864, "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043314.824837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043314.824987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043314.842393:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043314.842545:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://utrack.hexun.com/usertrack.aspx?site=https%3A//auto.hexun.com/2019-07-10/197801250.html&time=1562931183154&rsite="
[1:1:0712/043315.171790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043315.172029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043316.048736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043316.048995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043316.598941:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043316.599157:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.hexun.com/hxpage/index.html?fromhost=auto"
[1:1:0712/043316.602770:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 908 0x7f90e3cd6070 0x58ee2320960 , "https://www.hexun.com/hxpage/index.html?fromhost=auto"
[77494:77494:0712/043316.604336:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure script 'http://c.wrating.com/a1.js'. This request has been blocked; the content must be served over HTTPS.", source: https://www.hexun.com/hxpage/index.html?fromhost=auto (0)
[1:1:0712/043316.641972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://www.hexun.com/, 13439d621d18, , , 
var vjAcc="860010-2918010100";
var wrUrl="http://c.wrating.com/";
vjTrack("");

[1:1:0712/043316.642284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.hexun.com/hxpage/index.html?fromhost=auto", "www.hexun.com", 5, 1, https://auto.hexun.com, hexun.com, 3
[1:1:0712/043316.647109:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 908 0x7f90e3cd6070 0x58ee2320960 , "https://www.hexun.com/hxpage/index.html?fromhost=auto"
[77494:77494:0712/043316.649671:INFO:CONSOLE(81)] "Uncaught ReferenceError: vjTrack is not defined", source: https://www.hexun.com/hxpage/index.html?fromhost=auto (81)
[77494:77494:0712/043316.676648:INFO:CONSOLE(98)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure script 'http://m.wrating.com/m.gif?a=&c=860010-2370010130&mcookie=2019071219175101338081a23c7164514b48611e60fef35a3&callback=hxbase_json1562931196669'. This request has been blocked; the content must be served over HTTPS.", source: https://www.hexun.com/hxpage/index.html?fromhost=auto (98)
[77494:77494:0712/043316.680748:INFO:CONSOLE(98)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure script 'http://m.wrating.com/m.gif?a=&c=860010-2370010131&mcookie=undefined&callback=hxbase_json1562931196673'. This request has been blocked; the content must be served over HTTPS.", source: https://www.hexun.com/hxpage/index.html?fromhost=auto (98)
[1:1:0712/043316.731208:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043316.731427:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.hexun.com/hxpage-hcd/"
[77494:77494:0712/043316.762524:INFO:CONSOLE(26)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://i7.hexun.com/2019-07-05/197752058.jpg'. This content should also be served over HTTPS.", source: https://www.hexun.com/hxpage-hcd/ (26)
[1:1:0712/043316.802326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f90e5bfe2e0 0x58ee2346760 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043316.812330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/043316.812590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[77494:77494:0712/043317.578266:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/043318.204968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 915, 7f90e661b881
[1:1:0712/043318.225919:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"828 0x7f90e3cd6070 0x58ee1cb62e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.226104:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"828 0x7f90e3cd6070 0x58ee1cb62e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.226332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043318.226652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){s.push(e.now()-t)}
[1:1:0712/043318.227165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043318.324622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 611, 7f90e661b881
[1:1:0712/043318.364632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.364930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"510 0x7f90e5bfe2e0 0x58ee105f760 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.365291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043318.365861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){v(),o.measureInterval&&(this.measureInterval=setInterval(v,Math.max(Number(o.measureInterval),1e4
[1:1:0712/043318.366030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043318.382082:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043318.385260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 914, 7f90e661b8db
[77494:77494:0712/043318.387583:INFO:CONSOLE(11)] "Uncaught TypeError: (t.TRCImpl && t.TRCImpl.getGlobalSessionData.trcBind(...)) is not a function", source: https://cdn.taboola.com/libtrc/hexun-hxcom/loader.js (11)
[1:1:0712/043318.399687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"828 0x7f90e3cd6070 0x58ee1cb62e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.399854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"828 0x7f90e3cd6070 0x58ee1cb62e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.400082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1001
[1:1:0712/043318.400209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7f90e3cd6070 0x58ee1c977e0 , 5:3_https://auto.hexun.com/, 0, , 914 0x7f90e3cd6070 0x58ee22fba60 
[1:1:0712/043318.400437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043318.400735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043318.400839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043318.401144:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043318.401240:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043318.401452:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 1002
[1:1:0712/043318.401564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1002 0x7f90e3cd6070 0x58ee28fe560 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 914 0x7f90e3cd6070 0x58ee22fba60 
[1:1:0712/043318.402067:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 849, 7f90e661b8db
[1:1:0712/043318.415490:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"613 0x7f90e3cd6070 0x58ee1668260 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.415667:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"613 0x7f90e3cd6070 0x58ee1668260 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.415904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1003
[1:1:0712/043318.416019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f90e3cd6070 0x58ee2320ee0 , 5:3_https://auto.hexun.com/, 0, , 849 0x7f90e3cd6070 0x58ee1f9d1e0 
[1:1:0712/043318.416198:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043318.416555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/043318.416676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043318.445338:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 850, 7f90e661b8db
[1:1:0712/043318.471087:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"614 0x7f90e3cd6070 0x58ee1668860 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.471359:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"614 0x7f90e3cd6070 0x58ee1668860 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043318.471761:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1005
[1:1:0712/043318.471965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7f90e3cd6070 0x58ee039a760 , 5:3_https://auto.hexun.com/, 0, , 850 0x7f90e3cd6070 0x58ee1135660 
[1:1:0712/043318.472274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043318.472906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/043318.473080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043318.576541:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043318.651743:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043318.652178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043318.652291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043318.837190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043318.837449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043318.914700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/043318.914879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043320.235933:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043320.236155:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043320.240239:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1006 0x7f90e3cd6070 0x58ee117a9e0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043320.241433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , 
jQuery(document).ready(function () {

	if(window.location.pathname.indexOf("hjxh") > 0 ){
		ret
[1:1:0712/043320.241619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043320.250515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1006 0x7f90e3cd6070 0x58ee117a9e0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[77494:77494:0712/043320.350640:INFO:CONSOLE(276)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure image 'http://i9.hexun.com/2017-08-07/190346649.jpg'. This content should also be served over HTTPS.", source: https://hxjstool.hexun.com/auto/hx_pageMediaControl.js (276)
[1:1:0712/043320.549534:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0xb48c49a29c8, 0x58ee0052240
[1:1:0712/043320.549787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 20000
[1:1:0712/043320.550235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 1060
[1:1:0712/043320.550468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7f90e3cd6070 0x58ee2ba3ae0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 1006 0x7f90e3cd6070 0x58ee117a9e0 
[77494:77494:0712/043320.557554:INFO:CONSOLE(338)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure script 'http://bdc.hexun.com:8088/restfulES/restful?tag=userTarget&args=0,2019071219175101338081a23c7164514b48611e60fef35a3&callback=hexunjsonp_07789744097591309'. This request has been blocked; the content must be served over HTTPS.", source: https://hxjstool.hexun.com/auto/hx_pageMediaControl.js (338)
[77494:77494:0712/043320.567409:INFO:CONSOLE(434)] "Mixed Content: The page at 'https://auto.hexun.com/2019-07-10/197801250.html' was loaded over HTTPS, but requested an insecure script 'http://itv.hexun.com/lbi-html/ly/2011/allPages/setpageview.js'. This request has been blocked; the content must be served over HTTPS.", source: https://hxjstool.hexun.com/auto/hx_pageMediaControl.js (434)
[1:1:0712/043320.563976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1006 0x7f90e3cd6070 0x58ee117a9e0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043320.583090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1006 0x7f90e3cd6070 0x58ee117a9e0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043320.593166:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043320.594363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043320.604351:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://auto.hexun.com/2019-07-10/197801250.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043335.203714:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043335.456549:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0xb48c49a29c8, 0x58ee0052210
[1:1:0712/043335.457233:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 3000
[1:1:0712/043335.457747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 1112
[1:1:0712/043335.458024:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7f90e3cd6070 0x58ee861bde0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 1006 0x7f90e3cd6070 0x58ee117a9e0 
[1:1:0712/043336.021580:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043336.025131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043336.038082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee00521e0
[1:1:0712/043336.038349:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043336.038903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 1128
[1:1:0712/043336.039148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1128 0x7f90e3cd6070 0x58ee87d8460 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 1006 0x7f90e3cd6070 0x58ee117a9e0 
[77494:77494:0712/043336.145496:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: https://auto.hexun.com/2019-07-10/197801250.html (0)
[1:1:0712/043336.197775:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 1002, 7f90e661b881
[1:1:0712/043336.243915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13439d542860","ptid":"914 0x7f90e3cd6070 0x58ee22fba60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.244259:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://auto.hexun.com/","ptid":"914 0x7f90e3cd6070 0x58ee22fba60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.244722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043336.245300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){s.push(e.now()-t)}
[1:1:0712/043336.245527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043336.294174:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1001, 7f90e661b8db
[1:1:0712/043336.313665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"914 0x7f90e3cd6070 0x58ee22fba60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.313859:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"914 0x7f90e3cd6070 0x58ee22fba60 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.314130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1151
[1:1:0712/043336.314252:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1151 0x7f90e3cd6070 0x58ee8307a60 , 5:3_https://auto.hexun.com/, 0, , 1001 0x7f90e3cd6070 0x58ee1c977e0 
[1:1:0712/043336.314466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043336.314781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/043336.314889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043336.315206:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xb48c49a29c8, 0x58ee0052150
[1:1:0712/043336.315302:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 0
[1:1:0712/043336.315547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://auto.hexun.com/, 1152
[1:1:0712/043336.315664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1152 0x7f90e3cd6070 0x58ee117a9e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 1001 0x7f90e3cd6070 0x58ee1c977e0 
[1:1:0712/043336.468536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , document.readyState
[1:1:0712/043336.468737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043336.485971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "scroll", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043336.486689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , u, (e){return typeof v=="undefined"||!!e&&v.event.triggered===e.type?t:v.event.dispatch.apply(u.elem,ar
[1:1:0712/043336.486864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043336.708973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1003, 7f90e661b8db
[1:1:0712/043336.764542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"849 0x7f90e3cd6070 0x58ee1f9d1e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.764910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"849 0x7f90e3cd6070 0x58ee1f9d1e0 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.765393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1167
[1:1:0712/043336.765658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7f90e3cd6070 0x58ee2c2d1e0 , 5:3_https://auto.hexun.com/, 0, , 1003 0x7f90e3cd6070 0x58ee2320ee0 
[1:1:0712/043336.766074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043336.766823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/043336.767043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043336.769717:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1005, 7f90e661b8db
[1:1:0712/043336.817845:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"850 0x7f90e3cd6070 0x58ee1135660 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.818122:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"850 0x7f90e3cd6070 0x58ee1135660 ","rf":"5:3_https://auto.hexun.com/"}
[1:1:0712/043336.818534:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1169
[1:1:0712/043336.818758:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7f90e3cd6070 0x58ee872c6e0 , 5:3_https://auto.hexun.com/, 0, , 1005 0x7f90e3cd6070 0x58ee039a760 
[1:1:0712/043336.819069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043336.819655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/043336.819833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043337.256897:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1029 0x7f90e5bfe2e0 0x58ee0339160 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043337.258441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , ___adblockplus({"queryid" : "650ac37daa04eee6","tuid" : "u3646569_0","placement" : {"basic" : {"sspI
[1:1:0712/043337.258677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043337.335805:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043337.338119:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043337.340247:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x58ee069ba20
[1:1:0712/043337.340432:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[77494:77494:0712/043337.344820:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu3646569_0, 7, 7, 
[1:1:0712/043337.361621:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043337.361894:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77494:0712/043337.363678:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[1:1:0712/043337.372639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 500
[1:1:0712/043337.373107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1183
[1:1:0712/043337.373304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1183 0x7f90e3cd6070 0x58ee87006e0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 1029 0x7f90e5bfe2e0 0x58ee0339160 
[1:1:0712/043337.377108:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://auto.hexun.com/2019-07-10/197801250.html", 50
[1:1:0712/043337.377516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://auto.hexun.com/, 1184
[1:1:0712/043337.377707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7f90e3cd6070 0x58ee80ddde0 , 5:3_https://auto.hexun.com/, 1, -5:3_https://auto.hexun.com/, 1029 0x7f90e5bfe2e0 0x58ee0339160 
[1:1:0712/043337.498799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1030 0x7f90e5bfe2e0 0x58ee1eb3560 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043337.500281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , ___adblockplus({"queryid" : "594aef39f51588a5","tuid" : "u3646570_0","placement" : {"basic" : {"sspI
[1:1:0712/043337.500470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[77494:77494:0712/043337.549418:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043337.551137:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043337.560927:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043337.562750:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[77494:77494:0712/043337.562854:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://pos.baidu.com/, https://pos.baidu.com/hcrm?conwid=290&conhei=250&rdid=3646569&dc=3&exps=110011&psi=71ff504e1b2fa44e89e2c1225c034936&di=u3646569&dri=0&dis=0&dai=1&ps=3105x12&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562931197736&ti=%E9%95%BF%E5%AE%89%E6%B1%BD%E8%BD%A6%E5%8D%8A%E5%B9%B4%E8%80%83%7C%E4%B8%8A%E5%8D%8A%E5%B9%B4%E7%B4%AF%E8%AE%A1%E9%94%80%E5%94%AE82.5%E4%B8%87%E8%BE%86%20%E7%A6%8F%E7%89%B9%E3%80%81%E9%A9%AC%E8%87%AA%E8%BE%BE%E8%B7%8C%E5%B9%85%E6%94%B6%E7%AA%84%20-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E5%92%8C%E8%AE%AF%E7%BD%91&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x3565&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562931197&prot=2&rw=471&ltu=https%3A%2F%2Fauto.hexun.com%2F2019-07-10%2F197801250.html&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562931198&qn=650ac37daa04eee6&tt=1562931196826.1122.20441.20484, 7
[77494:77504:0712/043337.562926:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[77494:77504:0712/043337.563005:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043337.563009:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 11742 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 11:33:37 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 19:33:37 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,77592, 5
[1:1:0712/043337.564873:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x58ee069b020
[1:1:0712/043337.565050:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[77494:77494:0712/043337.565260:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:7:0712/043337.566172:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77494:77494:0712/043337.571910:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu3646570_0, 8, 8, 
[1:1:0712/043337.584839:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043337.585071:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77494:0712/043337.589853:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[77494:77494:0712/043337.722156:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043337.723664:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77494:77504:0712/043337.738074:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[77494:77504:0712/043337.738163:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043337.738291:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[77494:77494:0712/043337.738364:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://pos.baidu.com/, https://pos.baidu.com/hcrm?conwid=290&conhei=250&rdid=3646570&dc=3&exps=110011&psi=71ff504e1b2fa44e89e2c1225c034936&di=u3646570&dri=0&dis=0&dai=2&ps=3115x22&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562931197736&ti=%E9%95%BF%E5%AE%89%E6%B1%BD%E8%BD%A6%E5%8D%8A%E5%B9%B4%E8%80%83%7C%E4%B8%8A%E5%8D%8A%E5%B9%B4%E7%B4%AF%E8%AE%A1%E9%94%80%E5%94%AE82.5%E4%B8%87%E8%BE%86%20%E7%A6%8F%E7%89%B9%E3%80%81%E9%A9%AC%E8%87%AA%E8%BE%BE%E8%B7%8C%E5%B9%85%E6%94%B6%E7%AA%84%20-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E5%92%8C%E8%AE%AF%E7%BD%91&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x3565&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562931198&prot=2&rw=471&ltu=https%3A%2F%2Fauto.hexun.com%2F2019-07-10%2F197801250.html&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562931198&qn=594aef39f51588a5&tt=1562931196826.1240.20681.20711, 8
[77494:77494:0712/043337.738508:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 11817 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 11:33:37 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 19:33:37 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,77592, 5
[1:7:0712/043337.754078:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043337.804018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1033 0x7f90e5bfe2e0 0x58ee2a9cde0 , "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043337.805557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , , ___adblockplus({"queryid" : "6ddd2eaad271721b","tuid" : "u949576_0","placement" : {"basic" : {"sspId
[1:1:0712/043337.805809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043337.851031:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043337.853430:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043337.855681:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x58ee106de20
[1:1:0712/043337.855958:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[77494:77494:0712/043337.860315:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu949576_0, 9, 9, 
[1:1:0712/043337.875718:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043337.876000:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77494:0712/043337.878180:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[1:1:0712/043337.945204:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://auto.hexun.com/2019-07-10/197801250.html"
[1:1:0712/043337.946007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://auto.hexun.com/, 13439d542860, , script.onerror, () {
          error && error();
        }
[1:1:0712/043337.946237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://auto.hexun.com/2019-07-10/197801250.html", "hexun.com", 3, 1, , , 0
[1:1:0712/043337.948765:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[77494:77494:0712/043337.950203:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043337.952178:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x58ee069d820
[1:1:0712/043337.952378:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[77494:77494:0712/043337.956900:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[1:1:0712/043337.977016:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043337.977263:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77494:0712/043337.979825:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043337.980393:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043337.980459:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/043337.984219:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x58ee17b3a20
[1:1:0712/043337.984420:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[1:1:0712/043337.995479:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043337.995749:INFO:render_frame_impl.cc(7019)] 	 [url] = https://auto.hexun.com
[77494:77504:0712/043337.998889:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[77494:77504:0712/043337.999002:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043337.999052:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[77494:77494:0712/043337.999095:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://pos.baidu.com/, https://pos.baidu.com/hcrm?conwid=300&conhei=250&rdid=949576&dc=3&exps=110011&psi=71ff504e1b2fa44e89e2c1225c034936&di=u949576&dri=0&dis=0&dai=3&ps=3152x712&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562931197736&ti=%E9%95%BF%E5%AE%89%E6%B1%BD%E8%BD%A6%E5%8D%8A%E5%B9%B4%E8%80%83%7C%E4%B8%8A%E5%8D%8A%E5%B9%B4%E7%B4%AF%E8%AE%A1%E9%94%80%E5%94%AE82.5%E4%B8%87%E8%BE%86%20%E7%A6%8F%E7%89%B9%E3%80%81%E9%A9%AC%E8%87%AA%E8%BE%BE%E8%B7%8C%E5%B9%85%E6%94%B6%E7%AA%84%20-%E6%B1%BD%E8%BD%A6%E9%A2%91%E9%81%93-%E5%92%8C%E8%AE%AF%E7%BD%91&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x3565&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562931198&prot=2&rw=471&ltu=https%3A%2F%2Fauto.hexun.com%2F2019-07-10%2F197801250.html&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562931198&qn=6ddd2eaad271721b&tt=1562931196826.1312.20985.21003, 9
[77494:77494:0712/043337.999175:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 11704 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 11:33:37 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 19:33:37 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,77592, 5
[77494:77494:0712/043338.000097:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[1:7:0712/043338.001689:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77494:77494:0712/043338.002883:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[77494:77494:0712/043338.004737:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 11, 11, 
[77494:77494:0712/043338.007611:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://auto.hexun.com/
[77494:77494:0712/043338.149305:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043338.150272:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[77494:77504:0712/043338.181387:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 10
[77494:77494:0712/043338.181433:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h07hxsame.hexun.com/
[77494:77494:0712/043338.181476:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_https://h07hxsame.hexun.com/, https://h07hxsame.hexun.com/s?z=hexun&c=1720&op=1, 10
[77494:77504:0712/043338.181484:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 10, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043338.181539:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:10_https://h07hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:33:38 GMT Content-Type: text/html; charset=GBK Content-Length: 364 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:33:38 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,77592, 5
[77494:77494:0712/043338.182775:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[77494:77494:0712/043338.183538:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0712/043338.206104:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[77494:77504:0712/043338.213491:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 11
[77494:77504:0712/043338.213581:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 11, HandleIncomingMessage, HandleIncomingMessage
[77494:77494:0712/043338.213740:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h01hxsame.hexun.com/
[77494:77494:0712/043338.213820:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://h01hxsame.hexun.com/, https://h01hxsame.hexun.com/s?z=hexun&c=1724&op=1, 11
[77494:77494:0712/043338.213955:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:11_https://h01hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:33:38 GMT Content-Type: text/html; charset=GBK Content-Length: 364 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:33:38 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,77592, 5
[1:7:0712/043338.217793:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
