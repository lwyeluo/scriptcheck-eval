[0712/042014.202981:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042014.203369:INFO:switcher_clone.cc(787)] backtrace rip is 7f4a7237c891
[0712/042015.077637:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042015.077948:INFO:switcher_clone.cc(787)] backtrace rip is 7f8fa8fdb891
[1:1:0712/042015.082171:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/042015.082371:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/042015.086345:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[76095:76095:0712/042016.250636:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/bc8a6d93-9f25-402b-8998-1251d18d0037
[0712/042016.452254:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042016.452632:INFO:switcher_clone.cc(787)] backtrace rip is 7f168d24a891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[76126:76126:0712/042016.690642:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=76126
[76138:76138:0712/042016.690992:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=76138
[76095:76095:0712/042016.845026:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[76095:76124:0712/042016.845720:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/042016.845935:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042016.846145:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042016.846687:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042016.846860:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/042016.849638:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x18e143f7, 1
[1:1:0712/042016.849959:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1ae8c2c8, 0
[1:1:0712/042016.850158:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x210bd9ad, 3
[1:1:0712/042016.850353:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3c4f36ac, 2
[1:1:0712/042016.850575:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc8ffffffc2ffffffe81a fffffff743ffffffe118 ffffffac364f3c ffffffadffffffd90b21 , 10104, 4
[1:1:0712/042016.851545:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[76095:76124:0712/042016.851840:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����C��6O<��!9�s3
[76095:76124:0712/042016.851917:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����C��6O<��!�9�s3
[1:1:0712/042016.851835:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8fa72160a0, 3
[76095:76124:0712/042016.852218:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[76095:76124:0712/042016.852284:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 76146, 4, c8c2e81a f743e118 ac364f3c add90b21 
[1:1:0712/042016.852132:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8fa73a1080, 2
[1:1:0712/042016.852783:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f91064d20, -2
[1:1:0712/042016.871627:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042016.872293:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c4f36ac
[1:1:0712/042016.873229:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c4f36ac
[1:1:0712/042016.874839:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c4f36ac
[1:1:0712/042016.876356:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.876590:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.876841:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.877073:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.877733:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c4f36ac
[1:1:0712/042016.878114:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8fa8fdb7ba
[1:1:0712/042016.878288:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8fa8fd2def, 7f8fa8fdb77a, 7f8fa8fdd0cf
[1:1:0712/042016.884005:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c4f36ac
[1:1:0712/042016.884395:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c4f36ac
[1:1:0712/042016.885165:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c4f36ac
[1:1:0712/042016.887202:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.887431:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.887649:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.887916:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c4f36ac
[1:1:0712/042016.889181:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c4f36ac
[1:1:0712/042016.889571:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8fa8fdb7ba
[1:1:0712/042016.889739:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8fa8fd2def, 7f8fa8fdb77a, 7f8fa8fdd0cf
[1:1:0712/042016.898370:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042016.898869:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042016.899060:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd12569e88, 0x7ffd12569e08)
[1:1:0712/042016.915261:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042016.921056:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[76095:76095:0712/042017.561674:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76095:76095:0712/042017.562862:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76095:76105:0712/042017.574033:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[76095:76105:0712/042017.574220:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[76095:76095:0712/042017.574373:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[76095:76095:0712/042017.574472:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[76095:76095:0712/042017.574654:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,76146, 4
[1:7:0712/042017.580902:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[76095:76118:0712/042017.619355:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/042017.718809:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x9a1bfedf220
[1:1:0712/042017.719083:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/042018.138895:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/042019.443687:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042019.450332:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76095:76095:0712/042019.487352:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[76095:76095:0712/042019.487477:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042020.526276:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042020.644976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042020.645258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042020.712948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042020.713320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042020.883295:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042020.883676:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042021.389423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042021.397556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042021.397866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042021.435462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042021.446801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042021.447121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042021.451881:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76095:76095:0712/042021.457522:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042021.458109:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x9a1bfedde20
[1:1:0712/042021.458258:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[76095:76095:0712/042021.466095:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[76095:76095:0712/042021.495377:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[76095:76095:0712/042021.495531:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[76095:76095:0712/042021.510292:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/042021.521341:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042022.567683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f8f92c3f2e0 0x9a1bff8b8e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042022.569000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/042022.569198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042022.570629:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[76095:76095:0712/042022.639138:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042022.641491:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x9a1bfede820
[1:1:0712/042022.641704:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[76095:76095:0712/042022.647970:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/042022.648276:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042022.648397:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[76095:76095:0712/042022.675469:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[76095:76095:0712/042022.687477:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76095:76095:0712/042022.688502:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76095:76105:0712/042022.694331:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[76095:76105:0712/042022.694420:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[76095:76095:0712/042022.694571:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[76095:76095:0712/042022.694647:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[76095:76095:0712/042022.694775:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,76146, 4
[1:7:0712/042022.697801:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042023.215571:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/042023.508203:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f8f92c3f2e0 0x9a1c0182ae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042023.509213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/042023.509454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042023.510201:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[76095:76095:0712/042023.665008:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[76095:76095:0712/042023.665112:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/042023.700988:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042024.302513:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[76095:76095:0712/042024.399944:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[76095:76124:0712/042024.400445:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/042024.400667:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042024.400942:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042024.401328:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042024.401470:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/042024.404544:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b0cf098, 1
[1:1:0712/042024.404923:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1adaf91c, 0
[1:1:0712/042024.405123:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38f3e03, 3
[1:1:0712/042024.405318:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3676c0fd, 2
[1:1:0712/042024.405504:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1cfffffff9ffffffda1a ffffff98fffffff00c3b fffffffdffffffc07636 033effffff8f03 , 10104, 5
[1:1:0712/042024.406849:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[76095:76124:0712/042024.407156:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����;��v6>���s3
[76095:76124:0712/042024.407223:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����;��v6>�����s3
[1:1:0712/042024.407155:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8fa72160a0, 3
[76095:76124:0712/042024.407461:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 76192, 5, 1cf9da1a 98f00c3b fdc07636 033e8f03 
[1:1:0712/042024.407370:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8fa73a1080, 2
[1:1:0712/042024.407613:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f91064d20, -2
[1:1:0712/042024.420435:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042024.420917:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3676c0fd
[1:1:0712/042024.421319:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3676c0fd
[1:1:0712/042024.422105:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3676c0fd
[1:1:0712/042024.423522:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.423743:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.423944:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.424134:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.424810:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3676c0fd
[1:1:0712/042024.425100:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8fa8fdb7ba
[1:1:0712/042024.425233:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8fa8fd2def, 7f8fa8fdb77a, 7f8fa8fdd0cf
[1:1:0712/042024.431497:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3676c0fd
[1:1:0712/042024.431968:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3676c0fd
[1:1:0712/042024.432943:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3676c0fd
[1:1:0712/042024.435473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.435767:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.436009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.436257:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3676c0fd
[1:1:0712/042024.437880:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3676c0fd
[1:1:0712/042024.438334:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8fa8fdb7ba
[1:1:0712/042024.438511:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8fa8fd2def, 7f8fa8fdb77a, 7f8fa8fdd0cf
[1:1:0712/042024.448205:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042024.448845:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042024.449034:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd12569e88, 0x7ffd12569e08)
[1:1:0712/042024.465902:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042024.471305:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/042024.540475:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7f8f92c3f2e0 0x9a1c03e46e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042024.541469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , , var ddl = {"usable":false,"v":1};
[1:1:0712/042024.541727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042024.542438:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042024.625479:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042024.625781:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042024.730392:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x9a1bfec2220
[1:1:0712/042024.730667:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[76095:76095:0712/042024.822664:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76095:76095:0712/042024.827668:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76095:76105:0712/042024.862675:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[76095:76105:0712/042024.862814:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[76095:76095:0712/042024.863170:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://trust.hexun.com/
[76095:76095:0712/042024.863260:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://trust.hexun.com/, http://trust.hexun.com/, 1
[76095:76095:0712/042024.863386:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://trust.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:20:24 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:21:12 GMT Cache-Control: max-age=60 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,76192, 5
[1:7:0712/042024.869372:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042024.946710:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://trust.hexun.com/
[76095:76095:0712/042025.066296:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://trust.hexun.com/, http://trust.hexun.com/, 1
[76095:76095:0712/042025.066378:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://trust.hexun.com/, http://trust.hexun.com
[1:1:0712/042025.079407:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042025.164682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042025.169408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0eb8cb8d09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/042025.169728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/042025.173723:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042025.185088:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042025.276576:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042025.326223:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042025.326456:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042025.521633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042025.522496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0eb8cb7a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/042025.522721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042026.116024:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f8fa73a1080 0x9a1bfc8c920 1 0 0x9a1bfc8c938 , "http://trust.hexun.com/"
[1:1:0712/042026.148161:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042026.155193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , /*!
 * jQuery JavaScript Library v1.4.2
 * http://jquery.com/
 *
 * Copyright 2010, John Resig

[1:1:0712/042026.155495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "trust.hexun.com", 3, 1, , , 0
[1:1:0712/042026.211785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f8fa73a1080 0x9a1bfc8c920 1 0 0x9a1bfc8c938 , "http://trust.hexun.com/"
[1:1:0712/042026.301549:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f8fa73a1080 0x9a1bfc8c920 1 0 0x9a1bfc8c938 , "http://trust.hexun.com/"
[1:1:0712/042026.352107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f8fa73a1080 0x9a1bfc8c920 1 0 0x9a1bfc8c938 , "http://trust.hexun.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042026.835637:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042026.836108:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042026.836512:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042026.836953:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042026.837367:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[76095:76095:0712/042044.300971:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/042044.360241:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/042044.496040:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 18.2028, 13, 0
[1:1:0712/042044.496344:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042045.807085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/042045.807387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "trust.hexun.com", 3, 1, , , 0
[1:1:0712/042046.263189:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042046.263465:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042046.264579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 291 0x7f8f90d17070 0x9a1bffe5260 , "http://trust.hexun.com/"
[1:1:0712/042046.265594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , ,  
adhoc('init', { 
appKey: 'ADHOC_584d2ccf-6b52-4fca-826e-66c59854205a' 
}) 

[1:1:0712/042046.265856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "trust.hexun.com", 3, 1, , , 0
[1:1:0712/042046.301879:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x42ea6dc29c8, 0x9a1bfd4d198
[1:1:0712/042046.302169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 3000
[1:1:0712/042046.302531:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 354
[1:1:0712/042046.302770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 354 0x7f8f90d17070 0x9a1c00fc160 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 291 0x7f8f90d17070 0x9a1bffe5260 
[1:1:0712/042046.323222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 291 0x7f8f90d17070 0x9a1bffe5260 , "http://trust.hexun.com/"
[1:1:0712/042046.348256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 291 0x7f8f90d17070 0x9a1bffe5260 , "http://trust.hexun.com/"
[1:1:0712/042046.354020:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 291 0x7f8f90d17070 0x9a1bffe5260 , "http://trust.hexun.com/"
[1:1:0712/042046.357845:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 291 0x7f8f90d17070 0x9a1bffe5260 , "http://trust.hexun.com/"
[1:1:0712/042046.380371:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "trust.hexun.com", "hexun.com"
[1:1:0712/042046.396281:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.132702, 84, 1
[1:1:0712/042046.396524:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042047.061269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042047.061559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042048.062495:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042048.062836:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042048.063824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f8f90d17070 0x9a1bffe5ee0 , "http://trust.hexun.com/"
[1:1:0712/042048.065139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , 
if(document.cookie.indexOf("CITY=50")!=-1){
document.getElementById('nav_house').href="http://cq.ho
[1:1:0712/042048.065367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042048.085810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f8f90d17070 0x9a1bffe5ee0 , "http://trust.hexun.com/"
[1:1:0712/042048.096321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f8f90d17070 0x9a1bffe5ee0 , "http://trust.hexun.com/"
[1:1:0712/042048.126831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7f8f90d17070 0x9a1bffe5ee0 , "http://trust.hexun.com/"
[1:1:0712/042048.161702:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0988069, 116, 1
[1:1:0712/042048.162009:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042048.239169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042048.239416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042048.803364:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://trust.hexun.com/"
[1:1:0712/042048.805919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , c.onload, (){t(c.responseText)}
[1:1:0712/042048.806217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042048.810214:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6dc29c8, 0x9a1bfd4d518
[1:1:0712/042048.810476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 0
[1:1:0712/042048.810908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 446
[1:1:0712/042048.811156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 446 0x7f8f90d17070 0x9a1c0144de0 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 402
[1:1:0712/042049.353820:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042049.354170:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042049.355872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7f8f90d17070 0x9a1bffd8260 , "http://trust.hexun.com/"
[1:1:0712/042049.356855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , 
//滚动层ID,内容层ID,复制层ID,上操作ID,下操作ID，每个li及间隔长度，滚动间
[1:1:0712/042049.357107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042049.370760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7f8f90d17070 0x9a1bffd8260 , "http://trust.hexun.com/"
[1:1:0712/042049.410717:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0557601, 149, 1
[1:1:0712/042049.411041:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042049.483661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042049.484040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042049.641992:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 446, 7f8f9365c881
[1:1:0712/042049.665208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"402","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042049.665558:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"402","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042049.665858:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042049.666412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042049.666625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042049.672341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6dc29c8, 0x9a1bfd4d150
[1:1:0712/042049.672546:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 0
[1:1:0712/042049.672902:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 484
[1:1:0712/042049.673157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7f8f90d17070 0x9a1c013d8e0 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 446 0x7f8f90d17070 0x9a1c0144de0 
[1:1:0712/042049.817208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 354, 7f8f9365c881
[1:1:0712/042049.838933:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"291 0x7f8f90d17070 0x9a1bffe5260 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042049.839288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"291 0x7f8f90d17070 0x9a1bffe5260 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042049.839587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042049.840174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , (){s(i+" timeout")}
[1:1:0712/042049.840399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042050.674293:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042050.674546:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042050.677694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f8f90d17070 0x9a1bfeadfe0 , "http://trust.hexun.com/"
[1:1:0712/042050.678792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , function newCreateHexunFlashObject(src_str,w_num,h_num){
	var temp='<object id="focusMedia" classid
[1:1:0712/042050.679035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042050.684222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f8f90d17070 0x9a1bfeadfe0 , "http://trust.hexun.com/"
[1:1:0712/042050.691215:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f8f90d17070 0x9a1bfeadfe0 , "http://trust.hexun.com/"
[1:1:0712/042050.783154:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.108552, 547, 1
[1:1:0712/042050.783438:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042050.851744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042050.852045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042050.930965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f8f92c3f2e0 0x9a1c035fae0 , "http://trust.hexun.com/"
[1:1:0712/042050.931975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , hx_json11562930448141([{"code":"75075","name":"国投飞天4号证券黄金投资集合资金信托�
[1:1:0712/042050.932211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042050.936887:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://trust.hexun.com/"
[1:1:0712/042050.955266:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 484, 7f8f9365c881
[1:1:0712/042050.977677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"446 0x7f8f90d17070 0x9a1c0144de0 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042050.978009:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"446 0x7f8f90d17070 0x9a1c0144de0 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042050.978347:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042050.978881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042050.979091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042050.982696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6dc29c8, 0x9a1bfd4d150
[1:1:0712/042050.982902:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 0
[1:1:0712/042050.983255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 515
[1:1:0712/042050.983485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 515 0x7f8f90d17070 0x9a1c077cbe0 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 484 0x7f8f90d17070 0x9a1c013d8e0 
[1:1:0712/042051.831933:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042051.832273:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042051.833258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 510 0x7f8f90d17070 0x9a1c00bba60 , "http://trust.hexun.com/"
[1:1:0712/042051.834194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , 
function jump()
{
  window.open("http://data.trust.hexun.com/Entrust.aspx?Filter="+ document.getEle
[1:1:0712/042051.834437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042051.907370:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.074986, 445, 1
[1:1:0712/042051.907703:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042051.944655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042051.944930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042051.960191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 515, 7f8f9365c881
[1:1:0712/042051.976394:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"484 0x7f8f90d17070 0x9a1c013d8e0 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042051.976754:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"484 0x7f8f90d17070 0x9a1c013d8e0 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042051.977055:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042051.977634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042051.977846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042051.980151:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6dc29c8, 0x9a1bfd4d150
[1:1:0712/042051.980385:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 0
[1:1:0712/042051.980798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 564
[1:1:0712/042051.981032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 564 0x7f8f90d17070 0x9a1c0384f60 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 515 0x7f8f90d17070 0x9a1c077cbe0 
[1:1:0712/042053.358540:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042053.358789:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042053.359738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556 0x7f8f90d17070 0x9a1c06e00e0 , "http://trust.hexun.com/"
[1:1:0712/042053.360956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , 

/*信托产品查询*/
function OnClickSearch()
{
var href = "http://data.trust.hexun.com/list.asp
[1:1:0712/042053.361231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042053.496180:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76095:76095:0712/042053.497623:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042053.500362:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x9a1bfec0420
[1:1:0712/042053.500622:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[76095:76095:0712/042053.504486:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/042053.522664:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042053.522914:INFO:render_frame_impl.cc(7019)] 	 [url] = http://trust.hexun.com
[76095:76095:0712/042053.524788:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://trust.hexun.com/
[1:1:0712/042053.582150:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.22327, 1231, 1
[1:1:0712/042053.582418:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[76095:76095:0712/042053.665962:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76095:76095:0712/042053.668903:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/042053.670665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042053.670940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[76095:76105:0712/042053.680050:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[76095:76095:0712/042053.680084:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://data.trust.hexun.com/
[76095:76105:0712/042053.680166:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[76095:76095:0712/042053.680182:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://data.trust.hexun.com/, http://data.trust.hexun.com/map.html, 4
[76095:76095:0712/042053.680319:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://data.trust.hexun.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 11:20:53 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:25:55 GMT Cache-Control: max-age=300 Content-Encoding: gzip X-Via-JSL: 2e45f6a,- Set-Cookie: __jsluid_h=cfbf50e42eccabc9b237ff63d8b5333a; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,76192, 5
[1:7:0712/042053.686620:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042053.702143:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 564, 7f8f9365c881
[1:1:0712/042053.727317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"515 0x7f8f90d17070 0x9a1c077cbe0 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042053.727658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"515 0x7f8f90d17070 0x9a1c077cbe0 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042053.728007:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042053.728545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042053.728756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042053.765778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6dc29c8, 0x9a1bfd4d150
[1:1:0712/042053.766077:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 0
[1:1:0712/042053.766445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 621
[1:1:0712/042053.766672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7f8f90d17070 0x9a1c0144a60 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 564 0x7f8f90d17070 0x9a1c0384f60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042056.540069:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042056.540398:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042056.541419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f8f90d17070 0x9a1c0a145e0 , "http://trust.hexun.com/"
[1:1:0712/042056.542555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.write("违法和不良信息举报电话：010-85650899 客服电话：010-85650688 传真�
[1:1:0712/042056.542847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042056.545554:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f8f90d17070 0x9a1c0a145e0 , "http://trust.hexun.com/"
[1:1:0712/042056.561783:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f8f90d17070 0x9a1c0a145e0 , "http://trust.hexun.com/"
[1:1:0712/042056.563995:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "hexun.com", "hexun.com"
[1:1:0712/042056.583582:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76095:76095:0712/042056.586822:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042056.588660:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x9a1c07b9e20
[1:1:0712/042056.588935:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[76095:76095:0712/042056.594348:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/042056.611633:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042056.611915:INFO:render_frame_impl.cc(7019)] 	 [url] = http://trust.hexun.com
[76095:76095:0712/042056.613658:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://trust.hexun.com/
[1:1:0712/042056.622089:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f8f90d17070 0x9a1c0a145e0 , "http://trust.hexun.com/"
[1:1:0712/042056.671892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f8f90d17070 0x9a1c0a145e0 , "http://trust.hexun.com/"
[1:1:0712/042056.674400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f8f90d17070 0x9a1c0a145e0 , "http://trust.hexun.com/"
[76095:76095:0712/042056.683243:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76095:76095:0712/042056.687827:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76095:76095:0712/042056.722932:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://utrack.hexun.com/
[76095:76095:0712/042056.723028:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://utrack.hexun.com/, http://utrack.hexun.com/usertrack.aspx?site=http%3A//trust.hexun.com/&time=1562930456566&rsite=, 5
[76095:76095:0712/042056.723160:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://utrack.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:20:56 GMT Content-Type: text/html; charset=gb2312 Content-Length: 849 Connection: keep-alive Cache-Control: no-cache Pragma: no-cache Expires: -1 X-AspNet-Version: 4.0.30319 X-Powered-By: ASP.NET Set-Cookie: HexunTrack=SID=2019071219175101338081a23c7164514b48611e60fef35a3&CITY=11&TOWN=0; domain=hexun.com; expires=Wed, 06-Apr-2022 16:00:00 GMT; path=/  ,76192, 5
[76095:76105:0712/042056.727367:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[76095:76105:0712/042056.727465:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/042056.728540:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042056.781293:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://data.trust.hexun.com/
[1:1:0712/042056.816148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042056.816431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042056.912294:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 621, 7f8f9365c881
[1:1:0712/042056.949110:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"564 0x7f8f90d17070 0x9a1c0384f60 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042056.949511:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"564 0x7f8f90d17070 0x9a1c0384f60 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042056.949850:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042056.950438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042056.950664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042056.956903:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6dc29c8, 0x9a1bfd4d150
[1:1:0712/042056.957171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 0
[1:1:0712/042056.957561:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 692
[1:1:0712/042056.957841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7f8f90d17070 0x9a1c0b694e0 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 621 0x7f8f90d17070 0x9a1c0144a60 
[1:1:0712/042057.135246:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042057.140051:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042057.140621:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042057.140993:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042057.141343:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042057.141663:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042100.459955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "http://trust.hexun.com/"
[1:1:0712/042100.461818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , eval(function (p, a, c, k, e, d) { e = function (c) { return (c < a ? "" : e(parseInt(c / a))) + ((c
[1:1:0712/042100.462049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[76095:76095:0712/042100.752936:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s13.cnzz.com/z_stat.php?id=1262910217, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://utrack.hexun.com/dp/hexun_uweb.js (7)
[76095:76095:0712/042100.765129:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s13.cnzz.com/z_stat.php?id=1262910217, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://utrack.hexun.com/dp/hexun_uweb.js (7)
[1:1:0712/042100.964344:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://utrack.hexun.com/
[1:1:0712/042100.994285:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76095:76095:0712/042101.008708:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://data.trust.hexun.com/, http://data.trust.hexun.com/, 4
[76095:76095:0712/042101.008875:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://data.trust.hexun.com/, http://data.trust.hexun.com
[1:1:0712/042101.025283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042101.025563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042101.076151:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 692, 7f8f9365c881
[1:1:0712/042101.094110:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"621 0x7f8f90d17070 0x9a1c0144a60 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042101.094508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"621 0x7f8f90d17070 0x9a1c0144a60 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042101.095004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042101.095634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042101.095910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042101.123021:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042104.667944:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 807, "http://trust.hexun.com/"
[1:1:0712/042104.675037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , (function(){function p(){this.c="1262910217";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/042104.675338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[76095:76095:0712/042104.762653:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1262910217&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s13.cnzz.com/z_stat.php?id=1262910217 (17)
[76095:76095:0712/042104.776225:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1262910217&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s13.cnzz.com/z_stat.php?id=1262910217 (17)
[1:1:0712/042104.948372:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76095:76095:0712/042104.957685:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://utrack.hexun.com/, http://utrack.hexun.com/, 5
[76095:76095:0712/042104.957785:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://utrack.hexun.com/, http://utrack.hexun.com
[1:1:0712/042104.993087:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042105.307715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042105.308000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042105.374278:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042105.374526:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/042105.375858:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 825 0x7f8f90d17070 0x9a1c0cc9ce0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/042105.376578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 23cf89046808, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/042105.376758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/042105.407382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 825 0x7f8f90d17070 0x9a1c0cc9ce0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/042105.414352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 825 0x7f8f90d17070 0x9a1c0cc9ce0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/042105.416745:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 825 0x7f8f90d17070 0x9a1c0cc9ce0 , "data:text/html,pluginplaceholderdata"
[76095:76095:0712/042106.231887:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/042108.118717:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 897, "http://trust.hexun.com/"
[1:1:0712/042108.120988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/042108.121225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042108.367116:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042108.596438:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042108.596610:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://data.trust.hexun.com/map.html"
[1:1:0712/042108.760453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042108.760729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042109.196936:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/042109.199334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 23cf89046808, , onload, notifyDidFinishLoading();
[1:1:0712/042109.199529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/042110.031480:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042110.177701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://trust.hexun.com/"
[1:1:0712/042110.178183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/042110.178303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042110.236713:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042110.236877:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://utrack.hexun.com/usertrack.aspx?site=http%3A//trust.hexun.com/&time=1562930456566&rsite="
[1:1:0712/042110.574571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000, "http://data.trust.hexun.com/map.html"
[1:1:0712/042110.585016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://data.trust.hexun.com/, 23cf89077e98, , , if(!swfobject){
	/*!	SWFObject v2.2 <http://code.google.com/p/swfobject/> 
		is released under the M
[1:1:0712/042110.585770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://data.trust.hexun.com/map.html", "data.trust.hexun.com", 4, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042110.598476:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6e6b508, 0x9a1bfd4d1d0
[1:1:0712/042110.598754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://data.trust.hexun.com/map.html", 0
[1:1:0712/042110.599151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://data.trust.hexun.com/, 1044
[1:1:0712/042110.599419:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7f8f90d17070 0x9a1c1960c60 , 5:4_http://data.trust.hexun.com/, 1, -5:4_http://data.trust.hexun.com/, 1000
[1:1:0712/042110.606763:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000, "http://data.trust.hexun.com/map.html"
[1:1:0712/042110.633856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://data.trust.hexun.com/map.html"
		remove user.10_2be1343c -> 0
[1:1:0712/042110.718270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042110.718515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042111.009727:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042111.009954:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trust.hexun.com/"
[1:1:0712/042111.011653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1021 0x7f8f90d17070 0x9a1c1636560 , "http://trust.hexun.com/"
[1:1:0712/042111.012267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , 
jQuery(document).ready(function () {

	if(window.location.pathname.indexOf("hjxh") > 0 ){
		ret
[1:1:0712/042111.012444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042111.015246:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1021 0x7f8f90d17070 0x9a1c1636560 , "http://trust.hexun.com/"
[1:1:0712/042111.081270:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x42ea6dc29c8, 0x9a1bfd4d278
[1:1:0712/042111.081597:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 20000
[1:1:0712/042111.082177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 1089
[1:1:0712/042111.082478:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7f8f90d17070 0x9a1c19477e0 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 1021 0x7f8f90d17070 0x9a1c1636560 
[1:1:0712/042111.092324:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76095:76095:0712/042111.096543:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042111.096743:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x9a1c05f4020
[1:1:0712/042111.096933:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[76095:76095:0712/042111.103952:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/042111.118301:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042111.118526:INFO:render_frame_impl.cc(7019)] 	 [url] = http://trust.hexun.com
[1:1:0712/042111.121208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1021 0x7f8f90d17070 0x9a1c1636560 , "http://trust.hexun.com/"
[76095:76095:0712/042111.124221:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://trust.hexun.com/
[76095:76095:0712/042111.188738:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76095:76095:0712/042111.193572:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76095:76105:0712/042111.223454:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[76095:76095:0712/042111.223565:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://hxapp.hexun.com/
[76095:76105:0712/042111.223561:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[76095:76095:0712/042111.223612:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://hxapp.hexun.com/, http://hxapp.hexun.com/2013/trust/iframe.html, 6
[76095:76095:0712/042111.223678:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_http://hxapp.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:21:11 GMT Content-Type: text/html Content-Length: 3913 Connection: keep-alive Last-Modified: Tue, 05 Apr 2016 08:38:18 GMT Accept-Ranges: bytes ETag: "5f4dea80168fd11:7da" X-Powered-By: ASP.NET  ,76192, 5
[1:7:0712/042111.227181:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042111.253109:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://trust.hexun.com/"
[1:1:0712/042111.270736:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x42ea6dc29c8, 0x9a1bfd4d210
[1:1:0712/042111.271001:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 0
[1:1:0712/042111.271374:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 1115
[1:1:0712/042111.271676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1115 0x7f8f90d17070 0x9a1c00f31e0 , 5:3_http://trust.hexun.com/, 1, -5:3_http://trust.hexun.com/, 1021 0x7f8f90d17070 0x9a1c1636560 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042112.410248:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://data.trust.hexun.com/, 1044, 7f8f9365c881
[1:1:0712/042112.451861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf89077e98","ptid":"1000","rf":"5:4_http://data.trust.hexun.com/"}
[1:1:0712/042112.452211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://data.trust.hexun.com/","ptid":"1000","rf":"5:4_http://data.trust.hexun.com/"}
[1:1:0712/042112.452572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://data.trust.hexun.com/map.html"
[1:1:0712/042112.453179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://data.trust.hexun.com/, 23cf89077e98, , , (){
						if (isDomLoaded) { return; }
						if (!/loaded|complete/.test(doc.readyState)) {
							s
[1:1:0712/042112.453469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://data.trust.hexun.com/map.html", "data.trust.hexun.com", 4, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042112.573815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042112.574060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042113.439956:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_http://hxapp.hexun.com/
[1:1:0712/042113.816911:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://trust.hexun.com/, 1115, 7f8f9365c881
[1:1:0712/042113.872812:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23cf88f82860","ptid":"1021 0x7f8f90d17070 0x9a1c1636560 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042113.873699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://trust.hexun.com/","ptid":"1021 0x7f8f90d17070 0x9a1c1636560 ","rf":"5:3_http://trust.hexun.com/"}
[1:1:0712/042113.874183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://trust.hexun.com/"
[1:1:0712/042113.875022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042113.875236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[76095:76095:0712/042113.892952:INFO:CONSOLE(61)] "a", source: https://img.hexun.com/2016/pc/ad/bannercode/js/201808070942/articleAB.js (61)
[1:1:0712/042114.593446:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://trust.hexun.com/"
[1:1:0712/042114.594174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/042114.594400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042114.754834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042114.755489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042115.100738:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76095:76095:0712/042115.102503:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://hxapp.hexun.com/, http://hxapp.hexun.com/, 6
[76095:76095:0712/042115.102607:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://hxapp.hexun.com/, http://hxapp.hexun.com
[1:1:0712/042115.254958:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 502 (Bad Gateway)","http://bdc.hexun.com:8088/restfulES/restful?tag=userTarget&args=0,2019071219175101338081a23c7164514b48611e60fef35a3&callback=hexunjsonp_05060912203947385"
[1:1:0712/042115.328708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042115.328968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042115.410930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://data.trust.hexun.com/map.html"
[1:1:0712/042115.411718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://data.trust.hexun.com/, 23cf89077e98, , callDomLoadFunctions, () {
			if (isDomLoaded) { return; }
			try { // test if we can really add/remove elements to/from t
[1:1:0712/042115.411898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://data.trust.hexun.com/map.html", "data.trust.hexun.com", 4, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042115.722850:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042116.169539:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://trust.hexun.com/"
[1:1:0712/042116.169985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , script.onerror, () {
          error && error();
        }
[1:1:0712/042116.170099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042116.171384:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/042116.175119:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x9a1c1c60820
[1:1:0712/042116.175316:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[76095:76095:0712/042116.175937:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[76095:76095:0712/042116.181954:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0712/042116.195858:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042116.196131:INFO:render_frame_impl.cc(7019)] 	 [url] = http://trust.hexun.com
[1:1:0712/042116.200276:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76095:76095:0712/042116.203465:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://trust.hexun.com/
[1:1:0712/042116.204116:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x9a1c1c5fe20
[1:1:0712/042116.204299:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[1:1:0712/042116.215374:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042116.215588:INFO:render_frame_impl.cc(7019)] 	 [url] = http://trust.hexun.com
[76095:76095:0712/042116.220675:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[76095:76095:0712/042116.229121:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[76095:76095:0712/042116.241047:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://trust.hexun.com/
[76095:76095:0712/042116.354040:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76095:76095:0712/042116.360185:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/042116.361326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042116.361601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[76095:76105:0712/042116.376722:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[76095:76095:0712/042116.376800:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h02hxsame.hexun.com/
[76095:76105:0712/042116.376824:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[76095:76095:0712/042116.376880:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://h02hxsame.hexun.com/, https://h02hxsame.hexun.com/s?z=hexun&c=845&op=1, 7
[76095:76095:0712/042116.377002:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_https://h02hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:21:16 GMT Content-Type: text/html; charset=GBK Content-Length: 992 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:21:16 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,76192, 5
[76095:76095:0712/042116.379652:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:7:0712/042116.381303:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[76095:76095:0712/042116.386004:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76095:76105:0712/042116.406532:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[76095:76105:0712/042116.406631:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[76095:76095:0712/042116.406687:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h03hxsame.hexun.com/
[76095:76095:0712/042116.406754:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://h03hxsame.hexun.com/, https://h03hxsame.hexun.com/s?z=hexun&c=643&op=1, 8
[76095:76095:0712/042116.406850:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_https://h03hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:21:16 GMT Content-Type: text/html; charset=GBK Content-Length: 962 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:21:16 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,76192, 5
[1:7:0712/042116.409783:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042116.832087:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042116.832310:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hxapp.hexun.com/2013/trust/iframe.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042118.388158:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_https://h02hxsame.hexun.com/
[1:1:0712/042118.621027:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:8_https://h03hxsame.hexun.com/
[1:1:0712/042118.666531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042118.666707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042119.811022:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76095:76095:0712/042119.833421:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://h02hxsame.hexun.com/, https://h02hxsame.hexun.com/, 7
[76095:76095:0712/042119.833575:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://h02hxsame.hexun.com/, https://h02hxsame.hexun.com
[1:1:0712/042119.949140:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76095:76095:0712/042119.961867:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://h03hxsame.hexun.com/, https://h03hxsame.hexun.com/, 8
[76095:76095:0712/042119.961980:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, https://h03hxsame.hexun.com/, https://h03hxsame.hexun.com
[1:1:0712/042120.022193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042120.022443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042120.080283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1374 0x7f8fa73a1080 0x9a1c0eee4c0 1 0 0x9a1c0eee4d8 , "http://hxapp.hexun.com/2013/trust/iframe.html"
[1:1:0712/042120.101807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://hxapp.hexun.com/, 23cf8900c390, , , /*!
 * jQuery JavaScript Library v1.4.1
 * http://jquery.com/
 *
 *
 * Includes Sizzle.js
 * h
[1:1:0712/042120.102020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hxapp.hexun.com/2013/trust/iframe.html", "hxapp.hexun.com", 6, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042120.115051:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1374 0x7f8fa73a1080 0x9a1c0eee4c0 1 0 0x9a1c0eee4d8 , "http://hxapp.hexun.com/2013/trust/iframe.html"
[1:1:0712/042120.185211:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042120.185737:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042120.229268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1374 0x7f8fa73a1080 0x9a1c0eee4c0 1 0 0x9a1c0eee4d8 , "http://hxapp.hexun.com/2013/trust/iframe.html"
[1:1:0712/042120.238777:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1374 0x7f8fa73a1080 0x9a1c0eee4c0 1 0 0x9a1c0eee4d8 , "http://hxapp.hexun.com/2013/trust/iframe.html"
[1:1:0712/042120.468935:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1384, "http://hxapp.hexun.com/2013/trust/iframe.html"
[1:1:0712/042120.471267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://hxapp.hexun.com/, 23cf8900c390, , , 
var host = window.location.hostname;
if (host.indexOf('.homeway.com.cn') > 0) { 
	document.domai
[1:1:0712/042120.471533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hxapp.hexun.com/2013/trust/iframe.html", "hxapp.hexun.com", 6, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042120.472982:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "hxapp.hexun.com", "hexun.com"
[1:1:0712/042120.479478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hxapp.hexun.com/2013/trust/iframe.html"
[1:1:0712/042121.093140:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042121.979785:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042122.370058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042122.370450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042122.776680:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hxapp.hexun.com/2013/trust/iframe.html"
[1:1:0712/042122.777080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://hxapp.hexun.com/, 23cf8900c390, , ready, (){if(!c.isReady){if(!r.body)return setTimeout(c.ready,13);c.isReady=true;if(P){for(var a,b=0;a=P[b+
[1:1:0712/042122.777215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hxapp.hexun.com/2013/trust/iframe.html", "hexun.com", 6, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042123.333226:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042123.333421:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://h02hxsame.hexun.com/s?z=hexun&c=845&op=1"
[1:1:0712/042123.338343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1477 0x7f8f90d17070 0x9a1c0bdf4e0 , "https://h02hxsame.hexun.com/s?z=hexun&c=845&op=1"
[1:1:0712/042123.350209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_https://h02hxsame.hexun.com/, 23cf89016e28, , , 
if('http://'!='http://' && 'http://'!=''){document.write('<img src="http://" width="0" height="0" /
[1:1:0712/042123.350399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://h02hxsame.hexun.com/s?z=hexun&c=845&op=1", "h02hxsame.hexun.com", 7, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042124.076634:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042124.076916:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://h03hxsame.hexun.com/s?z=hexun&c=643&op=1"
[1:1:0712/042124.085384:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1505 0x7f8f90d17070 0x9a1c1a3fe60 , "https://h03hxsame.hexun.com/s?z=hexun&c=643&op=1"
[1:1:0712/042124.097749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://h03hxsame.hexun.com/, 23cf8901c1a0, , , 
if('http://'!='http://' && 'http://'!=''){document.write('<img src="http://" width="0" height="0" /
[1:1:0712/042124.097975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://h03hxsame.hexun.com/s?z=hexun&c=643&op=1", "h03hxsame.hexun.com", 8, 1, http://trust.hexun.com, hexun.com, 3
[1:1:0712/042124.180601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , , document.readyState
[1:1:0712/042124.180812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042127.394736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://trust.hexun.com/"
[1:1:0712/042127.395609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://trust.hexun.com/, 23cf88f82860, , ready, (){if(!c.isReady){if(!s.body)return setTimeout(c.ready,13);c.isReady=true;if(Q){for(var a,b=0;a=Q[b+
[1:1:0712/042127.395850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trust.hexun.com/", "hexun.com", 3, 1, , , 0
[1:1:0712/042127.396304:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://trust.hexun.com/"
[1:1:0712/042127.408139:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x42ea6dc29c8, 0x9a1bfd4d1f0
[1:1:0712/042127.408394:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://trust.hexun.com/", 4000
[1:1:0712/042127.408852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:8_https://h03hxsame.hexun.com/, 1700
[1:1:0712/042127.409090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1700 0x7f8f90d17070 0x9a1c1d80860 , 5:8_https://h03hxsame.hexun.com/, 1, -5:3_http://trust.hexun.com/, 1642 0x7f8f90d17070 0x9a1c08dec60 
