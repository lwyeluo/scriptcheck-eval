[0712/042244.284643:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042244.285127:INFO:switcher_clone.cc(787)] backtrace rip is 7efdfb51b891
[0712/042245.376349:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042245.376709:INFO:switcher_clone.cc(787)] backtrace rip is 7fe8d1bf5891
[1:1:0712/042245.388404:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/042245.388643:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/042245.398341:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[76346:76346:0712/042246.521376:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/042246.531934:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042246.532212:INFO:switcher_clone.cc(787)] backtrace rip is 7fa7c797a891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1afbbbc7-6cf0-4de8-aa0a-be0216c9f609
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[76377:76377:0712/042246.681705:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=76377
[76390:76390:0712/042246.682120:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=76390
[76346:76346:0712/042247.151786:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[76346:76375:0712/042247.152817:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/042247.153142:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042247.153469:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042247.154314:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042247.154562:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/042247.157367:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x62b6d08, 1
[1:1:0712/042247.157697:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x14983ca8, 0
[1:1:0712/042247.157830:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x246cc003, 3
[1:1:0712/042247.158005:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x306e976c, 2
[1:1:0712/042247.158171:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa83cffffff9814 086d2b06 6cffffff976e30 03ffffffc06c24 , 10104, 4
[1:1:0712/042247.159041:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[76346:76375:0712/042247.159349:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�<�m+l�n0�l$���
[1:1:0712/042247.159329:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8cfe300a0, 3
[76346:76375:0712/042247.159483:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �<�m+l�n0�l$�a���
[1:1:0712/042247.159514:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8cffbb080, 2
[76346:76375:0712/042247.159844:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/042247.159848:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8b9c7ed20, -2
[76346:76375:0712/042247.159951:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 76398, 4, a83c9814 086d2b06 6c976e30 03c06c24 
[1:1:0712/042247.179459:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042247.180242:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 306e976c
[1:1:0712/042247.181170:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 306e976c
[1:1:0712/042247.183116:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 306e976c
[1:1:0712/042247.184621:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.184737:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.184836:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.184937:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.185152:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 306e976c
[1:1:0712/042247.185296:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8d1bf57ba
[1:1:0712/042247.185388:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8d1becdef, 7fe8d1bf577a, 7fe8d1bf70cf
[1:1:0712/042247.186823:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 306e976c
[1:1:0712/042247.186976:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 306e976c
[1:1:0712/042247.187237:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 306e976c
[1:1:0712/042247.187928:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.188035:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.188125:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.188213:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 306e976c
[1:1:0712/042247.188748:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 306e976c
[1:1:0712/042247.188906:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8d1bf57ba
[1:1:0712/042247.188978:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8d1becdef, 7fe8d1bf577a, 7fe8d1bf70cf
[1:1:0712/042247.191131:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042247.191413:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042247.191512:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe07d99848, 0x7ffe07d997c8)
[1:1:0712/042247.205487:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042247.212026:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[76346:76346:0712/042247.869827:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76346:76346:0712/042247.871322:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76346:76357:0712/042247.885737:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[76346:76357:0712/042247.885839:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042247.886196:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[76346:76346:0712/042247.886290:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[76346:76346:0712/042247.886447:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,76398, 4
[1:7:0712/042247.889733:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042247.970448:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1bfc4b7da220
[1:1:0712/042247.970802:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[76346:76369:0712/042247.973269:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/042248.323719:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[76346:76346:0712/042250.039679:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[76346:76346:0712/042250.039822:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042250.066753:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042250.070887:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042250.915948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 07bde1321f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042250.916258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042250.946237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 07bde1321f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042250.946512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042251.026223:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042251.310493:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042251.310786:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042251.730639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042251.733424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 07bde1321f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042251.733597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042251.773311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042251.779320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 07bde1321f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042251.779485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042251.783811:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/042251.787273:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1bfc4b7d8e20
[1:1:0712/042251.787462:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[76346:76346:0712/042251.789205:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[76346:76346:0712/042251.806315:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[76346:76346:0712/042251.844879:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[76346:76346:0712/042251.844978:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[76346:76346:0712/042251.851523:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/042251.869141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042252.498956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7fe8bb8592e0 0x1bfc4b9da960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042252.499655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 07bde1321f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/042252.499842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042252.500398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[76346:76346:0712/042252.532292:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042252.532574:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1bfc4b7d9820
[1:1:0712/042252.532786:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[76346:76346:0712/042252.544292:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/042252.550849:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042252.551048:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[76346:76346:0712/042252.560600:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[76346:76346:0712/042252.573082:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76346:76346:0712/042252.574108:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76346:76346:0712/042252.580289:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[76346:76346:0712/042252.580369:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[76346:76357:0712/042252.580382:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[76346:76357:0712/042252.580467:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042252.580510:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,76398, 4
[1:7:0712/042252.588333:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042253.142357:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/042253.552125:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7fe8bb8592e0 0x1bfc4ba82b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042253.553125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 07bde1321f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/042253.553339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042253.554079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042253.706647:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76346:76346:0712/042253.738818:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[76346:76346:0712/042253.738925:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/042254.013380:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[76346:76346:0712/042254.158624:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[76346:76375:0712/042254.159085:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/042254.159335:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042254.159622:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042254.160023:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042254.160289:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/042254.163844:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xbe26af0, 1
[1:1:0712/042254.164242:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x331c5040, 0
[1:1:0712/042254.164390:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x267c8899, 3
[1:1:0712/042254.164532:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ee05076, 2
[1:1:0712/042254.164676:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 40501c33 fffffff06affffffe20b 7650ffffffe01e ffffff99ffffff887c26 , 10104, 5
[1:1:0712/042254.165871:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[76346:76375:0712/042254.166205:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING@P3�j�vP���|&ޗ�
[76346:76375:0712/042254.166301:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is @P3�j�vP���|&�)ޗ�
[1:1:0712/042254.166459:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8cfe300a0, 3
[76346:76375:0712/042254.166623:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 76442, 5, 40501c33 f06ae20b 7650e01e 99887c26 
[1:1:0712/042254.166701:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8cffbb080, 2
[1:1:0712/042254.166876:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8b9c7ed20, -2
[1:1:0712/042254.178617:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042254.178815:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ee05076
[1:1:0712/042254.178988:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ee05076
[1:1:0712/042254.179543:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ee05076
[1:1:0712/042254.181286:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.181515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.181734:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.181963:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.182768:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ee05076
[1:1:0712/042254.183119:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8d1bf57ba
[1:1:0712/042254.183304:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8d1becdef, 7fe8d1bf577a, 7fe8d1bf70cf
[1:1:0712/042254.190305:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ee05076
[1:1:0712/042254.190786:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ee05076
[1:1:0712/042254.191705:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ee05076
[1:1:0712/042254.194239:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.194469:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.194656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.194847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ee05076
[1:1:0712/042254.196094:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ee05076
[1:1:0712/042254.196574:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8d1bf57ba
[1:1:0712/042254.196744:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8d1becdef, 7fe8d1bf577a, 7fe8d1bf70cf
[1:1:0712/042254.206312:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042254.206918:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042254.207101:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe07d99848, 0x7ffe07d997c8)
[1:1:0712/042254.218983:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042254.223580:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/042254.444415:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1bfc4b7a7220
[1:1:0712/042254.444729:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/042254.559624:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042254.559888:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[76346:76346:0712/042254.873539:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76346:76346:0712/042254.878666:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76346:76357:0712/042254.895280:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[76346:76346:0712/042254.895514:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://funds.hexun.com/
[76346:76346:0712/042254.895555:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://funds.hexun.com/, http://funds.hexun.com/smjj/, 1
[76346:76346:0712/042254.895613:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://funds.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:22:54 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:23:23 GMT Cache-Control: max-age=60 X-UA-Compatible: IE=EmulateIE7 Content-Encoding: gzip  ,76442, 5
[76346:76357:0712/042254.895409:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/042254.897482:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042254.952145:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://funds.hexun.com/
[76346:76346:0712/042255.035263:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://funds.hexun.com/, http://funds.hexun.com/, 1
[76346:76346:0712/042255.035454:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://funds.hexun.com/, http://funds.hexun.com
[1:1:0712/042255.044818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042255.049526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 07bde14509f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/042255.049828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/042255.057049:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042255.057712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042255.177182:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042255.217161:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042255.217463:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://funds.hexun.com/smjj/"
[1:1:0712/042255.482604:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042255.483352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 07bde1321f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/042255.483628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042256.191876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7fe8cffbb080 0x1bfc4b9004c0 1 0 0x1bfc4b9004d8 , "http://funds.hexun.com/smjj/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042256.238297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , /*! jQuery v1.11.2 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/042256.238625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042256.263606:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042256.488795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7fe8cffbb080 0x1bfc4b9004c0 1 0 0x1bfc4b9004d8 , "http://funds.hexun.com/smjj/"
[1:1:0712/042256.504006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7fe8cffbb080 0x1bfc4b9004c0 1 0 0x1bfc4b9004d8 , "http://funds.hexun.com/smjj/"
[1:1:0712/042256.509877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7fe8cffbb080 0x1bfc4b9004c0 1 0 0x1bfc4b9004d8 , "http://funds.hexun.com/smjj/"
[1:1:0712/042256.586890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7fe8cffbb080 0x1bfc4b9004c0 1 0 0x1bfc4b9004d8 , "http://funds.hexun.com/smjj/"
[1:1:0712/042256.601587:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7fe8cffbb080 0x1bfc4b9004c0 1 0 0x1bfc4b9004d8 , "http://funds.hexun.com/smjj/"
[1:1:0712/042257.188426:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042257.188910:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042257.189307:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042257.189742:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042257.190141:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[76346:76346:0712/042314.901942:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/042314.945822:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/042315.098546:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 18.6115, 2, 0
[1:1:0712/042315.098846:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042318.171618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/042318.171938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042318.941987:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042318.942271:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://funds.hexun.com/smjj/"
[1:1:0712/042318.943395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 373 0x7fe8b9931070 0x1bfc4ba889e0 , "http://funds.hexun.com/smjj/"
[1:1:0712/042318.944748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , 
  window._taboola = window._taboola || [];
  _taboola.push({article:'auto'});
  !function (e, f, u,
[1:1:0712/042318.945016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042318.956448:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 373 0x7fe8b9931070 0x1bfc4ba889e0 , "http://funds.hexun.com/smjj/"
[1:1:0712/042319.017437:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x26ac5a7029c8, 0x1bfc4b62e198
[1:1:0712/042319.017762:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 3000
[1:1:0712/042319.018289:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 464
[1:1:0712/042319.018536:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 464 0x7fe8b9931070 0x1bfc4bdc6060 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 373 0x7fe8b9931070 0x1bfc4ba889e0 
[1:1:0712/042319.043995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 373 0x7fe8b9931070 0x1bfc4ba889e0 , "http://funds.hexun.com/smjj/"
[1:1:0712/042319.063205:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 373 0x7fe8b9931070 0x1bfc4ba889e0 , "http://funds.hexun.com/smjj/"
[1:1:0712/042319.074822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 373 0x7fe8b9931070 0x1bfc4ba889e0 , "http://funds.hexun.com/smjj/"
[1:1:0712/042319.078737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 373 0x7fe8b9931070 0x1bfc4ba889e0 , "http://funds.hexun.com/smjj/"
[1:1:0712/042319.094611:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.152213, 269, 1
[1:1:0712/042319.094872:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042320.453259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042320.453630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042321.876481:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042321.876694:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://funds.hexun.com/smjj/"
[1:1:0712/042321.877469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fe8b9931070 0x1bfc4b9b8860 , "http://funds.hexun.com/smjj/"
[1:1:0712/042321.878303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , articleTop.scrollTop();articleTop.isLogin();
[1:1:0712/042321.878483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042321.983193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fe8b9931070 0x1bfc4b9b8860 , "http://funds.hexun.com/smjj/"
[1:1:0712/042321.987339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fe8b9931070 0x1bfc4b9b8860 , "http://funds.hexun.com/smjj/"
[1:1:0712/042321.995897:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fe8b9931070 0x1bfc4b9b8860 , "http://funds.hexun.com/smjj/"
[1:1:0712/042322.111582:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.234787, 1162, 1
[1:1:0712/042322.111821:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042322.197813:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042322.241739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042322.241917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042325.883887:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://funds.hexun.com/smjj/"
[1:1:0712/042325.886286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , c.onload, (){t(c.responseText)}
[1:1:0712/042325.886518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042325.890118:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e518
[1:1:0712/042325.890339:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042325.890722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 603
[1:1:0712/042325.890947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 603 0x7fe8b9931070 0x1bfc4c72bc60 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 513
[1:1:0712/042327.548562:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042327.548858:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://funds.hexun.com/smjj/"
[1:1:0712/042327.552566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7fe8b9931070 0x1bfc4c22cae0 , "http://funds.hexun.com/smjj/"
[1:1:0712/042327.554029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (function ($) {
	var
	defaults = {
		className: 'autosizejs',
		id: 'autosizejs',
		append: '\n
[1:1:0712/042327.554258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042327.584879:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0359211, 105, 1
[1:1:0712/042327.585146:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042327.586670:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 464, 7fe8bc276881
[1:1:0712/042327.602475:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"373 0x7fe8b9931070 0x1bfc4ba889e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042327.602890:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"373 0x7fe8b9931070 0x1bfc4ba889e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042327.603383:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042327.603986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s(i+" timeout")}
[1:1:0712/042327.604204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042327.795008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042327.795315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042328.792546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 603, 7fe8bc276881
[1:1:0712/042328.820335:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"513","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042328.820705:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"513","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042328.821092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042328.821671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042328.821888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042328.827586:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042328.827825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042328.828203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 644
[1:1:0712/042328.828459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7fe8b9931070 0x1bfc4b9ca8e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 603 0x7fe8b9931070 0x1bfc4c72bc60 
[1:1:0712/042329.027413:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042329.027665:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://funds.hexun.com/smjj/"
[1:1:0712/042329.028630:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7fe8b9931070 0x1bfc4c35f060 , "http://funds.hexun.com/smjj/"
[1:1:0712/042329.029537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.write("违法和不良信息举报电话：010-85650899 客服电话：010-85650688 传真�
[1:1:0712/042329.029785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "funds.hexun.com", 3, 1, , , 0
[1:1:0712/042329.035703:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7fe8b9931070 0x1bfc4c35f060 , "http://funds.hexun.com/smjj/"
[1:1:0712/042329.049187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7fe8b9931070 0x1bfc4c35f060 , "http://funds.hexun.com/smjj/"
[1:1:0712/042329.052177:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "funds.hexun.com", "hexun.com"
[1:1:0712/042329.064899:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76346:76346:0712/042329.066201:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042329.068445:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1bfc4c642820
[1:1:0712/042329.068675:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[76346:76346:0712/042329.072827:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/042329.084064:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042329.084375:INFO:render_frame_impl.cc(7019)] 	 [url] = http://funds.hexun.com
[76346:76346:0712/042329.090770:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://funds.hexun.com/
[1:1:0712/042329.095908:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7fe8b9931070 0x1bfc4c35f060 , "http://funds.hexun.com/smjj/"
[76346:76346:0712/042329.141336:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0712/042329.144710:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7fe8b9931070 0x1bfc4c35f060 , "http://funds.hexun.com/smjj/"
[76346:76346:0712/042329.145571:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/042329.148295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7fe8b9931070 0x1bfc4c35f060 , "http://funds.hexun.com/smjj/"
[76346:76357:0712/042329.178665:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[76346:76357:0712/042329.178761:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042329.179018:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://utrack.hexun.com/
[76346:76346:0712/042329.179119:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://utrack.hexun.com/, http://utrack.hexun.com/usertrack.aspx?site=http%3A//funds.hexun.com/smjj/&time=1562930609054&rsite=, 4
[76346:76346:0712/042329.179286:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://utrack.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:23:29 GMT Content-Type: text/html; charset=gb2312 Content-Length: 697 Connection: keep-alive Cache-Control: no-cache Pragma: no-cache Expires: -1 X-Powered-By: ASP.NET X-AspNet-Version: 2.0.50727 Set-Cookie: HexunTrack=SID=2019071219175101338081a23c7164514b48611e60fef35a3&CITY=11&TOWN=0; domain=hexun.com; expires=Wed, 06-Apr-2022 16:00:00 GMT; path=/  ,76442, 5
[1:7:0712/042329.187666:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042329.226006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 624 0x7fe8bb8592e0 0x1bfc4bf70b60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042329.226967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , hx_json11562930602002([{"code":"161026","name":"华夏成长"}])
[1:1:0712/042329.227208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042329.229007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://funds.hexun.com/smjj/"
[1:1:0712/042329.298538:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 625 0x7fe8bb8592e0 0x1bfc4bdcf560 , "http://funds.hexun.com/smjj/"
[1:1:0712/042329.299631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , jQuery1112013918829302415014_1562930576436({"islogin":"False","userid":"","username":"","nickname":"
[1:1:0712/042329.299872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042329.300986:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://funds.hexun.com/smjj/"
[1:1:0712/042329.387971:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042329.709577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 629 0x7fe8bb8592e0 0x1bfc4b7e8c60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042329.718936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , //abtest111
//-> 19


    var _taboola = _taboola || [];var TRC = TRC || {};
TRC.perfConfOverride = 
[1:1:0712/042329.719268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042329.758611:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x26ac5a7029c8, 0x1bfc4b62e148
[1:1:0712/042329.758872:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 10000
[1:1:0712/042329.759250:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 683
[1:1:0712/042329.759490:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7fe8b9931070 0x1bfc4bd6cce0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 629 0x7fe8bb8592e0 0x1bfc4b7e8c60 
[1:1:0712/042329.760084:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 1000
[1:1:0712/042329.760474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 684
[1:1:0712/042329.760712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7fe8b9931070 0x1bfc4c8ac560 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 629 0x7fe8bb8592e0 0x1bfc4b7e8c60 
[1:1:0712/042329.761201:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 5000
[1:1:0712/042329.761670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 685
[1:1:0712/042329.761903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7fe8b9931070 0x1bfc4b955660 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 629 0x7fe8bb8592e0 0x1bfc4b7e8c60 
[1:1:0712/042329.762740:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 5000
[1:1:0712/042329.763102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 686
[1:1:0712/042329.763325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7fe8b9931070 0x1bfc4c7d00e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 629 0x7fe8bb8592e0 0x1bfc4b7e8c60 
		remove user.10_b958fdc3 -> 0
		remove user.11_96712f28 -> 0
[1:1:0712/042329.939330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042329.939626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042330.337437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 644, 7fe8bc276881
[1:1:0712/042330.352623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"603 0x7fe8b9931070 0x1bfc4c72bc60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042330.352994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"603 0x7fe8b9931070 0x1bfc4c72bc60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042330.353425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042330.354003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042330.354222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042330.358257:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042330.358464:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042330.358864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 699
[1:1:0712/042330.359104:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7fe8b9931070 0x1bfc4c11c860 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 644 0x7fe8b9931070 0x1bfc4b9ca8e0 
[1:1:0712/042330.420437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042330.420711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042331.452738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 676, "http://funds.hexun.com/smjj/"
[1:1:0712/042331.454364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , eval(function (p, a, c, k, e, d) { e = function (c) { return (c < a ? "" : e(parseInt(c / a))) + ((c
[1:1:0712/042331.454600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[76346:76346:0712/042331.785951:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s13.cnzz.com/z_stat.php?id=1262910149, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://utrack.hexun.com/dp/hexun_uweb.js (7)
[76346:76346:0712/042331.794003:INFO:CONSOLE(7)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s13.cnzz.com/z_stat.php?id=1262910149, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://utrack.hexun.com/dp/hexun_uweb.js (7)
[1:1:0712/042331.930161:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://utrack.hexun.com/
[1:1:0712/042332.022660:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://b.scorecardresearch.com/beacon.js"
[1:1:0712/042332.134045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042332.134308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042332.160981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 699, 7fe8bc276881
[1:1:0712/042332.188579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"644 0x7fe8b9931070 0x1bfc4b9ca8e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.188783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"644 0x7fe8b9931070 0x1bfc4b9ca8e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.189033:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042332.189370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042332.189481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042332.190405:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042332.190514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042332.190687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 727
[1:1:0712/042332.190794:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7fe8b9931070 0x1bfc4c350a60 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 699 0x7fe8b9931070 0x1bfc4c11c860 
[1:1:0712/042332.240287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042332.240532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042332.355930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 684, 7fe8bc2768db
[1:1:0712/042332.388541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.388848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.389258:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 730
[1:1:0712/042332.389471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7fe8b9931070 0x1bfc4c14ea60 , 5:3_http://funds.hexun.com/, 0, , 684 0x7fe8b9931070 0x1bfc4c8ac560 
[1:1:0712/042332.389743:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042332.390249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042332.390473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042332.391387:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042332.391600:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042332.391951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 731
[1:1:0712/042332.392139:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7fe8b9931070 0x1bfc4c223de0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 684 0x7fe8b9931070 0x1bfc4c8ac560 
[1:1:0712/042332.547607:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719, "http://funds.hexun.com/smjj/"
[1:1:0712/042332.554441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (function(){function p(){this.c="1262910149";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/042332.554753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[76346:76346:0712/042332.627802:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1262910149&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s13.cnzz.com/z_stat.php?id=1262910149 (17)
[76346:76346:0712/042332.637389:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1262910149&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s13.cnzz.com/z_stat.php?id=1262910149 (17)
[1:1:0712/042332.735552:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76346:76346:0712/042332.739521:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://utrack.hexun.com/, http://utrack.hexun.com/, 4
[76346:76346:0712/042332.739674:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://utrack.hexun.com/, http://utrack.hexun.com
[1:1:0712/042332.849553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042332.849747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042332.850943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 727, 7fe8bc276881
[1:1:0712/042332.872383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"699 0x7fe8b9931070 0x1bfc4c11c860 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.872720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"699 0x7fe8b9931070 0x1bfc4c11c860 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.873070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042332.873627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042332.873812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042332.903280:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042332.903507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042332.903852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 767
[1:1:0712/042332.904037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 767 0x7fe8b9931070 0x1bfc4b84b760 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 727 0x7fe8b9931070 0x1bfc4c350a60 
[1:1:0712/042332.941780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042332.942024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042332.978911:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 731, 7fe8bc276881
[1:1:0712/042332.989762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"684 0x7fe8b9931070 0x1bfc4c8ac560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.989945:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"684 0x7fe8b9931070 0x1bfc4c8ac560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042332.990166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042332.990465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042332.990569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042333.358515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 747, "http://funds.hexun.com/smjj/"
[1:1:0712/042333.361120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/042333.361406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042333.546390:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042333.701939:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 730, 7fe8bc2768db
[1:1:0712/042333.739718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"684 0x7fe8b9931070 0x1bfc4c8ac560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042333.740058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"684 0x7fe8b9931070 0x1bfc4c8ac560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042333.740471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 786
[1:1:0712/042333.740667:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7fe8b9931070 0x1bfc4c7758e0 , 5:3_http://funds.hexun.com/, 0, , 730 0x7fe8b9931070 0x1bfc4c14ea60 
[1:1:0712/042333.740985:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042333.741501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042333.741679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042333.742386:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042333.742556:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042333.742938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 787
[1:1:0712/042333.743135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 787 0x7fe8b9931070 0x1bfc4bd67360 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 730 0x7fe8b9931070 0x1bfc4c14ea60 
[1:1:0712/042333.972615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042333.972863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042334.081658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042334.081845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042334.086429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 767, 7fe8bc276881
[1:1:0712/042334.099110:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"727 0x7fe8b9931070 0x1bfc4c350a60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042334.099317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"727 0x7fe8b9931070 0x1bfc4c350a60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042334.099572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042334.099884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042334.100081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042334.103768:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042334.103956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042334.104259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 794
[1:1:0712/042334.104423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7fe8b9931070 0x1bfc4cd7eee0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 767 0x7fe8b9931070 0x1bfc4b84b760 
[1:1:0712/042334.283192:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042334.401183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://funds.hexun.com/smjj/"
[1:1:0712/042334.402874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/042334.403142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042334.544010:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042334.544182:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://utrack.hexun.com/usertrack.aspx?site=http%3A//funds.hexun.com/smjj/&time=1562930609054&rsite="
[1:1:0712/042335.613218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 787, 7fe8bc276881
[1:1:0712/042335.652055:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"730 0x7fe8b9931070 0x1bfc4c14ea60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042335.652485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"730 0x7fe8b9931070 0x1bfc4c14ea60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042335.653009:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042335.653747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042335.653932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042335.655988:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 786, 7fe8bc2768db
[1:1:0712/042335.679599:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"730 0x7fe8b9931070 0x1bfc4c14ea60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042335.679959:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"730 0x7fe8b9931070 0x1bfc4c14ea60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042335.680433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 841
[1:1:0712/042335.680662:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7fe8b9931070 0x1bfc4ccaa9e0 , 5:3_http://funds.hexun.com/, 0, , 786 0x7fe8b9931070 0x1bfc4c7758e0 
[1:1:0712/042335.680830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042335.681124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042335.681230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042335.681556:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042335.681660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042335.681821:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 842
[1:1:0712/042335.681927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7fe8b9931070 0x1bfc4c11d1e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 786 0x7fe8b9931070 0x1bfc4c7758e0 
[1:1:0712/042335.735158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042335.735343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042335.749437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042335.749626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042335.980090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 794, 7fe8bc276881
[1:1:0712/042335.999598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"767 0x7fe8b9931070 0x1bfc4b84b760 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042335.999885:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"767 0x7fe8b9931070 0x1bfc4b84b760 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042336.000196:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042336.000644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , drain, (){var e=t;for(t=i=h=void 0;e;)e.fn.call(e.self),e=e.next}
[1:1:0712/042336.000814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042336.127313:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042336.127547:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://funds.hexun.com/smjj/"
[1:1:0712/042336.131883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 797 0x7fe8b9931070 0x1bfc4cd85e60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042336.133404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , 
jQuery(document).ready(function () {

	if(window.location.pathname.indexOf("hjxh") > 0 ){
		ret
[1:1:0712/042336.133642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042336.143785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 797 0x7fe8b9931070 0x1bfc4cd85e60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042336.489480:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 797 0x7fe8b9931070 0x1bfc4cd85e60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042336.560469:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x26ac5a7029c8, 0x1bfc4b62e260
[1:1:0712/042336.560700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 20000
[1:1:0712/042336.561043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 871
[1:1:0712/042336.561308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7fe8b9931070 0x1bfc4c7cb4e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 797 0x7fe8b9931070 0x1bfc4cd85e60 
[76346:76346:0712/042336.918961:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/042337.716713:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 685, 7fe8bc2768db
[1:1:0712/042337.757384:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042337.757803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042337.758316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 895
[1:1:0712/042337.758586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7fe8b9931070 0x1bfc4c34da60 , 5:3_http://funds.hexun.com/, 0, , 685 0x7fe8b9931070 0x1bfc4b955660 
[1:1:0712/042337.758905:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042337.759567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/042337.759696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042337.761309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 686, 7fe8bc2768db
[1:1:0712/042337.804706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042337.805125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042337.805673:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 896
[1:1:0712/042337.805925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7fe8b9931070 0x1bfc4ce58660 , 5:3_http://funds.hexun.com/, 0, , 686 0x7fe8b9931070 0x1bfc4c7d00e0 
[1:1:0712/042337.806244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042337.806970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/042337.807266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042337.930815:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 842, 7fe8bc276881
[1:1:0712/042337.966272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"786 0x7fe8b9931070 0x1bfc4c7758e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042337.966471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"786 0x7fe8b9931070 0x1bfc4c7758e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042337.966733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042337.967039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042337.967143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042337.980716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042337.980890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042338.019536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 841, 7fe8bc2768db
[1:1:0712/042338.052683:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"786 0x7fe8b9931070 0x1bfc4c7758e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042338.053048:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"786 0x7fe8b9931070 0x1bfc4c7758e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042338.053646:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 900
[1:1:0712/042338.053898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7fe8b9931070 0x1bfc4b9558e0 , 5:3_http://funds.hexun.com/, 0, , 841 0x7fe8b9931070 0x1bfc4ccaa9e0 
[1:1:0712/042338.054272:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042338.054920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042338.055149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042338.056013:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042338.056221:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042338.056672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 901
[1:1:0712/042338.056922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7fe8b9931070 0x1bfc4c223a60 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 841 0x7fe8b9931070 0x1bfc4ccaa9e0 
[1:1:0712/042338.103480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "scroll", "http://funds.hexun.com/smjj/"
[1:1:0712/042338.104181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , r.handle, (a){return typeof m===K||a&&m.event.triggered===a.type?void 0:m.event.dispatch.apply(k.elem,argument
[1:1:0712/042338.104363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042339.061921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 878, "http://funds.hexun.com/smjj/"
[1:1:0712/042339.063065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , /*娴侀噺鎺у埗*/
var setpageview_showing = true;
(function () {
    function hexunOutTimer(y
[1:1:0712/042339.063190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042339.084746:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://funds.hexun.com/smjj/"
[1:1:0712/042339.089305:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://funds.hexun.com/smjj/"
[1:1:0712/042339.286614:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042339.287224:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[76346:76346:0712/042339.356948:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: http://funds.hexun.com/smjj/ (0)
[1:1:0712/042339.903817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042339.903997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042339.950328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 901, 7fe8bc276881
[1:1:0712/042339.999690:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"841 0x7fe8b9931070 0x1bfc4ccaa9e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042340.000090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"841 0x7fe8b9931070 0x1bfc4ccaa9e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042340.000640:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042340.001391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042340.001619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042340.088047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042340.088402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042340.279288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 900, 7fe8bc2768db
[1:1:0712/042340.320350:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"841 0x7fe8b9931070 0x1bfc4ccaa9e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042340.320690:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"841 0x7fe8b9931070 0x1bfc4ccaa9e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042340.321120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 957
[1:1:0712/042340.321332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7fe8b9931070 0x1bfc4b4375e0 , 5:3_http://funds.hexun.com/, 0, , 900 0x7fe8b9931070 0x1bfc4b9558e0 
[1:1:0712/042340.321625:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042340.322135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042340.322312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042340.322946:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042340.323104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042340.323451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 958
[1:1:0712/042340.323643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7fe8b9931070 0x1bfc4cee94e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 900 0x7fe8b9931070 0x1bfc4b9558e0 
[1:1:0712/042340.473353:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7fe8bb8592e0 0x1bfc4c8aae60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042340.474384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , jQuery1112013918829302415014_1562930576436({"islogin":"False","userid":"","username":"","nickname":"
[1:1:0712/042340.474591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042340.475308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://funds.hexun.com/smjj/"
[1:1:0712/042340.841780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 914 0x7fe8bb8592e0 0x1bfc4ceebe60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042340.842556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , jQuery1112013918829302415014_1562930576439({"islogin":"False","userid":"","username":"","nickname":"
[1:1:0712/042340.842776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042340.843329:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://funds.hexun.com/smjj/"
[1:1:0712/042341.694130:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 502 (Bad Gateway)","http://bdc.hexun.com:8088/restfulES/restful?tag=userTarget&args=0,2019071219175101338081a23c7164514b48611e60fef35a3&callback=hexunjsonp_014019336840243146"
[1:1:0712/042341.744313:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 683, 7fe8bc276881
[1:1:0712/042341.777273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042341.777667:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"629 0x7fe8bb8592e0 0x1bfc4b7e8c60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042341.777930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042341.778248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){v(),o.measureInterval&&(this.measureInterval=setInterval(v,Math.max(Number(o.measureInterval),1e4
[1:1:0712/042341.778355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042341.785585:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://funds.hexun.com/smjj/"
[76346:76346:0712/042341.791617:INFO:CONSOLE(11)] "Uncaught TypeError: (t.TRCImpl && t.TRCImpl.getGlobalSessionData.trcBind(...)) is not a function", source: http://cdn.taboola.com/libtrc/hexun-hxcom/loader.js (11)
[1:1:0712/042341.804519:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 895, 7fe8bc2768db
[1:1:0712/042341.851955:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"685 0x7fe8b9931070 0x1bfc4b955660 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042341.852298:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"685 0x7fe8b9931070 0x1bfc4b955660 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042341.852764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 983
[1:1:0712/042341.853021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7fe8b9931070 0x1bfc4c124260 , 5:3_http://funds.hexun.com/, 0, , 895 0x7fe8b9931070 0x1bfc4c34da60 
[1:1:0712/042341.853371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042341.853976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/042341.854208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042341.857045:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 896, 7fe8bc2768db
[1:1:0712/042341.890558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"686 0x7fe8b9931070 0x1bfc4c7d00e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042341.890954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"686 0x7fe8b9931070 0x1bfc4c7d00e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042341.891380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 985
[1:1:0712/042341.891574:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7fe8b9931070 0x1bfc4b43b760 , 5:3_http://funds.hexun.com/, 0, , 896 0x7fe8b9931070 0x1bfc4ce58660 
[1:1:0712/042341.891821:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042341.892384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/042341.892561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042342.004655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042342.004863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042342.026055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042342.026272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042342.190774:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 958, 7fe8bc276881
[1:1:0712/042342.236932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"900 0x7fe8b9931070 0x1bfc4b9558e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042342.237290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"900 0x7fe8b9931070 0x1bfc4b9558e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042342.237734:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042342.238292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042342.238476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042342.240243:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 957, 7fe8bc2768db
[1:1:0712/042342.282225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"900 0x7fe8b9931070 0x1bfc4b9558e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042342.282410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"900 0x7fe8b9931070 0x1bfc4b9558e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042342.282670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 994
[1:1:0712/042342.282795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7fe8b9931070 0x1bfc4ccaa560 , 5:3_http://funds.hexun.com/, 0, , 957 0x7fe8b9931070 0x1bfc4b4375e0 
[1:1:0712/042342.282949:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042342.283590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042342.283860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042342.284684:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042342.284887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042342.285326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 995
[1:1:0712/042342.285570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7fe8b9931070 0x1bfc4c7dd160 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 957 0x7fe8b9931070 0x1bfc4b4375e0 
[1:1:0712/042342.480279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 965 0x7fe8bb8592e0 0x1bfc4cee8b60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042342.481532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , jQuery1112013918829302415014_1562930576441({"islogin":"False","userid":"","username":"","nickname":"
[1:1:0712/042342.481778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042342.482698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://funds.hexun.com/smjj/"
[1:1:0712/042342.986135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 966 0x7fe8bb8592e0 0x1bfc4c8af660 , "http://funds.hexun.com/smjj/"
[1:1:0712/042342.987396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , jQuery1112013918829302415014_1562930576443({"islogin":"False","userid":"","username":"","nickname":"
[1:1:0712/042342.987668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042342.988452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://funds.hexun.com/smjj/"
		remove user.12_39f740cd -> 0
		remove user.13_44c3954f -> 0
[1:1:0712/042343.638393:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://funds.hexun.com/smjj/"
[1:1:0712/042343.638824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , script.onerror, () {
          error && error();
        }
[1:1:0712/042343.638940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042343.640139:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76346:76346:0712/042343.641509:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042343.644030:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1bfc4c2cd820
[1:1:0712/042343.644213:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[76346:76346:0712/042343.648637:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/042343.661317:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042343.661549:INFO:render_frame_impl.cc(7019)] 	 [url] = http://funds.hexun.com
[1:1:0712/042343.665066:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76346:76346:0712/042343.671391:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://funds.hexun.com/
[1:1:0712/042343.671432:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x1bfc4c643220
[1:1:0712/042343.671697:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0712/042343.681368:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042343.681644:INFO:render_frame_impl.cc(7019)] 	 [url] = http://funds.hexun.com
[76346:76346:0712/042343.688195:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[76346:76346:0712/042343.694862:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[76346:76346:0712/042343.700181:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://funds.hexun.com/
[1:1:0712/042343.764478:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fe8bb8592e0 0x1bfc4c350d60 , "http://funds.hexun.com/smjj/"
[1:1:0712/042343.793861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , /*! 365-420-RELEASE 2019-07-11 */

function __trcCopyProps(e,t,i){for(r in e)t[r]=e[r];if(i)for(var 
[1:1:0712/042343.794111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[76346:76346:0712/042343.828504:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76346:76346:0712/042343.835606:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76346:76357:0712/042343.863037:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[76346:76346:0712/042343.863092:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h10hxsame.hexun.com/
[76346:76346:0712/042343.863139:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://h10hxsame.hexun.com/, https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1, 5
[76346:76357:0712/042343.863144:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042343.863206:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://h10hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:23:43 GMT Content-Type: text/html; charset=GBK Content-Length: 364 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:23:43 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,76442, 5
[76346:76346:0712/042343.864480:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76346:76346:0712/042343.866728:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0712/042343.868846:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[76346:76357:0712/042343.877243:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[76346:76346:0712/042343.877293:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h01hxsame.hexun.com/
[76346:76346:0712/042343.877337:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://h01hxsame.hexun.com/, https://h01hxsame.hexun.com/s?z=hexun&c=2078&op=1, 6
[76346:76357:0712/042343.877338:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042343.877400:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://h01hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:23:43 GMT Content-Type: text/html; charset=GBK Content-Length: 983 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:23:43 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,76442, 5
[1:7:0712/042343.883387:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042344.702684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042344.702945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042344.789638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042344.789900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042345.103570:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 995, 7fe8bc276881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042345.141629:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"957 0x7fe8b9931070 0x1bfc4b4375e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042345.141825:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"957 0x7fe8b9931070 0x1bfc4b4375e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042345.142089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042345.142390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042345.142492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042345.263050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 994, 7fe8bc2768db
[1:1:0712/042345.279014:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"957 0x7fe8b9931070 0x1bfc4b4375e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042345.279254:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"957 0x7fe8b9931070 0x1bfc4b4375e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042345.279529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1071
[1:1:0712/042345.279650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1071 0x7fe8b9931070 0x1bfc4bf5ce60 , 5:3_http://funds.hexun.com/, 0, , 994 0x7fe8b9931070 0x1bfc4ccaa560 
[1:1:0712/042345.279849:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042345.280234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042345.280379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042345.280806:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042345.280975:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042345.281353:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1072
[1:1:0712/042345.281544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1072 0x7fe8b9931070 0x1bfc4cefa2e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 994 0x7fe8b9931070 0x1bfc4ccaa560 
[1:1:0712/042346.106952:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://h10hxsame.hexun.com/
[1:1:0712/042346.342684:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://h01hxsame.hexun.com/
[1:1:0712/042347.275392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042347.275742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042347.480392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042347.480797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042347.485532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 983, 7fe8bc2768db
[1:1:0712/042347.524970:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"895 0x7fe8b9931070 0x1bfc4c34da60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.525255:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"895 0x7fe8b9931070 0x1bfc4c34da60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.525661:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1108
[1:1:0712/042347.525947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1108 0x7fe8b9931070 0x1bfc4ce32de0 , 5:3_http://funds.hexun.com/, 0, , 983 0x7fe8b9931070 0x1bfc4c124260 
[1:1:0712/042347.526414:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042347.527098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/042347.527328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042347.575328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 985, 7fe8bc2768db
[1:1:0712/042347.597280:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"896 0x7fe8b9931070 0x1bfc4ce58660 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.597470:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"896 0x7fe8b9931070 0x1bfc4ce58660 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.597692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1109
[1:1:0712/042347.597831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7fe8b9931070 0x1bfc4dbe24e0 , 5:3_http://funds.hexun.com/, 0, , 985 0x7fe8b9931070 0x1bfc4b43b760 
[1:1:0712/042347.598057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042347.598356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/042347.598460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042347.698303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1072, 7fe8bc276881
[1:1:0712/042347.740345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"994 0x7fe8b9931070 0x1bfc4ccaa560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.740556:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"994 0x7fe8b9931070 0x1bfc4ccaa560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.740803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042347.741136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042347.741243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042347.957725:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1071, 7fe8bc2768db
[1:1:0712/042347.992762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"994 0x7fe8b9931070 0x1bfc4ccaa560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.993124:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"994 0x7fe8b9931070 0x1bfc4ccaa560 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042347.993441:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1115
[1:1:0712/042347.993555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1115 0x7fe8b9931070 0x1bfc4dbe7f60 , 5:3_http://funds.hexun.com/, 0, , 1071 0x7fe8b9931070 0x1bfc4bf5ce60 
[1:1:0712/042347.993752:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042347.994169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042347.994358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042347.994895:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042347.995089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042347.995468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1116
[1:1:0712/042347.995660:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1116 0x7fe8b9931070 0x1bfc4ce997e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 1071 0x7fe8b9931070 0x1bfc4bf5ce60 
[1:1:0712/042348.089447:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76346:76346:0712/042348.096303:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://h10hxsame.hexun.com/, https://h10hxsame.hexun.com/, 5
[76346:76346:0712/042348.096433:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://h10hxsame.hexun.com/, https://h10hxsame.hexun.com
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042348.327980:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[76346:76346:0712/042348.331764:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://h01hxsame.hexun.com/, https://h01hxsame.hexun.com/, 6
[76346:76346:0712/042348.331855:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://h01hxsame.hexun.com/, https://h01hxsame.hexun.com
[1:1:0712/042348.446823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042348.446999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042348.549980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042348.550254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042348.658392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1116, 7fe8bc276881
[1:1:0712/042348.675009:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"1071 0x7fe8b9931070 0x1bfc4bf5ce60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042348.675235:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"1071 0x7fe8b9931070 0x1bfc4bf5ce60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042348.675447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042348.675760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042348.675866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042348.798941:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042349.297180:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042349.684106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042349.684288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042349.794075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042349.794324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042350.150524:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042350.150786:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1"
[1:1:0712/042350.155721:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1158 0x7fe8b9931070 0x1bfc4c22c060 , "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1"
[1:1:0712/042350.205373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://h10hxsame.hexun.com/, 0af81bcce998, , , 
(function() {
var s = "_" + Math.random().toString(36).slice(2);
document.write('<div style="" id="
[1:1:0712/042350.205698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1", "h10hxsame.hexun.com", 5, 1, http://funds.hexun.com, hexun.com, 3
[1:1:0712/042350.222876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1115, 7fe8bc2768db
[1:1:0712/042350.276726:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1071 0x7fe8b9931070 0x1bfc4bf5ce60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042350.277090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1071 0x7fe8b9931070 0x1bfc4bf5ce60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042350.277569:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1195
[1:1:0712/042350.277792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7fe8b9931070 0x1bfc4dd12d60 , 5:3_http://funds.hexun.com/, 0, , 1115 0x7fe8b9931070 0x1bfc4dbe7f60 
[1:1:0712/042350.278146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042350.278666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042350.278920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042350.279706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042350.279908:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042350.280305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1196
[1:1:0712/042350.280538:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1196 0x7fe8b9931070 0x1bfc4dd253e0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 1115 0x7fe8b9931070 0x1bfc4dbe7f60 
[1:1:0712/042350.396370:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042350.396590:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://h01hxsame.hexun.com/s?z=hexun&c=2078&op=1"
[1:1:0712/042350.404198:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1166 0x7fe8b9931070 0x1bfc4bf9dd60 , "https://h01hxsame.hexun.com/s?z=hexun&c=2078&op=1"
[1:1:0712/042350.441203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://h01hxsame.hexun.com/, 0af81bcd3a90, , , 
if('http://'!='http://' && 'http://'!=''){document.write('<img src="http://" width="0" height="0" /
[1:1:0712/042350.441498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://h01hxsame.hexun.com/s?z=hexun&c=2078&op=1", "h01hxsame.hexun.com", 6, 1, http://funds.hexun.com, hexun.com, 3
[1:1:0712/042350.640911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042350.641150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042350.669628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042350.669911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042350.790744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1108, 7fe8bc2768db
[1:1:0712/042350.842134:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"983 0x7fe8b9931070 0x1bfc4c124260 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042350.842410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"983 0x7fe8b9931070 0x1bfc4c124260 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042350.842820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1221
[1:1:0712/042350.843088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1221 0x7fe8b9931070 0x1bfc4bf5ce60 , 5:3_http://funds.hexun.com/, 0, , 1108 0x7fe8b9931070 0x1bfc4ce32de0 
[1:1:0712/042350.843523:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042350.844245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/042350.844470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042350.847445:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1109, 7fe8bc2768db
[1:1:0712/042350.903086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"985 0x7fe8b9931070 0x1bfc4b43b760 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042350.903367:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"985 0x7fe8b9931070 0x1bfc4b43b760 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042350.903768:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1223
[1:1:0712/042350.903988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1223 0x7fe8b9931070 0x1bfc4cd7ec60 , 5:3_http://funds.hexun.com/, 0, , 1109 0x7fe8b9931070 0x1bfc4dbe24e0 
[1:1:0712/042350.904308:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042350.904823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/042350.905040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042351.343700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1196, 7fe8bc276881
[1:1:0712/042351.398110:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"1115 0x7fe8b9931070 0x1bfc4dbe7f60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042351.398424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"1115 0x7fe8b9931070 0x1bfc4dbe7f60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042351.398817:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042351.399340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042351.399519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042351.805365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042351.805607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042351.864952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042351.865193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042351.923279:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1195, 7fe8bc2768db
[1:1:0712/042351.979196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1115 0x7fe8b9931070 0x1bfc4dbe7f60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042351.979516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1115 0x7fe8b9931070 0x1bfc4dbe7f60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042351.979945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1252
[1:1:0712/042351.980144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1252 0x7fe8b9931070 0x1bfc4dd122e0 , 5:3_http://funds.hexun.com/, 0, , 1195 0x7fe8b9931070 0x1bfc4dd12d60 
[1:1:0712/042351.980501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042351.981006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042351.981182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042351.981829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042351.981999:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042351.982341:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1253
[1:1:0712/042351.982533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1253 0x7fe8b9931070 0x1bfc4cd83fe0 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 1195 0x7fe8b9931070 0x1bfc4dd12d60 
[1:1:0712/042352.725391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042352.725583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042352.805574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042352.805752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042352.808631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1253, 7fe8bc276881
[1:1:0712/042352.864800:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"1195 0x7fe8b9931070 0x1bfc4dd12d60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042352.865216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"1195 0x7fe8b9931070 0x1bfc4dd12d60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042352.865713:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042352.866378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042352.866629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042353.321361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , document.readyState
[1:1:0712/042353.321536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042353.323018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1252, 7fe8bc2768db
[1:1:0712/042353.372836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1195 0x7fe8b9931070 0x1bfc4dd12d60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042353.373033:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1195 0x7fe8b9931070 0x1bfc4dd12d60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042353.373280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1291
[1:1:0712/042353.373397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1291 0x7fe8b9931070 0x1bfc4cda5160 , 5:3_http://funds.hexun.com/, 0, , 1252 0x7fe8b9931070 0x1bfc4dd122e0 
[1:1:0712/042353.373601:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042353.373922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042353.374031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042353.374323:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042353.374422:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042353.374580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1292
[1:1:0712/042353.374688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1292 0x7fe8b9931070 0x1bfc4cdd6860 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 1252 0x7fe8b9931070 0x1bfc4dd122e0 
[1:1:0712/042353.429131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042353.429316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042353.551167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1279 0x7fe8bb8592e0 0x1bfc4cdce960 , "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1"
[1:1:0712/042353.569103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://h10hxsame.hexun.com/, 0af81bcce998, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/042353.569488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1", "h10hxsame.hexun.com", 5, 1, http://funds.hexun.com, hexun.com, 3
[1:1:0712/042355.213354:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1292, 7fe8bc276881
[1:1:0712/042355.242150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"1252 0x7fe8b9931070 0x1bfc4dd122e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042355.242389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"1252 0x7fe8b9931070 0x1bfc4dd122e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042355.243297:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042355.243814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042355.243981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042355.417005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042355.417194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042356.320740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1291, 7fe8bc2768db
[1:1:0712/042356.378379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1252 0x7fe8b9931070 0x1bfc4dd122e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042356.378669:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1252 0x7fe8b9931070 0x1bfc4dd122e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042356.379147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1339
[1:1:0712/042356.379344:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1339 0x7fe8b9931070 0x1bfc4e2d1de0 , 5:3_http://funds.hexun.com/, 0, , 1291 0x7fe8b9931070 0x1bfc4cda5160 
[1:1:0712/042356.379673:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042356.380245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var t=e.now();setTimeout(function(){s.push(e.now()-t)},0)}
[1:1:0712/042356.380446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042356.381111:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26ac5a7029c8, 0x1bfc4b62e150
[1:1:0712/042356.381270:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://funds.hexun.com/smjj/", 0
[1:1:0712/042356.381595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1340
[1:1:0712/042356.381806:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1340 0x7fe8b9931070 0x1bfc4c6a9a60 , 5:3_http://funds.hexun.com/, 1, -5:3_http://funds.hexun.com/, 1291 0x7fe8b9931070 0x1bfc4cda5160 
[1:1:0712/042356.383464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1221, 7fe8bc2768db
[1:1:0712/042356.441337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1108 0x7fe8b9931070 0x1bfc4ce32de0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042356.441621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1108 0x7fe8b9931070 0x1bfc4ce32de0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042356.442091:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1343
[1:1:0712/042356.442289:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1343 0x7fe8b9931070 0x1bfc4c755060 , 5:3_http://funds.hexun.com/, 0, , 1221 0x7fe8b9931070 0x1bfc4bf5ce60 
[1:1:0712/042356.442609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042356.443275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){var e,t=0,n=0,o=0;if(s.length>0){e=s.length;for(var a=0;a<s.length;a++)n=Math.max(n,s[a]),o+=s[a]
[1:1:0712/042356.443543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042356.446540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1223, 7fe8bc2768db
[1:1:0712/042356.507580:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1109 0x7fe8b9931070 0x1bfc4dbe24e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042356.507913:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1109 0x7fe8b9931070 0x1bfc4dbe24e0 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042356.508351:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://funds.hexun.com/, 1345
[1:1:0712/042356.508549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7fe8b9931070 0x1bfc4b843160 , 5:3_http://funds.hexun.com/, 0, , 1223 0x7fe8b9931070 0x1bfc4cd7ec60 
[1:1:0712/042356.508900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042356.509424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){if(TRC.performance){var e=TRC.performance.getTimer().fps();TRC.performance.fpsMeasurements.length
[1:1:0712/042356.509609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042356.569507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042356.569681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042356.762220:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1332 0x7fe8bb8592e0 0x1bfc4e2d4fe0 , "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1"
[1:1:0712/042356.763530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://h10hxsame.hexun.com/, 0af81bcce998, , , ___adblockplus({"queryid" : "a17df2b090be596f","tuid" : "u3609529_0","placement" : {"basic" : {"sspI
[1:1:0712/042356.763766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1", "h10hxsame.hexun.com", 5, 1, http://funds.hexun.com, hexun.com, 3
[1:1:0712/042356.838836:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[76346:76346:0712/042356.841603:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042356.843955:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x1bfc4c760020
[1:1:0712/042356.844211:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[76346:76346:0712/042356.854784:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu3609529_0, 7, 7, 
[1:1:0712/042356.857437:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042356.857603:INFO:render_frame_impl.cc(7019)] 	 [url] = https://h10hxsame.hexun.com
[1:1:0712/042356.867591:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1", 500
[1:1:0712/042356.868156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_https://h10hxsame.hexun.com/, 1366
[1:1:0712/042356.868380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1366 0x7fe8b9931070 0x1bfc4e232960 , 5:5_https://h10hxsame.hexun.com/, 1, -5:5_https://h10hxsame.hexun.com/, 1332 0x7fe8bb8592e0 0x1bfc4e2d4fe0 
[1:1:0712/042356.872805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1", 50
[1:1:0712/042356.873343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_https://h10hxsame.hexun.com/, 1368
[1:1:0712/042356.873541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1368 0x7fe8b9931070 0x1bfc4dbcf460 , 5:5_https://h10hxsame.hexun.com/, 1, -5:5_https://h10hxsame.hexun.com/, 1332 0x7fe8bb8592e0 0x1bfc4e2d4fe0 
[76346:76346:0712/042356.875962:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:5_https://h10hxsame.hexun.com/
[76346:76346:0712/042357.010142:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76346:76346:0712/042357.011626:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76346:76357:0712/042357.043012:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[76346:76357:0712/042357.043083:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042357.043331:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[76346:76346:0712/042357.043433:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://pos.baidu.com/, https://pos.baidu.com/rcqm?conwid=1000&conhei=90&rdid=3609529&dc=3&exps=110011&psi=58e28b4934583d45255964b8dc23d724&di=u3609529&dri=0&dis=11&dai=1&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562930634886&ari=2&dbv=2&drs=3&pcs=1000x90&pss=1000x90&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562930634&prot=2&rw=320&ltu=http%3A%2F%2Ffunds.hexun.com%2Fsmjj%2F&liu=https%3A%2F%2Fh10hxsame.hexun.com%2Fs%3Fz%3Dhexun%26c%3D2076%26op%3D1&ltr=http%3A%2F%2Ffunds.hexun.com%2Fsmjj%2F&ecd=1&uc=1211x623&pis=1000x90&sr=1276x647&tcn=1562930635&qn=a17df2b090be596f&tt=1562930633598.1347.3174.3215&lto=http%3A%2F%2Ffunds.hexun.com&ltl=1, 7
[76346:76346:0712/042357.043631:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 12579 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 11:23:57 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 19:23:57 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,76442, 5
[1:1:0712/042357.062274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1340, 7fe8bc276881
[1:7:0712/042357.062439:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042357.092326:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"1291 0x7fe8b9931070 0x1bfc4cda5160 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042357.092528:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"1291 0x7fe8b9931070 0x1bfc4cda5160 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042357.092763:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042357.093105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , (){s.push(e.now()-t)}
[1:1:0712/042357.093259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042357.321222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , h, (e){t.requestAnimationFrame(h),g.tick(e)}
[1:1:0712/042357.321471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042357.326874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 871, 7fe8bc276881
[1:1:0712/042357.390925:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0af81bc22860","ptid":"797 0x7fe8b9931070 0x1bfc4cd85e60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042357.391390:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://funds.hexun.com/","ptid":"797 0x7fe8b9931070 0x1bfc4cd85e60 ","rf":"5:3_http://funds.hexun.com/"}
[1:1:0712/042357.391938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://funds.hexun.com/smjj/"
[1:1:0712/042357.392522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://funds.hexun.com/, 0af81bc22860, , , () {
          if (win[callback] != null) {
            win[callback] = null;
            error &
[1:1:0712/042357.392713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 1, , , 0
[1:1:0712/042357.395098:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/042357.400362:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1"
[1:1:0712/042357.402573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://funds.hexun.com/-5:5_https://h10hxsame.hexun.com/, 0af81bcce998, 0af81bc22860, , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/042357.402916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1", "h10hxsame.hexun.com", 5, 2, http://funds.hexun.com, hexun.com, 3
[1:1:0712/042357.404094:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.publicMethod_obj.exchangeInner [as init] (https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1)
	adRender (https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1)
	https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1
	https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1

[76346:76346:0712/042357.414938:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042357.416454:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x1bfc4c763220
[1:1:0712/042357.416651:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[76346:76346:0712/042357.423336:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[1:1:0712/042357.425119:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042357.425264:INFO:render_frame_impl.cc(7019)] 	 [url] = https://h10hxsame.hexun.com
[1:1:0712/042357.425888:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1"
[1:1:0712/042357.427521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x26ac5a7e63a8, 0x1bfc4b62e250
[1:1:0712/042357.427635:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1", 2000
[1:1:0712/042357.427812:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://funds.hexun.com/, 1394
[1:1:0712/042357.427921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1394 0x7fe8b9931070 0x1bfc4b844360 , 5:3_http://funds.hexun.com/, 2, -5:3_http://funds.hexun.com/-5:5_https://h10hxsame.hexun.com/, 871 0x7fe8b9931070 0x1bfc4c7cb4e0 
[1:1:0712/042357.430169:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://funds.hexun.com/smjj/"
[1:1:0712/042357.430500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://funds.hexun.com/-5:5_https://h10hxsame.hexun.com/-5:3_http://funds.hexun.com/, 0af81bc22860, 0af81bcce998, , (t){"complete"===t.target.readyState&&TRC.performance.measurements.push({name:"generalMeasure_docume
[1:1:0712/042357.430653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://funds.hexun.com/smjj/", "hexun.com", 3, 3, , , 0
[1:1:0712/042357.430992:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.publicMethod_obj.exchangeInner [as init] (https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1)
	adRender (https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1)
	https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1
	https://hxjstool.hexun.com/funds/pageMediaControl_smjj2016.js:1:1

[76346:76346:0712/042357.440109:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://funds.hexun.com/
[1:1:0712/042357.461011:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x1bfc4c760020
[1:1:0712/042357.461259:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[1:1:0712/042357.479850:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042357.480152:INFO:render_frame_impl.cc(7019)] 	 [url] = http://funds.hexun.com
[1:1:0712/042357.482746:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/042357.515143:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x1bfc4c2cd820
[1:1:0712/042357.515411:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[1:1:0712/042357.537091:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042357.537377:INFO:render_frame_impl.cc(7019)] 	 [url] = http://funds.hexun.com
[76346:76346:0712/042357.570212:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[76346:76346:0712/042357.576614:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[76346:76346:0712/042357.587643:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://funds.hexun.com/
[76346:76346:0712/042357.629822:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[76346:76346:0712/042357.635902:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[76346:76346:0712/042357.648391:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://funds.hexun.com/
[76346:76346:0712/042357.667765:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[76346:76346:0712/042357.669407:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76346:76357:0712/042357.713353:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[76346:76357:0712/042357.713566:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042357.713690:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h10hxsame.hexun.com/
[76346:76346:0712/042357.713791:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://h10hxsame.hexun.com/, https://h10hxsame.hexun.com/s?z=hexun&c=2076&op=1, 9
[76346:76346:0712/042357.713972:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_https://h10hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:23:57 GMT Content-Type: text/html; charset=GBK Content-Length: 364 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:23:57 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,76442, 5
[76346:76346:0712/042357.718543:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:7:0712/042357.719125:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[76346:76346:0712/042357.720214:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[76346:76357:0712/042357.754938:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 10
[76346:76357:0712/042357.755044:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 10, HandleIncomingMessage, HandleIncomingMessage
[76346:76346:0712/042357.755197:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://h01hxsame.hexun.com/
[76346:76346:0712/042357.755285:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_https://h01hxsame.hexun.com/, https://h01hxsame.hexun.com/s?z=hexun&c=2078&op=1, 10
[76346:76346:0712/042357.755425:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:10_https://h01hxsame.hexun.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 11:23:57 GMT Content-Type: text/html; charset=GBK Content-Length: 983 Connection: keep-alive P3P: CP="CAO PSA OUR" Set-Cookie: ADVC=3786c467064c54;expires=Sun,11-Jul-2021 19:23:57 +0800;path=/;domain=hexun.com Expires: 0 Cache-control: private,no-store,no-cache,must-revalidate,proxy-revalidate,no-transform,max-age=0  ,76442, 5
[1:7:0712/042357.762873:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
