[0713/033656.807750:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/033656.808034:INFO:switcher_clone.cc(787)] backtrace rip is 7f6fd3f8b891
[0713/033657.655560:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/033657.655832:INFO:switcher_clone.cc(787)] backtrace rip is 7fbeedcc5891
[1:1:0713/033657.659964:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/033657.660142:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/033657.665449:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/033659.132516:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/033659.133052:INFO:switcher_clone.cc(787)] backtrace rip is 7fb55dd36891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[50425:50425:0713/033659.343336:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[50457:50457:0713/033659.392517:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=50457
[50467:50467:0713/033659.392918:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=50467

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c3f42c88-cb85-4126-9c11-f65be82f7af4
[50425:50425:0713/033659.871420:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[50425:50455:0713/033659.872221:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/033659.872465:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/033659.872681:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/033659.873275:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/033659.873454:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/033659.876357:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x20f60a48, 1
[1:1:0713/033659.876723:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3a732ef7, 0
[1:1:0713/033659.876942:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2be5057, 3
[1:1:0713/033659.877154:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1edf39bb, 2
[1:1:0713/033659.877377:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff72e733a 480afffffff620 ffffffbb39ffffffdf1e 5750ffffffbe02 , 10104, 4
[1:1:0713/033659.878384:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[50425:50455:0713/033659.878709:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�.s:H
� �9�WP�4d=
[50425:50455:0713/033659.878776:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �.s:H
� �9�WP�hB4d=
[1:1:0713/033659.878705:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbeebf000a0, 3
[50425:50455:0713/033659.879074:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/033659.878967:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbeec08b080, 2
[50425:50455:0713/033659.879154:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 50477, 4, f72e733a 480af620 bb39df1e 5750be02 
[1:1:0713/033659.879170:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbed5d4ed20, -2
[1:1:0713/033659.897856:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/033659.898743:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1edf39bb
[1:1:0713/033659.899664:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1edf39bb
[1:1:0713/033659.901220:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1edf39bb
[1:1:0713/033659.902738:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.902963:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.903184:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.903430:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.904103:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1edf39bb
[1:1:0713/033659.904483:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbeedcc57ba
[1:1:0713/033659.904665:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbeedcbcdef, 7fbeedcc577a, 7fbeedcc70cf
[1:1:0713/033659.910370:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1edf39bb
[1:1:0713/033659.910785:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1edf39bb
[1:1:0713/033659.911575:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1edf39bb
[1:1:0713/033659.913621:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.913869:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.914112:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.914339:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edf39bb
[1:1:0713/033659.915661:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1edf39bb
[1:1:0713/033659.916063:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbeedcc57ba
[1:1:0713/033659.916250:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbeedcbcdef, 7fbeedcc577a, 7fbeedcc70cf
[1:1:0713/033659.923989:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/033659.924487:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/033659.924689:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe13323118, 0x7ffe13323098)
[1:1:0713/033659.939414:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/033659.945188:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[50425:50425:0713/033700.605417:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50425:50425:0713/033700.606828:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50425:50436:0713/033700.624596:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[50425:50425:0713/033700.624696:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[50425:50425:0713/033700.624762:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[50425:50436:0713/033700.624734:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[50425:50425:0713/033700.624867:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,50477, 4
[1:7:0713/033700.627763:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[50425:50449:0713/033700.691736:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/033700.720986:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x8abaeb5d220
[1:1:0713/033700.721281:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/033701.060491:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/033702.983273:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033702.987897:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[50425:50425:0713/033703.256107:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[50425:50425:0713/033703.256170:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/033703.684399:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033703.928081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 345ad1021f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/033703.928398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033703.944589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 345ad1021f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/033703.944842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033704.008887:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033704.009214:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033704.318846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033704.326843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 345ad1021f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/033704.327074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033704.351115:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033704.361646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 345ad1021f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/033704.361899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033704.373602:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/033704.377045:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x8abaeb5be20
[1:1:0713/033704.377249:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[50425:50425:0713/033704.377659:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[50425:50425:0713/033704.384030:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[50425:50425:0713/033704.413243:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[50425:50425:0713/033704.413346:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/033704.480940:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033705.312995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7fbed79292e0 0x8abaed1c2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033705.315822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 345ad1021f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/033705.316291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033705.319927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[50425:50425:0713/033705.390155:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/033705.394247:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x8abaeb5c820
[1:1:0713/033705.394523:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[50425:50425:0713/033705.401898:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/033705.413541:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/033705.413782:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[50425:50425:0713/033705.422061:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[50425:50425:0713/033705.433863:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50425:50425:0713/033705.434915:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50425:50436:0713/033705.441537:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[50425:50436:0713/033705.441628:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[50425:50425:0713/033705.441809:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[50425:50425:0713/033705.441891:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[50425:50425:0713/033705.442031:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,50477, 4
[1:7:0713/033705.445992:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/033706.002444:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/033706.206774:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fbed79292e0 0x8abaed6ae60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033706.207860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 345ad1021f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/033706.208133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033706.208929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[50425:50425:0713/033706.496361:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[50425:50425:0713/033706.496479:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/033706.498851:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/033707.051193:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[50425:50425:0713/033707.303975:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[50425:50455:0713/033707.304517:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/033707.304705:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/033707.304958:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/033707.305380:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/033707.305561:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/033707.308727:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x10e303f5, 1
[1:1:0713/033707.309208:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3f0b184e, 0
[1:1:0713/033707.309421:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3b6cd6d7, 3
[1:1:0713/033707.309613:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x8120998, 2
[1:1:0713/033707.309797:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4e180b3f fffffff503ffffffe310 ffffff98091208 ffffffd7ffffffd66c3b , 10104, 5
[1:1:0713/033707.310843:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[50425:50455:0713/033707.311146:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGN?���	��l;�7d=
[50425:50455:0713/033707.311275:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is N?���	��l;�ߞ7d=
[1:1:0713/033707.311130:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbeebf000a0, 3
[1:1:0713/033707.311415:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbeec08b080, 2
[50425:50455:0713/033707.311579:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 50521, 5, 4e180b3f f503e310 98091208 d7d66c3b 
[1:1:0713/033707.311669:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbed5d4ed20, -2
[1:1:0713/033707.332300:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/033707.332683:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8120998
[1:1:0713/033707.333008:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8120998
[1:1:0713/033707.333641:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8120998
[1:1:0713/033707.335077:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.335322:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.335535:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.335750:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.336437:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8120998
[1:1:0713/033707.336757:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbeedcc57ba
[1:1:0713/033707.336927:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbeedcbcdef, 7fbeedcc577a, 7fbeedcc70cf
[1:1:0713/033707.342632:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8120998
[1:1:0713/033707.343024:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8120998
[1:1:0713/033707.343768:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8120998
[1:1:0713/033707.345758:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.346022:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.346277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.346530:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8120998
[1:1:0713/033707.347831:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8120998
[1:1:0713/033707.348249:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbeedcc57ba
[1:1:0713/033707.348422:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbeedcbcdef, 7fbeedcc577a, 7fbeedcc70cf
[1:1:0713/033707.356503:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/033707.357059:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/033707.357274:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe13323118, 0x7ffe13323098)
[1:1:0713/033707.372616:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/033707.376852:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/033707.565490:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x8abaeb21220
[1:1:0713/033707.565805:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/033707.609182:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033707.609464:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033708.145594:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033708.150269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/033708.150613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033708.158559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033708.274987:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/033708.275833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 345ad1021f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/033708.276110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/033708.384684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033708.386330:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/033708.386621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/033708.386902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033708.485661:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033708.486658:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/033708.486900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/033708.487189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033709.139291:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0713/033709.186808:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[1:1:0713/033709.348393:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mobile.zol.com.cn/"
[50425:50425:0713/033709.385010:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50425:50425:0713/033709.392645:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50425:50436:0713/033709.444482:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[50425:50436:0713/033709.444582:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[50425:50425:0713/033709.444674:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.lenovo.com/
[50425:50425:0713/033709.444753:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.lenovo.com/, https://www.lenovo.com/dk/da/, 1
[50425:50425:0713/033709.444854:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.lenovo.com/, HTTP/1.1 200 status:200 requestuuid:f26b47cd-f664-4a2d-9e97-a2aec04fda99 callid:781f8e1c-8ba6-4ba0-bbd6-0350178a5ef5 costtime:{"id":"781f8e1c-8ba6-4ba0-bbd6-0350178a5ef5","appName":"liecomm-microservices-web","currentTime":1563014044763} x-xss-protection:1; mode=block x-frame-options:DENY content-type:text/html;charset=UTF-8 x-dynatrace:PT=1142173510;PA=-1643921459;SP=y_Production;PS=-384574522 content-encoding:gzip content-length:32207 cache-control:private, max-age=1800 expires:Sat, 13 Jul 2019 11:07:09 GMT date:Sat, 13 Jul 2019 10:37:09 GMT vary:Accept-Encoding set-cookie:akavpau_WaitingRoomController=1563014529~id=0da44aafea4840f546df3b683dfa2905; Domain=www.lenovo.com; Path=/  ,50521, 5
[1:7:0713/033709.451561:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/033709.506370:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.lenovo.com/
[1:1:0713/033709.529599:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.researchgate.net/?_sg=GTTcjmmIjXiKFH9nfUmSzdlSVNCfHlOW5NedMmBB5tECtK-L3s9hJP_gtJf5_sYEDAmD6IvCizZl"
[1:1:0713/033709.613012:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://stackoverflow.com/"
[50425:50425:0713/033709.652877:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.lenovo.com/, https://www.lenovo.com/, 1
[50425:50425:0713/033709.652975:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.lenovo.com/, https://www.lenovo.com
[1:1:0713/033709.687972:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.fandom.com/"
[1:1:0713/033709.718359:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/033709.729433:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0713/033709.786415:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.springer.com/"
[1:1:0713/033709.834826:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033709.859474:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033709.860397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/033709.860743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033709.947422:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/033709.951195:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033709.951319:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.lenovo.com/dk/da/"
[1:1:0713/033710.028271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.029317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/033710.029593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033710.070396:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033710.085966:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.086904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/033710.087187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033710.166971:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/033710.190622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.191815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/033710.192190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033710.330299:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.331351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/033710.331640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033710.375198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.376285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/033710.376598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033710.555594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.556656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/033710.556954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033710.580484:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033710.580807:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.lenovo.com/dk/da/"
[1:1:0713/033710.794518:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/033710.882320:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.883478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/033710.883824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033710.922291:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033710.923377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/033710.923674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/033711.062787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/033711.063715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 345ad114e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/033711.063987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/033712.527781:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033713.799285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7fbed5d69bd0 0x8abaecf53d8 , "https://www.lenovo.com/dk/da/"
[1:1:0713/033713.810557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.lenovo.com/, 3cab6da02860, , , !function(global,factory){"use strict";"object"==typeof module&&"object"==typeof module.exports?modu
[1:1:0713/033713.810899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.lenovo.com/dk/da/", "www.lenovo.com", 3, 1, , , 0
[1:1:0713/033713.838926:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033714.278013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7fbed5d69bd0 0x8abaecf53d8 , "https://www.lenovo.com/dk/da/"
[1:1:0713/033714.285817:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7fbed5d69bd0 0x8abaecf53d8 , "https://www.lenovo.com/dk/da/"
[1:1:0713/033714.296148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7fbed5d69bd0 0x8abaecf53d8 , "https://www.lenovo.com/dk/da/"
[1:1:0713/033714.298843:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 393 0x7fbed5d69bd0 0x8abaecf53d8 , "https://www.lenovo.com/dk/da/"
[1:1:0713/033715.078835:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.803874, 0, 1
[1:1:0713/033715.079129:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/033715.414438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 411 0x7fbed79292e0 0x8abaec43a60 , "https://www.lenovo.com/dk/da/"
[1:1:0713/033715.415336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.lenovo.com/, 3cab6da02860, , , /* cleared */
[1:1:0713/033715.415562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.lenovo.com/dk/da/", "www.lenovo.com", 3, 1, , , 0
[1:1:0713/033715.519112:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/033715.519391:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.lenovo.com/dk/da/"
[1:1:0713/033715.918326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7fbed5d69bd0 0x8abaecc0c58 , "https://www.lenovo.com/dk/da/"
[1:1:0713/033715.971300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.lenovo.com/, 3cab6da02860, , , // For license information, see `https://assets.adobedtm.com/launch-ENbd80d0d08563407f8765e66b51ce82
[1:1:0713/033715.971604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.lenovo.com/dk/da/", "www.lenovo.com", 3, 1, , , 0
[1:1:0713/033718.092698:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033718.093266:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033718.093722:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033718.094258:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033718.095967:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[50425:50425:0713/033753.074798:INFO:CONSOLE(1)] "JQMIGRATE: Migrate is installed with logging active, version 3.0.1", source: https://static.lenovo.com/fea/js/temp/jquery-3.3.1-w-migrate.js (1)
[50425:50425:0713/033753.079798:INFO:CONSOLE(1)] "[object Object]", source: https://static.lenovo.com/fea/js/vendor/AdobeAnalyticsEvent.js (1)
[50425:50425:0713/033753.126524:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/033753.180695:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/033754.765570:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033754.775671:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033754.776354:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/033756.567870:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b9cf9a029c8, 0x8abae9a1160
[1:1:0713/033756.568174:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.lenovo.com/dk/da/", 0
[1:1:0713/033756.568592:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.lenovo.com/, 1088
[1:1:0713/033756.568825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7fbed5a01070 0x8abae73dc60 , 5:3_https://www.lenovo.com/, 1, -5:3_https://www.lenovo.com/, 439 0x7fbed5d69bd0 0x8abaecc0c58 
[1:1:0713/033756.583015:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.lenovo.com/dk/da/", 1000
[1:1:0713/033756.583383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.lenovo.com/, 1089
[1:1:0713/033756.583631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7fbed5a01070 0x8abaedd9560 , 5:3_https://www.lenovo.com/, 1, -5:3_https://www.lenovo.com/, 439 0x7fbed5d69bd0 0x8abaecc0c58 
[1:1:0713/033757.834909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1b9cf9a029c8, 0x8abae9a1160
[1:1:0713/033757.835278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.lenovo.com/dk/da/", 3000
[1:1:0713/033757.835782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.lenovo.com/, 1109
[1:1:0713/033757.836056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7fbed5a01070 0x8abb04548e0 , 5:3_https://www.lenovo.com/, 1, -5:3_https://www.lenovo.com/, 439 0x7fbed5d69bd0 0x8abaecc0c58 
[1:1:0713/033758.626072:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x1b9cf9a029c8, 0x8abae9a1160
[1:1:0713/033758.626300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.lenovo.com/dk/da/", 2000
[1:1:0713/033758.626884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.lenovo.com/, 1140
[1:1:0713/033758.627090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1140 0x7fbed5a01070 0x8abb0de2560 , 5:3_https://www.lenovo.com/, 1, -5:3_https://www.lenovo.com/, 439 0x7fbed5d69bd0 0x8abaecc0c58 
[1:1:0713/033758.939828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.lenovo.com/, 3cab6da02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/033758.940147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.lenovo.com/dk/da/", "www.lenovo.com", 3, 1, , , 0
