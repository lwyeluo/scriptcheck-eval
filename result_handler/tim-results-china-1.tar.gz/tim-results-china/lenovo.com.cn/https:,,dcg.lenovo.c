[0713/034017.729358:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/034017.729796:INFO:switcher_clone.cc(787)] backtrace rip is 7f4d560cb891
[0713/034018.729662:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/034018.729938:INFO:switcher_clone.cc(787)] backtrace rip is 7f26560a9891
[1:1:0713/034018.733982:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/034018.734150:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/034018.739452:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/034020.055894:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/034020.056207:INFO:switcher_clone.cc(787)] backtrace rip is 7f0a33f8e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[50912:50912:0713/034020.281895:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=50912
[50923:50923:0713/034020.282291:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=50923
[50881:50881:0713/034020.483127:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/7d21654f-9e34-4632-b37b-cfda515231ed
[50881:50881:0713/034020.977419:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[50881:50910:0713/034020.978380:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/034020.978640:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/034020.978921:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/034020.979540:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/034020.979780:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/034020.982734:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3d7e9507, 1
[1:1:0713/034020.983053:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2696f4c6, 0
[1:1:0713/034020.983214:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2b507f68, 3
[1:1:0713/034020.983402:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x277569ae, 2
[1:1:0713/034020.983589:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc6fffffff4ffffff9626 07ffffff957e3d ffffffae697527 687f502b , 10104, 4
[1:1:0713/034020.984553:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[50881:50910:0713/034020.984818:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���&�~=�iu'hP+�.8
[50881:50910:0713/034020.984892:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���&�~=�iu'hP+H��.8
[1:1:0713/034020.984811:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f26542e40a0, 3
[1:1:0713/034020.985034:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f265446f080, 2
[50881:50910:0713/034020.985225:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/034020.985189:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f263e132d20, -2
[50881:50910:0713/034020.985318:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 50933, 4, c6f49626 07957e3d ae697527 687f502b 
[1:1:0713/034021.001525:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/034021.002127:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 277569ae
[1:1:0713/034021.002814:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 277569ae
[1:1:0713/034021.003831:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 277569ae
[1:1:0713/034021.004356:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.004461:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.004553:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.004653:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.004894:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 277569ae
[1:1:0713/034021.005036:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f26560a97ba
[1:1:0713/034021.005114:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f26560a0def, 7f26560a977a, 7f26560ab0cf
[1:1:0713/034021.006546:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 277569ae
[1:1:0713/034021.006703:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 277569ae
[1:1:0713/034021.007004:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 277569ae
[1:1:0713/034021.007671:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.007800:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.007896:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.007991:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 277569ae
[1:1:0713/034021.008425:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 277569ae
[1:1:0713/034021.008582:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f26560a97ba
[1:1:0713/034021.008653:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f26560a0def, 7f26560a977a, 7f26560ab0cf
[1:1:0713/034021.010885:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/034021.011332:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/034021.011520:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdeeeb94f8, 0x7ffdeeeb9478)
[1:1:0713/034021.024161:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/034021.031500:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[50881:50881:0713/034021.609571:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034021.610993:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50881:0713/034021.629734:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[50881:50881:0713/034021.629862:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[50881:50881:0713/034021.630065:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,50933, 4
[50881:50892:0713/034021.639628:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[50881:50892:0713/034021.639753:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/034021.641017:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[50881:50905:0713/034021.648187:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/034021.749296:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x242755cc8220
[1:1:0713/034021.750390:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/034022.100099:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[50881:50881:0713/034023.980150:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[50881:50881:0713/034023.980275:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/034024.029891:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034024.034148:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034025.090326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1ebaf6381f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/034025.090664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034025.109651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1ebaf6381f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/034025.109861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034025.157624:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034025.514353:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034025.514586:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034025.858704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034025.868792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1ebaf6381f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/034025.869319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034025.912029:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034025.922568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1ebaf6381f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/034025.922812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034025.935301:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/034025.939115:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x242755cc6e20
[1:1:0713/034025.939318:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[50881:50881:0713/034025.944580:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[50881:50881:0713/034025.954457:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[50881:50881:0713/034026.003020:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[50881:50881:0713/034026.003197:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[50881:50881:0713/034026.022152:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0713/034026.023501:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034026.752883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f263fd0d2e0 0x242755f56d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034026.754244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1ebaf6381f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/034026.754452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034026.755568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[50881:50881:0713/034026.820938:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034026.821971:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x242755cc7820
[1:1:0713/034026.822226:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[50881:50881:0713/034026.828719:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/034026.845910:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034026.846253:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[50881:50881:0713/034026.847449:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[50881:50881:0713/034026.862533:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034026.863774:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50892:0713/034026.873589:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[50881:50892:0713/034026.873711:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[50881:50881:0713/034026.873892:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[50881:50881:0713/034026.873982:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[50881:50881:0713/034026.874143:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,50933, 4
[1:7:0713/034026.879015:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/034027.506355:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/034027.950388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7f263fd0d2e0 0x24275604b460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034027.951472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1ebaf6381f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/034027.951700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034027.952473:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[50881:50881:0713/034028.092299:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[50881:50881:0713/034028.092404:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/034028.109063:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[50881:50881:0713/034028.178912:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[50881:50910:0713/034028.179363:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/034028.179619:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/034028.179933:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/034028.180323:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/034028.180485:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/034028.183619:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xb80ab6c, 1
[1:1:0713/034028.183994:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2697d1d0, 0
[1:1:0713/034028.184183:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x99bfe00, 3
[1:1:0713/034028.184367:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x340af682, 2
[1:1:0713/034028.184556:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd0ffffffd1ffffff9726 6cffffffabffffff800b ffffff82fffffff60a34 00fffffffeffffff9b09 , 10104, 5
[1:1:0713/034028.185556:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[50881:50910:0713/034028.185778:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�ї&l����
4
[50881:50910:0713/034028.185847:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �ї&l����
4
[1:1:0713/034028.185978:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f26542e40a0, 3
[50881:50910:0713/034028.186115:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 50978, 5, d0d19726 6cab800b 82f60a34 00fe9b09 
[1:1:0713/034028.186171:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f265446f080, 2
[1:1:0713/034028.186355:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f263e132d20, -2
[1:1:0713/034028.210106:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/034028.210434:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 340af682
[1:1:0713/034028.210855:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 340af682
[1:1:0713/034028.211494:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 340af682
[1:1:0713/034028.212891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.213101:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.213281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.213456:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.214176:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 340af682
[1:1:0713/034028.214460:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f26560a97ba
[1:1:0713/034028.214637:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f26560a0def, 7f26560a977a, 7f26560ab0cf
[1:1:0713/034028.220373:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 340af682
[1:1:0713/034028.220771:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 340af682
[1:1:0713/034028.221520:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 340af682
[1:1:0713/034028.223561:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.223775:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.223968:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.224151:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 340af682
[1:1:0713/034028.225397:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 340af682
[1:1:0713/034028.225789:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f26560a97ba
[1:1:0713/034028.225926:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f26560a0def, 7f26560a977a, 7f26560ab0cf
[1:1:0713/034028.233702:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/034028.234313:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/034028.234465:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdeeeb94f8, 0x7ffdeeeb9478)
[1:1:0713/034028.248245:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/034028.251511:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/034028.432399:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x242755ca1220
[1:1:0713/034028.432588:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/034028.498330:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034029.295909:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034029.296167:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[50881:50881:0713/034029.615085:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034029.622089:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50892:0713/034029.638385:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[50881:50892:0713/034029.638480:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[50881:50881:0713/034029.645883:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://dcg.lenovo.com.cn/
[50881:50881:0713/034029.645969:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn/productlist/807.html, 1
[50881:50881:0713/034029.646105:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://dcg.lenovo.com.cn/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 10:40:29 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Server: waf/2.15.0-21.el6 Access-Control-Allow-Origin: * Access-Control-Allow-Headers: X-Requested-With Access-Control-Allow-Methods: GET,POST,OPTIONS Content-Encoding: gzip X-Via: 1.1 PSbjsdBGPuw61:2 (Cdn Cache Server V2.0), 1.1 hangkuan190:1 (Cdn Cache Server V2.0), 1.1 bj170:4 (Cdn Cache Server V2.0) Connection: keep-alive  ,50978, 5
[1:7:0713/034029.647769:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/034029.706121:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://dcg.lenovo.com.cn/
[50881:50881:0713/034029.839862:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn/, 1
[50881:50881:0713/034029.840016:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn
[1:1:0713/034029.873361:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034029.877720:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 571, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/034029.882430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1ebaf64ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/034029.882715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/034029.885394:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/034029.942157:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034029.965295:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034029.995388:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034029.995648:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034030.198022:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034030.441522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/034030.442398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1ebaf6381f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/034030.442625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/034030.550358:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034030.608418:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034030.838698:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034031.061954:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/034031.156586:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.169052:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034031.174259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0713/034031.174536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
		remove user.f_9b52b9a -> 0
[1:1:0713/034031.275122:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034031.275607:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034031.275929:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034031.277833:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034031.278323:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034031.410083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.488272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.538107:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x26a827d429c8, 0x24275582d248
[1:1:0713/034031.538491:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 1000
[1:1:0713/034031.538944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 227
[1:1:0713/034031.539186:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 227 0x7f263dde5070 0x242755f864e0 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 207 0x7f263e14dbd0 0x242755d87658 
[1:1:0713/034031.554600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.570393:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.597558:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.620771:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.783952:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f263e14dbd0 0x242755d87658 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034031.786108:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/034032.153184:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x242755c9f420
[1:1:0713/034032.153487:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0713/034032.174614:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034032.174933:INFO:render_frame_impl.cc(7019)] 	 [url] = https://dcg.lenovo.com.cn
[1:1:0713/034032.178416:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.776945, 7, 0
[1:1:0713/034032.178666:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034032.413182:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034036.096719:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034036.096994:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034036.123790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7f263dde5070 0x242755e59160 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034036.127342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , var hostname=window.location.href.indexOf("dcg.lenovo.com.cn")==-1?"lenovouat.com":"lenovo.com.cn";$
[1:1:0713/034036.127639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034036.591271:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.494174, 2156, 1
[1:1:0713/034036.591593:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034038.535110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 227, 7f264072a881
[1:1:0713/034038.564408:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"207 0x7f263e14dbd0 0x242755d87658 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034038.564716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"207 0x7f263e14dbd0 0x242755d87658 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034038.565070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034038.565644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (){createLeID()}
[1:1:0713/034038.565819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034038.582578:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x242755c9e020
[1:1:0713/034038.582801:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0713/034038.603543:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034038.603744:INFO:render_frame_impl.cc(7019)] 	 [url] = https://dcg.lenovo.com.cn
[1:1:0713/034046.134561:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034046.134735:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034046.136086:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626 0x7f263dde5070 0x2427566a24e0 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034046.138699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (function(a){a.fn.slide=function(b){return a.fn.slide.defaults={type:"slide",effect:"fade",autoPlay:
[1:1:0713/034046.138817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034046.144230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626 0x7f263dde5070 0x2427566a24e0 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034046.145385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626 0x7f263dde5070 0x2427566a24e0 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034046.158035:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.023212, 105, 1
[1:1:0713/034046.158156:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034056.312111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 915 0x7f263fd0d2e0 0x24275624a960 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034056.314654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0713/034056.314774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034059.674467:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034059.674716:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034059.675625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7f263dde5070 0x242756250160 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034059.676631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , 

            function QQCHAT() {

                $('#B2B_QQ_CHAT').click();

            }

      
[1:1:0713/034059.676860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034059.682530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7f263dde5070 0x242756250160 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034059.697764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7f263dde5070 0x242756250160 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034059.701718:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7f263dde5070 0x242756250160 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034059.714785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7f263dde5070 0x242756250160 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034059.886642:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.21178, 174, 1
[1:1:0713/034059.886899:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/034101.909553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1035 0x7f263fd0d2e0 0x2427561bf8e0 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034101.911431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , /**
 * Created by amos on 14-8-9.
 * Maintained and developed by vergil since 2015/02/01
 */
(functi
[1:1:0713/034101.911664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034102.060548:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1038 0x7f263fd0d2e0 0x2427560cb760 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034102.067659:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034102.069419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , /**
 * Created by amos on 14-8-9.
 * Maintained and developed by vergil since 2015/02/01
 */
(functi
[1:1:0713/034102.069698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034103.266263:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/034103.266506:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034103.271031:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1076 0x7f263dde5070 0x2427561a7760 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034103.273201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , function lenovo_analytics(p,S){function t(g){var A=end="";g+="=";if(e.cookie){var f=e.cookie.indexOf
[1:1:0713/034103.273385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034103.282005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1076 0x7f263dde5070 0x2427561a7760 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034103.291697:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1076 0x7f263dde5070 0x2427561a7760 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034103.292294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x26a827d429c8, 0x24275582d1a0
[1:1:0713/034103.292402:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 100
[1:1:0713/034103.292573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1104
[1:1:0713/034103.292682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1104 0x7f263dde5070 0x24275623f6e0 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1076 0x7f263dde5070 0x2427561a7760 
[1:1:0713/034103.294285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034105.835739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26a827d429c8, 0x24275582d440
[1:1:0713/034105.836006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 0
[1:1:0713/034105.836439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1114
[1:1:0713/034105.836730:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1114 0x7f263dde5070 0x24275619a060 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1076 0x7f263dde5070 0x2427561a7760 
[1:1:0713/034105.848702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 13
[1:1:0713/034105.849128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://dcg.lenovo.com.cn/, 1115
[1:1:0713/034105.849347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1115 0x7f263dde5070 0x2427563a8c60 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1076 0x7f263dde5070 0x2427561a7760 
[1:1:0713/034106.114620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1081 0x7f263fd0d2e0 0x2427561d1760 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034106.115945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (function(){var e=window,f="push",k="length",l="prototype",q=function(a){if(a.get&&a.set){this.clear
[1:1:0713/034106.116168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034107.313537:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1104, 7f264072a881
[1:1:0713/034107.363442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"1076 0x7f263dde5070 0x2427561a7760 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034107.363764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"1076 0x7f263dde5070 0x2427561a7760 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034107.364148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034107.364771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (){
	if($("body").find("a[href=tocode]").length>0){
        var qrcodeH =$("body").find("a[href=toco
[1:1:0713/034107.364982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034107.376123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1114, 7f264072a881
[1:1:0713/034107.427519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"1076 0x7f263dde5070 0x2427561a7760 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034107.427832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"1076 0x7f263dde5070 0x2427561a7760 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034107.428220:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034107.428740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (){qn=t}
[1:1:0713/034107.428943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034107.430805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://dcg.lenovo.com.cn/, 1115, 7f264072a8db
[1:1:0713/034107.484424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"1076 0x7f263dde5070 0x2427561a7760 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034107.484737:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"1076 0x7f263dde5070 0x2427561a7760 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034107.485162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://dcg.lenovo.com.cn/, 1159
[1:1:0713/034107.485395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1159 0x7f263dde5070 0x242756383be0 , 5:3_https://dcg.lenovo.com.cn/, 0, , 1115 0x7f263dde5070 0x2427563a8c60 
[1:1:0713/034107.485778:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034107.486395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0713/034107.486608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034107.604875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034107.605631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , r, (e,i){var u,f,l,c,h;try{if(r&&(i||a.readyState===4)){r=t,o&&(a.onreadystatechange=v.noop,Bn&&delete 
[1:1:0713/034107.605856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034107.607170:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034107.609977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034107.610724:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1cec1b654b80
[1:1:0713/034107.643857:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034107.644328:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/034108.609828:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1142 0x7f263fd0d2e0 0x2427561e39e0 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034108.611006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , 	function yfx_set_cookie(name, value, domain) {
        var yfx_0j = "";
		 if (window.document.co
[1:1:0713/034108.611192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[50881:50881:0713/034109.731348:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[50881:50881:0713/034109.738616:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[50881:50881:0713/034109.752039:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://dcg.lenovo.com.cn/
[50881:50881:0713/034109.943085:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[50881:50881:0713/034109.950061:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[50881:50881:0713/034109.962478:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://dcg.lenovo.com.cn/
[50881:50881:0713/034110.062426:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[50881:50881:0713/034110.288881:INFO:CONSOLE(2529)] "1", source: https://dcg.lenovo.com.cn/productlist/807.html (2529)
[50881:50881:0713/034110.292844:INFO:CONSOLE(2530)] "2", source: https://dcg.lenovo.com.cn/productlist/807.html (2530)
[50881:50881:0713/034110.296510:INFO:CONSOLE(2538)] "cmsData", source: https://dcg.lenovo.com.cn/productlist/807.html (2538)
[50881:50881:0713/034110.300175:INFO:CONSOLE(2539)] "componentUuid", source: https://dcg.lenovo.com.cn/productlist/807.html (2539)
[50881:50881:0713/034110.304145:INFO:CONSOLE(2540)] "crumbs", source: https://dcg.lenovo.com.cn/productlist/807.html (2540)
[50881:50881:0713/034110.307831:INFO:CONSOLE(2541)] "curmbsData", source: https://dcg.lenovo.com.cn/productlist/807.html (2541)
[50881:50881:0713/034110.311490:INFO:CONSOLE(2542)] "https://admin.lenovo.com.cn/investor/solutioncategory/getCategorySeo?pageId=28917355-9f68-481b-a49b-507f5ca93821", source: https://dcg.lenovo.com.cn/productlist/807.html (2542)
[3:3:0713/034110.373601:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[50881:50881:0713/034110.554004:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034110.557428:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50881:0713/034110.584254:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://reg.lenovo.com.cn/
[50881:50881:0713/034110.584347:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://reg.lenovo.com.cn/, https://reg.lenovo.com.cn/auth/anonymous, 5
[50881:50881:0713/034110.584474:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://reg.lenovo.com.cn/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 10:41:10 GMT Server: waf/2.15.0-21.el6 Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked P3P: CP="NON DSP COR CURa ADMa DEVa TAIa PSAa PSDa IVAa IVDa CONa HISa TELa OTPa OUR UNRa IND UNI COM NAV INT DEM CNT PRE LOC" Pragma: No-cache Cache-Control: no-cache Expires: Thu, 01 Jan 1970 00:00:00 GMT Set-Cookie: leid=1.LNkWeTjs16U; Domain=lenovo.com.cn; Expires=Wed, 28-Jun-2079 10:41:10 GMT; Path=/ Content-Language: en-US Access-Control-Allow-Origin: * Access-Control-Allow-Headers: X-Requested-With Access-Control-Allow-Methods: GET,POST,OPTIONS Set-Cookie: JSESSIONID=D81CE0208A2BA3419AFF3BE32763D47C; Path=/; Secure; HttpOnly Content-Encoding: gzip X-Via: 1.1 zhwt83:3 (Cdn Cache Server V2.0), 1.1 bj170:4 (Cdn Cache Server V2.0) Connection: keep-alive  ,50978, 5
[50881:50892:0713/034110.584997:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[50881:50892:0713/034110.585078:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/034110.586212:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
		remove user.11_c3ef53fc -> 0
		remove user.12_c5c5493d -> 0
		remove user.13_c5394b9f -> 0
[1:1:0713/034110.701815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 30000
[1:1:0713/034110.702339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://dcg.lenovo.com.cn/, 1273
[1:1:0713/034110.702565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1273 0x7f263dde5070 0x24275619a360 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1142 0x7f263fd0d2e0 0x2427561e39e0 
[1:1:0713/034110.756567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1143 0x7f263fd0d2e0 0x242756380d60 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034110.757438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , 
[1:1:0713/034110.757656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034110.758222:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034110.932194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1149 0x7f263fd0d2e0 0x2427560b40e0 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034110.936155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , 

$(function () {

    try {
        if ($(".tabswitch-customer").length > 0) {
            $(
[1:1:0713/034110.936389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034111.054531:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dcg.lenovo.com.cn/productlist/807.html"
[50881:50881:0713/034111.225057:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034111.228513:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50892:0713/034111.279694:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[50881:50892:0713/034111.279793:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[50881:50881:0713/034111.279963:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://6895322.fls.doubleclick.net/
[50881:50881:0713/034111.280060:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://6895322.fls.doubleclick.net/, https://6895322.fls.doubleclick.net/activityi;dc_pre=CMbxitLaseMCFUfRlgodVsAE5A;src=6895322;type=1124v0;cat=01-pc0;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1;num=6320993590982.96?, 4
[50881:50881:0713/034111.280199:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://6895322.fls.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* date:Sat, 13 Jul 2019 10:41:10 GMT expires:Sat, 13 Jul 2019 10:41:10 GMT cache-control:private, max-age=0 content-type:text/html; charset=UTF-8 x-content-type-options:nosniff content-encoding:gzip server:cafe content-length:177 x-xss-protection:0 alt-svc:quic=":443"; ma=2592000; v="46,43,39"  ,50978, 5
[1:7:0713/034111.309945:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/034112.079855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/034112.080145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034115.834830:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://reg.lenovo.com.cn/
[1:1:0713/034117.291082:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://6895322.fls.doubleclick.net/
[1:1:0713/034117.571100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1298 0x7f263fd0d2e0 0x242756193ce0 , "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034117.587972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , !function(t,e){function i(t){return function(e){return{}.toString.call(e)=="[object "+t+"]"}}functio
[1:1:0713/034117.588246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034122.471127:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.471395:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 0
[1:1:0713/034122.471897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1388
[1:1:0713/034122.472090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1388 0x7f263dde5070 0x242758bfd660 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034122.675050:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.675334:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 300
[1:1:0713/034122.675759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1402
[1:1:0713/034122.676004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1402 0x7f263dde5070 0x242758f40360 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[50881:50881:0713/034122.727662:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034122.729338:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x242756d7ca20
[1:1:0713/034122.729599:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[50881:50881:0713/034122.737296:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: __post_iframe1, 6, 6, 
[50881:50881:0713/034122.771897:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn/, 6
[50881:50881:0713/034122.772047:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn
[1:1:0713/034122.806268:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.806530:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 1000
[1:1:0713/034122.806958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1421
[1:1:0713/034122.807184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1421 0x7f263dde5070 0x2427579ed6e0 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034122.818571:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 7000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.818865:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 7000
[1:1:0713/034122.819286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1423
[1:1:0713/034122.819513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1423 0x7f263dde5070 0x2427579eda60 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034122.830800:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 7000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.831101:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 7000
[1:1:0713/034122.831552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1424
[1:1:0713/034122.831799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1424 0x7f263dde5070 0x2427579e0360 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034122.837121:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.837315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 1000
[1:1:0713/034122.837693:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1426
[1:1:0713/034122.837906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1426 0x7f263dde5070 0x2427579bff60 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[50881:50881:0713/034122.888682:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034122.890555:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x242756d7c020
[1:1:0713/034122.890760:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[50881:50881:0713/034122.895340:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: __post_iframe2, 7, 7, 
[50881:50881:0713/034122.948667:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn/, 7
[50881:50881:0713/034122.948812:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn
[1:1:0713/034122.972220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.972473:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 1000
[1:1:0713/034122.972899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1448
[1:1:0713/034122.973127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1448 0x7f263dde5070 0x2427563526e0 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034122.978090:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 7000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.978323:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 7000
[1:1:0713/034122.978734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1449
[1:1:0713/034122.978976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1449 0x7f263dde5070 0x2427579af0e0 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034122.987630:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 7000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.987852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 7000
[1:1:0713/034122.988268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1451
[1:1:0713/034122.988495:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1451 0x7f263dde5070 0x242757a18660 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034122.993426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x26a827d429c8, 0x24275582d148
[1:1:0713/034122.993633:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 1000
[1:1:0713/034122.994067:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1452
[1:1:0713/034122.994326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1452 0x7f263dde5070 0x242757a13ce0 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1298 0x7f263fd0d2e0 0x242756193ce0 
[1:1:0713/034123.014277:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dcg.lenovo.com.cn/productlist/807.html"
[50881:50881:0713/034123.195080:INFO:CONSOLE(0)] "Refused to execute script from 'https://passport.lenovo.com/wauthen2/synCookie.jhtml?lenovoid_realm=shop.lenovo.com.cn&_=1563014468663' because its MIME type ('') is not executable, and strict MIME type checking is enabled.", source: https://dcg.lenovo.com.cn/productlist/807.html (0)
[1:1:0713/034123.474631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , document.readyState
[1:1:0713/034123.474876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[50881:50881:0713/034124.193811:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://reg.lenovo.com.cn/, https://reg.lenovo.com.cn/, 5
[50881:50881:0713/034124.193943:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://reg.lenovo.com.cn/, https://reg.lenovo.com.cn
[1:1:0713/034124.194767:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/034124.366457:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034124.367238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , b.onload, (){b.onload=null;mb=1}
[1:1:0713/034124.367471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034124.461718:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[50881:50881:0713/034124.474040:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://6895322.fls.doubleclick.net/, https://6895322.fls.doubleclick.net/, 4
[50881:50881:0713/034124.474143:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://6895322.fls.doubleclick.net/, https://6895322.fls.doubleclick.net
[1:1:0713/034126.336072:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034126.336360:INFO:render_frame_impl.cc(7019)] 	 [url] = https://dcg.lenovo.com.cn
[50881:50881:0713/034126.338639:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://dcg.lenovo.com.cn/
[50881:50881:0713/034126.467511:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034126.474555:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50892:0713/034126.511797:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[50881:50881:0713/034126.511831:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://admin.qidian.qq.com/
[50881:50892:0713/034126.511931:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[50881:50881:0713/034126.511948:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://admin.qidian.qq.com/, https://admin.qidian.qq.com/ar/ActCap/ActRpt, 6
[50881:50881:0713/034126.512089:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://admin.qidian.qq.com/, HTTP/1.1 200 status:200 date:Sat, 13 Jul 2019 10:41:25 GMT content-type:text/html; content-length:0 server:openresty/1.13.6.1 cache-control:no-cache access-control-allow-origin:* access-control-allow-headers:X-Requested-With access-control-allow-methods:GET,POST,OPTIONS  ,50978, 5
[1:7:0713/034126.518175:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/034127.410896:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034127.411191:INFO:render_frame_impl.cc(7019)] 	 [url] = https://dcg.lenovo.com.cn
[50881:50881:0713/034127.412769:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://dcg.lenovo.com.cn/
[50881:50881:0713/034127.528283:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034127.529645:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50892:0713/034127.569490:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[50881:50892:0713/034127.569593:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[50881:50881:0713/034127.569739:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://admin.qidian.qq.com/
[50881:50881:0713/034127.569818:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://admin.qidian.qq.com/, https://admin.qidian.qq.com/ar/ActCap/ActRpt, 7
[50881:50881:0713/034127.569974:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_https://admin.qidian.qq.com/, HTTP/1.1 200 status:200 date:Sat, 13 Jul 2019 10:41:27 GMT content-type:text/html; content-length:0 server:openresty/1.13.6.1 cache-control:no-cache access-control-allow-origin:* access-control-allow-headers:X-Requested-With access-control-allow-methods:GET,POST,OPTIONS  ,50978, 5
[1:7:0713/034127.573759:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/034128.350329:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1388, 7f264072a881
[1:1:0713/034128.414834:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034128.415199:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034128.415646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034128.416264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (){((location.hash||"").match(/([#&])BJ_ERROR=([^&$]+)/)||[])[2]}
[1:1:0713/034128.416479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034128.419131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1402, 7f264072a881
[1:1:0713/034128.468149:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034128.468530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034128.468975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034128.469591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (){o({action:r,data:a({kfuin:e},s)})}
[1:1:0713/034128.469803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[50881:50881:0713/034128.476408:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034128.478563:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x242756c31020
[1:1:0713/034128.478792:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[50881:50881:0713/034128.483394:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: __post_iframe3, 8, 8, 
[50881:50881:0713/034128.517999:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn/, 8
[50881:50881:0713/034128.518141:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, https://dcg.lenovo.com.cn/, https://dcg.lenovo.com.cn
[1:1:0713/034128.542463:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x26a827d429c8, 0x24275582d150
[1:1:0713/034128.542758:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dcg.lenovo.com.cn/productlist/807.html", 1000
[1:1:0713/034128.543180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1613
[1:1:0713/034128.543417:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1613 0x7f263dde5070 0x24275771ec60 , 5:3_https://dcg.lenovo.com.cn/, 1, -5:3_https://dcg.lenovo.com.cn/, 1402 0x7f263dde5070 0x242758f40360 
[1:1:0713/034129.233197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , document.readyState
[1:1:0713/034129.233528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034131.302152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1421, 7f264072a881
[1:1:0713/034131.378356:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034131.378711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034131.379155:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034131.379770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (){var t=l.shift(),e=s.shift();try{t&&document.body.removeChild(t),e&&document.body.removeChild(e)}c
[1:1:0713/034131.380016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[1:1:0713/034131.387159:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://dcg.lenovo.com.cn/, 1426, 7f264072a881
[1:1:0713/034131.462013:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b9b8d482860","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034131.462233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://dcg.lenovo.com.cn/","ptid":"1298 0x7f263fd0d2e0 0x242756193ce0 ","rf":"5:3_https://dcg.lenovo.com.cn/"}
[1:1:0713/034131.462451:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dcg.lenovo.com.cn/productlist/807.html"
[1:1:0713/034131.462776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://dcg.lenovo.com.cn/, 1b9b8d482860, , , (){l("[getScaleInfo]setTimeout executed"),g(d)}
[1:1:0713/034131.462895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dcg.lenovo.com.cn/productlist/807.html", "dcg.lenovo.com.cn", 3, 1, , , 0
[50881:50881:0713/034131.471616:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034131.473933:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x242756d7ca20
[1:1:0713/034131.474495:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[50881:50881:0713/034131.480140:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[1:1:0713/034131.503196:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034131.503479:INFO:render_frame_impl.cc(7019)] 	 [url] = https://dcg.lenovo.com.cn
[50881:50881:0713/034131.505124:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://dcg.lenovo.com.cn/
[50881:50881:0713/034131.525253:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/034131.525995:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x242756d7f220
[1:1:0713/034131.526356:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[50881:50881:0713/034131.532436:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[1:1:0713/034131.551427:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/034131.551686:INFO:render_frame_impl.cc(7019)] 	 [url] = https://dcg.lenovo.com.cn
[50881:50881:0713/034131.563499:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://dcg.lenovo.com.cn/
[50881:50881:0713/034131.624342:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034131.625935:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[50881:50892:0713/034131.665076:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[50881:50881:0713/034131.665113:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://webpage.qidian.qq.com/
[50881:50892:0713/034131.665151:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[50881:50881:0713/034131.665162:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://webpage.qidian.qq.com/, https://webpage.qidian.qq.com/2/chat/pc/index.html, 9
[50881:50881:0713/034131.665236:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_https://webpage.qidian.qq.com/, HTTP/1.1 200 status:200 server:NWSs date:Sat, 13 Jul 2019 10:41:31 GMT content-type:text/html content-length:1393 cache-control:max-age=600 expires:Sat, 13 Jul 2019 10:51:31 GMT last-modified:Sat, 13 Jul 2019 10:30:00 GMT content-encoding:gzip x-nws-log-uuid:080bae9b-6264-4c80-9bf8-fb6664167275 server_ip:124.193.228.206 x-cache-lookup:Hit From Disktank3 Gz  ,50978, 5
[50881:50881:0713/034131.665997:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[50881:50881:0713/034131.666550:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0713/034131.683698:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[50881:50892:0713/034131.691915:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 10
[50881:50892:0713/034131.692011:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 10, HandleIncomingMessage, HandleIncomingMessage
[50881:50881:0713/034131.692195:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://webpage.qidian.qq.com/
[50881:50881:0713/034131.692292:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_https://webpage.qidian.qq.com/, https://webpage.qidian.qq.com/2/chat/statusManager/index.html, 10
[50881:50881:0713/034131.692459:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:10_https://webpage.qidian.qq.com/, HTTP/1.1 200 status:200 server:NWSs date:Sat, 13 Jul 2019 10:41:31 GMT content-type:text/html content-length:753 cache-control:max-age=600 expires:Sat, 13 Jul 2019 10:51:31 GMT last-modified:Sat, 13 Jul 2019 10:30:00 GMT content-encoding:gzip x-nws-log-uuid:14c82ba7-fe49-472b-8bb6-94079d8d2c2d server_ip:124.193.228.206 x-cache-lookup:Hit From Disktank3 Gz  ,50978, 5
[1:7:0713/034131.697232:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
