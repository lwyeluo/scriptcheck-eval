[0711/201842.152934:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201842.153246:INFO:switcher_clone.cc(787)] backtrace rip is 7f758aa5d891
[0711/201843.078730:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201843.079011:INFO:switcher_clone.cc(787)] backtrace rip is 7f8b78e74891
[1:1:0711/201843.083087:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/201843.083280:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/201843.088040:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[9407:9407:0711/201844.185052:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c9ed62b9-505a-4ddc-828f-cab71a41fe82
[0711/201844.480162:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201844.480603:INFO:switcher_clone.cc(787)] backtrace rip is 7f4ab4d31891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[9440:9440:0711/201844.678261:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9440
[9452:9452:0711/201844.678744:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9452
[9407:9407:0711/201844.699603:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9407:9438:0711/201844.700582:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/201844.700813:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/201844.701054:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/201844.701772:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/201844.701973:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/201844.708247:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1e99936e, 1
[1:1:0711/201844.708914:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2eb3e929, 0
[1:1:0711/201844.709075:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x37394a12, 3
[1:1:0711/201844.709234:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2955be13, 2
[1:1:0711/201844.709418:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 29ffffffe9ffffffb32e 6effffff93ffffff991e 13ffffffbe5529 124a3937 , 10104, 4
[1:1:0711/201844.710624:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9407:9438:0711/201844.710890:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING)�.n���U)J97��
[9407:9438:0711/201844.710976:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is )�.n���U)J97x���
[9407:9438:0711/201844.711291:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/201844.711123:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8b770af0a0, 3
[9407:9438:0711/201844.711340:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9460, 4, 29e9b32e 6e93991e 13be5529 124a3937 
[1:1:0711/201844.711393:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8b7723a080, 2
[1:1:0711/201844.711559:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8b60efdd20, -2
[1:1:0711/201844.730401:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/201844.731405:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2955be13
[1:1:0711/201844.732608:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2955be13
[1:1:0711/201844.734507:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2955be13
[1:1:0711/201844.736323:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.736590:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.736819:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.737034:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.737844:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2955be13
[1:1:0711/201844.738231:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8b78e747ba
[1:1:0711/201844.738390:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8b78e6bdef, 7f8b78e7477a, 7f8b78e760cf
[1:1:0711/201844.745334:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2955be13
[1:1:0711/201844.745762:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2955be13
[1:1:0711/201844.746650:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2955be13
[1:1:0711/201844.749166:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.749411:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.749653:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.749872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2955be13
[1:1:0711/201844.751400:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2955be13
[1:1:0711/201844.751856:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8b78e747ba
[1:1:0711/201844.752033:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8b78e6bdef, 7f8b78e7477a, 7f8b78e760cf
[1:1:0711/201844.761617:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/201844.762149:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/201844.762323:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffed4ee5528, 0x7ffed4ee54a8)
[1:1:0711/201844.772637:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/201844.775586:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9407:9430:0711/201845.339496:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[9407:9407:0711/201845.404062:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9407:9407:0711/201845.404862:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9407:9407:0711/201845.408211:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9407:9407:0711/201845.408253:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9407:9407:0711/201845.408311:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9460, 4
[9407:9419:0711/201845.408511:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9407:9419:0711/201845.408642:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/201845.410415:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/201845.423913:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2b205661b220
[1:1:0711/201845.424210:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/201845.910286:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[9407:9407:0711/201847.568552:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9407:9407:0711/201847.568667:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/201847.613008:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201847.616515:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/201848.727381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 388538a41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/201848.727565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201848.733158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 388538a41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/201848.733329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201848.757738:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201848.968664:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201848.968891:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201849.295722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201849.303691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 388538a41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/201849.303906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201849.355708:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201849.366840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 388538a41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/201849.367181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201849.381744:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[9407:9407:0711/201849.383702:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/201849.385250:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2b2056619e20
[1:1:0711/201849.385428:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9407:9407:0711/201849.390254:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9407:9407:0711/201849.422127:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9407:9407:0711/201849.422225:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/201849.439705:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201849.894296:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f8b62ad82e0 0x2b205651fce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201849.895024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 388538a41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/201849.895171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201849.895740:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9407:9407:0711/201849.959334:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/201849.961569:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2b205661a820
[1:1:0711/201849.961762:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9407:9407:0711/201849.965914:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/201849.979347:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/201849.979598:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9407:9407:0711/201849.984746:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9407:9407:0711/201849.998016:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9407:9407:0711/201849.999316:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9407:9419:0711/201850.006669:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9407:9419:0711/201850.006755:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9407:9407:0711/201850.007008:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9407:9407:0711/201850.007105:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9407:9407:0711/201850.007294:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9460, 4
[1:7:0711/201850.012209:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/201850.590341:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/201851.281073:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f8b62ad82e0 0x2b2056896d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201851.282102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 388538a41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/201851.282349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201851.283106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9407:9407:0711/201851.370084:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9407:9407:0711/201851.370183:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/201851.371961:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/201851.774281:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201852.546392:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201852.546760:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9407:9407:0711/201853.157306:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9407:9438:0711/201853.157823:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/201853.158056:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/201853.158349:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/201853.158863:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/201853.159087:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/201853.162642:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x71c043e, 1
[1:1:0711/201853.163276:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x21a8893, 0
[1:1:0711/201853.163628:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3a0c1a64, 3
[1:1:0711/201853.163930:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x255d7646, 2
[1:1:0711/201853.164178:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff93ffffff881a02 3e041c07 46765d25 641a0c3a , 10104, 5
[1:1:0711/201853.166275:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9407:9438:0711/201853.166643:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��>Fv]%d:��
[9407:9438:0711/201853.166751:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��>Fv]%d:���
[9407:9438:0711/201853.167074:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9505, 5, 93881a02 3e041c07 46765d25 641a0c3a 
[1:1:0711/201853.166925:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8b770af0a0, 3
[1:1:0711/201853.167745:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8b7723a080, 2
[1:1:0711/201853.168111:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8b60efdd20, -2
[1:1:0711/201853.198340:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/201853.198742:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 255d7646
[1:1:0711/201853.199137:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 255d7646
[1:1:0711/201853.199833:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 255d7646
[1:1:0711/201853.201387:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.201636:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.201863:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.202095:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.202836:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 255d7646
[1:1:0711/201853.203188:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8b78e747ba
[1:1:0711/201853.203380:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8b78e6bdef, 7f8b78e7477a, 7f8b78e760cf
[1:1:0711/201853.209502:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 255d7646
[1:1:0711/201853.209904:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 255d7646
[1:1:0711/201853.210759:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 255d7646
[1:1:0711/201853.212953:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.213221:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.213470:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.213731:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 255d7646
[1:1:0711/201853.215078:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 255d7646
[1:1:0711/201853.215486:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8b78e747ba
[1:1:0711/201853.215688:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8b78e6bdef, 7f8b78e7477a, 7f8b78e760cf
[1:1:0711/201853.224099:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/201853.224673:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/201853.224880:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffed4ee5528, 0x7ffed4ee54a8)
[1:1:0711/201853.243191:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/201853.247865:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/201853.345426:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201853.350050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 388538b70640, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/201853.350341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201853.358078:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201853.420883:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2b20565ee220
[1:1:0711/201853.421164:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9407:9407:0711/201853.593240:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9407:9407:0711/201853.600541:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9407:9419:0711/201853.635802:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[9407:9419:0711/201853.635907:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[9407:9407:0711/201853.636723:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://page.renren.com/
[9407:9407:0711/201853.636835:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://page.renren.com/, http://page.renren.com/register/regGuide/, 1
[9407:9407:0711/201853.637000:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://page.renren.com/, HTTP/1.1 200 OK Server: Tengine/2.0.2 Date: Fri, 12 Jul 2019 03:18:53 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Cache-Control: no-cache Pragma: no-cache Expires: Thu, 01 Jan 1970 00:00:00 GMT Set-Cookie: XNESSESSIONID=abcIakhUCGPEZ9MmnmKVw; domain=.renren.com; path=/ Content-Encoding: gzip  ,9505, 5
[1:7:0711/201853.640611:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/201853.717905:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://page.renren.com/
[9407:9407:0711/201853.852845:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://page.renren.com/, http://page.renren.com/, 1
[9407:9407:0711/201853.852972:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://page.renren.com/, http://page.renren.com
[1:1:0711/201853.878385:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/201853.946177:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201854.049048:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201854.049307:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://page.renren.com/register/regGuide/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/201854.751589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7f8b60bb0070 0x2b20567cbde0 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201854.753906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , 
if(typeof nx === 'undefined'){
var nx = {};
}
nx.log = {
startTime : + new Date()
};
nx.user = {
id
[1:1:0711/201854.754291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "page.renren.com", 3, 1, , , 0
[1:1:0711/201854.829212:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201854.973663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f8b60f18bd0 0x2b20567872d8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201854.979310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , /*
From fed-amd/src/amd.coffee
 */(function(){var Module,config,defaultDependencies,define,loader,ma
[1:1:0711/201854.979467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "page.renren.com", 3, 1, , , 0
[1:1:0711/201854.985041:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_fb9e6ed4 -> 0
[1:1:0711/201902.012878:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201902.013385:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201902.013774:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201902.014253:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201902.014653:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0711/201904.831677:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/201904.963700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b160
[1:1:0711/201904.963920:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201904.964337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 251
[1:1:0711/201904.964530:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 251 0x7f8b60bb0070 0x2b205631f960 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 209 0x7f8b60f18bd0 0x2b20567872d8 
[1:1:0711/201904.980470:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "page.renren.com", "renren.com"
[1:1:0711/201905.090392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f8b60f18bd0 0x2b20567872d8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201905.133223:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f8b60f18bd0 0x2b20567872d8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201905.172988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 1
[1:1:0711/201905.173275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 256
[1:1:0711/201905.173389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 256 0x7f8b60bb0070 0x2b205631fde0 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 209 0x7f8b60f18bd0 0x2b20567872d8 
[1:1:0711/201905.200272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f8b60f18bd0 0x2b20567872d8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201905.389824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f8b60f18bd0 0x2b20567872d8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201905.556009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/201905.556252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201906.128091:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 251, 7f8b634f5881
[1:1:0711/201906.140898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"209 0x7f8b60f18bd0 0x2b20567872d8 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201906.141228:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"209 0x7f8b60f18bd0 0x2b20567872d8 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201906.141623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201906.142221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){if(b)return;if(!/loaded|complete/.test(a.readyState)){setTimeout(arguments.callee,0);return}C()}
[1:1:0711/201906.142445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201906.143247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201906.143441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201906.143880:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 302
[1:1:0711/201906.144162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 302 0x7f8b60bb0070 0x2b20566c3d60 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 251 0x7f8b60bb0070 0x2b205631f960 
[1:1:0711/201906.145928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 256, 7f8b634f58db
[1:1:0711/201906.158632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"209 0x7f8b60f18bd0 0x2b20567872d8 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201906.158993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"209 0x7f8b60f18bd0 0x2b20567872d8 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201906.159464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 304
[1:1:0711/201906.159700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 304 0x7f8b60bb0070 0x2b20567179e0 , 5:3_http://page.renren.com/, 0, , 256 0x7f8b60bb0070 0x2b205631fde0 
[1:1:0711/201906.160057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201906.160653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){t("#nxHeader").length&&(clearInterval(i),"object"!=typeof e.fm&&e.initFrameSize())}
[1:1:0711/201906.160864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201906.283623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201906.311916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (function(){var parsed,separatorIndex,combinatorIndex,reversed,cache={},reverseCache={},reUnescape=/
[1:1:0711/201906.312196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[9407:9407:0711/201906.365574:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[9407:9407:0711/201907.219061:INFO:CONSOLE(5)] "find,Dom,,重复设置", source: http://s.xnimg.cn/a72842/n/core/base-all2.js (5)
[1:1:0711/201907.236706:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201907.237196:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201911.800521:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "renren.com", "renren.com"
[1:1:0711/201913.491647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.534789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.538866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.545680:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.558325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.563615:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.582225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.593483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.612295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201913.625332:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f8b60f18bd0 0x2b20569eaad8 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201914.086620:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.595943, 24, 0
[1:1:0711/201914.086888:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201914.149150:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "http://page.renren.com/register/regGuide/"
[1:1:0711/201914.151896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , shareDelegate, (e){var target=$(XN.event.element(e||window.event));if(!target)return false;if(!target.hasClassName(
[1:1:0711/201914.152167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201914.167604:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "http://page.renren.com/register/regGuide/"
[1:1:0711/201914.179510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201914.179769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201914.312421:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 302, 7f8b634f5881
[1:1:0711/201914.327580:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"251 0x7f8b60bb0070 0x2b205631f960 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201914.327903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"251 0x7f8b60bb0070 0x2b205631f960 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201914.328270:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201914.328894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){if(b)return;if(!/loaded|complete/.test(a.readyState)){setTimeout(arguments.callee,0);return}C()}
[1:1:0711/201914.329099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201914.329877:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201914.330066:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201914.330480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 360
[1:1:0711/201914.330705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 360 0x7f8b60bb0070 0x2b2058fc7760 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 302 0x7f8b60bb0070 0x2b20566c3d60 
[1:1:0711/201914.332550:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 304, 7f8b634f58db
[1:1:0711/201914.347487:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"256 0x7f8b60bb0070 0x2b205631fde0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201914.347756:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"256 0x7f8b60bb0070 0x2b205631fde0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201914.348189:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 362
[1:1:0711/201914.348414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 362 0x7f8b60bb0070 0x2b20569e7960 , 5:3_http://page.renren.com/, 0, , 304 0x7f8b60bb0070 0x2b20567179e0 
[1:1:0711/201914.348728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201914.349262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){t("#nxHeader").length&&(clearInterval(i),"object"!=typeof e.fm&&e.initFrameSize())}
[1:1:0711/201914.349481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201914.815255:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201914.815536:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://page.renren.com/register/regGuide/"
[1:1:0711/201914.834144:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.01845, 250, 1
[1:1:0711/201914.834404:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201914.935093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 360, 7f8b634f5881
[1:1:0711/201914.951572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"302 0x7f8b60bb0070 0x2b20566c3d60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201914.951937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"302 0x7f8b60bb0070 0x2b20566c3d60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201914.952368:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201914.953429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){if(b)return;if(!/loaded|complete/.test(a.readyState)){setTimeout(arguments.callee,0);return}C()}
[1:1:0711/201914.953655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201914.954345:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201914.954558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201914.954972:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 388
[1:1:0711/201914.955197:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7f8b60bb0070 0x2b2056786b60 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 360 0x7f8b60bb0070 0x2b2058fc7760 
[1:1:0711/201916.021424:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201916.021657:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://page.renren.com/register/regGuide/"
[1:1:0711/201916.022478:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 380 0x7f8b60bb0070 0x2b20584fbce0 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201916.023832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , 
XN.dom.ready(function()
{
var tv = new XN.ui.tabView(
{
activeClass : 'select',
event : 'mouseover'
[1:1:0711/201916.024048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201916.050742:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.028981, 130, 1
[1:1:0711/201916.051041:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201916.068392:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://page.renren.com/register/regGuide/"
[1:1:0711/201916.069167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , g.handle, (e){return typeof h===B||!!e&&h.event.triggered===e.type?undefined:h.event.dispatch.apply(l.elem,arg
[1:1:0711/201916.069385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201916.079183:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3f9ee81029c8, 0x2b205617b238
[1:1:0711/201916.079436:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 50
[1:1:0711/201916.079952:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 419
[1:1:0711/201916.080180:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 419 0x7f8b60bb0070 0x2b20591d9d60 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 381 0x7f8b6fec1960 0x2b205905d420 0x2b205905d430 
[1:1:0711/201916.561519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201916.561837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201916.661873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 388, 7f8b634f5881
[1:1:0711/201916.670741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"360 0x7f8b60bb0070 0x2b2058fc7760 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201916.671139:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"360 0x7f8b60bb0070 0x2b2058fc7760 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201916.671602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201916.672306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){if(b)return;if(!/loaded|complete/.test(a.readyState)){setTimeout(arguments.callee,0);return}C()}
[1:1:0711/201916.672517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201916.673331:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201916.673521:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201916.673987:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 454
[1:1:0711/201916.674218:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 454 0x7f8b60bb0070 0x2b2058ea5760 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 388 0x7f8b60bb0070 0x2b2056786b60 
[1:1:0711/201917.097794:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201917.098053:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.099000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f8b60bb0070 0x2b20584b23e0 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.100427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , 
function sendStats(url){var n="log_"+(new Date).getTime();var c=window[n]=new Image;c.onload=c.oner
[1:1:0711/201917.100614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[9407:9407:0711/201917.110395:INFO:CONSOLE(498)] "dj!!", source: http://page.renren.com/register/regGuide/ (498)
[1:1:0711/201917.115624:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.281148:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 5000
[1:1:0711/201917.281581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 481
[1:1:0711/201917.281785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7f8b60bb0070 0x2b20590b2ee0 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 416 0x7f8b60bb0070 0x2b20584b23e0 
[1:1:0711/201917.471735:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 3000
[1:1:0711/201917.472203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 482
[1:1:0711/201917.472397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7f8b60bb0070 0x2b20591d21e0 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 416 0x7f8b60bb0070 0x2b20584b23e0 
[1:1:0711/201917.516813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x3f9ee81029c8, 0x2b205617b228
[1:1:0711/201917.517062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 30000
[1:1:0711/201917.517437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 484
[1:1:0711/201917.517625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7f8b60bb0070 0x2b20591c6e60 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 416 0x7f8b60bb0070 0x2b20584b23e0 
		remove user.11_f3230658 -> 0
		remove user.12_220dd57c -> 0
[1:1:0711/201917.668682:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.674923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[9407:9407:0711/201917.786321:INFO:CONSOLE(10)] "The behavior that Selection.addRange() merges existing Range and the specified Range was removed. See https://www.chromestatus.com/features/6680566019653632 for more details.", source: http://s.xnimg.cn/a77347/nx/core/libs.js (10)
[1:1:0711/201917.808969:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.810208:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.811252:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.812538:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.853051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.865110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.870537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.881344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.884181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.886455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.888636:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.892997:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.895619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.900496:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.905681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.907053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[9407:9407:0711/201917.946756:INFO:CONSOLE(6)] "load file version:", source: http://s.xnimg.cn/a72842/n/core/base-all2.js (6)
[9407:9407:0711/201917.947442:INFO:CONSOLE(6)] "[object Object]", source: http://s.xnimg.cn/a72842/n/core/base-all2.js (6)
[1:1:0711/201917.949348:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201917.951112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://page.renren.com/register/regGuide/"
[1:1:0711/201918.682316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 419, 7f8b634f5881
[1:1:0711/201918.702386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"381 0x7f8b6fec1960 0x2b205905d420 0x2b205905d430 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201918.702766:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"381 0x7f8b6fec1960 0x2b205905d420 0x2b205905d430 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201918.703233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201918.703834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){e.type=t,a.handler.apply(o,f),e.type=n}
[1:1:0711/201918.704033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201918.804438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201918.804731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201919.407486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 454, 7f8b634f5881
[1:1:0711/201919.427573:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"388 0x7f8b60bb0070 0x2b2056786b60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201919.427917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"388 0x7f8b60bb0070 0x2b2056786b60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201919.428369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201919.428958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){if(b)return;if(!/loaded|complete/.test(a.readyState)){setTimeout(arguments.callee,0);return}C()}
[1:1:0711/201919.429211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/201920.159386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201920.159855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201920.657486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://page.renren.com/register/regGuide/"
[1:1:0711/201920.658534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , c.onload.c.onerror, (){window[n]=null}
[1:1:0711/201920.658782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201920.717561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 543 0x7f8b62ad82e0 0x2b2058fc5e60 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201920.719876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , /* From fed-core/dist/ui/scrollbar.js */define("ui/scrollbar",function(require){"use strict";var e=r
[1:1:0711/201920.720167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201920.723230:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201920.741268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544 0x7f8b62ad82e0 0x2b205993e2e0 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201920.743402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , define("ui/placeholder",function(require,e,t){var o=require("jquery"),s="placeholder"in document.cre
[1:1:0711/201920.743638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201920.746968:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201921.383653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547 0x7f8b62ad82e0 0x2b20566bf9e0 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201921.384643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , XN.photoSeedHandler({
    'exec': ['http://s.xnimg.cn/a34087/n/core/modules/flashUploader/flashUplo
[1:1:0711/201921.384868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201921.622222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201921.622540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201921.673345:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 482, 7f8b634f58db
[1:1:0711/201921.698905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"416 0x7f8b60bb0070 0x2b20584b23e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201921.699269:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"416 0x7f8b60bb0070 0x2b20584b23e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201921.699871:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 583
[1:1:0711/201921.700255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7f8b60bb0070 0x2b2059d212e0 , 5:3_http://page.renren.com/, 0, , 482 0x7f8b60bb0070 0x2b20591d21e0 
[1:1:0711/201921.700649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201921.701283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , autoplay, (){
_this.n = _this.n >= (_this.count - 1) ? 0 : ++_this.n;
$(_this.obj + " div a").eq(_this.n).trig
[1:1:0711/201921.701530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201921.779809:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201921.780140:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201921.780586:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 584
[1:1:0711/201921.780817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7f8b60bb0070 0x2b20599473e0 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 482 0x7f8b60bb0070 0x2b20591d21e0 
[1:1:0711/201921.902786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 13
[1:1:0711/201921.903267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 585
[1:1:0711/201921.903520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 585 0x7f8b60bb0070 0x2b2059d1dd60 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 482 0x7f8b60bb0070 0x2b20591d21e0 
[1:1:0711/201922.254773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201922.255081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201922.391318:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 584, 7f8b634f5881
[1:1:0711/201922.418664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"482 0x7f8b60bb0070 0x2b20591d21e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201922.419029:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"482 0x7f8b60bb0070 0x2b20591d21e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201922.419425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201922.420022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){Yt=undefined}
[1:1:0711/201922.420282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201922.421918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 585, 7f8b634f58db
[1:1:0711/201922.446474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"482 0x7f8b60bb0070 0x2b20591d21e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201922.446873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"482 0x7f8b60bb0070 0x2b20591d21e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201922.447457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 607
[1:1:0711/201922.447750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 607 0x7f8b60bb0070 0x2b2059b96ae0 , 5:3_http://page.renren.com/, 0, , 585 0x7f8b60bb0070 0x2b2059d1dd60 
[1:1:0711/201922.448145:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201922.448772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , h.fx.tick, (){var e,t=h.timers,n=0;Yt=h.now();for(;n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.leng
[1:1:0711/201922.448999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201922.580851:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 592 0x7f8b62ad82e0 0x2b205850efe0 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201922.584525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , define("ui/tooltip",function(require,exports,module){var $=require("jquery");require("ui/dialog");va
[1:1:0711/201922.584831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201922.588856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201922.650534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201922.650855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201922.654333:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 481, 7f8b634f58db
[1:1:0711/201922.681499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"416 0x7f8b60bb0070 0x2b20584b23e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201922.681933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"416 0x7f8b60bb0070 0x2b20584b23e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201922.682427:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 616
[1:1:0711/201922.682690:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f8b60bb0070 0x2b20598a9760 , 5:3_http://page.renren.com/, 0, , 481 0x7f8b60bb0070 0x2b20590b2ee0 
[1:1:0711/201922.682978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201922.683516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){
checkCount();
}
[1:1:0711/201922.683757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201922.710032:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[1:1:0711/201923.027527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201923.027887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201923.092487:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[1:1:0711/201923.093269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , onStateChange, (){var transport=this.transport;if(transport.readyState==1&&!this.hasRunStart){this.onStart();this.h
[1:1:0711/201923.093500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201923.094265:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[1:1:0711/201923.096771:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[1:1:0711/201923.303975:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 628 0x7f8b62ad82e0 0x2b20582d3560 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201923.308374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , /* From fed-core/dist/ui/dialog.js */define("ui/dialog",function(require,e,t){"use strict";var n=req
[1:1:0711/201923.308683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201923.314823:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201923.490137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201923.490423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201923.634525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 583, 7f8b634f58db
[1:1:0711/201923.663651:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"482 0x7f8b60bb0070 0x2b20591d21e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201923.664026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"482 0x7f8b60bb0070 0x2b20591d21e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201923.664465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 658
[1:1:0711/201923.664692:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7f8b60bb0070 0x2b2056788ce0 , 5:3_http://page.renren.com/, 0, , 583 0x7f8b60bb0070 0x2b2059d212e0 
[1:1:0711/201923.665043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201923.665639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , autoplay, (){
_this.n = _this.n >= (_this.count - 1) ? 0 : ++_this.n;
$(_this.obj + " div a").eq(_this.n).trig
[1:1:0711/201923.665938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201923.723280:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201923.723669:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201923.724230:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 659
[1:1:0711/201923.724498:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 659 0x7f8b60bb0070 0x2b2059f3aae0 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 583 0x7f8b60bb0070 0x2b2059d212e0 
[1:1:0711/201923.758770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 13
[1:1:0711/201923.759296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 661
[1:1:0711/201923.759546:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7f8b60bb0070 0x2b2059fda460 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 583 0x7f8b60bb0070 0x2b2059d212e0 
[1:1:0711/201923.988993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201923.989340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201924.111915:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 655 0x7f8b62ad82e0 0x2b2059b96d60 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201924.120711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , define("ui/draggable",["jquery","ui/sortable"],function($){$.widget("ui.draggable",$.ui.mouse,{versi
[1:1:0711/201924.120994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201924.122946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201924.309978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 659, 7f8b634f5881
[1:1:0711/201924.339543:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"583 0x7f8b60bb0070 0x2b2059d212e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201924.339947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"583 0x7f8b60bb0070 0x2b2059d212e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201924.340465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201924.341192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){Yt=undefined}
[1:1:0711/201924.341435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201924.343010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 661, 7f8b634f58db
[1:1:0711/201924.355669:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"583 0x7f8b60bb0070 0x2b2059d212e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201924.356050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"583 0x7f8b60bb0070 0x2b2059d212e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201924.356465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 682
[1:1:0711/201924.356696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7f8b60bb0070 0x2b20569e16e0 , 5:3_http://page.renren.com/, 0, , 661 0x7f8b60bb0070 0x2b2059fda460 
[1:1:0711/201924.357015:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201924.357573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , h.fx.tick, (){var e,t=h.timers,n=0;Yt=h.now();for(;n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.leng
[1:1:0711/201924.357776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201924.437831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201924.438135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201924.851647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201924.851989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201924.875029:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 687 0x7f8b62ad82e0 0x2b2059ec03e0 , "http://page.renren.com/register/regGuide/"
[1:1:0711/201924.885040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , define("ui/sortable",["jquery"],function($){return $.widget("ui.sortable",$.ui.mouse,{version:"@VERS
[1:1:0711/201924.885315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201924.887354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201925.704182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201925.704462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201925.737941:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201925.738757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , C, (){if(b)return;try{var e=a.getElementsByTagName("body")[0].appendChild(U("span"));e.parentNode.remov
[1:1:0711/201925.739090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201925.739655:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201925.740698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://page.renren.com/register/regGuide/"
[1:1:0711/201925.872900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , document.readyState
[1:1:0711/201925.873192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201926.512284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 658, 7f8b634f58db
[1:1:0711/201926.523688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"583 0x7f8b60bb0070 0x2b2059d212e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201926.524071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"583 0x7f8b60bb0070 0x2b2059d212e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201926.524493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 742
[1:1:0711/201926.524825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f8b60bb0070 0x2b205991cf60 , 5:3_http://page.renren.com/, 0, , 658 0x7f8b60bb0070 0x2b2056788ce0 
[1:1:0711/201926.525135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201926.525775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , autoplay, (){
_this.n = _this.n >= (_this.count - 1) ? 0 : ++_this.n;
$(_this.obj + " div a").eq(_this.n).trig
[1:1:0711/201926.525988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201926.585609:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201926.585875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201926.587088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 743
[1:1:0711/201926.587378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7f8b60bb0070 0x2b2059fd1c60 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 658 0x7f8b60bb0070 0x2b2056788ce0 
[1:1:0711/201926.624773:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 13
[1:1:0711/201926.625336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 745
[1:1:0711/201926.625565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f8b60bb0070 0x2b2059fda0e0 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 658 0x7f8b60bb0070 0x2b2056788ce0 
[1:1:0711/201926.786707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 743, 7f8b634f5881
[1:1:0711/201926.798404:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"658 0x7f8b60bb0070 0x2b2056788ce0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201926.798575:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"658 0x7f8b60bb0070 0x2b2056788ce0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201926.798783:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201926.799094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){Yt=undefined}
[1:1:0711/201926.799246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201926.812784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 745, 7f8b634f58db
[1:1:0711/201926.843112:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"658 0x7f8b60bb0070 0x2b2056788ce0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201926.843464:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"658 0x7f8b60bb0070 0x2b2056788ce0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201926.843891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 758
[1:1:0711/201926.844086:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 758 0x7f8b60bb0070 0x2b2056677260 , 5:3_http://page.renren.com/, 0, , 745 0x7f8b60bb0070 0x2b2059fda0e0 
[1:1:0711/201926.844396:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201926.844953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , h.fx.tick, (){var e,t=h.timers,n=0;Yt=h.now();for(;n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.leng
[1:1:0711/201926.845126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201927.126508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 758, 7f8b634f58db
[1:1:0711/201927.164652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"745 0x7f8b60bb0070 0x2b2059fda0e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201927.164997:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"745 0x7f8b60bb0070 0x2b2059fda0e0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201927.165503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 764
[1:1:0711/201927.165736:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7f8b60bb0070 0x2b2059f38d60 , 5:3_http://page.renren.com/, 0, , 758 0x7f8b60bb0070 0x2b2056677260 
[1:1:0711/201927.166060:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201927.166765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , h.fx.tick, (){var e,t=h.timers,n=0;Yt=h.now();for(;n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.leng
[1:1:0711/201927.167009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201927.320000:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 616, 7f8b634f58db
[1:1:0711/201927.332844:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"481 0x7f8b60bb0070 0x2b20590b2ee0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201927.333112:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"481 0x7f8b60bb0070 0x2b20590b2ee0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201927.333515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 779
[1:1:0711/201927.333721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 779 0x7f8b60bb0070 0x2b2059d1d0e0 , 5:3_http://page.renren.com/, 0, , 616 0x7f8b60bb0070 0x2b20598a9760 
[1:1:0711/201927.333971:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201927.334511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){
checkCount();
}
[1:1:0711/201927.334685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201927.363140:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[1:1:0711/201927.733723:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[1:1:0711/201927.734473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , onStateChange, (){var transport=this.transport;if(transport.readyState==1&&!this.hasRunStart){this.onStart();this.h
[1:1:0711/201927.734653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201927.735152:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[1:1:0711/201927.737354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://page.renren.com/register/regGuide/"
[9407:9407:0711/201928.353423:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/201929.507235:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 742, 7f8b634f58db
[1:1:0711/201929.518770:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"658 0x7f8b60bb0070 0x2b2056788ce0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201929.518968:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"658 0x7f8b60bb0070 0x2b2056788ce0 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201929.519187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 798
[1:1:0711/201929.519295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7f8b60bb0070 0x2b2059ed42e0 , 5:3_http://page.renren.com/, 0, , 742 0x7f8b60bb0070 0x2b205991cf60 
[1:1:0711/201929.519441:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201929.519763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , autoplay, (){
_this.n = _this.n >= (_this.count - 1) ? 0 : ++_this.n;
$(_this.obj + " div a").eq(_this.n).trig
[1:1:0711/201929.519872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201929.568393:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f9ee81029c8, 0x2b205617b150
[1:1:0711/201929.568672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 0
[1:1:0711/201929.569062:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 799
[1:1:0711/201929.569250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7f8b60bb0070 0x2b205a1465e0 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 742 0x7f8b60bb0070 0x2b205991cf60 
[1:1:0711/201929.597370:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://page.renren.com/register/regGuide/", 13
[1:1:0711/201929.597830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 800
[1:1:0711/201929.598027:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7f8b60bb0070 0x2b205994c960 , 5:3_http://page.renren.com/, 1, -5:3_http://page.renren.com/, 742 0x7f8b60bb0070 0x2b205991cf60 
[1:1:0711/201929.951039:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://page.renren.com/, 799, 7f8b634f5881
[1:1:0711/201929.983456:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"742 0x7f8b60bb0070 0x2b205991cf60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201929.983805:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"742 0x7f8b60bb0070 0x2b205991cf60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201929.984160:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201929.984733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , , (){Yt=undefined}
[1:1:0711/201929.984911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
[1:1:0711/201930.019692:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 800, 7f8b634f58db
[1:1:0711/201930.055669:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16ecbfee2860","ptid":"742 0x7f8b60bb0070 0x2b205991cf60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201930.056090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://page.renren.com/","ptid":"742 0x7f8b60bb0070 0x2b205991cf60 ","rf":"5:3_http://page.renren.com/"}
[1:1:0711/201930.056642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://page.renren.com/, 809
[1:1:0711/201930.056897:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f8b60bb0070 0x2b2059b967e0 , 5:3_http://page.renren.com/, 0, , 800 0x7f8b60bb0070 0x2b205994c960 
[1:1:0711/201930.057070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://page.renren.com/register/regGuide/"
[1:1:0711/201930.057375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://page.renren.com/, 16ecbfee2860, , h.fx.tick, (){var e,t=h.timers,n=0;Yt=h.now();for(;n<t.length;n++)e=t[n],!e()&&t[n]===e&&t.splice(n--,1);t.leng
[1:1:0711/201930.057482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://page.renren.com/register/regGuide/", "renren.com", 3, 1, , , 0
