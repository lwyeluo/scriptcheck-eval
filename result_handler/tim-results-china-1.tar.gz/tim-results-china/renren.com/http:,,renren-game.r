[0711/201746.205622:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201746.206042:INFO:switcher_clone.cc(787)] backtrace rip is 7ff0389b9891
[0711/201747.099234:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201747.099608:INFO:switcher_clone.cc(787)] backtrace rip is 7f36d7fdc891
[1:1:0711/201747.111417:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/201747.111662:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/201747.116762:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[9150:9150:0711/201748.254671:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/84e956fd-92ce-48f9-81ff-61d40da60846
[0711/201748.480425:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201748.480911:INFO:switcher_clone.cc(787)] backtrace rip is 7f3efe29a891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[9182:9182:0711/201748.727279:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9182
[9193:9193:0711/201748.727693:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9193
[9150:9150:0711/201748.841458:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9150:9179:0711/201748.841978:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/201748.842174:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/201748.842423:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/201748.843016:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/201748.843202:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/201748.846104:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x123363a0, 1
[1:1:0711/201748.846459:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3ec5507, 0
[1:1:0711/201748.846668:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2c0e6313, 3
[1:1:0711/201748.846964:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e731e79, 2
[1:1:0711/201748.847245:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 0755ffffffec03 ffffffa0633312 791e731e 13630e2c , 10104, 4
[1:1:0711/201748.848291:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9150:9179:0711/201748.848536:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGU��c3ysc,�B�
[9150:9179:0711/201748.848606:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is U��c3ysc,�!�B�
[1:1:0711/201748.848735:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f36d62170a0, 3
[9150:9179:0711/201748.848902:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[9150:9179:0711/201748.848972:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9201, 4, 0755ec03 a0633312 791e731e 13630e2c 
[1:1:0711/201748.848920:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f36d63a2080, 2
[1:1:0711/201748.849129:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f36c0065d20, -2
[1:1:0711/201748.867982:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/201748.868901:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e731e79
[1:1:0711/201748.869879:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e731e79
[1:1:0711/201748.871486:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e731e79
[1:1:0711/201748.873021:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.873251:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.873432:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.873605:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.874279:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e731e79
[1:1:0711/201748.874610:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f36d7fdc7ba
[1:1:0711/201748.874744:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f36d7fd3def, 7f36d7fdc77a, 7f36d7fde0cf
[1:1:0711/201748.880504:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e731e79
[1:1:0711/201748.880874:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e731e79
[1:1:0711/201748.881612:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e731e79
[1:1:0711/201748.883643:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.883834:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.884018:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.884253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e731e79
[1:1:0711/201748.885485:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e731e79
[1:1:0711/201748.885837:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f36d7fdc7ba
[1:1:0711/201748.885966:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f36d7fd3def, 7f36d7fdc77a, 7f36d7fde0cf
[1:1:0711/201748.894985:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/201748.895606:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/201748.895785:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe28f27668, 0x7ffe28f275e8)
[1:1:0711/201748.916087:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/201748.923291:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9150:9150:0711/201749.515054:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9150:9150:0711/201749.516661:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9150:9160:0711/201749.529603:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9150:9160:0711/201749.529706:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[9150:9150:0711/201749.529976:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9150:9150:0711/201749.530174:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9150:9150:0711/201749.530365:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9201, 4
[1:7:0711/201749.540077:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9150:9171:0711/201749.574742:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/201749.687361:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1032491a220
[1:1:0711/201749.687643:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/201750.084276:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[9150:9150:0711/201751.641663:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9150:9150:0711/201751.641812:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/201751.649931:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201751.652811:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/201752.681957:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201752.757633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 05855b621f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/201752.757883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201752.775788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 05855b621f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/201752.775968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201753.002702:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201753.002909:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201753.490926:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201753.498904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 05855b621f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/201753.499109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201753.534268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201753.541701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 05855b621f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/201753.541848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201753.545742:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/201753.550226:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x10324918e20
[1:1:0711/201753.550398:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9150:9150:0711/201753.558934:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9150:9150:0711/201753.572146:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9150:9150:0711/201753.611379:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9150:9150:0711/201753.611613:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/201753.616380:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201754.573254:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 431 0x7f36c1c402e0 0x103244c7fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201754.575702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 05855b621f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/201754.576155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201754.579162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9150:9150:0711/201754.661274:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/201754.661789:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x10324919820
[1:1:0711/201754.662862:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9150:9150:0711/201754.672207:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/201754.681329:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/201754.681547:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9150:9150:0711/201754.688733:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9150:9150:0711/201754.695460:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9150:9150:0711/201754.696532:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9150:9160:0711/201754.702740:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9150:9160:0711/201754.702843:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9150:9150:0711/201754.703012:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9150:9150:0711/201754.703090:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9150:9150:0711/201754.703228:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9201, 4
[1:7:0711/201754.706121:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/201755.408768:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/201755.707676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7f36c1c402e0 0x10324c731e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201755.708710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 05855b621f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/201755.708957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201755.709712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201755.922981:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9150:9150:0711/201755.924111:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9150:9150:0711/201755.924256:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[9150:9150:0711/201756.278731:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9150:9179:0711/201756.279186:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/201756.279371:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/201756.279609:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/201756.280031:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/201756.280202:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/201756.283305:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x23780067, 1
[1:1:0711/201756.283647:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x35fb244e, 0
[1:1:0711/201756.283844:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3598d5e7, 3
[1:1:0711/201756.284041:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x7567451, 2
[1:1:0711/201756.284217:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4e24fffffffb35 67007823 51745607 ffffffe7ffffffd5ffffff9835 , 10104, 5
[1:1:0711/201756.285229:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9150:9179:0711/201756.285474:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGN$�5g
[9150:9179:0711/201756.285544:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is N$�5g
[9150:9179:0711/201756.285875:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9249, 5, 4e24fb35 67007823 51745607 e7d59835 
[1:1:0711/201756.285682:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f36d62170a0, 3
[1:1:0711/201756.286309:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f36d63a2080, 2
[1:1:0711/201756.286534:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f36c0065d20, -2
[1:1:0711/201756.308162:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/201756.308512:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7567451
[1:1:0711/201756.308897:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7567451
[1:1:0711/201756.309558:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7567451
[1:1:0711/201756.311055:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.311280:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.311495:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.311709:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.312457:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7567451
[1:1:0711/201756.312790:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f36d7fdc7ba
[1:1:0711/201756.312964:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f36d7fd3def, 7f36d7fdc77a, 7f36d7fde0cf
[1:1:0711/201756.319641:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7567451
[1:1:0711/201756.320136:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7567451
[1:1:0711/201756.320901:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7567451
[1:1:0711/201756.322134:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.322402:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.322629:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.322861:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7567451
[1:1:0711/201756.324195:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7567451
[1:1:0711/201756.324596:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f36d7fdc7ba
[1:1:0711/201756.324785:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f36d7fd3def, 7f36d7fdc77a, 7f36d7fde0cf
[1:1:0711/201756.332831:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/201756.333463:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/201756.333667:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe28f27668, 0x7ffe28f275e8)
[1:1:0711/201756.347080:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/201756.351333:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/201756.371365:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201756.577797:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x103248c6220
[1:1:0711/201756.578045:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/201757.032876:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201757.033163:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9150:9150:0711/201757.126703:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9150:9150:0711/201757.131445:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9150:9160:0711/201757.165123:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[9150:9160:0711/201757.165305:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[9150:9150:0711/201757.165572:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://renren-game.renren.com/
[9150:9150:0711/201757.165663:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://renren-game.renren.com/, http://renren-game.renren.com/, 1
[9150:9150:0711/201757.165823:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://renren-game.renren.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 03:17:09 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=ogsd0jdjl8f9e7ljmo55ppphc7; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Content-Encoding: gzip  ,9249, 5
[1:7:0711/201757.168471:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/201757.201958:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://renren-game.renren.com/
[9150:9150:0711/201757.359633:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://renren-game.renren.com/, http://renren-game.renren.com/, 1
[9150:9150:0711/201757.359759:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://renren-game.renren.com/, http://renren-game.renren.com
[1:1:0711/201757.414945:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/201757.499169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201757.504365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 05855b7509f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/201757.504744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201757.514361:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201757.587755:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201757.622734:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201757.622991:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://renren-game.renren.com/"
[1:1:0711/201757.939099:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/201758.493422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7f36c0080bd0 0x1032496ced8 , "http://renren-game.renren.com/"
[1:1:0711/201758.503701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , /*! jQuery v1.11.0 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0711/201758.504050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201758.532604:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201758.724565:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7f36c0080bd0 0x1032496ced8 , "http://renren-game.renren.com/"
[1:1:0711/201758.766640:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7f36c0080bd0 0x1032496ced8 , "http://renren-game.renren.com/"
[1:1:0711/201758.783765:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7f36c0080bd0 0x1032496ced8 , "http://renren-game.renren.com/"
[1:1:0711/201758.887722:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201758.888003:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201758.890208:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201758.890449:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201758.890804:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201759.501176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f36c0080bd0 0x10324aab6d8 , "http://renren-game.renren.com/"
[1:1:0711/201759.511683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f36c0080bd0 0x10324aab6d8 , "http://renren-game.renren.com/"
[1:1:0711/201759.516377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , /*! jQuery Migrate v1.2.1 | (c) 2005, 2013 jQuery Foundation, Inc. and other contributors | jquery.o
[1:1:0711/201759.516754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201759.538785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f36c0080bd0 0x10324aab6d8 , "http://renren-game.renren.com/"
[1:1:0711/201759.560244:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.051899, 96, 1
[1:1:0711/201759.560571:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201759.840456:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201759.840708:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://renren-game.renren.com/"
[1:1:0711/201759.841550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f36bfd18070 0x10324934760 , "http://renren-game.renren.com/"
[1:1:0711/201759.842552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , 
    function Doexit()
    {
        $.ajax({
            url: "/logout.html",
            type: 'PO
[1:1:0711/201759.842769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201759.882378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://renren-game.renren.com/"
[1:1:0711/201801.118350:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 3000
[1:1:0711/201801.118856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 260
[1:1:0711/201801.119112:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 260 0x7f36bfd18070 0x103249e4860 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 242 0x7f36bfd18070 0x10324934760 
[1:1:0711/201801.238008:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 3000
[1:1:0711/201801.238481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 263
[1:1:0711/201801.238757:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 263 0x7f36bfd18070 0x10324dbdbe0 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 242 0x7f36bfd18070 0x10324934760 
[1:1:0711/201804.248596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 260, 7f36c265d8db
[1:1:0711/201804.256189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"242 0x7f36bfd18070 0x10324934760 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.256501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"242 0x7f36bfd18070 0x10324934760 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.256857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 470
[1:1:0711/201804.257107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7f36bfd18070 0x10324dd94e0 , 5:3_http://renren-game.renren.com/, 0, , 260 0x7f36bfd18070 0x103249e4860 
[1:1:0711/201804.257419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201804.257985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , carousel, () {
            i++;
            if (i > page) {
                i = 1
            }
         
[1:1:0711/201804.258243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201804.349547:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd49895629c8, 0x1032442e150
[1:1:0711/201804.349807:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 0
[1:1:0711/201804.350259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 473
[1:1:0711/201804.350493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 473 0x7f36bfd18070 0x103254c6ce0 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 260 0x7f36bfd18070 0x103249e4860 
[1:1:0711/201804.383021:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 13
[1:1:0711/201804.383503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 476
[1:1:0711/201804.383751:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 476 0x7f36bfd18070 0x10324aafae0 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 260 0x7f36bfd18070 0x103249e4860 
[1:1:0711/201804.558364:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 263, 7f36c265d8db
[1:1:0711/201804.568786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"242 0x7f36bfd18070 0x10324934760 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.569089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"242 0x7f36bfd18070 0x10324934760 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.569466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 484
[1:1:0711/201804.569692:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7f36bfd18070 0x10324aac8e0 , 5:3_http://renren-game.renren.com/, 0, , 263 0x7f36bfd18070 0x10324dbdbe0 
[1:1:0711/201804.569989:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201804.570731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , carousel, () {
            i++;
            if (i > page) {
                i = 1
            }
         
[1:1:0711/201804.570974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201804.855930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 473, 7f36c265d881
[1:1:0711/201804.867566:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"260 0x7f36bfd18070 0x103249e4860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.867891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"260 0x7f36bfd18070 0x103249e4860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.868235:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201804.868787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , (){_b=void 0}
[1:1:0711/201804.869021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201804.870638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 476, 7f36c265d8db
[1:1:0711/201804.898195:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"260 0x7f36bfd18070 0x103249e4860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.898544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"260 0x7f36bfd18070 0x103249e4860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201804.898906:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 495
[1:1:0711/201804.899132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7f36bfd18070 0x10324dc74e0 , 5:3_http://renren-game.renren.com/, 0, , 476 0x7f36bfd18070 0x10324aafae0 
[1:1:0711/201804.899474:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201804.900020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201804.900265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201805.227501:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 495, 7f36c265d8db
[1:1:0711/201805.250880:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"476 0x7f36bfd18070 0x10324aafae0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201805.251211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"476 0x7f36bfd18070 0x10324aafae0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201805.251585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 511
[1:1:0711/201805.251847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7f36bfd18070 0x103249e6860 , 5:3_http://renren-game.renren.com/, 0, , 495 0x7f36bfd18070 0x10324dc74e0 
[1:1:0711/201805.252156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201805.252722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201805.252932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.149568:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 470, 7f36c265d8db
[1:1:0711/201807.160731:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"260 0x7f36bfd18070 0x103249e4860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.161048:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"260 0x7f36bfd18070 0x103249e4860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.161390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 587
[1:1:0711/201807.161646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 587 0x7f36bfd18070 0x10324aacb60 , 5:3_http://renren-game.renren.com/, 0, , 470 0x7f36bfd18070 0x10324dd94e0 
[1:1:0711/201807.161936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.162497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , carousel, () {
            i++;
            if (i > page) {
                i = 1
            }
         
[1:1:0711/201807.162707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.222986:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd49895629c8, 0x1032442e150
[1:1:0711/201807.223267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 0
[1:1:0711/201807.223801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 588
[1:1:0711/201807.224047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7f36bfd18070 0x10324dc2d60 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 470 0x7f36bfd18070 0x10324dd94e0 
[1:1:0711/201807.243266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 13
[1:1:0711/201807.243830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 589
[1:1:0711/201807.244091:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 589 0x7f36bfd18070 0x10325816460 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 470 0x7f36bfd18070 0x10324dd94e0 
[1:1:0711/201807.266548:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 588, 7f36c265d881
[1:1:0711/201807.284650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"470 0x7f36bfd18070 0x10324dd94e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.284985:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"470 0x7f36bfd18070 0x10324dd94e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.285280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.285938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , (){_b=void 0}
[1:1:0711/201807.286179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.287590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 484, 7f36c265d8db
[1:1:0711/201807.306616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"263 0x7f36bfd18070 0x10324dbdbe0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.306933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"263 0x7f36bfd18070 0x10324dbdbe0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.307309:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 594
[1:1:0711/201807.307580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7f36bfd18070 0x10324dc33e0 , 5:3_http://renren-game.renren.com/, 0, , 484 0x7f36bfd18070 0x10324aac8e0 
[1:1:0711/201807.307912:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.308475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , carousel, () {
            i++;
            if (i > page) {
                i = 1
            }
         
[1:1:0711/201807.308692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.359776:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd49895629c8, 0x1032442e150
[1:1:0711/201807.359980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 0
[1:1:0711/201807.360388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 595
[1:1:0711/201807.360653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 595 0x7f36bfd18070 0x10324aaba60 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 484 0x7f36bfd18070 0x10324aac8e0 
[1:1:0711/201807.412585:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 589, 7f36c265d8db
[1:1:0711/201807.439167:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"470 0x7f36bfd18070 0x10324dd94e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.439543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"470 0x7f36bfd18070 0x10324dd94e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.439908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 600
[1:1:0711/201807.440138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f36bfd18070 0x103257d8d60 , 5:3_http://renren-game.renren.com/, 0, , 589 0x7f36bfd18070 0x10325816460 
[1:1:0711/201807.440463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.441027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.441245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.540557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 595, 7f36c265d881
[1:1:0711/201807.559095:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"484 0x7f36bfd18070 0x10324aac8e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.559454:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"484 0x7f36bfd18070 0x10324aac8e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.559785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.560336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , (){_b=void 0}
[1:1:0711/201807.560561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.562092:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 600, 7f36c265d8db
[1:1:0711/201807.587886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"589 0x7f36bfd18070 0x10325816460 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.588203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"589 0x7f36bfd18070 0x10325816460 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.588587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 603
[1:1:0711/201807.588831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 603 0x7f36bfd18070 0x10325591ce0 , 5:3_http://renren-game.renren.com/, 0, , 600 0x7f36bfd18070 0x103257d8d60 
[1:1:0711/201807.589142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.589724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.589938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.635397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 603, 7f36c265d8db
[1:1:0711/201807.644661:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"600 0x7f36bfd18070 0x103257d8d60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.644944:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"600 0x7f36bfd18070 0x103257d8d60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.645277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 606
[1:1:0711/201807.645531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f36bfd18070 0x1032554b760 , 5:3_http://renren-game.renren.com/, 0, , 603 0x7f36bfd18070 0x10325591ce0 
[1:1:0711/201807.645947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.646494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.646724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.654244:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 606, 7f36c265d8db
[1:1:0711/201807.670210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"603 0x7f36bfd18070 0x10325591ce0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.670501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"603 0x7f36bfd18070 0x10325591ce0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.670856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 608
[1:1:0711/201807.671080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f36bfd18070 0x10324dc47e0 , 5:3_http://renren-game.renren.com/, 0, , 606 0x7f36bfd18070 0x1032554b760 
[1:1:0711/201807.671392:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.671933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.672146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.694442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 608, 7f36c265d8db
[1:1:0711/201807.722858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"606 0x7f36bfd18070 0x1032554b760 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.723218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"606 0x7f36bfd18070 0x1032554b760 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.723601:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 610
[1:1:0711/201807.723858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f36bfd18070 0x10324dd67e0 , 5:3_http://renren-game.renren.com/, 0, , 608 0x7f36bfd18070 0x10324dc47e0 
[1:1:0711/201807.724184:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.724755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.724975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.730505:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 610, 7f36c265d8db
[1:1:0711/201807.747916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"608 0x7f36bfd18070 0x10324dc47e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.748263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"608 0x7f36bfd18070 0x10324dc47e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.748635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 612
[1:1:0711/201807.748884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7f36bfd18070 0x103254c2560 , 5:3_http://renren-game.renren.com/, 0, , 610 0x7f36bfd18070 0x10324dd67e0 
[1:1:0711/201807.749214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.749801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.750026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.754118:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 612, 7f36c265d8db
[1:1:0711/201807.771026:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"610 0x7f36bfd18070 0x10324dd67e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.771329:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"610 0x7f36bfd18070 0x10324dd67e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.771703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 614
[1:1:0711/201807.771932:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f36bfd18070 0x103249de860 , 5:3_http://renren-game.renren.com/, 0, , 612 0x7f36bfd18070 0x103254c2560 
[1:1:0711/201807.772252:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.772809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.773030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.779432:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 614, 7f36c265d8db
[1:1:0711/201807.796690:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"612 0x7f36bfd18070 0x103254c2560 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.796995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"612 0x7f36bfd18070 0x103254c2560 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.797329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 616
[1:1:0711/201807.797574:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f36bfd18070 0x103253d6860 , 5:3_http://renren-game.renren.com/, 0, , 614 0x7f36bfd18070 0x103249de860 
[1:1:0711/201807.797898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.798426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.798650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.813114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 616, 7f36c265d8db
[1:1:0711/201807.829548:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"614 0x7f36bfd18070 0x103249de860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.829868:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"614 0x7f36bfd18070 0x103249de860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.830213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 618
[1:1:0711/201807.830438:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f36bfd18070 0x103249df160 , 5:3_http://renren-game.renren.com/, 0, , 616 0x7f36bfd18070 0x103253d6860 
[1:1:0711/201807.830746:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.831301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.831512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.859226:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 618, 7f36c265d8db
[1:1:0711/201807.869594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"616 0x7f36bfd18070 0x103253d6860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.869888:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"616 0x7f36bfd18070 0x103253d6860 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.870221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 620
[1:1:0711/201807.870443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7f36bfd18070 0x10324dca3e0 , 5:3_http://renren-game.renren.com/, 0, , 618 0x7f36bfd18070 0x103249df160 
[1:1:0711/201807.870779:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.871370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.871645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.912975:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 620, 7f36c265d8db
[1:1:0711/201807.931262:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"618 0x7f36bfd18070 0x103249df160 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.931582:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"618 0x7f36bfd18070 0x103249df160 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.931946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 624
[1:1:0711/201807.932182:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 624 0x7f36bfd18070 0x103256e1960 , 5:3_http://renren-game.renren.com/, 0, , 620 0x7f36bfd18070 0x10324dca3e0 
[1:1:0711/201807.932514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.933096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.933311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.938863:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 624, 7f36c265d8db
[1:1:0711/201807.964740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"620 0x7f36bfd18070 0x10324dca3e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.965076:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"620 0x7f36bfd18070 0x10324dca3e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201807.965420:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 626
[1:1:0711/201807.965673:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7f36bfd18070 0x10324ac69e0 , 5:3_http://renren-game.renren.com/, 0, , 624 0x7f36bfd18070 0x103256e1960 
[1:1:0711/201807.966015:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201807.966574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201807.966797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201807.999594:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 626, 7f36c265d8db
[1:1:0711/201808.023590:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"624 0x7f36bfd18070 0x103256e1960 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.023919:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"624 0x7f36bfd18070 0x103256e1960 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.024264:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 628
[1:1:0711/201808.024489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7f36bfd18070 0x103258168e0 , 5:3_http://renren-game.renren.com/, 0, , 626 0x7f36bfd18070 0x10324ac69e0 
[1:1:0711/201808.024824:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201808.025364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201808.025586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201808.057033:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 628, 7f36c265d8db
[1:1:0711/201808.083048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"626 0x7f36bfd18070 0x10324ac69e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.083366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"626 0x7f36bfd18070 0x10324ac69e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.083743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 631
[1:1:0711/201808.084015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f36bfd18070 0x103254ed5e0 , 5:3_http://renren-game.renren.com/, 0, , 628 0x7f36bfd18070 0x103258168e0 
[1:1:0711/201808.084340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201808.084910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201808.085121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201808.112345:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 631, 7f36c265d8db
[1:1:0711/201808.144327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"628 0x7f36bfd18070 0x103258168e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.144728:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"628 0x7f36bfd18070 0x103258168e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.145085:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 633
[1:1:0711/201808.145326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f36bfd18070 0x10325617660 , 5:3_http://renren-game.renren.com/, 0, , 631 0x7f36bfd18070 0x103254ed5e0 
[1:1:0711/201808.145669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201808.146239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201808.146448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201808.185092:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 633, 7f36c265d8db
[1:1:0711/201808.196158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"631 0x7f36bfd18070 0x103254ed5e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.196437:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"631 0x7f36bfd18070 0x103254ed5e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201808.196787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 635
[1:1:0711/201808.197011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f36bfd18070 0x1032588d360 , 5:3_http://renren-game.renren.com/, 0, , 633 0x7f36bfd18070 0x10325617660 
[1:1:0711/201808.197326:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201808.197887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201808.198097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201808.285520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/201808.285939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[9150:9150:0711/201808.634081:INFO:CONSOLE(3)] "Uncaught SyntaxError: Unexpected identifier", source: http://renren-game.renren.com/static/index/css/jquery.min.js-ver=1.0 (3)
[3:3:0711/201809.725749:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/201810.445177:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 587, 7f36c265d8db
[1:1:0711/201810.473746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"470 0x7f36bfd18070 0x10324dd94e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.474116:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"470 0x7f36bfd18070 0x10324dd94e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.474470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 677
[1:1:0711/201810.474698:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7f36bfd18070 0x10325979b60 , 5:3_http://renren-game.renren.com/, 0, , 587 0x7f36bfd18070 0x10324aacb60 
[1:1:0711/201810.475035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201810.475587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , carousel, () {
            i++;
            if (i > page) {
                i = 1
            }
         
[1:1:0711/201810.475823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201810.546021:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd49895629c8, 0x1032442e150
[1:1:0711/201810.546332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 0
[1:1:0711/201810.546732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 678
[1:1:0711/201810.546996:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f36bfd18070 0x103257d87e0 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 587 0x7f36bfd18070 0x10324aacb60 
[1:1:0711/201810.557550:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://renren-game.renren.com/", 13
[1:1:0711/201810.558125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 679
[1:1:0711/201810.558364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f36bfd18070 0x10324dd9fe0 , 5:3_http://renren-game.renren.com/, 1, -5:3_http://renren-game.renren.com/, 587 0x7f36bfd18070 0x10324aacb60 
[1:1:0711/201810.622807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 594, 7f36c265d8db
[1:1:0711/201810.652046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"484 0x7f36bfd18070 0x10324aac8e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.652352:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"484 0x7f36bfd18070 0x10324aac8e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.652713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 684
[1:1:0711/201810.653010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7f36bfd18070 0x10324aaf0e0 , 5:3_http://renren-game.renren.com/, 0, , 594 0x7f36bfd18070 0x10324dc33e0 
[1:1:0711/201810.653309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201810.653855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , carousel, () {
            i++;
            if (i > page) {
                i = 1
            }
         
[1:1:0711/201810.654085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201810.757150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://renren-game.renren.com/, 678, 7f36c265d881
[1:1:0711/201810.787017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"587 0x7f36bfd18070 0x10324aacb60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.787410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"587 0x7f36bfd18070 0x10324aacb60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.787718:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201810.788320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , , (){_b=void 0}
[1:1:0711/201810.788531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201810.789916:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 679, 7f36c265d8db
[1:1:0711/201810.819155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a630d382860","ptid":"587 0x7f36bfd18070 0x10324aacb60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.819489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://renren-game.renren.com/","ptid":"587 0x7f36bfd18070 0x10324aacb60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.819849:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 688
[1:1:0711/201810.820138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7f36bfd18070 0x10325972060 , 5:3_http://renren-game.renren.com/, 0, , 679 0x7f36bfd18070 0x10324dd9fe0 
[1:1:0711/201810.820453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201810.820998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201810.821211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201810.925059:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 688, 7f36c265d8db
[1:1:0711/201810.953427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"679 0x7f36bfd18070 0x10324dd9fe0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.953721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"679 0x7f36bfd18070 0x10324dd9fe0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201810.954096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 691
[1:1:0711/201810.954324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f36bfd18070 0x103249dfa60 , 5:3_http://renren-game.renren.com/, 0, , 688 0x7f36bfd18070 0x10325972060 
[1:1:0711/201810.954654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201810.955222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201810.955434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201810.991252:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 691, 7f36c265d8db
[1:1:0711/201811.019019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"688 0x7f36bfd18070 0x10325972060 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.019340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"688 0x7f36bfd18070 0x10325972060 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.019673:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 694
[1:1:0711/201811.019930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f36bfd18070 0x1032588dae0 , 5:3_http://renren-game.renren.com/, 0, , 691 0x7f36bfd18070 0x103249dfa60 
[1:1:0711/201811.020292:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.020863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.021105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201811.046197:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 694, 7f36c265d8db
[1:1:0711/201811.074671:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"691 0x7f36bfd18070 0x103249dfa60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.075034:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"691 0x7f36bfd18070 0x103249dfa60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.075381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 696
[1:1:0711/201811.075621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 696 0x7f36bfd18070 0x1032596a560 , 5:3_http://renren-game.renren.com/, 0, , 694 0x7f36bfd18070 0x1032588dae0 
[1:1:0711/201811.075999:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.076551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.076760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201811.082342:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 696, 7f36c265d8db
[1:1:0711/201811.118385:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"694 0x7f36bfd18070 0x1032588dae0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.118769:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"694 0x7f36bfd18070 0x1032588dae0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.119149:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 698
[1:1:0711/201811.119402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7f36bfd18070 0x1032588d2e0 , 5:3_http://renren-game.renren.com/, 0, , 696 0x7f36bfd18070 0x1032596a560 
[1:1:0711/201811.119744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.120359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.120572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201811.160915:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 698, 7f36c265d8db
[1:1:0711/201811.190422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"696 0x7f36bfd18070 0x1032596a560 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.190738:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"696 0x7f36bfd18070 0x1032596a560 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.191108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 700
[1:1:0711/201811.191347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f36bfd18070 0x103259722e0 , 5:3_http://renren-game.renren.com/, 0, , 698 0x7f36bfd18070 0x1032588d2e0 
[1:1:0711/201811.191667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.192248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.192471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201811.198889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 700, 7f36c265d8db
[1:1:0711/201811.227031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"698 0x7f36bfd18070 0x1032588d2e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.227340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"698 0x7f36bfd18070 0x1032588d2e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.227685:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 702
[1:1:0711/201811.227919:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f36bfd18070 0x10325972d60 , 5:3_http://renren-game.renren.com/, 0, , 700 0x7f36bfd18070 0x103259722e0 
[1:1:0711/201811.228262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.228795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.229035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201811.235282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 702, 7f36c265d8db
[1:1:0711/201811.268197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"700 0x7f36bfd18070 0x103259722e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.268530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"700 0x7f36bfd18070 0x103259722e0 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.268869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 704
[1:1:0711/201811.269133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 704 0x7f36bfd18070 0x1032496c960 , 5:3_http://renren-game.renren.com/, 0, , 702 0x7f36bfd18070 0x10325972d60 
[1:1:0711/201811.269469:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.270055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.270268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201811.276542:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 704, 7f36c265d8db
[1:1:0711/201811.307140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"702 0x7f36bfd18070 0x10325972d60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.307453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"702 0x7f36bfd18070 0x10325972d60 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.307793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 706
[1:1:0711/201811.308087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7f36bfd18070 0x10325964960 , 5:3_http://renren-game.renren.com/, 0, , 704 0x7f36bfd18070 0x1032496c960 
[1:1:0711/201811.308399:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.308912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.309128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201811.326828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 706, 7f36c265d8db
[1:1:0711/201811.353675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"704 0x7f36bfd18070 0x1032496c960 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.353988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"704 0x7f36bfd18070 0x1032496c960 ","rf":"5:3_http://renren-game.renren.com/"}
[1:1:0711/201811.354348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://renren-game.renren.com/, 708
[1:1:0711/201811.354573:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 708 0x7f36bfd18070 0x103254c6b60 , 5:3_http://renren-game.renren.com/, 0, , 706 0x7f36bfd18070 0x10325964960 
[1:1:0711/201811.354892:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://renren-game.renren.com/"
[1:1:0711/201811.355450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://renren-game.renren.com/, 3a630d382860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0711/201811.355660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://renren-game.renren.com/", "renren-game.renren.com", 3, 1, , , 0
[1:1:0711/201812.265725:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://ee.cc/static/index/images/earth.ico"
[9150:9150:0711/201813.057513:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
