[0711/201458.460529:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201458.460941:INFO:switcher_clone.cc(787)] backtrace rip is 7fd495e7e891
[0711/201459.321080:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201459.321498:INFO:switcher_clone.cc(787)] backtrace rip is 7f5150693891
[1:1:0711/201459.338451:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/201459.338794:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/201459.344276:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[8631:8631:0711/201500.523481:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dbeb871b-9394-4f01-bb57-d8cc68d2ac26
[0711/201500.821469:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/201500.821873:INFO:switcher_clone.cc(787)] backtrace rip is 7f61c279d891
[8631:8631:0711/201500.987456:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[8631:8662:0711/201500.988526:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/201500.988785:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/201500.989023:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/201500.989621:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/201500.989792:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/201500.992974:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x18f0a37b, 1
[1:1:0711/201500.993366:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x29a13bc9, 0
[1:1:0711/201500.993576:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x370ac367, 3
[1:1:0711/201500.993813:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3cef81bb, 2
[1:1:0711/201500.994078:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc93bffffffa129 7bffffffa3fffffff018 ffffffbbffffff81ffffffef3c 67ffffffc30a37 , 10104, 4
[1:1:0711/201500.995101:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[8631:8662:0711/201500.995371:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�;�){�����<g�
7�ZO8
[8631:8662:0711/201500.995442:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �;�){�����<g�
7ȶ�ZO8
[1:1:0711/201500.995353:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f514e8ce0a0, 3
[1:1:0711/201500.995609:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f514ea59080, 2
[8631:8662:0711/201500.995830:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/201500.995764:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f513871cd20, -2
[8631:8662:0711/201500.995916:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 8677, 4, c93ba129 7ba3f018 bb81ef3c 67c30a37 
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/201501.020624:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/201501.021469:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3cef81bb
[1:1:0711/201501.022396:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3cef81bb
[1:1:0711/201501.024381:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3cef81bb
[1:1:0711/201501.026122:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.026345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.026525:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.026700:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.027354:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3cef81bb
[1:1:0711/201501.027672:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f51506937ba
[1:1:0711/201501.027812:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f515068adef, 7f515069377a, 7f51506950cf
[1:1:0711/201501.032816:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3cef81bb
[1:1:0711/201501.033220:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3cef81bb
[1:1:0711/201501.034228:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3cef81bb
[1:1:0711/201501.036589:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.036799:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.037024:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.037250:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cef81bb
[1:1:0711/201501.038511:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3cef81bb
[1:1:0711/201501.038898:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f51506937ba
[1:1:0711/201501.039118:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f515068adef, 7f515069377a, 7f51506950cf
[1:1:0711/201501.048788:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/201501.049419:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/201501.049592:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff4516a998, 0x7fff4516a918)
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/201501.066711:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[8664:8664:0711/201501.072614:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=8664
[1:1:0711/201501.072605:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[8685:8685:0711/201501.073148:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=8685
[8631:8631:0711/201501.598939:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[8631:8631:0711/201501.600378:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[8631:8643:0711/201501.616024:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[8631:8643:0711/201501.616132:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[8631:8631:0711/201501.616288:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[8631:8631:0711/201501.616370:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[8631:8631:0711/201501.616518:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,8677, 4
[1:7:0711/201501.618377:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[8631:8656:0711/201501.634323:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/201501.729807:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x16d563e7f220
[1:1:0711/201501.730139:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/201501.931961:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0711/201503.104895:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201503.108749:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[8631:8631:0711/201503.316235:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[8631:8631:0711/201503.316367:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/201504.109096:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201504.247111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f6fcf361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/201504.247443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201504.263712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f6fcf361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/201504.264034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201504.579409:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201504.579658:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201504.995749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201505.004062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f6fcf361f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/201505.004402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201505.039972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201505.050473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f6fcf361f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/201505.050758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201505.062561:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[8631:8631:0711/201505.066399:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/201505.066109:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x16d563e7de20
[1:1:0711/201505.067094:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[8631:8631:0711/201505.081518:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[8631:8631:0711/201505.108995:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[8631:8631:0711/201505.109153:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/201505.139009:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201505.957673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f513a2f72e0 0x16d56405fa60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201505.959007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f6fcf361f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/201505.959280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201505.960839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[8631:8631:0711/201506.028208:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/201506.030533:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x16d563e7e820
[1:1:0711/201506.030820:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[8631:8631:0711/201506.032971:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/201506.051981:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/201506.052256:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[8631:8631:0711/201506.053466:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[8631:8631:0711/201506.066419:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[8631:8631:0711/201506.067728:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[8631:8643:0711/201506.075201:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[8631:8643:0711/201506.075305:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[8631:8631:0711/201506.075564:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[8631:8631:0711/201506.075663:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[8631:8631:0711/201506.075837:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,8677, 4
[1:7:0711/201506.078221:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/201506.468872:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/201506.908561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f513a2f72e0 0x16d564242160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201506.909852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f6fcf361f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/201506.910110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201506.911026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[8631:8631:0711/201507.039095:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[8631:8631:0711/201507.039214:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/201507.077391:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/201507.433444:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201507.865731:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201507.865985:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201508.139993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201508.144465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/201508.144707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201508.152405:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[8631:8631:0711/201508.220989:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[8631:8662:0711/201508.221448:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/201508.221669:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/201508.221890:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/201508.222264:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/201508.222403:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/201508.225508:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x226736cd, 1
[1:1:0711/201508.225885:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x236d8747, 0
[1:1:0711/201508.226076:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x383ee9bf, 3
[1:1:0711/201508.226267:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1c36655b, 2
[1:1:0711/201508.226449:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 47ffffff876d23 ffffffcd366722 5b65361c ffffffbfffffffe93e38 , 10104, 5
[1:1:0711/201508.227875:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[8631:8662:0711/201508.228139:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGG�m#�6g"[e6��>8�[O8
[8631:8662:0711/201508.228207:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is G�m#�6g"[e6��>8(��[O8
[8631:8662:0711/201508.228488:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 8730, 5, 47876d23 cd366722 5b65361c bfe93e38 
[1:1:0711/201508.228322:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f514e8ce0a0, 3
[1:1:0711/201508.228648:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f514ea59080, 2
[1:1:0711/201508.228865:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f513871cd20, -2
[1:1:0711/201508.249559:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/201508.249786:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1c36655b
[1:1:0711/201508.249976:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1c36655b
[1:1:0711/201508.250241:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1c36655b
[1:1:0711/201508.250679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.250838:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.250970:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.251065:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.251298:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1c36655b
[1:1:0711/201508.251431:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f51506937ba
[1:1:0711/201508.251507:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f515068adef, 7f515069377a, 7f51506950cf
[1:1:0711/201508.253023:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1c36655b
[1:1:0711/201508.253187:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1c36655b
[1:1:0711/201508.253451:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1c36655b
[1:1:0711/201508.254147:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.254261:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.254357:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.254453:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c36655b
[1:1:0711/201508.254923:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1c36655b
[1:1:0711/201508.255083:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f51506937ba
[1:1:0711/201508.255157:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f515068adef, 7f515069377a, 7f51506950cf
[1:1:0711/201508.257466:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/201508.257834:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/201508.257934:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff4516a998, 0x7fff4516a918)
[1:1:0711/201508.266763:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/201508.271289:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/201508.381261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/201508.382050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f6fcf361f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/201508.382266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/201508.473727:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x16d563e68220
[1:1:0711/201508.473892:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/201508.638577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201508.640317:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/201508.640551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/201508.640857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201508.787009:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201508.788062:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/201508.788315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/201508.788563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[8631:8631:0711/201509.072328:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[8631:8631:0711/201509.088109:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[8631:8662:0711/201509.088567:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0711/201509.088860:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/201509.088999:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/201509.089228:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/201509.089320:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0711/201509.092046:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x20ddde58, 1
[1:1:0711/201509.092423:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1c7a2807, 0
[1:1:0711/201509.092657:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26535724, 3
[1:1:0711/201509.092875:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b378579, 2
[1:1:0711/201509.093054:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 07287a1c 58ffffffdeffffffdd20 79ffffff85371b 24575326 , 10104, 6
[1:1:0711/201509.094278:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[8631:8662:0711/201509.094619:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING(zX�� y�7$WS&�ZO8
[8631:8662:0711/201509.094689:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is (zX�� y�7$WS&8��ZO8
[1:1:0711/201509.094617:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f514e8ce0a0, 3
[1:1:0711/201509.094865:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f514ea59080, 2
[8631:8662:0711/201509.094980:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 8744, 6, 07287a1c 58dedd20 7985371b 24575326 
[1:1:0711/201509.095069:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f513871cd20, -2
[8631:8631:0711/201509.125187:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/201509.126073:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/201509.126386:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b378579
[1:1:0711/201509.126658:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b378579
[1:1:0711/201509.127241:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b378579
[1:1:0711/201509.128703:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.128914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.129104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.129278:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.129960:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b378579
[1:1:0711/201509.130318:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f51506937ba
[1:1:0711/201509.130485:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f515068adef, 7f515069377a, 7f51506950cf
[1:1:0711/201509.137571:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b378579
[1:1:0711/201509.138045:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b378579
[1:1:0711/201509.138976:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b378579
[1:1:0711/201509.141509:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.141782:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.142049:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.142278:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b378579
[1:1:0711/201509.143856:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b378579
[1:1:0711/201509.144320:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f51506937ba
[1:1:0711/201509.144485:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f515068adef, 7f515069377a, 7f51506950cf
[8631:8643:0711/201509.153111:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[8631:8643:0711/201509.153206:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[8631:8631:0711/201509.153574:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://safe.renren.com/
[8631:8631:0711/201509.153653:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://safe.renren.com/, https://safe.renren.com/standalone/findpwd, 1
[8631:8631:0711/201509.153780:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://safe.renren.com/, HTTP/1.1 200 OK Server: Tengine/2.0.2 Date: Fri, 12 Jul 2019 03:15:09 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Cache-Control: no-cache Pragma: no-cache Expires: Thu, 01 Jan 1970 00:00:00 GMT Set-Cookie: sdt=lC4LDV21VkZ39YPMMAQ3l8MM7f5AMAx0BJ0KD; domain=safe.renren.com; path=/; expires=Wed, 30-Jul-2087 06:29:16 GMT Set-Cookie: anonymid=jxzj3455-csh7vw; domain=.renren.com; path=/; expires=Wed, 10-Jul-2024 03:15:09 GMT Set-Cookie: JSESSIONID=aaaeyn2RvDSFi53AwlKVw; path=/ Content-Encoding: gzip  ,0, 6
[1:1:0711/201509.154248:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/201509.154839:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/201509.155018:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff4516a998, 0x7fff4516a918)
[3:3:0711/201509.159796:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/201509.172529:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/201509.177800:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0711/201509.249654:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/201509.396985:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0711/201509.410462:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x16d563e76220
[1:1:0711/201509.411216:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/201509.444003:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://safe.renren.com/
[8631:8631:0711/201509.470619:WARNING:CONSOLE(0)] "The SSL certificate used to load resources from https://safe.renren.com will be distrusted in M70. Once distrusted, users will be prevented from loading these resources. See https://g.co/chrome/symantecpkicerts for more information.", source:  (0)
[1:1:0711/201509.526596:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wish.com/"
[8631:8631:0711/201509.755302:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://safe.renren.com/, https://safe.renren.com/, 1
[8631:8631:0711/201509.755433:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://safe.renren.com/, https://safe.renren.com
[1:1:0711/201509.782684:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/201509.926392:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201509.992298:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201509.992543:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201510.071310:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gmx.net/"
[1:1:0711/201510.136723:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/201510.267702:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/201510.306295:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/201510.373446:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/201510.459169:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/201510.531713:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201510.532610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/201510.532885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201510.536937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7f51383cf070 0x16d5640670e0 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201510.539051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , , 
XN = {get_check:'',get_check_x:'92b37796',env:{domain:'renren.com',shortSiteName:'人人',siteName:
[1:1:0711/201510.539314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "safe.renren.com", 3, 1, , , 0
[1:1:0711/201510.589898:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201510.907328:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201510.917925:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201510.937001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , , (function(){var k,p,m,g,a={},c={},o=/\\/g;var e=function(t,s){if(t==null){return null}if(t.Slick===t
[1:1:0711/201510.937316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "safe.renren.com", 3, 1, , , 0
[1:1:0711/201511.097796:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201511.098729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/201511.099007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201511.166560:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201511.167560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/201511.167912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201511.193678:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201511.194687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/201511.194958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/201511.274339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/201511.275251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f6fcf4909f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/201511.275521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/201512.678491:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201512.678952:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201512.679482:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201512.679979:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201512.680475:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/201515.424783:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "safe.renren.com", "renren.com"
[1:1:0711/201515.492413:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.495929:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.548953:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.638205:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.754950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.761228:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.773683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.780848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.791325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.801978:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.811918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.832398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.838207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f5138737bd0 0x16d563fd4558 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201515.864254:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.372723, 301, 1
[1:1:0711/201515.864522:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/201516.226266:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/201516.226522:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.227396:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f51383cf070 0x16d5658b8360 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.228905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , , 
		XN.dom.ready(function(){
			var odom;
			object.use('dom', function(dom){
				odom = dom;
			});

[1:1:0711/201516.229130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "renren.com", 3, 1, , , 0
[1:1:0711/201516.232407:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f51383cf070 0x16d5658b8360 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.239744:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f51383cf070 0x16d5658b8360 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.247366:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.248782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.250141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.251281:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.264155:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201516.265482:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201517.596486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201517.599668:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201517.602152:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201517.666866:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201518.039095:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201518.941527:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f513a2f72e0 0x16d563e6cf60 , "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201518.945348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , , (function(){var E;var g=window,n=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0711/201518.945570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "renren.com", 3, 1, , , 0
[8631:8631:0711/201519.881617:INFO:CONSOLE(0)] "The SSL certificate used to load resources from https://safe.renren.com will be distrusted in M70. Once distrusted, users will be prevented from loading these resources. See https://g.co/chrome/symantecpkicerts for more information.", source: https://safe.renren.com/standalone/findpwd (0)
[3:3:0711/201520.423162:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/201520.545136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/201520.545411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "renren.com", 3, 1, , , 0
[1:1:0711/201520.867899:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201520.868705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0711/201520.868973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "renren.com", 3, 1, , , 0
[1:1:0711/201520.872717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201521.752500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , , document.readyState
[1:1:0711/201521.752826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "renren.com", 3, 1, , , 0
[1:1:0711/201522.187659:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://safe.renren.com/standalone/findpwd"
[1:1:0711/201522.188386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://safe.renren.com/, 15aecf6c2860, , , (){f.menu.refresh()}
[1:1:0711/201522.188599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://safe.renren.com/standalone/findpwd", "renren.com", 3, 1, , , 0
[1:1:0711/201522.189789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://safe.renren.com/standalone/findpwd"
[8631:8631:0711/201522.646432:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
