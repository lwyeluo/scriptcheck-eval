[0712/104725.267502:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/104725.267807:INFO:switcher_clone.cc(787)] backtrace rip is 7f86e9cbc891
[0712/104726.319685:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/104726.320090:INFO:switcher_clone.cc(787)] backtrace rip is 7f4d8ca4e891
[1:1:0712/104726.332149:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/104726.332428:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/104726.338324:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/104727.778129:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/104727.778545:INFO:switcher_clone.cc(787)] backtrace rip is 7f7c14bab891
[128118:128118:0712/104727.824775:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4e5c2c80-df2b-4802-9959-58b89ecd4a02
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[128151:128151:0712/104727.962286:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128151
[128163:128163:0712/104727.962763:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128163
[128118:128118:0712/104728.405269:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[128118:128148:0712/104728.406961:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/104728.407188:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/104728.407437:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/104728.408025:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/104728.408242:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/104728.411184:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x110c7233, 1
[1:1:0712/104728.411543:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2f80a3a8, 0
[1:1:0712/104728.411708:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3f2718c2, 3
[1:1:0712/104728.412050:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3def500, 2
[1:1:0712/104728.412450:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa8ffffffa3ffffff802f 33720c11 00fffffff5ffffffde03 ffffffc218273f , 10104, 4
[1:1:0712/104728.413386:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128118:128148:0712/104728.413618:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���/3r
[128118:128148:0712/104728.413711:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���/3r
[1:1:0712/104728.413607:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d8ac890a0, 3
[1:1:0712/104728.413820:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d8ae14080, 2
[128118:128148:0712/104728.414044:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/104728.413975:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d74ad7d20, -2
[128118:128148:0712/104728.414113:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128171, 4, a8a3802f 33720c11 00f5de03 c218273f 
[1:1:0712/104728.428898:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/104728.429777:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3def500
[1:1:0712/104728.430496:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3def500
[1:1:0712/104728.431552:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3def500
[1:1:0712/104728.432082:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.432248:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.432371:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.432490:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.432723:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3def500
[1:1:0712/104728.432871:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4d8ca4e7ba
[1:1:0712/104728.432951:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4d8ca45def, 7f4d8ca4e77a, 7f4d8ca500cf
[1:1:0712/104728.434431:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3def500
[1:1:0712/104728.434597:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3def500
[1:1:0712/104728.434873:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3def500
[1:1:0712/104728.435588:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.435701:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.435805:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.435904:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3def500
[1:1:0712/104728.436437:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3def500
[1:1:0712/104728.436604:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4d8ca4e7ba
[1:1:0712/104728.436698:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4d8ca45def, 7f4d8ca4e77a, 7f4d8ca500cf
[1:1:0712/104728.438843:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/104728.439103:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/104728.439213:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd8f37f3e8, 0x7ffd8f37f368)
[1:1:0712/104728.453677:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/104728.459455:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[128118:128118:0712/104728.984232:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128118:128118:0712/104728.985683:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128118:128130:0712/104729.002633:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[128118:128130:0712/104729.002734:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[128118:128118:0712/104729.002871:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[128118:128118:0712/104729.002951:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[128118:128118:0712/104729.003090:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,128171, 4
[1:7:0712/104729.004949:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[128118:128143:0712/104729.036091:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/104729.063253:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1dc860da3220
[1:1:0712/104729.063536:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/104729.428833:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[128118:128118:0712/104731.179181:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[128118:128118:0712/104731.179301:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/104731.234977:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104731.239832:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/104732.579984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 114c5ece1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/104732.580195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/104732.585717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 114c5ece1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/104732.585866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/104732.609563:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104732.908985:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104732.909172:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/104733.130678:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/104733.133361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 114c5ece1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/104733.133532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/104733.150511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/104733.153609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 114c5ece1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/104733.153745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/104733.157649:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/104733.161797:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1dc860da1e20
[1:1:0712/104733.161975:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[128118:128118:0712/104733.162793:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[128118:128118:0712/104733.169675:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[128118:128118:0712/104733.197644:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[128118:128118:0712/104733.197807:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/104733.268044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/104734.140119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f4d766b22e0 0x1dc8610466e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/104734.141495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 114c5ece1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/104734.141697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/104734.143180:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128118:128118:0712/104734.212255:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/104734.212773:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1dc860da2820
[1:1:0712/104734.212973:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[128118:128118:0712/104734.222242:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/104734.231629:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/104734.231931:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[128118:128118:0712/104734.242307:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[128118:128118:0712/104734.255317:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128118:128118:0712/104734.256632:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128118:128130:0712/104734.264831:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[128118:128130:0712/104734.264932:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[128118:128118:0712/104734.265177:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[128118:128118:0712/104734.265277:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[128118:128118:0712/104734.265454:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,128171, 4
[1:7:0712/104734.269100:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/104734.748855:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/104735.031365:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f4d766b22e0 0x1dc861182960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/104735.032472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 114c5ece1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/104735.032738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/104735.033549:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128118:128118:0712/104735.207541:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[128118:128118:0712/104735.207615:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/104735.232723:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[128118:128118:0712/104735.588731:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[128118:128148:0712/104735.589253:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/104735.589488:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/104735.589737:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/104735.590206:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/104735.590378:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/104735.594095:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x25dcca38, 1
[1:1:0712/104735.594605:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2452b15a, 0
[1:1:0712/104735.594851:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x202ec4e, 3
[1:1:0712/104735.595070:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1a9d8c7e, 2
[1:1:0712/104735.595320:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5affffffb15224 38ffffffcaffffffdc25 7effffff8cffffff9d1a 4effffffec0202 , 10104, 5
[1:1:0712/104735.596368:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128118:128148:0712/104735.596651:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGZ�R$8��%~��N�MA�
[128118:128148:0712/104735.596721:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Z�R$8��%~��N�(�MA�
[1:1:0712/104735.596643:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d8ac890a0, 3
[1:1:0712/104735.596841:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d8ae14080, 2
[128118:128148:0712/104735.596958:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128215, 5, 5ab15224 38cadc25 7e8c9d1a 4eec0202 
[1:1:0712/104735.597025:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d74ad7d20, -2
[1:1:0712/104735.613203:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/104735.613440:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1a9d8c7e
[1:1:0712/104735.613623:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1a9d8c7e
[1:1:0712/104735.613889:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1a9d8c7e
[1:1:0712/104735.614370:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.614480:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.614579:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.614679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.614926:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1a9d8c7e
[1:1:0712/104735.615063:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4d8ca4e7ba
[1:1:0712/104735.615252:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4d8ca45def, 7f4d8ca4e77a, 7f4d8ca500cf
[1:1:0712/104735.622349:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1a9d8c7e
[1:1:0712/104735.622808:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1a9d8c7e
[1:1:0712/104735.623730:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1a9d8c7e
[1:1:0712/104735.626330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.626627:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.626883:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.627145:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a9d8c7e
[1:1:0712/104735.628752:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1a9d8c7e
[1:1:0712/104735.629234:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4d8ca4e7ba
[1:1:0712/104735.629435:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4d8ca45def, 7f4d8ca4e77a, 7f4d8ca500cf
[1:1:0712/104735.639140:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/104735.639754:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/104735.639949:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd8f37f3e8, 0x7ffd8f37f368)
[1:1:0712/104735.656698:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/104735.662162:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/104735.672230:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104735.856848:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1dc860d6f220
[1:1:0712/104735.857013:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/104736.372880:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104736.373143:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104736.735084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104736.739910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/104736.740294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/104736.743597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104736.850641:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/104736.851368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 114c5ece1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/104736.851607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/104736.939406:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104736.941138:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/104736.941374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/104736.941728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/104737.118604:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104737.119627:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/104737.119924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/104737.120242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[128118:128118:0712/104737.225444:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128118:128118:0712/104737.251772:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[128118:128148:0712/104737.252145:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/104737.252368:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/104737.252579:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/104737.253005:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/104737.253164:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/104737.258701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x13043a24, 1
[1:1:0712/104737.259215:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x5977b27, 0
[1:1:0712/104737.259454:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3e124481, 3
[1:1:0712/104737.259669:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd50fa9e, 2
[1:1:0712/104737.259863:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 277bffffff9705 243a0413 ffffff9efffffffa500d ffffff8144123e , 10104, 6
[1:1:0712/104737.260969:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128118:128148:0712/104737.261459:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING'{�$:��P�D>A�
[128118:128148:0712/104737.261553:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is '{�$:��P�D>�`A�
[1:1:0712/104737.261435:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d8ac890a0, 3
[128118:128148:0712/104737.261866:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128231, 6, 277b9705 243a0413 9efa500d 8144123e 
[1:1:0712/104737.261887:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d8ae14080, 2
[1:1:0712/104737.262389:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4d74ad7d20, -2
[128118:128118:0712/104737.284424:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/104737.288001:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/104737.288391:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d50fa9e
[1:1:0712/104737.288763:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d50fa9e
[1:1:0712/104737.289485:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d50fa9e
[1:1:0712/104737.291226:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.291463:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.291710:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.291931:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.292756:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d50fa9e
[1:1:0712/104737.293105:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4d8ca4e7ba
[1:1:0712/104737.293266:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4d8ca45def, 7f4d8ca4e77a, 7f4d8ca500cf
[1:1:0712/104737.300192:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d50fa9e
[1:1:0712/104737.300689:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d50fa9e
[1:1:0712/104737.301603:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d50fa9e
[1:1:0712/104737.304142:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.304400:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.304655:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.304887:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d50fa9e
[1:1:0712/104737.306419:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d50fa9e
[1:1:0712/104737.306889:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4d8ca4e7ba
[1:1:0712/104737.307085:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4d8ca45def, 7f4d8ca4e77a, 7f4d8ca500cf
[128118:128130:0712/104737.313807:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[128118:128130:0712/104737.313936:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[128118:128118:0712/104737.313970:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://docs.oracle.com/
[128118:128118:0712/104737.314013:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://docs.oracle.com/, https://docs.oracle.com/en/, 1
[128118:128118:0712/104737.314075:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://docs.oracle.com/, HTTP/1.1 200 OK Server: AkamaiNetStorage Content-Type: text/html ETag: "c96165ef5f6ed7767935e06a4d4f6e40:1560871443.428903" Vary: Accept-Encoding Content-Encoding: gzip Cache-Control: max-age=4083 Date: Fri, 12 Jul 2019 17:47:37 GMT Content-Length: 8008 Connection: keep-alive  ,0, 6
[1:1:0712/104737.316555:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/104737.317224:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/104737.317400:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd8f37f3e8, 0x7ffd8f37f368)
[3:3:0712/104737.323490:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/104737.334085:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/104737.339976:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/104737.422692:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/104737.501034:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/104737.588738:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1dc860da3220
[1:1:0712/104737.589529:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/104737.668080:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://docs.oracle.com/
[1:1:0712/104737.826806:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.dytt8.net/"
[128118:128118:0712/104737.910526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://docs.oracle.com/, https://docs.oracle.com/, 1
[128118:128118:0712/104737.910666:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://docs.oracle.com/, https://docs.oracle.com
[1:1:0712/104737.934295:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.fandom.com/"
[1:1:0712/104737.942327:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/104738.126424:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104738.151685:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[1:1:0712/104738.271084:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104738.271419:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://docs.oracle.com/en/"
[1:1:0712/104738.390189:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.springer.com/"
[1:1:0712/104738.453701:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0712/104738.509706:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0712/104738.598811:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0712/104738.846401:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104739.074450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104739.075363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/104739.075637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/104739.254790:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104739.255891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/104739.256298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/104739.421837:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104739.423154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/104739.423465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/104739.608366:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104739.609330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/104739.609604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/104739.816857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/104739.817923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 114c5ee0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/104739.818226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/104739.824866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 217 0x7f4d7478a070 0x1dc861245260 , "https://docs.oracle.com/en/"
[1:1:0712/104739.838569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , /*!
######################################################

# JQUERY.JS

# OCOM GLOBAL ASSET RELEASE
[1:1:0712/104739.838870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104739.860197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/104740.575162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f4d74af2bd0 0x1dc860788558 , "https://docs.oracle.com/en/"
[1:1:0712/104740.604673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , /*! jQuery UI - v1.10.4 - 2014-05-18
* http://jqueryui.com
* Includes: jquery.ui.core.js, jquery.ui.
[1:1:0712/104740.604991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104741.554628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f4d74af2bd0 0x1dc860788558 , "https://docs.oracle.com/en/"
[1:1:0712/104746.959683:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104746.960334:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104746.960885:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104746.961342:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104746.961793:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[128118:128118:0712/104801.613295:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/104801.622848:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/104801.855056:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 20.3048, 0, 0
[1:1:0712/104801.855402:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104812.098548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/104812.098820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104812.857699:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104812.857980:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://docs.oracle.com/en/"
[1:1:0712/104812.863879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 671 0x7f4d7478a070 0x1dc86170f560 , "https://docs.oracle.com/en/"
[1:1:0712/104812.869212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , var suggestions = null,
    tabInView,
    typeInView,
    searchval,
    federation_categories,
   
[1:1:0712/104812.869481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104812.972335:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 671 0x7f4d7478a070 0x1dc86170f560 , "https://docs.oracle.com/en/"
[1:1:0712/104813.143285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104813.143605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104813.912668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104813.912955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104813.958339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 702, "https://docs.oracle.com/en/"
[1:1:0712/104813.960602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , /* Copyright 2017, Oracle and/or its affiliates. All rights reserved.
 * Contact: Jordan Douglas
 * 
[1:1:0712/104813.960848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104813.986850:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.023464, 133, 1
[1:1:0712/104813.987128:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104814.092282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104814.092583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104814.845457:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104814.845675:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://docs.oracle.com/en/"
[1:1:0712/104814.896214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104814.896508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104815.509648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 741 0x7f4d766b22e0 0x1dc8609f6ee0 , "https://docs.oracle.com/en/"
[1:1:0712/104815.512351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , function _truste_eumap(){truste=self.truste||{};truste.eu||(truste.eu={});var f=truste.eu.bindMap={v
[1:1:0712/104815.512620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[128118:128118:0712/104815.533412:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/104815.534040:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1dc860da2820
[1:1:0712/104815.534283:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/104815.538678:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[128118:128118:0712/104815.541005:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: trustarc_notice, 4, 4, 
[1:1:0712/104815.542132:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104815.542752:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/104815.566001:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/104815.566275:INFO:render_frame_impl.cc(7019)] 	 [url] = https://docs.oracle.com
[128118:128118:0712/104815.567916:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://docs.oracle.com/
[1:1:0712/104815.570913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x1a7bdf7029c8, 0x1dc860c0e1a8
[1:1:0712/104815.571136:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 30000
[1:1:0712/104815.571508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 767
[1:1:0712/104815.571764:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 767 0x7f4d7478a070 0x1dc860f63ce0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 741 0x7f4d766b22e0 0x1dc8609f6ee0 
[128118:128118:0712/104815.581390:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128118:128118:0712/104815.583071:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128118:128130:0712/104815.603457:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[128118:128118:0712/104815.603503:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://consent-st.trustarc.com/
[128118:128118:0712/104815.603547:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://consent-st.trustarc.com/, https://consent-st.trustarc.com/get?name=crossdomain.html&domain=oracle.com, 4
[128118:128130:0712/104815.603552:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[128118:128118:0712/104815.603608:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://consent-st.trustarc.com/, HTTP/1.1 200 status:200 content-type:text/html;charset=UTF-8 date:Fri, 28 Jun 2019 09:06:11 GMT server:nginx access-control-allow-origin:* pragma:public expires:Sun, 28 Jul 2019 09:06:11 GMT cache-control:max-age=2592000 x-frame-options:ALLOWALL content-encoding:gzip vary:Accept-Encoding age:1240496 x-cache:Hit from cloudfront via:1.1 a8207f715b2e293d5549c16cefbce66e.cloudfront.net (CloudFront) x-amz-cf-pop:DEN50-C1 x-amz-cf-id:McRnlAwZlRSSFBwGBtPMYZAzaCcDZkxGGE55TEQMaOquY-XLhQ6WQQ==  ,128231, 6
[1:7:0712/104815.607410:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/104815.641874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://docs.oracle.com/en/"
[1:1:0712/104815.643860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , q.handle, (b){return"undefined"!=typeof r&&r.event.triggered!==b.type?r.event.dispatch.apply(a,arguments):void
[1:1:0712/104815.644146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[128118:128118:0712/104815.665136:INFO:CONSOLE(21)] "Uncaught Error: cannot call methods on autocomplete prior to initialization; attempted to call method 'close'", source: https://docs.oracle.com/en/assets/js/jquery.js (21)
[1:1:0712/104815.950566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104815.950876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104816.650068:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://consent-st.trustarc.com/
[1:1:0712/104816.871175:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 778, "https://docs.oracle.com/en/"
[1:1:0712/104816.873463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , function _truste_eumap(){truste=self.truste||{};truste.eu||(truste.eu={});var f=truste.eu.bindMap={v
[1:1:0712/104816.873700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104816.926913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x1a7bdf7029c8, 0x1dc860c0e1a0
[1:1:0712/104816.927223:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 30000
[1:1:0712/104816.927616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 800
[1:1:0712/104816.927916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7f4d7478a070 0x1dc861ae25e0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 778
[1:1:0712/104816.976056:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[128118:128118:0712/104816.978013:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/104816.979781:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1dc860da0a20
[1:1:0712/104816.980034:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[128118:128118:0712/104816.986500:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/104817.000401:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/104817.000642:INFO:render_frame_impl.cc(7019)] 	 [url] = https://docs.oracle.com
[128118:128118:0712/104817.003037:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://docs.oracle.com/
[1:1:0712/104817.014726:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.085417, 392, 1
[1:1:0712/104817.014994:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104817.063795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104817.064090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104817.257530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 785 0x7f4d766b22e0 0x1dc861d2f760 , "https://docs.oracle.com/en/"
[1:1:0712/104817.263175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , function _truste_eu(){function t(){var g=truste.eu.bindMap;if(!t.done&&(!g.feat.crossDomain||g.feat.
[1:1:0712/104817.263495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104817.559443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x1a7bdf7029c8, 0x1dc860c0e160
[1:1:0712/104817.559710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 4500
[1:1:0712/104817.560132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 852
[1:1:0712/104817.560396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f4d7478a070 0x1dc861f2bce0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 785 0x7f4d766b22e0 0x1dc861d2f760 
[1:1:0712/104817.611382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 786 0x7f4d766b22e0 0x1dc8609aeee0 , "https://docs.oracle.com/en/"
[1:1:0712/104817.613814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , function _truste_eu(){function t(){var g=truste.eu.bindMap;if(!t.done&&(!g.feat.crossDomain||g.feat.
[1:1:0712/104817.614092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104817.645848:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x26ffed90aa38
[1:1:0712/104817.685653:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104817.685933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 4500
[1:1:0712/104817.686316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 870
[1:1:0712/104817.686579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f4d7478a070 0x1dc860abe860 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 786 0x7f4d766b22e0 0x1dc8609aeee0 
[128118:128118:0712/104818.083064:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://consent-st.trustarc.com/, https://consent-st.trustarc.com/, 4
[128118:128118:0712/104818.083177:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://consent-st.trustarc.com/, https://consent-st.trustarc.com
[1:1:0712/104818.083765:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[128118:128118:0712/104819.046079:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128118:128118:0712/104819.052181:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128118:128130:0712/104819.085414:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 5
[128118:128130:0712/104819.085519:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 5, HandleIncomingMessage, HandleIncomingMessage
[128118:128118:0712/104819.085668:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://ora-java.custhelp.com/
[128118:128118:0712/104819.085746:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://ora-java.custhelp.com/, https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN, 5
[128118:128118:0712/104819.085919:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:5_https://ora-java.custhelp.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:48:18 GMT Server: Apache Strict-Transport-Security: max-age=15724800 Set-Cookie: cp_session=fUKquuUajT5dHw6zZnSraaGINHMISnPzdQeXvIgubBUHihaSLQTAmv0tOgKJLOaH_Rmtiyqs_LyBpyxwBDmFPPKq%7EvUbcZGU4sRMIKbNRpZJLtPUcMClXHHN_p3Ao2JVURBc8aNpeF0JuWoxEYZSb1%7ErLfs5EjWTfQcVQscKJzDSw1flc_Qa0r1m1g7_6UUsCbC7ToZzFmmRV9i4kTv5q6QbgweN5C4RCkSK6PjNlbcOaDP%7E%7ERiIMkohwTChnRz4fEgo2buxbNK11H9mleBDikFH1iBzImai4IWZgK4P85ZisGjlwFd%7EKDQ1jAHVWwhSKSsU1sjSYD1x2Zcaor5O%7EXCRv1M%7EpInu2dWDyVsmBXkvaVqmXbQ6kYny3_vXaChxP%7E5dYue4uGsYMG8Jh51SnSK%7Ey6yUp1NfDL; path=/; secure; httponly RNT-Time: D=270297 t=1562953698543882 RNT-Machine: 0.73 Content-Encoding: gzip Content-Length: 3040 Keep-Alive: timeout=15, max=99 Connection: Keep-Alive Content-Type: text/html; charset=UTF-8  ,128231, 6
[1:7:0712/104819.088100:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/104819.716493:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104819.716753:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://docs.oracle.com/en/"
[1:1:0712/104819.717839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , g, (j){if(document.getElementById(e)){d.disconnect();
h()}}
[1:1:0712/104819.718085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104819.721358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 820 0x7f4d7478a070 0x1dc861e31160 , "https://docs.oracle.com/en/"
[1:1:0712/104819.805675:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://docs.oracle.com/en/"
[1:1:0712/104819.807576:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://docs.oracle.com/en/"
[1:1:0712/104819.809777:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 820 0x7f4d7478a070 0x1dc861e31160 , "https://docs.oracle.com/en/"
[1:1:0712/104819.822758:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 820 0x7f4d7478a070 0x1dc861e31160 , "https://docs.oracle.com/en/"
[1:1:0712/104819.827719:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://docs.oracle.com/en/"
[1:1:0712/104819.834922:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e210
[1:1:0712/104819.835165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104819.835526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 925
[1:1:0712/104819.835753:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7f4d7478a070 0x1dc861e28b60 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 820 0x7f4d7478a070 0x1dc861e31160 
[1:1:0712/104819.836612:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e210
[1:1:0712/104819.836803:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104819.837252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 926
[1:1:0712/104819.837500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7f4d7478a070 0x1dc860abba60 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 820 0x7f4d7478a070 0x1dc861e31160 
[1:1:0712/104819.838209:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e210
[1:1:0712/104819.838607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104819.838974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 927
[1:1:0712/104819.839202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 927 0x7f4d7478a070 0x1dc8609aee60 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 820 0x7f4d7478a070 0x1dc861e31160 
[1:1:0712/104819.839946:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e210
[1:1:0712/104819.840235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104819.840713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 928
[1:1:0712/104819.840983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 928 0x7f4d7478a070 0x1dc8619870e0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 820 0x7f4d7478a070 0x1dc861e31160 
[1:1:0712/104819.842048:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e210
[1:1:0712/104819.842251:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104819.842594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 929
[1:1:0712/104819.842813:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f4d7478a070 0x1dc860ea13e0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 820 0x7f4d7478a070 0x1dc861e31160 
[1:1:0712/104819.843541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e210
[1:1:0712/104819.843729:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104819.844140:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 930
[1:1:0712/104819.844361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 930 0x7f4d7478a070 0x1dc861fcaa60 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 820 0x7f4d7478a070 0x1dc861e31160 
[1:1:0712/104819.844735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://docs.oracle.com/en/"
[1:1:0712/104820.052881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104820.053189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104821.963488:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104822.424927:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:5_https://ora-java.custhelp.com/
[1:1:0712/104822.859610:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 925, 7f4d770cf881
[1:1:0712/104822.875641:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104822.876045:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104822.876458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104822.877080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104822.877299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104822.888506:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104822.888744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104822.889175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 994
[1:1:0712/104822.889413:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7f4d7478a070 0x1dc862284860 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 925 0x7f4d7478a070 0x1dc861e28b60 
[1:1:0712/104822.891690:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 926, 7f4d770cf881
[1:1:0712/104822.938701:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104822.939103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104822.939538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104822.940184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104822.940402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104822.967673:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104822.967980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104822.968365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 996
[1:1:0712/104822.968595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 996 0x7f4d7478a070 0x1dc861e71be0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 926 0x7f4d7478a070 0x1dc860abba60 
[1:1:0712/104822.970538:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 927, 7f4d770cf881
[1:1:0712/104823.002556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104823.002938:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104823.003340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104823.003962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104823.004193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[128118:128118:0712/104823.516256:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/104823.608608:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104823.608869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104823.609295:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1003
[1:1:0712/104823.609541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f4d7478a070 0x1dc86224ab60 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 927 0x7f4d7478a070 0x1dc8609aee60 
[1:1:0712/104823.700351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104823.700633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104823.704155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 928, 7f4d770cf881
[1:1:0712/104823.753104:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104823.753482:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104823.753898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104823.754492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104823.754736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104823.808143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104823.808407:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104823.808790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1008
[1:1:0712/104823.809039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1008 0x7f4d7478a070 0x1dc861e9aae0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 928 0x7f4d7478a070 0x1dc8619870e0 
[1:1:0712/104823.811077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 929, 7f4d770cf881
[1:1:0712/104823.859003:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104823.859401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104823.859795:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104823.860415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104823.860631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104824.609312:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104824.609590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104824.609961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1011
[1:1:0712/104824.610208:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1011 0x7f4d7478a070 0x1dc862241560 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 929 0x7f4d7478a070 0x1dc860ea13e0 
[1:1:0712/104824.613886:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 930, 7f4d770cf881
[1:1:0712/104824.650951:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104824.651330:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"820 0x7f4d7478a070 0x1dc861e31160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104824.651806:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104824.652435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104824.652655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104824.662522:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 1500000
[1:1:0712/104824.662939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://docs.oracle.com/, 1022
[1:1:0712/104824.663202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7f4d7478a070 0x1dc86223d260 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 930 0x7f4d7478a070 0x1dc861fcaa60 
[1:1:0712/104824.676506:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104824.676777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104824.677168:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1023
[1:1:0712/104824.677445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f4d7478a070 0x1dc861fd1de0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 930 0x7f4d7478a070 0x1dc861fcaa60 
[1:1:0712/104825.211325:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104825.211609:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://consent-st.trustarc.com/get?name=crossdomain.html&domain=oracle.com"
[1:1:0712/104825.214336:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 969 0x7f4d7478a070 0x1dc86222ece0 , "https://consent-st.trustarc.com/get?name=crossdomain.html&domain=oracle.com"
[1:1:0712/104825.217323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://consent-st.trustarc.com/, 03a4274c33e0, , , !function(){var e,t,a,r,n,s="truste.consent.",i=function(e){var t,a={},e=a._url=e;if(e=(a._query=e.r
[1:1:0712/104825.217622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://consent-st.trustarc.com/get?name=crossdomain.html&domain=oracle.com", "consent-st.trustarc.com", 4, 1, https://docs.oracle.com, docs.oracle.com, 3
[1:1:0712/104825.255568:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 852, 7f4d770cf881
[1:1:0712/104825.291972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"785 0x7f4d766b22e0 0x1dc861d2f760 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104825.292366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"785 0x7f4d766b22e0 0x1dc861d2f760 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104825.292995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104825.293589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , (){b.feat.isConsentRetrieved=!0;t()}
[1:1:0712/104825.293811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104825.330944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 870, 7f4d770cf881
[1:1:0712/104825.366517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"786 0x7f4d766b22e0 0x1dc8609aeee0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104825.366873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"786 0x7f4d766b22e0 0x1dc8609aeee0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104825.367299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104825.367876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , (){b.feat.isConsentRetrieved=!0;t()}
[1:1:0712/104825.368096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104825.832397:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7f4d766b22e0 0x1dc861e2a160 , "https://docs.oracle.com/en/"
[1:1:0712/104825.835087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , /*!
######################################################
# ORA_CODE_DOCS.JS
# VERSION: 1.11
# 
[1:1:0712/104825.835500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104825.871970:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e1e0
[1:1:0712/104825.872271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104825.872783:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1052
[1:1:0712/104825.873095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1052 0x7f4d7478a070 0x1dc8628e75e0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 991 0x7f4d766b22e0 0x1dc861e2a160 
[1:1:0712/104825.945745:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 992 0x7f4d766b22e0 0x1dc86222e2e0 , "https://docs.oracle.com/en/"
[1:1:0712/104825.953226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , /*!
######################################################
# ORA_CODE.JS - v1.73
# BUILD DATE: 25 Ap
[1:1:0712/104825.953515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
		remove user.11_5ea5b0c0 -> 0
		remove user.12_807cc5f7 -> 0
		remove user.13_5bc35032 -> 0
[1:1:0712/104826.408054:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1a7bdf7029c8, 0x1dc860c0e290
[1:1:0712/104826.408232:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 5000
[1:1:0712/104826.408427:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1077
[1:1:0712/104826.408542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7f4d7478a070 0x1dc861e713e0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 992 0x7f4d766b22e0 0x1dc86222e2e0 
[1:1:0712/104826.466030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 994, 7f4d770cf881
[1:1:0712/104826.516442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"925 0x7f4d7478a070 0x1dc861e28b60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104826.516860:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"925 0x7f4d7478a070 0x1dc861e28b60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104826.517299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104826.517866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104826.518098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104826.523538:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 996, 7f4d770cf881
[1:1:0712/104826.545232:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"926 0x7f4d7478a070 0x1dc860abba60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104826.545650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"926 0x7f4d7478a070 0x1dc860abba60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104826.546123:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104826.546819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104826.547093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/104826.768700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://docs.oracle.com/en/"
[1:1:0712/104826.770216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/104826.770464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104826.788011:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e300
[1:1:0712/104826.788294:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104826.788688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1100
[1:1:0712/104826.788940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7f4d7478a070 0x1dc862215ae0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 1002
[1:1:0712/104826.844898:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1003, 7f4d770cf881
[1:1:0712/104826.869847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"927 0x7f4d7478a070 0x1dc8609aee60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104826.870237:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"927 0x7f4d7478a070 0x1dc8609aee60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104826.870674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104826.871374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104826.871595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104826.974068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104826.974314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104826.978186:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1008, 7f4d770cf881
[1:1:0712/104827.025952:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"928 0x7f4d7478a070 0x1dc8619870e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104827.026304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"928 0x7f4d7478a070 0x1dc8619870e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104827.026707:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104827.027288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104827.027519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104827.336550:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/104827.336867:INFO:render_frame_impl.cc(7019)] 	 [url] = https://docs.oracle.com
[128118:128118:0712/104827.339420:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://docs.oracle.com/
[1:1:0712/104827.398685:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1011, 7f4d770cf881
[1:1:0712/104827.448522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"929 0x7f4d7478a070 0x1dc860ea13e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104827.448890:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"929 0x7f4d7478a070 0x1dc860ea13e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104827.449311:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104827.449896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104827.450146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104827.455811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1023, 7f4d770cf881
[1:1:0712/104827.475542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"930 0x7f4d7478a070 0x1dc861fcaa60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104827.475915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"930 0x7f4d7478a070 0x1dc861fcaa60 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104827.476336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104827.476946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104827.477183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104827.723279:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[1:1:0712/104827.724785:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 6:3_https://docs.oracle.com/, 6:4_https://consent-st.trustarc.com/
[1:1:0712/104827.725029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , msgListener, (a){var d=[(truste.eu.bindMap&&truste.eu.bindMap.prefmgrUrl.match(/^.{3,5}:\/\/[^\/]*/)||["*"])[0],s
[1:1:0712/104827.725254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104827.731900:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[1:1:0712/104827.735032:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[1:1:0712/104827.737986:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[1:1:0712/104827.814173:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[1:1:0712/104827.814923:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 6:3_https://docs.oracle.com/, 6:4_https://consent-st.trustarc.com/
[1:1:0712/104827.815156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , msgListener, (a){var d=[(truste.eu.bindMap&&truste.eu.bindMap.prefmgrUrl.match(/^.{3,5}:\/\/[^\/]*/)||["*"])[0],s
[1:1:0712/104827.815376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104827.818198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[1:1:0712/104827.819479:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[1:1:0712/104827.822321:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://docs.oracle.com/en/"
[128118:128118:0712/104827.892678:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128118:128118:0712/104827.898096:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128118:128130:0712/104827.925738:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 5
[128118:128130:0712/104827.925837:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 5, HandleIncomingMessage, HandleIncomingMessage
[128118:128118:0712/104827.926093:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://ora-java.custhelp.com/
[128118:128118:0712/104827.926208:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://ora-java.custhelp.com/, https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN, 5
[128118:128118:0712/104827.926330:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:5_https://ora-java.custhelp.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:48:27 GMT Server: Apache Strict-Transport-Security: max-age=15724800 Set-Cookie: cp_session=fUBTAlhfuLipLXaAs%7E%7Eeozp3hrkpkFd1ahHycyA2HZ5VJoKhZScRnTHxTM6OK3vIrKQS8z%7Ens6cs3ZblTtmEepDtObpkOyybWQiQRQ6NUBJqjiE%7EJ9g9togk9rvlZRM6YvYt_YTBPy2LzoBFHilhdBulTYYDFayi5tlmljVe%7Eep5357dPxDVOf6qV_bse_n3vfg7nkedCBONT5LuvalWr6p3MvKN0pgdQlcHvVajkIKCkr%7Eo_ovEMXaOlOq_YOKwnDlUXH5tRKUpq8MkhdiPlnlPfg9p0uJRLZk5CYJCbRH83pHg2r9EsuWqj09flYLzcG6WXfYqlKyNd0pV4mmnwV1kyXfsShvXrq2ddpaHrW2Bk5ByNZbhsNOyJ2VgjloMB1RxHEDmADfEUClj4gFiIiT_M4soC5gJCB; path=/; secure; httponly RNT-Time: D=220765 t=1562953707442855 RNT-Machine: 0.78 Content-Encoding: gzip Content-Length: 3042 Keep-Alive: timeout=15, max=96 Connection: Keep-Alive Content-Type: text/html; charset=UTF-8  ,128231, 6
[1:7:0712/104827.955426:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/104827.956528:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1052, 7f4d770cf881
[1:1:0712/104828.005403:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"991 0x7f4d766b22e0 0x1dc861e2a160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104828.005760:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"991 0x7f4d766b22e0 0x1dc861e2a160 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104828.006186:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104828.006870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104828.007118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104828.039530:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104828.039862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104828.040296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1123
[1:1:0712/104828.040541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7f4d7478a070 0x1dc862231060 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 1052 0x7f4d7478a070 0x1dc8628e75e0 
[1:1:0712/104829.349528:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1100, 7f4d770cf881
[1:1:0712/104829.398785:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"1002","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104829.399159:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"1002","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104829.399587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104829.400212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104829.400453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104830.384687:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104830.384998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104830.385349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1137
[1:1:0712/104830.385541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1137 0x7f4d7478a070 0x1dc861f25360 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 1100 0x7f4d7478a070 0x1dc862215ae0 
[1:1:0712/104830.490664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104830.490873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104830.900709:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:5_https://ora-java.custhelp.com/
[1:1:0712/104830.976077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1123, 7f4d770cf881
[1:1:0712/104831.026977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"1052 0x7f4d7478a070 0x1dc8628e75e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104831.027290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"1052 0x7f4d7478a070 0x1dc8628e75e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104831.027641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104831.028201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104831.028384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104831.326117:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1137, 7f4d770cf881
[1:1:0712/104831.342360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"1100 0x7f4d7478a070 0x1dc862215ae0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104831.342569:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"1100 0x7f4d7478a070 0x1dc862215ae0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104831.342789:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104831.343127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104831.343239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104831.344902:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104831.345014:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 0
[1:1:0712/104831.345217:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1171
[1:1:0712/104831.345339:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1171 0x7f4d7478a070 0x1dc861e9bfe0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 1137 0x7f4d7478a070 0x1dc861f25360 
[1:1:0712/104831.465103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104831.465411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[128118:128118:0712/104831.555455:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://ora-java.custhelp.com/, https://ora-java.custhelp.com/, 5
[128118:128118:0712/104831.555599:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://ora-java.custhelp.com/, https://ora-java.custhelp.com
[1:1:0712/104831.558847:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/104831.775459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1171, 7f4d770cf881
[1:1:0712/104831.827086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"1137 0x7f4d7478a070 0x1dc861f25360 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104831.827424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"1137 0x7f4d7478a070 0x1dc861f25360 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104831.827808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104831.828389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/104831.828571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104833.925188:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1a7bdf7029c8, 0x1dc860c0e150
[1:1:0712/104833.925370:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://docs.oracle.com/en/", 100
[1:1:0712/104833.925555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1205
[1:1:0712/104833.925667:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1205 0x7f4d7478a070 0x1dc861f0bae0 , 6:3_https://docs.oracle.com/, 1, -6:3_https://docs.oracle.com/, 1171 0x7f4d7478a070 0x1dc861e9bfe0 
[1:1:0712/104834.276560:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1077, 7f4d770cf881
[1:1:0712/104834.332618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"992 0x7f4d766b22e0 0x1dc86222e2e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104834.332844:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"992 0x7f4d766b22e0 0x1dc86222e2e0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104834.333290:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104834.333951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , (){b.G&&(b.complete?b.va():(a.trackOffline&&b.abort&&b.abort(),b.Ha()));}
[1:1:0712/104834.334176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104834.365414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104834.365634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104834.426840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , () {
                        if(window.getComputedStyle(link, null).visibility === 'visible') {
    
[1:1:0712/104834.427123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104834.707806:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/104835.396510:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://docs.oracle.com/, 1205, 7f4d770cf881
[1:1:0712/104835.418950:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a427402860","ptid":"1171 0x7f4d7478a070 0x1dc861e9bfe0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104835.419403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://docs.oracle.com/","ptid":"1171 0x7f4d7478a070 0x1dc861e9bfe0 ","rf":"6:3_https://docs.oracle.com/"}
[1:1:0712/104835.419853:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://docs.oracle.com/en/"
[1:1:0712/104835.420564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , () {
                        return equalHeights() && shiftToolPop() && shiftMegaMenu();
           
[1:1:0712/104835.420825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104835.753900:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://docs.oracle.com/en/"
[1:1:0712/104835.754802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , b.onload.b.va, (){a.bb(c);b.Da();a.sb();a.ga();a.q=0;a.ka();if(b.Ba){b.Ba=!1;try{a.doPostbacks(a.X(b.responseText))
[1:1:0712/104835.755041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104835.797557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , document.readyState
[1:1:0712/104835.797883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104836.411207:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/104836.411452:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN"
[1:1:0712/104836.662804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://docs.oracle.com/, 03a427402860, , , () {
                                $u02.find(classSelector(CLS_PADDED)).removeClass(CLS_PADDED);
 
[1:1:0712/104836.663061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://docs.oracle.com/en/", "docs.oracle.com", 3, 1, , , 0
[1:1:0712/104838.279378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1296 0x7f4d74af2bd0 0x1dc863f14758 , "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN"
[1:1:0712/104838.283154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:5_https://ora-java.custhelp.com/, 03a4274d1958, , , // ----------------------------------------------------------------------------
//       File Name: 
[1:1:0712/104838.283391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN", "ora-java.custhelp.com", 5, 1, https://docs.oracle.com, docs.oracle.com, 3
[1:1:0712/104838.287005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1296 0x7f4d74af2bd0 0x1dc863f14758 , "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN"
[1:1:0712/104838.307188:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1296 0x7f4d74af2bd0 0x1dc863f14758 , "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN"
[1:1:0712/104839.277601:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1322 0x7f4d74af2bd0 0x1dc861d4e058 , "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN"
[1:1:0712/104839.280288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:5_https://ora-java.custhelp.com/, 03a4274d1958, , , /*! jQuery v2.1.4 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"o
[1:1:0712/104839.280447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN", "ora-java.custhelp.com", 5, 1, https://docs.oracle.com, docs.oracle.com, 3
[1:1:0712/104839.386136:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1322 0x7f4d74af2bd0 0x1dc861d4e058 , "https://ora-java.custhelp.com/ci/documents/detail/5/2573/12/44094e13fc9b4657e63934ebc4cd31c019aa93a5?locale=EN"
