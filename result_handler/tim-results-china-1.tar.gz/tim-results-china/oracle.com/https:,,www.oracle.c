[0712/105306.177878:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105306.178204:INFO:switcher_clone.cc(787)] backtrace rip is 7f8cda851891
[0712/105307.113288:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105307.113576:INFO:switcher_clone.cc(787)] backtrace rip is 7f813c345891
[1:1:0712/105307.117565:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/105307.117763:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/105307.123219:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/105308.496937:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105308.497299:INFO:switcher_clone.cc(787)] backtrace rip is 7f0796f36891
[128793:128793:0712/105308.632826:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f75e3ccb-8c5d-4f15-88db-b3853ce3ed29
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[128825:128825:0712/105308.742819:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128825
[128838:128838:0712/105308.743212:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128838
[128793:128793:0712/105309.097991:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[128793:128823:0712/105309.098970:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/105309.099259:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/105309.099543:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/105309.100233:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/105309.100449:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/105309.103537:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x78195d0, 1
[1:1:0712/105309.103918:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1cffef4e, 0
[1:1:0712/105309.104169:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf12f8d5, 3
[1:1:0712/105309.104369:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x20bae281, 2
[1:1:0712/105309.104596:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4effffffefffffffff1c ffffffd0ffffff95ffffff8107 ffffff81ffffffe2ffffffba20 ffffffd5fffffff8120f , 10104, 4
[1:1:0712/105309.105824:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128793:128823:0712/105309.106079:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGN��Е��� ��x��"
[128793:128823:0712/105309.106160:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is N��Е��� ��xEx��"
[1:1:0712/105309.106308:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f813a5800a0, 3
[128793:128823:0712/105309.106527:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/105309.106562:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f813a70b080, 2
[128793:128823:0712/105309.106606:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128846, 4, 4eefff1c d0958107 81e2ba20 d5f8120f 
[1:1:0712/105309.106777:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f81243ced20, -2
[1:1:0712/105309.129042:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/105309.129909:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20bae281
[1:1:0712/105309.130861:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20bae281
[1:1:0712/105309.132477:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20bae281
[1:1:0712/105309.133923:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.134133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.134327:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.134515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.135152:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20bae281
[1:1:0712/105309.135502:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f813c3457ba
[1:1:0712/105309.135632:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f813c33cdef, 7f813c34577a, 7f813c3470cf
[1:1:0712/105309.141298:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20bae281
[1:1:0712/105309.141640:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20bae281
[1:1:0712/105309.142411:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20bae281
[1:1:0712/105309.144431:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.144623:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.144830:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.145014:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20bae281
[1:1:0712/105309.146275:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20bae281
[1:1:0712/105309.146638:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f813c3457ba
[1:1:0712/105309.146774:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f813c33cdef, 7f813c34577a, 7f813c3470cf
[1:1:0712/105309.154438:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/105309.154856:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/105309.155004:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe56c0a368, 0x7ffe56c0a2e8)
[1:1:0712/105309.170396:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/105309.176194:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[128793:128793:0712/105309.748952:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128793:128793:0712/105309.750134:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128793:128805:0712/105309.769135:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[128793:128805:0712/105309.769263:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[128793:128793:0712/105309.769445:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[128793:128793:0712/105309.769544:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[128793:128793:0712/105309.769735:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,128846, 4
[1:7:0712/105309.774717:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[128793:128816:0712/105309.805930:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/105309.900503:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2d8304e9b220
[1:1:0712/105309.900895:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/105310.341587:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[128793:128793:0712/105312.119518:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[128793:128793:0712/105312.119682:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/105312.180054:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105312.183646:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/105313.340452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c1ca6e61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/105313.340649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105313.346270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c1ca6e61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/105313.346482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105313.384427:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105313.545171:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105313.545407:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105313.795830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105313.803589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c1ca6e61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/105313.803793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105313.836722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105313.846563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c1ca6e61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/105313.846812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105313.858628:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/105313.862239:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2d8304e99e20
[1:1:0712/105313.862451:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[128793:128793:0712/105313.862668:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[128793:128793:0712/105313.870086:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[128793:128793:0712/105313.894506:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[128793:128793:0712/105313.894598:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/105313.964025:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105314.908277:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f8125fa92e0 0x2d8304ffdb60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105314.909274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c1ca6e61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/105314.910403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105314.913923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128793:128793:0712/105314.995978:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/105314.996495:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2d8304e9a820
[1:1:0712/105314.996703:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/105315.015466:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/105315.015665:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[128793:128793:0712/105315.018882:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[128793:128793:0712/105315.036754:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[128793:128793:0712/105315.044176:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128793:128793:0712/105315.045252:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128793:128805:0712/105315.051947:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[128793:128805:0712/105315.052035:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[128793:128793:0712/105315.052238:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[128793:128793:0712/105315.052322:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[128793:128793:0712/105315.052463:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,128846, 4
[1:7:0712/105315.061521:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105315.709308:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/105316.305322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f8125fa92e0 0x2d830524b560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105316.307175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c1ca6e61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/105316.307609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105316.309180:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128793:128793:0712/105316.459124:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[128793:128793:0712/105316.459243:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/105316.491592:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[128793:128793:0712/105316.751426:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[128793:128823:0712/105316.751960:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/105316.752182:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/105316.752679:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/105316.753394:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/105316.753756:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/105316.758400:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2f8d3b56, 1
[1:1:0712/105316.758897:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2623b65c, 0
[1:1:0712/105316.759266:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1965ab71, 3
[1:1:0712/105316.759629:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ccddc27, 2
[1:1:0712/105316.759894:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5cffffffb62326 563bffffff8d2f 27ffffffdcffffffcd1c 71ffffffab6519 , 10104, 5
[1:1:0712/105316.761710:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128793:128823:0712/105316.762186:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING\�#&V;�/'��q�e���"
[128793:128823:0712/105316.762306:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is \�#&V;�/'��q�e(���"
[128793:128823:0712/105316.762773:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128890, 5, 5cb62326 563b8d2f 27dccd1c 71ab6519 
[1:1:0712/105316.763324:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f813a5800a0, 3
[1:1:0712/105316.763808:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f813a70b080, 2
[1:1:0712/105316.764187:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f81243ced20, -2
[1:1:0712/105316.791315:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/105316.795431:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ccddc27
[1:1:0712/105316.795805:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ccddc27
[1:1:0712/105316.796507:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ccddc27
[1:1:0712/105316.797790:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.798014:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.798237:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.798503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.799215:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ccddc27
[1:1:0712/105316.799735:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f813c3457ba
[1:1:0712/105316.799942:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f813c33cdef, 7f813c34577a, 7f813c3470cf
[1:1:0712/105316.806359:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ccddc27
[1:1:0712/105316.806780:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ccddc27
[1:1:0712/105316.807564:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ccddc27
[1:1:0712/105316.809640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.809904:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.810130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.810372:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ccddc27
[1:1:0712/105316.811645:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ccddc27
[1:1:0712/105316.812056:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f813c3457ba
[1:1:0712/105316.812228:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f813c33cdef, 7f813c34577a, 7f813c3470cf
[1:1:0712/105316.819973:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/105316.820622:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/105316.820813:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe56c0a368, 0x7ffe56c0a2e8)
[1:1:0712/105316.835095:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/105316.839288:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/105317.026096:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105317.122637:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2d8304e74220
[1:1:0712/105317.122928:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/105317.633009:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105317.633279:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[128793:128793:0712/105317.922978:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128793:128793:0712/105317.934321:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128793:128805:0712/105317.984555:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[128793:128805:0712/105317.984658:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[128793:128793:0712/105317.985295:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.oracle.com/
[128793:128793:0712/105317.985394:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.oracle.com/, https://www.oracle.com/corporate/contact/help.html, 1
[128793:128793:0712/105317.985555:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.oracle.com/, HTTP/1.1 200 status:200 server:Oracle-HTTP-Server last-modified:Wed, 26 Jun 2019 14:00:17 GMT x-oracle-dms-ecid:005Z4^Hrbjy9Pdw70FYBUF0002WT000IGn custom_cache_rule_location:AssetTypeLevel device_type:Any x-content-type-options:nosniff host_service:FutureTenseContentServer:12c custom_akamai_autopurge:YES x-oracle-dms-rid:0:1 content-language:en-US content-type:text/html; charset=UTF-8 origin-cache-control:max-age=1800 origin-edge-control:!no-store,max-age=2592000,downstream-ttl=1800 x-akamai-transformed:9 - 0 pmb=mRUM,2 vary:Accept-Encoding content-encoding:gzip cache-control:max-age=1800 date:Fri, 12 Jul 2019 17:53:17 GMT content-length:8990 server-timing:cdn-cache; desc=HIT server-timing:edge; dur=0 x-frame-options:sameorigin content-security-policy:frame-ancestors 'self' https://explore.oracle.com x-xss-protection:1 actual-object-ttl:2592000  ,128890, 5
[1:7:0712/105317.991525:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105318.016068:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.oracle.com/
[1:1:0712/105318.079624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105318.084400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1c1ca6f8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/105318.084731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105318.093266:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[128793:128793:0712/105318.157300:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.oracle.com/, https://www.oracle.com/, 1
[128793:128793:0712/105318.157383:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.oracle.com/, https://www.oracle.com
[1:1:0712/105318.197066:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/105318.320642:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105318.430664:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105318.430944:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.oracle.com/corporate/contact/help.html"
[1:1:0712/105318.447236:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105318.448030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1c1ca6e61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/105318.448247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105318.460740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 136 0x7f8124081070 0x2d8304f3dd60 , "https://www.oracle.com/corporate/contact/help.html"
[1:1:0712/105318.461961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.oracle.com/, 04030e2a2860, , , 
		var pageData = pageData || {};
		//page info
		pageData.pageInfo = pageData.pageInfo || {};
		pag
[1:1:0712/105318.462127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.oracle.com/corporate/contact/help.html", "www.oracle.com", 3, 1, , , 0
[1:1:0712/105318.463596:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 136 0x7f8124081070 0x2d8304f3dd60 , "https://www.oracle.com/corporate/contact/help.html"
[1:1:0712/105318.487911:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 136 0x7f8124081070 0x2d8304f3dd60 , "https://www.oracle.com/corporate/contact/help.html"
[1:1:0712/105318.695247:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/105321.209121:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 257 0x7f8124081070 0x2d830511f5e0 , "https://www.oracle.com/corporate/contact/help.html"
[1:1:0712/105321.209926:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105321.222515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.oracle.com/, 04030e2a2860, , , /*!
######################################################

# JQUERY.JS

# OCOM GLOBAL ASSET RELEASE
[1:1:0712/105321.222792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.oracle.com/corporate/contact/help.html", "www.oracle.com", 3, 1, , , 0
[1:1:0712/105321.599175:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 257 0x7f8124081070 0x2d830511f5e0 , "https://www.oracle.com/corporate/contact/help.html"
		remove user.f_7880ec5e -> 0
[1:1:0712/105322.428032:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x321f379e29c8, 0x2d830483c2e8
[1:1:0712/105322.428325:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.oracle.com/corporate/contact/help.html", 1500
[1:1:0712/105322.428785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.oracle.com/, 267
[1:1:0712/105322.429016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 267 0x7f8124081070 0x2d830538ca60 , 5:3_https://www.oracle.com/, 1, -5:3_https://www.oracle.com/, 257 0x7f8124081070 0x2d830511f5e0 
[1:1:0712/105322.430142:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x321f379e29c8, 0x2d830483c2e8
[1:1:0712/105322.430349:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.oracle.com/corporate/contact/help.html", 2000
[1:1:0712/105322.430778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.oracle.com/, 268
[1:1:0712/105322.431003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 268 0x7f8124081070 0x2d8305391360 , 5:3_https://www.oracle.com/, 1, -5:3_https://www.oracle.com/, 257 0x7f8124081070 0x2d830511f5e0 
[1:1:0712/105322.449340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x321f379e29c8, 0x2d830483c2e8
[1:1:0712/105322.449579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.oracle.com/corporate/contact/help.html", 1
[1:1:0712/105322.450006:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.oracle.com/, 269
[1:1:0712/105322.450231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 269 0x7f8124081070 0x2d830543ee60 , 5:3_https://www.oracle.com/, 1, -5:3_https://www.oracle.com/, 257 0x7f8124081070 0x2d830511f5e0 
[1:1:0712/105327.013436:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105327.013974:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105327.014401:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105327.014923:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105327.015385:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[128793:128793:0712/105342.641882:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/105342.695671:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/105348.801065:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105348.805663:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105350.539542:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 28.9635, 0, 0
[1:1:0712/105350.539875:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105351.054065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.oracle.com/, 04030e2a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/105351.054390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.oracle.com/corporate/contact/help.html", "www.oracle.com", 3, 1, , , 0
[128793:128793:0712/105404.520468:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
