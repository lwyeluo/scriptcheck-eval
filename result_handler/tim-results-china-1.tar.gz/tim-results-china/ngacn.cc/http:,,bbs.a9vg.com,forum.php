[0711/091143.436964:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/091143.437393:INFO:switcher_clone.cc(787)] backtrace rip is 7f046420c891
[0711/091144.335242:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/091144.335653:INFO:switcher_clone.cc(787)] backtrace rip is 7fce15040891
[1:1:0711/091144.347450:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/091144.347747:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/091144.352980:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[28215:28215:0711/091145.372781:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ded410e5-5b40-42f2-83c8-da70361ea7f2
[0711/091145.738656:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/091145.739180:INFO:switcher_clone.cc(787)] backtrace rip is 7fbf91d62891
[28215:28215:0711/091145.767745:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[28215:28244:0711/091145.768629:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/091145.768900:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/091145.769169:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/091145.769914:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/091145.770119:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/091145.776099:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x11054f9b, 1
[1:1:0711/091145.776454:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x18142ad8, 0
[1:1:0711/091145.776620:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x36ef5dd6, 3
[1:1:0711/091145.776778:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2d898866, 2
[1:1:0711/091145.776979:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd82a1418 ffffff9b4f0511 66ffffff88ffffff892d ffffffd65dffffffef36 , 10104, 4
[1:1:0711/091145.777933:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28215:28244:0711/091145.778155:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�*�Of��-�]�6� 
[28215:28244:0711/091145.778225:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �*�Of��-�]�6��� 
[1:1:0711/091145.778378:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce1327b0a0, 3
[28215:28244:0711/091145.778563:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/091145.778564:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce13406080, 2
[28215:28244:0711/091145.778661:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28260, 4, d82a1418 9b4f0511 6688892d d65def36 
[1:1:0711/091145.778718:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcdfd0c9d20, -2
[1:1:0711/091145.796200:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/091145.796827:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d898866
[1:1:0711/091145.797531:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d898866
[1:1:0711/091145.798672:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d898866
[1:1:0711/091145.799258:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.799382:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.799483:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.799578:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.799812:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d898866
[1:1:0711/091145.800266:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce150407ba
[1:1:0711/091145.800451:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce15037def, 7fce1504077a, 7fce150420cf
[1:1:0711/091145.809161:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d898866
[1:1:0711/091145.809658:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d898866
[1:1:0711/091145.810614:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d898866
[1:1:0711/091145.813306:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.813589:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.813845:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.814127:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d898866
[1:1:0711/091145.815812:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d898866
[1:1:0711/091145.816336:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce150407ba
[1:1:0711/091145.816521:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce15037def, 7fce1504077a, 7fce150420cf
[1:1:0711/091145.825028:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/091145.825479:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/091145.825630:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe10e944b8, 0x7ffe10e94438)
[1:1:0711/091145.841183:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/091145.845578:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[28248:28248:0711/091145.994764:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28248
[28272:28272:0711/091145.995276:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=28272
[28215:28215:0711/091146.345655:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28215:28215:0711/091146.346149:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28215:28215:0711/091146.349117:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[28215:28215:0711/091146.349152:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[28215:28215:0711/091146.349208:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,28260, 4
[28215:28226:0711/091146.360104:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[28215:28226:0711/091146.360228:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/091146.376057:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[28215:28239:0711/091146.398743:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/091146.519736:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x9012e4be220
[1:1:0711/091146.520023:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/091146.847662:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[28215:28215:0711/091148.135594:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[28215:28215:0711/091148.135718:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/091148.156924:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/091148.160799:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/091148.945551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36b6adda1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/091148.945885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/091148.977842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36b6adda1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/091148.978169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/091149.007316:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091149.209957:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091149.210204:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[28215:28215:0711/091149.213835:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[28215:28244:0711/091149.214185:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/091149.214366:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/091149.214584:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/091149.215000:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/091149.215170:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/091149.218250:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2a6ee4b5, 1
[1:1:0711/091149.218597:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xa6cd293, 0
[1:1:0711/091149.223468:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2f67399d, 3
[1:1:0711/091149.223638:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26c05e2a, 2
[1:1:0711/091149.223824:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff93ffffffd26c0a ffffffb5ffffffe46e2a 2a5effffffc026 ffffff9d39672f , 10104, 5
[1:1:0711/091149.224810:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[28215:28244:0711/091149.227594:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��l
��n**^�&�9g/�� 
[28215:28244:0711/091149.227687:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��l
��n**^�&�9g/X=�� 
[1:1:0711/091149.227585:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce1327b0a0, 3
[1:1:0711/091149.227799:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce13406080, 2
[28215:28244:0711/091149.227935:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 28310, 5, 93d26c0a b5e46e2a 2a5ec026 9d39672f 
[1:1:0711/091149.227985:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcdfd0c9d20, -2
[1:1:0711/091149.251249:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/091149.251703:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26c05e2a
[1:1:0711/091149.252074:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26c05e2a
[1:1:0711/091149.252838:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26c05e2a
[1:1:0711/091149.254567:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.254864:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.255086:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.255322:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.256133:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26c05e2a
[1:1:0711/091149.256480:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce150407ba
[1:1:0711/091149.256681:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce15037def, 7fce1504077a, 7fce150420cf
[1:1:0711/091149.263408:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26c05e2a
[1:1:0711/091149.263780:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26c05e2a
[1:1:0711/091149.264471:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26c05e2a
[1:1:0711/091149.266384:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.266606:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.266834:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.267011:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26c05e2a
[1:1:0711/091149.268182:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26c05e2a
[1:1:0711/091149.268541:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce150407ba
[1:1:0711/091149.268680:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce15037def, 7fce1504077a, 7fce150420cf
[1:1:0711/091149.274932:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/091149.275281:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/091149.275412:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe10e944b8, 0x7ffe10e94438)
[1:1:0711/091149.287147:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/091149.291707:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/091149.491259:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x9012e488220
[1:1:0711/091149.491413:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/091149.637221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/091149.640734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36b6adda1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/091149.640992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/091149.702079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/091149.712608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36b6adda1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/091149.712895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/091149.727958:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[28215:28215:0711/091149.729531:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/091149.732939:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x9012e4bce20
[1:1:0711/091149.733148:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[28215:28215:0711/091149.738948:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[28215:28215:0711/091149.765767:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28215:28215:0711/091149.770697:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28215:28226:0711/091149.797993:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[28215:28226:0711/091149.798117:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[28215:28215:0711/091149.798611:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://bbs.a9vg.com/
[28215:28215:0711/091149.798700:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://bbs.a9vg.com/, http://bbs.a9vg.com/forum.php, 1
[28215:28215:0711/091149.798880:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://bbs.a9vg.com/, HTTP/1.1 200 OK Server: nginx Date: Thu, 11 Jul 2019 16:11:49 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Vary: Accept-Encoding X-Powered-By: PHP/5.3.3 Set-Cookie: WxSS_a648_saltkey=jJzmiiDD; expires=Sat, 10-Aug-2019 16:11:47 GMT; path=/; domain=.a9vg.com; httponly Set-Cookie: WxSS_a648_lastvisit=1562857907; expires=Sat, 10-Aug-2019 16:11:47 GMT; path=/; domain=.a9vg.com Set-Cookie: WxSS_a648_lastact=1562861507%09forum.php%09; expires=Fri, 12-Jul-2019 16:11:47 GMT; path=/; domain=.a9vg.com Content-Encoding: gzip  ,28310, 5
[1:7:0711/091149.805046:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[28215:28215:0711/091149.817349:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[28215:28215:0711/091149.817489:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/091149.821670:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/091149.845754:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://bbs.a9vg.com/
[28215:28215:0711/091149.955757:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://bbs.a9vg.com/, http://bbs.a9vg.com/, 1
[28215:28215:0711/091149.955816:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://bbs.a9vg.com/, http://bbs.a9vg.com
[1:1:0711/091149.972654:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/091150.042144:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091150.095793:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/091150.168562:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091150.168807:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/forum.php"
[1:1:0711/091150.655715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160 0x7fcdfcd7c070 0x9012e6120e0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091150.658341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , var STYLEID = '2', STATICURL = 'static/', IMGDIR = 'static/image/common', VERHASH = 'YQo', charset =
[1:1:0711/091150.658593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091150.668698:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160 0x7fcdfcd7c070 0x9012e6120e0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091150.701420:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/091150.713822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160 0x7fcdfcd7c070 0x9012e6120e0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091150.744567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160 0x7fcdfcd7c070 0x9012e6120e0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091150.752642:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0917802, 65, 1
[1:1:0711/091150.753040:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091151.140607:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091151.140846:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/forum.php"
[1:1:0711/091151.141720:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7fcdfcd7c070 0x9012e678b60 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091151.142705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , simulateSelect('ls_fastloginfield')
[1:1:0711/091151.142928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091151.176000:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0350029, 77, 1
[1:1:0711/091151.176305:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091151.235923:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_INVALID_ARGUMENT","http://discuz.gtimg.cn/cloud/scripts/discuz_tips.js?v=1"
[1:1:0711/091151.707180:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091151.707375:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/forum.php"
[1:1:0711/091151.709544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fcdfcd7c070 0x9012e66ca60 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091151.713710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , function SG_GG(){var t=new RegExp("(^|&)source=([^&]*)(&|$)","i"),e=window.location.search.substr(1)
[1:1:0711/091151.713885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091151.715282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x881fbae29c8, 0x9012e30e200
[1:1:0711/091151.715435:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 60000
[1:1:0711/091151.715703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 304
[1:1:0711/091151.715857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 304 0x7fcdfcd7c070 0x9012e0e0de0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 269 0x7fcdfcd7c070 0x9012e66ca60 
[1:1:0711/091151.717956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fcdfcd7c070 0x9012e66ca60 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091151.741096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7fcdfcd7c070 0x9012e66ca60 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091151.747790:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0404019, 87, 1
[1:1:0711/091151.747943:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091152.242816:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091152.242986:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/forum.php"
[1:1:0711/091152.243467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 316 0x7fcdfcd7c070 0x9012e1ef0e0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091152.243916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , announcement();
[1:1:0711/091152.244026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091152.664775:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x881fbae29c8, 0x9012e30e1a0
[1:1:0711/091152.665054:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 3000
[1:1:0711/091152.665435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 340
[1:1:0711/091152.665717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 340 0x7fcdfcd7c070 0x9012e6c38e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 316 0x7fcdfcd7c070 0x9012e1ef0e0 
[1:1:0711/091152.677933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 316 0x7fcdfcd7c070 0x9012e1ef0e0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091152.680996:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/091152.685621:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x9012e9e3220
[1:1:0711/091152.685993:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0711/091152.715883:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/091152.716152:INFO:render_frame_impl.cc(7019)] 	 [url] = http://bbs.a9vg.com
[1:1:0711/091152.804637:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.561769, 622, 0
[1:1:0711/091152.804944:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091153.199380:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091153.199676:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/forum.php"
[1:1:0711/091153.567811:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.368057, 2985, 1
[1:1:0711/091153.568102:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091153.655334:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7fcdfeca42e0 0x9012e9ce8e0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091153.656586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , STARGAMEGGCALLBACKFNV2({"PositionLocation":0,"PositionState":1,"PID":"504","PositionType":1,"Locatio
[1:1:0711/091153.656908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091153.684129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.542067:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091154.542273:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.545488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7fcdfcd7c070 0x9012e765560 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.547628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , function SG_GG(){var t=new RegExp("(^|&)source=([^&]*)(&|$)","i"),e=window.location.search.substr(1)
[1:1:0711/091154.547849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091154.548491:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x881fbae29c8, 0x9012e30e1f0
[1:1:0711/091154.548594:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 60000
[1:1:0711/091154.548760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 448
[1:1:0711/091154.548871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 448 0x7fcdfcd7c070 0x9012e338060 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 435 0x7fcdfcd7c070 0x9012e765560 
[1:1:0711/091154.556563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7fcdfcd7c070 0x9012e765560 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.578875:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7fcdfcd7c070 0x9012e765560 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.597152:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7fcdfcd7c070 0x9012e765560 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.619285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7fcdfcd7c070 0x9012e765560 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.727185:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/091154.900737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7fcdfcd7c070 0x9012e765560 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091154.905300:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.362945, 54, 1
[1:1:0711/091154.905539:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091155.322118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/091155.460491:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091155.460793:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/forum.php"
[1:1:0711/091155.463829:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fcdfcd7c070 0x9012e9fbee0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091155.466057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , 
            var flog=true;
    		var btnClose=jQuery('#close');
    		var oLayer=jQuery('#layer');

[1:1:0711/091155.466318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091155.478789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fcdfcd7c070 0x9012e9fbee0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091155.481736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fcdfcd7c070 0x9012e9fbee0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091155.485468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fcdfcd7c070 0x9012e9fbee0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091155.490263:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fcdfcd7c070 0x9012e9fbee0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091155.496525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fcdfcd7c070 0x9012e9fbee0 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091156.160156:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x9012e09de20
[1:1:0711/091156.160433:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0711/091156.210710:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://bbs.a9vg.com/forum.php"
[28215:28215:0711/091156.715910:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[28215:28215:0711/091156.721900:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 3, 
[28215:28215:0711/091156.728042:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://bbs.a9vg.com/
[28215:28215:0711/091156.763441:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[28215:28215:0711/091156.772058:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 4, 
[28215:28215:0711/091156.789011:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://bbs.a9vg.com/, http://bbs.a9vg.com/, 4
[28215:28215:0711/091156.789092:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 6, http://bbs.a9vg.com/, http://bbs.a9vg.com
[3:3:0711/091156.814748:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[28215:28215:0711/091156.900145:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[28215:28215:0711/091156.907020:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28215:28215:0711/091156.915474:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28215:28215:0711/091156.925583:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://bbs.a9vg.com/
[28215:28215:0711/091156.925703:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://bbs.a9vg.com/, http://bbs.a9vg.com/showit/, 3
[28215:28226:0711/091156.925701:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[28215:28226:0711/091156.925833:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[28215:28215:0711/091156.925864:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://bbs.a9vg.com/, HTTP/1.1 200 OK Server: nginx Date: Thu, 11 Jul 2019 16:11:56 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Vary: Accept-Encoding X-Powered-By: PHP/5.3.3 Set-Cookie: img_view_16777094=Y; expires=Sun, 14-Jul-2019 16:11:55 GMT Set-Cookie: img_view_16777089=Y; expires=Sun, 14-Jul-2019 16:11:55 GMT Set-Cookie: img_view_16777110=Y; expires=Sun, 14-Jul-2019 16:11:55 GMT Content-Encoding: gzip  ,28310, 5
[1:7:0711/091156.928564:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/091158.736062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7fcdfeca42e0 0x9012e5b4460 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091158.736947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , 
[1:1:0711/091158.737164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091158.737655:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091158.753826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7fcdfeca42e0 0x9012e1c4360 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091158.758934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , !function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};ret
[1:1:0711/091158.759197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091158.854947:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[28215:28215:0711/091159.037024:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/091159.039140:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x9012e485020
[1:1:0711/091159.039387:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[28215:28215:0711/091159.044222:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 5, 
[1:1:0711/091159.063053:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/091159.063356:INFO:render_frame_impl.cc(7019)] 	 [url] = http://bbs.a9vg.com
[28215:28215:0711/091159.065915:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://bbs.a9vg.com/
[1:1:0711/091159.129760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 491 0x7fcdfeca42e0 0x9012e657060 , "http://bbs.a9vg.com/forum.php"
[1:1:0711/091159.136017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , (function(){var h={},mt={},c={id:"68e4f3f877acf23e052991a583acf43e",dm:["a9vg.com"],js:"tongji.baidu
[1:1:0711/091159.136317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091159.168808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e148
[1:1:0711/091159.169087:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091159.169486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 611
[28215:28215:0711/091159.169725:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0711/091159.169729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7fcdfcd7c070 0x9012ee772e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 491 0x7fcdfeca42e0 0x9012e657060 
[28215:28215:0711/091159.174954:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[28215:28226:0711/091159.194641:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[28215:28226:0711/091159.194743:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[28215:28215:0711/091159.194919:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://bdtj.tagtic.cn/
[28215:28215:0711/091159.195024:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://bdtj.tagtic.cn/, http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false, 5
[28215:28215:0711/091159.195166:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_http://bdtj.tagtic.cn/, HTTP/1.1 200 OK Server: Tengine Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Date: Thu, 11 Jul 2019 16:11:59 GMT Last-Modified: Fri, 14 Jun 2019 00:46:47 GMT ETag: W/"5d02ee77-200" Access-Control-Allow-Methods: GET,POST,PUT,DELETE,PATCH,OPTIONS Access-Control-Allow-Credentials: true Ali-Swift-Global-Savetime: 1562861519 Via: cache7.l2st3-2[37,200-0,M], cache5.l2st3-2[38,0], cache5.cn538[61,200-0,M], cache2.cn538[62,0] X-Cache: MISS TCP_MISS dirn:-2:-2 X-Swift-SaveTime: Thu, 11 Jul 2019 16:11:59 GMT X-Swift-CacheTime: 172800 Timing-Allow-Origin: * EagleId: 2be0b8ca15628615191548237e Content-Encoding: gzip  ,28310, 5
[1:7:0711/091159.199426:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/091159.728192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/091159.728477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091200.572067:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://bbs.a9vg.com/
[1:1:0711/091200.863563:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 340, 7fcdff6c1881
[1:1:0711/091200.893619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"316 0x7fcdfcd7c070 0x9012e1ef0e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091200.893982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"316 0x7fcdfcd7c070 0x9012e1ef0e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091200.894436:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091200.895024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScroll();}
[1:1:0711/091200.895236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091200.915996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091200.916276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091200.916763:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 676
[1:1:0711/091200.916993:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7fcdfcd7c070 0x9012ed66260 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 340 0x7fcdfcd7c070 0x9012e6c38e0 
[1:1:0711/091201.526184:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_http://bdtj.tagtic.cn/
[1:1:0711/091202.019967:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 611, 7fcdff6c1881
[1:1:0711/091202.041942:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"491 0x7fcdfeca42e0 0x9012e657060 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091202.042288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"491 0x7fcdfeca42e0 0x9012e657060 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091202.042765:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091202.043346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091202.043561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091202.044320:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091202.044745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091202.045114:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 687
[1:1:0711/091202.045355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7fcdfcd7c070 0x9012e5b56e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 611 0x7fcdfcd7c070 0x9012ee772e0 
[1:1:0711/091202.278025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , document.readyState
[1:1:0711/091202.278375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091203.322495:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28215:28215:0711/091203.323909:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://bbs.a9vg.com/, http://bbs.a9vg.com/, 3
[28215:28215:0711/091203.324038:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 5, http://bbs.a9vg.com/, http://bbs.a9vg.com
[1:1:0711/091203.632431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 676, 7fcdff6c1881
[1:1:0711/091203.642968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"340 0x7fcdfcd7c070 0x9012e6c38e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091203.643176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"340 0x7fcdfcd7c070 0x9012e6c38e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091203.643404:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091203.643705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091203.643806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091203.644757:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091203.644862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091203.645036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 748
[1:1:0711/091203.645147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7fcdfcd7c070 0x9012e1c8ee0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 676 0x7fcdfcd7c070 0x9012ed66260 
[28215:28215:0711/091203.812088:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://bdtj.tagtic.cn/, http://bdtj.tagtic.cn/, 5
[28215:28215:0711/091203.812185:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 7, http://bdtj.tagtic.cn/, http://bdtj.tagtic.cn
[1:1:0711/091203.812559:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/091203.897037:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091203.897517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/091203.897630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091203.901828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 687, 7fcdff6c1881
[1:1:0711/091203.922047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"611 0x7fcdfcd7c070 0x9012ee772e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091203.922361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"611 0x7fcdfcd7c070 0x9012ee772e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091203.922730:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091203.923283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091203.923470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091203.924121:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091203.924310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091203.924646:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 770
[1:1:0711/091203.924835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7fcdfcd7c070 0x9012e9dcb60 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 687 0x7fcdfcd7c070 0x9012e5b56e0 
[1:1:0711/091203.961394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , document.readyState
[1:1:0711/091203.961628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091205.095955:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091205.333284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 748, 7fcdff6c1881
[1:1:0711/091205.351054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"676 0x7fcdfcd7c070 0x9012ed66260 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091205.351265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"676 0x7fcdfcd7c070 0x9012ed66260 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091205.351560:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091205.352200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091205.352443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091205.354445:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091205.354599:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091205.354765:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 798
[1:1:0711/091205.354887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7fcdfcd7c070 0x9012e7628e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 748 0x7fcdfcd7c070 0x9012e1c8ee0 
[1:1:0711/091205.440061:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091205.690989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , document.readyState
[1:1:0711/091205.691174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091205.692423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 770, 7fcdff6c1881
[1:1:0711/091205.723421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"687 0x7fcdfcd7c070 0x9012e5b56e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091205.723851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"687 0x7fcdfcd7c070 0x9012e5b56e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091205.724310:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091205.725004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091205.725228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091205.726036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091205.726236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091205.726689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 808
[1:1:0711/091205.726933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7fcdfcd7c070 0x9012e184c60 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 770 0x7fcdfcd7c070 0x9012e9dcb60 
[1:1:0711/091206.108762:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091206.109033:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bbs.a9vg.com/showit/"
[1:1:0711/091206.122035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 795 0x7fcdfcd7c070 0x9012e82abe0 , "http://bbs.a9vg.com/showit/"
[1:1:0711/091206.158800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://bbs.a9vg.com/, 1226aa113958, , , 
//coded by windy_sk <windy2006@gmail.com> 20071105

function reportError(msg,url,line) {
	var str =
[1:1:0711/091206.159096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/showit/", "bbs.a9vg.com", 5, 1, http://bbs.a9vg.com, bbs.a9vg.com, 3
[1:1:0711/091206.556420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 798, 7fcdff6c1881
[1:1:0711/091206.584497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"748 0x7fcdfcd7c070 0x9012e1c8ee0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091206.584926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"748 0x7fcdfcd7c070 0x9012e1c8ee0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091206.585512:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091206.586115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091206.586387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091206.587986:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091206.588190:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091206.588557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 854
[1:1:0711/091206.588849:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 854 0x7fcdfcd7c070 0x9012fa8b760 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 798 0x7fcdfcd7c070 0x9012e7628e0 
[1:1:0711/091206.732485:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091206.732778:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/091206.831995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , document.readyState
[1:1:0711/091206.832501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091206.989660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 808, 7fcdff6c1881
[1:1:0711/091207.007541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"770 0x7fcdfcd7c070 0x9012e9dcb60 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091207.007945:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"770 0x7fcdfcd7c070 0x9012e9dcb60 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091207.008334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091207.008926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091207.009138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091207.009824:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091207.010034:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091207.010411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 871
[1:1:0711/091207.010640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7fcdfcd7c070 0x9012f741760 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 808 0x7fcdfcd7c070 0x9012e184c60 
[28215:28215:0711/091207.411625:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/091207.882006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 854, 7fcdff6c1881
[1:1:0711/091207.922560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"798 0x7fcdfcd7c070 0x9012e7628e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091207.922925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"798 0x7fcdfcd7c070 0x9012e7628e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091207.923337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091207.923893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091207.924128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091207.925866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091207.926110:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091207.926506:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 902
[1:1:0711/091207.926740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 902 0x7fcdfcd7c070 0x9012f1c9260 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 854 0x7fcdfcd7c070 0x9012fa8b760 
[1:1:0711/091208.401772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , document.readyState
[1:1:0711/091208.401967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091208.403232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 871, 7fcdff6c1881
[1:1:0711/091208.418028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"808 0x7fcdfcd7c070 0x9012e184c60 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091208.418268:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"808 0x7fcdfcd7c070 0x9012e184c60 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091208.418519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091208.418832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091208.418947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091208.419340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091208.419473:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091208.419698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 918
[1:1:0711/091208.419851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7fcdfcd7c070 0x9012fc13060 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 871 0x7fcdfcd7c070 0x9012f741760 
[1:1:0711/091208.803798:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/showit/"
[1:1:0711/091208.805750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://bbs.a9vg.com/, 1226aa113958, , window.onload, () {
	sildeInit();
	setInterval("showPic(cur_idx+1)", 5000);
}
[1:1:0711/091208.806044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/showit/", "bbs.a9vg.com", 5, 1, http://bbs.a9vg.com, bbs.a9vg.com, 3
[1:1:0711/091208.824674:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xe9ad859eef8
[1:1:0711/091208.832964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/showit/", 5000
[1:1:0711/091208.833453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://bbs.a9vg.com/, 931
[1:1:0711/091208.833882:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7fcdfcd7c070 0x9012f8e6360 , 5:5_http://bbs.a9vg.com/, 1, -5:5_http://bbs.a9vg.com/, 888 0x7fcdfcd7c070 0x9012fc16e60 
[1:1:0711/091208.835575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091208.836638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_http://bbs.a9vg.com/-5:3_http://bbs.a9vg.com/, 1226aa002860, 1226aa113958, onload, this.height = showit.document.body.scrollHeight;
[1:1:0711/091208.836906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 2, , , 0
[1:1:0711/091208.837323:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[28215:28215:0711/091208.845004:INFO:CONSOLE(157)] "Uncaught TypeError: Cannot read property 'body' of undefined", source: http://bbs.a9vg.com/forum.php (157)
[1:1:0711/091209.385215:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 902, 7fcdff6c1881
[1:1:0711/091209.405583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"854 0x7fcdfcd7c070 0x9012fa8b760 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091209.405946:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"854 0x7fcdfcd7c070 0x9012fa8b760 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091209.406509:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091209.407090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091209.407326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091209.408887:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091209.409085:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091209.409477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 951
[1:1:0711/091209.409710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7fcdfcd7c070 0x9012fc311e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 902 0x7fcdfcd7c070 0x9012f1c9260 
[1:1:0711/091209.718898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 916 0x7fcdfd0e4bd0 0x9012de07b58 , "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/091209.723490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://bdtj.tagtic.cn/, 1226aa0cc370, , , !function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};ret
[1:1:0711/091209.723768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false", "bdtj.tagtic.cn", 7, 1, http://bbs.a9vg.com, bbs.a9vg.com, 3
[1:1:0711/091209.861726:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 916 0x7fcdfd0e4bd0 0x9012de07b58 , "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/091210.181569:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091210.182241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:7_http://bdtj.tagtic.cn/-5:3_http://bbs.a9vg.com/, 1226aa002860, 1226aa0cc370, cheatJS, (){var t=navigator.userAgent,e='<iframe src="//push.ppnad.com/pc/pc003.html" style="display: none;">
[1:1:0711/091210.182499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 2, , , 0
[1:1:0711/091210.182950:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0711/091210.190872:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/091210.197600:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x9012fb46220
[1:1:0711/091210.197870:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[28215:28215:0711/091210.202056:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[28215:28215:0711/091210.209916:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 6, 
[1:1:0711/091210.225399:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/091210.225690:INFO:render_frame_impl.cc(7019)] 	 [url] = http://bbs.a9vg.com
[1:1:0711/091210.227897:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091210.229640:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[28215:28215:0711/091210.235811:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:7_http://bdtj.tagtic.cn/
[1:1:0711/091210.235901:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x9012fb32220
[1:1:0711/091210.236546:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[28215:28215:0711/091210.245013:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[28215:28215:0711/091210.246900:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 7, 
[1:1:0711/091210.247860:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/091210.248087:INFO:render_frame_impl.cc(7019)] 	 [url] = http://bbs.a9vg.com
[1:1:0711/091210.250269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091210.253618:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://bbs.a9vg.com/forum.php"
[1:1:0711/091210.255056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e2f0
[1:1:0711/091210.255259:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091210.255655:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_http://bdtj.tagtic.cn/, 985
[1:1:0711/091210.255887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7fcdfcd7c070 0x9012fc98260 , 5:7_http://bdtj.tagtic.cn/, 2, -5:7_http://bdtj.tagtic.cn/-5:3_http://bbs.a9vg.com/, 916 0x7fcdfd0e4bd0 0x9012de07b58 
[28215:28215:0711/091210.258725:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:7_http://bdtj.tagtic.cn/
[28215:28215:0711/091210.290968:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28215:28215:0711/091210.297060:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/091210.305835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , document.readyState
[1:1:0711/091210.306100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[28215:28226:0711/091210.319456:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[28215:28226:0711/091210.319578:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[28215:28215:0711/091210.319736:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://push.ppnad.com/
[28215:28215:0711/091210.319812:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://push.ppnad.com/, http://push.ppnad.com/pc/pc003.html, 6
[28215:28215:0711/091210.319939:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_http://push.ppnad.com/, HTTP/1.1 200 OK Server: marco/2.10 Date: Thu, 11 Jul 2019 16:12:10 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Request-Id: a6447cea4b853253e2968b28fc1b29dc; 0730706a8cfe6f1f6377708d7f0f3f94; 92a1f073551e36c8949d6198d769c339; 03b99bfe99f229406d178898dace2707 X-Source: U/200 X-Upyun-Content-Length: 10125 ETag: W/"5baccc968e55b2b7dfa7995140da4d4e" Last-Modified: Thu, 11 Jul 2019 15:32:44 GMT X-Upyun-Content-Type: text/html Expires: Fri, 19 Jul 2019 15:32:43 GMT Cache-Control: max-age=691200 Age: 2367 Via: T.102.H, V.403-zj-sad-102, S.mix-sd-dst-068, T.71.H, V.mix-sd-dst-073, T.3.H, M.gwn-bj-pek-003 Content-Encoding: gzip  ,28310, 5
[28215:28215:0711/091210.320867:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[28215:28215:0711/091210.324679:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0711/091210.324879:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[28215:28226:0711/091210.345156:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[28215:28226:0711/091210.345244:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[28215:28215:0711/091210.345400:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://push.ppnad.com/
[28215:28215:0711/091210.345474:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://push.ppnad.com/, http://push.ppnad.com/pc/pc003.html, 7
[28215:28215:0711/091210.345629:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_http://push.ppnad.com/, HTTP/1.1 200 OK Server: marco/2.10 Date: Thu, 11 Jul 2019 16:12:10 GMT Content-Type: text/html Vary: Accept-Encoding X-Request-Id: a6447cea4b853253e2968b28fc1b29dc; 0730706a8cfe6f1f6377708d7f0f3f94; 92a1f073551e36c8949d6198d769c339; 03b99bfe99f229406d178898dace2707 X-Source: U/200 X-Upyun-Content-Length: 10125 ETag: W/"5baccc968e55b2b7dfa7995140da4d4e" Last-Modified: Thu, 11 Jul 2019 15:32:44 GMT X-Upyun-Content-Type: text/html Expires: Fri, 19 Jul 2019 15:32:43 GMT Cache-Control: max-age=691200 Age: 2367 Via: T.102.H, V.403-zj-sad-102, S.mix-sd-dst-068, T.71.H, V.mix-sd-dst-073, T.3.H, M.gwn-bj-pek-003 Content-Encoding: gzip  ,28310, 5
[1:7:0711/091210.358768:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/091211.057786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 951, 7fcdff6c1881
[1:1:0711/091211.080046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"902 0x7fcdfcd7c070 0x9012f1c9260 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091211.080392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"902 0x7fcdfcd7c070 0x9012f1c9260 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091211.080803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091211.081434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091211.081647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091211.083529:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091211.083769:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091211.084167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 1016
[1:1:0711/091211.084397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7fcdfcd7c070 0x901301a0360 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 951 0x7fcdfcd7c070 0x9012fc311e0 
[1:1:0711/091211.964943:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/091211.968050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://bdtj.tagtic.cn/, 1226aa0cc370, , d.(anonymous function), (){if(d&&(4===d.readyState||m)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0711/091211.968322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false", "bdtj.tagtic.cn", 7, 1, http://bbs.a9vg.com, bbs.a9vg.com, 3
[1:1:0711/091211.970726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/091211.974782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-11T16%3A11%3A58.946Z&suuid=26f31bfbca552ca0e7db70a2e2b8b9c4&appkey=weba9vgweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=http%3A%2F%2Fbbs.a9vg.com%2Fforum.php&referer=&request_method=get&page_id=d813912cd9fe9277ac169110a2f5d7d3&short_cookie=5a3f663976a247c7a90995bfcf334418&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/091212.093411:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:8_http://push.ppnad.com/
[1:1:0711/091212.296435:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:9_http://push.ppnad.com/
[1:1:0711/091212.496810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_http://bdtj.tagtic.cn/, 985, 7fcdff6c1881
[1:1:0711/091212.520594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa0cc3701226aa002860","ptid":"916 0x7fcdfd0e4bd0 0x9012de07b58 ","rf":"5:7_http://bdtj.tagtic.cn/"}
[1:1:0711/091212.520980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:7_http://bdtj.tagtic.cn/-5:3_http://bbs.a9vg.com/","ptid":"916 0x7fcdfd0e4bd0 0x9012de07b58 ","rf":"5:7_http://bdtj.tagtic.cn/"}
[1:1:0711/091212.521369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091212.521927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091212.522161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091212.522879:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091212.523098:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091212.523472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_http://bdtj.tagtic.cn/, 1040
[1:1:0711/091212.523698:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7fcdfcd7c070 0x9012fdc3360 , 5:7_http://bdtj.tagtic.cn/, 1, -5:3_http://bbs.a9vg.com/, 985 0x7fcdfcd7c070 0x9012fc98260 
[1:1:0711/091212.964255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 1016, 7fcdff6c1881
[1:1:0711/091212.995620:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"951 0x7fcdfcd7c070 0x9012fc311e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091212.996021:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"951 0x7fcdfcd7c070 0x9012fc311e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091212.996497:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091212.997150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091212.997396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091212.999535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091212.999743:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091213.000152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 1053
[1:1:0711/091213.000425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1053 0x7fcdfcd7c070 0x9012fdc08e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 1016 0x7fcdfcd7c070 0x901301a0360 
[1:1:0711/091213.285417:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28215:28215:0711/091213.288317:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://push.ppnad.com/, http://push.ppnad.com/, 6
[28215:28215:0711/091213.288362:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 8, http://push.ppnad.com/, http://push.ppnad.com
[1:1:0711/091213.402208:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[28215:28215:0711/091213.407932:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://push.ppnad.com/, http://push.ppnad.com/, 7
[28215:28215:0711/091213.408014:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 9, http://push.ppnad.com/, http://push.ppnad.com
[1:1:0711/091213.501855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_http://bdtj.tagtic.cn/, 1040, 7fcdff6c1881
[1:1:0711/091213.548582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"985 0x7fcdfcd7c070 0x9012fc98260 ","rf":"5:7_http://bdtj.tagtic.cn/"}
[1:1:0711/091213.548908:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"985 0x7fcdfcd7c070 0x9012fc98260 ","rf":"5:7_http://bdtj.tagtic.cn/"}
[1:1:0711/091213.549264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091213.549813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091213.549990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091213.550615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091213.550802:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091213.551137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_http://bdtj.tagtic.cn/, 1085
[1:1:0711/091213.551326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7fcdfcd7c070 0x9012fc93560 , 5:7_http://bdtj.tagtic.cn/, 1, -5:3_http://bbs.a9vg.com/, 1040 0x7fcdfcd7c070 0x9012fdc3360 
[1:1:0711/091213.835347:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 1053, 7fcdff6c1881
[1:1:0711/091213.862668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"1016 0x7fcdfcd7c070 0x901301a0360 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091213.862898:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"1016 0x7fcdfcd7c070 0x901301a0360 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091213.863134:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091213.863437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091213.863548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091213.864394:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091213.864498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091213.864665:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 1099
[1:1:0711/091213.864773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7fcdfcd7c070 0x9012e17e5e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 1053 0x7fcdfcd7c070 0x9012fdc08e0 
[1:1:0711/091213.926372:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091214.264349:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/091214.561404:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_http://bdtj.tagtic.cn/, 1085, 7fcdff6c1881
[1:1:0711/091214.608908:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"1040 0x7fcdfcd7c070 0x9012fdc3360 ","rf":"5:7_http://bdtj.tagtic.cn/"}
[1:1:0711/091214.609235:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"1040 0x7fcdfcd7c070 0x9012fdc3360 ","rf":"5:7_http://bdtj.tagtic.cn/"}
[1:1:0711/091214.609567:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091214.610115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/091214.610293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091214.610914:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091214.611116:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 100
[1:1:0711/091214.611447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_http://bdtj.tagtic.cn/, 1112
[1:1:0711/091214.611635:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7fcdfcd7c070 0x9012fcc5c60 , 5:7_http://bdtj.tagtic.cn/, 1, -5:3_http://bbs.a9vg.com/, 1085 0x7fcdfcd7c070 0x9012fc93560 
[1:1:0711/091214.808418:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://bbs.a9vg.com/, 931, 7fcdff6c18db
[1:1:0711/091214.855867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa113958","ptid":"888 0x7fcdfcd7c070 0x9012fc16e60 ","rf":"5:5_http://bbs.a9vg.com/"}
[1:1:0711/091214.856223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:5_http://bbs.a9vg.com/","ptid":"888 0x7fcdfcd7c070 0x9012fc16e60 ","rf":"5:5_http://bbs.a9vg.com/"}
[1:1:0711/091214.856618:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:5_http://bbs.a9vg.com/, 1115
[1:1:0711/091214.856824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1115 0x7fcdfcd7c070 0x901301c6fe0 , 5:5_http://bbs.a9vg.com/, 0, , 931 0x7fcdfcd7c070 0x9012f8e6360 
[1:1:0711/091214.857177:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/showit/"
[1:1:0711/091214.857965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://bbs.a9vg.com/, 1226aa113958, , , showPic(cur_idx+1)
[1:1:0711/091214.858331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/showit/", "bbs.a9vg.com", 5, 1, http://bbs.a9vg.com, bbs.a9vg.com, 3
[1:1:0711/091214.861673:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xe9ad8567690
[1:1:0711/091214.863487:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xe9ad8567840
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/091215.180967:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 1099, 7fcdff6c1881
[1:1:0711/091215.226530:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1226aa002860","ptid":"1053 0x7fcdfcd7c070 0x9012fdc08e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091215.226843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://bbs.a9vg.com/","ptid":"1053 0x7fcdfcd7c070 0x9012fdc08e0 ","rf":"5:3_http://bbs.a9vg.com/"}
[1:1:0711/091215.227236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://bbs.a9vg.com/forum.php"
[1:1:0711/091215.227591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://bbs.a9vg.com/, 1226aa002860, , , () {ann.announcementScrollnext(time);}
[1:1:0711/091215.227733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://bbs.a9vg.com/forum.php", "bbs.a9vg.com", 3, 1, , , 0
[1:1:0711/091215.228552:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x881fbae29c8, 0x9012e30e150
[1:1:0711/091215.228663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://bbs.a9vg.com/forum.php", 10
[1:1:0711/091215.228828:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://bbs.a9vg.com/, 1131
[1:1:0711/091215.228940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1131 0x7fcdfcd7c070 0x901301d51e0 , 5:3_http://bbs.a9vg.com/, 1, -5:3_http://bbs.a9vg.com/, 1099 0x7fcdfcd7c070 0x9012e17e5e0 
[1:1:0711/091215.304113:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/091215.304295:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://push.ppnad.com/pc/pc003.html"
[1:1:0711/091215.307114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1104 0x7fcdfcd7c070 0x901301f88e0 , "http://push.ppnad.com/pc/pc003.html"
[1:1:0711/091215.345098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://push.ppnad.com/, 1226aa0ab068, , , 
 (function() {
    if (is_pc()) {
        l_yd();
    }
})();
var vol_openedWindow;

function l_yd(
[1:1:0711/091215.345990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://push.ppnad.com/pc/pc003.html", "push.ppnad.com", 8, 1, http://bbs.a9vg.com, bbs.a9vg.com, 3
