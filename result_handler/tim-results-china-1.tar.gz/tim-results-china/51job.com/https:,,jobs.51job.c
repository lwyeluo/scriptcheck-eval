[0712/100637.984743:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/100637.985290:INFO:switcher_clone.cc(787)] backtrace rip is 7fe2a0e1b891
[0712/100638.850023:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/100638.850430:INFO:switcher_clone.cc(787)] backtrace rip is 7f18c374f891
[1:1:0712/100638.859588:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/100638.859835:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/100638.864548:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[121759:121759:0712/100640.089754:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4f4b639c-0899-4a25-bd1f-d33a8d3373b8
[0712/100640.406214:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/100640.406517:INFO:switcher_clone.cc(787)] backtrace rip is 7f4563d0e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[121759:121759:0712/100640.584062:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[121759:121790:0712/100640.584916:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/100640.585153:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/100640.585411:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/100640.585996:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/100640.586151:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/100640.588889:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x294378eb, 1
[1:1:0712/100640.589323:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1db47b61, 0
[1:1:0712/100640.589555:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x213c45dc, 3
[1:1:0712/100640.589766:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x14feb1f2, 2
[1:1:0712/100640.589993:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 617bffffffb41d ffffffeb784329 fffffff2ffffffb1fffffffe14 ffffffdc453c21 , 10104, 4
[1:1:0712/100640.590990:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[121759:121790:0712/100640.591268:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGa{��xC)���E<!�&%
[121759:121790:0712/100640.591356:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is a{��xC)���E<!�A�&%
[1:1:0712/100640.591258:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18c198a0a0, 3
[121759:121790:0712/100640.591667:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/100640.591554:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18c1b15080, 2
[121759:121790:0712/100640.591738:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 121805, 4, 617bb41d eb784329 f2b1fe14 dc453c21 
[1:1:0712/100640.591762:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18ab7d8d20, -2
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/100640.611270:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/100640.612178:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14feb1f2
[1:1:0712/100640.613219:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14feb1f2
[1:1:0712/100640.614832:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14feb1f2
[1:1:0712/100640.616407:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.616660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.616950:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.617203:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.617997:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14feb1f2
[1:1:0712/100640.618401:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18c374f7ba
[1:1:0712/100640.618571:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18c3746def, 7f18c374f77a, 7f18c37510cf
[121792:121792:0712/100640.620647:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=121792
[121806:121806:0712/100640.621118:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=121806
[1:1:0712/100640.625454:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14feb1f2
[1:1:0712/100640.625774:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14feb1f2
[1:1:0712/100640.626243:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14feb1f2
[1:1:0712/100640.627385:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.627541:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.627683:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.627847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14feb1f2
[1:1:0712/100640.628580:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14feb1f2
[1:1:0712/100640.628827:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18c374f7ba
[1:1:0712/100640.628953:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18c3746def, 7f18c374f77a, 7f18c37510cf
[1:1:0712/100640.632655:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/100640.633058:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/100640.633198:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff00143f28, 0x7fff00143ea8)
[1:1:0712/100640.653941:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/100640.658207:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[121759:121782:0712/100641.155582:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[121759:121759:0712/100641.189885:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[121759:121759:0712/100641.191453:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/100641.214047:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x38055a23e220
[1:1:0712/100641.214339:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[121759:121771:0712/100641.216979:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[121759:121771:0712/100641.217072:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[121759:121759:0712/100641.217243:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[121759:121759:0712/100641.217322:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[121759:121759:0712/100641.217501:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,121805, 4
[1:7:0712/100641.221120:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/100641.833454:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/100643.258674:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/100643.263369:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[121759:121759:0712/100643.302025:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[121759:121759:0712/100643.302167:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/100644.699858:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/100644.913748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21796f941f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/100644.914054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/100644.930664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21796f941f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/100644.930950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/100645.091579:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/100645.091882:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100645.525034:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100645.533291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21796f941f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/100645.533620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/100645.568787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100645.572725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21796f941f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/100645.573002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/100645.585284:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[121759:121759:0712/100645.588406:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/100645.588892:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x38055a23ce20
[1:1:0712/100645.589137:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[121759:121759:0712/100645.595260:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[121759:121759:0712/100645.631555:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[121759:121759:0712/100645.631722:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/100645.693522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100646.447351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f18ad3b32e0 0x38055a54c660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100646.448785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21796f941f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/100646.448982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/100646.450449:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100646.517317:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x38055a23d820
[1:1:0712/100646.517610:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[121759:121759:0712/100646.518412:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/100646.533381:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/100646.533549:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[121759:121759:0712/100646.538351:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[121759:121759:0712/100646.569525:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[121759:121759:0712/100646.593435:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[121759:121759:0712/100646.594468:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[121759:121771:0712/100646.600820:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[121759:121771:0712/100646.600916:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[121759:121759:0712/100646.605513:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[121759:121759:0712/100646.605626:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[121759:121759:0712/100646.605775:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,121805, 4
[1:7:0712/100646.607866:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/100647.029013:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/100647.529614:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f18ad3b32e0 0x38055a5d3de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100647.530682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21796f941f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/100647.530917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/100647.531642:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[121759:121759:0712/100647.643186:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[121759:121759:0712/100647.643259:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/100647.655981:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/100648.018463:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[121759:121759:0712/100648.184370:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[121759:121790:0712/100648.184851:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/100648.185124:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/100648.185327:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/100648.185731:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/100648.185876:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/100648.189351:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3a947afc, 1
[1:1:0712/100648.189746:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x14a99e0c, 0
[1:1:0712/100648.189903:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2492de0f, 3
[1:1:0712/100648.190092:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x311114e7, 2
[1:1:0712/100648.190247:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 0cffffff9effffffa914 fffffffc7affffff943a ffffffe7141131 0fffffffdeffffff9224 , 10104, 5
[1:1:0712/100648.191279:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[121759:121790:0712/100648.191513:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���z�:�1ޒ$��&%
[121759:121790:0712/100648.191593:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���z�:�1ޒ$����&%
[1:1:0712/100648.191703:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18c198a0a0, 3
[121759:121790:0712/100648.191884:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 121856, 5, 0c9ea914 fc7a943a e7141131 0fde9224 
[1:1:0712/100648.191882:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18c1b15080, 2
[1:1:0712/100648.192151:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18ab7d8d20, -2
[1:1:0712/100648.210352:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/100648.210697:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 311114e7
[1:1:0712/100648.211044:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 311114e7
[1:1:0712/100648.211665:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 311114e7
[1:1:0712/100648.213080:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.213272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.213451:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.213632:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.214326:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 311114e7
[1:1:0712/100648.214615:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18c374f7ba
[1:1:0712/100648.214753:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18c3746def, 7f18c374f77a, 7f18c37510cf
[1:1:0712/100648.220732:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 311114e7
[1:1:0712/100648.221206:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 311114e7
[1:1:0712/100648.222003:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 311114e7
[1:1:0712/100648.224062:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.224282:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.224468:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.224663:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 311114e7
[1:1:0712/100648.225910:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 311114e7
[1:1:0712/100648.226146:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18c374f7ba
[1:1:0712/100648.226237:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18c3746def, 7f18c374f77a, 7f18c37510cf
[1:1:0712/100648.228457:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/100648.228819:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/100648.228924:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff00143f28, 0x7fff00143ea8)
[1:1:0712/100648.241076:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/100648.246002:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/100648.492944:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x38055a1f3220
[1:1:0712/100648.493183:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/100648.569451:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/100648.569757:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/100649.126173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/100649.131887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21796fa6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/100649.132371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/100649.142329:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[121759:121759:0712/100649.237714:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[121759:121759:0712/100649.244033:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[121759:121771:0712/100649.282962:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[121759:121771:0712/100649.283064:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[121759:121759:0712/100649.283507:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://jobs.51job.com/
[121759:121759:0712/100649.283607:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://jobs.51job.com/, https://jobs.51job.com/, 1
[121759:121759:0712/100649.283766:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://jobs.51job.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:06:49 GMT Server: Apache Keep-Alive: timeout=10, max=192 Connection: Keep-Alive Content-Type: text/html; charset=GB2312 Cache-Control: private Content-Encoding: gzip Transfer-Encoding: chunked  ,121856, 5
[1:7:0712/100649.287633:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/100649.327152:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/100649.327942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21796f941f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/100649.330742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/100649.338160:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://jobs.51job.com/
[1:1:0712/100649.496028:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[121759:121759:0712/100649.507218:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://jobs.51job.com/, https://jobs.51job.com/, 1
[121759:121759:0712/100649.507382:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://jobs.51job.com/, https://jobs.51job.com
[1:1:0712/100649.543269:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/100649.599509:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/100649.625882:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/100649.626134:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jobs.51job.com/"
[1:1:0712/100649.714617:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/100649.889215:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/100649.890888:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/100649.891147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21796fa6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/100649.891479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/100650.023214:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/100650.024243:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/100650.024502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21796fa6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/100650.024763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/100650.070964:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f18c1b15080 0x38055a25ac40 1 0 0x38055a25ac58 , "https://jobs.51job.com/"
[1:1:0712/100650.100816:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/100650.111456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};ret
[1:1:0712/100650.111770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/100650.743038:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f18ab48b070 0x38055a32a860 , "https://jobs.51job.com/"
[1:1:0712/100650.747357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , , !function(e){var t=window.webpackJsonp;window.webpackJsonp=function(a,o,i){for(var c,s,l,d=0,y=[];d<
[1:1:0712/100650.747607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
[1:1:0712/100650.758288:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f18ab48b070 0x38055a32a860 , "https://jobs.51job.com/"
[1:1:0712/100650.819340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f18ab48b070 0x38055a32a860 , "https://jobs.51job.com/"
[1:1:0712/100650.841516:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f18ab48b070 0x38055a32a860 , "https://jobs.51job.com/"
[1:1:0712/100650.914875:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.164791, 920, 1
[1:1:0712/100650.915174:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/100650.971385:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/100650.971696:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jobs.51job.com/"
[1:1:0712/100650.972670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 212 0x7f18ab48b070 0x38055a4bc960 , "https://jobs.51job.com/"
[1:1:0712/100650.974113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , , 
    function areaChannelChangeTab(sName, oEvent)
    {
        $("#area_channel_layer_all").childre
[1:1:0712/100650.974399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
[1:1:0712/100651.440807:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.469002, 3580, 1
[1:1:0712/100651.441118:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/100651.534196:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/100651.534472:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jobs.51job.com/"
[1:1:0712/100651.535422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18ab48b070 0x38055a554360 , "https://jobs.51job.com/"
[1:1:0712/100651.538866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , , 
			<!--
				window.cfg = {
					fileName: '' ,
					lang : 'c' ,
					stype : '' ,
					fullLang : 
[1:1:0712/100651.539132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
[1:1:0712/100651.547433:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://jobs.51job.com/"
[1:1:0712/100655.121221:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://jobs.51job.com/"
[1:1:0712/100655.121995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0712/100655.122230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
[1:1:0712/100655.122728:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://jobs.51job.com/"
[1:1:0712/100655.124609:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x20e422c829c8, 0x380559fc21f0
[1:1:0712/100655.124823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jobs.51job.com/", 2000
[1:1:0712/100655.125186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jobs.51job.com/, 253
[1:1:0712/100655.125410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 253 0x7f18ab48b070 0x38055a325ce0 , 5:3_https://jobs.51job.com/, 1, -5:3_https://jobs.51job.com/, 237
[1:1:0712/100657.131596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jobs.51job.com/, 253, 7f18addd0881
[1:1:0712/100657.139836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"11e79b8a2860","ptid":"237","rf":"5:3_https://jobs.51job.com/"}
[1:1:0712/100657.140113:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jobs.51job.com/","ptid":"237","rf":"5:3_https://jobs.51job.com/"}
[1:1:0712/100657.140410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jobs.51job.com/"
[1:1:0712/100657.140949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , , (){var t=initTrackParams(e);e.requestFunc(t.rankParamsToStr(t.params,t.paramsRank))}
[1:1:0712/100657.141193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
[1:1:0712/100657.381909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://jobs.51job.com/"
[1:1:0712/100657.382636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , n.onload.n.onerror, (){a[r]=null}
[1:1:0712/100657.382863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
[1:1:0712/100658.314129:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/100658.314690:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/100658.315209:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/100658.315716:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/100658.316184:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/100713.442470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jobs.51job.com/, 11e79b8a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/100713.443035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jobs.51job.com/", "jobs.51job.com", 3, 1, , , 0
[121759:121759:0712/100713.906531:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/100713.916267:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
